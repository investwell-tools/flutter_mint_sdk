package investwell.textview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Build;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import com.iw.mint.sdk.R;


public class AppTextViewDesc extends AppCompatTextView {

    public AppTextViewDesc(Context context) {
        super(context);
        init(null, context);
    }

    public AppTextViewDesc(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(attrs, context);
    }

    public AppTextViewDesc(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, context);
    }

    private void init(@Nullable AttributeSet attrs, Context context) {
        if (attrs == null) return;

        // Load attributes
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.CustomTextView);

        // Set font family
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int fontResId = typedArray.getResourceId(R.styleable.CustomTextView_customFontFamilyRes, -1);
            Typeface typeface = AppTextView.getCachedFont(context, fontResId != -1 ? fontResId : R.font.lato);
            if (typeface != null) {
                setTypeface(typeface, getTypeface() != null ? getTypeface().getStyle() : Typeface.NORMAL);
            }
        }else{
           /* String fontFamily = typedArray.getString(R.styleable.CustomTextView_customFontFamily);
            if (fontFamily != null) {
                Typeface typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/" + fontFamily);
                setTypeface(typeface);
            }else{
                this.setTypeface(Typeface.createFromAsset(getContext().getAssets(),   "Roboto-Bold.ttf"));
            }  */
        }



        // Set font color
        int textColor = typedArray.getColor(R.styleable.CustomTextView_customFontColor, getCurrentTextColor());
        if (textColor == getCurrentTextColor()){
            setTextColor(ContextCompat.getColor(context, R.color.black_light));
        }else{
            setTextColor(textColor);
        }

        // Set font size
        float fontSize = typedArray.getDimension(R.styleable.CustomTextView_customTextSize, getTextSize());
        if (fontSize == getTextSize()){
            setTextSize(12);
        }else{
            setTextSize(fontSize );
        }

        typedArray.recycle();
    }
}

