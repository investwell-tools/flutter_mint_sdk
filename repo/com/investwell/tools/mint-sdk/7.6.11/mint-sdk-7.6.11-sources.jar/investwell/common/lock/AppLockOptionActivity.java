package investwell.common.lock;

import static investwell.utils.UtilityKotlin.applyAccessibilityList;
import static investwell.utils.UtilityKotlin.setAccessibilityRole;

import android.app.KeyguardManager;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.BaseActivity;
import investwell.activity.LoginActivity;
import investwell.activity.TwoFactorOTPVerifyActivity;
import investwell.admin.activity.AdminActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.CrmBuilder;
import investwell.utils.Extensions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class AppLockOptionActivity extends BaseActivity implements View.OnClickListener {
    private AppSession mSession;
    static public int DEFAULT_LOCK_CODE = 99, CUSTOM_PIN_LOCK_CODE = 100;
    private RadioGroup mRadioGroup;
    private AppApplication mApplication;
    private String mType = "", mCallFrom = "", mDomainName = "";
    private ImageView mRb1, mRb2, mRb3;
    private String mClickedView = "default";
    private Intent mIntent;

    @Override
    public void onBackPressedHandled() {
        if (!mType.equalsIgnoreCase("set_screen_lock")) {
            finish();
            System.exit(0);
        }
        super.onBackPressedHandled();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        Extensions.checkDevice(this);
        mIntent = getIntent();
        mSession = AppSession.getInstance(AppLockOptionActivity.this);
        mApplication = (AppApplication) getApplication();
        System.out.println("MintLifeCycle"+ " Applock screen called");

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("type")) {
            mType = intent.getStringExtra("type");
            mCallFrom = intent.getStringExtra("callFrom");
            LoginActivity.sCallingFrom = "login";

            if (mType.equalsIgnoreCase("set_screen_lock")) {
                setContentView(R.layout.activity_applock_options);
                mRadioGroup = findViewById(R.id.radioGroup1);

                mRadioGroup.setFocusable(true);
                mRadioGroup.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
                mRadioGroup.announceForAccessibility(getString(R.string.list_of_3_options));
                updateAccessibility();

                findViewById(R.id.iv_back_lock).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onBackPressedHandled();
                        finish();
                    }
                });
                findViewById(R.id.cl_radio_1).setOnClickListener(v -> {
                    mClickedView = "default";
                    updateAccessibility();
                    mRb1.setImageResource(R.drawable.ic_check_mark_active);
                    mRb2.setImageResource(R.drawable.ic_check_mark);
                    findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock_selected);
                    findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
                    findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock);
                    mRb3.setImageResource(R.drawable.ic_check_mark);
                    verifyAppLock();
                });
                findViewById(R.id.cl_radio_2).setOnClickListener(v -> {
                    mClickedView = "pin";
                    updateAccessibility();
                    findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock_selected);
                    findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
                    findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock);
                    mRb2.setImageResource(R.drawable.ic_check_mark_active);
                    mRb1.setImageResource(R.drawable.ic_check_mark);
                    mRb3.setImageResource(R.drawable.ic_check_mark);
                    verifyAppLock();
                });
                findViewById(R.id.cl_radio_3).setOnClickListener(v -> {
                    mClickedView = "nothing";
                    updateAccessibility();
                    findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock_selected);
                    findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
                    findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
                    mRb3.setImageResource(R.drawable.ic_check_mark_active);
                    mRb1.setImageResource(R.drawable.ic_check_mark);
                    mRb2.setImageResource(R.drawable.ic_check_mark);
                    verifyAppLock();
                });
                findViewById(R.id.btnContinue).setOnClickListener(this);


            } else if (mType.equalsIgnoreCase("verify_lock")) {
                verifyAppLock();
            }

        }
        initializer();
        if (intent != null && intent.hasExtra("domain_name")) {
            mDomainName = intent.getStringExtra("domain_name");
        } else {
            mDomainName = mSession.getUserBrokerDomain();
        }

    }

    private void applyRadioContentDescription(Integer index, View view, String value, String label) {
        boolean isSelected = value.equals(mClickedView);

        String description;

        if (isSelected) {
            description = label + ". In List. Button" +index +"of 3. selected";
        } else {
            description = label + ". In List. Button" +index +"of 3. not selected";
        }

        view.setContentDescription(description);
    }
    private void updateAccessibility() {
        applyRadioContentDescription(
                1,
                findViewById(R.id.cl_radio_1),
                "default",
                getString(R.string.pin_text_default_screen_lock) + ". " + getString(R.string.pin_text_default_screen_lock_details)
        );

        applyRadioContentDescription(
                2,
                findViewById(R.id.cl_radio_2),
                "pin",
                getString(R.string.pin_text_Create_PIN) + ". " + getString(R.string.pin_text_Create_PIN_Details)
        );

        applyRadioContentDescription(
                3,
                findViewById(R.id.cl_radio_3),
                "nothing",
                getString(R.string.pin_text_SKIP) + ". " + getString(R.string.i_would_like_to_enter_my_username_and_password_everytime)
        );
    }



    private void initializer() {
        mRb1 = findViewById(R.id.radioButton);
        mRb2 = findViewById(R.id.radioButton2);
        mRb3 = findViewById(R.id.radioButton3);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnContinue) {
                verifyAppLock();
}
    }

    private void verifyAppLock() {
        if (mType.equalsIgnoreCase("set_screen_lock")) {
            if (mClickedView.equalsIgnoreCase("default")) {
                mSession.setAppLockType("default");
            } else if (mClickedView.equalsIgnoreCase("pin")) {
                mSession.setAppLockType("pin");
            } else if (mClickedView.equalsIgnoreCase("nothing")) {
                mSession.setAppLockType("nothing");
            }

        }

        if (mSession.getAppLockType().equalsIgnoreCase("default")) {
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km.isKeyguardSecure()) {
                mSession.setHasAppLockEnable(true);
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Intent i = km.createConfirmDeviceCredentialIntent(getString(R.string.txt_use_your_screen_lock_pattern_to_login), "");
                    startActivityForResult(i, DEFAULT_LOCK_CODE);
                }
            } else {
                mSession.setHasAppLockEnable(false);
                mApplication.showCommonDailog(AppLockOptionActivity.this, getString(R.string.Error), getString(R.string.text_no_screen_lock), "message");
            }
        } else if (mSession.getAppLockType().equalsIgnoreCase("pin")) {
            mSession.setHasAppLockEnable(true);
            Intent intent = new Intent(getApplicationContext(), PinLockActivity.class);
            intent.putExtra("type", mType);
            startActivityForResult(intent, CUSTOM_PIN_LOCK_CODE);
        } else if (mSession.getAppLockType().equalsIgnoreCase("nothing")) {
            mSession.setHasAppLockEnable(false);
            if (mSession.getLoginType().equals("broker")) {
                Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                CrmBuilder.copyStringExtras(
                        mIntent,
                        intent,
                        "coming_from",
                        "data"
                );
                if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                    intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                }
                AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();

            } else if (mSession.getLoginType().equals("admin")) {
                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            } else {

                Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                    intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                }
                AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();

            }
        } else {
            mSession.setHasAppLockEnable(true);
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km.isKeyguardSecure()) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Intent i = km.createConfirmDeviceCredentialIntent(getString(R.string.txt_use_your_screen_lock_pattern_to_login), "");
                    startActivityForResult(i, DEFAULT_LOCK_CODE);
                }
            } else {
                mApplication.showCommonDailog(AppLockOptionActivity.this, getString(R.string.Error), getString(R.string.text_no_screen_lock), "message");

            }
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK && requestCode == DEFAULT_LOCK_CODE)) {
            mApplication.removedTempData();
            if (mType.equalsIgnoreCase("verify_lock")) {
                mApplication.mFirstTimeSkippedApplock = false;
                if (mCallFrom.equalsIgnoreCase("application") && mSession.getHasLoging()) {
                    String reAuth = mSession.getLastReAuthTime();
                    if (mSession.getHasLoging() && !reAuth.equals("")) {
                        activitySelection();
                    }else{
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        System.exit(0);
                    }

                }else if (mCallFrom.equalsIgnoreCase("splash") && mSession.getHasLoging()) {
                    String reAuth = mSession.getLastReAuthTime();
                    if (mSession.getHasLoging() && !reAuth.equals("")) {
                        activitySelection();
                    }else{
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        System.exit(0);
                    }

                } else {
                    String reAuth = mSession.getLastReAuthTime();
                    if (mSession.getHasLoging() && !reAuth.equals("")) {
                        activitySelection();
                      /*  long lastAdDateTime = Long.parseLong(reAuth);
                        long seconds = UtilityKotlin.getTimeDifferenceSeconds(lastAdDateTime);
                        double minutes = ((double) seconds / 60);
                        if (minutes > 25) {
                            reLogin();
                        }else{
                            activitySelection();
                        }*/
                    }else{
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        System.exit(0);
                    }

                }

            } else {
               activitySelection();
            }
        } else if ((resultCode == RESULT_CANCELED && requestCode == DEFAULT_LOCK_CODE)) {
            if (mType.equalsIgnoreCase("set_screen_lock")) {
                mSession.setAppLockType("");
                mSession.setHasAppLockEnable(false);
            } else {
                onBackPressedHandled();
            }
        } else if ((resultCode == RESULT_CANCELED && requestCode == CUSTOM_PIN_LOCK_CODE)) {
            if (mType.equalsIgnoreCase("set_screen_lock")) {
                mSession.setAppLockType("");
                mSession.setHasAppLockEnable(false);
            } else {
                onBackPressedHandled();
            }
        } else if (requestCode == CUSTOM_PIN_LOCK_CODE) {
            mApplication.removedTempData();
            if (mType.equalsIgnoreCase("verify_lock")) {
                mApplication.mFirstTimeSkippedApplock = false;
                if (mCallFrom.equalsIgnoreCase("application") && mSession.getHasLoging()) {
                    String reAuth = mSession.getLastReAuthTime();
                    if (mSession.getHasLoging() && !reAuth.equals("")) {
                        activitySelection();
                    }else{
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        System.exit(0);
                    }
                }else if (mCallFrom.equalsIgnoreCase("splash") && mSession.getHasLoging()) {
                    String reAuth = mSession.getLastReAuthTime();
                    if (mSession.getHasLoging() && !reAuth.equals("")) {
                        activitySelection();
                    }else{
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        System.exit(0);
                    }
                } else {
                    if (mSession.getHasLoging() && mSession.getServerReAuth().length()>0){
                       // reLogin();
                        activitySelection();
                    }else{
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        System.exit(0);
                    }

                }

            } else {
               activitySelection();
            }
        } else {
            mApplication.showCommonDailog(AppLockOptionActivity.this, getString(R.string.Error), getString(R.string.text_no_screen_lock), "message");

        }
    }

    private void activitySelection(){
        if (mSession.getLoginType().equals("broker")) {
            Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
            CrmBuilder.copyStringExtras(
                    mIntent,
                    intent,
                    "coming_from",
                    "data"
            );
            if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
            }

            AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            finish();

        } else if (mSession.getLoginType().equals("admin")) {
            Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
            AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            finish();
        } else {
            Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
            if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
            }
            AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            finish();

        }
    }


}
