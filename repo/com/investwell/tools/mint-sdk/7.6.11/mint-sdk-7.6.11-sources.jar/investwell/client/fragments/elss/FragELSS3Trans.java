package investwell.client.fragments.elss;

import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.piechart.utils.Util;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Utils;


public class FragELSS3Trans extends BaseFragment implements View.OnClickListener {
    FragElssTransAdapter3 mElsstAdapter;
    private LinearLayoutManager mLayoutManager;
    private TextView mTvNothing, tvAmount, tvName, tvScheme, tvFinancialYear;
    RecyclerView mRvDividendReport;

    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private String mFinYear = "";


    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.elss_text),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_elss_trans, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setUpToolBar();
        mMainActivity.setMainVisibility(this, null);

        tvFinancialYear = view.findViewById(R.id.tvFinancialYear);
        tvAmount = view.findViewById(R.id.tvAmount);
        tvName = view.findViewById(R.id.tvName);
        tvScheme = view.findViewById(R.id.tvScheme);
        mTvNothing = view.findViewById(R.id.tvLoading);
        mTvNothing.setVisibility(View.GONE);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llElssTrans).setBackgroundResource(R.mipmap.card_blank);

        mRvDividendReport = view.findViewById(R.id.recycleView);
        mRvDividendReport.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRvDividendReport.setLayoutManager(mLayoutManager);
        mElsstAdapter = new FragElssTransAdapter3(getActivity(), "type_scheme", new ArrayList<JSONObject>(), new FragElssTransAdapter3.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });
        mRvDividendReport.setAdapter(mElsstAdapter);

        setSchemeData();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

    private void setSchemeData() {
        List<JSONObject> list = new ArrayList<>();
        try {
            Bundle bundle = getArguments();
            if (bundle != null && bundle.containsKey("data")) {
                if (bundle.containsKey("finYear")){
                    mFinYear = bundle.getString("finYear");
                    tvFinancialYear.setText(mFinYear);
                }

                JSONObject jsonObject = new JSONObject(bundle.getString("data"));
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                tvName.setText(Utils.setFirstLetterCapital(jsonObject.optString("clientName")));
                tvScheme.setText(jsonObject.optString("schemeName"));
                double purchaseValue;
                if (jsonObject.has("amount")) {
                    purchaseValue = jsonObject.optDouble("amount", 0.0);
                } else {
                    JSONObject summaryObject = jsonObject.optJSONObject("txns").optJSONObject("summary");
                    if (summaryObject != null) {
                        purchaseValue = summaryObject.optDouble("amount", 0.0);
                    } else {
                        purchaseValue = 0.0;
                    }
                }
//                double purchaseValue = jsonObject.optDouble("amount");
                String strPurchaseValue = format.format(purchaseValue);
                tvAmount.setText(strPurchaseValue);



                JSONObject schemeObject = jsonObject.optJSONObject("txns");
                JSONArray jsonArray = schemeObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }
            }
        } catch (Exception e) {

        }finally {
            if (list.size() > 0) {
                mElsstAdapter.updateList(list);
                mTvNothing.setVisibility(View.GONE);
            }else{
                mTvNothing.setVisibility(View.VISIBLE);
                mElsstAdapter.updateList(list);
            }
        }
    }


}
