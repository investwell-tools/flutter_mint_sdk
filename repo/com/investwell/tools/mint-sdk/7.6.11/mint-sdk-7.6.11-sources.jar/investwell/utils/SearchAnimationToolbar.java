package investwell.utils;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.MenuItemCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.iw.mint.sdk.R;

import java.lang.reflect.Field;
import java.util.ArrayList;

public class SearchAnimationToolbar extends FrameLayout implements TextWatcher {

    public interface OnSearchQueryChangedListener {
        void onSearchCollapsed();

        void onSearchQueryChanged(String query);

        void onSearchExpanded();

        void onSearchSubmitted(String query);
    }

    private String toolbarTitle;
    private String toolbarSubtitle;
    private String searchHint;
    private int toolbarTitleColor;
    private int toolbarSubtitleColor;
    private int searchBackgroundColor;


    private Toolbar toolbar;
    private Toolbar searchToolbar;
    private EditText txtSearch;
    private MenuItem searchMenuItem;
    private OnSearchQueryChangedListener onSearchQueryChangedListener;
    private String currentQuery = "";

    public SearchAnimationToolbar(Context context) {
        this(context, null);
    }

    public SearchAnimationToolbar(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SearchAnimationToolbar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflateAndBindViews();
        bindAttributes(attrs);
    }

    private void bindAttributes(AttributeSet attrs) {

        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.SearchAnimationToolbar);
        toolbarTitle = typedArray.getString(R.styleable.SearchAnimationToolbar_title);
        toolbarTitleColor = typedArray.getColor(R.styleable.SearchAnimationToolbar_titleTextColor, ContextCompat.getColor(getContext(), R.color.colorToolbarText));
        toolbarSubtitle = typedArray.getString(R.styleable.SearchAnimationToolbar_subtitle);
        toolbarSubtitleColor = typedArray.getColor(R.styleable.SearchAnimationToolbar_subtitleTextColor, ContextCompat.getColor(getContext(), R.color.colorToolbarText));

        toolbar.setTitle(toolbarTitle);
        setToolbarTitleAsHeading(toolbar);
        toolbar.setTitleTextColor(toolbarTitleColor);
        centerToolbarTitle(toolbar);

        if (!TextUtils.isEmpty(toolbarSubtitle)) {
            toolbar.setSubtitle(toolbarSubtitle);
            toolbar.setSubtitleTextColor(toolbarSubtitleColor);
        }

        searchHint = typedArray.getString(R.styleable.SearchAnimationToolbar_searchHint);

        if (!TextUtils.isEmpty(searchHint)) {
            txtSearch.setTextSize(14);
            txtSearch.setHint(searchHint);
        }

  /*      searchBackgroundColor = typedArray.getColor(R.styleable.SearchAnimationToolbar_searchBackgroundColor, ContextCompat.getColor(getContext(), R.color.white_black));
        searchToolbar.setBackgroundColor(searchBackgroundColor);*/

    }



    static void centerToolbarTitle(@NonNull final Toolbar toolbar) {
        final CharSequence title = toolbar.getTitle();
        final ArrayList<View> outViews = new ArrayList<>(1);
        toolbar.findViewsWithText(outViews, title, View.FIND_VIEWS_WITH_TEXT);
        if (!outViews.isEmpty()) {
            final TextView titleView = (TextView) outViews.get(0);
            titleView.setGravity(Gravity.CENTER);
            final Toolbar.LayoutParams layoutParams = (Toolbar.LayoutParams) titleView.getLayoutParams();
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT;
            toolbar.requestLayout();
            //also you can use titleView for changing font: titleView.setTypeface(Typeface);
        }
    }

    public void setSearchTextColor(int color) {
        txtSearch.setTextColor(color);
    }

    public void setSearchHintColor(int color) {
        txtSearch.setHintTextColor(color);
    }

    @SuppressLint("NewApi")
    private void inflateAndBindViews() {
        View.inflate(getContext(), R.layout.view_search_toolbar, SearchAnimationToolbar.this);

        toolbar = (Toolbar) findViewById(R.id.lib_search_animation_toolbar);
        toolbar.setNavigationContentDescription(getResources().getString(R.string.back_button));
        searchToolbar = (Toolbar) findViewById(R.id.lib_search_animation_search_toolbar);

        searchToolbar.inflateMenu(R.menu.lib_search_toolbar_menu_search);

        searchToolbar.setNavigationContentDescription(getResources().getString(R.string.back_button));
        searchToolbar.setNavigationOnClickListener(v -> collapse());

        searchMenuItem = searchToolbar.getMenu().findItem(R.id.lib_search_toolbar_action_filter_search);
        searchMenuItem.setContentDescription(getContext().getString(R.string.search));

        MenuItemCompat.setOnActionExpandListener(searchMenuItem, new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                // Do something when collapsed
                collapse();
                return true;
            }

            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                return true;
            }
        });

        final SearchView searchView = (SearchView) searchMenuItem.getActionView();
        searchView.setContentDescription(getResources().getString(R.string.search));

        // Enable/Disable Submit button in the keyboard
        searchView.setSubmitButtonEnabled(false);

        // Change search close button image

        ImageView closeButton = (ImageView) searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
        closeButton.setImageResource(R.drawable.ic_close_grey_24dp);
        if (closeButton != null) {
            closeButton.setColorFilter(ContextCompat.getColor(getContext(), R.color.black_white), PorterDuff.Mode.SRC_IN);
        }

        Drawable collapseIcon = AppCompatResources.getDrawable(getContext(), R.drawable.ic_arrow_back_grey_24dp);
        Drawable wrapped = DrawableCompat.wrap(collapseIcon);
        DrawableCompat.setTint(wrapped, ContextCompat.getColor(getContext(), R.color.black_white));
        searchToolbar.setCollapseIcon(wrapped);

        ImageView searchMagIcon = searchView.findViewById(androidx.appcompat.R.id.search_mag_icon);
        if (searchMagIcon != null) {
            searchMagIcon.setColorFilter(ContextCompat.getColor(getContext(), R.color.black_white), PorterDuff.Mode.SRC_IN);
            searchMagIcon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);

//            searchMagIcon.setContentDescription(getResources().getString(R.string.search));
        }

        // set hint and the text colors
        txtSearch = ((EditText) searchView.findViewById(androidx.appcompat.R.id.search_src_text));
        txtSearch.setTextColor(ContextCompat.getColor(getContext(), R.color.value_text_color));
        txtSearch.setHintTextColor(ContextCompat.getColor(getContext(), R.color.hintTextDefaultColor));
        txtSearch.addTextChangedListener(SearchAnimationToolbar.this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            txtSearch.setTextCursorDrawable(R.drawable.cursor_color);
        }



        txtSearch.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                    notifySearchSubmitted(txtSearch.getText().toString());
                    return true;
                }

                return false;
            }
        });

    }

    public static void setToolbarTitleAsHeading(Toolbar toolbar) {
        CharSequence title = toolbar.getTitle();
        if (title == null) return;

        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View child = toolbar.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                if (title.equals(tv.getText())) {
                    ViewCompat.setAccessibilityHeading(tv, true);
                    tv.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
                    break;
                }
            }
        }
    }


    @Override
    protected void onDetachedFromWindow() {
        txtSearch.removeTextChangedListener(SearchAnimationToolbar.this);
        super.onDetachedFromWindow();
    }

    public void setSupportActionBar(AppCompatActivity act) {
        act.setSupportActionBar(toolbar);
    }

    public boolean onSearchIconClick() {
        expand();
        searchMenuItem.expandActionView();
        return true;
    }

    public void circleReveal(final boolean isShow) {

        int width = toolbar.getWidth();
        width -= (getResources().getDimensionPixelSize(androidx.appcompat.R.dimen.abc_action_button_min_width_material) / 2);

        int cx = width;
        int cy = toolbar.getHeight() / 2;

        Animator anim;
        if (isShow)
            anim = ViewAnimationUtils.createCircularReveal(searchToolbar, cx, cy, 0, (float) width);
        else
            anim = ViewAnimationUtils.createCircularReveal(searchToolbar, cx, cy, (float) width, 0);

        anim.setDuration(250L);

        // make the view invisible when the animation is done
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                if (!isShow) {
                    super.onAnimationEnd(animation);
                    searchToolbar.setVisibility(View.INVISIBLE);
                }
            }
        });

        // make the view visible and start the animation
        if (isShow) {
            searchToolbar.setVisibility(View.VISIBLE);
            notifySearchExpanded();
        } else {
            notifySearchCallapsed();
        }

        // start the animation
        anim.start();
    }

    public void setSearchHint(String hint) {
        txtSearch.setHint(hint);
    }
    public void setSearchText(String text)
    {
        txtSearch.setText(text);
        txtSearch.clearFocus();
    }

    public boolean onBackPressed() {
        boolean isInSearchMode = searchToolbar.getVisibility() == View.VISIBLE;
        if (!isInSearchMode) {
            return false;
        }

        collapse();
        searchMenuItem.collapseActionView();
        return true;
    }


    public void setTitle(String title) {
        toolbar.setTitle(title);
        toolbar.invalidate();
    }

    public void setTitleTextColor(int color) {
        toolbar.setTitleTextColor(color);
    }

    public Toolbar getToolbar() {
        return toolbar;
    }

    public Toolbar getSearchToolbar() {
        return searchToolbar;
    }

    public void setOnSearchQueryChangedListener(OnSearchQueryChangedListener onSearchQueryChangedListener) {
        this.onSearchQueryChangedListener = onSearchQueryChangedListener;
    }

    private void notifySearchCallapsed() {
        if (this.onSearchQueryChangedListener != null) {
            this.onSearchQueryChangedListener.onSearchCollapsed();
        }
    }

    private void notifySearchExpanded() {
        if (this.onSearchQueryChangedListener != null) {
            this.onSearchQueryChangedListener.onSearchExpanded();
        }
    }

    private void notifySearchQueryChanged(String q) {
        if (this.onSearchQueryChangedListener != null) {
            this.onSearchQueryChangedListener.onSearchQueryChanged(q);
        }
    }

    private void notifySearchSubmitted(String q) {
        if (this.onSearchQueryChangedListener != null) {
            this.onSearchQueryChangedListener.onSearchSubmitted(q);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {

        if (!currentQuery.equalsIgnoreCase(s.toString())) {
            currentQuery = s.toString();
            notifySearchQueryChanged(currentQuery);
        }
    }

    private void collapse() {
        circleReveal(false);
    }

    private void expand() {
        circleReveal(true);
    }

    /**
     * Expands the toolbar (Without animation) and update the search with a given query
     */
    public void expandAndSearch(String query) {
        searchToolbar.setVisibility(View.VISIBLE);
        searchMenuItem.expandActionView();
        txtSearch.setText(query);
    }
}
