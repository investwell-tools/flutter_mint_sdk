package investwell.client.fragments.elss;

import static android.os.Build.VERSION.SDK_INT;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.InputStreamVolleyRequest;
import investwell.utils.UtilityKotlin;


public class FragELSS2Scheme extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    FragElssAdapter2 mElsstAdapter;
    private LinearLayoutManager mLayoutManager;

    private TextView mTvNothing, tvAmount, tvName, tvFinancialYear;
    RecyclerView mRvDividendReport;

    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private String mclientName = "", mAppId ="";
    private String year = "";
    private String mFinYear = "";


    @Override
    public void onResume() {
        super.onResume();
   /*     if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    private void setUpToolBar(boolean isShowDownload) {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        boolean isShowPDFDownload = false;
        if (isShowDownload){
            String levelNo = "";
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            } else {
                levelNo = mSession.getLevelNo();
            }
            if (levelNo.equals("98")) {
                isShowPDFDownload = true;
            }else {
                isShowPDFDownload = false;
            }
        }

        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.elss_text),
                    true, false, false, isShowPDFDownload, false, false, false);
        }
        fragToolBar.setCallback(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_elss_scheme, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mMainActivity.setMainVisibility(this, null);

        tvAmount = view.findViewById(R.id.tvAmount);
        tvName = view.findViewById(R.id.tvName);
        mTvNothing = view.findViewById(R.id.tvLoading);
        mTvNothing.setVisibility(View.GONE);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llElssScheme).setBackgroundResource(R.mipmap.card_blank);

        mRvDividendReport = view.findViewById(R.id.recycleView);
        tvFinancialYear = view.findViewById(R.id.tvFinancialYear);
        mRvDividendReport.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRvDividendReport.setLayoutManager(mLayoutManager);
        mElsstAdapter = new FragElssAdapter2(getActivity(), "type_scheme", new ArrayList<JSONObject>(), new FragElssAdapter2.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    JSONObject jsonObject = mElsstAdapter.mDataList.get(position);
                    jsonObject.put("clientName", mclientName);
                    Bundle bundle = new Bundle();
                    bundle.putString("data", jsonObject.toString());
                    bundle.putString("finYear", mFinYear);
                    mMainActivity.displayViewOther(75, bundle);
                }catch ( Exception e){

                }
            }
        });
        mRvDividendReport.setAdapter(mElsstAdapter);
        // check feature permission feature1011 if exist then show download
        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
        boolean isShowDownload = false;
        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
            JSONObject mJsoObject = null;
            try {
                mJsoObject = new JSONObject(allowedFeatured);
                JSONArray jsonArray = mJsoObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.optJSONObject(i).has("feature1011")) {
                        isShowDownload = true;
                        break;
                    }
                }
                setUpToolBar(isShowDownload);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }
        setSchemeData();
        //downloadFile2();
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        }
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                downloadFile2();
}
    }

    private void downloadFile2() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }
        String url ="";
        try {

            JSONObject selectedUser = new JSONObject();
            selectedUser.put("uid", mAppId);
            selectedUser.put("levelNo", 100);
            //jsonArrayFilter.put(new JSONObject().put("selectedUser", selectedUser));
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ELSS_REPORT_CLIENT_PDF + "year=" + year
                    + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+selectedUser;
        } catch (Exception e) {
           // System.out.println("----"+e.toString());
        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "ELSSStatement","", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_elss_report_download_successfully), "pdf", mFileSave,uri);
                        else{
                            mMainActivity.showCommonDownload(mMainActivity, getString(R.string.txt_successfully), getString(R.string.txt_elss_report_download_successfully), "pdf", mFileSave,uri);
                        }                    }
                });

    }

    private void setSchemeData() {
        List<JSONObject> list = new ArrayList<>();
        try {
            Bundle bundle = getArguments();
            if (bundle != null && bundle.containsKey("data")) {
                JSONObject jsonObject = new JSONObject(bundle.getString("data"));
                year = bundle.getString("year");
                if (bundle.containsKey("finYear")){
                    mFinYear = bundle.getString("finYear");
                    tvFinancialYear.setText(mFinYear);
                }
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                mclientName = jsonObject.optString("clientName");
                mAppId = jsonObject.optString("uid");
                tvName.setText(mclientName);
                double purchaseValue;
                if (jsonObject.has("amount")) {
                    purchaseValue = jsonObject.optDouble("amount", 0.0);
                } else {
                    JSONObject summaryObject = jsonObject.optJSONObject("schemes").optJSONObject("summary");
                    if (summaryObject != null) {
                        purchaseValue = summaryObject.optDouble("amount", 0.0);
                    } else {
                        purchaseValue = 0.0;
                    }
                }

//                double purchaseValue = jsonObject.optDouble("amount");
                String strPurchaseValue = format.format(purchaseValue);
                tvAmount.setText(strPurchaseValue);


                JSONObject schemeObject = jsonObject.optJSONObject("schemes");
                JSONArray jsonArray = schemeObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }
            }
        } catch (Exception e) {

        } finally {
            if (list.size() > 0) {
                mElsstAdapter.updateList(list);
                mTvNothing.setVisibility(View.GONE);
            } else {
                mTvNothing.setVisibility(View.VISIBLE);
                mElsstAdapter.updateList(list);
            }
        }
    }

    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions){
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }

    private void requestMultiPermissions( String[] permissionList){
        List<String> permissionsToRequest = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)){

        }else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2();
        }
    });

}
