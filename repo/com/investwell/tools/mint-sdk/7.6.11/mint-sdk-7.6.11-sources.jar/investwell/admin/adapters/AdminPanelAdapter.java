package investwell.admin.adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;
import investwell.utils.Utils;

public class AdminPanelAdapter extends RecyclerView.Adapter<AdminPanelAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    Context context;
    private AppSession mSession;

    public AdminPanelAdapter(ArrayList<JSONObject> mDataList, Context context) {
        this.mDataList = mDataList;
        this.context = context;
        mSession = AppSession.getInstance(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.admin_list_layout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        JSONObject jsonObject1 = mDataList.get(position);
        holder.name.setText(jsonObject1.optString("name"));
        holder.email.setText(jsonObject1.optString("email"));
        holder.userName.setText(jsonObject1.optString("username"));
        holder.userType.setText(Utils.setFirstLetterCapital(jsonObject1.optString("userType")));
        holder.createDate.setText(Utils.formatedDate2(jsonObject1.optString("createdAt")));
        holder.domain.setText(jsonObject1.optString("domain"));
        holder.bid.setText(jsonObject1.optString("bid"));
        String lastLogin = jsonObject1.optString("lastLogin");
        holder.lastLogin.setText(lastLogin.equals("null") ? context.getString(R.string.not_available) : Utils.formatedDate2(lastLogin));
        String remaraks = jsonObject1.optString("remarks");
        holder.remarks.setText(remaraks.equals("null") ? context.getString(R.string.not_available) : remaraks);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }



    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, email, domain, userName, bid, createDate, lastLogin, userType, remarks;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            email = itemView.findViewById(R.id.email_id);
            domain = itemView.findViewById(R.id.domain_name);
            userName = itemView.findViewById(R.id.user_name);
            bid = itemView.findViewById(R.id.bid);
            createDate = itemView.findViewById(R.id.create_date);
            lastLogin = itemView.findViewById(R.id.last_login);
            userType = itemView.findViewById(R.id.user_type);
            remarks = itemView.findViewById(R.id.remark);
        }
    }
}
