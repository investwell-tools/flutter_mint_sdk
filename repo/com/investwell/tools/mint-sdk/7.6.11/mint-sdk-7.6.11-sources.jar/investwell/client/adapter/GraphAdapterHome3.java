package investwell.client.adapter;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import investwell.utils.Utils;

public class GraphAdapterHome3 extends RecyclerView.Adapter<GraphAdapterHome3.MyViewHolder> {
    public ArrayList<JSONObject> mDataList;
    Context context;

    public GraphAdapterHome3(Context context, ArrayList<JSONObject> jsonObject) {
        this.context = context;
        this.mDataList = jsonObject;
    }

    @Override
    public GraphAdapterHome3.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.graph_table_adapter_home3, parent, false);
        GraphAdapterHome3.MyViewHolder vh = new GraphAdapterHome3.MyViewHolder(v);

        return vh;
    }

    @Override
    public void onBindViewHolder(final GraphAdapterHome3.MyViewHolder holder, final int position) {
        DecimalFormat twoDForm = new DecimalFormat("#.00");
        final JSONObject jsonObject1 = mDataList.get(position);

        holder.mCategory.setText(Utils.setFirstLetterCapital(jsonObject1.optString("category")));
        holder.mCategory.setSelected(true);



        Double aDouble = Double.parseDouble(jsonObject1.optString("share"));
        double percentage = Double.parseDouble(twoDForm.format(aDouble));
        String value = String.format("%.0f", aDouble);
        holder.mPercentage.setText("" + value + "%");



        ///String hexColor = String.format("#%06X", (0xFFFFFF & jsonObject1.optInt("colorCode")));
        holder.ivColor.setBackgroundResource(R.drawable.roundshape);
        GradientDrawable drawable = (GradientDrawable) holder.ivColor.getBackground();
        drawable.setColor(jsonObject1.optInt("colorCode"));

       // holder.tvColor.setBackgroundColor(jsonObject1.optInt("colorCode"));

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView mCategory, mPercentage;
        ImageView ivColor;

        public MyViewHolder(View view) {
            super(view);
            mCategory = view.findViewById(R.id.category);
            mPercentage = view.findViewById(R.id.percent);
            ivColor = view.findViewById(R.id.ivColor);
        }
    }
}


