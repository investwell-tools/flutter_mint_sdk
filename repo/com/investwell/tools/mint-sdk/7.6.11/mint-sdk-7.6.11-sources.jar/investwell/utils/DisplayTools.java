package investwell.utils;

import android.app.Activity;
import android.content.res.Configuration;

public class DisplayTools {

/*    static public Point getDisplaySize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();

        return size;
    }*/

    static public Orientation getDisplatOrientation(Activity activity) {
        if (activity != null) {
            int orientation = activity.getResources().getConfiguration().orientation;
            if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
                return Orientation.LANDSCAPE;
            }
            if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                return Orientation.PORTRAIT;
            }
            if (orientation == Configuration.ORIENTATION_UNDEFINED) {
                return Orientation.UNDEFINED;
            }
        }
        return Orientation.UNKNOWN;
    }

    public static enum Orientation {
        UNKNOWN(-1),
        UNDEFINED(0),
        PORTRAIT(1),
        LANDSCAPE(2);

        private int tag;

        Orientation(int i) {
            this.tag = i;
        }
    }
}
