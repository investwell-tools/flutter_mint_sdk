package investwell.common.calculator.fragment;

import android.annotation.SuppressLint;
import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.calculator.utils.AudioPlayer;
import investwell.common.calculator.utils.RoundKnobButton;
import investwell.common.calculator.utils.Singleton;
import investwell.common.calculator.utils.Utils;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;


public class FragSipStepup extends BaseFragment implements View.OnClickListener, View.OnTouchListener, RoundKnobButton.RoundKnobButtonListener, ToolbarFragment.ToolbarCallback {
    private final long DELAY = 1000; // milliseconds
    double w_delay = 0;
    double w_tot = 0;

    double amt_inv = 0, amtD = 0, incrementedAmount = 0, MonthlyInvestmentAmount = 0, CummulationAmount = 0, TotalSIPWithStepUp, periodInMonth = 0, years = 0, rorD = 0, YearlyIncrement = 0;

    // double  mDoubleYear = 0, mDoubleRate = 0, mDouleMonthInfletation = 0;
    Singleton m_Inst = Singleton.getInstance();
    private EditText mEtYear, mEtAmount, mEtRate, mEtAnnualIncrement;
    private TextView mTvSipTitle, mTvFutureAmount, mTvTotalInvest, mTvInvestedTimes, mTvWealth, mTvImageTitle, mResulttxt;
    private ImageView mIvImageRight, mIvRefresh, mIvBack;
    private int mAmountCount = 0, mAnnualAmountCount = 0, mYearCount = 0, mReturn = 01;
    private AudioPlayer audioPlayer;
    private ScrollView mScrollView;
    private RoundKnobButton mDailerInvest1, mDailerInvest2, mDailerInvest3, mDailerInvest4;
    private ConstraintLayout mClCalcFooter;
    private Timer timer = new Timer();
    private ClientActivity mActivity;
    private AppApplication mApplication;
    private RelativeLayout mRelToolbar;
    private ToolbarFragment toolbarFragment;
    private AppTextViewTitle tvHeaderTitle;
    private LinearLayout ll_calculator_header;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private TextView mTvAppName, mTvWebsite, mTvEmail, mTvAddress, mTvPhone, mTvSlogan;
    private ImageView mIvAppLogo;

    private TextView mTvAmountError, mTvInvestmentPeriodError, mTvAnnualReturnError, mTvIncrementError;

    @Override
    public void onResume() {
        super.onResume();
/*
        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);
*/

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mActivity.getApplication();
            mSession = AppSession.getInstance(mActivity);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = this.getArguments();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_cal_stepup, container, false);

        if (mBrokerActivity != null) {
            m_Inst.InitGUIFrame(mBrokerActivity);

        } else {
            m_Inst.InitGUIFrame(mActivity);

        }
        audioPlayer = new AudioPlayer();

        mRelToolbar = view.findViewById(R.id.relToolBar);
        mIvAppLogo = view.findViewById(R.id.iv_app_logo);
        mEtAmount = view.findViewById(R.id.edit1);
        mEtYear = view.findViewById(R.id.edit2);
        mEtRate = view.findViewById(R.id.edit3);
        mEtAnnualIncrement = view.findViewById(R.id.edit4);
        view.findViewById(R.id.rl_annual_increment).setVisibility(View.VISIBLE);

        mTvAmountError = view.findViewById(R.id.tvAmountError);
        mTvInvestmentPeriodError = view.findViewById(R.id.tvInvestmentPeriodError);
        mTvAnnualReturnError = view.findViewById(R.id.tvAnnualReturnError);
        mTvIncrementError = view.findViewById(R.id.tvIncrementError);

        mTvWealth = view.findViewById(R.id.tvResult2);
        mScrollView = view.findViewById(R.id.scrollView);
        mTvImageTitle = view.findViewById(R.id.tvImageTitle);
        mClCalcFooter = view.findViewById(R.id.cl_calc_footer);
        mClCalcFooter.setVisibility(View.GONE);
        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        ll_calculator_header = view.findViewById(R.id.ll_calculator_header);
        mTvSlogan = view.findViewById(R.id.tvSlogan);


        mTvSipTitle = view.findViewById(R.id.textView1);
        mTvFutureAmount = view.findViewById(R.id.textView2);
        mTvTotalInvest = view.findViewById(R.id.tvResult);
        mTvInvestedTimes = view.findViewById(R.id.textView6);

        mIvBack = view.findViewById(R.id.ivLeft);
        mTvAddress = view.findViewById(R.id.tvAddress);
        mTvAppName = view.findViewById(R.id.tvApp_name);
        mTvPhone = view.findViewById(R.id.call);
        mTvWebsite = view.findViewById(R.id.web);
        mTvEmail = view.findViewById(R.id.email);
        setupFooter();
       /* TextViewtoolbar_title_left = view.findViewById(R.id.toolbar_title_left);
        toolbar_title_left.setText("SIP Calculator");*/


        mDailerInvest1 = view.findViewById(R.id.dialer1);
        mDailerInvest2 = view.findViewById(R.id.dialer2);
        mDailerInvest3 = view.findViewById(R.id.dialer3);
        mDailerInvest4 = view.findViewById(R.id.dialer4);
        if (mBrokerActivity != null) {
            mDailerInvest1.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        } else {
            mDailerInvest1.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));

        }
        mResulttxt = view.findViewById(R.id.textView3);
        mResulttxt.setText(getString(R.string.to_achieve_this_Goal_you_must_start_Investment_of) + mEtAmount.getText().toString() + getString(R.string.monthly_sip_today));


        mDailerInvest1.setOnTouchListener(this);
        mDailerInvest2.setOnTouchListener(this);
        mDailerInvest3.setOnTouchListener(this);
        mDailerInvest4.setOnTouchListener(this);

        mDailerInvest1.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                System.out.println("" + percentage);
                mEtAmount.post(new Runnable() {
                    public void run() {
                        long currentValue = Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""));
                        long updateValue = 0;
                        if (mAmountCount != percentage) {
                            if (percentage > mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue + 500);
                                } else {
                                    updateValue = (currentValue + 1000);
                                }
                            } else if (percentage < mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue - 500);
                                } else {
                                    updateValue = (currentValue - 1000);
                                }
                            }

                            mAmountCount = percentage;
                            if (updateValue < 500) {
                                mEtAmount.setText("" + 500);
                            } else {
                                mEtAmount.setText("" + updateValue);
                            }
                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });

        mDailerInvest2.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtYear.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtYear.getText().toString());
                        int updateValue = 0;
                        if (mYearCount != percentage) {
                            if (percentage > mYearCount) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mYearCount) {
                                updateValue = (currentValue - 1);
                            }

                            mYearCount = percentage;
                            if (updateValue < 1) mEtYear.setText("" + 1);
                            else if (updateValue > 99) mEtYear.setText("" + 99);
                            else mEtYear.setText("" + updateValue);
                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }

                    }
                });
            }
        });


        mDailerInvest3.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtRate.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtRate.getText().toString());
                        double updateValue = 0;
                        if (mReturn != percentage) {
                            if (percentage > mReturn) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mReturn) {
                                updateValue = (currentValue - 1);
                            }

                            mReturn = percentage;
                            if (updateValue < 1) mEtRate.setText("" + 1.00);
                            else if (updateValue > 100.00) mEtRate.setText("" + 100.00);
                            else mEtRate.setText("" + updateValue);
                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }
                    }
                });
            }
        });

        mDailerInvest4.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtAnnualIncrement.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtAnnualIncrement.getText().toString());
                        double updateValue = 0;
                        if (mReturn != percentage) {
                            if (percentage > mReturn) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mReturn) {
                                updateValue = (currentValue - 1);
                            }

                            mReturn = percentage;
                            if (updateValue < 1) mEtAnnualIncrement.setText("" + 1.00);
                            else if (updateValue > 50.00) mEtAnnualIncrement.setText("" + 50.00);
                            else mEtAnnualIncrement.setText("" + updateValue);
                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }
                    }
                });
            }
        });


        mEtAmount.addTextChangedListener(new GenericTextWatcher(mEtAmount));
        mEtRate.addTextChangedListener(new GenericTextWatcher(mEtRate));
        mEtYear.addTextChangedListener(new GenericTextWatcher(mEtYear));
        mEtAnnualIncrement.addTextChangedListener(new GenericTextWatcher(mEtAnnualIncrement));
        // calculateAmount();
        setUpToolBar();
        refreshView();
        return view;
    }

    private void setUpToolBar() {
        toolbarFragment = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (toolbarFragment != null) {
            toolbarFragment.setUpToolBar(requireActivity().getResources().getString(R.string.SIPStep_upCalculator), true, true, false, false, true, false, false);
            toolbarFragment.setCallback(this);
        }

        tvHeaderTitle.setText(requireActivity().getResources().getString(R.string.SIPStep_upCalculator));
    }

    @Override
    public void onStateChange(boolean newstate) {

    }

    @Override
    public void onRotate(int percentage) {

    }

    @Override
    public void onClick(View view) {
      /*  if (view.getId() == R.id.ivRight) {
            saveFrameLayout();
        }*//* else if (view.getId() == R.id.ivRight2) {
            refreshView();
        }*/ /*else*/


    }

    private void setupFooter() {
        setTintColorIfDark(requireActivity(), mIvAppLogo);
        mIvAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (requireActivity().getResources().getString(R.string.subdomain).equals("mint")) {
            if (mSession.getHasLoging()) {
                if (!TextUtils.isEmpty(mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")) {
                    Picasso.get().load(mSession.getAppLogo()).error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                    mIvAppLogo.setVisibility(View.VISIBLE);
                } else {
                    mIvAppLogo.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")) {
                    mTvAddress.setText(mSession.getAddress());
                    mTvAddress.setVisibility(View.VISIBLE);
                } else {
                    mTvAddress.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")) {
                    mTvWebsite.setText(mSession.getWebsite());
                    mTvWebsite.setVisibility(View.VISIBLE);
                } else {
                    mTvWebsite.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")) {
                    mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                    mTvPhone.setVisibility(View.VISIBLE);
                } else {
                    mTvPhone.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")) {
                    mTvEmail.setText(mSession.getUserEmail());
                    mTvEmail.setVisibility(View.VISIBLE);
                } else {
                    mTvEmail.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")) {
                    mTvAppName.setText(mSession.getCompanyName());
                    mTvAppName.setVisibility(View.VISIBLE);
                } else {
                    mTvAppName.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                    mTvSlogan.setText(mSession.getSloganOnLogo());
                    mTvSlogan.setVisibility(View.VISIBLE);
                }else{
                    mTvSlogan.setVisibility(View.GONE);
                }
            } else {
                if (!TextUtils.isEmpty(mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")) {
                    Picasso.get().load(mSession.getAppLogo()).error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                }
                mTvAddress.setText(requireActivity().getResources().getString(R.string.locatetext));
                mTvWebsite.setText(requireActivity().getResources().getString(R.string.website));
                mTvPhone.setText(requireActivity().getResources().getString(R.string.image_phone));
                mTvEmail.setText(requireActivity().getResources().getString(R.string.support_email_address));
                mTvAppName.setText(getString(R.string.app_name));
                mTvSlogan.setText(mSession.getSloganOnLogo());

            }
        } else {

            mIvAppLogo.setVisibility(View.VISIBLE);
            int squareLogo =   UtilityKotlin.checkExistResources("app_logo_square","mipmap",requireContext());
            int circleLogo =   UtilityKotlin.checkExistResources("app_logo_round","mipmap",requireContext());
            if (squareLogo !=0) {
                mIvAppLogo.setImageResource(squareLogo);
            }else if (circleLogo !=0) {
                mIvAppLogo.setImageResource(circleLogo);
            }else{
                mIvAppLogo.setImageResource(R.mipmap.app_logo);
            }

            if (!TextUtils.isEmpty(mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")) {
                mTvAddress.setText(mSession.getAddress());
                mTvAddress.setVisibility(View.VISIBLE);
            } else {
                mTvAddress.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")) {
                mTvWebsite.setText(mSession.getWebsite());
                mTvWebsite.setVisibility(View.VISIBLE);
            } else {
                mTvWebsite.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")) {
                mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                mTvPhone.setVisibility(View.VISIBLE);
            } else {
                mTvPhone.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")) {
                mTvEmail.setText(mSession.getUserEmail());
                mTvEmail.setVisibility(View.VISIBLE);
            } else {
                mTvEmail.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")) {
                mTvAppName.setText(mSession.getCompanyName());
                mTvAppName.setVisibility(View.VISIBLE);
            } else {
                mTvAppName.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                mTvSlogan.setText(mSession.getSloganOnLogo());
                mTvSlogan.setVisibility(View.VISIBLE);
            }else{
                mTvSlogan.setVisibility(View.GONE);
            }


        }
    }

    private void refreshView() {
        mDailerInvest1.setRotorPercentage(0);
        mDailerInvest2.setRotorPercentage(0);
        mDailerInvest3.setRotorPercentage(0);
        mDailerInvest4.setRotorPercentage(0);
        mEtAmount.setText("1000");
        mEtYear.setText("15");
        mEtRate.setText("12.00");
        mEtAnnualIncrement.setText("10.00");
        calculateAmount();
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        hideKeyPad();
        String currentValue = "";
        int i = view.getId();
        if (i == R.id.dialer1) {
            currentValue = mEtAmount.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 500) mEtAmount.setText("" + 500);
            } else {
                mEtAmount.setText("" + 500);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer2) {
            currentValue = mEtYear.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 1) mEtYear.setText("" + 1);
                else if (value > 99) mEtYear.setText("" + 99);

            } else {
                mEtYear.setText("" + 1);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer3) {
            currentValue = mEtRate.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 2) mEtRate.setText("" + 1.00);
                else if (value > 100) mEtRate.setText("" + 100.00);
            } else {
                mEtRate.setText("" + 1);
            }
            desableScrollView(motionEvent);

        }else if (i == R.id.dialer4) {
            currentValue = mEtAnnualIncrement.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 2) mEtAnnualIncrement.setText("" + 1.00);
                else if (value > 50) mEtAnnualIncrement.setText("" + 50.00);
            } else {
                mEtAnnualIncrement.setText("" + 1);
            }
            desableScrollView(motionEvent);

        }
        return false;
    }

    private void desableScrollView(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            mScrollView.requestDisallowInterceptTouchEvent(true);

        else if (motionEvent.getAction() == MotionEvent.ACTION_UP)
            mScrollView.requestDisallowInterceptTouchEvent(false);

    }

    public void hideKeyPad() {
        if (mBrokerActivity != null) {
            InputMethodManager inputManager = (InputMethodManager) mBrokerActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mBrokerActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } else {
            InputMethodManager inputManager = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    private void delayCall() {
        timer.cancel();
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (mBrokerActivity != null) {
                    mBrokerActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            calculateAmount();
                        }
                    });

                } else {
                    mActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            calculateAmount();
                        }
                    });
                }
            }
        }, DELAY);
    }

    @SuppressLint("SetTextI18n")
    private void calculateAmount() {

        if(!isAdded())
            return ;

        mTvAmountError.setVisibility(View.GONE);
        mTvInvestmentPeriodError.setVisibility(View.GONE);
        mTvAnnualReturnError.setVisibility(View.GONE);
        mTvIncrementError.setVisibility(View.GONE);

        if (mBrokerActivity != null) {
            if (mEtAmount.getText().toString().replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
//                mBrokerActivity.showCommonDialog(mBrokerActivity, "Not Valid", requireActivity().getResources().getString(R.string.new_purchase_error_empty_amnt));
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.announceForAccessibility(getResources().getString(R.string.new_purchase_error_empty_amnt));
                mTvAmountError.setText(getResources().getString(R.string.new_purchase_error_empty_amnt));
            } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 500) {
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.announceForAccessibility(getResources().getString(R.string.sip_setup_error_amnt));
                mTvAmountError.setText(getResources().getString(R.string.sip_setup_error_amnt));
            } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.sip_setup_invest_duration));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.sip_setup_invest_duration));
            } else if (Integer.parseInt(mEtYear.getText().toString()) > 99) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.sip_setup_max_duration));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.sip_setup_max_duration));
            } else if (mEtRate.getText().toString().equals("") ||mEtRate.getText().toString().equals(".") || mEtRate.getText().toString().equals("0")) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.sip_setup_min_duration));
                mTvAnnualReturnError.setText(getResources().getString(R.string.sip_setup_min_duration));
            } else if (Double.parseDouble(mEtRate.getText().toString()) > 100) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.sip_setup_error_min_ror));
                mTvAnnualReturnError.setText(getResources().getString(R.string.sip_setup_error_min_ror));
            } else {
                // -------- Parse Inputs --------
                double amount = mParseDouble(mEtAmount);
                int years = mParseInt(mEtYear);
                double rate = mParseDouble(mEtRate);
                double yearlyIncrement = mParseDouble(mEtAnnualIncrement);
                mBrokerActivity.convertIntoCurrencyFormat(String.valueOf(amount), mEtAmount);

                /**
                  @see
                 * SIP Step Calculator
                 * Note: Pass here P as percentage wise calculation and A as absolute amount wise calculation
                 */
                try {
                    Extensions.SipResult sipResult = Extensions.calculateStepUpSipYearlyCompounding(
                            Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", "")),
                            Integer.parseInt(mEtYear.getText().toString()),
                            Double.parseDouble(mEtRate.getText().toString()),
                            Double.parseDouble(mEtAnnualIncrement.getText().toString()),
                            0.0,
                            "P"
                    );

                    double totalValue = sipResult.getFutureValue();
                    double investedAmount = sipResult.getTotalInvested();
                    double profit = sipResult.getExpectedProfit();
                    double times = totalValue / investedAmount;
                    double monthlyInvestment = sipResult.getMonthlyInvestment();

                    // -------- Formatting --------
                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    mTvSipTitle.setText(
                            getString(R.string.txt_monthly_sip_of) + mFormatWithoutDecimal(format, monthlyInvestment) +
                                    getString(R.string.txt_incremented_annually_by) + yearlyIncrement + getString(R.string.txt_for_a_period_of) + years +
                                    getString(R.string.txt_years_with_returns_of) + rate + getString(R.string.txt_yearly_will_grow_to)
                    );

                    mTvFutureAmount.setText(mFormatWithoutDecimal(format, totalValue));
                    mTvTotalInvest.setText(mFormatWithoutDecimal(format, investedAmount));
                    mTvWealth.setText(mFormatWithoutDecimal(format, profit));

                    // -------- Times Calculation --------
                    mTvInvestedTimes.setText(getString(R.string.sip_calculator_txt_times,Double.isNaN(times) ? "0" : String.format("%.2f", times)));


                    String announcement =
                            mTvSipTitle.getText().toString() +". " + mTvFutureAmount.getText().toString() + ". "
                                    + getString(R.string.sip_calculator_total_amount_invested_txt) + ". " + mTvTotalInvest.getText().toString() +". "
                                    + getString(R.string.sip_calculator_txt_wealth_gained) + ". " + mTvWealth.getText().toString() +". "
                                    + getString(R.string.sip_calculator_your_multiplied_txt) + ". " + mTvInvestedTimes.getText().toString() +". ";

                    mTvFutureAmount.post(() ->
                            mTvFutureAmount.announceForAccessibility(announcement)
                    );

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        } else {
            if (mEtAmount.getText().toString().replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
//                mActivity.showCommonDialog(mActivity, "Not Valid", requireActivity().getResources().getString(R.string.new_purchase_error_empty_amnt));
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.announceForAccessibility(getResources().getString(R.string.new_purchase_error_empty_amnt));
                mTvAmountError.setText(getResources().getString(R.string.new_purchase_error_empty_amnt));
            } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 500) {
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.announceForAccessibility(getResources().getString(R.string.sip_setup_invest_duration));
                mTvAmountError.setText(getResources().getString(R.string.sip_setup_error_amnt));
            } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.sip_setup_invest_duration));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.sip_setup_invest_duration));
            } else if (Integer.parseInt(mEtYear.getText().toString()) > 99) {
                mEtYear.setText("99");
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.sip_setup_max_duration));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.sip_setup_max_duration));
            } else if (mEtRate.getText().toString().equals("") ||mEtRate.getText().toString().equals(".") || mEtRate.getText().toString().equals("0")) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.sip_setup_min_duration));
                mTvAnnualReturnError.setText(getResources().getString(R.string.sip_setup_min_duration));
            } else if (Double.parseDouble(mEtRate.getText().toString()) > 100) {
                mEtRate.setText("100.00");
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.sip_setup_error_min_ror));
                mTvAnnualReturnError.setText(getResources().getString(R.string.sip_setup_error_min_ror));
            } else {
                // -------- Parse Inputs --------
                double amount = mParseDouble(mEtAmount);
                int years = mParseInt(mEtYear);
                double rate = mParseDouble(mEtRate);
                double yearlyIncrement = mParseDouble(mEtAnnualIncrement);
                mActivity.convertIntoCurrencyFormat(String.valueOf(amount), mEtAmount);

                /**
                 @see
                  * SIP Step Calculator
                  * Note: Pass here P as percentage wise calculation and A as absolute amount wise calculation
                 */
                try {
                    Extensions.SipResult sipResult = Extensions.calculateStepUpSipYearlyCompounding(
                            Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", "")),
                            Integer.parseInt(mEtYear.getText().toString()),
                            Double.parseDouble(mEtRate.getText().toString()),
                            Double.parseDouble(mEtAnnualIncrement.getText().toString()),
                            0.0,
                            "P"
                    );

                    double totalValue = sipResult.getFutureValue();
                    double investedAmount = sipResult.getTotalInvested();
                    double profit = sipResult.getExpectedProfit();
                    double times = totalValue / investedAmount;
                    double monthlyInvestment = sipResult.getMonthlyInvestment();
                    // -------- Formatting --------
                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    mTvSipTitle.setText(
                            getString(R.string.txt_monthly_sip_of) + mFormatWithoutDecimal(format, monthlyInvestment) +
                                    getString(R.string.txt_incremented_annually_by) + yearlyIncrement + getString(R.string.txt_for_a_period_of) + years +
                                    getString(R.string.txt_years_with_returns_of) + rate + getString(R.string.txt_yearly_will_grow_to)
                    );

                    mTvFutureAmount.setText(mFormatWithoutDecimal(format, totalValue));
                    mTvTotalInvest.setText(mFormatWithoutDecimal(format, investedAmount));
                    mTvWealth.setText(mFormatWithoutDecimal(format, profit));

                    // -------- Times Calculation --------
                    mTvInvestedTimes.setText(
                            Double.isNaN(times) ? "0 times" : String.format("%.2f times", times)
                    );

                    String announcement =
                            mTvSipTitle.getText().toString() +". " + mTvFutureAmount.getText().toString() + ". "
                                    + getString(R.string.sip_calculator_total_amount_invested_txt) + ". " + mTvTotalInvest.getText().toString() +". "
                                    + getString(R.string.sip_calculator_txt_wealth_gained) + ". " + mTvWealth.getText().toString() +". "
                                    + getString(R.string.sip_calculator_your_multiplied_txt) + ". " + mTvInvestedTimes.getText().toString() +". ";

                    mTvFutureAmount.post(() ->
                            mTvFutureAmount.announceForAccessibility(announcement)
                    );


                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }
    }

    private double mParseDouble(EditText et) {
        String value = et.getText().toString().replace(",", "");
        return value.isEmpty() ? 0 : Double.parseDouble(value);
    }

    private int mParseInt(EditText et) {
        String value = et.getText().toString();
        return value.isEmpty() ? 0 : Integer.parseInt(value);
    }

    private String mFormatWithoutDecimal(NumberFormat format, double value) {
        return format.format(Math.round(value)).split("\\.")[0];
    }



    public void saveFrameLayout() {
        mClCalcFooter.setVisibility(View.VISIBLE);
        ll_calculator_header.setVisibility(View.VISIBLE);
        loadUpdatedView();
    }

    private void loadUpdatedView() {
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          createImage();
                                      }
                                  },

                100);
    }

    private void createImage() {
        if (mBrokerActivity != null) {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mBrokerActivity);

                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        } else {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mActivity);

                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        }
    }

    private Bitmap getBitmapFromView(View view, int height, int width) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null) bgDrawable.draw(canvas);
        else canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return bitmap;
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                saveFrameLayout();
}
else if (view.getId() == R.id.iv_refresh) {
                refreshView();
}
    }

    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {
            if (mBrokerActivity != null) {
                if (mBrokerActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtAnnualIncrement) {
                    delayCall();
                }
            } else {
                if (mActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtAnnualIncrement) {
                    delayCall();
                }
            }
            mResulttxt.setText(getString(R.string.to_achieve_this_Goal_you_must_start_Investment_of) + mEtAmount.getText().toString() + getString(R.string.monthly_sip_today));

        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

    }
}