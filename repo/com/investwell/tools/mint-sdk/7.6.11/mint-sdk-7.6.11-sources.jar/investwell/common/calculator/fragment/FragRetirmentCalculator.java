package investwell.common.calculator.fragment;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.calculator.utils.AudioPlayer;
import investwell.common.calculator.utils.RoundKnobButton;
import investwell.common.calculator.utils.Singleton;
import investwell.common.calculator.utils.Utils;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;


public class FragRetirmentCalculator extends BaseFragment implements View.OnClickListener,
        View.OnTouchListener, RoundKnobButton.RoundKnobButtonListener, ToolbarFragment.ToolbarCallback {
    boolean dialogShown;
    private final long DELAY = 1000; // milliseconds
    Singleton m_Inst = Singleton.getInstance();
    double dblCurrentAge = 0, dblRetirementAge = 0, dblMonthlyExpenses = 0, inflationRate = 0,
            dblMonthlySavings = 0, dblPreRetirement = 0, postRetirmentRate = 0, dlbLifeExpetancy = 0, dlbExistingCorpus = 0;
    double ret_year = 0, dblAmtReq = 0, dblExistingGrowth = 0, lumsum = 0;
    double amt_acc = 0, amt_final = 0, short_fall = 0, totalSavings = 0, LumpSumInvestment = 0;
    double extra_amt = 0;
    String[] resultAmount;
    private EditText mEtPresentAge, mEtRetiermentAge, mEtMonthlyExpense, mEtInflations, mEtCurrentSaving, mEtExitingCurpus, mEtPreRetirement, mEtPostRetirement, mEtLifeExpectation;
    TextView mTvCorpusAge, mTvText1, mTvText2, mTvResult4, mTvImageTitle, mTvSipAmount, mTvResult2;
    private ImageView mIvImageRight, mIvRefresh, mIvBack;
    private int mCount1 = 0, mCount2 = 0, mCount3 = 0, mCount4 = 0, mCount5 = 0, mCount6 = 0, mCount7 = 0, mCount8 = 0, mCount9 = 0;
    private AudioPlayer audioPlayer;
    private ScrollView mScrollView;
    private RoundKnobButton mDailerInvest1, mDailerInvest2, mDailerInvest3, mDailerInvest4, mDailerInvest5, mDailerInvest6, mDailerInvest7, mDailerInvest8, mDailerInvest9;
    private ConstraintLayout mClCalcFooter;
    private Timer timer = new Timer();
    private ClientActivity mActivity;
    private AppApplication mApplication;
    private RelativeLayout mRelToolbar;
    private String mResultLumpsum, mResultSIP, mResultShortfall;
    private ProgressBar mProgressBar;
    private Bundle bundle;
    private ToolbarFragment fragToolBar;
    private AppTextViewTitle tvHeaderTitle;
    private LinearLayout ll_calculator_header, llSipLum;
    private TextView tvAmount, tv_amount2, tvHeaderDesc, tvLine5, tvLine6, tvSipLumSumMessage;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private TextView mTvAppName, mTvWebsite, mTvEmail, mTvAddress, mTvPhone, mTvSlogan;
    private ImageView mIvAppLogo;

    private TextView mTvCurrentAgeError, mTvRetirementAgeError, mTvMonthlyExpenseError, mTvPreRetirementReturnError, mTvPostRetirementReturnError, mTvLifeExpectancyError;

    @Override
    public void onResume() {
        super.onResume();
   /*     if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mActivity.setMainVisibility(this, null);
            mSession = AppSession.getInstance(mActivity);
            mApplication = (AppApplication) mActivity.getApplication();

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_cal_retirement, container, false);
        bundle = getArguments();
        if (mBrokerActivity != null) {
            m_Inst.InitGUIFrame(mBrokerActivity);

        } else {
            m_Inst.InitGUIFrame(mActivity);

        }
        audioPlayer = new AudioPlayer();


        mRelToolbar = view.findViewById(R.id.relToolBar);
        tvLine5 = view.findViewById(R.id.tvLine5);
        tvLine6 = view.findViewById(R.id.tvLine6);
        tvSipLumSumMessage = view.findViewById(R.id.tvSipLumSumMessage);
        llSipLum = view.findViewById(R.id.llSipLum);

        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        ll_calculator_header = view.findViewById(R.id.ll_calculator_header);
        mTvSlogan = view.findViewById(R.id.tvSlogan);

        setUpToolBar();
        mEtPresentAge = view.findViewById(R.id.edit1);
        mEtRetiermentAge = view.findViewById(R.id.edit2);
        mEtMonthlyExpense = view.findViewById(R.id.edit3);
        mEtInflations = view.findViewById(R.id.edit4);
        mEtCurrentSaving = view.findViewById(R.id.edit5);
        mEtExitingCurpus = view.findViewById(R.id.edit6);
        mEtPreRetirement = view.findViewById(R.id.edit7);
        mEtPostRetirement = view.findViewById(R.id.edit8);
        mEtLifeExpectation = view.findViewById(R.id.edit9);
        mTvImageTitle = view.findViewById(R.id.tvImageTitle);
        mClCalcFooter = view.findViewById(R.id.cl_calc_footer);
        mClCalcFooter.setVisibility(View.GONE);
        mProgressBar = view.findViewById(R.id.progress_bar1);
        mIvAppLogo = view.findViewById(R.id.iv_app_logo);
        mScrollView = view.findViewById(R.id.scrollView);
        mEtPresentAge.requestFocus();


        mTvCurrentAgeError = view.findViewById(R.id.tvCurrentAgeError);
        mTvRetirementAgeError = view.findViewById(R.id.tvRetirementAgeError);
        mTvMonthlyExpenseError = view.findViewById(R.id.tvMonthlyExpenseError);
        mTvPreRetirementReturnError = view.findViewById(R.id.tvPreRetirementReturnError);
        mTvPostRetirementReturnError = view.findViewById(R.id.tvPostRetirementReturnError);
        mTvLifeExpectancyError = view.findViewById(R.id.tvLifeExpectancyError);

        mTvText2 = view.findViewById(R.id.textView2);
        mTvText1 = view.findViewById(R.id.textView1);
        tvAmount = view.findViewById(R.id.tv_amount);
        tv_amount2 = view.findViewById(R.id.tv_amount2);
        tvHeaderDesc = view.findViewById(R.id.tv_header_desc);
        mTvResult4 = view.findViewById(R.id.shortfallAmount);
        mTvAddress = view.findViewById(R.id.tvAddress);
        mTvAppName = view.findViewById(R.id.tvApp_name);
        mTvPhone = view.findViewById(R.id.call);
        mTvWebsite = view.findViewById(R.id.web);
        mTvEmail = view.findViewById(R.id.email);
        setupFooter();

        mIvBack = view.findViewById(R.id.ivLeft);
/*
        TextViewtoolbar_title_left = view.findViewById(R.id.toolbar_title_left);
        toolbar_title_left.setText("Retirement Calculator");*/

        mTvSipAmount = view.findViewById(R.id.tvResult);
        mTvResult2 = view.findViewById(R.id.tvResult2);


        mDailerInvest1 = view.findViewById(R.id.dialer1);
        mDailerInvest2 = view.findViewById(R.id.dialer2);
        mDailerInvest3 = view.findViewById(R.id.dialer3);
        mDailerInvest4 = view.findViewById(R.id.dialer4);
        mDailerInvest5 = view.findViewById(R.id.dialer5);
        mDailerInvest6 = view.findViewById(R.id.dialer6);
        mDailerInvest7 = view.findViewById(R.id.dialer7);
        mDailerInvest8 = view.findViewById(R.id.dialer8);
        mDailerInvest9 = view.findViewById(R.id.dialer9);
        if (mBrokerActivity != null) {
            mDailerInvest1.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest5.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest6.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest7.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest8.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest9.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        } else {
            mDailerInvest1.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest5.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest6.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest7.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest8.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest9.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        }

        mDailerInvest1.setOnTouchListener(this);
        mDailerInvest2.setOnTouchListener(this);
        mDailerInvest3.setOnTouchListener(this);
        mDailerInvest4.setOnTouchListener(this);
        mDailerInvest5.setOnTouchListener(this);
        mDailerInvest6.setOnTouchListener(this);
        mDailerInvest7.setOnTouchListener(this);
        mDailerInvest8.setOnTouchListener(this);
        mDailerInvest9.setOnTouchListener(this);
        view.findViewById(R.id.sip_btn).setOnClickListener(this);


        if (bundle != null && bundle.containsKey("viewLayout"))
            view.findViewById(R.id.button_layout).setVisibility(View.VISIBLE);

        mDailerInvest1.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtPresentAge.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtPresentAge.getText().toString());
                        int retirementAge = Integer.parseInt(mEtRetiermentAge.getText().toString());
                        int updateValue = 0;


                        if (mCount1 != percentage) {
                            if (percentage > mCount1) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount1) {
                                updateValue = (currentValue - 1);
                            }

                            mCount1 = percentage;
                            if (currentValue < retirementAge || updateValue < retirementAge) {
                                if (updateValue < 20) {
                                    mEtPresentAge.setText("" + 20);
                                } else if (updateValue > 80)
                                    mEtPresentAge.setText("" + 80);
                                else {
                                    mEtPresentAge.setText("" + updateValue);
                                }


                                if (mBrokerActivity != null) {
                                    audioPlayer.play(mBrokerActivity);
                                } else {
                                    audioPlayer.play(mActivity);
                                }
                                calculateAmount();

                            } else {
                               /* if (mBrokerActivity != null) {
                                    mBrokerActivity.showCommonDialog(mBrokerActivity, "Error", "Current Age always less than Retirement age");

                                } else {
                                    if(dialogShown){
                                        return;
                                    }else{
                                        dialogShown=true;
                                        mActivity.showCommonDialog(mActivity, "Error", "Current Age always less than Retirement age");
                                    }


                                }*/
                            }
                        }


                    }
                });
            }
        });
        mDailerInvest2.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtRetiermentAge.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtRetiermentAge.getText().toString());
                        int presentAge = Integer.parseInt(mEtPresentAge.getText().toString());
                        int updateValue = 0;

                        if (mCount2 != percentage) {
                            if (percentage > mCount2) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount2) {
                                updateValue = (currentValue - 1);
                            }

                            mCount2 = percentage;
                            if (currentValue > presentAge || updateValue > presentAge) {

                                if (updateValue < 25)
                                    mEtRetiermentAge.setText("" + 25);
                                else if (updateValue > 100)
                                    mEtRetiermentAge.setText("" + 100);
                                else
                                    mEtRetiermentAge.setText("" + updateValue);


                                if (mBrokerActivity != null) {
                                    audioPlayer.play(mBrokerActivity);
                                } else {
                                    audioPlayer.play(mActivity);
                                }
                                calculateAmount();

                            } else {
                               /* if (mBrokerActivity != null)
                                    mBrokerActivity.showCommonDialog(mBrokerActivity, "Error", "Retirement age always greater than Current Age");
                                else
                                    mActivity.showCommonDialog(mActivity, "Error", "Retirement age always greater than Current Age");
*/
                            }
                        }

                    }
                });
            }
        });
        mDailerInvest3.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtMonthlyExpense.post(new Runnable() {
                    public void run() {
                        long currentValue = getLongValue(mEtMonthlyExpense);
                        long updateValue = 0;
                        if (mCount3 != percentage) {
                            if (percentage > mCount3) {
                                updateValue = (currentValue + 1000);
                            } else if (percentage < mCount3) {
                                updateValue = (currentValue - 1000);
                            }

                            mCount3 = percentage;
                            if (updateValue < 1000)
                                mEtMonthlyExpense.setText("" + 1000);
                            else
                                mEtMonthlyExpense.setText("" + updateValue);

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }

                    }
                });
            }
        });
        mDailerInvest4.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtInflations.post(new Runnable() {
                    public void run() {
                        double currentValue = getDoubleValue(mEtInflations);
                        double updateValue = 0;
                        if (mCount4 != percentage) {
                            if (percentage > mCount4) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount4) {
                                updateValue = (currentValue - 1);
                            }

                            mCount4 = percentage;

                            if (updateValue < 1) {
                                mEtInflations.setText("" + 1.00);
                            } else if (updateValue > 30)
                                mEtInflations.setText("" + 30.00);
                            else {
                                mEtInflations.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });
        mDailerInvest5.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtCurrentSaving.post(new Runnable() {
                    public void run() {
                        long currentValue = getLongValue(mEtCurrentSaving);
                        long updateValue = 0;
                        if (mCount5 != percentage) {
                            if (percentage > mCount5) {
                                updateValue = (currentValue + 1000);
                            } else if (percentage < mCount5) {
                                updateValue = (currentValue - 1000);
                            }

                            mCount5 = percentage;
                            if (updateValue < 1000) {
                                mEtCurrentSaving.setText("" + 1000);
                            } else {
                                mEtCurrentSaving.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });
        mDailerInvest6.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtExitingCurpus.post(new Runnable() {
                    public void run() {
                        long currentValue = getLongValue(mEtExitingCurpus);
                        long updateValue = 0;
                        if (mCount6 != percentage) {
                            if (percentage > mCount6) {
                                updateValue = (currentValue + 1000);
                            } else if (percentage < mCount6) {
                                updateValue = (currentValue - 1000);
                            }

                            mCount6 = percentage;
                            if (updateValue < 1) {
                                mEtExitingCurpus.setText("" + 0);
                            } else {
                                mEtExitingCurpus.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });
        mDailerInvest7.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtInflations.post(new Runnable() {
                    public void run() {
                        double currentValue = getDoubleValue(mEtPreRetirement);
                        double updateValue = 0;
                        if (mCount7 != percentage) {
                            if (percentage > mCount7) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount7) {
                                updateValue = (currentValue - 1);
                            }

                            mCount7 = percentage;
                            if (updateValue < 1) {
                                mEtPreRetirement.setText("" + 1.00);
                            } else if (updateValue > 30)
                                mEtPreRetirement.setText("" + 30.00);
                            else {
                                mEtPreRetirement.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });
        mDailerInvest8.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtPreRetirement.post(new Runnable() {
                    public void run() {
                        Double currentValue = getDoubleValue(mEtPostRetirement);
                        double updateValue = 0;
                        if (mCount8 != percentage) {
                            if (percentage > mCount8) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount8) {
                                updateValue = (currentValue - 1);
                            }

                            mCount8 = percentage;
                            if (updateValue < 1) {
                                mEtPostRetirement.setText("" + 1.00);
                            } else if (updateValue > 30)
                                mEtPostRetirement.setText("" + 30.00);
                            else {
                                mEtPostRetirement.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });
        mDailerInvest9.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtLifeExpectation.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtLifeExpectation.getText().toString());
                        int updateValue = 0;
                        if (mCount9 != percentage) {
                            if (percentage > mCount9) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount9) {
                                updateValue = (currentValue - 1);
                            }

                            mCount9 = percentage;
                            if (updateValue < 25) {
                                mEtLifeExpectation.setText("" + 25);
                            } else if (updateValue > 100)
                                mEtLifeExpectation.setText("" + 100);
                            else {
                                mEtLifeExpectation.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });
        mEtRetiermentAge.addTextChangedListener(new GenericTextWatcher(mEtRetiermentAge));
        mEtMonthlyExpense.addTextChangedListener(new GenericTextWatcher(mEtMonthlyExpense));
        mEtPresentAge.addTextChangedListener(new GenericTextWatcher(mEtPresentAge));
        mEtInflations.addTextChangedListener(new GenericTextWatcher(mEtInflations));
        mEtCurrentSaving.addTextChangedListener(new GenericTextWatcher(mEtCurrentSaving));
        mEtExitingCurpus.addTextChangedListener(new GenericTextWatcher(mEtExitingCurpus));
        mEtPreRetirement.addTextChangedListener(new GenericTextWatcher(mEtPreRetirement));
        mEtPostRetirement.addTextChangedListener(new GenericTextWatcher(mEtPostRetirement));
        mEtLifeExpectation.addTextChangedListener(new GenericTextWatcher(mEtLifeExpectation));
        calculateAmount();
        return view;
    }

    private void setupFooter() {
        setTintColorIfDark(requireActivity(), mIvAppLogo);
        mIvAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getResources().getString(R.string.subdomain).equals("mint")) {
            if (mSession.getHasLoging()) {
                if (!TextUtils.isEmpty(mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")) {
                    Picasso.get().load(mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                    mIvAppLogo.setVisibility(View.VISIBLE);
                } else {
                    mIvAppLogo.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")) {
                    mTvAddress.setText(mSession.getAddress());
                    mTvAddress.setVisibility(View.VISIBLE);
                } else {
                    mTvAddress.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")) {
                    mTvWebsite.setText(mSession.getWebsite());
                    mTvWebsite.setVisibility(View.VISIBLE);
                } else {
                    mTvWebsite.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")) {
                    mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                    mTvPhone.setVisibility(View.VISIBLE);
                } else {
                    mTvPhone.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")) {
                    mTvEmail.setText(mSession.getUserEmail());
                    mTvEmail.setVisibility(View.VISIBLE);
                } else {
                    mTvEmail.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")) {
                    mTvAppName.setText(mSession.getCompanyName());
                    mTvAppName.setVisibility(View.VISIBLE);
                } else {
                    mTvAppName.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                    mTvSlogan.setText(mSession.getSloganOnLogo());
                    mTvSlogan.setVisibility(View.VISIBLE);
                }else{
                    mTvSlogan.setVisibility(View.GONE);
                }
            } else {
                if (!TextUtils.isEmpty(mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")) {
                    Picasso.get().load(mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                }
                mTvAddress.setText(getResources().getString(R.string.locatetext));
                mTvWebsite.setText(getResources().getString(R.string.website));
                mTvPhone.setText(getResources().getString(R.string.image_phone));
                mTvEmail.setText(getResources().getString(R.string.support_email_address));
                mTvAppName.setText(getString(R.string.app_name));
                mTvSlogan.setText(mSession.getSloganOnLogo());
            }
        } else {
            mIvAppLogo.setVisibility(View.VISIBLE);
            int squareLogo =   UtilityKotlin.checkExistResources("app_logo_square","mipmap",requireContext());
            int circleLogo =   UtilityKotlin.checkExistResources("app_logo_round","mipmap",requireContext());
            if (squareLogo !=0) {
                mIvAppLogo.setImageResource(squareLogo);
            }else if (circleLogo !=0) {
                mIvAppLogo.setImageResource(circleLogo);
            }else{
                mIvAppLogo.setImageResource(R.mipmap.app_logo);
            }

            if (!TextUtils.isEmpty(mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")) {
                mTvAddress.setText(mSession.getAddress());
                mTvAddress.setVisibility(View.VISIBLE);
            } else {
                mTvAddress.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")) {
                mTvWebsite.setText(mSession.getWebsite());
                mTvWebsite.setVisibility(View.VISIBLE);
            } else {
                mTvWebsite.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")) {
                mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                mTvPhone.setVisibility(View.VISIBLE);
            } else {
                mTvPhone.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")) {
                mTvEmail.setText(mSession.getUserEmail());
                mTvEmail.setVisibility(View.VISIBLE);
            } else {
                mTvEmail.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")) {
                mTvAppName.setText(mSession.getCompanyName());
                mTvAppName.setVisibility(View.VISIBLE);
            } else {
                mTvAppName.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                mTvSlogan.setText(mSession.getSloganOnLogo());
                mTvSlogan.setVisibility(View.VISIBLE);
            }else{
                mTvSlogan.setVisibility(View.GONE);
            }

        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.toolBar_title_retirement_cal),
                    true, true, false, false, true, false, false);
            fragToolBar.setCallback(this);
        }
        tvHeaderTitle.setText(getResources().getString(R.string.toolBar_title_retirement_cal));
    }

    @Override
    public void onStateChange(boolean newstate) {

    }

    @Override
    public void onRotate(int percentage) {

    }

    @Override
    public void onClick(View view) {
        int duration = Integer.parseInt(mEtRetiermentAge.getText().toString()) - Integer.parseInt(mEtPresentAge.getText().toString());

        Bundle bundle = new Bundle();
     /*   if (view.getId() == R.id.ivRight) {
            saveFrameLayout();
        }*//* else if (view.getId() == R.id.ivRight2) {
            refreshView();
        }*//* else if (view.getId() == R.id.ivLeft) {
            mActivity.getSupportFragmentManager().popBackStack();
        } else */
        if (view.getId() == R.id.lumpsum_btn) {
            bundle.putString("type", "coming_from_goal");
            bundle.putString("investment_type", "Lumpsum");
            bundle.putString("ic_invest_route_goal", "Retirement Planning");
            bundle.putString("Amount", mResultLumpsum);
            bundle.putInt("duration", duration);
            mActivity.displayViewOther(64, bundle);
            System.out.println(bundle.toString());

        } else if (view.getId() == R.id.sip_btn) {
            bundle.putString("type", "coming_from_goal");
            bundle.putString("investment_type", "SIP");
            bundle.putString("ic_invest_route_goal", "Retirement Planning");
            bundle.putString("Amount", mResultSIP);
            bundle.putInt("duration", duration);
            mActivity.displayViewOther(64, bundle);
        }


    }


    private void refreshView() {

        mDailerInvest1.setRotorPercentage(0);
        mDailerInvest2.setRotorPercentage(0);
        mDailerInvest3.setRotorPercentage(0);
        mDailerInvest4.setRotorPercentage(0);
        mDailerInvest5.setRotorPercentage(0);
        mDailerInvest6.setRotorPercentage(0);
        mDailerInvest7.setRotorPercentage(0);
        mDailerInvest8.setRotorPercentage(0);
        mDailerInvest9.setRotorPercentage(0);
        mEtPresentAge.setText("30");
        mEtRetiermentAge.setText("60");
        mEtMonthlyExpense.setText("30000");
        mEtInflations.setText("6.00");
        mEtCurrentSaving.setText("5000");
        mEtExitingCurpus.setText("100000");
        mEtPreRetirement.setText("12.00");
        mEtPostRetirement.setText("7.00");
        mEtLifeExpectation.setText("80");

        calculateAmount();
    }

    private void delayCall() {
        timer.cancel();
        timer = new Timer();
        timer.schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        if (mBrokerActivity != null) {
                            mBrokerActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });

                        } else {
                            mActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });
                        }
                    }
                },
                DELAY
        );
    }

    private void calculateAmount() {
        mTvCurrentAgeError.setVisibility(View.GONE);
        mTvRetirementAgeError.setVisibility(View.GONE);
        mTvMonthlyExpenseError.setVisibility(View.GONE);
        mTvPreRetirementReturnError.setVisibility(View.GONE);
        mTvPostRetirementReturnError.setVisibility(View.GONE);
        mTvLifeExpectancyError.setVisibility(View.GONE);

        if (mBrokerActivity != null) {
            if (mEtPresentAge.getText().toString().equals("") || mEtPresentAge.getText().toString().equals("0")) {
                if (dialogShown) {
                    return;
                } else {
                    dialogShown = true;
//                    mBrokerActivity.showCommonDialog(mBrokerActivity, "Not Valid", getResources().getString(R.string.error_current_age));
                    mTvCurrentAgeError.setVisibility(View.VISIBLE);
                    mTvCurrentAgeError.announceForAccessibility(getResources().getString(R.string.error_current_age));
                    mTvCurrentAgeError.setText(getResources().getString(R.string.error_current_age));
                }

            } else if (Integer.parseInt(mEtPresentAge.getText().toString()) < 18) {
                mTvCurrentAgeError.setVisibility(View.VISIBLE);
                mTvCurrentAgeError.announceForAccessibility(getResources().getString(R.string.error_minn_retire_age));
                mTvCurrentAgeError.setText(getResources().getString(R.string.error_minn_retire_age));
            } else if (mEtRetiermentAge.getText().toString().equals("") || mEtRetiermentAge.getText().toString().equals("0")) {
                mTvRetirementAgeError.setVisibility(View.VISIBLE);
                mTvRetirementAgeError.announceForAccessibility(getResources().getString(R.string.error_empty_retiremnt_age));
                mTvRetirementAgeError.setText(getResources().getString(R.string.error_empty_retiremnt_age));
            } else if (Integer.parseInt(mEtRetiermentAge.getText().toString()) > 80) {
                mEtRetiermentAge.setText("80");
                mTvRetirementAgeError.setVisibility(View.VISIBLE);
                mTvRetirementAgeError.announceForAccessibility(getResources().getString(R.string.error_maxx_retire_age));
                mTvRetirementAgeError.setText(getResources().getString(R.string.error_maxx_retire_age));
            } else if (Integer.parseInt(mEtPresentAge.getText().toString()) > Integer.parseInt(mEtRetiermentAge.getText().toString())) {
//                mEtPresentAge.setError(getString(R.string.txt_current_age_always_less_than_retirement_age));
                mTvCurrentAgeError.setVisibility(View.VISIBLE);
                mTvCurrentAgeError.announceForAccessibility(getResources().getString(R.string.txt_current_age_always_less_than_retirement_age));
                mTvCurrentAgeError.setText(getString(R.string.txt_current_age_always_less_than_retirement_age));
            } else if (mEtMonthlyExpense.getText().toString().equals("") || mEtMonthlyExpense.getText().toString().equals("0")) {
                mTvMonthlyExpenseError.setVisibility(View.VISIBLE);
                mTvMonthlyExpenseError.announceForAccessibility(getResources().getString(R.string.error_empty_monthly_expense));
                mTvMonthlyExpenseError.setText(getResources().getString(R.string.error_empty_monthly_expense));
            } else if (getLongValue(mEtMonthlyExpense) < 1000) {
                mTvMonthlyExpenseError.setVisibility(View.VISIBLE);
                mTvMonthlyExpenseError.announceForAccessibility(getResources().getString(R.string.error_minn_me));
                mTvMonthlyExpenseError.setText(getResources().getString(R.string.error_minn_me));
            } else if (mEtPreRetirement.getText().toString().equals("") ||mEtPreRetirement.getText().toString().equals(".") || mEtPreRetirement.getText().toString().equals("0")) {
                mTvPreRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPreRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_expected_ror));
                mTvPreRetirementReturnError.setText(getResources().getString(R.string.error_expected_ror));
            } else if (getDoubleValue(mEtPreRetirement) > 50) {
                mTvPreRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPreRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_max_ror));
                mTvPreRetirementReturnError.setText(getResources().getString(R.string.error_max_ror));
            } else if (mEtPostRetirement.getText().toString().equals("") ||mEtPostRetirement.getText().toString().equals(".") || mEtPostRetirement.getText().toString().equals("0")) {
                mTvPostRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPostRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_post_retiremnt_return));
                mTvPostRetirementReturnError.setText(getResources().getString(R.string.error_post_retiremnt_return));
            } else if (getDoubleValue(mEtPostRetirement) > 30) {
                mTvPostRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPostRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_max_expected_post_retiremnt_ror));
                mTvPostRetirementReturnError.setText(getResources().getString(R.string.error_max_expected_post_retiremnt_ror));
            } else if (mEtLifeExpectation.getText().toString().equals("") || mEtLifeExpectation.getText().toString().equals(".")) {
                mTvLifeExpectancyError.setVisibility(View.VISIBLE);
                mTvLifeExpectancyError.announceForAccessibility(getResources().getString(R.string.error_empty_something));
                mTvLifeExpectancyError.setText(getResources().getString(R.string.error_empty_something));
            } else if (Integer.parseInt(mEtLifeExpectation.getText().toString()) > 100) {
                mTvLifeExpectancyError.setVisibility(View.VISIBLE);
                mTvLifeExpectancyError.announceForAccessibility(getResources().getString(R.string.error_max_life));
                mTvLifeExpectancyError.setText(getResources().getString(R.string.error_max_life));
            } else if ((Integer.parseInt(mEtLifeExpectation.getText().toString())) < (Integer.parseInt(mEtRetiermentAge.getText().toString()))) {
                mTvLifeExpectancyError.setVisibility(View.VISIBLE);
                mTvLifeExpectancyError.announceForAccessibility(getResources().getString(R.string.invalid_life_retire));
                mTvLifeExpectancyError.setText(getResources().getString(R.string.invalid_life_retire));
            } else {
                String rawValue = mEtMonthlyExpense.getText().toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue, mEtMonthlyExpense);

                String rawValue2 = mEtCurrentSaving.getText().toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue2, mEtCurrentSaving);

                String rawValue3 = mEtExitingCurpus.getText().toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue3, mEtExitingCurpus);
                try {

                    ret_year = 0;
                    dblAmtReq = 0;
                    dblExistingGrowth = 0;
                    lumsum = 0;
                    amt_acc = 0;
                    amt_final = 0;
                    short_fall = 0;
                    extra_amt = 0;

                    dblCurrentAge = getDoubleValue(mEtPresentAge);
                    dblRetirementAge =   getDoubleValue(mEtRetiermentAge);
                    dblMonthlyExpenses = getDoubleValue(mEtMonthlyExpense);
                    dblMonthlySavings =  getDoubleValue(mEtCurrentSaving);
                    dlbExistingCorpus =  getDoubleValue(mEtExitingCurpus);
                    dblPreRetirement =   getDoubleValue(mEtPreRetirement);
                    postRetirmentRate =  getDoubleValue(mEtPostRetirement);
                    inflationRate =      getDoubleValue(mEtInflations);
                    dlbLifeExpetancy =   getDoubleValue(mEtLifeExpectation);

                    ///calculation for yeras in retirement
                    ret_year = dblRetirementAge - dblCurrentAge;

                    //Age After retirement
                    double xAfterRetAge = dlbLifeExpetancy - dblRetirementAge;

                    double finalrate = postRetirmentRate - inflationRate;
                    if (finalrate == 0) {
                        finalrate = 0.0001;
                    }
                    double xRRR = (finalrate / (1 + 0.01 * inflationRate)) / 100;

                    //After Retirement Rate
                    double xRRRAR = postRetirmentRate / 100;

                    //Calculation for amount require after retirement --- This is for Expense after Retirement
                    dblAmtReq = dblMonthlyExpenses * (Math.pow((1 + inflationRate / 100), ret_year));

                    //Calculation for existing corpus gain after retirement
                    dblExistingGrowth = dlbExistingCorpus * (Math.pow((1 + dblPreRetirement / 100), ret_year));

                    //Calculation for Corpus suggested by Jain Sir applied in Fincart
                    double pow = Math.pow(1 + xRRR, (xAfterRetAge + 1)) - (1 + xRRR);
                    double pow1 = (xRRR * Math.pow(1 + xRRR, xAfterRetAge));

                    //calculation for lum sum amount ---- Corpus Required
                    lumsum = (dblAmtReq * 12 * (pow / pow1));

                 /*   //Based on PV formula by Moneycontrol
                    double pow = Math.pow(1 + xRRR, (xAfterRetAge + 1)) - (1 + xRRR);
                    double pow1 = (xRRR * Math.pow(1 + xRRR, xAfterRetAge));

                    lumsum = (dblAmtReq * 12 * (pow / pow1));
//mTvSipAmount.setText((int) lumsum);*/

                    // Calculation for amount accumulate with current saving

                    double tt = ret_year * 12;
                    double rt = dblPreRetirement / 12;

                    for (int i = 1; i <= tt; i++) {
                        amt_acc = dblMonthlySavings * (Math.pow((1 + rt / 100), i));
                        amt_final += amt_acc;
                    }

                    //Total Savings based on Present Saving Structures
                    totalSavings = amt_final + dblExistingGrowth;

                    //Shortfall Calculation
                    short_fall = lumsum - (amt_final + dblExistingGrowth);

                    //Calculation for lumpsum amount
                    LumpSumInvestment=short_fall/(Math.pow((1+dblPreRetirement/100),ret_year));
                    //=============new sip formula nov 2024 =======
                    double r=dblPreRetirement/12;
                    double t=ret_year*12;
                    double MonthlyInvestments = 0;
                    MonthlyInvestments = (short_fall * r/100)/(Math.pow((1+r/100),t)-1);


                    if (short_fall > 0) {
                        double pm = 12 * ret_year;
                        double intr = dblPreRetirement / 1200;

                        double powr = Math.pow((1 + intr), pm);
                        extra_amt = ((short_fall * ((intr * powr) / (powr - 1))) / powr);
                        if (dblPreRetirement == 0) {
                            extra_amt = (short_fall / (ret_year * 12));
                        }
                        if (ret_year == 0) {
                            extra_amt = short_fall;
                        }
                    }
                    mTvResult4.setText(String.valueOf(short_fall));

                    String strAmount = "";

                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));

                    mTvText1.setText(getString(R.string.expected_monthly_expenses_when_you_retire_at) + (int)dblRetirementAge + getString(R.string.years_would_be));
                    long value1 = Math.round(dblAmtReq);
                    strAmount = format.format(value1);
                    resultAmount = strAmount.split("\\.", 0);
                    tvAmount.setText(resultAmount[0] + "/-");
                    tvHeaderDesc.setText(R.string.estimated_amount_required_as_retirement);

                    long value2 = Math.round(lumsum);
                    strAmount = format.format(value2);
                    resultAmount = strAmount.split("\\.", 0);
                    tv_amount2.setText(resultAmount[0] + "/-");

                    double totalAmount = Math.round(amt_final + dblExistingGrowth);
                    long value3 = Math.round(totalAmount);
                    strAmount = format.format(value3);
                    resultAmount = strAmount.split("\\.", 0);
                    tvLine5.setText(getString(R.string.total_savings_at_the_time_of_retirement_will_be)+resultAmount[0]);

                    double shortFall = Math.round(short_fall);
                    long value4 =  Math.round(shortFall);
                    strAmount = format.format(value4);
                    resultAmount = strAmount.split("\\.", 0);
                    if (shortFall > 0) {
                        llSipLum.setVisibility(View.VISIBLE);
                        tvLine6.setVisibility(View.VISIBLE);

                        tvLine6.setText(getString(R.string.shortfall_in_savings)+resultAmount[0]);
                        tvSipLumSumMessage.setText(R.string.to_achieve_this_goal_you_need_to_do);

                        long valueSip = Math.round(MonthlyInvestments);
                        strAmount = format.format(valueSip);
                        resultAmount = strAmount.split("\\.", 0);
                        mTvSipAmount.setText(resultAmount[0]);

                        long valueshortfall = Math.round(LumpSumInvestment);
                        strAmount = format.format(valueshortfall);
                        resultAmount = strAmount.split("\\.", 0);
                        mTvResult4.setText(resultAmount[0]);

                    }else{
                        tvSipLumSumMessage.setText(getString(R.string.congratulations_new_line) +
                                getString(R.string.your_current_savings_is_enough_to_sustain_your_post_retirement_expenses_should_there_be_a_change_in_expense_pattern_or_rate_of_return_please_do_recalculate));

                        llSipLum.setVisibility(View.GONE);
                        tvLine6.setVisibility(View.GONE);
                    }

                    String announcement =
                            mTvText1.getText().toString() + ". " + tvAmount.getText().toString() + ". "
                                    + tvHeaderDesc.getText().toString() + ". " + ". " + tv_amount2.getText().toString() + ". "
                                    + tvLine5.getText().toString() + ". " + ". " + tvLine6.getText().toString() + ". "
                                    + tvLine5.getText().toString() + ". " + ". " + tvLine6.getText().toString() + ". "
                                    + tvSipLumSumMessage.getText().toString() + ". "
                                    + getString(R.string.SIP) + mTvSipAmount.getText().toString() + ". "
                                    + getString(R.string.lumpsum) + mTvResult4.getText().toString() + ". ";

                    tvAmount.post(() ->
                            tvAmount.announceForAccessibility(announcement)
                    );
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        } else {
            if (mEtPresentAge.getText().toString().equals("") || mEtPresentAge.getText().toString().equals("0")) {
                //mActivity.showCommonDialog(mActivity, "Not Valid", "Please enter Current Age");
                if (dialogShown) {
                    return;
                } else {
                    dialogShown = true;
                    // mActivity.showCommonDialog(mActivity, "Not Valid", "Please enter Current Age");
                }
            } else if (Integer.parseInt(mEtPresentAge.getText().toString()) < 18) {
                mTvCurrentAgeError.setVisibility(View.VISIBLE);
                mTvCurrentAgeError.announceForAccessibility(getResources().getString(R.string.error_current_age));
                mTvCurrentAgeError.setText(getResources().getString(R.string.error_current_age));
            } else if (mEtRetiermentAge.getText().toString().equals("") || mEtRetiermentAge.getText().toString().equals("0")) {
                mTvRetirementAgeError.setVisibility(View.VISIBLE);
                mTvRetirementAgeError.announceForAccessibility(getResources().getString(R.string.error_minn_retire_age));
                mTvRetirementAgeError.setText(getResources().getString(R.string.error_minn_retire_age));
            } else if (Integer.parseInt(mEtRetiermentAge.getText().toString()) > 80) {
                mEtRetiermentAge.setText("80");
                mTvRetirementAgeError.setVisibility(View.VISIBLE);
                mTvRetirementAgeError.announceForAccessibility(getResources().getString(R.string.error_empty_retiremnt_age));
                mTvRetirementAgeError.setText(getResources().getString(R.string.error_empty_retiremnt_age));
            } else if (Integer.parseInt(mEtPresentAge.getText().toString()) > Integer.parseInt(mEtRetiermentAge.getText().toString())) {
        /*        if(dialogShown){
                    return ;
                }else{
                    dialogShown = true;
                    mActivity.showCommonDialog(mActivity, "Not Valid", "Current Age always less than Retirement age");*/
                mEtPresentAge.setError(getString(R.string.txt_current_age_always_less_than_retirement_age));
                mEtPresentAge.announceForAccessibility(getResources().getString(R.string.txt_current_age_always_less_than_retirement_age));
                mApplication.showSnackBar(mEtPresentAge, getResources().getString(R.string.error_maxx_retire_age));
                /*  }*/

            } else if (mEtMonthlyExpense.getText().toString().equals("") || mEtMonthlyExpense.getText().toString().equals("0")) {
                mTvMonthlyExpenseError.setVisibility(View.VISIBLE);
                mTvMonthlyExpenseError.announceForAccessibility(getResources().getString(R.string.error_empty_monthly_expense));
                mTvMonthlyExpenseError.setText(getResources().getString(R.string.error_empty_monthly_expense));
            } else if (getLongValue(mEtMonthlyExpense) < 1000) {
                mTvMonthlyExpenseError.setVisibility(View.VISIBLE);
                mTvMonthlyExpenseError.announceForAccessibility(getResources().getString(R.string.error_minn_me));
                mTvMonthlyExpenseError.setText(getResources().getString(R.string.error_minn_me));
            } else if (mEtPreRetirement.getText().toString().equals("") ||mEtPreRetirement.getText().toString().equals(".") || mEtPreRetirement.getText().toString().equals("0")) {
                mTvPreRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPreRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_expected_ror));
                mTvPreRetirementReturnError.setText(getResources().getString(R.string.error_expected_ror));
            } else if (getDoubleValue(mEtPreRetirement) > 50) {
                mEtPreRetirement.setText("30.00");
                mTvPreRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPreRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_max_ror));
                mTvPreRetirementReturnError.setText(getResources().getString(R.string.error_max_ror));
            } else if (mEtPostRetirement.getText().toString().equals("") ||mEtPostRetirement.getText().toString().equals(".") || mEtPostRetirement.getText().toString().equals("0")) {
                mTvPostRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPostRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_post_retiremnt_return));
                mTvPostRetirementReturnError.setText(getResources().getString(R.string.error_post_retiremnt_return));
            } else if (getDoubleValue(mEtPostRetirement) > 30) {
                mEtPostRetirement.setText("30.00");
                mTvPostRetirementReturnError.setVisibility(View.VISIBLE);
                mTvPostRetirementReturnError.announceForAccessibility(getResources().getString(R.string.error_max_expected_post_retiremnt_ror));
                mTvPostRetirementReturnError.setText(getResources().getString(R.string.error_max_expected_post_retiremnt_ror));
            } else if (mEtLifeExpectation.getText().toString().equals("") || mEtLifeExpectation.getText().toString().equals(".")) {
                mTvLifeExpectancyError.setVisibility(View.VISIBLE);
                mTvLifeExpectancyError.announceForAccessibility(getResources().getString(R.string.error_empty_something));
                mTvLifeExpectancyError.setText(getResources().getString(R.string.error_empty_something));
            } else if (Integer.parseInt(mEtLifeExpectation.getText().toString()) > 100) {
                mEtLifeExpectation.setText("100");
                mTvLifeExpectancyError.setVisibility(View.VISIBLE);
                mTvLifeExpectancyError.announceForAccessibility(getResources().getString(R.string.error_max_life));
                mTvLifeExpectancyError.setText(getResources().getString(R.string.error_max_life));
            } else if ((Integer.parseInt(mEtLifeExpectation.getText().toString())) < (Integer.parseInt(mEtRetiermentAge.getText().toString()))) {
                mTvLifeExpectancyError.setVisibility(View.VISIBLE);
                mTvLifeExpectancyError.announceForAccessibility(getResources().getString(R.string.invalid_life_retire));
                mTvLifeExpectancyError.setText(getResources().getString(R.string.invalid_life_retire));
            } else {
                String rawValue = mEtMonthlyExpense.getText().toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue, mEtMonthlyExpense);

                String rawValue2 = mEtCurrentSaving.getText().toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue2, mEtCurrentSaving);

                String rawValue3 = mEtExitingCurpus.getText().toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue3, mEtExitingCurpus);
                try {

                    ret_year = 0;
                    dblAmtReq = 0;
                    dblExistingGrowth = 0;
                    lumsum = 0;
                    amt_acc = 0;
                    amt_final = 0;
                    short_fall = 0;
                    extra_amt = 0;

                    dblCurrentAge = getDoubleValue(mEtPresentAge);
                    dblRetirementAge =   getDoubleValue(mEtRetiermentAge);
                    dblMonthlyExpenses = getDoubleValue(mEtMonthlyExpense);
                    dblMonthlySavings =  getDoubleValue(mEtCurrentSaving);
                    dlbExistingCorpus =  getDoubleValue(mEtExitingCurpus);
                    dblPreRetirement =   getDoubleValue(mEtPreRetirement);
                    postRetirmentRate =  getDoubleValue(mEtPostRetirement);
                    inflationRate =      getDoubleValue(mEtInflations);
                    dlbLifeExpetancy =   getDoubleValue(mEtLifeExpectation);

                    ///calculation for yeras in retirement
                    ret_year = dblRetirementAge - dblCurrentAge;

                    //Age After retirement
                    double xAfterRetAge = dlbLifeExpetancy - dblRetirementAge;

                    double finalrate = postRetirmentRate - inflationRate;
                    if (finalrate == 0) {
                        finalrate = 0.0001;
                    }
                    double xRRR = (finalrate / (1 + 0.01 * inflationRate)) / 100;

                    //After Retirement Rate
                    double xRRRAR = postRetirmentRate / 100;

                    //Calculation for amount require after retirement --- This is for Expense after Retirement
                    dblAmtReq = dblMonthlyExpenses * (Math.pow((1 + inflationRate / 100), ret_year));

                    //Calculation for existing corpus gain after retirement
                    dblExistingGrowth = dlbExistingCorpus * (Math.pow((1 + dblPreRetirement / 100), ret_year));

                    //Calculation for Corpus suggested by Jain Sir applied in Fincart
                    double pow = Math.pow(1 + xRRR, (xAfterRetAge + 1)) - (1 + xRRR);
                    double pow1 = (xRRR * Math.pow(1 + xRRR, xAfterRetAge));

                    //calculation for lum sum amount ---- Corpus Required
                    lumsum = (dblAmtReq * 12 * (pow / pow1));

                 /*   //Based on PV formula by Moneycontrol
                    double pow = Math.pow(1 + xRRR, (xAfterRetAge + 1)) - (1 + xRRR);
                    double pow1 = (xRRR * Math.pow(1 + xRRR, xAfterRetAge));

                    lumsum = (dblAmtReq * 12 * (pow / pow1));
//mTvSipAmount.setText((int) lumsum);*/

                    // Calculation for amount accumulate with current saving

                    double tt = ret_year * 12;
                    double rt = dblPreRetirement / 12;

                    for (int i = 1; i <= tt; i++) {
                        amt_acc = dblMonthlySavings * (Math.pow((1 + rt / 100), i));
                        amt_final += amt_acc;
                    }

                    //Total Savings based on Present Saving Structures
                    totalSavings = amt_final + dblExistingGrowth;

                    //Shortfall Calculation
                    short_fall = lumsum - (amt_final + dblExistingGrowth);

                    //Calculation for lumpsum amount
                    LumpSumInvestment=short_fall/(Math.pow((1+dblPreRetirement/100),ret_year));


                    //Calculation for extra amount to save

                    double sipAmount = 0;
                    if (short_fall > 0) {
                        double pm = 12 * ret_year;
                        double intr = dblPreRetirement / 1200;
                        double powr = Math.pow((1 + intr), pm);
                        double nSip = short_fall;
                        double nYears = ret_year;
                        double nRate = dblPreRetirement;
                        double r = nRate / 100;
                        double nMonths = (nYears * 12);
                        for (int i = 0; i < nMonths; i++) {
                            sipAmount = sipAmount + Math.pow((1 + r), (nMonths - i) / 12);
                        }
                        sipAmount = nSip / sipAmount;
                    }

                    if (short_fall > 0) {
                        double pm = 12 * ret_year;
                        double intr = dblPreRetirement / 1200;

                        double powr = Math.pow((1 + intr), pm);
                        extra_amt = ((short_fall * ((intr * powr) / (powr - 1))) / powr);
                        if (dblPreRetirement == 0) {
                            extra_amt = (short_fall / (ret_year * 12));
                        }
                        if (ret_year == 0) {
                            extra_amt = short_fall;
                        }
                    }
                    mTvResult4.setText(String.valueOf(short_fall));

                    String strAmount = "";

                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));

                    mTvText1.setText(getString(R.string.expected_monthly_expenses_when_you_retire_at) + (int)dblRetirementAge + getString(R.string.years_would_be));
                    long value1 = Math.round(dblAmtReq);
                    strAmount = format.format(value1);
                    resultAmount = strAmount.split("\\.", 0);
                    tvAmount.setText(resultAmount[0] + "/-");
                    tvHeaderDesc.setText(getString(R.string.estimated_amount_required_as_retirement));

                    long value2 = Math.round(lumsum);
                    strAmount = format.format(value2);
                    resultAmount = strAmount.split("\\.", 0);
                    tv_amount2.setText(resultAmount[0] + "/-");

                    double totalAmount = Math.round(amt_final + dblExistingGrowth);
                    long value3 = Math.round(totalAmount);
                    strAmount = format.format(value3);
                    resultAmount = strAmount.split("\\.", 0);
                    tvLine5.setText(getString(R.string.total_savings_at_the_time_of_retirement_will_be)+resultAmount[0]);

                    double shortFall = Math.round(short_fall);
                    long value4 =  Math.round(shortFall);
                    strAmount = format.format(value4);
                    resultAmount = strAmount.split("\\.", 0);
                    if (shortFall > 0) {
                        llSipLum.setVisibility(View.VISIBLE);
                        tvLine6.setVisibility(View.VISIBLE);

                        tvLine6.setText(getString(R.string.shortfall_in_savings)+resultAmount[0]);
                        tvSipLumSumMessage.setText(getString(R.string.to_achieve_this_goal_you_need_to_do));

                        long valueSip = Math.round(sipAmount);
                        strAmount = format.format(valueSip);
                        resultAmount = strAmount.split("\\.", 0);
                        mTvSipAmount.setText(resultAmount[0]);

                        long valueshortfall = Math.round(LumpSumInvestment);
                        strAmount = format.format(valueshortfall);
                        resultAmount = strAmount.split("\\.", 0);
                        mTvResult4.setText(resultAmount[0]);

                    }else{
                        tvSipLumSumMessage.setText(getString(R.string.congratulations_new_line) +
                                getString(R.string.your_current_savings_is_enough_to_sustain_your_post_retirement_expenses_should_there_be_a_change_in_expense_pattern_or_rate_of_return_please_do_recalculate));

                        llSipLum.setVisibility(View.GONE);
                        tvLine6.setVisibility(View.GONE);
                    }

                    String announcement =
                            mTvText1.getText().toString() + ". "  + tvAmount.getText().toString() + ". "
                                    +  tvHeaderDesc.getText().toString() + ". " +". " + tv_amount2.getText().toString() + ". "
                                    +  tvLine5.getText().toString() + ". " +". " + tvLine6.getText().toString() + ". "
                                    +  tvLine5.getText().toString() + ". " +". " + tvLine6.getText().toString() + ". "
                                    + tvSipLumSumMessage.getText().toString() + ". "
                                    + getString(R.string.SIP) + mTvSipAmount.getText().toString() + ". "
                                    + getString(R.string.lumpsum) + mTvResult4.getText().toString() + ". ";

                    tvAmount.post(() ->
                            tvAmount.announceForAccessibility(announcement)
                    );
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }
    }

    private double getDoubleValue(EditText editText) {
        try {
            String value = editText.getText()
                    .toString()
                    .replace(",", "")
                    .trim();

            if (TextUtils.isEmpty(value) || ".".equals(value)) {
                return 0d;
            }

            return Double.parseDouble(value);

        } catch (Exception e) {
            return 0d;
        }
    }

    private long getLongValue(EditText editText) {
        try {
            String value = editText.getText()
                    .toString()
                    .replace(",", "")
                    .trim();

            if (TextUtils.isEmpty(value)) {
                return 0L;
            }

            return Long.parseLong(value);

        } catch (Exception e) {
            return 0L;
        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        hideKeyPad();
        String currentValue = "";
        int i = view.getId();
        if (i == R.id.dialer1) {
            currentValue = mEtPresentAge.getText().toString();

            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 20)
                    mEtPresentAge.setText("" + 20);
                else if (value > 80)
                    mEtPresentAge.setText("" + 80);
            } else {
                mEtPresentAge.setText("" + 25);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer2) {
            currentValue = mEtRetiermentAge.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 25)
                    mEtRetiermentAge.setText("" + 25);
                else if (value > 100)
                    mEtRetiermentAge.setText("" + 100);

            } else {
                mEtRetiermentAge.setText("" + 60);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer3) {
            currentValue = mEtMonthlyExpense.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 1000)
                    mEtMonthlyExpense.setText("" + 1000);

            } else {
                mEtMonthlyExpense.setText("" + 1000);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer4) {
            currentValue = mEtInflations.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtInflations.setText("" + 1.00);
                else if (value > 30)
                    mEtInflations.setText("" + 30.00);
            } else {
                mEtInflations.setText("" + 1.00);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer5) {
            currentValue = mEtCurrentSaving.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 1000)
                    mEtCurrentSaving.setText("" + 1000);

            } else {
                mEtCurrentSaving.setText("" + 1000);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer6) {
            currentValue = mEtExitingCurpus.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 1)
                    mEtExitingCurpus.setText("" + 0);

            } else {
                mEtExitingCurpus.setText("" + 0);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer7) {
            currentValue = mEtPreRetirement.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtPreRetirement.setText("" + 1.00);
                else if (value > 30)
                    mEtPreRetirement.setText("" + 30.00);

            } else {
                mEtPreRetirement.setText("" + 1.00);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer8) {
            currentValue = mEtPostRetirement.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtPostRetirement.setText("" + 1.00);
                else if (value > 30)
                    mEtPostRetirement.setText("" + 30.00);

            } else {
                mEtPostRetirement.setText("" + 1.00);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer9) {
            currentValue = mEtLifeExpectation.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 30)
                    mEtLifeExpectation.setText("" + 30);

            } else {
                mEtLifeExpectation.setText("" + 30);
            }

            desableScrollView(motionEvent);

        }
        return false;
    }

    private void desableScrollView(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            mScrollView.requestDisallowInterceptTouchEvent(true);

        else if (motionEvent.getAction() == MotionEvent.ACTION_UP)
            mScrollView.requestDisallowInterceptTouchEvent(false);

    }

    public void hideKeyPad() {
        if (mBrokerActivity != null) {
            InputMethodManager inputManager = (InputMethodManager) mBrokerActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mBrokerActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } else {
            InputMethodManager inputManager = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }


    public void saveFrameLayout() {
        mClCalcFooter.setVisibility(View.VISIBLE);
        ll_calculator_header.setVisibility(View.VISIBLE);
        loadUpdatedView();
    }

    private void loadUpdatedView() {
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          createImage();
                                      }
                                  },

                100);
    }

    private void createImage() {
        if (mBrokerActivity != null) {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mBrokerActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        } else {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        }
    }

    private Bitmap getBitmapFromView(View view, int height, int width) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return bitmap;
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                saveFrameLayout();
}
else if (view.getId() == R.id.iv_refresh) {
                refreshView();
}
    }


    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {
            if (mBrokerActivity != null) {
                if (mBrokerActivity.getCurrentFocus() == mEtPresentAge) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtRetiermentAge) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtMonthlyExpense) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtInflations) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtCurrentSaving) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtExitingCurpus) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtPreRetirement) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtPostRetirement) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtLifeExpectation) {
                    delayCall();
                }

            } else {
                if (mActivity.getCurrentFocus() == mEtPresentAge) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtRetiermentAge) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtMonthlyExpense) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtInflations) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtCurrentSaving) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtExitingCurpus) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtPreRetirement) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtPostRetirement) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtLifeExpectation) {
                    delayCall();
                }
            }
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

    }


}