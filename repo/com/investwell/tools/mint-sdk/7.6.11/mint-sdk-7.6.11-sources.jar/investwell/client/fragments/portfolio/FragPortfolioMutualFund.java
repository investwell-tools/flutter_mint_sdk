package investwell.client.fragments.portfolio;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Portfolio_Client_Adapter;
import investwell.utils.AppSession;
import investwell.utils.Config;


public class FragPortfolioMutualFund extends BaseFragment implements View.OnClickListener {
    RequestQueue requestQueue;
    RecyclerView sub_client;
    TextView applicant_name, purchase_cost, market_value, gain, cagr;
    ImageView gain_arrow, cagr_arrow;

    DecimalFormat myFormatter;
    Portfolio_Client_Adapter portfolio_client_adapter;
    Bundle port_bundle;
    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private CardView mCardView;
    private TextView mTvNothing;
    private AppApplication mAppplication;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.stopShimmer();
      /*  if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmer();
        super.onPause();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_portfolio_mutualfund, container, false);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        mTvNothing = view.findViewById(R.id.tvNothing);

        applicant_name = view.findViewById(R.id.applicant_name);
        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        gain = view.findViewById(R.id.gain);
        cagr = view.findViewById(R.id.cagr);

        gain_arrow = view.findViewById(R.id.gain_arrow);
        cagr_arrow = view.findViewById(R.id.cagr_arrow);
        sub_client = view.findViewById(R.id.sub_client);

        sub_client.setHasFixedSize(true);
        sub_client.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        portfolio_client_adapter = new Portfolio_Client_Adapter(getActivity(), new ArrayList<JSONObject>(), new Portfolio_Client_Adapter.OnItemClickListener() {
            @Override
            public void onItemClick(int pos, JSONObject jsonObject) {

            }
        });
        sub_client.setAdapter(portfolio_client_adapter);
        myFormatter = new DecimalFormat("##,##,###.00");

        port_bundle = new Bundle();


        if (AppApplication.DASHBOARD_PORTFOLIO.isEmpty()) {
            getPortfolio();
        } else {
            SetData();
        }

        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}

    }


    private void SetData() {

        try {
            ArrayList<JSONObject> list = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(AppApplication.DASHBOARD_PORTFOLIO);
            if (jsonObject.optInt("status") == 0) {


                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                if (jsonArray.length() > 0) {
                    JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                    mCardView.setVisibility(View.VISIBLE);
                    mTvNothing.setVisibility(View.GONE);


                    if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                        String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                        if (levelNo.equals("98")) {
                            applicant_name.setText(getString(R.string.family_head));
                        } else {
                            applicant_name.setText(UtilityKotlin.getClientHopObject(mSession).optString("name"));
                        }

                    } else {
                        String levelNo = mSession.getLevelNo();
                        if (levelNo.equals("98")) {
                            applicant_name.setText(getString(R.string.family_head));
                        } else {
                            applicant_name.setText(mSession.getPersonName());
                        }
                    }

                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    format.setMinimumFractionDigits(0);
                    format.setMaximumFractionDigits(0);

                    double currentValue = jsonObjectSummary.optDouble("currentValue");
                    String strCurrentAmount = format.format(currentValue);
                    market_value.setText(strCurrentAmount);

                    double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    purchase_cost.setText(strPurchaseValue);

                    double gaine = jsonObjectSummary.optDouble("gain");
                    String strGain = format.format(gaine);
                    gain.setText(strGain);

                    double cgrValue = jsonObjectSummary.optDouble("CAGR");
                    String data2 = String.format("%.2f", cgrValue) + "%";
                    cagr.setText(data2);


                    if (gain.getText().toString().contains("-")) {
                        gain_arrow.setBackgroundResource(R.drawable.menu_down);
                    } else {
                        gain_arrow.setBackgroundResource(R.drawable.menu_up);
                    }
                    if (cagr.getText().toString().contains("-")) {
                        cagr_arrow.setBackgroundResource(R.drawable.menu_down);
                    } else {
                        cagr_arrow.setBackgroundResource(R.drawable.menu_up);
                    }

                    mCardView.setVisibility(View.VISIBLE);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        list.add(jsonObject1);
                    }
                    portfolio_client_adapter.updateList(list);
                } else {
                    mCardView.setVisibility(View.GONE);
                    mTvNothing.setVisibility(View.VISIBLE);
                }
            } else {
                mCardView.setVisibility(View.GONE);
                mTvNothing.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
            mCardView.setVisibility(View.GONE);
        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
        }

    }

    private void getPortfolio() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(new Date());

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioTable");


            /*https://demo.investwell.app/webapi/client/dashboard/getPortfolioReturns?
            filters=[{"endDate":"2019-09-13"}]&group=appid&componentForLoader=
            {"componentName":"folioTable"}&pageSize=20¤tPage=1&investorUid=
            68e4b40eedf91ed2fc94460512aff049&selectedUser=
            {"uid":"68e4b40eedf91ed2fc94460512aff049","levelNo":"98"}*/


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_PORTFOLIO + "filters=" + jsonArray.toString() +
                    "&group=appid"
                    + "&pageSize=100&currentPage=1" +
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession) + "";
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        AppApplication.DASHBOARD_PORTFOLIO = response;
                        SetData();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
