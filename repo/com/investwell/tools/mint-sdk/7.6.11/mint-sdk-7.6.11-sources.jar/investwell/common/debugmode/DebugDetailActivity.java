package investwell.common.debugmode;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import investwell.utils.Extensions;

public class DebugDetailActivity extends AppCompatActivity {
    private TextView mTvApiName, mTvReq, mTvApiRes, mTvApiDateTime;
    private ImageView mIvShare;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        androidx.activity.EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(com.iw.mint.sdk.R.layout.activity_debug_detail);

        Extensions.checkDevice(this);

        initializerControl();
        getDatAFromBundle();
        setListeners();

    }

    private void initializerControl() {
        mTvApiName = findViewById(R.id.textView84);
        mTvReq = findViewById(R.id.textView85);
        mTvApiDateTime = findViewById(R.id.textView87);
        mTvApiRes = findViewById(R.id.textView88);

        mIvShare = findViewById(R.id.imageView49);
    }

    private void getDatAFromBundle() {
        Intent i = getIntent();
        if (getIntent() != null) {
            setUpUiData(i.getStringExtra("API"), i.getStringExtra("apireq"),
                    i.getStringExtra("apiDate"), i.getStringExtra("apiRes"));
        }

    }

    private String prettifyJson(String jsonString) {
        JSONObject jsonObject = null;

        try {
            jsonObject = new JSONObject(jsonString);
        } catch (JSONException ignored) {
        }

        try {
            if (jsonObject != null) {
                return jsonObject.toString(4);
            }
        } catch (JSONException ignored) {
        }

        return "empty";
    }

    private void setUpUiData(String url, String req, String res, String date) {
        mTvReq.setText(req);
        mTvApiDateTime.setText(res);

        try {
            JSONObject jsonObj = new JSONObject(date);
            mTvApiRes.setText(jsonObj.toString(10));
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }




        mTvApiName.setText(url);
    }

    private void onShare(String apiName, String apiReq, String apiRes, String dateTime) {

        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        String text = "Api:\n" + apiName + "\n" +
                "REQUEST\n" + apiReq + "\n" + "RESPONSE\n" +
                apiRes + "DATETIME :\n" + dateTime +
                "&hl=en";

        i.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(i);
    }

    private void setListeners() {
        mIvShare.setOnClickListener(v -> {
            onShare(mTvApiName.getText().toString(), mTvReq.getText().toString(),
                    mTvApiDateTime.getText().toString(), mTvApiRes.getText().toString());
        });

    }
}