package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.client.activity.ClientActivity;
import investwell.client.fragments.dividend.FragDividendReport;
import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * Created by Dev on 16/08/2021.
 */

public class FragFaqAdapter extends RecyclerView.Adapter<FragFaqAdapter.ViewHolder> {
    public ArrayList<String> mQuestionList;
    public ArrayList<String> mAnswerList;
    private Context mContext;

    public FragFaqAdapter(Context context, ArrayList<String> questionList,ArrayList<String> answerList) {
        mContext = context;
        mQuestionList = questionList;
        mAnswerList = answerList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_faq, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position);
    }

    @Override
    public int getItemCount() {
        return mQuestionList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvQuestion, tvAns;
        ImageView ivToggle;

        public ViewHolder(View view) {
            super(view);
            tvQuestion = view.findViewById(R.id.tv_ques);
            tvAns = view.findViewById(R.id.tv_ans);
            ivToggle = view.findViewById(R.id.iv_toggle);
        }

        public void setItem(final int position) {
            try {
                tvQuestion.setText(mQuestionList.get(position));
                tvAns.setText(mAnswerList.get(position));
                itemView.setContentDescription(tvQuestion.getText().toString() + "\nAnswer is collapsed");
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                      //  listener.onItemClick(position);
                        if (tvAns.getVisibility() == View.VISIBLE) {
                            ivToggle.setBackgroundResource(R.drawable.menu_down);
                            tvAns.setVisibility(View.GONE);
                            itemView.setContentDescription(tvQuestion.getText().toString() + "\nAnswer is collapsed");
                        } else {
                            ivToggle.setBackgroundResource(R.drawable.menu_up);
                            tvAns.setVisibility(View.VISIBLE);
                            itemView.setContentDescription(tvQuestion.getText().toString() + "\n"+tvAns.getText().toString() + "\nAnswer is expanded");
                        }
                    }
                });




            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


        }
    }
    public void updateList(List<String> list, List<String> ansList) {
        mQuestionList.clear();
        mAnswerList.clear();
        mQuestionList.addAll(list);
        mAnswerList.addAll(ansList);
        notifyDataSetChanged();
    }


}
