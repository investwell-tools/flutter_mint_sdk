package investwell.client.fragments.portfolioSummary;

import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mEndDate;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mStartingDate;
import static investwell.utils.UtilityKotlin.getOneDayEarlier;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPtSummaryMutualFundAdapterV2;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.KtorHelper;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class FragPtSummaryMutualFamilyHead extends BaseFragment implements View.OnClickListener {
    private TextView  mTvCurrent, mTvTotalGain, mTvOneDayChange;
    RequestQueue requestQueue;
    private FragPtSummaryMutualFundAdapterV2 mAdapterForClient;
    private RecyclerView mRecycleView;
    private ClientActivity mActivity;
    private AppSession mSession;
    private LinearLayout mCardView;
    private LinearLayout mLinerNoData, llFilterNoData, llFilter;
    private AppApplication mAppplication;

    private TextView tvPurchageValue, tvCagrLavel, tvPurchaseLevel, tvCagr;
    private ImageView ivGainLoss, ivGainInfo;
    private ShimmerFrameLayout mShimmerViewContainer;
    private View viewLineTotalGain;
    private ConstraintLayout relOverallGainLayout;
    private TextView tvOverallGainInPercentage,tvOverallGain;

    private ProgressBar pbLoaderOnArn;
    private String OverAllGainData = "";

    private View viewFilterIndicator, viewFilterIndicatorNoData;
    private ImageView ivFilter, ivFilterNoData;
    private BottomSheetPortfolioFilter bottomSheetPortfolioFilter;


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(@NotNull Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        boolean isFilterApplied = !mActivity.ptMFSelectedFilter.getFirst().equals("0") || !mActivity.ptMFSelectedFilter.getSecond();
        updateFilterIndicator(isFilterApplied);
        updateApiData();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_pt_summary_family_head, container, false);

        mCardView = view.findViewById(R.id.top_layout);
        tvPurchageValue = view.findViewById(R.id.tvPurchageValue);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvTotalGain = view.findViewById(R.id.tvTotalGain);
        mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
        mLinerNoData = view.findViewById(R.id.linerNoData);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        viewLineTotalGain = view.findViewById(R.id.viewLineTotalGain);
        relOverallGainLayout = view.findViewById(R.id.relOverallGainLayout);
        tvCagr = view.findViewById(R.id.tvCagr);

        tvOverallGainInPercentage = view.findViewById(R.id.tvOverallGainInPercentage);
        tvOverallGain = view.findViewById(R.id.tvOverallGain);

        pbLoaderOnArn = view.findViewById(R.id.pbLoaderOnArn);

        ivGainLoss = view.findViewById(R.id.ivGainLoss);
        mRecycleView = view.findViewById(R.id.recycleView);
        tvCagrLavel = view.findViewById(R.id.tvCagrLavel);
        ivGainInfo = view.findViewById(R.id.ivGainInfo);
        ivGainInfo.setOnClickListener(this);
        tvPurchaseLevel = view.findViewById(R.id.tvPurchaseLevel);
        viewFilterIndicator = view.findViewById(R.id.viewFilterIndicator);
        viewFilterIndicatorNoData = view.findViewById(R.id.viewFilterIndicatorNoData);
        ivFilter = view.findViewById(R.id.ivFilter);
        ivFilterNoData = view.findViewById(R.id.ivFilterNoData);

        llFilter = view.findViewById(R.id.llFilter);
        llFilterNoData = view.findViewById(R.id.llFilterNoData);
        llFilter.setOnClickListener(this);
        llFilterNoData.setOnClickListener(this);


        view.findViewById(R.id.iv_overall_gain_info).setOnClickListener(v ->
                mActivity.showGainInfoDialog(getString(R.string.dialog_overall_gain_info_dashboard)));

   /*    try{
           JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
           String lightColorShade = appConfigObject.optString("lightColorShade");
           //50% — 80, 40% — 66, 30% — 4D, 20% — 33, 10% — 1A
           String lightColorShade2 = "#4d"+lightColorShade.replace("#",""); //10 opacity
           int[] colors = {Color.parseColor(lightColorShade), Color.parseColor(lightColorShade2)};
           GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, colors);
           gd.setCornerRadius(30f);
           llTopCard.setBackground(gd);
       }catch (Exception e){
           System.out.println();

       }*/


        mRecycleView.setHasFixedSize(true);
        mRecycleView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
        mAdapterForClient = new FragPtSummaryMutualFundAdapterV2(mActivity, new ArrayList<>(), new FragPtSummaryMutualFundAdapterV2.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    JSONObject jsonObject = mAdapterForClient.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("data", jsonObject.toString());
                    bundle1.putString("isAnimation", "true");
                    bundle1.putBoolean("isHideToolBar", false);
                    mActivity.displayViewOther(32, bundle1);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }

            @Override
            public void onSchemeClick(int position) {

            }
        });
        mRecycleView.setAdapter(mAdapterForClient);


        if (mSession.getHasShowXirr()) {
            relOverallGainLayout.setVisibility(View.GONE);
            viewLineTotalGain.setVisibility(View.GONE);
        }else{
            try {
                JSONObject appConfigObject = new JSONObject();
                if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
                    appConfigObject = new JSONObject(mSession.getAppInfo());
                }
                if (appConfigObject != null) {
                    if ((!TextUtils.isEmpty(appConfigObject.optString("showInvestmentSummary")) && !appConfigObject.optString("showInvestmentSummary").equalsIgnoreCase("null")) && appConfigObject.optString("showInvestmentSummary").equalsIgnoreCase("1")) {
                        relOverallGainLayout.setVisibility(View.VISIBLE);
                        viewLineTotalGain.setVisibility(View.VISIBLE);
                        if (OverAllGainData.equals("")) {
                            getOverallGainApi();
                        } else {
                            setOverAllGain();
                        }

                    } else {
                        relOverallGainLayout.setVisibility(View.GONE);
                        viewLineTotalGain.setVisibility(View.GONE);
                    }
                }

            }catch (Exception e){

            }
        }

        SetData();
        return view;
    }

    private void showFilterBottomSheet() {
        boolean isCagr = !mSession.getHasShowXirr();
        bottomSheetPortfolioFilter = BottomSheetPortfolioFilter.newInstance(isCagr, true);
        bottomSheetPortfolioFilter.setClicked(true);
        bottomSheetPortfolioFilter.show(getChildFragmentManager(), "BottomSheetPortfolioFilter");
    }

    private void setOverAllGain() {
        try {
            JSONObject jsonObject = new JSONObject(OverAllGainData);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double oneDayChange = jsonObjectMain.optDouble("netGain");
                Utils.checkNegativeAndPositiveValue(tvOverallGain, oneDayChange, mActivity);

                UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectMain, "XIRR", "", "%", 2, true, tvOverallGainInPercentage,true);

            }

        } catch (Exception e) {

        }
    }


    private void updateApiData() {
        try {

            if (AppApplication.DASHBOARD_PORTFOLIO.isEmpty()) {
                getPortfolio();
            } else {
                SetData();
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}
else if (v.getId() == R.id.ivGainInfo) {
                showGainInfoDialog();
}
else if (v.getId() == R.id.llFilter) {
}
else if (v.getId() == R.id.llFilterNoData) {
                showFilterBottomSheet();
}

    }

    private void showGainInfoDialog() {

        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireContext(), R.style.CustomAlertDialog);

        builder.setTitle(getString(R.string.overall_gain));
        builder.setMessage(getString(R.string.dialog_gain_info_portfolio));
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        androidx.appcompat.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }

    @SuppressLint("AccessibilityFocus")
    private void SetData() {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        mCardView.setVisibility(View.VISIBLE);
        mLinerNoData.setVisibility(View.GONE);
        ArrayList<JSONObject> list = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(AppApplication.DASHBOARD_PORTFOLIO);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");


                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

                if (mAppplication.isDaysChange) {
                    double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                    String strOneDayChange = format.format(oneDayChange);
                    double changePercent = jsonObjectSummary.optDouble("changePercent");
                    String changePercentStr = String.format("%.2f", changePercent) + "%";
                    if (oneDayChange == 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.black_white));
                    } else if (oneDayChange > 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                    } else {
                     //   ivGainLoss.setImageResource(R.mipmap.home3_triangle_loss);
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                    }
                } else {
                    mTvOneDayChange.setVisibility(View.GONE);
                }
                if (mSession.getHasShowXirr()) {
                    tvCagrLavel.setText(getString(R.string.overall_gain));
                    ivGainInfo.setVisibility(View.VISIBLE);
                    if (mSession.getHideXirr().equals("0")) {
                        tvPurchaseLevel.setText(getString(R.string.XIRR));
                        UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-", "%", 2, false, tvPurchageValue);
                    } else {
                        tvPurchaseLevel.setVisibility(View.GONE);
                        tvPurchageValue.setVisibility(View.GONE);
                    }

                /*    double totalGain = jsonObjectSummary.optDouble("gain");
                    String gainValue = format.format(totalGain);
                    mTvTotalGain.setText(gainValue);*/
                    double gain = jsonObjectSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(mTvTotalGain, gain, mActivity);

                    RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                    params.addRule(RelativeLayout.ALIGN_PARENT_END);
                    params.setMargins(0, 0, 55, 0);
                    mTvTotalGain.setLayoutParams(params);
                } else {
                    tvPurchaseLevel.setText(getString(R.string.PurchaseCost));
                    tvCagrLavel.setText(getString(R.string.gain_cagr));
                    ivGainInfo.setVisibility(View.GONE);


                    double gain = jsonObjectSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(mTvTotalGain,gain,requireActivity());

                    double CAGR = jsonObjectSummary.optDouble("CAGR");
                    Utils.checkNegativeAndPositiveWithSign(tvCagr,CAGR,requireActivity());

                 /*
                   double cgrValue = jsonObjectSummary.optDouble("CAGR");
                    String data2 = String.format("%.2f", cgrValue) + "%";String gainValue = format.format(totalGain);
                    String finalValue = gainValue + " (" + data2 + ")";
                    mTvTotalGain.setText(finalValue);

                    if (totalGain > 0) {
                        mTvTotalGain.setTextColor(ContextCompat.getColor(requireActivity(), R.color.marketGreen));
                    } else {
                        mTvTotalGain.setTextColor(ContextCompat.getColor(requireActivity(), R.color.red));
                    }*/

                    double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvPurchageValue.setText(strPurchaseValue);
                }

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }

            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();

        } finally {
            if (list.size() > 0) {
                llFilterNoData.setVisibility(View.GONE);

                String levelNo = "";
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                } else {
                    levelNo = mSession.getLevelNo();
                }

                if (levelNo.equals("98")) {
                    mLinerNoData.setVisibility(View.GONE);
                    mRecycleView.setAdapter(mAdapterForClient);
                    mCardView.setVisibility(View.VISIBLE);
                    mAdapterForClient.updateList(list);
                } else {
                    JSONObject clientObject = list.get(0);
                    JSONArray jsonArray = clientObject.optJSONArray("data");
                    List<JSONObject> schemeList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        schemeList.add(jsonObject1);
                    }
                    mLinerNoData.setVisibility(View.GONE);
                }
                if (llFilter.isShown()) {
                    llFilter.performAccessibilityAction(
                            AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS,
                            null
                    );
                }



           /*     if (list.size() == 1) {
                    JSONObject clientObject = list.get(0);
                    JSONArray jsonArray = clientObject.optJSONArray("data");
                    List<JSONObject> schemeList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        schemeList.add(jsonObject1);
                    }
                    mLinerNoData.setVisibility(View.GONE);

                } else {
                    mLinerNoData.setVisibility(View.GONE);
                    mRecycleView.setAdapter(mAdapterForClient);
                    mCardView.setVisibility(View.VISIBLE);
                    mAdapterForClient.updateList(list);
                }*/

            } else {
                mLinerNoData.setVisibility(View.VISIBLE);
                llFilterNoData.setVisibility(View.VISIBLE);
                mRecycleView.setAdapter(mAdapterForClient);
                mAdapterForClient.updateList(list);
                mCardView.setVisibility(View.GONE);
            }
        }

    }
    public void updateFilterIndicator(Boolean isFilterApplied){
        if(isFilterApplied) {
            ivFilter.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_filled_icon));
            viewFilterIndicator.setVisibility(View.VISIBLE);
            ivFilterNoData.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_filled_icon));
            viewFilterIndicatorNoData.setVisibility(View.VISIBLE);
            llFilter.setContentDescription(getString(R.string.filter_button_filter_applied));
            llFilterNoData.setContentDescription(getString(R.string.filter_button_filter_applied));
        }
        else {
            ivFilter.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_unfilled_icon));
            viewFilterIndicator.setVisibility(View.GONE);
            ivFilterNoData.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_unfilled_icon));
            viewFilterIndicatorNoData.setVisibility(View.GONE);
            llFilter.setContentDescription(getString(R.string.filter_button_no_filter_applied));
            llFilterNoData.setContentDescription(getString(R.string.filter_button_no_filter_applied));
        }
    }

    private void getOverallGainApi() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            JSONArray jsonArrayTop = new JSONArray();
            JSONArray jsonArrayInside = new JSONArray();
            JSONObject jsonObjectTop = new JSONObject();
            JSONObject jsonObjectMf = new JSONObject();
            jsonObjectMf.put("name", "MF");
            jsonObjectMf.put("isRequired", true);
            jsonArrayInside.put(jsonObjectMf);
            jsonObjectTop.put("products", jsonArrayInside);
            jsonArrayTop.put(jsonObjectTop);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_DASHBOARD_XIRR
                    + "preferences=" + jsonArrayTop + "&investorUid=" + Utils.getSelectedUid(mSession)
                    + "&selectedUser=" + Utils.getSelectedUserObject(mSession) +
                    "&levelNo=" + Utils.getSelectedLevelNo(mSession);

            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }


        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {

                    @Override
                    public void onLoading(boolean isLoading){
                        if(isLoading){
                            pbLoaderOnArn.setVisibility(View.VISIBLE);

                            tvOverallGainInPercentage.setVisibility(View.GONE);
                            tvOverallGain.setVisibility(View.GONE);
                        }
                        else{
                            pbLoaderOnArn.setVisibility(View.GONE);

                            tvOverallGainInPercentage.setVisibility(View.VISIBLE);
                            tvOverallGain.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {
                        OverAllGainData = response;
                        setOverAllGain();
                    }
                }


        );

}

    public void getPortfolio() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        mCardView.setVisibility(View.GONE);
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();

        String url = "";
        try {
            @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            JSONArray jsonArray = new JSONArray();

            if (mStartingDate.equals(mEndDate)) {
                JSONObject dateObject = new JSONObject();
                Date date = getOneDayEarlier();
                if (date != null) {
                    dateObject.put("endDate", formatter.format(date));
                }
                jsonArray.put(dateObject);
            } else {
                JSONObject object = new JSONObject();
                object.put("startDate", mStartingDate);
                jsonArray.put(object);
                JSONObject object2 = new JSONObject();
                object2.put("endDate", mEndDate);
                jsonArray.put(object2);
            }


            JSONObject selectedObject = new JSONObject();
            selectedObject.put("selectedUser", Utils.getSelectedUserObject(mSession));
            jsonArray.put(selectedObject);

            JSONObject dataSourceObj = new JSONObject();
            dataSourceObj.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSourceObj);



            if (mSession.getHasShowXirr()) {
                JSONObject activeFolioObject = new JSONObject();
                activeFolioObject.put("activeFoliosOnly", mActivity.ptMFSelectedFilter.getSecond());
                jsonArray.put(activeFolioObject);

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.XIRR_PORTFOLIO_RETURN_NEW_API + "&filters=" + jsonArray.toString() + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) ;

            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CAGR_PORTFOLIO_RETURN_NEW_API + "filters=" + jsonArray.toString() + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {

            AppApplication.DASHBOARD_PORTFOLIO = response;
            SetData();
        }, volleyError -> {
            if (!isAdded())
                return;
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession,getMCurrentActivity());
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public class SortData implements Comparator {

        @Override
        public int compare(Object o1, Object o2) {
            String a = "0";
            String b = "0";
            a = ((JSONObject) o1).optString("dueDiligence");
            b = ((JSONObject) o2).optString("dueDiligence");

            int ia = 0, ib = 0;
            int nza = 0, nzb = 0;
            char ca, cb;
            int result;

            while (true) {
                // only count the number of zeroes leading the last number compared
                nza = nzb = 0;

                ca = charAt(a, ia);
                cb = charAt(b, ib);

                // skip over leading spaces or zeros
                while (Character.isSpaceChar(ca) || ca == '0') {
                    if (ca == '0') {
                        nza++;
                    } else {
                        // only count consecutive zeroes
                        nza = 0;
                    }

                    ca = charAt(a, ++ia);
                }

                while (Character.isSpaceChar(cb) || cb == '0') {
                    if (cb == '0') {
                        nzb++;
                    } else {
                        // only count consecutive zeroes
                        nzb = 0;
                    }

                    cb = charAt(b, ++ib);
                }

                // process run of digits
                if (Character.isDigit(ca) && Character.isDigit(cb)) {
                    if ((result = compareRight(a.substring(ia), b.substring(ib))) != 0) {
                        return result;
                    }
                }

                if (ca == 0 && cb == 0) {
                    // The strings compare the same. Perhaps the caller
                    // will want to call strcmp to break the tie.
                    return nza - nzb;
                }

                if (ca < cb) {
                    return -1;
                } else if (ca > cb) {
                    return +1;
                }

                ++ia;
                ++ib;
            }
        }

        private char charAt(String s, int i) {
            if (i >= s.length()) {
                return 0;
            } else {
                return s.charAt(i);
            }
        }

        int compareRight(String a, String b) {
            int bias = 0;
            int ia = 0;
            int ib = 0;

            // The longest run of digits wins. That aside, the greatest
            // value wins, but we can't know that it will until we've scanned
            // both numbers to know that they have the same magnitude, so we
            // remember it in BIAS.
            for (; ; ia++, ib++) {
                char ca = charAt(a, ia);
                char cb = charAt(b, ib);

                if (!Character.isDigit(ca) && !Character.isDigit(cb)) {
                    return bias;
                } else if (!Character.isDigit(ca)) {
                    return -1;
                } else if (!Character.isDigit(cb)) {
                    return +1;
                } else if (ca < cb) {
                    if (bias == 0) {
                        bias = -1;
                    }
                } else if (ca > cb) {
                    if (bias == 0) bias = +1;
                } else if (ca == 0 && cb == 0) {
                    return bias;
                }
            }
        }
    }
}
