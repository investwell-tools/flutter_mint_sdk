package investwell.common.piechart.utils;

import android.os.AsyncTask;

import com.iw.mint.sdk.BuildConfig;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class WebService extends AsyncTask<Void, Void, Void> {
    WebServiceInterface<String, String> mInterface;
    private JSONObject mParams;
    private String mRequestURL, mResult = "x";
    private int mRequestType;
    private String mToken;

    public WebService(String weburl, JSONObject parms, int type, String token) {
        this.mRequestURL = weburl;
        this.mParams = parms;
        mRequestType = type;
        mToken = token;
    }

    public void result(WebServiceInterface<String, String> myInterface) {
        this.mInterface = myInterface;
    }

    @Override
    protected Void doInBackground(Void... params) {
        try {
            if (mRequestType == 0) {// GET

                URL url = new URL(mRequestURL);
                HttpURLConnection cox = (HttpURLConnection) url.openConnection();

                cox.setRequestMethod("GET");
                cox.setRequestProperty("Content-Type", "application/json");
                cox.setRequestProperty("tenantName", "CBD");
                if (mToken.length() > 0) {
                    cox.setRequestProperty("mz_token", mToken);
                }
                cox.setRequestProperty("Cache-Control", "no-cache");
                cox.setUseCaches(false);
                String line;
                System.out.println(cox.getResponseMessage());
                BufferedReader reader = new BufferedReader(new InputStreamReader(cox.getInputStream()));
                StringBuilder sb = new StringBuilder();

                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }

                mResult = sb.toString();
                reader.close();
            } else if (mRequestType == 1) { // POST

                URL url = new URL(mRequestURL);
                HttpURLConnection cox = (HttpURLConnection) url.openConnection();
                cox.setDoOutput(true);
                cox.setDoInput(true);
                cox.setInstanceFollowRedirects(false);
                cox.setRequestMethod("POST");
                cox.setRequestProperty("Content-Type", "application/json");

                if (mToken.length() > 0) {
                    cox.setRequestProperty("token", mToken);
                }

                cox.setRequestProperty("tenantName", "CBD");
                cox.setRequestProperty("Cache-Control", "no-cache");
                cox.setUseCaches(false);

                OutputStreamWriter writer = new OutputStreamWriter(cox.getOutputStream());
                writer.write(mParams.toString());
                writer.flush();

                String line;
                System.out.println(cox.getResponseCode());

                BufferedReader reader = null;
                StringBuilder sb = null;
                if (cox.getResponseCode() == 200) {
                    reader = new BufferedReader(new InputStreamReader(cox.getInputStream()));
                    sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                } else {
                    reader = new BufferedReader(new InputStreamReader(cox.getErrorStream()));
                    sb = new StringBuilder();
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }

                }

                mResult = sb.toString();
                writer.close();
                reader.close();
            }

        } catch (Exception e) {
            mResult = e.toString();
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        // TODO Auto-generated method stub
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Void result) {
        // TODO Auto-generated method stub
        super.onPostExecute(result);
        mInterface.success(this.mResult);

    }

    public interface WebServiceInterface<E, R> {
        void success(E reslut);

        void error(R Error);
    }

}
