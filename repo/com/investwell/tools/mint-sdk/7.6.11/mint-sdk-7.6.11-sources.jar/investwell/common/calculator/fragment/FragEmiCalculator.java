package investwell.common.calculator.fragment;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.calculator.utils.AudioPlayer;
import investwell.common.calculator.utils.RoundKnobButton;
import investwell.common.calculator.utils.Singleton;
import investwell.common.calculator.utils.Utils;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;


public class FragEmiCalculator extends BaseFragment implements View.OnClickListener,
        View.OnTouchListener, RoundKnobButton.RoundKnobButtonListener,  ToolbarFragment.ToolbarCallback {
    private final long DELAY = 1000; // milliseconds
    double nFV = 0;
    private AppTextViewTitle tvHeaderTitle;

    double nYears = 0, nMonths = 0;
    double r, nRate, nRate1 = 0, p, z, i;
    float intpaid, principal;
    Singleton m_Inst = Singleton.getInstance();
    private EditText mEtYear, mEtAmount, mEtRate;
    private TextView mTvSipTitle, mTvFutureAmount, mTvTotalInvest, mTvInvestedTimes, mTvWealth;
    private int mAmountCount = 0, mAnnualAmountCount = 0, mYearCount = 0, mReturn = 01;
    private ProgressBar mProgressBar;
    private AudioPlayer audioPlayer;
    private ScrollView mScrollView;
    private RoundKnobButton mDailerInvest1, mDailerInvest2, mDailerInvest3;
    private ConstraintLayout mClCalcFooter;
    private Timer timer = new Timer();
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private RelativeLayout mRelToolbar;
    private ToolbarFragment fragToolBar;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private LinearLayout ll_calculator_header;
    private TextView mTvAppName,mTvWebsite,mTvEmail,mTvAddress,mTvPhone,mTvSlogan;
    private ImageView mIvAppLogo;

    private TextView mTvLoanAmountError, mTvLoanDurationError, mTvInterestError;
    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession= AppSession.getInstance(mBrokerActivity);
        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mMainActivity.setMainVisibility(this, null);
            mSession=AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_cal_emi, container, false);
        if (mBrokerActivity != null) {
            m_Inst.InitGUIFrame(mBrokerActivity);
        } else {
            m_Inst.InitGUIFrame(mMainActivity);
        }
        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        setUpToolBar();
        audioPlayer = new AudioPlayer();
        mRelToolbar = view.findViewById(R.id.relToolBar);
        mIvAppLogo=view.findViewById(R.id.iv_app_logo);
        mEtAmount = view.findViewById(R.id.edit1);
        mEtYear = view.findViewById(R.id.edit2);
        mEtRate = view.findViewById(R.id.edit3);

        mTvWealth = view.findViewById(R.id.textView8);
        mScrollView = view.findViewById(R.id.scrollView);
        mClCalcFooter = view.findViewById(R.id.cl_calc_footer);
        mClCalcFooter.setVisibility(View.GONE);

        mTvSipTitle = view.findViewById(R.id.textView1);
        mTvFutureAmount = view.findViewById(R.id.textView2);
        mTvTotalInvest = view.findViewById(R.id.textView4);
        mTvInvestedTimes = view.findViewById(R.id.textView6);

        mTvLoanAmountError = view.findViewById(R.id.tvLoanAmountError);
        mTvLoanDurationError = view.findViewById(R.id.tvLoanDurationError);
        mTvInterestError = view.findViewById(R.id.tvInterestError);



        mProgressBar = view.findViewById(R.id.progress_bar);
        ll_calculator_header = view.findViewById(R.id.ll_calculator_header);
        mTvSlogan = view.findViewById(R.id.tvSlogan);


    /*    TextView toolbar_title_left = view.findViewById(R.id.toolbar_title_left);
        toolbar_title_left.setText("EMI Calculator");*/
        mTvAddress = view.findViewById(R.id.tvAddress);
        mTvAppName = view.findViewById(R.id.tvApp_name);
        mTvPhone = view.findViewById(R.id.call);
        mTvWebsite = view.findViewById(R.id.web);
        mTvEmail = view.findViewById(R.id.email);
        setupFooter();




        mDailerInvest1 = view.findViewById(R.id.dialer1);
        mDailerInvest2 = view.findViewById(R.id.dialer2);
        mDailerInvest3 = view.findViewById(R.id.dialer3);
        if (mBrokerActivity != null) {
            mDailerInvest1.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        } else {
            mDailerInvest1.RoundKnobButton2(mMainActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mMainActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mMainActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));

        }


        mDailerInvest1.setOnTouchListener(this);
        mDailerInvest2.setOnTouchListener(this);
        mDailerInvest3.setOnTouchListener(this);

        mDailerInvest1.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
            }

            public void onRotate(final int percentage) {
                System.out.println("" + percentage);
                mEtAmount.post(new Runnable() {
                    public void run() {
                        long currentValue = Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""));
                        long updateValue = 0;
                        if (mAmountCount != percentage) {
                            if (percentage > mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue + 500);
                                } else {
                                    updateValue = (currentValue + 1000);
                                }
                            } else if (percentage < mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue - 500);
                                } else {
                                    updateValue = (currentValue - 1000);
                                }
                            }

                            mAmountCount = percentage;
                            if (updateValue < 50000) {
                                mEtAmount.setText("" + 50000);
                            } else {
                                mEtAmount.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mMainActivity);
                            calculateAmount();
                        }


                    }
                });
            }
        });

        mDailerInvest2.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtYear.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtYear.getText().toString());
                        int updateValue = 0;
                        if (mYearCount != percentage) {
                            if (percentage > mYearCount) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mYearCount) {
                                updateValue = (currentValue - 1);
                            }

                            mYearCount = percentage;
                            if (updateValue < 1)
                                mEtYear.setText("" + 1);
                            else if (updateValue > 50)
                                mEtYear.setText("" + 50);
                            else
                                mEtYear.setText("" + updateValue);

                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mMainActivity);
                            calculateAmount();
                        }

                    }
                });
            }
        });


        mDailerInvest3.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtRate.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtRate.getText().toString());
                        double updateValue = 0;
                        if (mReturn != percentage) {
                            if (percentage > mReturn) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mReturn) {
                                updateValue = (currentValue - 1);
                            }

                            mReturn = percentage;
                            if (updateValue < 1)
                                mEtRate.setText("" + 1.00);
                            else if (updateValue > 30)
                                mEtRate.setText("" + 30.00);
                            else
                                mEtRate.setText("" + updateValue);

                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mMainActivity);
                            calculateAmount();
                        }

                    }
                });
            }
        });


        mEtAmount.addTextChangedListener(new GenericTextWatcher(mEtAmount));
        mEtRate.addTextChangedListener(new GenericTextWatcher(mEtRate));
        mEtYear.addTextChangedListener(new GenericTextWatcher(mEtYear));

        calculateAmount();
        return view;
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.toolBar_title_emi_cal),
                    true, true, false, false,true,false,false);
            fragToolBar.setCallback(this);
        }
        tvHeaderTitle.setText(requireActivity().getResources().getString(R.string.toolBar_title_emi_cal));

    }

    @Override
    public void onStateChange(boolean newstate) {

    }

    @Override
    public void onRotate(int percentage) {

    }

    @Override
    public void onClick(View view) {


    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                saveFrameLayout();
}
else if (view.getId() == R.id.iv_refresh) {
                refreshView();
}

    }
    private void setupFooter() {
        setTintColorIfDark(requireActivity(), mIvAppLogo);
        if (getResources().getString(R.string.subdomain).equals("mint")) {
            if (mSession.getHasLoging()) {
                if(!TextUtils.isEmpty(  mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")){
                    Picasso.get().load( mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                    mIvAppLogo.setVisibility(View.VISIBLE);
                }else{
                    mIvAppLogo.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")){
                    mTvAddress.setText(mSession.getAddress());
                    mTvAddress.setVisibility(View.VISIBLE);
                }else{
                    mTvAddress.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")){
                    mTvWebsite.setText(mSession.getWebsite());
                    mTvWebsite.setVisibility(View.VISIBLE);
                }else{
                    mTvWebsite.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")){
                    mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                    mTvPhone.setVisibility(View.VISIBLE);
                }else{
                    mTvPhone.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")){
                    mTvEmail.setText(mSession.getUserEmail());
                    mTvEmail.setVisibility(View.VISIBLE);
                }else{
                    mTvEmail.setVisibility(View.GONE);
                } if(!TextUtils.isEmpty(  mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")){
                    mTvAppName.setText(mSession.getCompanyName());
                    mTvAppName.setVisibility(View.VISIBLE);
                }else{
                    mTvAppName.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                    mTvSlogan.setText(mSession.getSloganOnLogo());
                    mTvSlogan.setVisibility(View.VISIBLE);
                }else{
                    mTvSlogan.setVisibility(View.GONE);
                }
            } else {
                if(!TextUtils.isEmpty(  mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")){
                    Picasso.get().load( mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                }
                mTvAddress.setText(getResources().getString(R.string.locatetext));
                mTvWebsite.setText(getResources().getString(R.string.website));
                mTvPhone.setText(getResources().getString(R.string.image_phone));
                mTvEmail.setText(getResources().getString(R.string.support_email_address));
                mTvAppName.setText(getString(R.string.app_name));
                mTvSlogan.setText(mSession.getSloganOnLogo());

            }
        } else {
            mIvAppLogo.setVisibility(View.VISIBLE);
            int squareLogo =   UtilityKotlin.checkExistResources("app_logo_square","mipmap",requireContext());
            int circleLogo =   UtilityKotlin.checkExistResources("app_logo_round","mipmap",requireContext());
            if (squareLogo !=0) {
                mIvAppLogo.setImageResource(squareLogo);
            }else if (circleLogo !=0) {
                mIvAppLogo.setImageResource(circleLogo);
            }else{
                mIvAppLogo.setImageResource(R.mipmap.app_logo);
            }

            if(!TextUtils.isEmpty(  mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")){
                mTvAddress.setText(mSession.getAddress());
                mTvAddress.setVisibility(View.VISIBLE);
            }else{
                mTvAddress.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")){
                mTvWebsite.setText(mSession.getWebsite());
                mTvWebsite.setVisibility(View.VISIBLE);
            }else{
                mTvWebsite.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")){
                mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                mTvPhone.setVisibility(View.VISIBLE);
            }else{
                mTvPhone.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")){
                mTvEmail.setText(mSession.getUserEmail());
                mTvEmail.setVisibility(View.VISIBLE);
            }else{
                mTvEmail.setVisibility(View.GONE);
            } if(!TextUtils.isEmpty(  mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")){
                mTvAppName.setText(mSession.getCompanyName());
                mTvAppName.setVisibility(View.VISIBLE);
            }else{
                mTvAppName.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                mTvSlogan.setText(mSession.getSloganOnLogo());
                mTvSlogan.setVisibility(View.VISIBLE);
            }else{
                mTvSlogan.setVisibility(View.GONE);
            }

        }
    }
private void refreshView() {
        mDailerInvest1.setRotorPercentage(0);
        mDailerInvest2.setRotorPercentage(0);
        mDailerInvest3.setRotorPercentage(0);
        mEtAmount.setText("500000");
        mEtYear.setText("10");
        mEtRate.setText("10.00");
        calculateAmount();
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        hideKeyPad();
        String currentValue = "";
        int i1 = view.getId();
        if (i1 == R.id.dialer1) {
            currentValue = mEtAmount.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 50000)
                    mEtAmount.setText("" + 50000);
            } else {
                mEtAmount.setText("" + 50000);
            }
            desableScrollView(motionEvent);

        } else if (i1 == R.id.dialer2) {
            currentValue = mEtYear.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 1)
                    mEtYear.setText("" + 1);
                else if (value > 50)
                    mEtYear.setText("" + 50);

            } else {
                mEtYear.setText("" + 1);
            }

            desableScrollView(motionEvent);

        } else if (i1 == R.id.dialer3) {
            currentValue = mEtRate.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtRate.setText("" + 1.00);
                else if (value > 30)
                    mEtRate.setText("" + 30.00);
            } else {
                mEtRate.setText("" + 1.00);
            }
            desableScrollView(motionEvent);

        }
        return false;
    }

    private void desableScrollView(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            mScrollView.requestDisallowInterceptTouchEvent(true);

        else if (motionEvent.getAction() == MotionEvent.ACTION_UP)
            mScrollView.requestDisallowInterceptTouchEvent(false);

    }

    public void hideKeyPad() {
        if (mBrokerActivity != null) {
            InputMethodManager inputManager = (InputMethodManager) mBrokerActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mBrokerActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } else {
            InputMethodManager inputManager = (InputMethodManager) mMainActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mMainActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    private void delayCall() {
        timer.cancel();
        timer = new Timer();
        timer.schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        if (mBrokerActivity != null)
                            mBrokerActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });

                        else
                            mMainActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });
                    }
                },
                DELAY
        );
    }

    private void calculateAmount() {
        mTvLoanAmountError.setVisibility(View.GONE);
        mTvLoanDurationError.setVisibility(View.GONE);
        mTvInterestError.setVisibility(View.GONE);

        if (mEtAmount.getText().toString().replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
            mTvLoanAmountError.setVisibility(View.VISIBLE);
            mTvLoanAmountError.announceForAccessibility(getResources().getString(R.string.emi_cal_error_empty_loan));
            mTvLoanAmountError.setText(getResources().getString(R.string.emi_cal_error_empty_loan));
        } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 50000) {
            mTvLoanAmountError.setVisibility(View.VISIBLE);
            mTvLoanAmountError.announceForAccessibility(getResources().getString(R.string.emi_cal_error_minnimum_loan_amount));
            mTvLoanAmountError.setText(getResources().getString(R.string.emi_cal_error_minnimum_loan_amount));

        } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
            mTvLoanDurationError.setVisibility(View.VISIBLE);
            mTvLoanDurationError.announceForAccessibility(getResources().getString(R.string.emi_cal_error_empty_loan_duration));
            mTvLoanDurationError.setText(getResources().getString(R.string.emi_cal_error_empty_loan_duration));
        } else if (Integer.parseInt(mEtYear.getText().toString()) > 50) {
            mTvLoanDurationError.setVisibility(View.VISIBLE);
            mTvLoanDurationError.announceForAccessibility(getResources().getString(R.string.emi_cal_error_invalid_loan_duration));
            mTvLoanDurationError.setText(getResources().getString(R.string.emi_cal_error_invalid_loan_duration));
        } else if (mEtRate.getText().toString().equals("") || mEtRate.getText().toString().equals("0")|| mEtRate.getText().toString().equals(".")) {
            mTvInterestError.setVisibility(View.VISIBLE);
            mTvInterestError.announceForAccessibility(getResources().getString(R.string.emi_cal_error_empty_roi));
            mTvInterestError.setText(getResources().getString(R.string.emi_cal_error_empty_roi));
        } else if (Double.parseDouble(mEtRate.getText().toString()) > 30) {
            mTvInterestError.setVisibility(View.VISIBLE);
            mTvInterestError.announceForAccessibility(getResources().getString(R.string.emi_cal_error_max_roi));
            mTvInterestError.setText(getResources().getString(R.string.emi_cal_error_max_roi));
        } else {
            String rawValue = mEtAmount.getText().toString().replaceAll(",", "").replaceAll(",", "");

            if (mBrokerActivity != null) {
                mBrokerActivity.convertIntoCurrencyFormat(rawValue, mEtAmount);
            }else{
                mMainActivity.convertIntoCurrencyFormat(rawValue, mEtAmount);
            }
            try {


                nFV = Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", ""));
                nYears = Double.parseDouble(mEtYear.getText().toString());
                nMonths = nYears * 12;
                nRate1 = Double.parseDouble(mEtRate.getText().toString());
                nRate = nRate1 / 1200;
                intpaid = Math.round((((nFV - p * nMonths)) / (p * nMonths)) * 100);
                principal = Math.round((nFV / p * nMonths) * 100);

                z = 1;
                for (i = 1; i <= nMonths; i++) {
                    z = z * (1 + nRate);
                }
                p = nFV * nRate * (z / (z - 1));

                Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                String strAmount = format.format(nFV);
                String[] resultAmount = strAmount.split("\\.", 0);

                mTvSipTitle.setText(getString(R.string.loan_amount) +" " + resultAmount[0] + getString(R.string.txt_for) + ((int) nYears) + getString(R.string.years_and_rate) +  nRate1 + getString(R.string.yearly_your_estimated_emi_would_be));
                mTvTotalInvest.setText(resultAmount[0]);

                long value1 = Math.round(p);
                String str = format.format(value1);
                String[] result = str.split("\\.", 0);
                mTvFutureAmount.setText(result[0]);

                Double totalAmountPay = (nFV + ((p * nMonths) - nFV));
                long value2 = Math.round(totalAmountPay);
                String totalAmountPayable = format.format(value2);
                String[] invesRresult = totalAmountPayable.split("\\.", 0);

                mTvInvestedTimes.setText(invesRresult[0]);

                Double totalIntrest = ((p * nMonths) - nFV);
                long value3 = Math.round(totalIntrest);
                String strProfit = format.format(value3);
                String[] arrayProfit = strProfit.split("\\.", 0);
                mTvWealth.setText(arrayProfit[0]);


                int percentage = (int) ((nFV * 100) / totalAmountPay);
                mProgressBar.setProgress(percentage);
                double times = (totalIntrest / nFV);
              /*  if (Double.isNaN(times)) {
                    mTvInvestedTimes.setText("0 times");
                } else {
                    String strTimes = String.format("%.2f", times);
                    mTvInvestedTimes.setText("" + strTimes + " times");
                }*/


                String announcement =
                        mTvSipTitle.getText().toString() +". " + mTvFutureAmount.getText().toString() + ". "
                                + getString(R.string.emi_cal_principal_amnt) + ". " + mTvTotalInvest.getText().toString() +". "
                                + getString(R.string.emi_cal_interest_amnt) + ". " + mTvWealth.getText().toString() +". "
                                + getString(R.string.emi_cal_total_amnt_pay) + ". " + mTvInvestedTimes.getText().toString() +". ";

                mTvFutureAmount.post(() ->
                        mTvFutureAmount.announceForAccessibility(announcement)
                );
            } catch (Exception e) {

            }

        }

    }

    public void saveFrameLayout() {
        mClCalcFooter.setVisibility(View.VISIBLE);
        ll_calculator_header.setVisibility(View.VISIBLE);
        loadUpdatedView();
    }

    private void loadUpdatedView() {
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          createImage();
                                      }
                                  },

                100);
    }

    private void createImage() {
        if (mBrokerActivity != null) {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mBrokerActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        } else {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mMainActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        }
    }


    private Bitmap getBitmapFromView(View view, int height, int width) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return bitmap;
    }

    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {
            if (mBrokerActivity!=null){
                if (mBrokerActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                }
            }else{
                if (mMainActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mMainActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mMainActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                }
            }



        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

    }


}
