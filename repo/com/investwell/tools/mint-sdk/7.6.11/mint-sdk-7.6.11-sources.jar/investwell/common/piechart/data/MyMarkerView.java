
package investwell.common.piechart.data;

import android.annotation.SuppressLint;
import android.content.Context;
import android.widget.TextView;

import investwell.charts.mikephil.charting.components.MarkerView;
import investwell.charts.mikephil.charting.data.CandleEntry;
import investwell.charts.mikephil.charting.data.Entry;
import investwell.charts.mikephil.charting.highlight.Highlight;
import investwell.charts.mikephil.charting.utils.MPPointF;
import com.iw.mint.sdk.R;
import investwell.activity.AppApplication;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Custom implementation of the MarkerView.
 *
 * @author Philipp Jahoda
 */
@SuppressLint("ViewConstructor")
public class MyMarkerView extends MarkerView {

    private final TextView tvDate ,tvInvestment, tvCurrent;
    String mType = "";

    public MyMarkerView(Context context, int layoutResource, String type) {
        super(context, layoutResource);

        tvDate = findViewById(R.id.tvDate);
        tvCurrent = findViewById(R.id.tvCurrent);
        tvInvestment = findViewById(R.id.tvInvestment);
        mType = type;
    }

    // runs every time the MarkerView is redrawn, can be used to update the
    // content (user-interface)
    @Override
    public void refreshContent(Entry e, Highlight highlight) {

        try {
            if (e instanceof CandleEntry) {

                CandleEntry ce = (CandleEntry) e;

                //tvContent.setText(Utils.formatNumber(ce.getHigh(), 0, true));
            } else {
                int xValue = (int) (Math.round(e.getX()));
                ;
                Entry investment = AppApplication.GInvestmentList.get(xValue);
                Entry currentValue = AppApplication.GCurrentValueList.get(xValue);
                JSONObject jsonObject = AppApplication.dataList.get(xValue);

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                tvCurrent.setText(getResources().getString(R.string.current)+": "+format.format(currentValue.getY()));
                tvInvestment.setText(getResources().getString(R.string.Net_Investment)+": " + format.format(investment.getY()));
                SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
                SimpleDateFormat outPutDateFormat = new SimpleDateFormat("dd MMM yyyy");

                if (mType.equalsIgnoreCase("thisMonth")) {
            /*    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd MMM yyyy");
                Calendar calendar = Calendar.getInstance();
                Date todayDate = calendar.getTime();
                String today = simpleDateFormat.format(todayDate);

                calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
                Date oneMonthAgoDate = calendar.getTime();
                String firstDayOfMonth = simpleDateFormat.format(oneMonthAgoDate);
*/

/*
                NumberFormat format = new DecimalFormat("00");
                String twoDigit = format.format(xValue);
                tvDate.setText("Date: "+twoDigit+" "+today[1]+" "+today[2]);*/
                    Date date = inputDateFormat.parse(jsonObject.optString("date"));
                    String outPutDate = outPutDateFormat.format(date);
                    tvDate.setText(getResources().getString(R.string.date)+": " + outPutDate);

                } else if (mType.equalsIgnoreCase("lastOneMonth")) {
                    Date date = inputDateFormat.parse(jsonObject.optString("date"));
                    String outPutDate = outPutDateFormat.format(date);
                    tvDate.setText(getResources().getString(R.string.date)+": " + outPutDate);
                } else if (mType.equalsIgnoreCase("currentFY")) {
                    Date date = inputDateFormat.parse(jsonObject.optString("date"));
                    String outPutDate = outPutDateFormat.format(date);
                    tvDate.setText(getResources().getString(R.string.date)+": " + outPutDate);
                } else if (mType.equalsIgnoreCase("lastFY")) {
                    Date date = inputDateFormat.parse(jsonObject.optString("date"));
                    String outPutDate = outPutDateFormat.format(date);
                    tvDate.setText(getResources().getString(R.string.date)+": " + outPutDate);
                } else if (mType.equalsIgnoreCase("lastOneYear")) {
                    Date date = inputDateFormat.parse(jsonObject.optString("date"));
                    String outPutDate = outPutDateFormat.format(date);
                    tvDate.setText(getResources().getString(R.string.date)+": " + outPutDate);
                } else if (mType.equalsIgnoreCase("sinceInception")) {
                    Date date = inputDateFormat.parse(jsonObject.optString("date"));
                    String outPutDate = outPutDateFormat.format(date);
                    tvDate.setText(getResources().getString(R.string.date)+": " + outPutDate);
                }

                //tvContent.setText(Utils.formatNumber(e.getY(), 0, true));
            }

            //Entry, x: 13.0 y: 2452628.8
//Highlight, x: 13.0, y: 2452628.8, dataSetIndex: 1, stackIndex (only stacked barentry): -1
        }catch (Exception ea){

        }
        super.refreshContent(e, highlight);
    }

    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2), -getHeight());
    }
}
