package investwell.common.onboarding.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.Utils;

public class SelectOnBoardUser extends RecyclerView.Adapter<SelectOnBoardUser.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;

    public SelectOnBoardUser(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public SelectOnBoardUser.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_onboard_users, viewGroup, false);
        return new SelectOnBoardUser.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SelectOnBoardUser.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPan,tvEmail;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tv_user_name);
            tvEmail = view.findViewById(R.id.tv_user_mail);
            tvPan = view.findViewById(R.id.tv_pan);
        }


        public void setItem(final int position, final SelectOnBoardUser.OnItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);
                tvName.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                tvPan.setText(Utils.setFirstLetterCapital("PAN: "+jsonObject.optString("firstHolderPAN")));
                tvEmail.setText(jsonObject.optString("email"));


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });

        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
