package investwell.client.adapter;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import investwell.activity.PaymentActivity;
import investwell.client.fragments.insurance.FragLifeInsurance;
import investwell.utils.AppSession;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FolioLefeInsuranceAdapter extends RecyclerView.Adapter<FolioLefeInsuranceAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private AppSession mSession;
    private FolioLefeInsuranceAdapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private String mType = "";
    FragLifeInsurance fragLifeInsurance;

    public FolioLefeInsuranceAdapter(Context context, AppSession session, FragLifeInsurance fragLifeInsuranceIntanse, String type, ArrayList<JSONObject> list, FolioLefeInsuranceAdapter.OnItemClickListener listener) {
        mContext = context;
        mSession = session;
        mDataList = list;
        this.listener = listener;
        mType = type;
        fragLifeInsurance =fragLifeInsuranceIntanse;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_life_insurance_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onUpload(JSONObject object);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvSchemeName, tvIssueDate, tvPolicy, tvRenewDate, tvPremium,
                tvSum, tvStatus, tvDownloadFile, tvMaturityDate, tvPremiumPayTerm,tv_sum_assured,tvNseBse;
        private View viewLine;
        LinearLayout llForLifeInsurance,linerPremium ,llPayTerm, llStatus;
        MaterialButton tvButtonPay;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvSchemeName = view.findViewById(R.id.tvSchemeName);
            tvIssueDate = view.findViewById(R.id.tvIssueDate);
            tvPolicy = view.findViewById(R.id.tvPolicy);
            tvRenewDate = view.findViewById(R.id.tvRenewDate);
            tvPremium = view.findViewById(R.id.tvPremium);
            tvSum = view.findViewById(R.id.tvSum);
            tvStatus = view.findViewById(R.id.tvStatus);
            tvDownloadFile = view.findViewById(R.id.tvDownloadFile);
            tvMaturityDate = view.findViewById(R.id.tvMaturityDate);
            tvPremiumPayTerm = view.findViewById(R.id.tvPremiumPay);
            tvButtonPay = view.findViewById(R.id.tvButtonPay);
            viewLine = view.findViewById(R.id.viewLine);
            llForLifeInsurance = view.findViewById(R.id.llForLifeInsurance);
            linerPremium = view.findViewById(R.id.linerPremium);
            llPayTerm = view.findViewById(R.id.llPayTerm);
            tv_sum_assured = view.findViewById(R.id.tv_sum_assured);
            tvNseBse =view.findViewById(R.id.tvNseBse);
            llStatus =view.findViewById(R.id.llStatus);


        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                // Life--> Renual date --> Next Premium Date
                // General--> sum assured-> Sum Insured
                if (mType.equalsIgnoreCase("L")){
                    tvNseBse.setText(R.string.txt_next_premium_date);
                }else {
                    llStatus.setVisibility(View.INVISIBLE);
                    tv_sum_assured.setText(R.string.txt_sum_insured);
                }
                final JSONObject jsonObject = mDataList.get(position);

                tvName.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                tvSchemeName.setText(Utils.setFirstLetterCapital(jsonObject.optString("policyName")));
                tvPolicy.setText(jsonObject.optString("policyNumber"));
                tvIssueDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("issuingDate")));

                tvRenewDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("renewalDate")));

              /*  int daysCount = 0;
                if (mType.equalsIgnoreCase("g")){
                     daysCount =Utils.daysCount(jsonObject.optString("renewalDate"));
                }else{
                    tvRenewDate.setText(Utils.formatedDate2(jsonObject.optString("renewalDate")));
                    daysCount =Utils.daysCount(jsonObject.optString("renewalDate"));
                }
                if (daysCount>=0 && daysCount<=30){
                    tvRenewDate.setTextColor(ContextCompat.getColor(mContext, R.color.red_for_dashboard));
                    Animation anim = new AlphaAnimation(0.0f, 1.0f);
                    anim.setDuration(500); //You can manage the blinking time with this parameter
                    anim.setStartOffset(20);
                    anim.setRepeatMode(Animation.REVERSE);
                    anim.setRepeatCount(Animation.INFINITE);
                    tvRenewDate.startAnimation(anim);
                }else{
                    tvRenewDate.setTextColor(ContextCompat.getColor(mContext, R.color.black));
                }*/


                double sumAssured = jsonObject.optDouble("sumAssured");
                String strsumAssured = format.format(sumAssured);
                tvSum.setText(strsumAssured);

                double premiumAmount = jsonObject.optDouble("premiumAmount");
                String strpremiumAmount = format.format(premiumAmount);
                tvPremium.setText(strpremiumAmount);

                tvStatus.setText(jsonObject.optString("status"));
                viewLine.setVisibility(View.GONE);
                llForLifeInsurance.setVisibility(View.VISIBLE);

                if (mType.equals("L") || mType.equalsIgnoreCase("life")) {
                    tvMaturityDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("maturityDate")));
                    tvPremiumPayTerm.setText(jsonObject.optString("premiumPayTerm"));
                }else{
                    llPayTerm.setVisibility(View.INVISIBLE);
                    linerPremium.setVisibility(View.INVISIBLE);
                }

                String attachment = jsonObject.optString("attachment");
                if (!attachment.equals("null") && attachment.length()>0){
                    tvDownloadFile.setText("Download");
                    Drawable top = mContext.getResources().getDrawable(R.mipmap.download);
                    tvDownloadFile.setCompoundDrawablesWithIntrinsicBounds(null, top , null, null);
                }else{
                    tvDownloadFile.setText("Upload");
                    Drawable top = mContext.getResources().getDrawable(R.mipmap.upload);
                    tvDownloadFile.setCompoundDrawablesWithIntrinsicBounds(null, top , null, null);
                }


                //upload = add/edit
                //download = export
                if(Objects.equals(mSession.getLoginType(), "broker") && mSession.getClientObject().isEmpty()) // broker
                {
                    boolean isAddEnabledInsurance = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature7", Permissions.ADD);
                    boolean isExportEnabledInsurance = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature7", Permissions.EXPORT);
                    if(tvDownloadFile.getText() == "Upload" && !isAddEnabledInsurance)
                        tvDownloadFile.setVisibility(View.GONE);
                    if(tvDownloadFile.getText() == "Download" && !isExportEnabledInsurance)
                        tvDownloadFile.setVisibility(View.GONE);
                }

                tvDownloadFile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!attachment.equals("null") && attachment.length()>0) {
                            fragLifeInsurance.downloadFile2(attachment, jsonObject.optString("appid"));
                        }else{
//                            Intent intent = new Intent(mContext, InsuranceUploadActivity.class);
//                            intent.putExtra("object", jsonObject.toString());
//                            mContext.startActivity(intent);
                            listener.onUpload(jsonObject);
                        }
                    }
                });

                String url = jsonObject.optString("payLink");
                if (url.equalsIgnoreCase("null") || url.equals("")) {
                    if (mType.equals("L") || mType.equalsIgnoreCase("life")) {
                        tvButtonPay.setVisibility(View.GONE);
                        llForLifeInsurance.setVisibility(View.VISIBLE);
                    }else{
                        tvButtonPay.setVisibility(View.GONE);
                        llForLifeInsurance.setVisibility(View.GONE);
                    }

                } else {
                    llForLifeInsurance.setVisibility(View.VISIBLE);
                    tvButtonPay.setVisibility(View.VISIBLE);
                }
                tvButtonPay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(mContext, PaymentActivity.class);
                        intent.putExtra("raw_data", url);
                        intent.putExtra("type", "payNow");
                        mContext.startActivity(intent);
                    }
                });


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });



        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    @SuppressLint("WrongConstant")
    private void setIncompleteCardAnimation(View view ) {
        ObjectAnimator anim = ObjectAnimator.ofInt(view.findViewById(R.id.ll_profile_not_complete), "backgroundColor", Color.WHITE, Color.RED,
                Color.WHITE);
        anim.setDuration(3000);
        anim.setEvaluator(new ArgbEvaluator());
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        anim.start();

    }

}
