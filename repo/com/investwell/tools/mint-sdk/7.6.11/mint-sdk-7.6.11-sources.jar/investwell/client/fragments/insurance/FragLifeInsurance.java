package investwell.client.fragments.insurance;


import static android.app.Activity.RESULT_OK;
import static android.os.Build.VERSION.SDK_INT;

import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.Utils.hideKeyboard;
import static investwell.utils.Utils.isEmptyOrNull;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FolioLefeInsuranceAdapter;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.volleyCustom.VolleyMultipartRequest;
import android.os.Handler;
import android.os.Looper;



public class FragLifeInsurance extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    public static String values;
    private RequestQueue requestQueue;
    private AppApplication mAppplication;
    private FolioLefeInsuranceAdapter mAdapter;
    private ShimmerFrameLayout mShimmerViewContainer;
    private RecyclerView recyclerView;
    //    private CustomProgressBar progressBar;
    private boolean loading = false;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentPageNo = 0;
    private int mFetchListsize = 10;
    private Timer timer = new Timer();
    private final long DELAY = 1000; // milliseconds
    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;
    private String mType = "L";

    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;

    private Animation slideUpAnimation, slideDownAnimation;
    private List<JSONObject> mMemberTypesList;
    private Spinner mMemberSpinner, mSpUserType;
    private int mSelectedUserTypePosition = 0, mSelectedTransType;
    private LinearLayout mLinerUserType, mLinFilterPart;
    private FloatingActionButton mFilterIcon;
    private boolean isClickedApply = false;
    private RelativeLayout mRelFilterMain;
    private LinearLayout mLinerNoData;
    private String mFileName = "", mAppId = "";
    private Uri mFileUri =null;
    private JSONObject mOJbject = null;
    private int requestCode = 0;

    private AutoCompleteTextView acSelectMember;
    private TextInputLayout tilSelectMember;
    private ProgressBar pbLoadMember;
    private HashMap<String,JSONObject> mMemberJsonList = new HashMap<>();
    private ArrayList<String> mMemberNameList = new ArrayList<>();
    private Button btnApply;
    private ConstraintLayout clSelectMember;
    private JSONObject mSelectedMember = new JSONObject();


    @Override
    public void onResume() {
        super.onResume();
     /*   if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

    @Override
    public void onStop() {
        super.onStop();

        try {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            IBinder binder = getActivity().getCurrentFocus().getWindowToken();
            if (imm.isAcceptingText() && binder != null) {
                imm.hideSoftInputFromWindow(binder, 0);
            }
        } catch (Exception e) {

        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_life_insurance, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle bundle = getArguments();
        if (bundle != null)
            mType = bundle.getString("type");

        mLinerNoData = view.findViewById(R.id.linerNoData);
        mMemberSpinner = view.findViewById(R.id.member_spinner);
        mSpUserType = view.findViewById(R.id.spUserType);
        mLinerUserType = view.findViewById(R.id.linerUserType);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mFilterIcon = view.findViewById(R.id.filters);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mFilterIcon.setOnClickListener(this);
        slideUpAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_down);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        btnApply = view.findViewById(R.id.apply_btn);
        btnApply.setOnClickListener(this);
        acSelectMember = view.findViewById(R.id.acSelectMember);
        tilSelectMember = view.findViewById(R.id.tilSelectMember);
        pbLoadMember = view.findViewById(R.id.pbLoadMember);
        clSelectMember = view.findViewById(R.id.clSelectMember);


        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);


        recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setNestedScrollingEnabled(true);

        recyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new FolioLefeInsuranceAdapter(getActivity(), mSession,this, mType, new ArrayList<JSONObject>(), new FolioLefeInsuranceAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                  /*  JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(15, bundle1);*/
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }

            @Override
            public void onUpload(JSONObject mOJ) {
                // upload insurance
                mOJbject =mOJ;
                checkUploadFile();
            }
        });
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 100;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getInsurance(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);
                mFilterIcon.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }


            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            if (mSession.getClientObject().isEmpty()) {
                mFilterIcon.setVisibility(View.VISIBLE);
                mLinerUserType.setVisibility(View.VISIBLE);
                clSelectMember.setVisibility(View.VISIBLE);
                setSpinnerMemberType();
            } else {
                mFilterIcon.setVisibility(View.GONE);
                mLinerUserType.setVisibility(View.GONE);
                clSelectMember.setVisibility(View.VISIBLE);
                getAllMembers("client");
            }
        } else {
            mFilterIcon.setVisibility(View.GONE);
        }


        getInsurance(1);

    }

    private void checkUploadFile() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestCode = 22;
                setPermission();
                return;
            }
        }
        openFileChooser();
    }

    private void uploadSignatureBitmapApi(String fileName , Uri uri) {
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        if (uri !=null){
            InputStream iStream = null;
            try {
                iStream = getActivity().getContentResolver().openInputStream(uri);
                final byte[] inputData = getBytes(iStream);

                String url = "https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.UPLOAD_PROFILE_PHOTO;
                VolleyMultipartRequest volleyMultipartRequest =  new VolleyMultipartRequest(Request.Method.POST, url,response ->
                {
                    UtilityKotlin.setRefreshKey(mSession);
                    try {
                        if (mBar != null)
                            mBar.dismiss();
                        String json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                        JSONObject obj = new JSONObject(json);
                        UtilityKotlin.onSnackSuccess(mFilterIcon, obj.optString("message"), getActivity());
                        if (obj.optInt("status") == 0) {
                            JSONObject jsonObject1 = obj.optJSONObject("result");

                            if (jsonObject1 != null) {
                                callSubmiInsuranceName(jsonObject1.optString("filename"));
                            } else {
                                UtilityKotlin.onSnackSuccess(mFilterIcon, obj.optString("message"), getActivity());
                            }
                        } else {
                            UtilityKotlin.onSnackFailure(mFilterIcon, obj.optString("message"), getActivity());
                        }
                    }catch (UnsupportedEncodingException | JSONException  e){
                        if (BuildConfig.DEBUG)
                           e.printStackTrace();
                        if (mBar != null)
                            mBar.dismiss();
                    }
                },error -> {
                    if (mBar != null)
                        mBar.dismiss();
                    UtilityKotlin.onSnackFailure(mFilterIcon, error.getMessage().toString(), getActivity());
                }){

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("fileHandle", "1");
                        params.put("appid",mOJbject.optString("appid"));
                        params.put("isExternal","1");
                        params.put("selectedUser",Utils.getSelectedUserObject(mSession).toString());
                        return params;
                    }

                    @Override
                    protected Map<String, DataPart> getByteData() throws AuthFailureError {
                        Map<String, DataPart> params = new HashMap<>();
                        params.put("file", new DataPart(fileName, inputData));
                        return params;
                    }

                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
                    }

                    @Override
                    public Response<NetworkResponse> parseNetworkResponse(NetworkResponse response) {
                        UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                        return super.parseNetworkResponse(response);
                    }
                };
                volleyMultipartRequest.setRetryPolicy(new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 50000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 2;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {
                        int statusCode = error.networkResponse.statusCode;
                        if (statusCode == 401) {
                            new AppApplication().showCommonDailog(
                                    getActivity(),
                                    getString(R.string.txt_session_expired),
                                    getString(R.string.txt_please_login_again_for_continue),
                                    "sessionExpired"
                            );
                        }
                    }
                });
                Volley.newRequestQueue(getActivity()).add(volleyMultipartRequest);

            }catch ( Exception e) {
//                progressBar.dialog.dismiss()
            }

        }

    }

    //Submit Documents BSE
    private void callSubmiInsuranceName(String fileName) {
//        progressBar.show(this, "Please wait...", R.drawable.ic_form_submit)
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        try {
            String url = "";
            JSONObject jsonObject= null;
            jsonObject= new JSONObject();
            if ( mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
                url = "https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.UPLOAD_INSURANCE_IMAGE_BROKER;
                jsonObject.put("id", mOJbject.optString("id"));
                jsonObject.put("attachment", fileName);
                jsonObject.put("isExternal","1");

            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.UPLOAD_INSURANCE_IMAGE_CLIENT;
                jsonObject.put("id", mOJbject.optString("id"));
                jsonObject.put("attachment", fileName);
                jsonObject.put("isExternal","1");
                jsonObject.put("selectedUser", Utils.getSelectedUserObject(mSession));
            }

            try {
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject, response -> {
                    try {
                        UtilityKotlin.setRefreshKey(mSession);
                        if (mBar != null)
                            mBar.dismiss();
                        if (response.optInt("status")==0){
                            UtilityKotlin.onSnackSuccess(mFilterIcon, response.optString("message"), getActivity());
                        }
                    }catch (Exception e){
                        if (BuildConfig.DEBUG)
                          e.printStackTrace();
                        if (mBar != null)
                            mBar.dismiss();
                    }

                },volleyError -> {
                    if (!isAdded())
                        return;
                    if (mBar != null)
                        mBar.dismiss();
                    UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
                }){
                    @Override
                    public Map<String, String> getHeaders() {
                        return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
                    }

                    @Override
                    public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                        UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                        return super.parseNetworkResponse(response);
                    }
                };

                jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 50000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 2;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {
                        int statusCode = error.networkResponse.statusCode;
                        if (statusCode == 401) {
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                        }
                    }
                });

                RequestQueue mRequestQueue = Volley.newRequestQueue(getActivity(), new HurlStack());
                jsonObjectRequest.setShouldCache(false);
                mRequestQueue.add(jsonObjectRequest);
            } catch ( Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }catch (JSONException e){
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.filters) {
                // mActivity.mCvTabBarBottom.setVisibility(View.GONE);
                mFilterIcon.setVisibility(View.GONE);
                mRelFilterMain.setVisibility(View.VISIBLE);
                mLinFilterPart.startAnimation(slideUpAnimation);
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                // filterValidation();
                if(!acSelectMember.getText().toString().equals(getString(R.string.txt_all)) && mSelectedMember.length() == 0){
                    Toast.makeText(requireContext(),"Please Select a valid Member",Toast.LENGTH_SHORT).show();
                }
                else {
                    isClickedApply = true;
                    mLinFilterPart.startAnimation(slideDownAnimation);
                    new Handler().postDelayed(() -> {
                        getInsurance(1);
                    }, 500);
                }
}
    }


    private void setSpinnerMemberType() {
        try {
            mMemberTypesList = new ArrayList<>();
            List<String> listMemType = new ArrayList<>();

            JSONArray jsonArray = new JSONArray(mSession.getLowerReportingLevels());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.optJSONObject(i);
                mMemberTypesList.add(jsonObject);
                listMemType.add(jsonObject.optString("levelName"));
            }


            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMemType);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpUserType.setAdapter(adapter);
            mSpUserType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedUserTypePosition = position;
                    getAllMembers("broker");
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void setUpSelectMember(ArrayList<String> listMem) {
        try {
            listMem.add(0,getString(R.string.txt_all));
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), R.layout.spinner_dropdown, listMem);
            acSelectMember.setAdapter(adapter);
            acSelectMember.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void afterTextChanged(Editable s) {
                    mSelectedMember = new JSONObject();
                }
            });

            acSelectMember.setText(getString(R.string.txt_all), false);
            mSelectedMember = new JSONObject();
            acSelectMember.setOnItemClickListener((adapterView, view, i, l) -> {
                String item = adapterView.getItemAtPosition(i).toString();
                hideKeyboard(requireActivity());
                 if (!item.equals(getString(R.string.txt_all))){
                     mSelectedMember = mMemberJsonList.get(item);
                    } else{
                     mSelectedMember =  new JSONObject();
                    }

                if (listMem.size() >= 10) {
                    hideKeyboard(requireActivity());
                    acSelectMember.clearFocus();
                }
            });
        }
        catch (Exception e){

        }
    }

    private void getAllMembers(String type) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        String levelNo = "";
        try {
            https:
//demo.investwell.app/webapi/auth/getLevelUsers?levelNo=
            // 98&componentForLoader={"componentName":"getLevelUser"}&selectedUser={}


            if (type.equals("broker")) {
                JSONObject jsonObject = mMemberTypesList.get(mSelectedUserTypePosition);
                levelNo = jsonObject.optString("levelNo");

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_MEMBERS + "levelNo=" + levelNo +
                        "&investorUid=" + Utils.getSelectedUid(mSession);
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_MEMBERS + "levelNo=" + "100" +
                        "&investorUid=" + Utils.getSelectedUid(mSession)+"&selectedUser="+Utils.getSelectedUserObject(mSession);

            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }
        pbLoadMember.setVisibility(View.VISIBLE);
        tilSelectMember.setEnabled(false);
        String finalLevelNo = levelNo;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    pbLoadMember.setVisibility(View.GONE);

                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        mMemberJsonList.clear();
                        mMemberNameList.clear();

                        if (jsonObject.optInt("status") == 0) {
                            JSONObject result = jsonObject.optJSONObject("result");
                            JSONArray data = result != null ? result.optJSONArray("data") : null;

                            if (finalLevelNo.equals("100")) {
                                acSelectMember.setFocusable(true);
                                acSelectMember.setFocusableInTouchMode(true);
                                tilSelectMember.setHint(R.string.txt_search_member);
                                tilSelectMember.setEndIconDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.magnifying_glass_search_client));

                            } else {
                                acSelectMember.setFocusable(false);
                                acSelectMember.setFocusableInTouchMode(false);
                                tilSelectMember.setHint(R.string.select_member);
                                tilSelectMember.setEndIconDrawable(ContextCompat.getDrawable(requireContext(), R.mipmap.ic_arrow_drop_down_trangle));
                            }

                            if (data != null && data.length() != 0) {
                                btnApply.setEnabled(true);
                                tilSelectMember.setEnabled(true);


                                for (int i = 0; i < data.length(); i++) {
                                    JSONObject memberObject = data.optJSONObject(i);

                                    String name = memberObject.optString("name");
                                    String pan = memberObject.optString("pan");
                                    String key ;
                                    if (!isEmptyOrNull(pan))
                                       key = name + " / " + pan;
                                    else
                                       key =  name;
                                    mMemberJsonList.put(key, memberObject);
                                    mMemberNameList.add(key);
                                }

                                setUpSelectMember(mMemberNameList);

                            } else {
                                mSelectedMember = new JSONObject();
                                acSelectMember.setText(getString(R.string.no_member_available));
                                btnApply.setEnabled(false);
                            }
                        } else {
                            Toast.makeText(requireContext(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        pbLoadMember.setVisibility(View.GONE);
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    public void getInsurance(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.startShimmer();
        mLinerNoData.setVisibility(View.GONE);

        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        } else {
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";
        String uId = "";
        String levelNo = "";

        try {
            JSONObject jsonObjectUID = new JSONObject();
            JSONArray jsonArray1 = new JSONArray();
            if (!TextUtils.isEmpty(mType)) {
                if (mType.equals("L")){
                    jsonArray1.put("INFORCE");
                    jsonArray1.put("PAIDUP");
                }else {
                    jsonArray1.put("ACTIVE");
                }
            }

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                if (UtilityKotlin.getClientHopObject(mSession).length() != 0) {
                    if (Utils.getSelectedLevelNo(mSession).equals("1")){
                        return;
                    }
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");

                    jsonObjectUID.put("uid", uId);
                    jsonObjectUID.put("levelNo", levelNo);

                    JSONArray jsonArray = new JSONArray();
                    JSONObject jsonObject = new JSONObject();
                    ArrayList<String> mylist = new ArrayList<String>();
                    mylist.add(uId);
                    jsonObject.put("applicantUIds", mylist.toString());
                    jsonArray.put(jsonObject);

                    JSONObject jsonObject3 = new JSONObject();
                    jsonObject3.put("componentName", "lifeInsuranceTable");

                    JSONArray filterArray = new JSONArray();
                    JSONObject filterObject = new JSONObject();

                    filterObject.put("status", jsonArray1);
                    filterArray.put(filterObject);

                    //if (mType.equals(""))
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                            Config.GET_LIFE_INSURANCE_CLIENT +
                            "filters="+filterArray+"&category=" + mType + "&orderBy=issuingDate" +
                            "&orderByDesc=true&pageSize=100&currentPage=" + pageNo +
                            "&selectedUser="+Utils.getSelectedUserObject(mSession);
                } else {
                    JSONArray filterJaonArray = new JSONArray();
                    JSONObject uidFilter = new JSONObject();
                    if (acSelectMember.getText().toString().equals(getString(R.string.txt_all))) {
                        uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                        levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                        jsonObjectUID.put("uid", uId);
                        jsonObjectUID.put("levelNo", levelNo);
                    }
                    else {
                        jsonObjectUID.put("levelNo", mSelectedMember.optString("levelNo"));
                        uId = mSelectedMember.optString("uid");
                        jsonObjectUID.put("uid", uId);
                    }
                    uidFilter.put("selectedUser", jsonObjectUID);
                    filterJaonArray.put(uidFilter);

                    JSONObject filterObject = new JSONObject();
                    filterObject.put("status", jsonArray1);
                    filterJaonArray.put(filterObject);

                    JSONObject jsonObject3 = new JSONObject();
                    jsonObject3.put("componentName", "lifeInsuranceTable");
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                            Config.GET_LIFE_INSURANCE_BROKER +
                            "filters=" + filterJaonArray + "&orderBy=issuingDate" +
                            "&orderByDesc=true&category=" + mType + "&pageSize=100&currentPage=" + pageNo ;
                }
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                JSONArray filterArray = new JSONArray();
                JSONObject filterObject = new JSONObject();
                filterArray.put(filterObject);

                filterObject.put("status", jsonArray1);
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.GET_LIFE_INSURANCE_CLIENT +
                        "filters="+filterArray+"&category=" + mType + "&orderBy=issuingDate" +
                        "&orderByDesc=true&pageSize=100&currentPage=" + pageNo +
                        "&selectedUser="+Utils.getSelectedUserObject(mSession);
            }


            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
                 /*   hhttps://demo.investwell.app/webapi/broker/insurance/getInsuranceList?
                    currentPage=1&pageSize=20&orderBy=issuingDate&orderByDesc=true&category=
                            L&componentForLoader={"componentName":"lifeInsuranceTable"}&filters=[]&
                    selectedUser={}
*/

              /*
            https://demo.investwell.app/webapi/client/insurance/getInsuranceList?
            currentPage=1&pageSize=20&orderBy=issuingDate&orderByDesc=
            true&category=L&componentForLoader={"componentName":"lifeInsuranceTable"}
            &filters=[{"applicantUIds":["5553ce3575b8e1a64181794eb86c5b27"]}]
            &investorUid=5553ce3575b8e1a64181794eb86c5b27&levelNo&selectedUser=
            {"uid":"5553ce3575b8e1a64181794eb86c5b27&levelNo","levelNo":"98"}*/
        } catch (Exception e) {
            System.out.println();
        }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    loading = false;
                    List<JSONObject> list = new ArrayList<>();
                    if (pageNo > 1) {
                        list.addAll(mAdapter.mDataList);
                    }
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("status") == 0) {
                            JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                            JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                list.add(jsonObject1);
                            }

                        }
                    } catch (Exception e) {

                    } finally {
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);

                        if (list.size() > 0) {
                            mAdapter.updateList(list, "");
                            mLinerNoData.setVisibility(View.GONE);
                        } else {
                            mAdapter.updateList(new ArrayList<JSONObject>(), "");
                            mLinerNoData.setVisibility(View.VISIBLE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        ProgressBarCommon.dismissDialog();
                        if (!isAdded())
                            return;

                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mAdapter.updateList(new ArrayList<JSONObject>(), "");
                        mLinerNoData.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public void downloadFile2(String fileName, String appId) {
        mFileName = fileName;
        mAppId = appId;
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestCode = 11;
                setPermission();
                return;
            }
        }

        String url = "";

        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.DOWNLOAD_SOA + "fileHandle=1" + "&appid=" + mAppId +"&isExternal=1"+ "&fileName=" + mFileName+"&downloadType=PDF"+"&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "insurance", "", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_insurance_download_successfully), "pdf", mFileSave,uri);
                        else{
                            mMainActivity.showCommonDownload(mMainActivity, getString(R.string.txt_successfully), getString(R.string.txt_insurance_download_successfully), "pdf", mFileSave,uri);
                        }                    }
                });

    }

    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions){
            requestMultiPermissions(permissionList,requestCode);
        }else {
            if (requestCode == 11) {
                if (!mFileName.isEmpty()) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                    downloadFile2(mFileName, mAppId);
                }
            } else if (requestCode == 12) {
                openFileChooser();
            }
        }
    }

    private void requestMultiPermissions( String[] permissionList ,int requestCode){
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
/*
        if (!permissionsToRequest.isEmpty() && permissionsToRequest !=null) {

             ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
                boolean isGranted = true;
                if (permissions.containsValue(true)){
                    Log.d("DB", "PERMISSION GRANTED");
                }else {
                    isGranted = false;
                    Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
                }
                if (isGranted && requestCode == 12) {
                    openFileChooser();
                }
                if (isGranted) {
                    if (!mFileName.isEmpty()) {
                        final ProgressDialog pDialog = new ProgressDialog(getActivity());
                        pDialog.setMessage(getString(R.string.txt_downloading_file_please_wait));
                        pDialog.setCancelable(false);
                        pDialog.show();
                        downloadFile2(mFileName, mAppId);
                    }

                }
            });
            String[] pendingPermission = permissionsToRequest.toArray(new String[permissionsToRequest.size()]);
            rqPermission.launch(pendingPermission);
        }*/

    }

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),permissions -> {
        if (permissions.containsValue(true)){
            if (requestCode == 11) {
                if (!mFileName.isEmpty()) {
                    downloadFile2(mFileName, mAppId);
                }
            } else if (requestCode == 12) {
                openFileChooser();
            }
        }else {
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
    });


    private void openFileChooser() {
        Intent chooseFileIntent = new Intent(Intent.ACTION_GET_CONTENT);
        chooseFileIntent.setType("*/*");
        String[] mimetype = {"image/*", "application/pdf", "application/msword", "text/plain", "application/excel"};
        chooseFileIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimetype);
        chooseFileIntent.addCategory(Intent.CATEGORY_OPENABLE);
        chooseFileIntent = Intent.createChooser(chooseFileIntent, "Choose a file");
        startActivityForResult(chooseFileIntent, 2001);

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean isGranted = true;
        switch (requestCode) {
            case 11: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    } else {
                        isGranted = false;
                        Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
                        break;
                    }
                }

            }
        }
        if (isGranted && requestCode == 12) {
            openFileChooser();
        }
        if (isGranted) {
            if (!mFileName.isEmpty()) {
                downloadFile2(mFileName, mAppId);
            }

        }
    }

    @SuppressLint("Range")
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode ==2001 && data !=null && resultCode == RESULT_OK){
            mFileUri = data.getData();
            String uriString= mFileUri.toString();
            File myFile = new File(uriString);

            if (uriString.startsWith("content://")) {
                Cursor cursor = null;
                try {
                    cursor = getActivity().getContentResolver().query(mFileUri, null, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        mFileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                        // uploadDocument(displayName, uri);
                    }
                } finally {
                    cursor.close();
                }
            } else if (uriString.startsWith("file://")) {
                mFileName = myFile.getName();
            }

            try {
                InputStream iStream =  getActivity().getContentResolver().openInputStream(mFileUri);
                final byte[] inputData = getBytes(iStream);
                long lengthbmp = inputData.length;
                int fileSize = (int) (lengthbmp / 1024);

            } catch (Exception e) {

            }

        }
        if (mFileName != null && !mFileName.equalsIgnoreCase("") && mOJbject !=null) {
            uploadSignatureBitmapApi(mFileName,mFileUri);
        }
    }

    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }
}
