package investwell.common.onboarding.marketupdate;

/**
 * Created by Binesh on 24-04-2021.
 */

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewDataAdapter extends RecyclerView.Adapter<RecyclerViewDataAdapter.ItemRowHolder> {
    private ArrayList<JSONObject> dataList;
    private Context mContext;

    public RecyclerViewDataAdapter(Context context, ArrayList<JSONObject> dataList) {
        this.dataList = dataList;
        this.mContext = context;
    }

    @Override
    public ItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item_market, viewGroup, false);

        //  View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item_market, null);
        ItemRowHolder mh = new ItemRowHolder(view);
        return mh;
    }

    @Override
    public void onBindViewHolder(ItemRowHolder itemRowHolder, int i) {
        // itemRowHolder.flxform.removeAllViews();

        itemRowHolder.tvHeader1.setBackgroundResource(R.drawable.market_update_line1);
        GradientDrawable drawable = (GradientDrawable) itemRowHolder.tvHeader1.getBackground();
        if (i == 0) {
            drawable.setColor(ContextCompat.getColor(mContext, R.color.colormarket1));
            itemRowHolder.tvMenu1.setText(mContext.getString(R.string.text_name));
            itemRowHolder.tvMenu2.setText(mContext.getString(R.string.text_previous));
            itemRowHolder.tvMenu3.setText(mContext.getString(R.string.text_current));
            itemRowHolder.tvMenu4.setText(mContext.getString(R.string.text_change));
        } else if (i == 1) {
            drawable.setColor(ContextCompat.getColor(mContext, R.color.colormarket2));
            itemRowHolder.tvMenu1.setText(mContext.getString(R.string.text_name));
            itemRowHolder.tvMenu2.setText(mContext.getString(R.string.text_unit));
            itemRowHolder.tvMenu3.setText(mContext.getString(R.string.text_price));
            itemRowHolder.tvMenu4.setText(mContext.getString(R.string.text_change));
        } else if (i == 2) {
            drawable.setColor(ContextCompat.getColor(mContext, R.color.colormarket3));
            itemRowHolder.tvMenu1.setText(mContext.getString(R.string.text_name));
            itemRowHolder.tvMenu2.setText(mContext.getString(R.string.text_previous));
            itemRowHolder.tvMenu3.setText(mContext.getString(R.string.text_current));
            itemRowHolder.tvMenu4.setText(mContext.getString(R.string.text_change));
        } else if (i == 3) {
            drawable.setColor(ContextCompat.getColor(mContext, R.color.colormarket4));
            itemRowHolder.tvMenu1.setText(mContext.getString(R.string.text_name));
            itemRowHolder.tvMenu2.setText(mContext.getString(R.string.text_previous));
            itemRowHolder.tvMenu3.setText(mContext.getString(R.string.text_current));
            itemRowHolder.tvMenu4.setText(mContext.getString(R.string.text_change));
        } else {
            drawable.setColor(ContextCompat.getColor(mContext, R.color.colormarket1));
            itemRowHolder.tvMenu1.setText(mContext.getString(R.string.text_name));
            itemRowHolder.tvMenu2.setText(mContext.getString(R.string.text_previous));
            itemRowHolder.tvMenu3.setText(mContext.getString(R.string.text_current));
            itemRowHolder.tvMenu4.setText(mContext.getString(R.string.text_change));

        }

        JSONObject jsonObject = dataList.get(i);
        itemRowHolder.tvHeader1.setText(jsonObject.optString("ProductName") + " (" + jsonObject.optString("LastDate") + ")");


        JSONArray jsonArray = jsonObject.optJSONArray("IndexList");
        if (jsonArray != null) {
            for (int j = 0; j < jsonArray.length(); j++) {
                JSONObject innerObject = jsonArray.optJSONObject(j);
                View child = View.inflate(mContext, R.layout.list_single_card, null);
                TextView text1 = child.findViewById(R.id.text1);
                TextView text2 = child.findViewById(R.id.text2);
                TextView text3 = child.findViewById(R.id.text3);
                TextView text4 = child.findViewById(R.id.text4);
                text1.setTextColor(ContextCompat.getColor(mContext, R.color.blue_text_color));

                if (innerObject.optString("Change").contains("-")) {
                    text4.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                } else {
                    text4.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                }

                if (i == 0) {
                    text1.setText(innerObject.optString("IndexName"));
                    text2.setText(innerObject.optString("PreviousValue"));
                    text3.setText(innerObject.optString("CurrentValue"));
                    text4.setText(innerObject.optString("Change"));
                } else if (i == 1) {
                    text1.setText(innerObject.optString("IndexName"));
                    text2.setText(innerObject.optString("Unit"));
                    text3.setText(innerObject.optString("CurrentValue"));
                    text4.setText(innerObject.optString("Change"));
                } else if (i == 2) {
                    text1.setText(innerObject.optString("IndexName"));
                    text2.setText(innerObject.optString("PreviousValue"));
                    text3.setText(innerObject.optString("CurrentValue"));
                    String change = innerObject.optString("Change");
                    if (change.equals("") || change.equals("null") || change.equals("0")|change.equals("0.00")){
                        text4.setText("0.00%");
                    }else{
                        text4.setText(change);
                    }


                } else if (i == 3) {
                    text1.setText(innerObject.optString("IndexName"));
                    text2.setText(innerObject.optString("PreviousValue"));
                    text3.setText(innerObject.optString("CurrentValue"));
                    String change = innerObject.optString("Change");
                    if (change.equals("") || change.equals("null") || change.equals("0")|change.equals("0.00")){
                        text4.setText("0");
                    }else{
                        text4.setText(change);
                    }
                }else{
                    text1.setText(innerObject.optString("IndexName"));
                    text2.setText(innerObject.optString("PreviousValue"));
                    text3.setText(innerObject.optString("CurrentValue"));
                    text4.setText(innerObject.optString("Change"));
                }


                text1.setContentDescription(itemRowHolder.tvMenu1.getText().toString() + ". " + text1.getText().toString());
                text2.setContentDescription(itemRowHolder.tvMenu2.getText().toString() + ". " + text2.getText().toString());
                text3.setContentDescription(itemRowHolder.tvMenu3.getText().toString() + ". " + text3.getText().toString());
                text4.setContentDescription(itemRowHolder.tvMenu4.getText().toString() + ". " + text4.getText().toString());

                itemRowHolder.flxform.addView(child);
            }
        }

    }

    @Override
    public int getItemCount() {
        return (null != dataList ? dataList.size() : 0);
    }

    public static class ItemRowHolder extends RecyclerView.ViewHolder {
        protected TextView tvHeader1, tvMenu1, tvMenu2, tvMenu3, tvMenu4;
        protected LinearLayout flxform;

        public ItemRowHolder(View view) {
            super(view);
            this.tvHeader1 = view.findViewById(R.id.tvHeader1);
            this.tvMenu1 = view.findViewById(R.id.tvMenu1);
            this.tvMenu2 = view.findViewById(R.id.tvMenu2);
            this.tvMenu3 = view.findViewById(R.id.tvMenu3);
            this.tvMenu4 = view.findViewById(R.id.tvMenu4);
            this.flxform = view.findViewById(R.id.flxform);
        }
    }

    public void updateList(List<JSONObject> list) {
        dataList.clear();
        dataList.addAll(list);
        notifyDataSetChanged();
    }

}