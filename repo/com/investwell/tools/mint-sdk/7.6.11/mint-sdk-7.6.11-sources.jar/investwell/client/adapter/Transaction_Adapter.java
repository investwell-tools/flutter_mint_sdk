package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class Transaction_Adapter extends RecyclerView.Adapter<Transaction_Adapter.MyViewHolder> {

    // String[] ApplicantName, cardview_top_name_color, folio, date, transaction_type, amount;

    public ArrayList<JSONObject> mDataList;
    Context context;

    public Transaction_Adapter(Context context, ArrayList<JSONObject> jsonObject) {

        this.context = context;
        this.mDataList = jsonObject;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.my_transaction_item, parent, false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {



        final JSONObject jsonObject1 = mDataList.get(position);

        try {

            holder.client_name.setText(Utils.setFirstLetterCapital(jsonObject1.optString("clientName")));
            holder.cardview_top_name_color.setText(jsonObject1.optString("schemeName"));
            holder.folio.setText(jsonObject1.optString("folioNo"));
            holder.date.setText(UtilityKotlin.dateFormat2(jsonObject1.optString("navDate")));
         //   holder.transaction_type.setText(jsonObject1.optString("txnType"));

            String txnType = jsonObject1.optString("txnType");
            holder.transaction_type.setText(Utils.SchemeNameFormat(txnType));

            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
            format.setMinimumFractionDigits(0);
            format.setMaximumFractionDigits(0);

            double tnxAmount = jsonObject1.optDouble("amount");
            String strAmount = format.format(tnxAmount);

            double navValue = jsonObject1.optDouble("nav");
            if (Double.isNaN(navValue)) {
                holder.tvNav.setText("");
            }else {
                String strtvNav = String.valueOf(navValue);//60.11
                holder.tvNav.setText(strtvNav);
            }

            holder.amount.setText(strAmount);
            if (Utils.txnTypeColor(txnType)){
                holder.amount.setTextColor(ContextCompat.getColor(context, R.color.red_text_color));
            }else{
                holder.amount.setTextColor(ContextCompat.getColor(context, R.color.green_text_color));
            }

         /*   if (tnxAmount < 0) {
                holder.amount.setTextColor(Color.parseColor("#FFD33D22"));
            } else {
                holder.amount.setTextColor(Color.parseColor("#43ce41"));
            }*/
        } catch (Exception e) {

        }


    }

    @Override
    public int getItemCount() {

        return mDataList.size();

    }

    public void updateList(List<JSONObject> list) {

        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView client_name, cardview_top_name_color, folio, date, tvNav, transaction_type, amount;


        public MyViewHolder(View view) {
            super(view);

            client_name = view.findViewById(R.id.client_name);
            cardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);
            folio = view.findViewById(R.id.folio);
            date = view.findViewById(R.id.date);
            transaction_type = view.findViewById(R.id.transaction_type);
            amount = view.findViewById(R.id.amount);
            tvNav = view.findViewById(R.id.tvNav);


        }
    }
}