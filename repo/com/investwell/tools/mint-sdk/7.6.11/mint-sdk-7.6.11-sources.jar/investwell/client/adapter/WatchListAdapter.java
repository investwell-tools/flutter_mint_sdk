package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.client.activity.WatchListActivity;
import investwell.common.factsheet.FactSheetActivity;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class WatchListAdapter extends RecyclerView.Adapter<WatchListAdapter.MyViewHolder> {


    Context context;
    private ArrayList<JSONObject> jsonObject;
    private int mLastPosition = -1;
    private WatchListActivity mActivity;


    public WatchListAdapter(Context context, ArrayList<JSONObject> jsonObject) {

        this.context = context;
        this.jsonObject = jsonObject;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_watch_list, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {


        if (position % 2 == 1) {
                holder.itemView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        } else {
                holder.itemView.setBackgroundColor(Color.parseColor("#FAFAFA"));
        }
        mActivity = (WatchListActivity) context;
        final JSONObject jsonObject1 = jsonObject.get(position);
        Animation animation = AnimationUtils.loadAnimation(context, (position > mLastPosition) ? R.anim.item_animation_fall_down : R.anim.down_from_top);
        holder.itemView.startAnimation(animation);
        mLastPosition = position;
        if (position == 1) {
            holder.itemView.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                @Override
                public void onScrollChanged() {
                    Rect rect = new Rect();
                    holder.itemView.getGlobalVisibleRect(rect);
                }
            });
        }
        holder.colorBlue.setText(jsonObject1.optString("name"));
        holder.colorBlue.setSelected(true);
        holder.nav_date.setText("as on "+ UtilityKotlin.dateFormat2(jsonObject1.optString("navDate")));
        Double longValue = jsonObject1.optDouble("nav");
        if (longValue > 0) {
            String data1 = String.format("%.4f", longValue);
            holder.nav.setText(data1);
        } else {
            holder.nav.setText(".0000");
        }
        double cgrValue = jsonObject1.optDouble("changePercent");
        String data2 = String.format("%.2f", cgrValue) + "%";
        holder.change.setText(data2);
        if (holder.change.getText().toString().contains("-")) {

            holder.change.setTextColor((context.getResources().getColor(R.color.red_text_color)));
        } else {

            holder.change.setTextColor(context.getResources().getColor(R.color.green_text_color));
        }

        holder.itemView.setOnClickListener(view -> {
            //comment on 11 May 2022
           /* Bundle bundle = new Bundle();
            String schemeId = Utils.getSchemeIdFromAll(jsonObject1);
            bundle.putString("schemeId", schemeId);
            bundle.putString("SchemeName", jsonObject1.optString("name"));
            bundle.putString("schemeObj", jsonObject1.toString());
            Intent i = new Intent(mActivity, FactSheetActivity.class);
            i.putExtras(bundle);
            mActivity.startActivity(i);*/
           // mActivity.displayViewOther(42, bundle);

        });
    }

    @Override
    public int getItemCount() {

        return jsonObject.size();
    }


    public void updateList(List<JSONObject> list) {

        jsonObject.clear();
        jsonObject.addAll(list);
        notifyDataSetChanged();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView colorBlue, nav, change,nav_date;


        public MyViewHolder(View view) {
            super(view);

            colorBlue = view.findViewById(R.id.colorBlue);
            nav = view.findViewById(R.id.nav);
            change = view.findViewById(R.id.tv_change);
            nav_date=view.findViewById(R.id.nav_date);

        }
    }
}