package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class RecycleIINAdapter extends RecyclerView.Adapter<RecycleIINAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private RecycleIINAdapter.OnItemClickListener listener;
    private int mWidth = 0, mHeight = 0;
    private RecyclerView.LayoutParams params;
    private String mType = "";
    private NumberFormat format;
    public HashMap<Integer, Boolean> mHashSelection = new HashMap<>();

    public RecycleIINAdapter(Context context, ArrayList<JSONObject> list, int width, RecycleIINAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mWidth = width;

        format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycle_iin_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {

        return mDataList.size();

    }

    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mType = type;
        for (int i = 0; i < list.size(); i++) {
            if (i == 0)
                mHashSelection.put(i, true);
            else
                mHashSelection.put(i, false);

        }
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvText1, tvText2, tvText3, tvText4;
        TextView tvLevel1, tvLevel2, tvLevel3, tvLevel4;
        LinearLayout liner4;
        RelativeLayout relMain;
        ImageView ivSelected;
        CardView mainCardView;


        public ViewHolder(View view) {
            super(view);
            tvText1 = view.findViewById(R.id.tvText1);
            tvText2 = view.findViewById(R.id.tvText2);
            tvText3 = view.findViewById(R.id.tvText3);
            tvText4 = view.findViewById(R.id.tvText4);
            tvLevel1 = view.findViewById(R.id.tvLevel1);
            tvLevel2 = view.findViewById(R.id.tvLevel2);
            tvLevel3 = view.findViewById(R.id.tvLevel3);
            tvLevel4 = view.findViewById(R.id.tvLevel4);
            liner4 = view.findViewById(R.id.liner4);
            relMain = view.findViewById(R.id.relMain);
            mainCardView = view.findViewById(R.id.cardMainLayout);
            ivSelected = view.findViewById(R.id.ivSelected);
            if (!mType.equalsIgnoreCase("iinByFolio")) {
                params = (RecyclerView.LayoutParams) view.getLayoutParams();
                params.width = mWidth - 150;
                view.setLayoutParams(params);
            }

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                JSONObject jsonObject = mDataList.get(position);
                if (mType.equalsIgnoreCase("iin")) {
                    tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                    tvText2.setText(jsonObject.optString("pan"));

                    String joint1 = jsonObject.optString("JH1Name");
                    if (!joint1.equalsIgnoreCase("null") && !joint1.isEmpty())
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    else
                        tvText3.setText(mContext.getString(R.string.not_available));

                    tvText4.setText(jsonObject.optString("iinNo"));
                    tvLevel4.setText(mContext.getString(R.string.inn));
                }else if (mType.equalsIgnoreCase("iinByFolio")) {
                    tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                    tvText2.setText(jsonObject.optString("pan"));

                    String joint1 = jsonObject.optString("JH1Name");
                    if (!joint1.equalsIgnoreCase("null") && !joint1.isEmpty())
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    else
                        tvText3.setText(mContext.getString(R.string.not_available));

                    tvText4.setText(jsonObject.optString("iinNo"));
                    tvLevel4.setText(mContext.getString(R.string.inn));
                }else if (mType.equalsIgnoreCase("mfu")) {
                    /*"investorName":"CHINMAY DARGAR",
"firstHolderPAN":"MNBVC1234X",
"canNumber":"14157AKA03",
"JH1Name":null,
"JH2Name":null,
"mfuid":"2edf844a56fc63dc2420a7d75350e98e",
"holdingCode":"SI",
"taxStatusCode":"RI",
"nominees":[
],
"source":"folio",
"holding":"Single",
"taxStatus":"Individual",
"nomineeName":""*/
                    tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                    tvText2.setText(jsonObject.optString("firstHolderPAN"));

                    String joint1 = jsonObject.optString("JH1Name");
                    if (!joint1.equalsIgnoreCase("null") && !joint1.isEmpty())
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    else
                        tvText3.setText(mContext.getString(R.string.not_available));

                    tvText4.setText(jsonObject.optString("canNumber"));
                    tvLevel4.setText(mContext.getString(R.string.can));
                }else {
                    tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                    tvText2.setText(jsonObject.optString("firstHolderPAN"));

                    String joint1 = jsonObject.optString("JH1Name");
                    if (!joint1.equalsIgnoreCase("null") && !joint1.isEmpty())
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    else
                        tvText3.setText(mContext.getString(R.string.not_available));

                    tvText4.setText(jsonObject.optString("uccNumber"));
                    tvLevel4.setText(mContext.getString(R.string.ucc));
                }

                if (mHashSelection.get(position) == true) {
                    relMain.setBackgroundResource(R.drawable.selected_payment_mode);
                    ivSelected.setVisibility(View.VISIBLE);
                    listener.onItemClick(position);
                } else {
                    relMain.setBackgroundResource(R.drawable.unselcted_bank);
                    ivSelected.setVisibility(View.GONE);
                }


                mainCardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mHashSelection.get(position) == true) {
                            relMain.setBackgroundResource(R.drawable.unselcted_bank);
                            ivSelected.setVisibility(View.GONE);
                            for (int i = 0; i < mHashSelection.size(); i++) {
                                mHashSelection.put(i, false);
                            }
                            notifyDataSetChanged();

                        } else {
                            relMain.setBackgroundResource(R.drawable.selected_payment_mode);
                            ivSelected.setVisibility(View.VISIBLE);
                            for (int i = 0; i < mHashSelection.size(); i++) {
                                mHashSelection.put(i, false);
                            }
                            mHashSelection.put(position, true);
                            notifyDataSetChanged();

                        }
                        //listener.onItemClick(position);

                    }
                });

            } catch (Exception e) {

            }


        }

    }


}
