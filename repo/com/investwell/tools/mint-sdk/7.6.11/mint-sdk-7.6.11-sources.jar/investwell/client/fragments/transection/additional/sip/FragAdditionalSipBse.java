package investwell.client.fragments.transection.additional.sip;

import static investwell.utils.ExtensionsKt.decodeUrl;
import static investwell.utils.ExtensionsKt.formatDateToYYYYMMDD;
import static investwell.utils.ExtensionsKt.formatRupees;
import static investwell.utils.ExtensionsKt.getDate;
import static investwell.utils.ExtensionsKt.getUccCode;
import static investwell.utils.UtilityKotlin.checkFeaturePermissionsOnOff;
import static investwell.utils.UtilityKotlin.firstLetterCapitalOfSentence;
import static investwell.utils.UtilityKotlin.hasReAuthTimeNotValid;
import static investwell.utils.UtilityKotlin.isDarkTheme;
import static investwell.utils.UtilityKotlin.setRefreshKeyInExistingApi;
import static investwell.utils.UtilityKotlin.showSnackbar;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.client.fragments.mandate.BseMandateFormActivity;
import investwell.client.fragments.transection.BottomScreenPaymentMode;
import investwell.client.fragments.transection.FullScreenBsePopUpDialog;
import investwell.common.allorderstatus.MyOrdersActivity;
import investwell.common.transactions.FullScreenPaymentStatus;
import investwell.di.viewmodel.ApiClient;
import investwell.textview.AppTextView;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.CurrencyTextToWord;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import investwell.utils.ExtensionsKt;

import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.allorderstatus.BseOrderStatusActivity;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.customView.CustomDialog;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class FragAdditionalSipBse extends BaseFragment implements View.OnClickListener,BottomScreenPaymentMode.ResultListener {
    private TextView mTvcardview_top_name_color,tvWordAmount, tvStartDate;
    private RequestQueue requestQueue;
    private Spinner mSpMandate, mSpFrequency;
    private EditText mEtAmount;
    private final String mcardview_top_name_color = "";
    private String mTransactionType = "";
    private CheckBox mCheckboxPayNow;
    private final DecimalFormat myFormatter = new DecimalFormat("##,##,###.00");

    private ClientActivity mActivity;
    private AppSession mSession;
    private JSONObject mOldJsonObject, tranJsonObject, mBseObject, mObjNewScheme;
    private ArrayList<JSONObject> mSchemeList, mMandateList;
    private Calendar mCalendar;
    private final String mDateAfter8days = "";
    private final String mSeletedDate = "";
    private final String mSeletedEndDate = "";
    private String mSelectedMandateId = "";
    private ArrayList<String> mMonthListNumber, mMonthListNumber2;
    private ArrayList<String> mYearList, mYearList2;
    private ArrayList<String> mFrequencyList;
    private AppApplication mAppplication;
    private ToolbarFragment mFragToolBar;

    private LinearLayout mLlDatePicker, mLlDropDownDate, mLinearEndDate2,llAmount;
    private TextView mTvPopDate,tvGrowth,tvDividend,tvDividendReinvest,tvErrorMessage,tvLabelMinAmount;
    private String mPopUpStartDate = "";
    private final boolean mHasShowPopDatePicker = true;

    private LinearLayout mLlEndDateOptionsForBSe,llafterSchemeSelection, mLlInstalmentBox,mLLStartDate, mLinerEndDate, llAfterFrequency;
    private String mEndDateOptionType = "maxDate";
    private RadioGroup mRadioGroupEndDateOptionsForBse;
    private EditText mEtInstalments;

    private List<JSONObject> mJsonARNList;
    private Spinner mSpArn,spDivedentFrequencySip;
    private LinearLayout mLlArn,llDividentFreqSip,llschemeTypeMain,llSchemeType;
    private View line1,line2;
    private String mBseId = "";
    private String mFundName = "";
    private ProgressBar pbLoaderOnSchemeType;

    private String mSelectedFreq = "";
    private String selectedStartDate = "";
    private String selectedEndDate = "";
    private TextView mTvStartDate;
    private TextView mTvEndDate;

    private String mSchemeName = "",nseUccCode="";
    private String mSchemeId = "";

    private JSONObject mJsonObjNseInfo = new JSONObject();
    private JSONObject sipObject = new JSONObject();
    private ArrayList<Integer> mEnableSipDateFreqWise = new ArrayList<>();

    private RadioButton rbInstallment,rbMaxDate;
    private FullScreenBsePopUpDialog popup;
    private JSONObject profileObject;
    private BottomScreenPaymentMode bottomPaymentMode;
    private JSONObject bseProfileData= new JSONObject();
    private String mExchange = "2";
    private String mSchemeType="G";
    private String mSchemeGroupId="";
    private final String mPurchaseType="SIP";
    private String uccNumber = "";
    private boolean isNse2 = false;
    private MaterialButton transact_btn;
    private MaterialButton tvCart;

    private AppTextView mTvCreateMandate;

    private JSONArray mSIPDateArray = new JSONArray();
    private ArrayList<JSONObject> mJsonDividend = new ArrayList<>();

    private Boolean isWeekly = false;

    private LinearLayout llBottomButtons;

    private LinearLayout llPaymentOptions;
    private RadioGroup rgPaymentOptions;
    private boolean isAddToCartBseEnabled = false;
    private boolean isAddToCartNseInvestEnabled = false;

    private LinearLayout llStepUp,llStepUpAfterCheckBox;
    private RadioGroup rgStepUp;
    private RadioButton rbHalfYearly, rbYearly;
    private TextInputLayout tilStepUpAmount,tilStepUpStartDate;
    private TextInputEditText etStepUpAmount,etStepUpStartDate;
    private CheckBox cbAddStepUp;
    private boolean allowedNseStepUp = false;
    private UtilityKotlin.MinAmountResult minAmountResult = null;



    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.toolBar_title_sip_nse), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_additional_sip, container, false);
        setUpToolBar();

        mLlEndDateOptionsForBSe = view.findViewById(R.id.llEndDateOptions);
        llafterSchemeSelection = view.findViewById(R.id.llafterSchemeSelection);
        mLlInstalmentBox = view.findViewById(R.id.llInstalmentBox);
        llAfterFrequency = view.findViewById(R.id.llAfterFrequency);
        mEtInstalments = view.findViewById(R.id.etInstalments);
        mRadioGroupEndDateOptionsForBse = view.findViewById(R.id.rgDurationOptions);
        mLinearEndDate2 = view.findViewById(R.id.llEndDate);
        mTvEndDate = view.findViewById(R.id.tvEndDate);
        rbInstallment = view.findViewById(R.id.rbInstallment);
        rbMaxDate = view.findViewById(R.id.rbMaxDate);

        mSpArn = view.findViewById(R.id.spArn);
        mLlArn = view.findViewById(R.id.llArn);
        llDividentFreqSip = view.findViewById(R.id.llDividentFreqSip);
        tvGrowth = view.findViewById(R.id.tvGrowth);
        tvErrorMessage = view.findViewById(R.id.tvErrorMessage);
        llAmount = view.findViewById(R.id.llAmount);
        tvDividend = view.findViewById(R.id.tvDividend);
        tvDividendReinvest = view.findViewById(R.id.tvDividendReinvest);
        llschemeTypeMain = view.findViewById(R.id.llschemeTypeMain);
        llSchemeType = view.findViewById(R.id.llSchemeType);
        line1 = view.findViewById(R.id.line1);
        line2 = view.findViewById(R.id.line2);
        pbLoaderOnSchemeType = view.findViewById(R.id.pbLoaderOnSchemeType);
        spDivedentFrequencySip = view.findViewById(R.id.spDivedentFrequencySip);

        mLlArn.setVisibility(View.GONE);

        mLLStartDate = view.findViewById(R.id.llStartDate);
        mTvStartDate = view.findViewById(R.id.tvStartDate);

        TextView user_name = view.findViewById(R.id.user_name);
        TextView tvUcc = view.findViewById(R.id.tvUcc);
        TextView tvFolio = view.findViewById(R.id.tvFolio);
        mTvcardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);

        mEtAmount = view.findViewById(R.id.amount);
        tvWordAmount = view.findViewById(R.id.tvWordAmount);
        tvLabelMinAmount = view.findViewById(R.id.tvLabelMinAmount);
        mSpMandate = view.findViewById(R.id.select_mendate);
        mSpFrequency = view.findViewById(R.id.select_frequently);

        mCheckboxPayNow = view.findViewById(R.id.checkPayNow);
        rgPaymentOptions = view.findViewById(R.id.rgPaymentOptions);
        llPaymentOptions = view.findViewById(R.id.llPaymentOptions);
        mTvCreateMandate = view.findViewById(R.id.tvCreateMandate);

        llStepUp = view.findViewById(R.id.llStepUp);
        llStepUpAfterCheckBox = view.findViewById(R.id.llStepUpAfterCheckBox);
        rgStepUp = view.findViewById(R.id.rgStepUp);
        rbHalfYearly = view.findViewById(R.id.rbHalfYearly);
        rbYearly = view.findViewById(R.id.rbYearly);
        tilStepUpAmount = view.findViewById(R.id.tilStepUpAmount);
        tilStepUpStartDate = view.findViewById(R.id.tilStepUpStartDate);
        etStepUpAmount = view.findViewById(R.id.etStepUpAmount);
        etStepUpStartDate = view.findViewById(R.id.etStepUpStartDate);
        cbAddStepUp = view.findViewById(R.id.cbAddStepUp);


        mSchemeList = new ArrayList<>();
        mMandateList = new ArrayList<>();

        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mOldJsonObject = new JSONObject(bundle.getString("oldObject"));
                tranJsonObject = new JSONObject(bundle.getString("tranJsonObject"));
                if (tranJsonObject.has("investmentType")){
                    mSchemeType =tranJsonObject.optString("investmentType");
                }else {
                    mSchemeType ="";
                    llafterSchemeSelection.setVisibility(View.GONE);
                }
                mSchemeGroupId = mOldJsonObject.optString("schemeGroupId");
                mFundName = mOldJsonObject.optString("fundName");
                if (bundle.containsKey("nse2")){
                    isNse2 = bundle.getBoolean("nse2");
                    mExchange = bundle.getString("exchange");
                }else {
                    mExchange = "2";
                    isNse2 = false;
                }

                if (bundle.containsKey("sIinProfileObject")){
                    profileObject = new JSONObject(bundle.getString("sIinProfileObject"));
                    if (isNse2){
                        mBseId = profileObject.optString("nseInvestid");
                        nseUccCode= getUccCode(isNse2,profileObject,mOldJsonObject);
                    }else {
                        mBseId = profileObject.optString("bseid");
                        uccNumber = getUccCode(isNse2,profileObject,mOldJsonObject);
                    }
                }
                if (bundle.containsKey("mUccIinResponseObject")){
                    bseProfileData = new JSONObject(bundle.getString("mUccIinResponseObject"));
                }
                mTransactionType = bundle.getString("transactionType");






                user_name.setText(mOldJsonObject.optString("applicant_name"));
                mTvcardview_top_name_color.setText(mOldJsonObject.optString("schemeName"));

                tvUcc.setText(getUccCode(isNse2,profileObject,mOldJsonObject));

                tvFolio.setText(mOldJsonObject.optString("folioNo"));
                mSchemeName = mOldJsonObject.optString("schemeName");
                mSchemeId = Utils.getSchemeIdFromAll(mOldJsonObject);


                if(!isNse2)getSchemeNSEInfo();
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }

        if (mSession.getLoginType().equals("broker")) {
            getArnList();
        } else{
            getMendateList(mBseId,false);
        }
        mRadioGroupEndDateOptionsForBse.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbInstallment) {
                        mEndDateOptionType = "instalment";
                        mLlInstalmentBox.setVisibility(View.VISIBLE);
                        mLinearEndDate2.setVisibility(View.GONE);
}
else if (checkedId == R.id.rbEndDate) {
                        mEndDateOptionType = "end_date";
                        mLlInstalmentBox.setVisibility(View.GONE);
                        mLinearEndDate2.setVisibility(View.VISIBLE);
}
else if (checkedId == R.id.rbMaxDate) {
                        mEndDateOptionType = "maxDate";
                        mLlInstalmentBox.setVisibility(View.GONE);
                        mLinearEndDate2.setVisibility(View.GONE);
}
            }
        });

        view.findViewById(R.id.ivEdit).setOnClickListener(this);
        transact_btn =view.findViewById(R.id.transact_btn);
        transact_btn.setOnClickListener(this);
        tvGrowth.setOnClickListener(this);
        tvDividend.setOnClickListener(this);
        tvDividendReinvest.setOnClickListener(this);
        mTvCreateMandate.setOnClickListener(this);

        view.findViewById(R.id.tvStartDate).setOnClickListener(this);
        view.findViewById(R.id.tvEndDate).setOnClickListener(this);

        // getBSEID();

        mEtAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
              String word ="";
              if (!TextUtils.isEmpty(charSequence)){
                  try {
                      if (charSequence.length() !=0){
                          word = CurrencyTextToWord.convertToIndianCurrency(requireContext(),charSequence.toString().trim());
                      }else {
                          word = firstLetterCapitalOfSentence("");
                      }
                  }catch (Exception e){
                      if (BuildConfig.DEBUG)
                        e.printStackTrace();
                  }
              }else {
                 word = firstLetterCapitalOfSentence("");
              }
              tvWordAmount.setText(word);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        etStepUpAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                // No implementation
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                String word = "";

                if (!TextUtils.isEmpty(charSequence)) {
                    try {
                        if (charSequence.length() > 0) {
                            word = CurrencyTextToWord.convertToIndianCurrency(requireContext(),
                                    charSequence.toString().trim()
                            );
                        } else {
                            word = firstLetterCapitalOfSentence("");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    word = firstLetterCapitalOfSentence("");
                }

                ExtensionsKt.setCustomError(tilStepUpAmount, word, ContextCompat.getColor(requireContext(), R.color.default_text_color));
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No implementation
            }
        });

        tvCart = view.findViewById(R.id.tvCart);
        llBottomButtons = view.findViewById(R.id.llBottomButtons);
        tvCart.setOnClickListener(this);

        mCheckboxPayNow.setOnCheckedChangeListener((buttonView, isChecked) -> {
            llPaymentOptions.setVisibility(View.GONE);
            rgPaymentOptions.clearCheck();
            setTextOfPaymentButton();
        });

        cbAddStepUp.setOnCheckedChangeListener((buttonView, isChecked) -> {
            etStepUpAmount.setText(null);
            llStepUpAfterCheckBox.setVisibility(isChecked ? View.VISIBLE : View.GONE);

            if (isChecked) {
                setStepUpStartDate();
            }
        });

        rgStepUp.setOnCheckedChangeListener((group, checkedId) -> {
            setStepUpStartDate();
        });

        applyDefaultButtonState();

        getInvestmentType();
        return view;
    }

    private void setStepUpStartDate() {
        String showStartDate = getDate(
                mTvStartDate.getText().toString(),
                new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()),
                new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()),
                null,
                rbHalfYearly.isChecked() ? 6 : 12,
                null
        );

        etStepUpStartDate.setText(showStartDate);
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivEdit) {
                if (mSchemeList.size() > 0) {
                    showSchemesDailog();
                } else {
                    getSchemes(mOldJsonObject.optString("fundid"));
                }
}
else if (v.getId() == R.id.tvGrowth) {
                mSchemeType = "G";
                updateAmountAndFreq();
}
else if (v.getId() == R.id.tvDividend) {
                mSchemeType = "DP";
                updateAmountAndFreq();
}
else if (v.getId() == R.id.tvDividendReinvest) {
                mSchemeType = "DR";
                updateAmountAndFreq();
}
else if (v.getId() == R.id.tvCart) {
                if (tvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {
                    if (isValidInputNseBse("cart"))
                        insertTxnInNseOrBseCart();
                } else {
                    Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                    intent.putExtra("url", UtilityKotlin.constructCartUrl(mSession));
                    intent.putExtra("isPopup", true);
                    intent.putExtra("comeFrom", "client");
                    startActivity(intent);
                    new Handler(Looper.getMainLooper()).postDelayed(this::addToCartBtnClicked, 1500);

                }
}
else if (v.getId() == R.id.transact_btn) {
                if(isValidInputNseBse("transact")){
                    if ((transact_btn.getText().toString().equalsIgnoreCase(getString(R.string.place_order)))) {
                        placeSIP(
                                false,
                                "",
                                false,
                                "",
                                "",
                                "",
                                new JSONObject(),
                                isNse2
                        );
                    }
                    else
                        transactNowBtnClicked();
                }
}
else if (v.getId() == R.id.tvStartDate) {
                showDatePickerForStartDate(mTvStartDate.getText().toString());
}
else if (v.getId() == R.id.tvEndDate) {
                showDatePickerEndDate(mTvEndDate.getText().toString());
}
else if (v.getId() == R.id.tvCreateMandate) {
                Intent intent = new Intent(requireActivity(), BseMandateFormActivity.class);
                if(!isNse2)
                    intent.putExtra("result", "" + bseProfileData);
                else
                    intent.putExtra("result", "" + profileObject);
                intent.putExtra("fromNavigationPoint", "profile");
                startActivity(intent);
}
    }

    private void updateAmountAndFreq() {
        updateSchemeTypeUi();
        mEtAmount.setVisibility(View.VISIBLE);
    }

    private void getSchemeDetails() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String mUrl = "";
        try {
            String nseBseCode = "";
            if (isNse2){
                nseBseCode ="&hasNseInvestCode=true";
            }else {
                nseBseCode="&hasBseCode=true";
            }

            mUrl ="https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.GET_TARGET_SCHEME+"schemeGroupId="+mSchemeGroupId+"&investmentType="+mSchemeType+"&subType="+mPurchaseType+
                    nseBseCode+"&investorUid="+Utils.getSelectedUid(mSession)+"&selectedUser="+Utils.getSelectedUserObject(mSession);
            String refreshedUrl = setRefreshKeyInExistingApi(mUrl, mSession);
            mUrl =URLDecoder.decode(refreshedUrl, "UTF-8");

        }catch (Exception e){
        }

        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                mUrl,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        KtorCallBack.super.onLoading(isLoading);
                        if (isLoading){
                            ProgressBarCommon.showDialog(requireActivity());
                        }else{
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {
                        ArrayList<String> freqency = new ArrayList<>();
                        mSIPDateArray = new JSONArray();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                JSONObject jsonObj2 = jsonArray.getJSONObject(0);
                                mSchemeId = Utils.getSchemeIdFromAll(jsonObj2);
                                mSchemeName = jsonObj2.optString("name");
                                //new
                                JSONObject jsonObjectNew = jsonArray.optJSONObject(0);
                                mSIPDateArray = jsonObjectNew.optJSONArray("daysOfTheMonth");
                                mJsonDividend = new ArrayList();

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    var dividentFreq = jsonObject1.optString("dividendFrequency");
                                    if (dividentFreq != "" && !dividentFreq.equalsIgnoreCase("null")) {
                                        dividentFreq = dividentFreq.toUpperCase(Locale.getDefault());
                                        dividentFreq = setUsername(dividentFreq);
                                        freqency.add(dividentFreq);
                                    }
                                    mJsonDividend.add(jsonObject1);
                                }
                                tvLabelMinAmount.setVisibility(View.GONE);
                                if (!mSchemeType.equalsIgnoreCase("G")) {
                                    setDividendFrequency(freqency);
                                }
                                tvErrorMessage.setVisibility(View.GONE);
                                llAmount.setVisibility(View.VISIBLE);
                                llafterSchemeSelection.setVisibility(View.VISIBLE);
                                //user is allowed to addToCart again if schid is changed
                                applyDefaultButtonState();
                                transact_btn.setEnabled(true);
                                llBottomButtons.setVisibility(View.VISIBLE);

                                //in scheme type "DP" & "DR" getSchemeNseInfo is called acc to the div frequency selected
                                if(mSchemeType.equalsIgnoreCase("G"))
                                    getSchemeNSEInfo();
                            } else {
                                llAmount.setVisibility(View.GONE);
                                transact_btn.setEnabled(false);
                                llBottomButtons.setVisibility(View.GONE);
                                tvErrorMessage.setVisibility(View.VISIBLE);
                                tvErrorMessage.setText(getString(R.string.not_available));
//                                relFrequency.setVisibility(View.GONE);
                                llafterSchemeSelection.setVisibility(View.GONE);
                                llDividentFreqSip.setVisibility(View.GONE);
                            }
                        } catch ( Exception e) {
                        }
                    }
                }
        );


    }

    private void setMinAmount(String freqCodeSelected){
        int divFreqPos;
        if (mSchemeType.equalsIgnoreCase("G"))
            divFreqPos = 0;
        else
            divFreqPos = spDivedentFrequencySip.getSelectedItemPosition();
        minAmountResult = UtilityKotlin.getMinAmount(mJsonDividend, divFreqPos, "minAmount", freqCodeSelected);
        if (minAmountResult.getVisibility() == UtilityKotlin.MinAmountVisibility.HIDE) {
            tvLabelMinAmount.setVisibility(View.GONE);
        } else {
            tvLabelMinAmount.setVisibility(View.VISIBLE);
            Double minAmount = minAmountResult.getMinAmount();

            if (minAmount != null) {
                tvLabelMinAmount.setText("Min : "+formatRupees(this,minAmount));
            }
        }
    }

    private String setUsername(String name) {
        StringBuffer capBuffer = new StringBuffer();
        java.util.regex.Matcher capMatcher = java.util.regex.Pattern
                .compile("([a-z])([a-z]*)", java.util.regex.Pattern.CASE_INSENSITIVE)
                .matcher(name == null ? "" : name);
        while (capMatcher.find()) {
            String firstChar = capMatcher.group(1).toUpperCase(java.util.Locale.getDefault());
            String restChars = capMatcher.group(2).toLowerCase(java.util.Locale.getDefault());
            capMatcher.appendReplacement(capBuffer, firstChar + restChars);
        }
        capMatcher.appendTail(capBuffer);
        return capBuffer.toString();
    }

    private void setDividendFrequency(List<String> frequencyList) {
        try {
            llDividentFreqSip.setVisibility(View.VISIBLE);
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(
                    requireActivity(),
                    R.layout.spinner_bg,
                    frequencyList
            );
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            spDivedentFrequencySip.setAdapter(dataAdapter);

            spDivedentFrequencySip.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    // Handle item selected
                    JSONObject mSelectedObject = mJsonDividend.get(position);
                    //user is allowed to addToCart again if schid is changed
                    applyDefaultButtonState();
                    mSchemeId = Utils.getSchemeIdFromAll(mSelectedObject);
                    mSchemeName = mSelectedObject.optString("name");
                    getSchemeNSEInfo();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Handle nothing selected
                }
            });
        } catch (Exception ignored) {
        }


    }


    private void getInvestmentType() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){return;}

        String mUrl ="";
        try {
            String nseBseCode = "";
            if (isNse2){
                nseBseCode ="&hasNseInvestCode=true";
            }else {
                nseBseCode="&hasBseCode=true";
            }
            mUrl = "https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.GET_INVESTMENT_TYPE+
                    "schemeGroupId="+mSchemeGroupId+"&subType="+mPurchaseType+nseBseCode +
                    "&investorUid="+Utils.getSelectedUid(mSession)+"&selectedUser="+Utils.getSelectedUserObject(mSession);
            String refreshedUrl = setRefreshKeyInExistingApi(mUrl, mSession);
            mUrl=  URLDecoder.decode(refreshedUrl, "UTF-8");
        } catch (Exception e) {
        }
        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                mUrl,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        KtorCallBack.super.onLoading(isLoading);
                        if (isLoading)
                            pbLoaderOnSchemeType.setVisibility(View.VISIBLE);
                        else
                            pbLoaderOnSchemeType.setVisibility(View.GONE);
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                llschemeTypeMain.setVisibility(View.VISIBLE);
                                llSchemeType.setVisibility(View.VISIBLE);
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONObject objData = null;
                                if (jsonObject1 != null) {
                                    objData = jsonObject1.optJSONObject("data");
                                }
                                JSONArray mSchemeTypeJsonArray = null;
                                if (objData != null) {
                                    mSchemeTypeJsonArray = objData.optJSONArray("allowedInvestmentTypes");
                                }

                                tvGrowth.setEnabled(false);
                                tvDividend.setEnabled(false);
                                tvDividendReinvest.setEnabled(false);
                                mSchemeType = "";
                                if (mSchemeTypeJsonArray != null && mSchemeTypeJsonArray.length() > 0) {
                                    if (containsValue(mSchemeTypeJsonArray, "G") && containsValue(mSchemeTypeJsonArray, "D")) {
                                        tvGrowth.setEnabled(true);
                                        tvDividend.setEnabled(true);
                                        tvDividendReinvest.setEnabled(true);
                                        mSchemeType = "G";
                                    } else if (containsValue(mSchemeTypeJsonArray, "G")) {
                                        tvGrowth.setEnabled(true);
                                        mSchemeType = "G";
                                    } else {
                                        tvDividend.setEnabled(true);
                                        tvDividendReinvest.setEnabled(true);
                                        mSchemeType = "DP";
                                    }
                                    tvErrorMessage.setVisibility(View.GONE);
                                    llSchemeType.setVisibility(View.VISIBLE);
                                    llafterSchemeSelection.setVisibility(View.VISIBLE);
                                    transact_btn.setEnabled(true);
                                    updateAmountAndFreq();
                                    if (mSchemeTypeJsonArray.length() ==1 && mSchemeType.equalsIgnoreCase("G")){
                                        llschemeTypeMain.setVisibility(View.GONE);
                                    }

                                } else {
                                    tvErrorMessage.setVisibility(View.VISIBLE);
                                    tvErrorMessage.setText(getString(R.string.no_scheme_type_available));
                                    llSchemeType.setVisibility(View.GONE);
                                    llafterSchemeSelection.setVisibility(View.GONE);
//                                    checkPayNow.setVisibility(View.GONE);
                                    // disable button
                                    transact_btn.setEnabled(false);

                                }
                            } else if (jsonObject.optInt("status") == -1) {
//                                binding.llAfterSchemeType.setVisibility(View.GONE);
                                llSchemeType.setVisibility(View.GONE);
                                llafterSchemeSelection.setVisibility(View.GONE);
                                transact_btn.setEnabled(false);
                                Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                        }


                        //            llschemeTypeMain.setVisibility(View.VISIBLE);

                    }
                }
        );
    }

    public static boolean containsValue(JSONArray array, String value) {
        if (array == null || value == null) return false;

        for (int i = 0; i < array.length(); i++) {
            if (value.equals(array.optString(i))) {
                return true;
            }
        }
        return false;
    }

    private void updateSchemeTypeUi() {
        if (mSchemeType.equals("G")) {
            tvGrowth.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.login_btn_bg_two));
            tvGrowth.setSelected(true);
            tvDividend.setSelected(false);
            tvDividendReinvest.setSelected(false);
            tvDividend.setBackgroundColor(Color.TRANSPARENT);
            tvDividendReinvest.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.GONE);
            line1.setVisibility(View.GONE);
            line2.setVisibility(View.VISIBLE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3. Not Selected");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3. Not Selected");
            getSchemeDetails();

        } else if (mSchemeType.equals("DP")) {
            tvDividend.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.login_btn_bg_two));
            tvGrowth.setSelected(false);
            tvDividend.setSelected(true);
            tvDividendReinvest.setSelected(false);

            tvGrowth.setBackgroundColor(Color.TRANSPARENT);
            tvDividendReinvest.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.VISIBLE);
            line1.setVisibility(View.GONE);
            line2.setVisibility(View.GONE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3. Not Selected");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3.");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3. Not Selected");
            getSchemeDetails();
        } else if (mSchemeType.equals("DR")) {
            tvDividendReinvest.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.login_btn_bg_two));
            tvGrowth.setSelected(false);
            tvDividend.setSelected(false);
            tvDividendReinvest.setSelected(true);

            tvGrowth.setBackgroundColor(Color.TRANSPARENT);
            tvDividend.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.VISIBLE);
            line1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.GONE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3. Not Selected");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3. Not Selected");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3");
            getSchemeDetails();
        } else {
            tvGrowth.setSelected(false);
            tvDividend.setSelected(false);
            tvDividendReinvest.setSelected(false);

            tvGrowth.setBackgroundColor(Color.TRANSPARENT);
            tvDividend.setBackgroundColor(Color.TRANSPARENT);
            tvDividendReinvest.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.GONE);
            line1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.VISIBLE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3. Not Selected");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3. Not Selected");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3. Not Selected");
        }

    }

    private void getArnList() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "investOnline");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ARN_LIST_NSE + "exchange="+mExchange +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

          /*  https://spvithlani.investwell.app/webapi/client/getArns?
            // exchange=2&investorUid=67c025d3f470b86011712f7f974d669d
            // &selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = decodeUrl(url);
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mBar.dismiss();

                        mJsonARNList = new ArrayList<>();
                        ArrayList<String> arnList = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    arnList.add(jsonObject1.optString("arnNo"));
                                    mJsonARNList.add(jsonObject1);
                                }
                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(getActivity(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {

                        } finally {
                            if (mJsonARNList.size() > 1) {
                                mLlArn.setVisibility(View.VISIBLE);
                                setArnList(arnList);
                            }else{
                                mLlArn.setVisibility(View.GONE);
                                getMendateList(mBseId,false);
                            }


                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar !=null) mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void setArnList(List<String> list) {
        try {
            list.add(0, getString(R.string.select_arn_2));
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpArn.setAdapter(dataAdapter);
            mSpArn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int po, long l) {
                    JSONArray dataArray = bseProfileData.optJSONArray("data");
                    if(isNse2){
                        String arn =mSpArn.getSelectedItem().toString().trim();
                        getMendateList(mBseId,true);
                    }else if (dataArray != null) {
                        boolean isMatched = false;

                        for (int i = 0; i < dataArray.length(); i++) {
                            JSONObject item = dataArray.optJSONObject(i);

                            if (item != null &&
                                    mSpArn.getSelectedItem().toString().equals(item.optString("arnNo"))) {

                                String mBseIdTSelected = item.optString(isNse2 ? "nseInvestid" :"bseid");
                                mSelectedMandateId = "";
                                getMendateList(mBseIdTSelected, true);

                                isMatched = true;
                                break;
                            }
                        }

                        // If NO match found
                        if (!isMatched) {
                            mSelectedMandateId = "";
                            getMendateList(mBseId, true);
                        }
                    }else {
                        getMendateList(mBseId,true);
                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });

        } catch (Exception e) {

        }
    }


    private void showDatePickerForStartDate(String defaultDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();

        // Getting the min date for the date picker
        Calendar minDate = Calendar.getInstance();
        minDate.add(Calendar.DATE, 1);
        Calendar maxDate = Calendar.getInstance();
        maxDate.set(2100, Calendar.JANUARY, 1);

        // Setting the default date of the start date picker
        try {
            if (!defaultDate.isEmpty()) {
                calendar.setTime(dateFormat.parse(defaultDate));
            } else {
                Calendar tempCalendar = Calendar.getInstance();
                tempCalendar.add(Calendar.DAY_OF_MONTH, 8);
                calendar.setTime(tempCalendar.getTime());
            }
        } catch (ParseException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        DatePickerDialog datePickerDialog = DatePickerDialog.newInstance((view, year, monthOfYear, dayOfMonth) -> {
            monthOfYear += 1;
            NumberFormat f = new DecimalFormat("00");
            String months = f.format(monthOfYear);
            String days = f.format(dayOfMonth);
            selectedStartDate = year + "-" + months + "-" + days;
            String startDate = days + "-" + months + "-" + year;
            mTvStartDate.setText(startDate);
            String endDate = getDate(startDate,dateFormat,dateFormat, 0,0,40);
            String[] endDateList = endDate.split("-");
            selectedEndDate = endDateList[2] + "-" + endDateList[1] + "-" + endDateList[0];
            mTvEndDate.setText(endDate);
            setStepUpStartDate();

        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        datePickerDialog.setMinDate(minDate);
        datePickerDialog.setMaxDate(maxDate);

        datePickerDialog.setThemeDark(isDarkTheme(requireActivity()));
        datePickerDialog.setAccentColor(ContextCompat.getColor(requireContext(), R.color.calendarAccentColor));
        datePickerDialog.setOkColor(ContextCompat.getColor(requireContext(), R.color.primaryToGreenPrimary));
        datePickerDialog.setCancelColor(ContextCompat.getColor(requireContext(), R.color.primaryToGreenPrimary));


        disableDays(datePickerDialog,minDate,maxDate, mEnableSipDateFreqWise);

        datePickerDialog.show(getActivity().getSupportFragmentManager(), "Datepickerdialog");
    }
    private void showDatePickerEndDate(String defaultDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();

        // setting the min date for the date picker
        String minDateString = getDate(
                mTvStartDate.getText().toString(),
                dateFormat,
                dateFormat,
                0, 1, 0);
        Calendar minDate = Calendar.getInstance();
        try {
            minDate.setTime(dateFormat.parse(minDateString));
        } catch (ParseException ignored) {
        }

        // setting the max date for the date picker
        String maxDateString = getDate(
                mTvStartDate.getText().toString(),
                dateFormat,
                dateFormat,
                0, 0, 40);
        Calendar maxDate = Calendar.getInstance();
        try {
            maxDate.setTime(dateFormat.parse(maxDateString));
        } catch (ParseException ignored) {
        }

        // Setting the default date of the end date picker
        try {
            calendar.setTime(dateFormat.parse(defaultDate));
        } catch (ParseException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        DatePickerDialog datePickerDialog = DatePickerDialog.newInstance((view, year, monthOfYear, dayOfMonth) -> {
            monthOfYear += 1;
            NumberFormat f = new DecimalFormat("00");
            String months = f.format(monthOfYear);
            String days = f.format(dayOfMonth);
            mPopUpStartDate = year + "-" + months + "-" + days;
            selectedEndDate = mPopUpStartDate;
            String showDate = days + "-" + months + "-" + year;
            mTvEndDate.setText(showDate);
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));

        boolean isDarkTheme =
                (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                        == Configuration.UI_MODE_NIGHT_YES;

        datePickerDialog.setThemeDark(isDarkTheme);
        int accentColor = ContextCompat.getColor(requireContext(), R.color.primaryToGreenPrimary);
        datePickerDialog.setAccentColor(accentColor);
        datePickerDialog.setOkColor(accentColor);
        datePickerDialog.setCancelColor(accentColor);

        datePickerDialog.setMinDate(minDate);
        datePickerDialog.setMaxDate(maxDate);

        Calendar loopDate = (Calendar) minDate.clone();
        String startDateSelected = mTvStartDate.getText().toString();
        int daySelectedInStartDate = Integer.parseInt(startDateSelected.split("-")[0]);
        while (minDate.before(datePickerDialog.getMaxDate())) {
            int dayOfMonth = loopDate.get(Calendar.DAY_OF_MONTH);
            if (dayOfMonth != daySelectedInStartDate) {
                Calendar[] disabledDays = new Calendar[1];
                disabledDays[0] = (Calendar) loopDate.clone();
                datePickerDialog.setDisabledDays(disabledDays);
            }
            minDate.add(Calendar.DATE, 1);
            loopDate = (Calendar) minDate.clone();
        }

        datePickerDialog.show(getActivity().getSupportFragmentManager(), "Datepickerdialog");
    }
    private void disableDays(DatePickerDialog datePickerDialog, Calendar minDate, Calendar maxDate, ArrayList<Integer> allowableDays) {
        List<Calendar> disabledDaysList = new ArrayList<>();
        Calendar loopDate = (Calendar) minDate.clone();

        while (loopDate.before(maxDate)) {
            int dayOfWeek = loopDate.get(Calendar.DAY_OF_WEEK);
            int dayOfMonth = loopDate.get(Calendar.DAY_OF_MONTH);

            boolean shouldDisable;

            if (allowableDays.isEmpty()) {
                shouldDisable = dayOfMonth > 28 || dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY;
            } else {
                if (isWeekly) {
                    shouldDisable = !allowableDays.contains(dayOfWeek);
                } else {
                    shouldDisable = !allowableDays.contains(dayOfMonth);
                }
            }

            if (shouldDisable) {
                disabledDaysList.add((Calendar) loopDate.clone());
            }


            loopDate.add(Calendar.DATE, 1);
        }

        datePickerDialog.setDisabledDays(disabledDaysList.toArray(new Calendar[0]));
    }





    private void setFrequently() {
        try {
            ArrayAdapter<String> dataAdapter;
            if (mFrequencyList.isEmpty()) {
                llAfterFrequency.setVisibility(View.GONE);
                dataAdapter = new ArrayAdapter<>(requireActivity(), R.layout.spinner_bg, List.of(getString(R.string.no_frequency_available)));
            } else {
                llAfterFrequency.setVisibility(View.VISIBLE);
                dataAdapter = new ArrayAdapter<>(requireActivity(), R.layout.spinner_bg, mFrequencyList);
            }
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpFrequency.setAdapter(dataAdapter);

            mSpFrequency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedFreq = parent.getItemAtPosition(position).toString();

                    if(llAfterFrequency.getVisibility() == View.GONE){
                        mSelectedFreq = "";
                        return;
                    }

                    if (mSelectedFreq.equalsIgnoreCase("Daily")) {
                        rbMaxDate.setChecked(true);
                        rbInstallment.setVisibility(View.GONE);
                    } else
                        rbInstallment.setVisibility(View.VISIBLE);

                    if (isNse2 && allowedNseStepUp && mSelectedFreq.equalsIgnoreCase("Monthly")) {

                        llStepUp.setVisibility(View.VISIBLE);
                        cbAddStepUp.setChecked(false);
                        rbYearly.setChecked(true);
                        etStepUpAmount.setText(null);
                        etStepUpStartDate.setText(null);

                    } else {
                        llStepUp.setVisibility(View.GONE);
                    }


                    String freqCode = mSelectedFreq.toLowerCase();
                    JSONArray jsonArray;
                    if(sipObject.optJSONArray(freqCode) != null)
                        jsonArray =  sipObject.optJSONArray(freqCode);
                    else
                        jsonArray = new JSONArray();

                    setMinAmount(freqCode);

                    isWeekly = true;

                    try {
                        if ("Weekly".equals(mSelectedFreq)) {
                            if (isNse2) {
                                // Check if all string values are between "1" and "5"
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    String value = jsonArray.optString(i, "-1");
                                    try {
                                        int intValue = Integer.parseInt(value);
                                        if (intValue < 1 || intValue > 5) {
                                            isWeekly = false;
                                            break;
                                        }
                                    } catch (NumberFormatException e) {
                                        isWeekly = false;
                                        break;
                                    }
                                }
                            } else {
                                isWeekly = false;
                            }
                        } else {
                            isWeekly = false;
                        }
                    } catch (Exception e) {
                        isWeekly = false;
                    }

                   // Now convert based on final isWeekly result
                    mEnableSipDateFreqWise = UtilityKotlin.convertJsonArrayToListOfInt(jsonArray, isWeekly);

                    // Set default date in start and end date
                    if (mEnableSipDateFreqWise.isEmpty()) {
                        ArrayList<Integer> currentMonthEnableDays;

                        Calendar calendar = Calendar.getInstance();
                        calendar.add(Calendar.DAY_OF_MONTH, 1);

                        Calendar calendar8DaysAhead = Calendar.getInstance();
                        calendar8DaysAhead.add(Calendar.DAY_OF_MONTH, 8);

                        if (calendar8DaysAhead.get(Calendar.MONTH) > calendar.get(Calendar.MONTH)) {
                            calendar.set(Calendar.MONTH, calendar8DaysAhead.get(Calendar.MONTH));
                        }

                        currentMonthEnableDays = new ArrayList<>();
                        for (int day = 1; day <= 28; day++) {
                            calendar.set(Calendar.DAY_OF_MONTH, day);
                            int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
                            if (dayOfWeek != Calendar.SATURDAY && dayOfWeek != Calendar.SUNDAY) {
                                currentMonthEnableDays.add(day);
                            }
                        }
                        initializeStartEndDate(currentMonthEnableDays);
                    }
                    else {
                        if (isWeekly) {
                            Calendar calendar = Calendar.getInstance();
                            calendar.add(Calendar.DAY_OF_MONTH, 1);

                            Calendar calendar8DaysAhead = Calendar.getInstance();
                            calendar8DaysAhead.add(Calendar.DAY_OF_MONTH, 8);

                            if (calendar8DaysAhead.get(Calendar.MONTH) > calendar.get(Calendar.MONTH)) {
                                calendar.set(Calendar.MONTH, calendar8DaysAhead.get(Calendar.MONTH));
                            }

                            ArrayList<Integer> currentMonthEnableDays = new ArrayList<>();
                            for (int day = 1; day <= 31; day++) {
                                calendar.set(Calendar.DAY_OF_MONTH, day);
                                int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
                                if (mEnableSipDateFreqWise.contains(dayOfWeek)) {
                                    currentMonthEnableDays.add(day);
                                }
                            }

                            initializeStartEndDate(currentMonthEnableDays);
                        } else {
                            initializeStartEndDate(mEnableSipDateFreqWise);
                        }
                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Do nothing
                }
            });

        } catch (Exception e) {

        }

    }

    private void initializeStartEndDate(ArrayList<Integer> allowedDates) {
        // Setting start and end date initially
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, 8);
        int dayNumber = calendar.get(Calendar.DAY_OF_MONTH);
        int monthNumber = calendar.get(Calendar.MONTH);
        int yearNumber = calendar.get(Calendar.YEAR);

        int allowedDayAfter8Days = firstGreaterOrEqual(dayNumber, allowedDates);
        if(allowedDayAfter8Days < dayNumber)
            monthNumber++;

        calendar.set(yearNumber,monthNumber,allowedDayAfter8Days);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        String initialStartDate = dateFormat.format(calendar.getTime());
        selectedStartDate = formatDateToYYYYMMDD(initialStartDate);
        mTvStartDate.setText(initialStartDate);

        String initialEndDate = getDate(initialStartDate,dateFormat,dateFormat,0,0,40);
        selectedEndDate = formatDateToYYYYMMDD(initialEndDate);
        mTvEndDate.setText(initialEndDate);
    }
    private int firstGreaterOrEqual(int number, ArrayList<Integer> array) {
        try {
            for (int value : array) {
                if (value >= number) {
                    return value;
                }
            }
            return array.get(0); // Default to first element if no greater or equal value found
        }
        catch (Exception e){
            System.out.println(e);
            return 1;
        }
    }


    private boolean isValidInputNseBse(String clickedFrom) {
         if (tvErrorMessage.getVisibility() == View.VISIBLE) {
            if(tvErrorMessage.getText().toString().equals(getString(R.string.no_scheme_type_available)))
                Toast.makeText(requireActivity(), getString(R.string.please_select_another_scheme), Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(requireActivity(), getString(R.string.new_purchase_text_select_another_scheme_type), Toast.LENGTH_SHORT).show();
            return false;
        }
         else if (isNse2 && !mSchemeType.equalsIgnoreCase("G") && spDivedentFrequencySip.getSelectedItem().toString().isEmpty()) {
             Toast.makeText(mActivity, getString(R.string.please_select_div_frequency), Toast.LENGTH_SHORT).show();
             return false;
         }
         else if(llAfterFrequency.getVisibility() == View.GONE){
             Extensions.showToast(requireContext(),getString(R.string.frequency_not_available_in_selected_scheme));
             return false;
         }
        else if (mEtAmount.getText().toString().equals("")) {
            Toast.makeText(mActivity, getString(R.string.error_empty_amount), Toast.LENGTH_SHORT).show();
            return false;
        }
         else if (minAmountResult != null && minAmountResult.getVisibility() == UtilityKotlin.MinAmountVisibility.SHOW && Double.parseDouble(mEtAmount.getText().toString().trim()) < minAmountResult.getMinAmount()) {
             Toast.makeText(mActivity, getString(R.string.minimum_amount_should_be) + " " + formatRupees(this,minAmountResult.getMinAmount()), Toast.LENGTH_SHORT).show();
             return false;
         }

        else if (mEndDateOptionType.equalsIgnoreCase("instalment") && mEtInstalments.getText().toString().equals("")) {
            Toast.makeText(mActivity, R.string.Please_enter_instalment, Toast.LENGTH_SHORT).show();
            return false;
        }
         else if(isNse2 && llStepUp.getVisibility() == View.VISIBLE && cbAddStepUp.isChecked() && etStepUpAmount.getText().toString().equals("")){
             Toast.makeText(mActivity, R.string.please_enter_step_up_amount, Toast.LENGTH_SHORT).show();
             return false;
         }
        else if (mSelectedMandateId.equalsIgnoreCase("")) {
            Toast.makeText(mActivity, getString(R.string.new_purchase_text_no_mandate), Toast.LENGTH_SHORT).show();
            return false;
        } else if (!isNse2 && "transact".equalsIgnoreCase(clickedFrom) &&
                mSession.getShowBseAuthPopup() &&
                llPaymentOptions.getVisibility() == View.VISIBLE &&
                rgPaymentOptions.getCheckedRadioButtonId() == -1) {
            Toast.makeText(mActivity, getString(R.string.new_purchase_text_select_payment), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;

    }

    private void placeSIP(
            boolean isIgnoreDuplicate,
            String otp,
            boolean isValidated,
            String provisonalOrderId,
            String paymentMode,
            String loopBackUrl,
            JSONObject paymentDetails,
            boolean isNse2Value
    ) {
        Utils.hideKeyBoardFromAnyWhere(getActivity());

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url ="";
        if (isNse2Value){
            url ="https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +Config.NSE_INVEST_PLACE_SIP_ORDER;
        }else {
            url=  "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.PLACE_SIP_ORDER;
        }

        JSONObject objectMain = new JSONObject();

        try {
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));

            if (!isNse2Value && isValidated){
                objectMain.put("provisionalOrderid",provisonalOrderId);
                objectMain.put("otp", otp);
            }else {
                // common for normal bse transaction flow and Nse2 transaction common payload
                // isNseValue==true and BSE non- validated transaction flow
                objectMain.put("txnType", "ADDITIONAL");
                objectMain.put("startDate", selectedStartDate);
                objectMain.put("installmentAmount", mEtAmount.getText().toString().trim());
                objectMain.put("mandateId", mSelectedMandateId);
                objectMain.put("folioNo", mOldJsonObject.optString("folioNo"));
                objectMain.put("folioid", mOldJsonObject.optString("folioid"));
                objectMain.put("frequencyType", mSpFrequency.getSelectedItem().toString().toUpperCase());

                if(isNse2 && llStepUp.getVisibility() == View.VISIBLE && cbAddStepUp.isChecked()){
                    objectMain.put("isStepUp", true);
                    if(rbHalfYearly.isChecked())  objectMain.put("stepUpFreq",  "semi-annual" ); else  objectMain.put("stepUpFreq",  "annual" );
                    objectMain.put("stepUpAmt", etStepUpAmount.getText().toString().trim());
                    objectMain.put("stepUpStartDate", formatDateToYYYYMMDD(etStepUpStartDate.getText().toString()));
                }

                objectMain.put("schid", mSchemeId);
                if (mSession.getLoginType().equals("broker")) {
                    if (mJsonARNList.size() == 1) {
                        JSONObject folioObject = mJsonARNList.get(0);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    } else {
                        int position = mSpArn.getSelectedItemPosition();
                        if (position == 0)
                            objectMain.put("arnid", "");
                        else {
                            JSONObject folioObject = mJsonARNList.get(position - 1);
                            objectMain.put("arnid", folioObject.optString("arnid"));
                        }
                    }
                }else {
                    objectMain.put("arnid", "");
                }

                if (mEndDateOptionType.equalsIgnoreCase("instalment")) {
                    objectMain.put("noOfInstallment", mEtInstalments.getText().toString().trim());
                } else if (mEndDateOptionType.equals("maxDate")) {
                    objectMain.put("maxPeriod", true);
                }else {
                    objectMain.put("endDate", selectedEndDate);
                }

                if (mCheckboxPayNow.isChecked()) {
                    objectMain.put("firstOrderFlag", "Y");
                } else {
                    objectMain.put("firstOrderFlag", "N");
                }

                if (isNse2Value){
                    objectMain.put("nseInvestid", mBseId);
                    objectMain.put("nseUccCode", nseUccCode);
                }else {
                    // non validated bse additioanl flow
                    objectMain.put("uccNumber", mOldJsonObject.optString("uccNumber"));
                    if (mSession.getShowBseAuthPopup() && mCheckboxPayNow.isChecked()){
                        objectMain.put("loopbackUrl", loopBackUrl);
                        objectMain.put("paymentDetails",paymentDetails);
                        if (!isNse2 && rgPaymentOptions.getCheckedRadioButtonId() == R.id.rbLinkOnEmail)
                            objectMain.put("paymentMethod", "linkOnEmail");
                        else
                            objectMain.put("paymentMethod", "payNow");
                    }
                }
                if (isIgnoreDuplicate)
                    objectMain.put("ignoreDuplicate", "N");


            }
        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                if (mBar != null)
                    mBar.dismiss();
                try {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject mPlaceOderResponseObj = jsonObject.optJSONObject("result");

                       if (!isNse2Value){
                           if (!mSession.getShowBseAuthPopup()){
                               if (!mPlaceOderResponseObj.optString("status").equalsIgnoreCase("failed")) {
                                   // existing logic
                                   Bundle bundle = new Bundle();
                                   bundle.putString("bseid", mBseId);
                                   bundle.putString("payNowOptionType", "");
                                   bundle.putBoolean("firstPaymentNowBse", mCheckboxPayNow.isChecked());
                                   bundle.putString("amount", mEtAmount.getText().toString().trim());
                                   mPlaceOderResponseObj.put("ClientCode", mOldJsonObject.optString("uccNumber"));
                                   mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));

                                   bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                   bundle.putString("fundName", mFundName);
                                   Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                   intent.putExtras(bundle);
                                   startActivity(intent);

                               }else {

                                   Bundle bundle = new Bundle();
                                   bundle.putString("bseid", mBseId);
                                   bundle.putString("payNowOptionType", "");
                                   bundle.putBoolean("firstPaymentNowBse", mCheckboxPayNow.isChecked());
                                   bundle.putString("amount", mEtAmount.getText().toString().trim());
                                   bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                   bundle.putString("fundName", mFundName);
                                   Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                   intent.putExtras(bundle);
                                   startActivity(intent);
                               }
                           }else {
                               // new flow
                               if (mSession.getShowBseAuthPopup() && isValidated){
                                   // dismiss the popup
                                   if (popup.isVisible()){popup.dismiss();}
                                   Bundle mBundle = new Bundle();
                                   String orderNumber = "";
                                   if (!mPlaceOderResponseObj.optString("OrderNumber").equals("null") && !mPlaceOderResponseObj.optString("OrderNumber").equals("")) {
                                       orderNumber = mPlaceOderResponseObj.optString("OrderNumber");
                                   }
                                   else if (!mPlaceOderResponseObj.optString("orderNo").equals("null") && !mPlaceOderResponseObj.optString("orderNo").equals("")) {
                                       orderNumber = mPlaceOderResponseObj.optString("orderNo");
                                   }

                                   String paymentData = "";
                                   if (!mPlaceOderResponseObj.optString("paymentData").equals("null") && !mPlaceOderResponseObj.optString("paymentData").equals("")) {
                                       paymentData = mPlaceOderResponseObj.optString("paymentData");
                                   }
                                   String status = mPlaceOderResponseObj.optString("status");
                                   if(!isNse2 && mSession.getLoginType().equalsIgnoreCase("broker") && mPlaceOderResponseObj.has("bseLinkOnMail") && mPlaceOderResponseObj.optBoolean("bseLinkOnMail")){
                                       mBundle = new Bundle();
                                       mBundle.putString("type", "success");
                                       mBundle.putString("title", getString(R.string.payment_link_sent));
                                       mBundle.putString("mode", paymentMode);
                                       mBundle.putString("mTitle", orderNumber);
                                       mBundle.putString("mDescription", getString(R.string.payment_email_message, mPlaceOderResponseObj.optString("email")));
                                       mBundle.putBoolean("lottie", true);
                                       mBundle.putString("message", "");
                                       mBundle.putString("paymentData", paymentData);
                                       mBundle.putBoolean("bseLinkOnMail", true);
                                       popupSuccessOrFailed(mBundle);
                                   }
                                   else if (!paymentData.isEmpty() && !status.equals("failed")){
                                       mBundle = new Bundle();
                                       mBundle.putString("type", "success");
                                       mBundle.putString("title", "Payment");
                                       mBundle.putString("mode", paymentMode);
                                       mBundle.putString("mTitle", orderNumber);
                                       mBundle.putString("mDescription", getString(R.string.txt_bse_order_status_des));
                                       mBundle.putBoolean("lottie", true);
                                       mBundle.putString("message", mPlaceOderResponseObj.optString("amount"));
                                       mBundle.putString("paymentData", paymentData);
                                       popupSuccessOrFailed(mBundle);
                                       // open netbanking
                                       if (paymentMode.contains("Net Banking")){
                                           Intent netBankingContent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                                           netBankingContent.putExtra("title","Transaction");
                                           netBankingContent.putExtra("htmlContent",paymentData);
                                           netBankingContent.putExtra("endPointUrl", loopBackUrl);
                                           startActivity(netBankingContent);
                                       }

                                   }else if (!status.equals("failed") && mCheckboxPayNow.isChecked() && paymentData.equalsIgnoreCase("")){
                                       //
                                       mBundle = new Bundle();
                                       mBundle.putString("type","failed");
                                       mBundle.putString("title","Couldn't proceed with the payment");
                                       mBundle.putBoolean("lottie",true);
                                       mBundle.putString("message",getString(R.string.txt_bse_failed_order_message));
                                       popupSuccessOrFailed(mBundle);
                                   }else {
                                       // old screen failed
                                       mBundle = new Bundle();
                                       mBundle.putString("bseid", mBseId);
//                                    mBundle.putString("payNowOptionType", mPayNowOption);
                                       mBundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                       mBundle.putString("fundName", mFundName);
                                       mBundle.putString("amount", mEtAmount.getText().toString().trim());
                                       mBundle.putBoolean("isOtpValidated", true);
                                       Intent intent = new Intent(requireActivity(), BseOrderStatusActivity.class);
                                       intent.putExtras(mBundle);
                                       startActivity(intent);
                                   }
                               }else {
                                   // not validated
                                   showOTPAuth(
                                           true,
                                           mPlaceOderResponseObj.optString("provisionalOrderid"),
                                           paymentDetails,
                                           paymentMode,
                                           loopBackUrl
                                   );
                               }
                           }
                       }else {
                           Bundle bundle = new Bundle();
                           bundle.putString("nseInvestid", mBseId);
                           bundle.putString("payNowOptionType", "");
                           bundle.putString("amount", mEtAmount.getText().toString().trim());
                           mPlaceOderResponseObj.put("ClientCode", mOldJsonObject.optString("uccNumber"));
                           mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));
                           bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                           bundle.putString("fundName", mFundName);
                           Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                           intent.putExtras(bundle);
                           startActivity(intent);
                       }
                    } else if (jsonObject.optInt("status") == -1) {
                        String message = jsonObject.optString("message");
                        if (message.contains("order already exists")) {
                            orderExistsDailog();
                        } else {
                            appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                        }

                    } else if (jsonObject.optInt("status") == 3) {
                        String message = jsonObject.optString("message");
                        if (message.contains("order already exists")) {
                            orderExistsDailog();
                        } else {
                            appApplication.showCommonDailog(getActivity(), "Failed", message, "message");
                        }
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void popupSuccessOrFailed( Bundle dataBunndle){
        FullScreenPaymentStatus popup = new FullScreenPaymentStatus();
        popup.setArguments(dataBunndle);
        popup.onValidateButtonClick(bundle -> {
            // show my orders
            popup.dismiss();
            Intent intent = new Intent(requireActivity(), MyOrdersActivity.class);
            startActivity(intent);
//            finish()
            return null;
        });
        popup.show(requireActivity().getSupportFragmentManager(), "FullScreenPopup");

    }


    private void showOTPAuth(
            boolean mIsIgnoreDuplicate,
            String mProvisionalOrderid,
            JSONObject mPaymentDetails,
            String mMode,
            String mLoopbackUrl
    ){
        popup = new FullScreenBsePopUpDialog();
        Bundle bundle = new Bundle();
        bundle.putString("profileData",profileObject.toString());
        bundle.putString("purchaseType","SIP");
        bundle.putString("funname",mSchemeName);
        bundle.putBoolean("ispurchase",false);
        bundle.putString("mProvisionalOrderid", mProvisionalOrderid);
        bundle.putString("mode", mMode);
        popup.setArguments(bundle);
        popup.onValidateButtonClick(new Function1<Bundle, Unit>() {
            @Override
            public Unit invoke(Bundle bundle) {
                // place order by otp
                try {
                    // place order by otp
                    String mOtp = bundle.getString("otp");
                    placeSIP(
                            mIsIgnoreDuplicate,
                            mOtp,
                            true,
                            mProvisionalOrderid,
                            mMode,
                            mLoopbackUrl,
                            mPaymentDetails,
                            false
                    );

                } catch (Exception e) {}

                return null;
            }
        });
        popup.show(requireActivity().getSupportFragmentManager(),"FullScreenPopup");
    }


    private void orderExistsDailog() {
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    if (isNse2){
                        placeSIP(
                                true,
                                "",
                                false,
                                "",
                                "",
                                "",
                                new JSONObject(),
                                true
                        );
                    }else {
                        if (mSession.getShowBseAuthPopup()) {
                            Bundle mbBundle = new Bundle();
                            bottomPaymentMode = BottomScreenPaymentMode.create(
                                    requireActivity(),
                                    R.style.ModalBottomSheetDialog,
                                    mbBundle
                            );
                            bottomPaymentMode.setListener(this);
                            bottomPaymentMode.show();
                        }else{
                            placeSIP(
                                    true,
                                    "",
                                    false,
                                    "",
                                    "",
                                    "",
                                    new JSONObject(),
                                    false
                            );
                        }
                    }
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(getActivity(), getString(R.string.alert_dialog_order_exist_header_txt),
                getString(R.string.alert_dialog_order_exist_message_txt),
                getString(R.string.alert_dialog__order_exist_button1),
                getString(R.string.alert_dialog__order_exist_button2),
                true, true);
    }

    private void setMandateInSpinner() {
        boolean isShowAllMandate = false;
        ArrayList<String> list = new ArrayList<>();
        final ArrayList<JSONObject> newMandateList = new ArrayList<>();
        if(mMandateList.isEmpty())
        {
            list.add("No Mandate Available");
        } else {
            list.add(getString(R.string.select_mandate));
            try {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
                Date currentDate = simpleDateFormat.parse(selectedStartDate);

                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.DATE, 30);
                Date date = calendar.getTime();
                long difference = currentDate.getTime() - date.getTime();
                long days = (difference / (60 * 60 * 24 * 1000));
                if (days >= 30) {
                    isShowAllMandate = true;
                }
            } catch (Exception e) {

            }

            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
            format.setMinimumFractionDigits(0);
            format.setMaximumFractionDigits(0);

            for (int i = 0; i < mMandateList.size(); i++) {
                JSONObject jsonObject = mMandateList.get(i);
                String bankName = jsonObject.optString("bankName");
                String accountNo = jsonObject.optString("accountNo");
                String maskAccountNumber = accountNo.replaceAll("\\w(?=\\w{4})", "X");

                String mandateAmount = format.format(new BigDecimal(jsonObject.optString("mandateAmount")));

                String fullLine = mandateAmount + " - " + bankName + " (" + maskAccountNumber + ")";
                if (jsonObject.optString("status").equalsIgnoreCase("pending")) {
                    fullLine = fullLine + " Pending";
                }
                list.add(fullLine);
                newMandateList.add(jsonObject);

                // web and ios showing pending mandate
        /*    if (jsonObject.optString("status").equals("APPROVED")) {
                String bankName = jsonObject.optString("bankName");
                String accountNo = jsonObject.optString("accountNo");
                String maskAccountNumber = accountNo.replaceAll("\\w(?=\\w{4})", "X");

                String mandateAmount = format.format(new BigDecimal(jsonObject.optString("mandateAmount")));

                String fullLine = mandateAmount + " - " + bankName + " (" + maskAccountNumber + ")";
                list.add(fullLine);
                newMandateList.add(jsonObject);
            } else {
                if (isShowAllMandate) {
                    String bankName = jsonObject.optString("bankName");
                    String accountNo = jsonObject.optString("accountNo");
                    String maskAccountNumber = accountNo.replaceAll("\\w(?=\\w{4})", "X");

                    String mandateAmount = format.format(new BigDecimal(jsonObject.optString("mandateAmount")));

                    String fullLine = mandateAmount + " - " + bankName + " (" + maskAccountNumber + ")";
                    list.add(fullLine);
                    newMandateList.add(jsonObject);
                }
            }*/
            }
        }


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        mSpMandate.setAdapter(dataAdapter);

        mSpMandate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int selectedPostion, long l) {
                if (selectedPostion > 0) {
                    JSONObject jsonObject = newMandateList.get(selectedPostion - 1);
                    mSelectedMandateId = jsonObject.optString("id");
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                System.out.println();
            }
        });


    }

    private void getMendateList(String mBseIdP,boolean isSelected) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
//        String month = mMonthListNumber.get(mSpMonth.getSelectedItemPosition());
//        mSeletedDate = mSpYear.getSelectedItem().toString() + "-" + month
//                + "-" + mSpDate.getSelectedItem().toString();
//
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, 2);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        String date = simpleDateFormat.format(cal.getTime());


        try {
            if (isNse2){
                String marnId ="";
                if (mSession.getLoginType().equals("broker")) {
                    if (mJsonARNList.size() == 1) {
                        JSONObject folioObject = mJsonARNList.get(0);
                        marnId = folioObject.optString("arnid");
                    } else {
                        int position = mSpArn.getSelectedItemPosition();
                        if (position == 0)
                            marnId ="";
                        else {
                            JSONObject folioObject = mJsonARNList.get(position - 1);
                            marnId = folioObject.optString("arnid");
                        }
                    }
                }else {
                    marnId ="";
                }

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_PREPARE_ORDER_DATA_NSE2 + "nseInvestid=" + mBseIdP+"&nseUccCode="+nseUccCode+"&schid="+mSchemeId+"&txnType=ADDITIONAL"
                        + "&approvedMandates=false&getBanks=true&arnid="+marnId+"&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);
            }else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.GET_MANDATE_LIST + "bseid=" + mBseIdP
                        + "&paymentDate=" + date+"&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);
            }

          url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = decodeUrl(url);

        } catch (Exception e) {

        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                if (isSelected){
                                    mMandateList.clear();
                                }
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                if (isNse2) {
                                    // NSE2 Logic: Mandates are in the "mandates" array
                                    JSONArray mandateArray = jsonObject1.optJSONArray("mandates");
                                    if (mandateArray != null && mandateArray.length() > 0) {
                                        for (int i = 0; i < mandateArray.length(); i++) {
                                            mMandateList.add(mandateArray.optJSONObject(i));
                                        }
                                        mTvCreateMandate.setVisibility(View.GONE);
                                    }
                                    else{
                                        mMandateList.clear();
                                        mTvCreateMandate.setVisibility(View.VISIBLE);
                                        setMandateInSpinner();
                                    }
                                }else{
                                    JSONArray jsonArray = jsonObject1.optJSONArray("data");
                                    if (jsonArray.length() > 0) {
                                        for (int i = 0; i < jsonArray.length(); i++) {
                                            mMandateList.add(jsonArray.optJSONObject(i));
                                        }
                                    } else {
                                    /* never show as per ios Dharmendra
                                    if (isSelected){
                                        showMandateErrorDailog();
                                    }*/
                                        mMandateList.clear();
                                        mTvCreateMandate.setVisibility(View.VISIBLE);
                                        setMandateInSpinner();
                                    }
                                }
                                if (mMandateList.size() > 0 || isSelected) {
                                    setMandateInSpinner();
                                }

                            }else {
                                mAppplication.showCommonDailog(
                                        requireActivity(),
                                        getString(R.string.alert_dialog_header_txt),
                                        jsonObject.optString("message"),
                                        "message"
                                );
                                showSnackbar(
                                        transact_btn,
                                        jsonObject.optString("message"),
                                        Snackbar.LENGTH_SHORT,
                                        2000L
                                        );

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getBSEID() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";
        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_BSEID + "arnid="
                    + mOldJsonObject.optString("lastTxnArnid")
                    + "&uccNumber=" + mOldJsonObject.optString("uccNumber") +
                    "&appid=" + mOldJsonObject.optString("appid")+"&selectedUser="+Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = decodeUrl(url);
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.optJSONArray("data");
                                mBseObject = jsonArray.optJSONObject(0);
                                // getMendateList(mBar);

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getSchemes(String fundId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        String url = "";
        try{
            String varableForBSeMfu ="";
            if(isNse2) varableForBSeMfu ="&hasNseInvestCode=true"; else varableForBSeMfu ="&hasBseCode=true";
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_FUND_SCHEAMES + "fundid=" + fundId + "&exchange="+mExchange +varableForBSeMfu
                    + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        }catch (Exception e){

        }



        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    mSchemeList.add(jsonArray.optJSONObject(i));
                                }
                                showSchemesDailog();

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getSchemeNSEInfo() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        try {
            String nseBseCode="";
            if (isNse2){
                nseBseCode ="&hasNseInvestCode=true";
            }else {
                nseBseCode="&hasBseCode=true";
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TRANSECTION_TYPE +
                    "schid=" +mSchemeId+
                    nseBseCode+
                    "&bid=" + mSession.getBid() +
                    "&levelid=" + mSession.getLevelId() +
                    "&exchange="+mExchange +
                    "&systematicDetails=true" +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = decodeUrl(url);


        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                tranJsonObject = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = tranJsonObject.optJSONArray("allowedInvestmentTypes");
                                if (jsonArray.toString().contains(mTransactionType)) {

                                    mJsonObjNseInfo = jsonObject.optJSONObject("result");
                                    allowedNseStepUp = isNse2 && mJsonObjNseInfo != null && mJsonObjNseInfo.optBoolean("allowedStepUp",false);
                                    if (mJsonObjNseInfo != null) {
                                        sipObject = mJsonObjNseInfo.optJSONObject("sip");
                                        mFrequencyList = new ArrayList<>();
                                        if (sipObject != null) {

                                            JSONArray jsonArrayFrequency = sipObject.optJSONArray("frequencies");

                                            if (jsonArrayFrequency != null) {
                                                for (int i = 0; i < jsonArrayFrequency.length(); i++) {
                                                    String freq = jsonArrayFrequency.optString(i);
                                                    mFrequencyList.add(firstLetterCapitalOfSentence(freq));
                                                }
                                            }


                                        }
                                        setFrequently();
//                                        else {
//                                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
//                                            appApplication.showCommonDailog(
//                                                    requireActivity(),
//                                                    getString(R.string.no_data_available),
//                                                    getString(R.string.txt_frequency_not_available),
//                                                    "message"
//                                            );
//                                            llafterSchemeSelection.setVisibility(View.GONE);
//                                        }
                                    }

                                } else {
                                    mObjNewScheme = null;
                                    showErrorDailog();
                                }

                            } else if (jsonObject.optInt("status") == -1) {
                                mAppplication.showCommonDailog(
                                        requireActivity(),
                                        getString(R.string.alert_dialog_header_txt),
                                        jsonObject.optString("message"),
                                        "message"
                                );
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void showErrorDailog() {
        CustomDialog customDialog = new CustomDialog(new CustomDialog.DialogBtnCallBack() {
            @Override
            public void onDialogBtnClick(View view) {
                if (view.getId() == R.id.btDone) {
                        //  mActivity.getSupportFragmentManager().popBackStack();
}
else if (view.getId() == R.id.btCalcel) {
}
            }
        });

        customDialog.showDialog(mActivity, getString(R.string.alert_dialog_error_txt),
                getString(R.string.alert_dialog_message_purchase_not_allowed),
                getString(R.string.alert_dialog_btn_txt),
                "",
                true, false);
    }


    private void showMandateErrorDailog() {
        CustomDialog customDialog = new CustomDialog(new CustomDialog.DialogBtnCallBack() {
            @Override
            public void onDialogBtnClick(View view) {
                if (view.getId() == R.id.btDone) {
                        mActivity.getSupportFragmentManager().popBackStack();
}
else if (view.getId() == R.id.btCalcel) {
}
            }
        });

        customDialog.showDialog(mActivity, getString(R.string.alert_dialog_error_txt),
                getString(R.string.mendate_list_no_mandate_found_txt),
                getString(R.string.alert_dialog_btn_txt),
                "",
                true, false);
    }


    public String formatMonth(String month) {
        String strMonth = "";
        SimpleDateFormat monthParse = new SimpleDateFormat("MM");
        SimpleDateFormat monthDisplay = new SimpleDateFormat("MMM");
        try {
            strMonth = monthDisplay.format(monthParse.parse(month));

        } catch (ParseException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        return strMonth;
    }

    private void showSchemesDailog() {
        final Dialog dialog = new Dialog(mActivity);
        dialog.setContentView(R.layout.change_scheme);
        final Spinner mSchemeSpinner = dialog.findViewById(R.id.scheme);
        Button mSubmitBtn = dialog.findViewById(R.id.submit_btn);

        ArrayList<String> list = new ArrayList<>();
        list.add(0, getString(R.string.select_scheme));
        for (int i = 0; i < mSchemeList.size(); i++) {
            JSONObject jsonObject = mSchemeList.get(i);
            String data = jsonObject.optString("name");
            list.add(data);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        mSchemeSpinner.setAdapter(dataAdapter);


        mSchemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int selectedPostion, long l) {
                if (selectedPostion > 0) {
                    mObjNewScheme = mSchemeList.get(selectedPostion - 1);
                    mSchemeId = Utils.getSchemeIdFromAll(mObjNewScheme);
                    mSchemeName = mObjNewScheme.optString("name");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mObjNewScheme != null) {
                    mSchemeGroupId = mObjNewScheme.optString("schemeGroupId");
                    mTvcardview_top_name_color.setText(mObjNewScheme.optString("name"));
                    getInvestmentType();
                    applyDefaultButtonState();
//                    getSchemeNSEInfo();
                }

                dialog.dismiss();
            }
        });


        dialog.findViewById(R.id.close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
    }


    @Override
    public void onDataReturned(@Nullable Bundle resultBundle) {
        try {
//            val mOtp =resultBundle?.getString("otp")!!
            String mOrderId =resultBundle.getString("orderid");
            String loopbackUrl =resultBundle.getString("loopbackUrl");
            String mode =resultBundle.getString("mode");
            JSONObject paymentDetails = new JSONObject(resultBundle.getString("paymentDetails"));
            bottomPaymentMode.dismiss();
            placeSIP(
                    true,
                    "",
                    false,
                    "",
                    mode,
                    loopbackUrl,
                    paymentDetails,
                    false
            );

        }catch (Exception e){}
    }

    private void insertTxnInNseOrBseCart() {
        ProgressBarCommon.showDialog(mActivity);

        JSONObject objectMain = new JSONObject();
        try {
            objectMain.put("type", "purchase"); // static
            if(isNse2 )
                objectMain.put("exchange", "4");
            else
                objectMain.put("exchange", "2");
            objectMain.put("subType", "SIP");
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));

            JSONObject itemObject = getItemObject();
            objectMain.put("item", itemObject);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.INSERT_NSE_BSE_CART_ITEM;

        new ApiClient(mActivity, mSession).makeJsonPostRequest(
                url,
                objectMain,
                it -> {
                    if (it) {
                        ProgressBarCommon.showDialog(mActivity);
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                },
                response -> {
                    try {
                        if (response.optInt("status") == 0) {
                            addToCartBtnClicked();
                            Toast.makeText(mActivity,getString(R.string.added_successfully), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mActivity,response.optString("message"),Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception ignored) {
                    }
                    return null;
                },
                error -> {
                    UtilityKotlin.parseVolleyError(error, mSession, mActivity, "");
                    return null;
                },
                code -> {
                    if (code == 401) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(
                                mActivity,
                                getString(R.string.txt_session_expired),
                                getString(R.string.txt_please_login_again_for_continue),
                                "sessionExpired"
                        );
                    }
                    return null;
                }
        );
    }
    private JSONObject getItemObject() {
        JSONObject itemObject = new JSONObject();

        try {
            // Folio
            itemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            itemObject.put("folioid", mOldJsonObject.optString("folioid"));

            itemObject.put("txnType", "ADDITIONAL");
            if(isNse2) {
                itemObject.put("nseInvestid", mBseId);
                itemObject.put("nseUccCode", nseUccCode);
            }
            else{
                itemObject.put("uccNumber", uccNumber);
                itemObject.put("bseid", mBseId);
            }
            // ARN handling
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    itemObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        itemObject.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        itemObject.put("arnid", folioObject.optString("arnid"));
                    }
                }
            }else {
                itemObject.put("arnid", "");
            }

            itemObject.put("investmentType", mSchemeType);

            if (llDividentFreqSip.getVisibility() == View.VISIBLE) {
                itemObject.put("divFrequency",  String.valueOf(spDivedentFrequencySip.getSelectedItemPosition()));
            }

            //mJsonDividend
            itemObject.put("schid", mSchemeId);
            itemObject.put("schemeName", mSchemeName);
            itemObject.put("amount", mEtAmount.getText().toString());

            if (mCheckboxPayNow.isChecked()) {
                itemObject.put("firstOrderFlag", "Y");
            } else {
                itemObject.put("firstOrderFlag", "N");
            }
            itemObject.put("startDate", selectedStartDate);

            if( isNse2 && llStepUp.getVisibility() == View.VISIBLE && cbAddStepUp.isChecked()){
                itemObject.put("isStepUp", true);
                if(rbHalfYearly.isChecked())  itemObject.put("stepUpFreq",  "semi-annual" ); else  itemObject.put("stepUpFreq","annual" );
                itemObject.put("stepUpAmt", etStepUpAmount.getText().toString().trim());
                itemObject.put("stepUpStartDate", formatDateToYYYYMMDD(etStepUpStartDate.getText().toString()));
            }

            if (mEndDateOptionType.equalsIgnoreCase("instalment")) {
                itemObject.put("noOfInstallment", mEtInstalments.getText().toString().trim());
            } else if (mEndDateOptionType.equals("maxDate")) {
                itemObject.put("maxPeriod", true);
            }else {
                itemObject.put("endDate", selectedEndDate);
            }

            itemObject.put("mandateid", mSelectedMandateId);

            itemObject.put("frequencyType", mSpFrequency.getSelectedItem().toString().toLowerCase());




        } catch (Exception e) {
            e.printStackTrace();
        }

        return itemObject;
    }

    private void addToCartBtnClicked() {
        Utils.hideKeyboard(mActivity);

        if (tvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {

            transact_btn.setVisibility(View.GONE);
            tvCart.setText(getString(R.string.go_to_cart));

        } else {
            transact_btn.setVisibility(View.VISIBLE);
            tvCart.setText(getString(R.string.add_to_cart));
        }
    }
    private void transactNowBtnClicked() {
        Utils.hideKeyboard(requireActivity());

        if (transact_btn.getText().toString().equalsIgnoreCase(getString(R.string.TransactNow))) {

            tvCart.setVisibility(View.GONE);
            llPaymentOptions.setVisibility(View.VISIBLE);
            transact_btn.setText(getString(R.string.Choose_Payment_Mode));

        } else if (transact_btn.getText().toString().equalsIgnoreCase(getString(R.string.Choose_Payment_Mode))) {

            boolean isLinkOnEmailChecked = rgPaymentOptions.getCheckedRadioButtonId() == R.id.rbLinkOnEmail;

                Bundle bundle = new Bundle();
                bundle.putString("mBseId", mBseId);
                bundle.putBoolean("isLinkOnEmailSelected", isLinkOnEmailChecked);

                bottomPaymentMode = BottomScreenPaymentMode.create(requireActivity(), R.style.ModalBottomSheetDialog, bundle);
                mEtAmount.clearFocus();
                bottomPaymentMode.setListener(this);
                bottomPaymentMode.show();

        } else {
            if (isAddToCartBseEnabled) {
                tvCart.setVisibility(View.VISIBLE);
                llPaymentOptions.setVisibility(View.GONE);
                transact_btn.setText(getString(R.string.TransactNow));
            }
        }
    }

    private void applyDefaultButtonState() {
        isAddToCartNseInvestEnabled = checkFeaturePermissionsOnOff(mSession, "feature1053", Permissions.ADD);
        isAddToCartBseEnabled = checkFeaturePermissionsOnOff(mSession, "feature1043", Permissions.ADD);

        transact_btn.setVisibility(View.VISIBLE);
        setTextOfPaymentButton();

        boolean visible = (isNse2 && isAddToCartNseInvestEnabled) || (!isNse2 && mSession.getShowBseAuthPopup() && isAddToCartBseEnabled);
        tvCart.setVisibility(visible ? View.VISIBLE : View.GONE);
        tvCart.setText(getString(R.string.add_to_cart));

        llPaymentOptions.setVisibility(View.GONE);
        rgPaymentOptions.clearCheck();
    }
    private void setTextOfPaymentButton() {

        if (!isNse2 && mSession.getShowBseAuthPopup() && mCheckboxPayNow.isChecked()) {
            if (mSession.getLoginType().equals("broker"))
                transact_btn.setText(getString(R.string.TransactNow));
            else
                transact_btn.setText(getString(R.string.Choose_Payment_Mode));
        } else
            transact_btn.setText(getString(R.string.place_order));
    }


}






