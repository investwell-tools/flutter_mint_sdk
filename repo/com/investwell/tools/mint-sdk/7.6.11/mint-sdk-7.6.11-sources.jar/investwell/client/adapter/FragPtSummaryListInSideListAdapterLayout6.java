package investwell.client.adapter;

/**
 * Created by Binesh on 24-04-2021.
 */

import android.content.Context;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class FragPtSummaryListInSideListAdapterLayout6 extends RecyclerView.Adapter<FragPtSummaryListInSideListAdapterLayout6.ItemRowHolder> {
    private ArrayList<JSONObject> dataList;
    private Context mContext;
    private NumberFormat format;
    private AppSession mSession;
    private String mClient = "";
    private AppApplication mAppplication;
    private boolean AreAllExpanded;
    private boolean[] AreAllExpandedArray;

    public interface OnAllCardsCollapsedListener {
        void onAllFlxFormCardsCollapsed();
        void onAllFlxFormCardsExpanded();
    }

    private OnAllCardsCollapsedListener listener;

    // Provide a method to set the listener
    public void setOnAllCardsCollapsedListener(OnAllCardsCollapsedListener listener) {
        this.listener = listener;
    }


    public FragPtSummaryListInSideListAdapterLayout6(Context context, ArrayList<JSONObject> dataList) {
        this.dataList = dataList;
        this.mContext = context;

        format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
        mSession = AppSession.getInstance(mContext);
        mAppplication = (AppApplication) context.getApplicationContext();
    }

    @Override
    public ItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.pt_primary_scheme_item_layout6, viewGroup, false);

        //  View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_item_market, null);
        ItemRowHolder mh = new ItemRowHolder(view);
        return mh;
    }

    @Override
    public void onBindViewHolder(ItemRowHolder itemRowHolder, int i) {

        JSONObject jsonObject = dataList.get(i);
        itemRowHolder.tvHeader1.setText(jsonObject.optString("name"));
        if (jsonObject.optString("name").equalsIgnoreCase("debt")){
            itemRowHolder.ivFundType.setImageResource(R.mipmap.home3_debt);
          //  itemRowHolder.mViewLine.getBackground().setColorFilter(ContextCompat.getColor(mContext, R.color.layout3_debt), PorterDuff.Mode.SRC_OVER);
        }else if (jsonObject.optString("name").equalsIgnoreCase("equity")){
            itemRowHolder.ivFundType.setImageResource(R.mipmap.home3_equity);
            //itemRowHolder.mViewLine.getBackground().setColorFilter(ContextCompat.getColor(mContext, R.color.layout3_equity), PorterDuff.Mode.SRC_OVER);
        }else if (jsonObject.optString("name").equalsIgnoreCase("hybrid")){
            itemRowHolder.ivFundType.setImageResource(R.mipmap.home3_hybrid);
          //  itemRowHolder.mViewLine.getBackground().setColorFilter(ContextCompat.getColor(mContext, R.color.layout3_hybrid), PorterDuff.Mode.SRC_OVER);
        }else if (jsonObject.optString("name").equalsIgnoreCase("liquid and ultra short")){
            itemRowHolder.ivFundType.setImageResource(R.mipmap.home3_liquid);
           // itemRowHolder.mViewLine.getBackground().setColorFilter(ContextCompat.getColor(mContext, R.color.layout3_liquid), PorterDuff.Mode.SRC_OVER);
        }else if (jsonObject.optString("name").equalsIgnoreCase("arbitrage")){
            itemRowHolder.ivFundType.setImageResource(R.mipmap.home3_artbitrage);
          //  itemRowHolder.mViewLine.getBackground().setColorFilter(ContextCompat.getColor(mContext, R.color.layout3_arbitrage), PorterDuff.Mode.SRC_OVER);
        }else{
            itemRowHolder.ivFundType.setImageResource(R.mipmap.home3_others);
          //  itemRowHolder.mViewLine.getBackground().setColorFilter(ContextCompat.getColor(mContext, R.color.layout3_other_color), PorterDuff.Mode.SRC_OVER);
        }

        JSONObject jsonObjectSummary = jsonObject.optJSONObject("summary");
        if (jsonObjectSummary!=null) {
            double currentValue2 = jsonObjectSummary.optDouble("currentValue");
            String strCurrentAmount2 = format.format(currentValue2);
            itemRowHolder.tvCurrent.setText(strCurrentAmount2);



            // double cgrValue2 = jsonObjectSummary.optDouble("CAGR");
            // String dataCAgr = String.format("%.2f", cgrValue2) + "%";

            //double totalGainTop = jsonObjectSummary.optDouble("gain");
            // String gainValue = format.format(totalGainTop);
            // String finalValue = gainValue + " (" + dataCAgr + ")";
            // itemRowHolder.tvOneDayChange.setText(finalValue);
//            itemRowHolder.flxform.setVisibility(View.VISIBLE);
            AreAllExpandedArray[i] = AreAllExpanded;
            if(AreAllExpanded)
            {
                itemRowHolder.flxform.setVisibility(View.VISIBLE);
                itemRowHolder.ivExpand.setImageResource(R.mipmap.home3_up_arrow);
            }
            else
            {
                itemRowHolder.flxform.setVisibility(View.GONE);
                itemRowHolder.ivExpand.setImageResource(R.mipmap.home3_down_arrow);
            }


            if (mSession.getHasShowXirr()) {
                itemRowHolder.llXirrHeaderView.setVisibility(View.VISIBLE);
                itemRowHolder.llCagrTopCardView.setVisibility(View.GONE);
              //  itemRowHolder.tvOneDayChange.setVisibility(View.GONE);

                if (mSession.getHideXirr().equals("0")) {
                    itemRowHolder.llXirrValue.setVisibility(View.VISIBLE);

                    UtilityKotlin.safeDisplayXirrPercentValue(
                            jsonObjectSummary,
                            "XIRR",
                            "-",
                            "%",
                            2,
                            true,
                            itemRowHolder.tvXirrHeader,
                            false,
                            R.color.green2,
                            R.color.red_2,
                            R.color.black
                            );

                } else {
                    itemRowHolder.llXirrValue.setVisibility(View.GONE);
                }

                double totalGain = jsonObjectSummary.optDouble("gain");
                String gainValueStr = format.format(totalGain);
                itemRowHolder.tvXirrGainHeader.setText(gainValueStr);
                if (totalGain > 0) {
                    itemRowHolder.tvXirrGainHeader.setTextColor(ContextCompat.getColor(mContext, R.color.green2));
                } else {
                    itemRowHolder.tvXirrGainHeader.setTextColor(ContextCompat.getColor(mContext, R.color.red_2));
                }

            } else {
                itemRowHolder.llXirrHeaderView.setVisibility(View.GONE);
                itemRowHolder.llCagrTopCardView.setVisibility(View.VISIBLE);

                double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                String strPurchaseValue = format.format(purchaseValue);
                itemRowHolder.tvPurchaseValue.setText(strPurchaseValue);

                double gain = jsonObjectSummary.optDouble("gain");
                Utils.checkNegativeAndPositiveValueLayout6(itemRowHolder.tvGain,gain,mContext);

                double cgrValue = jsonObjectSummary.optDouble("CAGR");
                Utils.checkNegativeAndPositivePercentageDarkGreenLayout6(itemRowHolder.tvCagr, cgrValue, mContext);

               /* double cgrValue = jsonObjectSummary.optDouble("CAGR");
                String data2 = String.format("%.2f", cgrValue) + "%";
                double totalGain = jsonObjectSummary.optDouble("gain");
                String gainValueStr = format.format(totalGain);
                String finalValueStr = gainValueStr + " (" + data2 + ")";
                itemRowHolder.tvCagrGainValue.setText(finalValueStr);
                if (totalGain > 0) {
                    itemRowHolder.tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                } else {
                    itemRowHolder.tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                }
*/

            }

            if(mAppplication.isDaysChange) {
                double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                String oneDayStr = format.format(oneDayChange);
                double changePercent = jsonObjectSummary.optDouble("changePercent");
                String changePercentStr = String.format("%.2f", changePercent) + "%";
                String finalOneDayChange = oneDayStr + " (" + changePercentStr + ")";
                itemRowHolder.tvOneDayChange.setText(finalOneDayChange);
                itemRowHolder.tvOneDayChange.setVisibility(View.VISIBLE);
                if (oneDayChange == 0) {
                    itemRowHolder.tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black_white));
                }else if (oneDayChange > 0) {
                    itemRowHolder.tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.green2));
                } else {
                    itemRowHolder.tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red_2));
                }
            }else{
                itemRowHolder.tvOneDayChange.setVisibility(View.INVISIBLE);
            }


            // TODO: mf bazaar
            if (mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")){
                itemRowHolder.flxform.setVisibility(View.GONE);
                itemRowHolder.ivExpand.setImageResource(R.mipmap.home3_down_arrow);
            }
            itemRowHolder.llTopCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (itemRowHolder.flxform.getVisibility() == View.VISIBLE) {
                        itemRowHolder.flxform.setVisibility(View.GONE);
                        itemRowHolder.ivExpand.setImageResource(R.mipmap.home3_down_arrow);
                        AreAllExpandedArray[i] = false;
                        checkIfAllFlxCardCollapsed(itemRowHolder);
                    } else {
                        itemRowHolder.flxform.setVisibility(View.VISIBLE);
                        itemRowHolder.ivExpand.setImageResource(R.mipmap.home3_up_arrow);
                        AreAllExpandedArray[i]= true;
                        checkIfAllFlxCardExpanded(itemRowHolder);
                    }
                }
            });


            itemRowHolder.flxform.removeAllViews();

            JSONArray jsonArray = jsonObject.optJSONArray("data");
            for (int j = 0; j < jsonArray.length(); j++) {
                View child = View.inflate(mContext, R.layout.pt_secondry_scheme_item_layout6, null);
                TextView tvSchemeName = child.findViewById(R.id.tvSchemeName);
                TextView tvFolio = child.findViewById(R.id.tvFolio);
                TextView tvMarketValue = child.findViewById(R.id.tvMarketValue);
                TextView tvDividentInt = child.findViewById(R.id.tvDividentInt);

                TextView tvGain = child.findViewById(R.id.tvGain);
                TextView tvCagr = child.findViewById(R.id.tvCagr);
                TextView tvPurchaseValue = child.findViewById(R.id.tvPurchaseValue);
                TextView tvAverageDays = child.findViewById(R.id.tvAverageDays);
                TextView tvAbsReturn = child.findViewById(R.id.tvAbsReturn);
                TextView tvOneDayChange = child.findViewById(R.id.tvOneDayChange);
                LinearLayout llLine3 = child.findViewById(R.id.llLine3);
                RelativeLayout llLine4 = child.findViewById(R.id.llLine4);
                TextView tvPurchaseLevel = child.findViewById(R.id.tvPurchaseLevel);
                TextView tvCagrLavel = child.findViewById(R.id.tvCagrLavel);
                LinearLayout llDividend = child.findViewById(R.id.llDividend);

                JSONObject innerObject = jsonArray.optJSONObject(j);

                tvSchemeName.setText(innerObject.optString("schemeName"));
                if (mSession.getHasShowXirr()) {
                    llLine3.setVisibility(View.GONE);
                    llLine4.setVisibility(View.GONE);
                    tvCagrLavel.setText(mContext.getString(R.string.overall_gain));
                    if (mSession.getHideXirr().equals("0")) {
                        tvPurchaseLevel.setText(mContext.getString(R.string.XIRR));
                    } else {
                        tvPurchaseLevel.setVisibility(View.GONE);
                        tvPurchaseValue.setVisibility(View.GONE);
                    }
                    tvFolio.setText("[" + innerObject.optString("folioNo") + "]");

                    UtilityKotlin.safeDisplayXirrPercentValue(
                            innerObject,
                            "XIRR",
                            "-",
                            "%",
                            2,
                            true,
                            tvPurchaseValue,
                            false,
                            R.color.green2,
                            R.color.red_2,
                            R.color.black
                            );


                    double gain = innerObject.optDouble("gain");
                    Utils.checkNegativeAndPositiveValueLayout6(tvGain,gain,mContext);


                  /*  double gain = innerObject.optDouble("gain");
                    String gainStr = format.format(gain);
                    tvCagrGainValue.setText(gainStr);

                    if (gain > 0) {
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    } else {
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }*/

                    double currentValue = innerObject.optDouble("currentValue");
                    String currentValueStr = format.format(currentValue);
                    tvMarketValue.setText(currentValueStr);

                    double changePercent2 = innerObject.optDouble("changePercent");
                    String changePercentStr2 = String.format("%.2f", changePercent2) + "%";

                    if(mAppplication.isDaysChange) {
                        double oneDayChange2 = innerObject.optDouble("oneDayChange");
                        String oneDayChange2Str = format.format(oneDayChange2);
                        String finalValueStr2 = oneDayChange2Str + " (" + changePercentStr2 + ")";
                        tvOneDayChange.setText(finalValueStr2);
                        tvOneDayChange.setVisibility(View.VISIBLE);
                        if (oneDayChange2 == 0) {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black_white));
                        }else if (oneDayChange2 > 0) {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.green2));
                        } else {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red_2));
                        }
                    }else{
                        tvOneDayChange.setVisibility(View.INVISIBLE);
                    }


                } else {
                    llLine3.setVisibility(View.VISIBLE);
                    llLine4.setVisibility(View.VISIBLE);
                    tvCagrLavel.setText(mContext.getString(R.string.gain_cgr));
                    tvPurchaseLevel.setText(mContext.getString(R.string.purchase_value));
                    JSONObject schemeSummary = innerObject.optJSONObject("summary");

                    double purchaseValue = schemeSummary.optDouble("purchaseValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvPurchaseValue.setText(strPurchaseValue);

                    double dividend = schemeSummary.optDouble("dividend");
                    if (dividend > 0) {
                        String strdividend = format.format(dividend);
                        tvDividentInt.setText(strdividend);
                        llDividend.setVisibility(View.VISIBLE);
                    } else {
                        llDividend.setVisibility(View.GONE);
                    }

                    double gain = schemeSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValueLayout6(tvGain,gain,mContext);

                    double cgrValue = schemeSummary.optDouble("CAGR");
                    Utils.checkNegativeAndPositivePercentageDarkGreenLayout6(tvCagr, cgrValue, mContext);

                  /*  double cgrValue = schemeSummary.optDouble("CAGR");
                    String data2 = String.format("%.2f", cgrValue) + "%";
                    double totalGain = schemeSummary.optDouble("gain");
                    String gainValueStr = format.format(totalGain);
                    String finalValueStr = gainValueStr + " (" + data2 + ")";
                    tvCagrGainValue.setText(finalValueStr);
                    if (totalGain > 0) {
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    } else {
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }
*/
                    try {
                        double avgHoldingDays = schemeSummary.optDouble("avgHoldingDays");
                        long rounded = Math.round(avgHoldingDays);
                        int days = (rounded <= Integer.MAX_VALUE) ? (int) rounded : Integer.MAX_VALUE;
                        tvAverageDays.setText("" + days);
                    }
                    catch (Exception e){
                        tvAverageDays.setText("");
                    }

                    double absoluteReturn = schemeSummary.optDouble("absoluteReturn");
                    String data3 = String.format("%.2f", absoluteReturn) + "%";
                    tvAbsReturn.setText(data3);


                    double currentValue = schemeSummary.optDouble("currentValue");
                    String currentValueStr = format.format(currentValue);
                    tvMarketValue.setText(currentValueStr);

                    double changePercent2 = schemeSummary.optDouble("changePercent");
                    String changePercentStr2 = String.format("%.2f", changePercent2) + "%";

                    if(mAppplication.isDaysChange) {
                        double oneDayChange2 = schemeSummary.optDouble("oneDayChange");
                        String oneDayChange2Str = format.format(oneDayChange2);
                        String finalValueStr2 = oneDayChange2Str + " (" + changePercentStr2 + ")";
                        tvOneDayChange.setText(finalValueStr2);
                        tvOneDayChange.setVisibility(View.VISIBLE);
                        if (oneDayChange2 == 0) {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black_white));
                        }else if (oneDayChange2 > 0) {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.green2));
                        } else {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red_2));
                        }
                        tvFolio.setText("[" + innerObject.optString("folioNo") + "]");
                    }else{
                        tvOneDayChange.setVisibility(View.INVISIBLE);
                    }

                }








          /*  JSONObject schemeSummaryObject = null;
            if (mSession.getHasShowXirr()) {
                schemeSummaryObject = innerObject;
                double cgrValue = schemeSummaryObject.optDouble("XIRR");
                String data2 = String.format("%.2f", cgrValue) + "%";
              //  tvCagrValue.setText(data2);

            } else {
                schemeSummaryObject = innerObject.optJSONObject("summary");
                double cgrValue = schemeSummaryObject.optDouble("CAGR");
                String data2 = String.format("%.2f", cgrValue) + "%";
               // tvCagrValue.setText(data2);
            }*/


                child.setOnClickListener(buttonClick);
                itemRowHolder.flxform.addView(child);
                child.setTag("" + innerObject);

            }

        }
    }

    View.OnClickListener buttonClick = new View.OnClickListener() {
        public void onClick(View view) {
            try {
                ClientActivity activty = (ClientActivity) mContext;
                Bundle bundle1 = new Bundle();
                String tagValue = (String) view.getTag();
                JSONObject object = new JSONObject(tagValue);
                bundle1.putString("data", tagValue);
                bundle1.putString("isAnimation", "true");
                if (object.has("name")) {
                    bundle1.putString("applicant_name", object.optString("name"));
                } else {
                    bundle1.putString("applicant_name", object.optString("applicantName"));
                }
                bundle1.putString("applicant_name", mClient);
                activty.displayViewOther(31, bundle1);
            } catch (Exception e) {

            }
        }
    };

    @Override
    public int getItemCount() {
        return (null != dataList ? dataList.size() : 0);
    }

    public class ItemRowHolder extends RecyclerView.ViewHolder {
        protected TextView tvHeader1, tvCurrent, tvOneDayChange, tvXirrHeader,
                tvXirrGainHeader, tvPurchaseValue,  tvGain, tvCagr;
        protected ImageView ivFundType, ivExpand;


        protected LinearLayout flxform, llTopCard, llXirrHeaderView, llCagrTopCardView, llXirrValue;
        private View mViewLine;

        public ItemRowHolder(View view) {
            super(view);

            this.llXirrHeaderView = view.findViewById(R.id.llXirrHeaderView);
            this.tvXirrHeader = view.findViewById(R.id.tvXirrHeader);
            this.tvXirrGainHeader = view.findViewById(R.id.tvXirrGainHeader);
            this.tvHeader1 = view.findViewById(R.id.tvHeader1);
            this.tvCurrent = view.findViewById(R.id.tvCurrent);
            this.tvOneDayChange = view.findViewById(R.id.tvOneDayChange);
            this.ivFundType = view.findViewById(R.id.ivFundType);
            this.ivExpand = view.findViewById(R.id.ivExpand);
            this.llTopCard = view.findViewById(R.id.llTopCard);
            this.mViewLine = view.findViewById(R.id.viewLine1);
            this.flxform = view.findViewById(R.id.flxform);
            this.llCagrTopCardView = view.findViewById(R.id.llCagrTopCardView);
            this.tvPurchaseValue = view.findViewById(R.id.tvPurchaseValue);
            this.tvGain = view.findViewById(R.id.tvGain);
            this.tvCagr = view.findViewById(R.id.tvCagr);
            this.llXirrValue = view.findViewById(R.id.llXirrValue);
        }
    }

    public void updateList(List<JSONObject> list, String mClientName) {
        dataList.clear();
        dataList.addAll(list);
        mClient = mClientName;
        AreAllExpandedArray = new boolean[list.size()];
        notifyDataSetChanged();
    }

    private void checkIfAllFlxCardCollapsed(ItemRowHolder holder) {
        boolean allCollapsed = true;
        for(boolean isExpanded : AreAllExpandedArray)
        {
            if(isExpanded)
            {
                allCollapsed = false;
                break;
            }
        }
        if(allCollapsed && listener != null)
        {
            listener.onAllFlxFormCardsCollapsed();
        }
    }
    private void checkIfAllFlxCardExpanded(ItemRowHolder holder) {
        boolean allExpanded = true;
        for(boolean isExpanded : AreAllExpandedArray)
        {
            if(!isExpanded)
            {
                allExpanded = false;
                break;
            }
        }
        if(allExpanded && listener != null)
        {
            listener.onAllFlxFormCardsExpanded();
        }
    }

    public void setAreAllExpanded(boolean areAllExpanded)
    {
        this.AreAllExpanded = areAllExpanded;
        notifyDataSetChanged();
    }

}