package investwell.client.fragments.others;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.iw.mint.sdk.R;

import investwell.utils.AppSession;
import investwell.utils.BaseFragment;


public class Help_Frag extends BaseFragment implements View.OnClickListener {
    private TextView TvPhone, TvEmail;
    private AppSession mSession;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_help_, container, false);
        view.findViewById(R.id.phone_layout).setOnClickListener(this);
        view.findViewById(R.id.email_layout).setOnClickListener(this);
        view.findViewById(R.id.bac_arrow).setOnClickListener(this);
        view.findViewById(R.id.bac_arrow);
        mSession = AppSession.getInstance(getContext());
        TvPhone = view.findViewById(R.id.phone);
        TvEmail = view.findViewById(R.id.email);
        TvPhone.setText(mSession.getTelNumber());
        TvEmail.setText(mSession.getUserEmail());
        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.phone_layout) {
                Intent inten = new Intent(Intent.ACTION_DIAL);
                inten.setData(Uri.parse("tel:" + mSession.getTelNumber()));
                startActivity(inten);
}
else if (v.getId() == R.id.email_layout) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("plain/text");
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"" + mSession.getUserEmail()});
                intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.txt_enquiry_from_mobile_app));
                intent.setType("email/rfc822");
                if (intent != null) {
                    intent.putExtra(Intent.EXTRA_TEXT, "");
                    startActivity(Intent.createChooser(intent, ""));
                } else {
                    Toast.makeText(getActivity(), R.string.txt_app_not_found, Toast.LENGTH_SHORT).show();
                }
}
else if (v.getId() == R.id.bac_arrow) {
                getActivity().getSupportFragmentManager().popBackStack();
}

    }


}
