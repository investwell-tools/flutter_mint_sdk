package investwell.common.alltransactions;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.iw.mint.sdk.R;

import investwell.activity.AppApplication;
import investwell.activity.BaseActivity;
import investwell.broker.bseOnboarding.BrokerBse_ProfileBrokerActivity;
import investwell.broker.mfuOnboarding.BrokerMfuPendingOnboardListActivity;
import investwell.broker.nseOnborading.BrokerNsePendingOnboardListActivity;
import investwell.client.manageProfiles.ManageProfilesHomeActivity;
import investwell.common.allprofiles.BseProfileActivity;
import investwell.common.allprofiles.MfuProfileActivity;
import investwell.common.allprofiles.NseProfileActivity;
import investwell.utils.AppSession;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class CommonExchangeActivity extends BaseActivity implements View.OnClickListener {
    private ImageView mIvNse, mIvBse, mIvMfu,mIvNse2;
    private TextView mTvText;
    private String mType = "";
    private AppSession mSession;
    private Bundle mBundle;
    private Intent mIntent;


    @Override
    public void onBackPressedHandled() {
        super.onBackPressedHandled();
        AppApplication.sExchangeType = "";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exchange_for_new_purchase);
        mSession = AppSession.getInstance(this);

        mTvText = findViewById(R.id.tvText);

        mIvNse = findViewById(R.id.ivNse);
        mIvNse2 = findViewById(R.id.ivNse2);
        mIvBse = findViewById(R.id.ivBse);
        mIvMfu = findViewById(R.id.ivMfu);
        mIvNse.setOnClickListener(this);
        mIvBse.setOnClickListener(this);
        mIvMfu.setOnClickListener(this);
        mIvNse2.setOnClickListener(this);

        findViewById(R.id.iv_back).setOnClickListener(this);

        boolean hasBse = mSession.getHasBseOpted();
        boolean hasNse = mSession.getHasNseOpted();
        boolean hasMfu = mSession.getHasMfuOpted();
        boolean hasNse2 = mSession.getHasNse2Opted();


        View[] exchangeViews = { mIvBse, mIvNse, mIvMfu, mIvNse2 };
        boolean[] exchangeFlags = { hasBse, hasNse, hasMfu, hasNse2 };

        int enabledCount = 0;
        for (int i = 0; i < exchangeViews.length; i++) {
            if (exchangeFlags[i]) {
                exchangeViews[i].setVisibility(View.VISIBLE);
                enabledCount++;
            } else {
                exchangeViews[i].setVisibility(View.GONE);
            }
        }

        mSession.setHasMultiExchange(enabledCount > 1);




        mIntent = getIntent();
        if (mIntent != null && mIntent.hasExtra("type")) {
            mBundle = mIntent.getExtras();
            mType = mIntent.getStringExtra("type");
        }

        if (mType.equalsIgnoreCase("broker_onboard")){
            boolean isViewEnableNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature44", Permissions.VIEW);
            boolean isViewEnableBSe = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature35", Permissions.VIEW);
            boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature40", Permissions.VIEW);
            boolean isViewEnableNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature53", Permissions.VIEW);

//            if (isViewEnableNse){
//                mIvNse.setVisibility(View.VISIBLE);
//            }else{
//                mIvNse.setVisibility(View.GONE);
//            }

            if (isViewEnableBSe){
                mIvBse.setVisibility(View.VISIBLE);
            }else{
                mIvBse.setVisibility(View.GONE);
            }

            if (isViewEnableMfu){
                mIvMfu.setVisibility(View.VISIBLE);
            }else{
                mIvMfu.setVisibility(View.GONE);
            }

            if (isViewEnableNSE2){
                mIvNse2.setVisibility(View.VISIBLE);
            }else{
                mIvNse2.setVisibility(View.GONE);
            }
        }else {
            // NSE 2 broker invest online
            if (hasNse2 && mType.equalsIgnoreCase("transferholding")){
                mIvNse2.setVisibility(View.GONE);
            }

        }
        //
//        mIvNse2.setVisibility(View.VISIBLE);
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.iv_back) {
                onBackPressedHandled();
                finish();
}
else if (view.getId() == R.id.ivNse) {
                //mBundle.putString("transactionRoute", "clientHome");
                AppApplication.sExchangeType = "1";
                redirectMethod();
}
else if (view.getId() == R.id.ivBse) {
               // mBundle.putString("transactionRoute", "clientHome");
                AppApplication.sExchangeType = "2";
                redirectMethod();
}
else if (view.getId() == R.id.ivMfu) {
                // mBundle.putString("transactionRoute", "clientHome");
                AppApplication.sExchangeType = "3";
                redirectMethod();
}
else if (view.getId() == R.id.ivNse2) {
                // mBundle.putString("transactionRoute", "clientHome");
                AppApplication.sExchangeType = "4";
                redirectMethod();
}

    }


    private void redirectMethod() {
        String exchange = Utils.getSelectedExchange(mSession);
        if (mType.equals("broker_onboard")){
            Bundle bundle = new Bundle();
            bundle.putString("call_from", "broker_menu");
            if (exchange.equals("1")) {
                Intent intent = new Intent(CommonExchangeActivity.this, BrokerNsePendingOnboardListActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            } else if (exchange.equals("2")) {
                Intent intent = new Intent(CommonExchangeActivity.this, BrokerBse_ProfileBrokerActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            } else if (exchange.equals("4")) {
                Intent intent = new Intent(CommonExchangeActivity.this, BrokerNsePendingOnboardListActivity.class);
                bundle.putString("exchange",exchange);
                bundle.putBoolean("nse2", true);
                intent.putExtras(bundle);
                startActivity(intent);
            }
            else if (exchange.equals("3")) {
                Intent intent = new Intent(CommonExchangeActivity.this, BrokerMfuPendingOnboardListActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }

        }else {
            if (mType.equals("manageProfile")) {
                Intent intent = new Intent(CommonExchangeActivity.this, ManageProfilesHomeActivity.class);
                startActivity(intent);
            } else {
                if (exchange.equalsIgnoreCase("1")) {
                    Intent intent = new Intent(CommonExchangeActivity.this, NseProfileActivity.class);
                    mBundle.putString("isComeFromExchangeActivity", "yes");
                    intent.putExtras(mBundle);
                    startActivity(intent);
                } else if (exchange.equalsIgnoreCase("2")) {
                    Intent intent = new Intent(CommonExchangeActivity.this, BseProfileActivity.class);
                    mBundle.putString("isComeFromExchangeActivity", "yes");
                    mBundle.putString("exchange", "2");
                    mBundle.putBoolean("nse2", false);
                    intent.putExtras(mBundle);
                    startActivity(intent);
                } else if (exchange.equalsIgnoreCase("3")) {
                    Intent intent = new Intent(CommonExchangeActivity.this, MfuProfileActivity.class);
                    mBundle.putString("isComeFromExchangeActivity", "yes");
                    intent.putExtras(mBundle);
                    startActivity(intent);
                } else if (exchange.equalsIgnoreCase("4")) {
                    Intent intent = new Intent(CommonExchangeActivity.this, BseProfileActivity.class);
                    mBundle.putString("isComeFromExchangeActivity", "yes");
                    mBundle.putString("exchange", "4");
                    mBundle.putBoolean("nse2", true);
                    intent.putExtras(mBundle);
                    startActivity(intent);
                }
            }
        }
    }
}