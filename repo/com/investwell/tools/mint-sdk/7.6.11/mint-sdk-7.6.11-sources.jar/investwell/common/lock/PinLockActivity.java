package investwell.common.lock;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

import com.iw.mint.sdk.R;

import investwell.activity.AppApplication;
import investwell.activity.BaseActivity;
import investwell.activity.DomainActivity;
import investwell.admin.activity.AdminActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.common.lock.pinlock.PFFLockScreenConfiguration;
import investwell.common.lock.pinlock.PFLockScreenFragment;
import investwell.utils.AppSession;
import investwell.utils.Extensions;
import investwell.utils.Utils;
import investwell.utils.customView.CustomDialog;


public class PinLockActivity extends BaseActivity {
    private AppSession mSession;
    private String mType = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.pin_lock_activity);
        Extensions.checkDevice(this);

        mSession = AppSession.getInstance(this);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("type")) {
            mType = intent.getStringExtra("type");
        }
        showLockScreenFragment();
    }


    private PFLockScreenFragment.OnPFLockScreenCodeCreateListener mCodeCreateListener =
            new PFLockScreenFragment.OnPFLockScreenCodeCreateListener() {
                @Override
                public void onCodeCreated(String encodedCode) {
                    mSession.setPIN(encodedCode);
                    redirectionMethod();
                }
            };

    private PFLockScreenFragment.OnPFLockScreenLoginListener mLoginListener =
            new PFLockScreenFragment.OnPFLockScreenLoginListener() {

                @Override
                public void onCodeInputSuccessful() {
                    redirectionMethod();
                }

                @Override
                public void onFingerprintSuccessful() {
                    redirectionMethod();
                }

                @Override
                public void onPinLoginFailed() {
                    // Toast.makeText(PinLockActivity.this, "Pin failed", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFingerprintLoginFailed() {
                    // Toast.makeText(PinLockActivity.this, "Fingerprint failed", Toast.LENGTH_SHORT).show();
                }
            };

    private void redirectionMethod(){
        if (mType.equalsIgnoreCase("verifyFromSetting")) {
            Intent intent = new Intent();
            setResult(105, intent);
            finish();
        } else if (mType.equalsIgnoreCase("change_pin")) {
            mSession.setHasAppLockEnable(true);
            Intent intent = new Intent();
            setResult(108, intent);
            finish();
        } else if (mType.equalsIgnoreCase("set_screen_lock")) {
            mSession.setHasAppLockEnable(true);
            if (mSession.getLoginType().equals("broker")) {
                Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            } else if (mSession.getLoginType().equals("admin")) {
                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            }else {
                Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                intent.putExtra("coming_from",mType);
                startActivity(intent);
                finish();
            }

        } else if (mType.equalsIgnoreCase("verify_lock")) {
            Intent intent = new Intent();
            setResult(100, intent);
            finish();
        } else {
            if (mSession.getLoginType().equals("broker")) {
                Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            }  else if (mSession.getLoginType().equals("admin")) {
                Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            } else {
                Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                finish();
            }
        }
    }


    private void showLockScreenFragment() {
        //final boolean isPinExist = PFFingerprintPinCodeHelper.getInstance().isPinCodeEncryptionKeyExist();
        boolean isPinExist = false;
        if (mType.equalsIgnoreCase("change_pin")) {
            isPinExist = false;
        } else if (mType.equalsIgnoreCase("verifyFromSetting")) {
            isPinExist = true;
        } else if (mSession.getPIN().length() > 0) {
            isPinExist = true;
        } else {
            isPinExist = false;
        }
        final PFFLockScreenConfiguration.Builder builder = new PFFLockScreenConfiguration
                .Builder(this)
                .setTitle(isPinExist ? getString(R.string.txt_unlock_with_pin_or_finger_print) : getString(R.string.pin_text_Create_PIN))
                .setCodeLength(4)
                .setLeftButton(getString(R.string.forgot), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        showResetPINDailog();

                    }
                })
                .setUseFingerprint(true);
        PFLockScreenFragment fragment = new PFLockScreenFragment();
        Bundle bundle = new Bundle();
        bundle.putString("type", mType);
        fragment.setArguments(bundle);


        builder.setMode(isPinExist
                ? PFFLockScreenConfiguration.MODE_AUTH
                : PFFLockScreenConfiguration.MODE_CREATE);
        if (isPinExist) {
            fragment.setEncodedPinCode(mSession.getPIN());
            fragment.setLoginListener(mLoginListener);
        }

        fragment.setConfiguration(builder.build());
        fragment.setCodeCreateListener(mCodeCreateListener);
        getSupportFragmentManager().beginTransaction().replace(R.id.container_view, fragment).commit();

    }


    private void showResetPINDailog() {
        CustomDialog customDialog = new CustomDialog(new CustomDialog.DialogBtnCallBack() {
            @Override
            public void onDialogBtnClick(View view) {
                if (view.getId() == R.id.btDone) {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.clearAllSession();
                        Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);

                        startActivity(intent);
                        finish();
}
else if (view.getId() == R.id.btCalcel) {
}
            }
        });

        customDialog.showDialog(PinLockActivity.this, getString(R.string.alert_dialog_confirmation_header_txt),
                getString(R.string.dialog_message_reset_pin),
                getString(R.string.alert_dialog_yes_btn_txt),
                getString(R.string.alert_dialog_btn_no_txt),
                true, true);
    }





}
