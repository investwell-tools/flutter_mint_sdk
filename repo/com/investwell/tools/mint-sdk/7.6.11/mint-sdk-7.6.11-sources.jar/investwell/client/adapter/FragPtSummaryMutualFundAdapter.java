package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;

/**
 * Created by binesh on 8/5/18.
 */

public class FragPtSummaryMutualFundAdapter extends RecyclerView.Adapter<FragPtSummaryMutualFundAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private AppSession mSession;
    private Context mContext;
    private String mGroupByType = "1002";
    private OnItemClickListener listener;
    AppApplication mAppplication;

    public FragPtSummaryMutualFundAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
        mAppplication = (AppApplication) context.getApplicationContext();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_pt_summary_mutialfund_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onSchemeClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView mTvName, mTvCurrent, mTvTotalGain, mTvXirr, mTvOneDayChange,
                tvCategoryName, tvFolio, tvTitle3, tvPurchase, tvCAGR, tvAbsRet, tvHoldingDays, tvGainLevel;
        private LinearLayout llCAGRExtraView, linerFolio, llButtomLine, llAbsRet;
        private View viewLinew;


        public ViewHolder(View view) {
            super(view);
            mTvName = view.findViewById(R.id.tvName);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvXirr = view.findViewById(R.id.tvXIRR);
            tvCategoryName = view.findViewById(R.id.tvCategoryName);
            mTvTotalGain = view.findViewById(R.id.tvTotalGain);
            mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
            tvFolio = view.findViewById(R.id.tvFolio);
            linerFolio = view.findViewById(R.id.linerFolio);
            tvTitle3 = view.findViewById(R.id.tvTitle3);

            llCAGRExtraView = view.findViewById(R.id.llCAGRExtraView);
            tvPurchase = view.findViewById(R.id.tvPurchase);
            tvCAGR = view.findViewById(R.id.tvCAGR);
            tvAbsRet = view.findViewById(R.id.tvAbsRet);
            tvHoldingDays = view.findViewById(R.id.tvHoldingDays);
            tvGainLevel = view.findViewById(R.id.tvGainLevel);
            viewLinew = view.findViewById(R.id.viewLinew);
            llButtomLine = view.findViewById(R.id.llButtomLine);
            llAbsRet = view.findViewById(R.id.llAbsRet);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObjectSummary = mDataList.get(position);
                tvCategoryName.setVisibility(View.GONE);
                linerFolio.setVisibility(View.INVISIBLE);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

                double totalGain = jsonObjectSummary.optDouble("gain");
                String strTotalGain = format.format(totalGain);
                if (totalGain >= 0) {
                    mTvTotalGain.setTextColor(ContextCompat.getColor(mContext, R.color.green2));
                } else {
                    mTvTotalGain.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                }
                mTvTotalGain.setText(strTotalGain);

                if (mGroupByType.equals("100")) {
                    mTvName.setText(jsonObjectSummary.optString("applicantName"));
                    viewLinew.setVisibility(View.GONE);
                    if (mSession.getHasShowXirr()) {
                        llCAGRExtraView.setVisibility(View.GONE);
                        tvGainLevel.setText(mContext.getString(R.string.Overall_Gain));

                        UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-","%",2,false,mTvXirr);


                    } else {
                        viewLinew.setVisibility(View.GONE);
                        llButtomLine.setVisibility(View.GONE);
                        llAbsRet.setVisibility(View.GONE);
                        llCAGRExtraView.setVisibility(View.VISIBLE);
                        tvGainLevel.setText(mContext.getString(R.string.current_gain));

                        double cgrValue = jsonObjectSummary.optDouble("CAGR");
                        String srtCAGR = String.format("%.2f", cgrValue) + "%";
                        tvCAGR.setText(srtCAGR);

                        double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                        String strPurchaseValue = format.format(purchaseValue);
                        tvPurchase.setText(strPurchaseValue);


                    }


                } else if (mGroupByType.equals("1005")) {
                    linerFolio.setVisibility(View.VISIBLE);
                    tvTitle3.setText(mContext.getResources().getString(R.string.txt_Folio));
                    mTvName.setText(jsonObjectSummary.optString("schemeName"));
                    mTvName.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.onSchemeClick(position);
                        }
                    });
                    tvFolio.setText(jsonObjectSummary.optString("folioNo"));

                    String categoryName = jsonObjectSummary.optString("dueDiligence");

                    tvCategoryName.setText(categoryName);
                    if (position == 0) {
                        tvCategoryName.setVisibility(View.VISIBLE);
                    } else {
                        JSONObject jsonObject = mDataList.get(position - 1);
                        if (jsonObject.optString("dueDiligence").equalsIgnoreCase(jsonObjectSummary.optString("dueDiligence"))) {
                            tvCategoryName.setVisibility(View.GONE);
                        } else {
                            tvCategoryName.setVisibility(View.VISIBLE);
                        }

                    }
                    if (categoryName.equals("")){
                        tvCategoryName.setVisibility(View.GONE);
                    }



                    if (mSession.getHasShowXirr()) {
                        viewLinew.setVisibility(View.GONE);
                        llCAGRExtraView.setVisibility(View.GONE);
                        tvGainLevel.setText(mContext.getString(R.string.Overall_Gain));

                        UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-","%",2,true,mTvXirr);


                    } else {
                        viewLinew.setVisibility(View.VISIBLE);
                        llCAGRExtraView.setVisibility(View.VISIBLE);
                        tvGainLevel.setText(mContext.getString(R.string.current_gain));
                        tvHoldingDays.setText(mContext.getString(R.string.holding_days));
                        try {
                            double avgHoldingDays = jsonObjectSummary.optDouble("avgHoldingDays");
                            long rounded = Math.round(avgHoldingDays);
                            int days = (rounded <= Integer.MAX_VALUE) ? (int) rounded : Integer.MAX_VALUE;
                            mTvXirr.setText("" + days);
                        }
                        catch (Exception e){
                            mTvXirr.setText("");
                        }
                        double absoluteReturn = jsonObjectSummary.optDouble("absoluteReturn");
                        String data2 = String.format("%.2f", absoluteReturn) + "%";
                        tvAbsRet.setText(data2);

                        double cgrValue = jsonObjectSummary.optDouble("CAGR");
                        String srtCAGR = String.format("%.2f", cgrValue) + "%";
                        tvCAGR.setText(srtCAGR);

                        double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                        String strPurchaseValue = format.format(purchaseValue);
                        tvPurchase.setText(strPurchaseValue);


                    }


                } else if (mGroupByType.equals("1002")) {
                    linerFolio.setVisibility(View.VISIBLE);
                    tvTitle3.setText(mContext.getResources().getString(R.string.text_quantity));
                    tvFolio.setText(jsonObjectSummary.optString("currentUnits"));
                    mTvName.setText(jsonObjectSummary.optString("schemeName"));
                    mTvName.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.onSchemeClick(position);
                        }
                    });
                } else {
                    tvCategoryName.setVisibility(View.GONE);
                    mTvName.setText(jsonObjectSummary.optString("schemeName"));
                    mTvName.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            listener.onSchemeClick(position);
                        }
                    });
                }

                if(mAppplication.isDaysChange) {
                    String stroneDayChange = jsonObjectSummary.optString("oneDayChange");
                    if (!stroneDayChange.equalsIgnoreCase("null")) {
                        Double oneDayChange = Double.parseDouble(stroneDayChange);
                        String formatedOneDayChange = format.format(oneDayChange);
                        if (oneDayChange == 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black));
                            mTvOneDayChange.setText("  (+" + formatedOneDayChange + ")");
                        } else if (oneDayChange > 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.marketGreen));
                            mTvOneDayChange.setText("  (+" + formatedOneDayChange + ")");
                        } else {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                            mTvOneDayChange.setText("  (" + formatedOneDayChange + ")");
                        }
                    }
                }else{
                    mTvOneDayChange.setVisibility(View.GONE);
                }


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mGroupByType = type;
        notifyDataSetChanged();
    }

}
