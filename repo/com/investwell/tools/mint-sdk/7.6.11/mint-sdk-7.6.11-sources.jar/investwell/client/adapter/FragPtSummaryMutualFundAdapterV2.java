package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.Group;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FragPtSummaryMutualFundAdapterV2 extends RecyclerView.Adapter<FragPtSummaryMutualFundAdapterV2.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private AppSession mSession;
    private Context mContext;
    private OnItemClickListener listener;
    AppApplication mAppplication;

    public FragPtSummaryMutualFundAdapterV2(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
        mAppplication = (AppApplication) mContext.getApplicationContext();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_pt_summary_mutialfund_adapterv2, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onSchemeClick(int position);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView mTvName, mTvCurrent, mTvOneDayChange,
                tvCagr, tvGain, tvPurchageValue, tvCagrLavel, tvPurchaseLevel;

        private LinearLayout llView;

        // private Group grp_change;

        public ViewHolder(View view) {
            super(view);
            mTvName = view.findViewById(R.id.tvName);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
            tvCagrLavel = view.findViewById(R.id.tvCagrLavel);
            tvCagr = view.findViewById(R.id.tvCagr);
            tvGain = view.findViewById(R.id.tvGain);
            tvPurchaseLevel = view.findViewById(R.id.tvPurchaseLevel);
            tvPurchageValue = view.findViewById(R.id.tvPurchageValue);
            llView = view.findViewById(R.id.llView);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject clientObject = mDataList.get(position);
                final JSONObject jsonObjectSummary = clientObject.optJSONObject("summary");


                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

                String name = "";
                if (clientObject.has("name")) {
                     name = clientObject.optString("name");
                } else {
                     name = clientObject.optString("applicantName");
                }
                mTvName.setText(name);


                if (mSession.getHasShowXirr()) {
                    tvCagrLavel.setText(mContext.getString(R.string.overall_gain));
                    if (mSession.getHideXirr().equals("0")) {
                        tvPurchaseLevel.setText(mContext.getString(R.string.XIRR));

                        UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-","%",2,true,tvPurchageValue);

                    } else {
                        tvPurchaseLevel.setVisibility(View.GONE);
                        tvPurchageValue.setVisibility(View.GONE);
                    }
                    double gain = jsonObjectSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(tvGain,gain,mContext);


                    /*double totalGain = jsonObjectSummary.optDouble("gain");
                    String gainValue = format.format(totalGain);
                    tvCAGR.setText(gainValue);

                    if (totalGain > 0) {
                        tvCAGR.setTextColor(ContextCompat.getColor(mContext, R.color.marketGreen));
                    } else {
                        tvCAGR.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                    }*/
                } else {
                    tvPurchaseLevel.setText(mContext.getString(R.string.PurchaseCost));
                    tvCagrLavel.setText(mContext.getString(R.string.gain_cagr));

                    double gain = jsonObjectSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(tvGain,gain,mContext);

                    double CAGR = jsonObjectSummary.optDouble("CAGR");
                    Utils.checkNegativeAndPositiveWithSign(tvCagr,CAGR,mContext);

                    double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvPurchageValue.setText(strPurchaseValue);

                }

                if(mAppplication.isDaysChange) {
                    double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                    String strOneDayChange = format.format(oneDayChange);
                    double changePercent = jsonObjectSummary.optDouble("changePercent");
                    String changePercentStr = String.format("%.2f", changePercent) + "%";
                    if (oneDayChange == 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black));
                    } else if (oneDayChange > 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.marketGreen));
                    } else {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                    }
                } else {
                    mTvOneDayChange.setVisibility(View.GONE);
                }


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            llView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
