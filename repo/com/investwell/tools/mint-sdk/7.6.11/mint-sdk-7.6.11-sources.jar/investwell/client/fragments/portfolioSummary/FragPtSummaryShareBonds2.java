package investwell.client.fragments.portfolioSummary;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.client.adapter.FragPtShareBondAdapter2;
import investwell.utils.BaseFragment;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPtShareBondAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.Utils;

import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mEndDate;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mMemberList;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mSelectedPosition;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mStartingDate;
import static investwell.utils.UtilityKotlin.getOneDayEarlier;


public class FragPtSummaryShareBonds2 extends BaseFragment implements View.OnClickListener {
    private TextView mTvName, mTvCurrent, mTvTotalGain, mTvAbsolute,tvPurchageValue, tvGainLevel,mTvOneDayChange, tvDividend, tvCagr;
    RequestQueue requestQueue;
    private FragPtShareBondAdapter2 mAdapter;
    private RecyclerView mRecycleView;
    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mCardView;
    private String mGroupById = "1002";
    private LinearLayout mLinerNoData;
    private ToolbarFragment mFragToolBar;

    private AppApplication mAppplication;
    private boolean mIsActiveAssert = true;
    private JSONObject mFamilyObject = new JSONObject();

    private ArrayList<JSONObject> mList;
    private MaterialButton mbNoDataAddTxn;
    private FragPtSummaryHome ptSummaryHome;


    @Override
    public void onResume() {
        super.onResume();
 /*       if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        JSONObject appConfigObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }
        } catch (Exception e) {

        }
        View view;
        if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
            view = inflater.inflate(R.layout.frag_share_bond2_layout6, container, false);
        } else {
            view = inflater.inflate(R.layout.frag_share_bond2, container, false);
        }

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        view.findViewById(R.id.ll_end_content_primary).setVisibility(View.GONE);
        view.findViewById(R.id.ivBack).setOnClickListener(this);
        TextView tvTitle = view.findViewById(R.id.tvToolbarTitle);
        LinearLayout llToolbar = view.findViewById(R.id.llToolbar);
        tvTitle.setText(getResources().getString(R.string.share_amp_bond));

        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("data")) {
            try {
                mFamilyObject = new JSONObject(bundle.getString("data"));
            } catch (Exception e) {

            }
        }

        if (bundle != null && bundle.containsKey("isHideToolBar")) {
            if (bundle.getBoolean("isHideToolBar")) {
                llToolbar.setVisibility(View.GONE);
            } else {
                llToolbar.setVisibility(View.VISIBLE);
            }
        }


        mTvName = view.findViewById(R.id.tvName);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
        mTvTotalGain = view.findViewById(R.id.tvTotalGain);
        tvCagr = view.findViewById(R.id.tvCagr);
        tvDividend = view.findViewById(R.id.tvDividend);
        mTvAbsolute = view.findViewById(R.id.tvAbsolute);
        mLinerNoData = view.findViewById(R.id.linerNoData);
        tvGainLevel = view.findViewById(R.id.tvGainLevel);
        tvPurchageValue = view.findViewById(R.id.tvPurchageValue);
        mbNoDataAddTxn = view.findViewById(R.id.mbAddTransaction);
        mbNoDataAddTxn.setOnClickListener(this);

        mRecycleView = view.findViewById(R.id.recycleView);
        mRecycleView.setHasFixedSize(true);
        mRecycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mAdapter = new FragPtShareBondAdapter2(getActivity(), new ArrayList<JSONObject>(), new FragPtShareBondAdapter2.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    JSONObject jsonObject = mAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("data", ""+jsonObject);
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(48, bundle1);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }

            @Override
            public void onSchemeClick(int position) {
             /*   JSONObject jsonObject = mAdapter.mDataList.get(position);
                Bundle bundle1 = new Bundle();
                bundle1.putString("schemeId", jsonObject.optString("schid"));
                Intent i = new Intent(mActivity, FactSheetActivity.class);
                i.putExtras(bundle1);
                startActivity(i);*/
            }
        });
        mRecycleView.setAdapter(mAdapter);

        ptSummaryHome = (FragPtSummaryHome) getParentFragment();
        boolean canAddTxn;
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
            canAddTxn =  UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature57", Permissions.ADD);
        } else {
            canAddTxn =  UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature1003", Permissions.ADD);
        }
        mbNoDataAddTxn.setVisibility(canAddTxn ? View.VISIBLE : View.GONE);

        getPtShareBond();
        return view;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}
else if (v.getId() == R.id.ivBack) {
                mActivity.onBackPressed();
}
else if (v.getId() == R.id.mbAddTransaction) {
                Bundle bundle = new Bundle();
                bundle.putBoolean("isFromPortfolio", true);
                bundle.putInt("tabPos", 1);
                mActivity.goToTransactionTab(bundle);
}

    }

    private void SetData(String data) {

        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        mCardView.setVisibility(View.VISIBLE);
        mLinerNoData.setVisibility(View.GONE);
        mList = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");

                String userName = "";
                String levelNo = mSession.getLevelNo();
               if(Objects.equals(levelNo, "100"))
                   mTvName.setText(mSession.getPersonName());
               else{
                   if (mFamilyObject.length()>0){
                       mTvName.setText(mFamilyObject.optString("applicantName"));
                   }else{
                       String name = jsonArray.optJSONObject(0).optString("applicantName");
                       mTvName.setText(name);
                   }
               }



                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

                double purchaseValue = 0;
                if (jsonObjectSummary.has("purchaseValue")){
                    purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                }else{
                    purchaseValue = jsonObjectSummary.optDouble("remainingBalUnitsPurchaseValue");
                }

                String strpurchaseValue = format.format(purchaseValue);
                tvPurchageValue.setText(strpurchaseValue);

                if (mAppplication.isDaysChange) {
                    double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                    String strOneDayChange = format.format(oneDayChange);
                    double changePercent = jsonObjectSummary.optDouble("changePercent");
                    String changePercentStr = String.format("%.2f", changePercent) + "%";
                    if (oneDayChange == 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.black_white));
                    } else if (oneDayChange > 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.green_text_color));
                    } else {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.red_text_color));
                    }
                } else {
                    mTvOneDayChange.setVisibility(View.GONE);
                }

         /*       double gain = jsonObjectSummary.optDouble("gain");
                String strTotalGain = format.format(gain);
                mTvTotalGain.setText(strTotalGain);*/

                double dividend = jsonObjectSummary.optDouble("dividend");
                String strDividend = format.format(dividend);
                tvDividend.setText(strDividend);

                double cgrValue = jsonObjectSummary.optDouble("absoluteReturn");
                String data2 = String.format("%.2f", cgrValue) + "%";
                mTvAbsolute.setText(data2);

             /*   double CAGR = jsonObjectSummary.optDouble("CAGR");
                String strCAGR = String.format("%.2f", CAGR) + "%";
                if (CAGR >= 0) {
                    tvCagr.setText("(+" + strCAGR + ")");
                }else{
                    tvCagr.setText("(" + strCAGR + ")");
                }
*/
                double gain = jsonObjectSummary.optDouble("gain");
                Utils.checkNegativeAndPositiveValue(mTvTotalGain,gain,requireActivity());

                double CAGR = jsonObjectSummary.optDouble("CAGR");
                Utils.checkNegativeAndPositiveWithSign(tvCagr,CAGR,requireActivity());


                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    mList.add(jsonObject1);
                }


            } else {
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        } finally {

            if (!mList.isEmpty()) { //contains data
                if (mGroupById.equals("1002")) {
                    Collections.sort(mList, new SortData());
                }
                mLinerNoData.setVisibility(View.GONE);
                mAdapter.updateList(mList, mGroupById);
                if(ptSummaryHome != null)
                   ptSummaryHome.showAddButton(1);
            } else {
                mAdapter.updateList(mList, mGroupById);
                mLinerNoData.setVisibility(View.VISIBLE);
                mCardView.setVisibility(View.GONE);
                if(ptSummaryHome != null)
                    ptSummaryHome.hideAddButton(1);
            }
        }

    }

    public void getPtShareBond() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        mCardView.setVisibility(View.GONE);
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if(ptSummaryHome != null)
           ptSummaryHome.hideAddButton(1);

        String uId = "";
        String url = "";
        String levelNo = "";
        try {
            JSONObject jsonObject1 = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            JSONObject appIdObject = new JSONObject();
            String appId = "";
            if (mFamilyObject.has("appid")) {
                appId = mFamilyObject.optString("appid");
            }else{
                if (mSession.getLoginType().equals("broker")){
                    appId = UtilityKotlin.getClientHopObject(mSession).optString("appid");
                }else{
                    appId = mSession.getAppId();
                }
            }

            appIdObject.put("appid",appId );
            jsonArray.put(appIdObject);

            JSONObject casArnOptionObject = new JSONObject();
            casArnOptionObject.put("casArnOption", "0");
            jsonArray.put(casArnOptionObject);

            JSONObject endDateObject = new JSONObject();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            Date date = getOneDayEarlier();
            if (date != null) {
                endDateObject.put("endDate", formatter.format(date));
            }
            jsonArray.put(endDateObject);

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");

            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            jsonObject1.put("uid", mFamilyObject.optString("uid"));
            jsonObject1.put("levelNo", 100);
            jsonArray.put(jsonObject1);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_PT_SUMMARY_RETURN_SHAREBOND + "filters=" + jsonArray.toString()
                    + "&group=schid"+ "&pageSize=100&currentPage=1" +
                    "&investorUid=" + uId + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            //  https://moneyempire.investwell.app/webapi/client/dashboard/getPortfolioSummaryForSharesAndBonds?
            //  filters=[{"endDate":"2020-05-18"}]&groupBy=1002&componentForLoader=
            //  {"componentName":"folioTable"}&activeFoliosOnly=false&pageSize=100&currentPage=
            //  1&investorUid=20254c11cf1cdf2f2fa2ec58921903c8&selectedUser={"uid":"20254c11c
            //  f1cdf2f2fa2ec58921903c8","levelNo":"100"}
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        SetData(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public boolean isShareBondListEmpty()
    {
        if(mList != null)
            return  mList.isEmpty();
        else return false;
    }

    public class SortData implements Comparator {

        @Override
        public int compare(Object o1, Object o2) {
            String a = "0";
            String b = "0";
            a = ((JSONObject) o1).optString("schemeName");
            b = ((JSONObject) o2).optString("schemeName");

            int ia = 0, ib = 0;
            int nza = 0, nzb = 0;
            char ca, cb;
            int result;

            while (true) {
                // only count the number of zeroes leading the last number compared_text_color
                nza = nzb = 0;

                ca = charAt(a, ia);
                cb = charAt(b, ib);

                // skip over leading spaces or zeros
                while (Character.isSpaceChar(ca) || ca == '0') {
                    if (ca == '0') {
                        nza++;
                    } else {
                        // only count consecutive zeroes
                        nza = 0;
                    }

                    ca = charAt(a, ++ia);
                }

                while (Character.isSpaceChar(cb) || cb == '0') {
                    if (cb == '0') {
                        nzb++;
                    } else {
                        // only count consecutive zeroes
                        nzb = 0;
                    }

                    cb = charAt(b, ++ib);
                }

                // process run of digits
                if (Character.isDigit(ca) && Character.isDigit(cb)) {
                    if ((result = compareRight(a.substring(ia), b.substring(ib))) != 0) {
                        return result;
                    }
                }

                if (ca == 0 && cb == 0) {
                    // The strings compare the same. Perhaps the caller
                    // will want to call strcmp to break the tie.
                    return nza - nzb;
                }

                if (ca < cb) {
                    return -1;
                } else if (ca > cb) {
                    return +1;
                }

                ++ia;
                ++ib;
            }
        }

        private char charAt(String s, int i) {
            if (i >= s.length()) {
                return 0;
            } else {
                return s.charAt(i);
            }
        }

        int compareRight(String a, String b) {
            int bias = 0;
            int ia = 0;
            int ib = 0;

            // The longest run of digits wins. That aside, the greatest
            // value wins, but we can't know that it will until we've scanned
            // both numbers to know that they have the same magnitude, so we
            // remember it in BIAS.
            for (; ; ia++, ib++) {
                char ca = charAt(a, ia);
                char cb = charAt(b, ib);

                if (!Character.isDigit(ca) && !Character.isDigit(cb)) {
                    return bias;
                } else if (!Character.isDigit(ca)) {
                    return -1;
                } else if (!Character.isDigit(cb)) {
                    return +1;
                } else if (ca < cb) {
                    if (bias == 0) {
                        bias = -1;
                    }
                } else if (ca > cb) {
                    if (bias == 0)
                        bias = +1;
                } else if (ca == 0 && cb == 0) {
                    return bias;
                }
            }
        }
    }

}
