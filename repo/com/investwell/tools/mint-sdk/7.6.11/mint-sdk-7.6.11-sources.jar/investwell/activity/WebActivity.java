package investwell.activity;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import static investwell.utils.Extensions.resolveIsInternal;
import static investwell.utils.Extensions.setCustomUserAgent;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.iw.mint.sdk.R;

import java.net.URISyntaxException;

import investwell.di.core.BaseUrls;
import investwell.utils.AppSession;
import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import kotlin.jvm.functions.Function0;

public class WebActivity extends BaseActivity {
    private WebView webview;
    private TextView heading;
    private AppSession mSession;
    private ProgressBar progressBar;


    @Override
    protected void onStart() {
        super.onStart();
        if (mSession!=null){
            UtilityKotlin.checkReAuth(mSession, WebActivity.this);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_payment);
        Extensions.checkDevice(this);

        heading = findViewById(R.id.heading);
        webview = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progressBar1);

        mSession = AppSession.getInstance(this);
        ImageView back_arrow = findViewById(R.id.back_arrow);
        back_arrow.setOnClickListener(v -> finish());

        String url = getIntent().getStringExtra("url");
        String title = getIntent().getStringExtra("title");
        String htmlContent = "";
        if (getIntent().hasExtra("htmlContent") ){
            htmlContent = getIntent().getStringExtra("htmlContent");
        }else {
            htmlContent="";
        }
        boolean isInternal =resolveIsInternal(getIntent(), url, () -> BaseUrls.baseUrl().replace("/webapi",""));
        setCustomUserAgent(webview,null,isInternal);
        heading.setText(title);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setDomStorageEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webview, true);

        webview.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                AlertDialog.Builder builder = new AlertDialog.Builder(
                        WebActivity.this);
                builder.setMessage(message)
                        .setNeutralButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int arg1) {
                                dialog.dismiss();
                            }
                        }).show();
                result.cancel();
                return true;
            }
        });
        if (!isFinishing()){
            progressBar.setVisibility(VISIBLE);
        }
        webview.setWebViewClient(new WebViewClient());
        CookieManager.getInstance().setAcceptCookie(true);
        if (!htmlContent.equalsIgnoreCase("null") && !htmlContent.equalsIgnoreCase("")){

            webview.loadDataWithBaseURL(
                    null,
                    htmlContent,
                    "text/html",
                    "UTF-8",
                    null
            );
        }else {
            webview.loadUrl(url);
        }
    }

    @Override
    public void onBackPressedHandled() {
        if (webview.canGoBack()) {
            webview.goBack();
        } else {
            super.onBackPressedHandled();
        }
    }

    public class WebViewClient extends android.webkit.WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url == null || url.startsWith("http://") || url.startsWith("https://"))
                return false;

            if (url.startsWith("intent")) {

                try {
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);

                    String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                    if (fallbackUrl != null) {
                        webview.loadUrl(fallbackUrl);
                        return true;
                    }}
                catch (URISyntaxException e) {
                    return true;//do nothing in other cases
                }
            }

            return true;//do nothing in other cases

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!isFinishing()){
                progressBar.setVisibility(GONE);
            }

        }
    }

}
