package investwell.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import java.util.ArrayList;
import java.util.List;

public class WhatsAppShare {

    public static void shareOnWhatsApp(Context context, String url) {

        PackageManager pm = context.getPackageManager();
        List<Intent> targetIntents = new ArrayList<>();

        // WhatsApp package names
        String[] whatsappPackages = {"com.whatsapp.w4b","com.whatsapp"};

        for (String packageName : whatsappPackages) {
            if (isAppInstalled(context, packageName)) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                intent.setPackage(packageName);
                targetIntents.add(intent);
            }
        }

        if (!targetIntents.isEmpty()) {
            Intent chooserIntent = Intent.createChooser(targetIntents.remove(0), "Open with");
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetIntents.toArray(new Intent[0]));
            context.startActivity(chooserIntent);
        } else {
            // Open WhatsApp Web if no app is installed
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            context.startActivity(webIntent);
        }
    }

    private static boolean isAppInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getApplicationInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static boolean isAnyWhatsappInstalled(Context context){
        PackageManager pm = context.getPackageManager();
        boolean isWhatsAppInstalled;
        boolean isWhatsAppBusinessInstalled;
        // check whatsapp app is installed
        try{
            pm.getPackageInfo("com.whatsapp",PackageManager.GET_ACTIVITIES);
            isWhatsAppInstalled= true;
        }catch (PackageManager.NameNotFoundException e){
            isWhatsAppInstalled= false;
        }
        // check whatsapp business
        try {
            // Check for WhatsApp Business
            pm.getPackageInfo("com.whatsapp.w4b", PackageManager.GET_ACTIVITIES);
            isWhatsAppBusinessInstalled = true;
        } catch (PackageManager.NameNotFoundException e) {
            isWhatsAppBusinessInstalled = false;
        }
        return isWhatsAppInstalled || isWhatsAppBusinessInstalled;
    }


}

