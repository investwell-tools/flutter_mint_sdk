package investwell.client.fragments.portfolioSummary;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Portfolio_Client_Adapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

;


public class FragInvestInExistingPortfolio extends BaseFragment implements View.OnClickListener, Portfolio_Client_Adapter.OnItemClickListener {
    RequestQueue requestQueue;
    RecyclerView recyclerView;
    Portfolio_Client_Adapter portfolio_client_adapter;
    Bundle port_bundle;
    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private TextView mTvNothing;
    private AppApplication mAppplication;
    private ToolbarFragment fragToolBar;

    private JSONObject tranJsonObject, mUccIinResponseObject;


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.stopShimmer();
  /*      if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmer();
        super.onPause();
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.invest_existing),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ProgressBarCommon.dismissDialog();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_portfolio_mutualfund, container, false);
        setUpToolBar();
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mTvNothing = view.findViewById(R.id.tvNothing);

        recyclerView = view.findViewById(R.id.sub_client);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        portfolio_client_adapter = new Portfolio_Client_Adapter(getActivity(), new ArrayList<JSONObject>(), this);
        recyclerView.setAdapter(portfolio_client_adapter);

        port_bundle = new Bundle();


        getPortfolio();
        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}

    }

    @Override
    public void onItemClick(int pos, JSONObject jsonObject) {
        String schemeId = Utils.getSchemeIdFromAll(jsonObject);
        popupPurchase(schemeId, jsonObject.optString("folioid"), jsonObject);
    }


    private void SetData(String response) {

        try {
            ArrayList<JSONObject> list = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                if (jsonObjectMain !=null){
                    JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                    if (jsonArray !=null && jsonArray.length() > 0) {
                        mTvNothing.setVisibility(View.GONE);

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                            list.add(jsonObject1);
                        }
                        portfolio_client_adapter.updateList(list);
                    } else {
                        mTvNothing.setVisibility(View.VISIBLE);
                    }
                }else {
                    mTvNothing.setVisibility(View.VISIBLE);
                }
            } else {
                mTvNothing.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
        }

    }

    private void popupPurchase(String schemeCode, String folioId, JSONObject jsonObject) {
        final Dialog dialog = new Dialog(requireActivity());
        dialog.setContentView(R.layout.purchase_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.findViewById(R.id.tvLumpsum).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getAllTransactionTypes(schemeCode, folioId, "NRP", jsonObject);
                dialog.dismiss();
            }
        });

        dialog.findViewById(R.id.tvSip).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getAllTransactionTypes(schemeCode, folioId, "SIP", jsonObject);
                dialog.dismiss();

            }
        });

        dialog.setCancelable(true);
        dialog.show();
    }

    private void checkPurchaseValidation(String transectionType, JSONObject jsonObject) {
        Bundle bundle = new Bundle();
        String exchange = "";
        if (mSession.getHasMultiExchange()) {
            exchange = AppApplication.sExchangeType;
            if (exchange == "") exchange = mSession.getExchangeNseBseMfu();
        } else {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            } else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            }  else if (mSession.getHasNse2Opted()) {
                exchange = "4";
            } else {
                 exchange = mSession.getExchangeNseBseMfu();
            }
        }
        if (exchange.equalsIgnoreCase("4")){
            bundle.putString("exchange","4");
            bundle.putBoolean("nse2",true);
        }else {
            bundle.putString("exchange",exchange);
            bundle.putBoolean("nse2",false);
        }
        try {
            jsonObject.put("applicant_name", jsonObject.optString("applicantName"));
            bundle.putString("oldObject", jsonObject.toString());
            bundle.putString("tranJsonObject", tranJsonObject.toString());
            bundle.putString("transactionType", transectionType);
            bundle.putString("isAnimation", "true");
            JSONObject newEmptyobject = new JSONObject();
            bundle.putString("sIinProfileObject", newEmptyobject.toString());
        } catch (Exception exception) {

        }

        if (mSession.getHasMultiExchange()) {
            bundle.putString("comefrom", "additionalPurchase");
            bundle.putString("transactionType", transectionType);
            bundle.putString("oldObject", jsonObject.toString());
            bundle.putString("tranJsonObject", jsonObject.toString());
            mActivity.displayViewOther(76, bundle);
        } else {
            try {

                JSONArray jsonArray = mUccIinResponseObject.getJSONArray("data");
                if (jsonArray.length() > 0) {
                    JSONObject object = jsonArray.optJSONObject(0);

                    if (!mUccIinResponseObject.optBoolean("recommended") && mSession.getExchangeNseBseMfu().equals("3")) {

                        String mfuid = object.optString("mfuid");
                        String source = object.optString("source");
                        jsonObject.put("mfuid", mfuid);
                        jsonObject.put("source", source);
                        bundle.putString("oldObject", jsonObject.toString());
                        bundle.putString("sIinProfileObject", object.toString());
                    } else {
                        bundle.putString("sIinProfileObject", object.toString());
                    }

                }


                if (mUccIinResponseObject == null) {
                    JSONObject object = new JSONObject();
                    bundle.putString("sIinProfileObject", object.toString());
                    mActivity.displayViewOther(34, bundle);
                } else if (mUccIinResponseObject.optBoolean("recommended")) {
                    bundle.putString("sIinProfileObject", mUccIinResponseObject.toString());
                    mActivity.displayViewOther(34, bundle);
                } else {
                    if (transectionType.equalsIgnoreCase("NRP")) {

                        if (exchange.equals("1")) {
                            mActivity.displayViewOther(27, bundle);
                        } else if (exchange.equals("2") || exchange.equals("4")) {
                            mActivity.displayViewOther(8, bundle);
                        } else if (exchange.equals("3")) {
                            mActivity.displayViewOther(43, bundle);
                        } else {
                            Toast.makeText(getActivity(), getString(R.string.profile_creation_not_allowed_please_contact_administrator), Toast.LENGTH_LONG).show();
                        }

                    } else if (transectionType.equalsIgnoreCase("SIP")) {
                        if (exchange.equals("1")) {
                            mActivity.displayViewOther(28, bundle);
                        } else if (exchange.equals("2") || exchange.equals("4")) {
                            mActivity.displayViewOther(9, bundle);
                        } else if (exchange.equals("3")) {
                            mActivity.displayViewOther(44, bundle);
                        } else {
                            Toast.makeText(getActivity(), getString(R.string.profile_creation_not_allowed_please_contact_administrator), Toast.LENGTH_LONG).show();
                        }

                    } else if (transectionType.equalsIgnoreCase("SWO")) {
                        mActivity.displayViewOther(10, bundle);
                    } else if (transectionType.equalsIgnoreCase("SWP")) {
                        if (mSession.getExchangeNseBseMfu().equals("1")) {
                            mActivity.displayViewOther(86, bundle);
                        } else{
                            mActivity.displayViewOther(11, bundle);
                        }
                    } else if (transectionType.equalsIgnoreCase("STP")) {
                        if (mSession.getExchangeNseBseMfu().equals("1")) {
                            mActivity.displayViewOther(87, bundle);
                        } else{
                            mActivity.displayViewOther(12, bundle);
                        }
                    } else if (transectionType.equalsIgnoreCase("NRS")) {
                        mActivity.displayViewOther(13, bundle);
                    }
                }

            } catch (Exception e) {
                if (mUccIinResponseObject == null) {
                    JSONObject object = new JSONObject();
                    Bundle bundle2 = new Bundle();
                    bundle2.putString("data", jsonObject.toString());
                    bundle2.putString("applicant_name", jsonObject.optString("applicantName"));
                    bundle2.putString("sIinProfileObject", object.toString());
                    mActivity.displayViewOther(34, bundle2);
                }
            }
        }
    }

    private void getPortfolio() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            JSONArray activeFolioJsonArray = new JSONArray();
            JSONObject activeFolio = new JSONObject();
            activeFolio.put("activeFolio", true);
            activeFolioJsonArray.put(activeFolio);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioTable");


            /*https://demo.investwell.app/webapi/client/dashboard/getPortfolioReturns?
            filters=[{"endDate":"2019-09-13"}]&group=appid&componentForLoader=
            {"componentName":"folioTable"}&pageSize=20¤tPage=1&investorUid=
            68e4b40eedf91ed2fc94460512aff049&selectedUser=
            {"uid":"68e4b40eedf91ed2fc94460512aff049","levelNo":"98"}*/


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_EXISTING_INVESTMENT + "filters=" + activeFolioJsonArray.toString()
                    + "&pageSize=100&currentPage=1" +
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "";
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        SetData(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getAllTransactionTypes(String schemeCode, String folioId, String transactionType, JSONObject jsonObjectMain) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            String varableForBSeMfu = "";
            if (mSession.getExchangeNseBseMfu().equals("2")) {
                varableForBSeMfu = "&hasBseCode=true";
            } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                varableForBSeMfu = "&hasMfuCode=true";
            }else if (mSession.getExchangeNseBseMfu().equals("4")) {
                varableForBSeMfu = "&hasNseInvestCode=true"  ;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TRANSECTION_TYPE + "schid=" + schemeCode + varableForBSeMfu + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "&bid=" + mSession.getBid() + "&exchange=" + mSession.getExchangeNseBseMfu() + "&levelid=" + mSession.getLevelId();
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }
        ProgressBarCommon.showDialog(requireActivity());

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        tranJsonObject = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = tranJsonObject.getJSONArray("allowedInvestmentTypes");
                        if (jsonArray.length() > 0) {
                            ArrayList<String> list = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                String transectionType = jsonArray.getString(i);
                                list.add(transectionType);
                            }


                            if (mSession.getHasMultiExchange()) {
                                ProgressBarCommon.dismissDialog();

                                Bundle bundle = new Bundle();
                                // getUccIinMfu(folioId, transactionType, jsonObjectMain); // multiple profile
                                bundle.putString("comefrom", "additionalPurchase");
                                bundle.putString("transactionType", transactionType);
                                bundle.putString("oldObject", jsonObjectMain.toString());
                                bundle.putString("tranJsonObject", jsonObjectMain.toString());
                                mActivity.displayViewOther(76, bundle);
                            }else {
                                ProgressBarCommon.dismissDialog();
                                getUccIinMfu(folioId, transactionType, jsonObjectMain); // multiple profile
//                                checkPurchaseValidation(transactionType, jsonObjectMain);
                            }

                        } else {
                            ProgressBarCommon.dismissDialog();
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(getActivity(), "Failed", getString(R.string.TransactionNotAllowed), "message");
                        }

                    } else if (jsonObject.optInt("status") == -1) {
                        ProgressBarCommon.dismissDialog();
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), getString(R.string.failed), getString(R.string.TransactionNotAllowed), "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    ProgressBarCommon.dismissDialog();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                ProgressBarCommon.dismissDialog();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getUccIinMfu(String mFolioId, String transectionType, JSONObject jsonObject) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("componentName", "investOnline");

            String exchange = "";
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            } else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            } else if (mSession.getHasNse2Opted()){
                exchange = "4";
            }else {
                exchange = mSession.getExchangeNseBseMfu();
            }

            if (exchange.equals("1")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_IIN_BY_FOLIO + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("2")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_UCC_LIST + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("3")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CAN_LIST + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("4")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_SELECTED_UCC_NSE2 + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }

            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                ProgressBarCommon.dismissDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {

                        mUccIinResponseObject = jsonObject.optJSONObject("result");

                        // Message will be show when recomended false as well as no any ucc/iin
                        if (!mUccIinResponseObject.optBoolean("recommended")) {
                            JSONArray jsonArray = mUccIinResponseObject.getJSONArray("data");
                            if (jsonArray.length() > 0) {

                            } else {

                                if (mSession.getExchangeNseBseMfu().equals("1")) {
                                    Toast.makeText(mActivity, getString(R.string.no_iin_available), Toast.LENGTH_SHORT).show();
                                } else if (mSession.getExchangeNseBseMfu().equals("2")) {
                                    Toast.makeText(mActivity, getString(R.string.no_ucc_available), Toast.LENGTH_SHORT).show();
                                } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                                    Toast.makeText(mActivity, getString(R.string.no_can_available), Toast.LENGTH_SHORT).show();
                                } else if (mSession.getExchangeNseBseMfu().equals("4")) {
                                    Toast.makeText(mActivity, getString(R.string.no_can_available), Toast.LENGTH_SHORT).show();
                                }

                            }
                        }

                    } else if (jsonObject.optInt("status") == -1) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), getString(R.string.failed), jsonObject.optString("message"), "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                } finally {
                    checkPurchaseValidation(transectionType, jsonObject);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
