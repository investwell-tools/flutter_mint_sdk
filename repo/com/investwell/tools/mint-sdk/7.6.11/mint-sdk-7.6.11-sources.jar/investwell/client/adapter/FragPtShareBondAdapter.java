package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FragPtShareBondAdapter extends RecyclerView.Adapter<FragPtShareBondAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private AppSession mSession;
    private Context mContext;
    private OnItemClickListener listener;
    AppApplication mAppplication;

    public FragPtShareBondAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
        mAppplication = (AppApplication) context.getApplicationContext();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_share_bond_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onSchemeClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView mTvName, mTvCurrent, mTvTotalGain, mTvOneDayChange,
                  tvCAGR, mTvAbsolute, tvPurchageValue, tvDividend;

        public ViewHolder(View view) {
            super(view);
            mTvName = view.findViewById(R.id.tvName);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvTotalGain = view.findViewById(R.id.tvTotalGain);
            mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
            tvDividend = view.findViewById(R.id.tvDividend);
            mTvAbsolute = view.findViewById(R.id.tvAbsolute);
            tvCAGR = view.findViewById(R.id.tvCagr);
            tvPurchageValue = view.findViewById(R.id.tvPurchageValue);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObjectSummary = mDataList.get(position);
              //  linerFolio.setVisibility(View.INVISIBLE);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

             /*   double totalGain = jsonObjectSummary.optDouble("gain");
                String strTotalGain = format.format(totalGain);
                mTvTotalGain.setText(strTotalGain);*/

                mTvName.setText(jsonObjectSummary.optString("applicantName"));

                double purchaseValue = 0;
                if (jsonObjectSummary.has("purchaseValue")){
                    purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                }else{
                    purchaseValue = jsonObjectSummary.optDouble("remainingBalUnitsPurchaseValue");
                }
                String strpurchaseValue = format.format(purchaseValue);
                tvPurchageValue.setText(strpurchaseValue);

                double dividend = jsonObjectSummary.optDouble("dividend");
                String strDividend = format.format(dividend);
                tvDividend.setText(strDividend);

                double cgrValue = jsonObjectSummary.optDouble("absoluteReturn");
                String data2 = String.format("%.2f", cgrValue) + "%";
                mTvAbsolute.setText(data2);

                double gain = jsonObjectSummary.optDouble("gain");
                Utils.checkNegativeAndPositiveValue(mTvTotalGain,gain,mContext);
                //  String strTotalGain = format.format(gain);
                //   mTvTotalGain.setText(strTotalGain);

                double CAGR = jsonObjectSummary.optDouble("CAGR");
                Utils.checkNegativeAndPositiveWithSign(tvCAGR,CAGR,mContext);


                if (mAppplication.isDaysChange) {
                    double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                    String strOneDayChange = format.format(oneDayChange);
                    double changePercent = jsonObjectSummary.optDouble("changePercent");
                    String changePercentStr = String.format("%.2f", changePercent) + "%";
                    if (oneDayChange == 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (+" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black));
                    } else if (oneDayChange > 0) {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (+" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.marketGreen));
                    } else {
                        mTvOneDayChange.setVisibility(View.VISIBLE);
                        mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                        mTvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                    }
                } else {
                    mTvOneDayChange.setVisibility(View.GONE);
                }


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
