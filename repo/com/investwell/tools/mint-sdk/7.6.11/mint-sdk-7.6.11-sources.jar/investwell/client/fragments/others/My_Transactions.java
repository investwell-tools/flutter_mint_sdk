package investwell.client.fragments.others;

import static android.os.Build.VERSION.SDK_INT;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.ExtensionsKt.formatDateToYYYYMMDD;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;
import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UrlEncoderDecoderKt.decode;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.textfield.TextInputLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Transaction_Adapter;
import investwell.common.transactions.fragments.FragTransactionHome;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class My_Transactions extends BaseFragment implements View.OnClickListener {
    private RecyclerView transaction_recyclier;
    private StringRequest stringRequest;
    private Transaction_Adapter transaction_adapter;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private boolean loading = false;
    private  int mCurrentPageNo = 1;
    private LinearLayout fullScreenShedow, linerUsers;
//    private FloatingActionButton mFilterIcon;
    private boolean isClickedApply = false;
    private RelativeLayout mRelFilterMain;
    private RelativeLayout singleShedow;
    private ShimmerFrameLayout mShimmerViewContainer;
    AutoCompleteTextView spSelectMemberPDF;


    private RequestQueue requestQueue;

    private final boolean mIsFirstTime = true;
    private TextView mTvStartDate, mTvEndDate;
    private String mStartingDate = "", mEndDate = "", mStartDatePDF = "", mEndDatePDF = "";
    private LinearLayout mLinFilterPart, mLinerCustomDuration;
    private Animation slideUpAnimation, slideDownAnimation;
    private List<JSONObject> mMemberList, mMemberTypesList;
    private Spinner mMemberSpinner, mSpUserType;
    private int mSelectedPosition = 0, mSelectedUserTypePosition = 0, mSelectedPositionMemberPDF = 0;
    private LinearLayout mLinerNoDataFound;
    private LinearLayout mLinerUserType, mLinerUsers;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private CheckBox cbAll,cbPurchaseTye1, cbPurchaseTye2, cbPurchaseTye3, cbPurchaseTye4, cbPurchaseTye5, cbPurchaseTye6, cbSellTye1, cbSellTye2, cbSellTye3, cbSellTye4, cbSellTye5;
    private RadioGroup radioGroup;
    private RadioButton radio3, radio4;
    private String mMembersRawData = "";

    private LinearLayout mFilterLayout;

    private int mFetchListSize = 20;

    @Override
    public void onResume() {
        super.onResume();
      /*  if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
   */
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

//    private void setUpToolBar(boolean isShowDownload) {
//        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
//        if (fragToolBar != null) {
//            if (mBrokerActivity != null) {
//                fragToolBar.setUpToolBar(requireActivity().getResources().getString(R.string.transactions), true, false, false, false, false, false, false);
//            } else {
//                fragToolBar.setUpToolBar(requireActivity().getResources().getString(R.string.transactions), false, false, false, isShowDownload, false, false, false);
//            }
//        }
//        fragToolBar.setCallback(this);
//    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_my__transactions, container, false);

//        if (mBrokerActivity != null) {
//            mBrokerActivity.setMainVisibility(this, null);
//        } else {
//            mMainActivity.setMainVisibility(this, null);
//        }

        // check feature permission  if exist then show download
        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
        boolean isShowDownload = false;
        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
            JSONObject mJsoObject = null;
            try {
                mJsoObject = new JSONObject(allowedFeatured);
                JSONArray jsonArray = mJsoObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.optJSONObject(i).has("feature1003")) {
                        isShowDownload = true;
                    }
                }
//                setUpToolBar(isShowDownload);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }

        mMemberSpinner = view.findViewById(R.id.member_spinner);

        mSpUserType = view.findViewById(R.id.spUserType);
        mLinerUserType = view.findViewById(R.id.linerUserType);
        mLinerUsers = view.findViewById(R.id.linerUsers);

        cbAll = view.findViewById(R.id.cbAll);
        cbPurchaseTye1 = view.findViewById(R.id.cbPurchaseTye1);
        cbPurchaseTye2 = view.findViewById(R.id.cbPurchaseTye2);
        cbPurchaseTye3 = view.findViewById(R.id.cbPurchaseTye3);
        cbPurchaseTye4 = view.findViewById(R.id.cbPurchaseTye4);
        cbPurchaseTye5 = view.findViewById(R.id.cbPurchaseTye5);
        cbPurchaseTye6 = view.findViewById(R.id.cbPurchaseTye6);

        radio3 = view.findViewById(R.id.radio3);
        radio4 = view.findViewById(R.id.radio4);

        cbSellTye1 = view.findViewById(R.id.cbSellTye1);
        cbSellTye2 = view.findViewById(R.id.cbSellTye2);
        cbSellTye3 = view.findViewById(R.id.cbSellTye3);
        cbSellTye4 = view.findViewById(R.id.cbSellTye4);
        cbSellTye5 = view.findViewById(R.id.cbSellTye5);
        cbAll.setVisibility(View.VISIBLE);
        cbAll.setOnClickListener(view1 -> {
            boolean isChecked = cbAll.isChecked();
            cbPurchaseTye1.setChecked(isChecked);
            cbPurchaseTye2.setChecked(isChecked);
            cbPurchaseTye3.setChecked(isChecked);
            cbPurchaseTye4.setChecked(isChecked);
            cbPurchaseTye5.setChecked(isChecked);
            cbPurchaseTye6.setChecked(isChecked);
            cbSellTye1.setChecked(isChecked);
            cbSellTye2.setChecked(isChecked);
            cbSellTye3.setChecked(isChecked);
            cbSellTye4.setChecked(isChecked);
            cbSellTye5.setChecked(isChecked);
        });

        cbPurchaseTye1.setOnClickListener(view1 -> updateCheckBoxes());
        cbPurchaseTye2.setOnClickListener(view1 -> updateCheckBoxes());
        cbPurchaseTye3.setOnClickListener(view1 -> updateCheckBoxes());
        cbPurchaseTye4.setOnClickListener(view1 -> updateCheckBoxes());
        cbPurchaseTye5.setOnClickListener(view1 -> updateCheckBoxes());
        cbPurchaseTye6.setOnClickListener(view1 -> updateCheckBoxes());
        cbSellTye1.setOnClickListener(view1 -> updateCheckBoxes());
        cbSellTye2.setOnClickListener(view1 -> updateCheckBoxes());
        cbSellTye3.setOnClickListener(view1 -> updateCheckBoxes());
        cbSellTye4.setOnClickListener(view1 -> updateCheckBoxes());
        cbSellTye5.setOnClickListener(view1 -> updateCheckBoxes());


        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
//        mFilterIcon = view.findViewById(R.id.filters);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mLinerCustomDuration = view.findViewById(R.id.linerCustomDuration);
        mLinerCustomDuration.setVisibility(View.GONE);

        mTvStartDate = view.findViewById(R.id.tvSTart);
        mTvEndDate = view.findViewById(R.id.tvEnd);
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        mFilterLayout = view.findViewById(R.id.llFilter);

        slideUpAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_down);
        transaction_recyclier = view.findViewById(R.id.recycleView);

        setUpRecyclerView();


//        mFilterIcon.setOnClickListener(this);
        mTvStartDate.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);
        mFilterLayout.setOnClickListener(this);

        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);

        radioGroup = view.findViewById(R.id.rdGroup);
        radioGroup.check(R.id.radio5);
        mLinerCustomDuration.setVisibility(View.VISIBLE);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                mLinerCustomDuration.setVisibility(View.GONE);
                int position = radioGroup.indexOfChild(view.findViewById(i));
                switch (position) {
                    case 0:
                        dateCalculation("currentMonth");
                        break;

                    case 1:
                        dateCalculation("prevMonth");
                        break;

                    case 2:
                        dateCalculation("currentFy");
                        break;

                    case 3:
                        dateCalculation("previousFy");
                        break;

                    case 4:
                        dateCalculation("custom");
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                }

            }

        });

        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);

//                mFilterIcon.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            if (mSession.getClientObject().isEmpty()) {
                mLinerUserType.setVisibility(View.VISIBLE);
                mLinerUsers.setVisibility(View.VISIBLE);
                setSpinnerMemberType();
            } else {
                mLinerUserType.setVisibility(View.GONE);
                mLinerUsers.setVisibility(View.VISIBLE);
                getAllMembers("client", false);
            }
        } else {
            mLinerUserType.setVisibility(View.GONE);
            mLinerUsers.setVisibility(View.VISIBLE);
            getAllMembers("client", false);
        }

        dateCalculation("custom");
        mLinerCustomDuration.setVisibility(View.VISIBLE);
        checkTransactionData(1);

        LinearLayout purchaseContainer = mRelFilterMain.findViewById(R.id.llPurchaseTypes);
        CheckBox[] purchaseCheckBoxes = new CheckBox[]{
                cbPurchaseTye1,
                cbPurchaseTye2,
                cbPurchaseTye3,
                cbPurchaseTye4,
                cbPurchaseTye5,
                cbPurchaseTye6
        };
        applyCheckboxListAccessibility(purchaseContainer,purchaseCheckBoxes);

        LinearLayout sellContainer = mRelFilterMain.findViewById(R.id.llSellTypes);
        CheckBox[] sellCheckBoxes = new CheckBox[]{
                cbSellTye1,
                cbSellTye4,
                cbSellTye2,
                cbSellTye3,
                cbSellTye5
        };
        applyCheckboxListAccessibility(sellContainer,sellCheckBoxes);

        return view;
    }

    private void setUpRecyclerView() {

        transaction_recyclier.setNestedScrollingEnabled(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(requireActivity());
        mLayoutManager = layoutManager;
        transaction_recyclier.setLayoutManager(layoutManager);

        transaction_adapter = new Transaction_Adapter(getActivity(), new ArrayList<>());
        transaction_recyclier.setAdapter(transaction_adapter);

        boolean isBroker = mSession.getHasLoging() && "broker".equals(mSession.getLoginType()) && mSession.getClientObject().isEmpty();
        if(isBroker) {
            transaction_recyclier.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(@NonNull RecyclerView rv, int dx, int dy) {
                    super.onScrolled(rv, dx, dy);

                    if (dy <= 0 || loading) return;

                    visibleItemCount = (mLayoutManager != null) ? mLayoutManager.getChildCount() : 0;
                    totalItemCount = (mLayoutManager != null) ? mLayoutManager.getItemCount() : 0;
                    pastVisiblesItems = (mLayoutManager != null) ? mLayoutManager.findFirstVisibleItemPosition() : 0;

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = (double) totalItemCount / mFetchListSize;
                            int page = (int) value;

                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo += 1;
                                checkTransactionData(mCurrentPageNo);
                            }
                        }
                    }
                }
            });
        }
    }

    private void updateCheckBoxes() {
        boolean isAllChecked =
                cbPurchaseTye1.isChecked() && cbPurchaseTye2.isChecked() &&
                        cbPurchaseTye3.isChecked() && cbPurchaseTye4.isChecked() &&
                        cbPurchaseTye5.isChecked() && cbPurchaseTye6.isChecked() &&
                        cbSellTye1.isChecked() && cbSellTye2.isChecked() &&
                        cbSellTye3.isChecked() && cbSellTye4.isChecked() &&
                        cbSellTye5.isChecked();

        cbAll.setChecked(isAllChecked);
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() ==  R.id.llFilter) {
                showFilterBottomSheetMF();
}
else if (v.getId() == R.id.ivClose) {
//                Fragment parentFragment = getParentFragment();
//                if (parentFragment instanceof FragTransactionHome) {
//                    ((FragTransactionHome) parentFragment).enableFilterButton();
//                }
                enableFilterButton();
                mRelFilterMain.announceForAccessibility(getString(R.string.filter_dialog_collapsed));
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                filterValidation();
}
else if (v.getId() == R.id.tvSTart) {
                radioGroup.check(R.id.radio5);
                SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

                showDatePickerDialog(
                        requireContext(),
                        this,
                        null, //min date
                        null, //max date
                        mStartingDate, // default date
                        inputDateFormat,
                        outputDateFormat,
                        date -> {
                            mTvStartDate.setText(date);
                            mStartingDate = formatDateToYYYYMMDD(date);
                            return null;
                        }
                );
}
else if (v.getId() == R.id.tvEnd) {
                radioGroup.check(R.id.radio5);
                SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                SimpleDateFormat outputDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

                showDatePickerDialog(
                        requireContext(),
                        this,
                        null, //min date
                        null, //max date
                        mEndDate, // default date
                        inputDateFormat,
                        outputDateFormat,
                        date -> {
                            mTvEndDate.setText(date);
                            mEndDate = formatDateToYYYYMMDD(date);
                            return null;
                        }
                );
}
else if (v.getId() == R.id.ivLeft) {
                getActivity().getSupportFragmentManager().popBackStack();
}
    }

//    @Override
//    public void onToolbarItemClick(View view) {
//        switch (view.getId()) {
//            case R.id.iv_pdf_download:
//                // pdfDownloadDailog();
//                downloadFile2();
//                break;
//        }
//
//    }

    private void refreshDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy", new Locale("en","in"));
        String strShowStartDate = "";
        String strShowEndDate = "";

        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            if (mSession.getClientObject().isEmpty()) {
                Calendar mCalender = Calendar.getInstance();
                Date todayDate = mCalender.getTime();
                strShowStartDate = formatterForText.format(todayDate);
                mEndDate = formatter.format(todayDate);

                mCalender.add(Calendar.DAY_OF_YEAR, -15);
                Date previousDays = mCalender.getTime();
                strShowEndDate = formatterForText.format(previousDays);
                mStartingDate = formatter.format(previousDays);
            } else {
                Calendar mCalender = Calendar.getInstance();
                Date todayDate = mCalender.getTime();
                strShowStartDate = formatterForText.format(todayDate);
                mEndDate = formatter.format(todayDate);

                mCalender.add(Calendar.DAY_OF_YEAR, -30);
                Date previousDays = mCalender.getTime();
                strShowEndDate = formatterForText.format(previousDays);
                mStartingDate = formatter.format(previousDays);
            }
        } else {
            Calendar mCalender = Calendar.getInstance();
            Date todayDate = mCalender.getTime();
            mEndDate = formatter.format(todayDate);
            strShowStartDate = formatterForText.format(todayDate);

            mCalender.add(Calendar.DAY_OF_YEAR, -30);
            Date previousDays = mCalender.getTime();
            strShowEndDate = formatterForText.format(previousDays);
            mStartingDate = formatter.format(previousDays);
        }

//        mTvStartDate.setText(strShowStartDate);
//        mTvEndDate.setText(strShowEndDate);
        mTvStartDate.setText(strShowEndDate);
        mTvEndDate.setText(strShowStartDate);
    }


   public void filterValidation() {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            Fragment parentFragment = getParentFragment();

            // get selected radio button from radioGroup
            int selectedId = radioGroup.getCheckedRadioButtonId();
            if (selectedId == R.id.radio5) {
                Date date1 = formatter.parse(mStartingDate);
                Date date2 = formatter.parse(mEndDate);
                if (System.currentTimeMillis() < date1.getTime()) {
                    Toast.makeText(getActivity(), getString(R.string.invalid_start_date), Toast.LENGTH_SHORT).show();
                } else if (System.currentTimeMillis() < date2.getTime()) {
                    Toast.makeText(getActivity(), getString(R.string.invalid_end_date), Toast.LENGTH_SHORT).show();
                } else if (date1.getTime() > date2.getTime()) {
                    Toast.makeText(getActivity(), getString(R.string.please_check_start_date_and_end_date), Toast.LENGTH_SHORT).show();
                } else {
                    mLinFilterPart.startAnimation(slideDownAnimation);
                    isClickedApply = true;
                    mRelFilterMain.announceForAccessibility(getString(R.string.filter_applied));
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
//                            if (parentFragment instanceof FragTransactionHome) {
//                                ((FragTransactionHome) parentFragment).enableFilterButton();
//                            }
                            enableFilterButton();
                            checkTransactionData(1);
                        }
                    }, 500);

                }
            } else {
                mLinFilterPart.startAnimation(slideDownAnimation);
                isClickedApply = true;
//                if (parentFragment instanceof FragTransactionHome) {
//                    ((FragTransactionHome) parentFragment).enableFilterButton();
//                }
                mRelFilterMain.announceForAccessibility(getString(R.string.filter_applied));
                enableFilterButton();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        checkTransactionData(1);
                    }
                }, 500);
            }


        } catch (ParseException e1) {
            e1.printStackTrace();
        }
    }

    private void applyCheckboxListAccessibility(
            ViewGroup container,
            CheckBox[] checkBoxes
    ) {

        // 1️⃣ Mark container as a LIST
        ViewCompat.setAccessibilityDelegate(container,
                new AccessibilityDelegateCompat() {
                    @Override
                    public void onInitializeAccessibilityNodeInfo(
                            View host,
                            AccessibilityNodeInfoCompat info) {

                        super.onInitializeAccessibilityNodeInfo(host, info);

                        info.setCollectionInfo(
                                AccessibilityNodeInfoCompat.CollectionInfoCompat.obtain(
                                        checkBoxes.length, // total items
                                        1,                 // one column
                                        false              // not hierarchical
                                )
                        );
                    }
                });

        // 2️⃣ Mark each checkbox as a LIST ITEM
        for (int i = 0; i < checkBoxes.length; i++) {

            final int index = i;
            CheckBox checkBox = checkBoxes[i];

            ViewCompat.setAccessibilityDelegate(checkBox,
                    new AccessibilityDelegateCompat() {
                        @Override
                        public void onInitializeAccessibilityNodeInfo(
                                View host,
                                AccessibilityNodeInfoCompat info) {

                            super.onInitializeAccessibilityNodeInfo(host, info);

                            info.setCollectionItemInfo(
                                    AccessibilityNodeInfoCompat.CollectionItemInfoCompat.obtain(
                                            index,            // row index
                                            1,                // row span
                                            0,                // column index
                                            1,                // column span
                                            checkBox.isChecked()
                                    )
                            );
                        }
                    });
        }
    }


    private void datePicker(final boolean isStartDate) {
        Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = 0;
        int mDay = 0;
        if (isStartDate) {
            c.add(Calendar.MONTH, -1);
        } else {
            c.add(Calendar.DAY_OF_MONTH, -1);
        }

        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                if (view.isShown()) {
                    NumberFormat formatter = new DecimalFormat("00");
                    String day = formatter.format((dayOfMonth));
                    String month = formatter.format((monthOfYear + 1));
                    String date_time = year + "-" + month + "-" + day;
                    String date_for_text = day + "-" + month + "-" + year;


                    if (isStartDate) {
                        mTvStartDate.setText(date_for_text);
                        mStartingDate = date_time;
                    } else {
                        mTvEndDate.setText(date_for_text);
                        mEndDate = date_time;
                    }
                }

            }
        }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }


    private void showLoading(int pageNo,boolean isLoading) {
        if (pageNo!=0){
            if (isLoading){
                mShimmerViewContainer.setVisibility(View.VISIBLE);
                mShimmerViewContainer.stopShimmer();
                if (pageNo > 1) {
                    singleShedow.setVisibility(View.VISIBLE);
                    fullScreenShedow.setVisibility(View.GONE);
                } else {
                    transaction_adapter.mDataList.clear();
                    transaction_recyclier.setVisibility(View.GONE);
                    singleShedow.setVisibility(View.GONE);
                    fullScreenShedow.setVisibility(View.VISIBLE);
                }
            }else {
                mShimmerViewContainer.stopShimmer();
                mShimmerViewContainer.setVisibility(View.GONE);
                transaction_recyclier.setVisibility(View.VISIBLE);
            }
        }else {
            if (isLoading){
                mShimmerViewContainer.startShimmer();
                mShimmerViewContainer.setVisibility(View.VISIBLE);
            }else{
                mShimmerViewContainer.stopShimmer();
                mShimmerViewContainer.setVisibility(View.GONE);
                transaction_recyclier.setVisibility(View.VISIBLE);
            }
        }
    }


    private JSONObject getSelectedUser() throws JSONException {

        JSONObject user = new JSONObject();

        if (mSelectedPosition != 0) {
            JSONObject member = mMemberList.get(mSelectedPosition - 1);
            user.put("uid", member.optString("uid"));
            user.put("levelNo", member.optString("levelNo"));

        } else {
            String uid;
            String levelNo;
            if (mSession.getHasLoging() && "broker".equals(mSession.getLoginType())) {
                if (mSession.getClientObject().isEmpty()) {
                    uid = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                } else {
                    JSONObject obj = UtilityKotlin.getClientHopObject(mSession);
                    uid = obj.optString("uid");
                    levelNo = obj.optString("levelNo");
                }
            } else {
                uid = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            user.put("uid", uid);
            user.put("levelNo", levelNo);
        }
        return user;
    }

    private JSONArray buildFilters() throws JSONException {
        JSONArray filters = new JSONArray();
        JSONObject txnTypes = new JSONObject();
        txnTypes.put("txnTypeNotIn", getTxnTypeArray());
        filters.put(txnTypes);
        JSONObject fromDate = new JSONObject();
        fromDate.put("fromDate", mStartingDate);

        JSONObject toDate = new JSONObject();
        toDate.put("toDate", mEndDate);
        filters.put(fromDate);
        filters.put(toDate);

        return filters;
    }

    private JSONArray getTxnTypeArray() {

        JSONArray array = new JSONArray();

        if (!cbPurchaseTye1.isChecked()) array.put("NRP");
        if (!cbPurchaseTye2.isChecked()) array.put("SIP");
        if (!cbPurchaseTye3.isChecked()) array.put("STI");
        if (!cbPurchaseTye4.isChecked()) array.put("SWI");
        if (!cbPurchaseTye5.isChecked()) array.put("DIR");
        if (!cbPurchaseTye6.isChecked()) array.put("BON");

        if (!cbSellTye1.isChecked()) array.put("NRS");
        if (!cbSellTye2.isChecked()) array.put("STO");
        if (!cbSellTye3.isChecked()) array.put("SWO");
        if (!cbSellTye4.isChecked()) array.put("SWP");
        if (!cbSellTye5.isChecked()) array.put("DVP");

        return array;
    }


    private String buildTransactionUrl(
            String api,
            String uid,
            JSONObject selectedUser,
            JSONArray filters,
            int pageNo,
            boolean isBroker
    ) {
        String baseUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath();
        String url = baseUrl + api +
                "orderByDesc=true" +
                "&orderBy=navDate" +
                "&filters=" + filters +
                "&clubTxns=true";
        if (isBroker) {
            url += "&currentPage=" + pageNo + "&pageSize=20";
        }
        url += "&investorUid=" + uid + "&selectedUser=" + selectedUser;
        return decode(url,"UTF-8");
    }

    private void checkTransactionData(int pageNo){
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) return;
        try {
            JSONObject selectedUser = getSelectedUser();
            String uid = selectedUser.optString("uid");
            JSONArray filters = buildFilters();
            String api;
            boolean isBroker = mSession.getHasLoging() && "broker".equals(mSession.getLoginType()) && mSession.getClientObject().isEmpty();
            if (isBroker) {
                api = Config.GET_TRANSECTIONS_BROKER;
            } else {
                api = Config.GET_TRANSECTIONS_CLient;
            }
            String url = buildTransactionUrl(api, uid, selectedUser, filters, pageNo, isBroker);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = url.replace(" ", "%20");
            callTransactionApi(url, pageNo);
        } catch (Exception e){if (BuildConfig.DEBUG) e.printStackTrace();}

    }

    private void callTransactionApi(String url, int pageNo) {
        KtorCallBack mResponseCallBack = new KtorCallBack() {
            @Override
            public void onSuccess(String response, int statusCode) {
                if (mBrokerActivity!=null){
                    mBrokerActivity.userDidAction("");
                }else {
                    mMainActivity.userDidAction("");
                }

                loading = false;
                List<JSONObject> list = new ArrayList<>();
                if (pageNo > 1) {
                    list.addAll(transaction_adapter.mDataList);
                }
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            list.add(jsonObject1);
                        }

                    }
                } catch (Exception e) {

                } finally {
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.GONE);
                    transaction_recyclier.setVisibility(View.VISIBLE);

                    if (list.size() > 0) {
                        transaction_adapter.updateList(list);
                        mLinerNoDataFound.setVisibility(View.GONE);
                    } else {
                        transaction_adapter.updateList(new ArrayList<JSONObject>());
                        mLinerNoDataFound.setVisibility(View.VISIBLE);
                    }
                }
            }

            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                loading=isLoading;
                showLoading(pageNo,isLoading);
            }
        };

        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                mResponseCallBack
        );
    }

    //select user types
    public void setSpinnerMemberType() {
        try {
            mMemberTypesList = new ArrayList<>();
            List<String> listMemType = new ArrayList<>();

            JSONArray jsonArray = new JSONArray(mSession.getLowerReportingLevels());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.optJSONObject(i);
                mMemberTypesList.add(jsonObject);
                listMemType.add(jsonObject.optString("levelName"));
            }


            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMemType);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpUserType.setAdapter(adapter);
            mSpUserType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedUserTypePosition = position;
                    getAllMembers("broker", false);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }


    //select member
    public void setSpinnerMembers(String rawData) {
        try {
            mMemberList = new ArrayList<>();
            List<String> listMem = new ArrayList<>();
            listMem.add(getString(R.string.all));

            JSONObject jsonObject = new JSONObject(rawData);

            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    mMemberList.add(jsonObject1);
                    listMem.add(jsonObject1.optString("name"));
                }
            } else {
                String service_msg = jsonObject.optString("message");
                Toast.makeText(getActivity(), service_msg, Toast.LENGTH_SHORT).show();
            }

            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMem);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mMemberSpinner.setAdapter(adapter);
            mMemberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedPosition = position;
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }


    private void setMemberListForPDF() {
        try {
            mMemberList = new ArrayList<>();
            List<String> listMem = new ArrayList<>();
            listMem.add(getString(R.string.all));

            if (!mMembersRawData.equals("")) {
                JSONObject jsonObject = new JSONObject(mMembersRawData);

                if (jsonObject.optInt("status") == 0) {
                    JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                    JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        mMemberList.add(jsonObject1);
                        listMem.add(jsonObject1.optString("name"));
                    }
                } else {
                    String service_msg = jsonObject.optString("message");
                    Toast.makeText(getActivity(), service_msg, Toast.LENGTH_SHORT).show();
                }
            } else {
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    getAllMembers("broker", true);
                } else {
                    getAllMembers("client", true);
                }

            }

            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_dropdown, listMem);
            spSelectMemberPDF.setAdapter(dataAdapter);
            spSelectMemberPDF.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long rowId) {
                    //  String selection = (String) parent.getItemAtPosition(position);
                    mSelectedPositionMemberPDF = position;
                   /* for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).equals(selection)) {
                            mPosArn = i;
                            break;
                        }
                    }*/

                }
            });

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }


    public void getAllMembers(String type, boolean calledForPdf) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        JSONObject jsonObject1 = new JSONObject();
        try {
            String levelNo = "";
            levelNo = Utils.getSelectedLevelNo(mSession);
            if (type.equals("broker")) {
                if (calledForPdf) {
                    levelNo = "100";
                } else {
                    JSONObject jsonObject = mMemberTypesList.get(mSelectedUserTypePosition);
                    levelNo = jsonObject.optString("levelNo");
                }

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MEMBERS + "levelNo=" + levelNo ;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MEMBERS + "levelNo=" + "100" + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = decode(url,"UTF-8");
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                mMembersRawData = response;
                setSpinnerMembers(response);
                if (calledForPdf) {
                    setMemberListForPDF();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (!isAdded()) return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void dateCalculation(String durationType) {
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        if (durationType.equals("currentMonth")) {
            Date todayDate = calendar1.getTime();
            mEndDate = formatter.format(todayDate);

            calendar2.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfCurrentMonth = calendar2.getTime();
            mStartingDate = formatter.format(firstDateOfCurrentMonth);

        } else if (durationType.equals("prevMonth")) {
            calendar1.add(Calendar.MONTH, -1);
            calendar1.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfPreviousMonth = calendar1.getTime();
            mStartingDate = formatter.format(firstDateOfPreviousMonth);

            calendar2.add(Calendar.MONTH, -1);
            calendar2.set(Calendar.DATE, calendar2.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date lastDateOfPreviousMonth = calendar2.getTime();
            mEndDate = formatter.format(lastDateOfPreviousMonth);

        } else if (durationType.equals("currentFy")) {
            Date todayDate = Calendar.getInstance().getTime();
            mStartingDate = getCurrentFinYear(false);
            mEndDate = formatter.format(todayDate);

        } else if (durationType.equals("previousFy")) {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.YEAR, -1);
            mStartingDate = getCurrentFinYear(true);

            int year = calendar.get(Calendar.YEAR);
            mEndDate = (year + 1) + "-03-31";
            System.out.println();

        } else {
            refreshDate();
        }

    }

    private String getCurrentFinYear(boolean isPrev) {
        int month = 0;
        int year = 0;
        Calendar calendar = Calendar.getInstance();
        if (isPrev) {
            year = calendar.get(Calendar.YEAR) - 1;
        } else {
            year = calendar.get(Calendar.YEAR);
        }
        month = calendar.get(Calendar.MONTH) + 1;
        String finYearStardDate = "";
        if (month < 3) {
            finYearStardDate = (year - 1) + "-04-01";
        } else if (month == 3) {
            finYearStardDate = (year - 1) + "-04-01";
        } else {
            finYearStardDate = year + "-04-01";
        }
        return finYearStardDate;
    }


    private void pdfDownloadDailog() {

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_transaction_pdf_download, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();


        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        Button tvDownload = dialogView.findViewById(R.id.tvDownload);
        LinearLayout llSubMenu = dialogView.findViewById(R.id.linerMain);

        TextInputLayout tiStartDate = dialogView.findViewById(R.id.tiStartDate);
        spSelectMemberPDF = dialogView.findViewById(R.id.spSelectMember);
        AutoCompleteTextView spStartDate = dialogView.findViewById(R.id.spStartDate);
        AutoCompleteTextView spEndDate = dialogView.findViewById(R.id.spEndDate);

        spSelectMemberPDF.setTag(spSelectMemberPDF.getKeyListener());
        spSelectMemberPDF.setKeyListener(null);

        spStartDate.setTag(spStartDate.getKeyListener());
        spStartDate.setKeyListener(null);

        spEndDate.setTag(spEndDate.getKeyListener());
        spEndDate.setKeyListener(null);

        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy");

        calendar1.add(Calendar.MONTH, -1);
        calendar1.set(Calendar.DAY_OF_MONTH, calendar1.getActualMinimum(Calendar.DAY_OF_MONTH));
        Date firstDateOfPreviousMonth = calendar1.getTime();
        mStartDatePDF = formatter.format(firstDateOfPreviousMonth);

        calendar2.add(Calendar.MONTH, -1);
        calendar2.set(Calendar.DATE, calendar2.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date lastDateOfPreviousMonth = calendar2.getTime();
        mEndDatePDF = formatter.format(lastDateOfPreviousMonth);

        spStartDate.setText(formatterForText.format(firstDateOfPreviousMonth));
        spEndDate.setText(formatterForText.format(lastDateOfPreviousMonth));

        setMemberListForPDF();
        spStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePicker2(true, spStartDate);
            }
        });

        spEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePicker2(false, spEndDate);
            }
        });

        tvDownload.setOnClickListener(v -> {
            alertDialog.dismiss();
            downloadFile2();
        });

        alertDialog.show();
    }

    private void datePicker2(final boolean isStartDate, AutoCompleteTextView autoCompleteTextView) {
        Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = 0;
        int mDay = 0;
        if (isStartDate) {
            c.add(Calendar.MONTH, -1);
        } else {
            c.add(Calendar.DAY_OF_MONTH, -1);
        }

        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                if (view.isShown()) {
                    NumberFormat formatter = new DecimalFormat("00");
                    String day = formatter.format((dayOfMonth));
                    String month = formatter.format((monthOfYear + 1));
                    String date_time = year + "-" + month + "-" + day;
                    String date_for_text = day + "-" + month + "-" + year;

                    autoCompleteTextView.setText(date_for_text);
                    if (isStartDate) {
                        mStartDatePDF = date_time;
                    } else {
                        mEndDatePDF = date_time;
                    }

                }

            }
        }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }


    public void downloadFile2() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        String uId = "";
        String url = "";
        String levelNo = "";

        try {
            JSONObject jsonObject1 = new JSONObject();

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("fromDate", mStartingDate);
            jsonArray.put(dateObject);

            JSONObject dateObject2 = new JSONObject();
            dateObject2.put("toDate", mEndDate);
            jsonArray.put(dateObject2);


            // {"txnTypeNotIn":["NRP","SIP","STI","SWI","DIR","BON","NRS","STO","SWO","SWP","DVP"]}
            // ArrayList<String> stringArrayList = new ArrayList<String>();

            JSONArray stringArrayList = new JSONArray();
            if (!cbPurchaseTye1.isChecked()) {
                stringArrayList.put("NRP");
            }
            if (!cbPurchaseTye2.isChecked()) {
                stringArrayList.put("SIP");
            }
            if (!cbPurchaseTye3.isChecked()) {
                stringArrayList.put("STI");
            }
            if (!cbPurchaseTye4.isChecked()) {
                stringArrayList.put("SWI");
            }
            if (!cbPurchaseTye5.isChecked()) {
                stringArrayList.put("DIR");
            }
            if (!cbPurchaseTye6.isChecked()) {
                stringArrayList.put("BON");
            }

            if (!cbSellTye1.isChecked()) {
                stringArrayList.put("NRS");
            }
            if (!cbSellTye2.isChecked()) {
                stringArrayList.put("STO");
            }
            if (!cbSellTye3.isChecked()) {
                stringArrayList.put("SWO");
            }
            if (!cbSellTye4.isChecked()) {
                stringArrayList.put("SWP");
            }
            if (!cbSellTye5.isChecked()) {
                stringArrayList.put("DVP");
            }

            JSONObject TranjsonObject1 = new JSONObject();
            TranjsonObject1.put("txnTypeNotIn", stringArrayList);
            jsonArray.put(TranjsonObject1);


            if (mSelectedPosition != 0) {
                JSONObject jsonObject = mMemberList.get(mSelectedPosition - 1);
                jsonObject1.put("levelNo", jsonObject.optString("levelNo"));
                uId = jsonObject.optString("uid");
                jsonObject1.put("uid", uId);
            } else {
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    if (mSession.getClientObject().isEmpty()) {
                      /*  uId = mSession.getUid();
                        levelNo = mSession.getLevelNo();*/
                    } else {
                        uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                        levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                    }
                } else {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                }
                jsonObject1.put("uid", uId);
                jsonObject1.put("levelNo", levelNo);
            }


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_TRANSACION_PDF_CLIENT + "filters=" + jsonArray + "&clubTxns=true" + "&selectedUser=" + jsonObject1;

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = decode(url,"UTF-8");

        } catch (Exception e) {
        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "transactionStatement", "",new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null){
                            mBrokerActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_statement_download_successfully), "pdf", mFileSave, uri);
                        }else {
                            mMainActivity.showCommonDownload(mMainActivity, getString(R.string.txt_successfully), getString(R.string.txt_statement_download_successfully), "pdf", mFileSave, uri);

                        }
                    }
                });

    }


    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");

        }
    }

    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }

    }

    private final ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {
            Log.d("DB", "PERMISSION GRANTED");
        } else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2();
        }
    });

    public void showFilterBottomSheetMF()
    {
        mRelFilterMain.announceForAccessibility(getString(R.string.filter_dialog_expanded));
        moveAccessibilityFocusToFilter();
        mRelFilterMain.setVisibility(View.VISIBLE);
        disableFilterButton();
        Fragment parentFragment = getParentFragment();
        if (parentFragment instanceof FragTransactionHome) {
            ((FragTransactionHome) parentFragment).hideAddButton(0);
        }
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
            radio3.setVisibility(View.GONE);
            radio4.setVisibility(View.GONE);
        } else {
            radio3.setVisibility(View.VISIBLE);
            radio4.setVisibility(View.VISIBLE);
        }
        mLinFilterPart.startAnimation(slideUpAnimation);
    }

    private void moveAccessibilityFocusToFilter() {

        final View targetView = mRelFilterMain.findViewById(R.id.filterDialogHeading); // best focus target

        targetView.post(new Runnable() {
            @Override
            public void run() {

                targetView.setFocusable(true);
                targetView.setFocusableInTouchMode(true);
                targetView.setImportantForAccessibility(
                        View.IMPORTANT_FOR_ACCESSIBILITY_YES
                );

                targetView.requestFocus();

                targetView.sendAccessibilityEvent(
                        AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED
                );
            }
        });
    }

    private void disableFilterButton(){
        mFilterLayout.setEnabled(false);
    }
    private void enableFilterButton(){
        mFilterLayout.setEnabled(true);
    }


}
