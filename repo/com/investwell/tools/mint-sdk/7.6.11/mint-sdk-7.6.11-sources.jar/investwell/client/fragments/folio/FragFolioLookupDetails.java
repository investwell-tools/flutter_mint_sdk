package investwell.client.fragments.folio;

import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.common.api.Api;
import com.google.android.material.card.MaterialCardView;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import timber.log.Timber;


public class FragFolioLookupDetails extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    RequestQueue requestQueue;
    private TextView tvSchemeName, tvMappedTo, tvAmount, tvFolio, tvUCC, tvInvestor,tvFolioType,
            tvTextStatus,tvARN, tvDOB, tvHolding, tvPan, tvEmail, tvAddress, mTvJointName1, mTvJointPAN1, mTvJointKYC1, mTvJointName2, mTvJointPAN2, mTvJointKYC2, mTvBankName, mTvBankAccount, mTvBankAccountType, mTVBankIFSC, mGuarName, mGuarPAN, mGuaDOB, tvMob;


    private String mFolioId = "",  mSchemeId = "";
    private ShimmerFrameLayout mShimmerViewContainer;
    private ScrollView mTopLayout;
    private TextView mTvNothing;
    private LinearLayout mLinerJoint1, mLinerJoint2, mLinerBankDetails, linerGaurdian, folioTypeLayout;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;


    private TextView mTvNominee1Name,mTvNominee2Name,mTvNominee3Name,
            mTvNomionee1Percent,mTvNomionee2Percent,mTvNomionee3Percent,
            mTvNominee1Relation,mTvNominee2Relation,mTvNominee3Relation,
            mTvNominee1Mobile,mTvNominee2Mobile,mTvNominee3Mobile,
            mTvNomionee1Email,mTvNomionee2Email,mTvNomionee3Email,
            mTvNominee1Address,mTvNominee2Address,mTvNominee3Address,
            mTvShowHideDetailsNom1,mTvShowHideDetailsNom2,mTvShowHideDetailsNom3;
    private MaterialCardView mNominee1Card,mNominee2Card,mNominee3Card;
    private LinearLayout mLLNominee1Details,mLLNominee2Details,mLLNominee3Details,
            mLLShowHideDetailsNom1, mLLShowHideDetailsNom2, mLLShowHideDetailsNom3;
    private ImageView mIvExpandCollapseNom1, mIvExpandCollapseNom2, mIvExpandCollapseNom3;

    private String data;


    @Override
    public void onResume() {
        super.onResume();
  /*      if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);
            mBrokerActivity.setMainVisibility(this, null);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
            mMainActivity.setMainVisibility(this, null);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.folio_detail),
                    true, true, false, false, false, false, false);
            fragToolBar.setCallback(this);
        }
    }

    @Override
    public void onToolbarItemClick(View view){
        if (view.getId() == R.id.iv_share) {
            openShareFrag();
        }
    }

    public void openShareFrag()
    {
        Bundle bundle1 = new Bundle();

        try {
            bundle1.putString("response",data);


        if(mMainActivity != null)
            mMainActivity.displayViewOther(100, bundle1);
        else{
            mBrokerActivity.displayViewOther(86,bundle1);
        }
        }catch (Exception e){
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_folio_lookup_details, container, false);
        setUpToolBar();

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mTopLayout = view.findViewById(R.id.top_layout);
        mTvNothing = view.findViewById(R.id.tvNothing);
        mLinerJoint1 = view.findViewById(R.id.linerJoint1);
        mLinerJoint2 = view.findViewById(R.id.linerJoint2);
        mLinerBankDetails = view.findViewById(R.id.linerBankLevel);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llFolioLookupDetails).setBackgroundResource(R.mipmap.card_blank);

        /*---------------------------nominee variables -------------------------------------*/
        mNominee1Card = view.findViewById(R.id.nominee1Card);
        mNominee2Card = view.findViewById(R.id.nominee2Card);
        mNominee3Card = view.findViewById(R.id.nominee3Card);

        mLLNominee1Details = view.findViewById(R.id.llNominee1Details);
        mLLNominee2Details = view.findViewById(R.id.llNominee2Details);
        mLLNominee3Details = view.findViewById(R.id.llNominee3Details);

        mTvNominee1Name = view.findViewById(R.id.tvNominee1Name);
        mTvNominee2Name = view.findViewById(R.id.tvNominee2Name);
        mTvNominee3Name = view.findViewById(R.id.tvNominee3Name);

        mTvNomionee1Percent = view.findViewById(R.id.tvNominee1Percent);
        mTvNomionee2Percent = view.findViewById(R.id.tvNominee2Percent);
        mTvNomionee3Percent = view.findViewById(R.id.tvNominee3Percent);

        mTvNominee1Relation = view.findViewById(R.id.tvNominee1Relation);
        mTvNominee2Relation = view.findViewById(R.id.tvNominee2Relation);
        mTvNominee3Relation = view.findViewById(R.id.tvNominee3Relation);

        mTvNominee1Mobile = view.findViewById(R.id.tvNominee1Mobile);
        mTvNominee2Mobile = view.findViewById(R.id.tvNominee2Mobile);
        mTvNominee3Mobile = view.findViewById(R.id.tvNominee3Mobile);

        mTvNomionee1Email = view.findViewById(R.id.tvNominee1Email);
        mTvNomionee2Email = view.findViewById(R.id.tvNominee2Email);
        mTvNomionee3Email = view.findViewById(R.id.tvNominee3Email);

        mTvNominee1Address = view.findViewById(R.id.tvNominee1Address);
        mTvNominee2Address = view.findViewById(R.id.tvNominee2Address);
        mTvNominee3Address = view.findViewById(R.id.tvNominee3Address);


        mLLShowHideDetailsNom1 = view.findViewById(R.id.llShowHideDetailsNom1);
        mLLShowHideDetailsNom2 = view.findViewById(R.id.llShowHideDetailsNom2);
        mLLShowHideDetailsNom3 = view.findViewById(R.id.llShowHideDetailsNom3);
        UtilityKotlin.setAccessibilityRole(mLLShowHideDetailsNom1,"button");
        UtilityKotlin.setAccessibilityRole(mLLShowHideDetailsNom2,"button");
        UtilityKotlin.setAccessibilityRole(mLLShowHideDetailsNom3,"button");

        mTvShowHideDetailsNom1 = view.findViewById(R.id.tvShowHideDetailsNom1);
        mTvShowHideDetailsNom2 = view.findViewById(R.id.tvShowHideDetailsNom2);
        mTvShowHideDetailsNom3 = view.findViewById(R.id.tvShowHideDetailsNom3);

        mIvExpandCollapseNom1 = view.findViewById(R.id.ivExpandCollapseNom1);
        mIvExpandCollapseNom2 = view.findViewById(R.id.ivExpandCollapseNom2);
        mIvExpandCollapseNom3 = view.findViewById(R.id.ivExpandCollapseNom3);


        mLLShowHideDetailsNom1.setOnClickListener(v -> {
            if (mTvShowHideDetailsNom1.getText() == getString(R.string.show_details)) {
                mLLNominee1Details.setVisibility(View.VISIBLE);
                mTvShowHideDetailsNom1.setText(getString(R.string.txt_hide_details));
                mLLShowHideDetailsNom1.announceForAccessibility("Nominee details expanded");
                mIvExpandCollapseNom1.setImageResource(R.mipmap.home3_up_arrow);
            } else {
                mLLNominee1Details.setVisibility(View.GONE);
                mTvShowHideDetailsNom1.setText(getString(R.string.txt_show_details));
                mIvExpandCollapseNom1.setImageResource(R.mipmap.home3_down_arrow);
                mLLShowHideDetailsNom1.announceForAccessibility("Nominee details Collapsed");
            }
        });
        mLLShowHideDetailsNom2.setOnClickListener(v -> {
            if (mTvShowHideDetailsNom2.getText() == getString(R.string.show_details)) {
                mLLNominee2Details.setVisibility(View.VISIBLE);
                mTvShowHideDetailsNom2.setText(getString(R.string.txt_hide_details));
                mIvExpandCollapseNom2.setImageResource(R.mipmap.home3_up_arrow);
                mLLShowHideDetailsNom2.announceForAccessibility("Nominee details expanded");
            } else {
                mLLNominee2Details.setVisibility(View.GONE);
                mTvShowHideDetailsNom2.setText(getString(R.string.txt_show_details));
                mIvExpandCollapseNom2.setImageResource(R.mipmap.home3_down_arrow);
                mLLShowHideDetailsNom2.announceForAccessibility("Nominee details Collapsed");

            }
        });
        mLLShowHideDetailsNom3.setOnClickListener(v -> {
            if (mTvShowHideDetailsNom3.getText() == getString(R.string.show_details)) {
                mLLNominee3Details.setVisibility(View.VISIBLE);
                mTvShowHideDetailsNom3.setText(getString(R.string.txt_hide_details));
                mIvExpandCollapseNom3.setImageResource(R.mipmap.home3_up_arrow);
                mLLShowHideDetailsNom3.announceForAccessibility("Nominee details expanded");
            } else {
                mLLNominee3Details.setVisibility(View.GONE);
                mTvShowHideDetailsNom3.setText(getString(R.string.txt_show_details));
                mIvExpandCollapseNom3.setImageResource(R.mipmap.home3_down_arrow);
                mLLShowHideDetailsNom3.announceForAccessibility("Nominee details Collapsed");
            }
        });

        /*---------------------------nominee variables -------------------------------------*/



        mGuarName = view.findViewById(R.id.tvGuarName);
        mGuarPAN = view.findViewById(R.id.tvNGuarPAN);
        mGuaDOB = view.findViewById(R.id.tvGuarDOB);
        linerGaurdian = view.findViewById(R.id.linerGaurdian);
        tvMob = view.findViewById(R.id.tvMob);


        mTvBankName = view.findViewById(R.id.tvBankName);
        mTvBankAccount = view.findViewById(R.id.tvAccountNo);
        mTvBankAccountType = view.findViewById(R.id.tvAccountType);
        mTVBankIFSC = view.findViewById(R.id.tvIFSC);

        mTvJointName1 = view.findViewById(R.id.tvJointName1);
        mTvJointPAN1 = view.findViewById(R.id.tvJointPan1);
        mTvJointKYC1 = view.findViewById(R.id.tvJointKyc1);

        mTvJointName2 = view.findViewById(R.id.tvJointName2);
        mTvJointPAN2 = view.findViewById(R.id.tvJointPan2);
        mTvJointKYC2 = view.findViewById(R.id.tvJointKyc2);

        tvSchemeName = view.findViewById(R.id.tvSchemeName);
        tvMappedTo = view.findViewById(R.id.tvMappedTo);
        tvARN = view.findViewById(R.id.tvARN);
        tvDOB = view.findViewById(R.id.tvDOB);
        tvAmount = view.findViewById(R.id.tvAmount);
        tvFolio = view.findViewById(R.id.tvFolio);
        tvUCC = view.findViewById(R.id.tvUCC);
        tvInvestor = view.findViewById(R.id.tvInvestor);
        tvTextStatus = view.findViewById(R.id.tvTextStatus);
        tvHolding = view.findViewById(R.id.tvHolding);
        tvPan = view.findViewById(R.id.tvPan);
        tvEmail = view.findViewById(R.id.tvEmail);
        tvAddress = view.findViewById(R.id.tvAddress);

        tvFolioType = view.findViewById(R.id.tvFolioType);
        folioTypeLayout = view.findViewById(R.id.folio_type_layout);


        view.findViewById(R.id.ivCopyFolio).setOnClickListener(this::onClick);


        TextView tvNseBse = view.findViewById(R.id.tvNseBse);

        if (mSession.getExchangeNseBseMfu().equals("1")) {
            tvNseBse.setText(getString(R.string.inn));
        } else if (mSession.getExchangeNseBseMfu().equals("2") || mSession.getExchangeNseBseMfu().equals("4")) {
            tvNseBse.setText(getString(R.string.ucc));
        } else if (mSession.getExchangeNseBseMfu().equals("3")) {
            tvNseBse.setText(getString(R.string.can));
        }


        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("folioid")) {
            mFolioId = bundle.getString("folioid");
            mSchemeId = bundle.getString("schid");
        }

        getFolioDetails();
        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivCopyFolio) {
            UtilityKotlin.copyTextWithAccessibility(
                    requireActivity(),
                    tvFolio.getText().toString(),
                    "Folio Number"
            );
}

    }

    private void setData(String data) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        try {
            JSONObject jsonO = new JSONObject(data);
            JSONObject jsonObject = jsonO.optJSONObject("result");
            tvSchemeName.setText(jsonObject.optString("schemeName"));

            tvFolio.setText(jsonObject.optString("folioNo"));
            tvInvestor.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
            tvMappedTo.setText(Utils.setFirstLetterCapital(jsonObject.optString("clientName")));


            String dematAccount = jsonObject.optString("dematAccount");
            if ( dematAccount.equals("N")){
                tvFolioType.setText("Physical");
            }
            if ( dematAccount.equals("Y")){
                tvFolioType.setText("Demat");
            }
            if (dematAccount.equals("") || dematAccount.equalsIgnoreCase("null")){
                folioTypeLayout.setVisibility(View.GONE);
            }




            String taxStatus = jsonObject.optString("taxStatus");
            if (taxStatus.equals("") || taxStatus.equalsIgnoreCase("null")){
                tvTextStatus.setText(getString(R.string.not_available));
            }else {
                tvTextStatus.setText(taxStatus);
            }

            String pan = jsonObject.optString("pan");
            if (pan.equals("") || pan.equalsIgnoreCase("null")){
                tvPan.setText(getString(R.string.not_available));
            }else {
                tvPan.setText(pan);
            }




            //float longValue = jsonObject.optLong("balanceUnits");
            Double longValue = jsonObject.optDouble("balanceUnits");
            if (longValue>0) {
                String data1 = String.format("%.4f", longValue);
                tvAmount.setText(data1);
            }else{
                tvAmount.setText("0");
            }


            String email = jsonObject.optString("email");
            if (email.equals("") || email.equalsIgnoreCase("null")){
                tvEmail.setText(getString(R.string.not_available));
            }else{
                tvEmail.setText(email);
            }

            String holding = jsonObject.optString("holding");
            if (holding.equals("") || holding.equalsIgnoreCase("null")){
                tvHolding.setText(getString(R.string.not_available));
            }else{
                tvHolding.setText(Utils.SchemeNameFormat(jsonObject.optString("holding")));
            }


            String uccIinMfu = "";
            if (mSession.getExchangeNseBseMfu().equals("1")) {
                if (jsonObject.has("iinNumber")){
                    uccIinMfu = jsonObject.optString("iinNumber");
                }else{
                    uccIinMfu = jsonObject.optString("iinNo");
                }
            } else if (mSession.getExchangeNseBseMfu().equals("2")) {
                uccIinMfu = jsonObject.optString("uccNumber");
            } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                uccIinMfu = jsonObject.optString("canNumber");
            }else if (mSession.getExchangeNseBseMfu().equals("4")) {
                uccIinMfu = jsonObject.optString("nseUccCode");
            }
            if (uccIinMfu.equalsIgnoreCase("") || uccIinMfu.equalsIgnoreCase("null")) {
                tvUCC.setText(getString(R.string.not_available));
            } else {
                tvUCC.setText(uccIinMfu);
            }

          /*  String ucc = jsonObject.optString("uccNumber");
            if (ucc.equalsIgnoreCase("") || ucc.equalsIgnoreCase("null")) {
                tvUCC.setText(getString(R.string.not_available));
            } else {
                tvUCC.setText(ucc);
            }*/

            String arnNo = jsonObject.optString("arnNo");
            if (arnNo.equalsIgnoreCase("") || arnNo.equalsIgnoreCase("null")) {
                tvARN.setText(getString(R.string.not_available));
            } else {
                tvARN.setText(arnNo);
            }

            String dob = jsonObject.optString("dob");
            if (dob.equalsIgnoreCase("") || dob.equalsIgnoreCase("null")) {
                tvDOB.setText(getString(R.string.not_available));
            } else {
                tvDOB.setText(UtilityKotlin.dateFormat2(dob));
            }

            String mobileNo = jsonObject.optString("mobileNo");
            if (mobileNo.equalsIgnoreCase("") || mobileNo.equalsIgnoreCase("null")) {
                tvMob.setText(getString(R.string.not_available));
            } else {
                tvMob.setText(mobileNo);
            }

            String guardName = jsonObject.optString("guardName");
            if (guardName.equalsIgnoreCase("") || guardName.equalsIgnoreCase("null")) {
                linerGaurdian.setVisibility(View.GONE);
            } else {
                linerGaurdian.setVisibility(View.VISIBLE);
                mGuarName.setText(guardName);

                String guardPan = jsonObject.optString("guardPan");
                if (guardPan.equalsIgnoreCase("") || guardPan.equalsIgnoreCase("null")) {
                    mGuarPAN.setText(getString(R.string.not_available));
                } else {
                    mGuarPAN.setText(guardPan);
                }

                String guardDob = jsonObject.optString("guardDob");
                if (guardDob.equalsIgnoreCase("") || guardDob.equalsIgnoreCase("null")) {
                    mGuaDOB.setText(getString(R.string.not_available));
                } else {
                    mGuaDOB.setText(Utils.formatedDate(guardDob));
                }
            }


            String fullAddress = "";
            String address = Utils.setFirstLetterCapital(jsonObject.optString("address1"));
            String address2 = Utils.setFirstLetterCapital(jsonObject.optString("address2"));
            String address3 = Utils.setFirstLetterCapital(jsonObject.optString("address3"));
            String city = Utils.setFirstLetterCapital(jsonObject.optString("city"));
            String state = Utils.setFirstLetterCapital(jsonObject.optString("state"));
            String pin = Utils.setFirstLetterCapital(jsonObject.optString("pin"));


            if (!address.equalsIgnoreCase("null") && !address.equalsIgnoreCase("")) {
                fullAddress = address + ", ";
            }

            if (!address2.equalsIgnoreCase("null") && !address2.equalsIgnoreCase("")) {
                if (fullAddress.equalsIgnoreCase("")) {
                    fullAddress = address2;
                } else {
                    fullAddress = fullAddress + ", " + address2;
                }
            }

            if (!address3.equalsIgnoreCase("null") && !address3.equalsIgnoreCase("")) {
                if (fullAddress.equalsIgnoreCase("")) {
                    fullAddress = address3;
                } else {
                    fullAddress = fullAddress + ", " + address3;
                }

            }

            if (!city.equalsIgnoreCase("null") && !city.equalsIgnoreCase("")) {
                if (fullAddress.equalsIgnoreCase("")) {
                    fullAddress = city;
                } else {
                    fullAddress = fullAddress + ", " + city;
                }
            }

            if (!state.equalsIgnoreCase("null") && !state.equalsIgnoreCase("")) {
                if (fullAddress.equalsIgnoreCase("")) {
                    fullAddress = state;
                } else {
                    fullAddress = fullAddress + ", " + state;
                }
            }

            if (!pin.equalsIgnoreCase("null") && !pin.equalsIgnoreCase("")) {
                if (fullAddress.equalsIgnoreCase("")) {
                    fullAddress = pin;
                } else {
                    fullAddress = fullAddress + ", " + pin;
                }
            }

            if (!fullAddress.equals("")){
                tvAddress.setText(fullAddress);
            }else{
                tvAddress.setText(getString(R.string.not_available));
            }

            if (jsonObject.optString("bankName").equalsIgnoreCase("") || jsonObject.optString("bankName").equalsIgnoreCase("null")){
                mLinerBankDetails.setVisibility(View.GONE);
            }else{
                mTvBankName.setText(jsonObject.optString("bankName"));
                mTvBankAccount.setText(jsonObject.optString("accountNo"));
                mTVBankIFSC.setText(jsonObject.optString("ifsc"));

                String accountType = jsonObject.optString("accountType");
                if (accountType.equalsIgnoreCase("") || accountType.equalsIgnoreCase("null")) {
                    mTvBankAccountType.setText(getString(R.string.not_available));
                } else {
                    mTvBankAccountType.setText(accountType);
                }
            }

            if (jsonObject.optString("jt1Name").equalsIgnoreCase("") || jsonObject.optString("jt1Name").equalsIgnoreCase("null")){
                mLinerJoint1.setVisibility(View.GONE);
                mLinerJoint2.setVisibility(View.GONE);
            } else{
                mLinerJoint1.setVisibility(View.VISIBLE);
                mTvJointName1.setText(Utils.setFirstLetterCapital(jsonObject.optString("jt1Name")));
                mTvJointPAN1.setText(jsonObject.optString("jt1Pan"));

                String jt1Kyc = jsonObject.optString("jt1Kyc");
                if (jt1Kyc.equalsIgnoreCase("") || jt1Kyc.equalsIgnoreCase("null")) {
                    mTvJointKYC1.setText(getString(R.string.not_available));
                } else {
                    mTvJointKYC1.setText(jt1Kyc);
                }


                if (jsonObject.optString("jt2Name").equalsIgnoreCase("") || jsonObject.optString("jt2Name").equalsIgnoreCase("null")){
                    mLinerJoint2.setVisibility(View.GONE);
                }else{
                    mLinerJoint2.setVisibility(View.VISIBLE);
                    mTvJointName2.setText(Utils.setFirstLetterCapital(jsonObject.optString("jt2Name")));
                    mTvJointPAN2.setText(jsonObject.optString("jt2Pan"));

                    String jt2Kyc = jsonObject.optString("jt2Kyc");
                    if (jt2Kyc.equalsIgnoreCase("") || jt2Kyc.equalsIgnoreCase("null")) {
                        mTvJointKYC2.setText(getString(R.string.not_available));
                    } else {
                        mTvJointKYC2.setText(jt2Kyc);
                    }
                }
            }


            /**  --------------------------- all nominee details -------------------------**/

            JSONObject nomineeObject = jsonObject.optJSONObject("nomineeDetails");
            if(nomineeObject != null && nomineeObject.length() != 0) {

                //nominee 1
                JSONObject nomineeDetails1 = nomineeObject.optJSONObject("nomineeDetails1");
                if (nomineeDetails1 != null && nomineeDetails1.length() != 0) {
                    mNominee1Card.setVisibility(View.VISIBLE);

                    mTvNominee1Name.setText(Utils.nullStringHandle(getActivity(), nomineeDetails1.optString("nomName")));
                    mTvNomionee1Percent.setText(Utils.nullStringHandle(getActivity(), nomineeDetails1.optString("nomPer")));
                    mTvNominee1Relation.setText(Utils.nullStringHandle(getActivity(), nomineeDetails1.optString("nomRelation")));

                    //other details
                    mTvNominee1Mobile.setText(Utils.nullStringHandle(getActivity(), nomineeDetails1.optString("nomPhoneResidence")));
                    if (nomineeDetails1.optString("nomEmail") == null || nomineeDetails1.optString("nomEmail").isEmpty() || nomineeDetails1.optString("nomEmail").equalsIgnoreCase("null"))
                        mTvNomionee1Email.setText(getString(R.string.not_available));
                    else
                        mTvNomionee1Email.setText(nomineeDetails1.optString("nomEmail"));
                    String nom1FullAddress = getFullAddressOfNominee(nomineeDetails1);
                    mTvNominee1Address.setText(nom1FullAddress);
                } else {
                    mNominee1Card.setVisibility(View.GONE);
                }

                //nominee 2
                JSONObject nomineeDetails2 = nomineeObject.optJSONObject("nomineeDetails2");
                if (nomineeDetails2 != null && nomineeDetails2.length() != 0) {
                    mNominee2Card.setVisibility(View.VISIBLE);

                    mTvNominee2Name.setText(Utils.nullStringHandle(getActivity(), nomineeDetails2.optString("nomName")));
                    mTvNomionee2Percent.setText(Utils.nullStringHandle(getActivity(), nomineeDetails2.optString("nomPer")));
                    mTvNominee2Relation.setText(Utils.nullStringHandle(getActivity(), nomineeDetails2.optString("nomRelation")));

                    //other details
                    mTvNominee2Mobile.setText(Utils.nullStringHandle(getActivity(), nomineeDetails2.optString("nomPhoneResidence")));
                    if (nomineeDetails2.optString("nomEmail") == null || nomineeDetails2.optString("nomEmail").isEmpty() || nomineeDetails2.optString("nomEmail").equalsIgnoreCase("null"))
                        mTvNomionee2Email.setText(getString(R.string.not_available));
                    else
                        mTvNomionee2Email.setText(nomineeDetails2.optString("nomEmail"));
                    String nom2FullAddress = getFullAddressOfNominee(nomineeDetails2);
                    mTvNominee2Address.setText(nom2FullAddress);
                } else {
                    mNominee2Card.setVisibility(View.GONE);
                }

                //nominee 3
                JSONObject nomineeDetails3 = nomineeObject.optJSONObject("nomineeDetails3");
                if (nomineeDetails3 != null && nomineeDetails3.length() != 0) {
                    mNominee3Card.setVisibility(View.VISIBLE);

                    mTvNominee3Name.setText(Utils.nullStringHandle(getActivity(), nomineeDetails3.optString("nomName")));
                    mTvNomionee3Percent.setText(Utils.nullStringHandle(getActivity(), nomineeDetails3.optString("nomPer")));
                    mTvNominee3Relation.setText(Utils.nullStringHandle(getActivity(), nomineeDetails3.optString("nomRelation")));

                    //other details
                    mTvNominee3Mobile.setText(Utils.nullStringHandle(getActivity(), nomineeDetails3.optString("nomPhoneResidence")));
                    if (nomineeDetails3.optString("nomEmail") == null || nomineeDetails3.optString("nomEmail").isEmpty() || nomineeDetails3.optString("nomEmail").equalsIgnoreCase("null"))
                        mTvNomionee3Email.setText(getString(R.string.not_available));
                    else
                        mTvNomionee3Email.setText(nomineeDetails3.optString("nomEmail"));
                    String nom3FullAddress = getFullAddressOfNominee(nomineeDetails3);
                    mTvNominee3Address.setText(nom3FullAddress);
                } else {
                    mNominee3Card.setVisibility(View.GONE);
                }
            }
            else {
                mNominee1Card.setVisibility(View.GONE);
                mNominee2Card.setVisibility(View.GONE);
                mNominee3Card.setVisibility(View.GONE);
                                        }

        } catch (Exception e) {

        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mTopLayout.setVisibility(View.VISIBLE);
        }


    }
    private String getFullAddressOfNominee(JSONObject nomObject ){
        String nomFullAddress = "";
        String nomAddress1 = Utils.setFirstLetterCapital(nomObject.optString("nom"+"Address1"));
        String nomAddress2 = Utils.setFirstLetterCapital(nomObject.optString("nom"+"Address2"));
        String nomAddress3 = Utils.setFirstLetterCapital(nomObject.optString("nom"+"Address3"));
        String nomCity = Utils.setFirstLetterCapital(nomObject.optString("nom" + "City"));
        String nomState = Utils.setFirstLetterCapital(nomObject.optString("nom" + "State"));
        String nomPin = Utils.setFirstLetterCapital(nomObject.optString("nom"  + "PinCode"));


        if (!nomAddress1.equalsIgnoreCase("null") && !nomAddress1.equalsIgnoreCase("")) {
            nomFullAddress = nomAddress1;
        }

        if (!nomAddress2.equalsIgnoreCase("null") && !nomAddress2.equalsIgnoreCase("")) {
            if (nomFullAddress.equalsIgnoreCase("")) {
                nomFullAddress = nomAddress2;
            } else {
                nomFullAddress = nomFullAddress + ", " + nomAddress2;
            }
        }

        if (!nomAddress3.equalsIgnoreCase("null") && !nomAddress3.equalsIgnoreCase("")) {
            if (nomFullAddress.equalsIgnoreCase("")) {
                nomFullAddress = nomAddress3;
            } else {
                nomFullAddress = nomFullAddress + ", " + nomAddress3;
            }

        }

        if (!nomCity.equalsIgnoreCase("null") && !nomCity.equalsIgnoreCase("")) {
            if (nomFullAddress.equalsIgnoreCase("")) {
                nomFullAddress = nomCity;
            } else {
                nomFullAddress = nomFullAddress + ", " + nomCity;
            }
        }

        if (!nomState.equalsIgnoreCase("null") && !nomState.equalsIgnoreCase("")) {
            if (nomFullAddress.equalsIgnoreCase("")) {
                nomFullAddress = nomState;
            } else {
                nomFullAddress = nomFullAddress + ", " + nomState;
            }
        }

        if (!nomPin.equalsIgnoreCase("null") && !nomPin.equalsIgnoreCase("")) {
            if (nomFullAddress.equalsIgnoreCase("")) {
                nomFullAddress = nomPin;
            } else {
                nomFullAddress = nomFullAddress + ", " + nomPin;
            }
        }

        if (!nomFullAddress.isEmpty()){
            return nomFullAddress;
        }else{
            return getString(R.string.not_available);
        }

    }


    private void getFolioDetails() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mShimmerViewContainer.stopShimmer();
        String url = "";
        try {
            JSONObject jsonObject3 = new JSONObject();
            jsonObject3.put("componentName", "folioLookUp");
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_FOLIO_DETAILS_BROKER + "folioId=" + mFolioId ;
            }else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_FOLIO_DETAILS_Client + "folioid=" + mFolioId +"&selectedUser="+Utils.getSelectedUserObject(mSession);

            }

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        data = response;
                        setData(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mTopLayout.setVisibility(View.GONE);
                        mTvNothing.setVisibility(View.VISIBLE);

                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        if (mBrokerActivity != null)
            requestQueue = Volley.newRequestQueue(mBrokerActivity);
        else
            requestQueue = Volley.newRequestQueue(mMainActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

}