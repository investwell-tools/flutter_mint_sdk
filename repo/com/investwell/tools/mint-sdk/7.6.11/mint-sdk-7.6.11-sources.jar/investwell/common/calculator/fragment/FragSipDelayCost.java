package investwell.common.calculator.fragment;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.calculator.utils.AudioPlayer;
import investwell.common.calculator.utils.RoundKnobButton;
import investwell.common.calculator.utils.Singleton;
import investwell.common.calculator.utils.Utils;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;


public class FragSipDelayCost extends BaseFragment implements View.OnClickListener, View.OnTouchListener,
        RoundKnobButton.RoundKnobButtonListener, ToolbarFragment.ToolbarCallback {

    private final long DELAY = 1000; // milliseconds
    Singleton m_Inst = Singleton.getInstance();
    double nSIP = 0, nYears = 0;
    double r, nRate = 0, delaycharge = 0;
    double i, nMonths, z;
    double w_delay = 0;
    double w_tot = 0, w_tot_with_delay = 0;

    double mMaturityDelay = 0, mMuturityFromToday = 0, mInvestAmountFromToday = 0, mInvestAmountWithDelay = 0;
    private EditText mEtYear, mEtAmount, mEtRate, mEtDelay;
    private TextView mTvSipTitle, mTvSipTitle2, mTvSipValue, mTvFutureAmount, mTvResult1, mTvResult2, mTvResult3, mTvResult4, mTvImageTitle;
    private LinearLayout mLinerResult;
    private int mAmountCount = 0, mAnnualAmountCount = 0, mYearCount = 0, mReturn = 01;
    private ProgressBar mProgressBar, mProgressBar2;
    private AudioPlayer audioPlayer;
    private ScrollView mScrollView;
    private RoundKnobButton mDailerInvest1, mDailerInvest2, mDailerInvest3, mDailerInvest4;
    private ConstraintLayout mClCalcFooter;
    private Timer timer = new Timer();
    private ClientActivity mActivity;
    private AppApplication mApplication;
    private RelativeLayout mRelToolbar;
    private ToolbarFragment toolbarFragment;
    private AppTextViewTitle tvHeaderTitle;
    private LinearLayout ll_calculator_header;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private TextView mTvAppName,mTvWebsite,mTvEmail,mTvAddress,mTvPhone, mTvSlogan;
    private ImageView mIvAppLogo;

    private  TextView mTvMonthlyInvestmentError, mTvInvestmentPeriodError, mTvAnnualReturnError, mTvDelayFromTodayError;
    @Override
    public void onResume() {
        super.onResume();
   /*     if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mActivity.getApplication();
            mSession = AppSession.getInstance(mActivity);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_cal_delay_cost, container, false);
        if (mBrokerActivity != null) {
            m_Inst.InitGUIFrame(mBrokerActivity);

        } else {
            m_Inst.InitGUIFrame(mActivity);

        }
        audioPlayer = new AudioPlayer();

        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        ll_calculator_header = view.findViewById(R.id.ll_calculator_header);
        setUpToolBar();
        mIvAppLogo=view.findViewById(R.id.iv_app_logo);
        mRelToolbar = view.findViewById(R.id.relToolBar);
        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        mEtAmount = view.findViewById(R.id.edit1);
        mEtYear = view.findViewById(R.id.edit2);
        mEtRate = view.findViewById(R.id.edit3);
        mEtDelay = view.findViewById(R.id.edit4);

        mScrollView = view.findViewById(R.id.scrollView);
        mTvImageTitle = view.findViewById(R.id.tvImageTitle);
        mClCalcFooter = view.findViewById(R.id.cl_calc_footer);
        mClCalcFooter.setVisibility(View.GONE);
        mTvSlogan = view.findViewById(R.id.tvSlogan);


        mTvSipTitle = view.findViewById(R.id.textView1);
        mTvSipTitle2 = view.findViewById(R.id.textView11);
        mTvFutureAmount = view.findViewById(R.id.textView2);
        mTvSipValue = view.findViewById(R.id.textView22);
        mTvResult1 = view.findViewById(R.id.tvResult1);
        mTvResult2 = view.findViewById(R.id.tvResult2);
        mTvResult3 = view.findViewById(R.id.tvResult3);
        mTvResult4 = view.findViewById(R.id.tvResult4);

        mTvMonthlyInvestmentError = view.findViewById(R.id.tvMonthlyInvestmentError);
        mTvInvestmentPeriodError = view.findViewById(R.id.tvInvestmentPeriodError);
        mTvAnnualReturnError = view.findViewById(R.id.tvAnnualReturnError);
        mTvDelayFromTodayError = view.findViewById(R.id.tvDelayFromTodayError);


        mLinerResult = view.findViewById(R.id.linerResult);

        mProgressBar = view.findViewById(R.id.progress_bar1);
        mProgressBar2 = view.findViewById(R.id.progress_bar2);

        mTvAddress=view.findViewById(R.id.tvAddress);
        mTvAppName=view.findViewById(R.id.tvApp_name);
        mTvPhone=view.findViewById(R.id.call);
        mTvWebsite=view.findViewById(R.id.web);
        mTvEmail=view.findViewById(R.id.email);
        setupFooter();
      /*  TextViewtoolbar_title_left = view.findViewById(R.id.toolbar_title_left);
        toolbar_title_left.setText("SIP Delay Calculator");*/


        mDailerInvest1 = view.findViewById(R.id.dialer1);
        mDailerInvest2 = view.findViewById(R.id.dialer2);
        mDailerInvest3 = view.findViewById(R.id.dialer3);
        mDailerInvest4 = view.findViewById(R.id.dialer4);
        if (mBrokerActivity != null) {
            mDailerInvest1.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        } else {
            mDailerInvest1.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        }

        mDailerInvest1.setOnTouchListener(this);
        mDailerInvest2.setOnTouchListener(this);
        mDailerInvest3.setOnTouchListener(this);
        mDailerInvest4.setOnTouchListener(this);

        mDailerInvest1.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
            }

            public void onRotate(final int percentage) {
                System.out.println("" + percentage);
                mEtAmount.post(new Runnable() {
                    public void run() {
                        long currentValue = Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""));
                        long updateValue = 0;
                        if (mAmountCount != percentage) {
                            if (percentage > mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue + 500);
                                } else {
                                    updateValue = (currentValue + 1000);
                                }
                            } else if (percentage < mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue - 500);
                                } else {
                                    updateValue = (currentValue - 1000);
                                }
                            }

                            mAmountCount = percentage;
                            if (updateValue < 500) {
                                mEtAmount.setText("" + 500);
                            } else {
                                mEtAmount.setText("" + updateValue);
                            }
                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                                calculateAmount();
                            } else {
                                audioPlayer.play(mActivity);
                                calculateAmount();
                            }

                        }


                    }
                });
            }
        });

        mDailerInvest2.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtYear.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtYear.getText().toString());
                        int updateValue = 0;
                        if (mYearCount != percentage) {
                            if (percentage > mYearCount) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mYearCount) {
                                updateValue = (currentValue - 1);
                            }

                            mYearCount = percentage;
                            if (updateValue < 1)
                                mEtYear.setText("" + 1);
                            else if (updateValue > 99)
                                mEtYear.setText("" + 99);
                            else
                                mEtYear.setText("" + updateValue);

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                                calculateAmount();
                            } else {
                                audioPlayer.play(mActivity);
                                calculateAmount();
                            }
                        }

                    }
                });
            }
        });


        mDailerInvest3.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtRate.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtRate.getText().toString());
                        double updateValue = 0;
                        if (mReturn != percentage) {
                            if (percentage > mReturn) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mReturn) {
                                updateValue = (currentValue - 1);
                            }

                            mReturn = percentage;
                            if (updateValue < 1)
                                mEtRate.setText("" + 1.00);
                            else if (updateValue > 100.00)
                                mEtRate.setText("" + 100.00);
                            else
                                mEtRate.setText("" + updateValue);

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                                calculateAmount();
                            } else {
                                audioPlayer.play(mActivity);
                                calculateAmount();
                            }
                        }
                    }
                });
            }
        });

        mDailerInvest4.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtDelay.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtDelay.getText().toString());
                        int updateValue = 0;
                        if (mAnnualAmountCount != percentage) {
                            if (percentage > mAnnualAmountCount) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mAnnualAmountCount) {
                                updateValue = (currentValue - 1);
                            }

                            mAnnualAmountCount = percentage;
                            if (updateValue < 1) {
                                mEtDelay.setText("" + 1);
                            } else if (updateValue > 120) {
                                mEtDelay.setText("" + 120);
                            } else {
                                mEtDelay.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                                calculateAmount();
                            } else {
                                audioPlayer.play(mActivity);
                                calculateAmount();
                            }
                        }


                    }
                });
            }
        });

        mEtAmount.addTextChangedListener(new GenericTextWatcher(mEtAmount));
        mEtRate.addTextChangedListener(new GenericTextWatcher(mEtRate));
        mEtYear.addTextChangedListener(new GenericTextWatcher(mEtYear));
        mEtDelay.addTextChangedListener(new GenericTextWatcher(mEtDelay));
        calculateAmount();

        return view;
    }
    private void setupFooter() {
        setTintColorIfDark(requireActivity(), mIvAppLogo);
        mIvAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (requireActivity().getResources().getString(R.string.subdomain).equals("mint")) {
            if (mSession.getHasLoging()) {
                if(!TextUtils.isEmpty(  mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")){
                    Picasso.get().load( mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                    mIvAppLogo.setVisibility(View.VISIBLE);
                }else{
                    mIvAppLogo.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")){
                    mTvAddress.setText(mSession.getAddress());
                    mTvAddress.setVisibility(View.VISIBLE);
                }else{
                    mTvAddress.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")){
                    mTvWebsite.setText(mSession.getWebsite());
                    mTvWebsite.setVisibility(View.VISIBLE);
                }else{
                    mTvWebsite.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")){
                    mTvPhone.setText(requireActivity().getResources().getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                    mTvPhone.setVisibility(View.VISIBLE);
                }else{
                    mTvPhone.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")){
                    mTvEmail.setText(mSession.getUserEmail());
                    mTvEmail.setVisibility(View.VISIBLE);
                }else{
                    mTvEmail.setVisibility(View.GONE);
                } if(!TextUtils.isEmpty(  mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")){
                    mTvAppName.setText(mSession.getCompanyName());
                    mTvAppName.setVisibility(View.VISIBLE);
                }else{
                    mTvAppName.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                    mTvSlogan.setText(mSession.getSloganOnLogo());
                    mTvSlogan.setVisibility(View.VISIBLE);
                }else{
                    mTvSlogan.setVisibility(View.GONE);
                }
            } else {
                if(!TextUtils.isEmpty(  mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")){
                    Picasso.get().load( mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                }
                mTvAddress.setText(requireActivity().getResources().getString(R.string.locatetext));
                mTvWebsite.setText(requireActivity().getResources().getString(R.string.website));
                mTvPhone.setText(requireActivity().getResources().getString(R.string.image_phone));
                mTvEmail.setText(requireActivity().getResources().getString(R.string.support_email_address));
                mTvAppName.setText(requireActivity().getResources().getString(R.string.app_name));
                mTvSlogan.setText(mSession.getSloganOnLogo());

            }
        } else {
            mIvAppLogo.setVisibility(View.VISIBLE);
            int squareLogo =   UtilityKotlin.checkExistResources("app_logo_square","mipmap",requireContext());
            int circleLogo =   UtilityKotlin.checkExistResources("app_logo_round","mipmap",requireContext());
            if (squareLogo !=0) {
                mIvAppLogo.setImageResource(squareLogo);
            }else if (circleLogo !=0) {
                mIvAppLogo.setImageResource(circleLogo);
            }else{
                mIvAppLogo.setImageResource(R.mipmap.app_logo);
            }

            if(!TextUtils.isEmpty(  mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")){
                mTvAddress.setText(mSession.getAddress());
                mTvAddress.setVisibility(View.VISIBLE);
            }else{
                mTvAddress.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")){
                mTvWebsite.setText(mSession.getWebsite());
                mTvWebsite.setVisibility(View.VISIBLE);
            }else{
                mTvWebsite.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")){
                mTvPhone.setText(requireActivity().getResources().getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                mTvPhone.setVisibility(View.VISIBLE);
            }else{
                mTvPhone.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")){
                mTvEmail.setText(mSession.getUserEmail());
                mTvEmail.setVisibility(View.VISIBLE);
            }else{
                mTvEmail.setVisibility(View.GONE);
            } if(!TextUtils.isEmpty(  mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")){
                mTvAppName.setText(mSession.getCompanyName());
                mTvAppName.setVisibility(View.VISIBLE);
            }else{
                mTvAppName.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                mTvSlogan.setText(mSession.getSloganOnLogo());
                mTvSlogan.setVisibility(View.VISIBLE);
            }else{
                mTvSlogan.setVisibility(View.GONE);
            }

        }
    }

    private void setUpToolBar() {
        toolbarFragment = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (toolbarFragment != null) {
            toolbarFragment.setUpToolBar(requireActivity().getResources().getString(R.string.toolBar_title_delay_sip_cal),
                    true, true, false, false, true, false, false);
            toolbarFragment.setCallback(this);
        }

        tvHeaderTitle.setText(requireActivity().getResources().getString(R.string.toolBar_title_delay_sip_cal));
    }

    @Override
    public void onStateChange(boolean newstate) {

    }

    @Override
    public void onRotate(int percentage) {

    }

    @Override
    public void onClick(View view) {
        /*if (view.getId() == R.id.ivRight) {
            saveFrameLayout();
        }*//* else if (view.getId() == R.id.ivRight2) {
            refreshView();
        } *//*else */

    }


    private void refreshView() {
        mDailerInvest1.setRotorPercentage(0);
        mDailerInvest2.setRotorPercentage(0);
        mDailerInvest3.setRotorPercentage(0);
        mDailerInvest4.setRotorPercentage(0);
        mEtAmount.setText("1000");
        mEtYear.setText("10");
        mEtRate.setText("10.00");
        mEtDelay.setText("5");
        calculateAmount();
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        hideKeyPad();
        String currentValue = "";
        int i1 = view.getId();
        if (i1 == R.id.dialer1) {
            currentValue = mEtAmount.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 500)
                    mEtAmount.setText("" + 500);
            } else {
                mEtAmount.setText("" + 500);
            }
            desableScrollView(motionEvent);

        } else if (i1 == R.id.dialer2) {
            currentValue = mEtYear.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 1)
                    mEtYear.setText("" + 1);
                else if (value > 99)
                    mEtYear.setText("" + 99);

            } else {
                mEtYear.setText("" + 1);
            }

            desableScrollView(motionEvent);

        } else if (i1 == R.id.dialer3) {
            currentValue = mEtRate.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtRate.setText("" + 1.00);
                else if (value > 100)
                    mEtRate.setText("" + 100.00);
            } else {
                mEtRate.setText("" + 1.00);
            }
            desableScrollView(motionEvent);

        } else if (i1 == R.id.dialer4) {
            currentValue = mEtDelay.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 1)
                    mEtDelay.setText("" + 1);
                else if (value > 120)
                    mEtDelay.setText("" + 120);

            } else {
                mEtDelay.setText("" + 1);
            }
            desableScrollView(motionEvent);

        }
        return false;
    }

    private void desableScrollView(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            mScrollView.requestDisallowInterceptTouchEvent(true);

        else if (motionEvent.getAction() == MotionEvent.ACTION_UP)
            mScrollView.requestDisallowInterceptTouchEvent(false);

    }

    public void hideKeyPad() {
        if (mBrokerActivity != null) {
            investwell.utils.Utils.hideKeyboard(mBrokerActivity);
        } else {
            investwell.utils.Utils.hideKeyboard(mActivity);
        }
    }

    private void delayCall() {
        timer.cancel();
        timer = new Timer();
        timer.schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        if (mBrokerActivity != null) {
                            mBrokerActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });

                        } else {
                            if (mActivity != null) {
                                mActivity.runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        calculateAmount();
                                    }
                                });
                            }
                        }
                    }
                },
                DELAY
        );
    }

    @SuppressLint("SetTextI18n")
    private void calculateAmount() {
        mTvMonthlyInvestmentError.setVisibility(View.GONE);
        mTvInvestmentPeriodError.setVisibility(View.GONE);
        mTvAnnualReturnError.setVisibility(View.GONE);
        mTvDelayFromTodayError.setVisibility(View.GONE);

        if (mBrokerActivity != null) {
            if (mEtAmount.getText().toString().replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
//                mBrokerActivity.showCommonDialog(mBrokerActivity, "Not Valid", requireActivity().getResources().getString(R.string.error_empty_amount));
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
            } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 500) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_cal_minn_amnt));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_cal_minn_amnt));
            } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_empty_yr));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.sip_delay_error_empty_yr));
            } else if (Integer.parseInt(mEtYear.getText().toString()) > 99) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_minn_amnt));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.sip_delay_error_minn_amnt));
            } else if (mEtRate.getText().toString().equals("") ||mEtRate.getText().toString().equals(".") || mEtRate.getText().toString().equals("0")) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_ror));
                mTvAnnualReturnError.setText(getResources().getString(R.string.sip_delay_error_ror));
            } else if (Double.parseDouble(mEtRate.getText().toString()) > 100) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_minn_ror));
                mTvAnnualReturnError.setText(getResources().getString(R.string.sip_delay_error_minn_ror));
            } else if (mEtDelay.getText().toString().equals("") || mEtDelay.getText().toString().equals(".")) {
                mTvDelayFromTodayError.setVisibility(View.VISIBLE);
                mTvDelayFromTodayError.announceForAccessibility(getResources().getString(R.string.sip_delay_empty_duration));
                mTvDelayFromTodayError.setText(getResources().getString(R.string.sip_delay_empty_duration));
            } else if ((Integer.parseInt(mEtDelay.getText().toString())) > 120) {
                mTvDelayFromTodayError.setVisibility(View.VISIBLE);
                mTvDelayFromTodayError.announceForAccessibility(getResources().getString(R.string.sip_delay_minn_delay));
                mTvDelayFromTodayError.setText(getResources().getString(R.string.sip_delay_minn_delay));
            } else {

                String rawValue = mEtAmount.getText().toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue, mEtAmount);

                if (getActivity()!=null) {
                    try {
                        nSIP = 0;
                        nYears = 0;
                        mMaturityDelay = 0;
                        mMuturityFromToday = 0;
                        mInvestAmountFromToday = 0;
                        mInvestAmountWithDelay = 0;
                        w_delay = 0;
                        w_tot = 0;
                        w_tot_with_delay = 0;

                        nSIP = Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", ""));
                        nYears = Double.parseDouble(mEtYear.getText().toString());
                        nRate = Double.parseDouble(mEtRate.getText().toString());
                        delaycharge = Double.parseDouble(mEtDelay.getText().toString());

                        r = nRate / 100;
                        double rateOfReturn = nRate / 12;
                        nMonths = 12 * nYears;
                        mInvestAmountFromToday = nMonths * nSIP;
                        mInvestAmountWithDelay = (nMonths - delaycharge) * nSIP;

                        //  SIP Starting after a Delay case ----------------------------------------------------------------------------
                        double cumulationWithDelay = 0;
                        for (int i = 0; i < (nMonths - delaycharge); i++) {
                            cumulationWithDelay += Math.pow((1 + r), (nMonths - delaycharge - i) / 12.0);
                        }
                        w_tot_with_delay = nSIP * cumulationWithDelay;

                        // SIP Starting Today case
                        double cumulationFromToday = 0;
                        for (int i = 0; i < nMonths; i++) {
                            cumulationFromToday += Math.pow((1 + r), (nMonths - i) / 12.0);
                        }
                        w_tot = nSIP * cumulationFromToday;


                        mLinerResult.setVisibility(View.VISIBLE);


                        // mTvSipTitle.setText(mBrokerActivity.requireActivity().getResources().getString(R.string.sip_delay_title_desc));
                        mTvSipTitle.setText(getString(R.string.if_you_start_sip_from_today_then_your_maturity_value_would_be));
                        Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                        long value1 = Math.round(w_tot);
                        String str = format.format(value1);
                        String[] result = str.split("\\.", 0);
                        mTvFutureAmount.setText(result[0]);

                        mTvSipTitle2.setText(requireActivity().getResources().getString(R.string.if_you_start_sip_with_delay_of) + Math.round(delaycharge) + requireActivity().getResources().getString(R.string.txt_months_then_our_maturity_value_would_be));

                        long value2 = Math.round(w_tot_with_delay);
                        String str2 = format.format(value2);
                        String[] result2 = str2.split("\\.", 0);
                        mTvSipValue.setText(result2[0]);


                        long value3 = Math.round(mInvestAmountFromToday);
                        String investAmount = format.format(value3);
                        String[] invesRresult = investAmount.split("\\.", 0);
                        mTvResult1.setText(invesRresult[0]);

                        Double onlyProfit = (w_tot - mInvestAmountFromToday);
                        long value4 = Math.round(onlyProfit);
                        String strProfit = format.format(value4);
                        String[] arrayProfit = strProfit.split("\\.", 0);
                        mTvResult2.setText(arrayProfit[0]);

                        String investAmount2 = format.format(mInvestAmountWithDelay);
                        String[] invesRresult2 = investAmount2.split("\\.", 0);
                        mTvResult3.setText(invesRresult2[0]);

                        Double onlyProfit2 = (w_tot_with_delay - mInvestAmountWithDelay);
                        long value5 = Math.round(onlyProfit2);
                        String strProfit2 = format.format(value5);
                        String[] arrayProfit2 = strProfit2.split("\\.", 0);
                        mTvResult4.setText(arrayProfit2[0]);


                        int percentage = (int) ((mInvestAmountFromToday * 100) / w_tot);
                        mProgressBar.setProgress(percentage);

                        int percentage2 = (int) ((mInvestAmountWithDelay * 100) / w_tot_with_delay);
                        mProgressBar2.setProgress(percentage2);

                        String announcement =
                                mTvSipTitle.getText().toString() + ". " + mTvFutureAmount.getText().toString() + ". "
                                + getString(R.string.delay_cal_amount_investment_txt) + ". " + mTvResult1.getText().toString() + ". "
                                + getString(R.string.sip_calculator_txt_wealth_gained) + ". " + mTvResult2.getText().toString() + ". "
                                + mTvSipTitle2.getText().toString() + ". " + mTvSipValue.getText().toString() + ". "
                                + getString(R.string.delay_cal_amount_investment_txt) + ". " + mTvResult3.getText().toString() + ". "
                                + getString(R.string.sip_calculator_txt_wealth_gained) + ". " + mTvResult4.getText().toString() + ".";

                        mLinerResult.post(() ->
                                mLinerResult.announceForAccessibility(announcement)
                        );


                    } catch (NumberFormatException e) {

                    }
                }


            }
        } else {
            if (mEtAmount.getText().toString().replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
//                mActivity.showCommonDialog(mActivity, "Not Valid",requireActivity().getResources().getString(R.string.error_empty_amount));
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.error_empty_amount));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.error_empty_amount));
            } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 500) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_cal_minn_amnt));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_cal_minn_amnt));
            } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_empty_yr));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_error_empty_yr));
            } else if (Integer.parseInt(mEtYear.getText().toString()) > 99) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_minn_amnt));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_error_minn_amnt));
            } else if (mEtRate.getText().toString().equals("") ||mEtRate.getText().toString().equals(".") || mEtRate.getText().toString().equals("0")) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_ror));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_error_ror));
            } else if (Double.parseDouble(mEtRate.getText().toString()) > 100) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_error_minn_ror));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_error_minn_ror));
            } else if (mEtDelay.getText().toString().equals("") || mEtDelay.getText().toString().equals(".")) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_empty_duration));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_empty_duration));
            } else if ((Integer.parseInt(mEtDelay.getText().toString())) > 120) {
                mTvMonthlyInvestmentError.setVisibility(View.VISIBLE);
                mTvMonthlyInvestmentError.announceForAccessibility(getResources().getString(R.string.sip_delay_minn_delay));
                mTvMonthlyInvestmentError.setText(getResources().getString(R.string.sip_delay_minn_delay));
            } else {

                String rawValue = mEtAmount.getText().toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue, mEtAmount);

                if (getActivity()!=null) {

                try {
                    nSIP = 0;
                    nYears = 0;
                    mMaturityDelay = 0;
                    mMuturityFromToday = 0;
                    mInvestAmountFromToday = 0;
                    mInvestAmountWithDelay = 0;
                    w_delay = 0;
                    w_tot = 0;
                    w_tot_with_delay = 0;

                    nSIP = Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", ""));
                    nYears = Double.parseDouble(mEtYear.getText().toString());
                    nRate = Double.parseDouble(mEtRate.getText().toString());
                    delaycharge = Double.parseDouble(mEtDelay.getText().toString());

                    r = nRate / 100;
                    nMonths = 12 * nYears;
                    double rateOfReturn = nRate / 12;
                    mInvestAmountFromToday = nMonths * nSIP;
                    mInvestAmountWithDelay = (nMonths - delaycharge) * nSIP;
//  SIP Starting after a Delay case ----------------------------------------------------------------------------
                    for (i = 1; i <= (nMonths - delaycharge); i++) {
                        mMaturityDelay = nSIP * (Math.pow((1 + rateOfReturn / 100), i));
                        w_tot_with_delay += mMaturityDelay;
                    }

//  SIP Starting Today case  ---------------------------------------------------------------------------------------
                    for (i = 1; i <= nMonths; i++) {
                        // mMuturityFromToday = mMuturityFromToday + Math.pow((1 + r), (i / 12));
                        w_delay = nSIP * (Math.pow((1 + rateOfReturn / 100), i));
                        w_tot += w_delay;
                    }

                    mLinerResult.setVisibility(View.VISIBLE);


                    mTvSipTitle.setText(requireActivity().getResources().getString(R.string.if_you_start_sip_from_today_then_your_maturity_value_would_be));

                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    long value1 = Math.round(w_tot);
                    String str = format.format(value1);
                    String[] result = str.split("\\.", 0);
                    mTvFutureAmount.setText(result[0]);

                    mTvSipTitle2.setText(getString(R.string.if_you_start_sip_with_delay_of) + Math.round(delaycharge) + requireActivity().getResources().getString(R.string.txt_months_then_our_maturity_value_would_be));

                    long value2 = Math.round(w_tot_with_delay);
                    String str2 = format.format(value2);
                    String[] result2 = str2.split("\\.", 0);
                    mTvSipValue.setText(result2[0]);


                    long value3 = Math.round(mInvestAmountFromToday);
                    String investAmount = format.format(value3);
                    String[] invesRresult = investAmount.split("\\.", 0);
                    mTvResult1.setText(invesRresult[0]);

                    Double onlyProfit = (w_tot - mInvestAmountFromToday);
                    long value4 = Math.round(onlyProfit);
                    String strProfit = format.format(value4);
                    String[] arrayProfit = strProfit.split("\\.", 0);
                    mTvResult2.setText(arrayProfit[0]);

                    String investAmount2 = format.format(mInvestAmountWithDelay);
                    String[] invesRresult2 = investAmount2.split("\\.", 0);
                    mTvResult3.setText(invesRresult2[0]);

                    Double onlyProfit2 = (w_tot_with_delay - mInvestAmountWithDelay);
                    long value5 = Math.round(onlyProfit2);
                    String strProfit2 = format.format(value5);
                    String[] arrayProfit2 = strProfit2.split("\\.", 0);
                    mTvResult4.setText(arrayProfit2[0]);

                    int percentage = (int) ((mInvestAmountFromToday * 100) / w_tot);
                    mProgressBar.setProgress(percentage);

                    int percentage2 = (int) ((mInvestAmountWithDelay * 100) / w_tot_with_delay);
                    mProgressBar2.setProgress(percentage2);

                    String announcement =
                            mTvSipTitle.getText().toString() + ". " + mTvFutureAmount.getText().toString() + ". "
                                    + getString(R.string.delay_cal_amount_investment_txt) + ". " + mTvResult1.getText().toString() + ". "
                                    + getString(R.string.sip_calculator_txt_wealth_gained) + ". " + mTvResult2.getText().toString() + ". "
                                    + mTvSipTitle2.getText().toString() + ". " + mTvSipValue.getText().toString() + ". "
                                    + getString(R.string.delay_cal_amount_investment_txt) + ". " + mTvResult3.getText().toString() + ". "
                                    + getString(R.string.sip_calculator_txt_wealth_gained) + ". " + mTvResult4.getText().toString() + ".";
                    mLinerResult.post(() ->
                            mLinerResult.announceForAccessibility(announcement)
                    );

                } catch (NumberFormatException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }


            }
        }
        }
    }

    public void saveFrameLayout() {
        mClCalcFooter.setVisibility(View.VISIBLE);
        ll_calculator_header.setVisibility(View.VISIBLE);
        loadUpdatedView();
    }

    private void loadUpdatedView() {
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          createImage();
                                      }
                                  },

                100);
    }

    private void createImage() {
        if (mBrokerActivity != null) {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mBrokerActivity);

                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        } else {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mActivity);

                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        }
    }

    private Bitmap getBitmapFromView(View view, int height, int width) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return bitmap;
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                saveFrameLayout();
}
else if (view.getId() == R.id.iv_refresh) {
                refreshView();
}
    }

    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {
            if (mBrokerActivity != null) {
                if (mBrokerActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtDelay) {
                    delayCall();
                }
            } else {
                if (mActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtDelay) {
                    delayCall();
                }
            }

        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

    }


}
