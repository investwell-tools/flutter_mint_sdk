package investwell.broker.bseOnboarding;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class BseProfileBrokerAdapter extends RecyclerView.Adapter<BseProfileBrokerAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private AppSession mSession;
    private OnItemClickListener listener;
    private String mLoggedUserType = "";

    public BseProfileBrokerAdapter(Context context,AppSession session, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mSession = session;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.bse_profile_broker_adapter, viewGroup, false);
        return new BseProfileBrokerAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final BseProfileBrokerAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject mJsonData);

        void onProfileItemClick(int position);

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvUcc, tvPan, tvArn, tcTaxStatus, tvHolding, tvCreateDate, tvCompleteProfile;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvUcc = view.findViewById(R.id.tvUcc);
            tvPan = view.findViewById(R.id.tvPan);
            tvArn = view.findViewById(R.id.tvArn);
            tcTaxStatus = view.findViewById(R.id.tcTaxStatus);
            tvHolding = view.findViewById(R.id.tvHolding);
            tvCreateDate = view.findViewById(R.id.tvCreateDate);
            tvCompleteProfile = view.findViewById(R.id.tvCompleteProfile);
        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final BseProfileBrokerAdapter.OnItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);

                if (!TextUtils.isEmpty(jsonObject.optString("name")) && !jsonObject.optString("name").equalsIgnoreCase("null")) {
                    tvName.setText(jsonObject.optString("name"));
                } else {
                    tvName.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("uccNumber")) && !jsonObject.optString("uccNumber").equalsIgnoreCase("null")) {
                    tvUcc.setText(jsonObject.optString("uccNumber"));
                } else {
                    tvUcc.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("pan")) && !jsonObject.optString("pan").equalsIgnoreCase("null")) {
                    tvPan.setText(jsonObject.optString("pan"));
                } else {
                    tvPan.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("arn")) && !jsonObject.optString("arn").equalsIgnoreCase("null")) {
                    tvArn.setText(jsonObject.optString("arn"));
                } else {
                    tvArn.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("taxStatus")) && !jsonObject.optString("taxStatus").equalsIgnoreCase("null")) {
                    tcTaxStatus.setText(jsonObject.optString("taxStatus"));
                } else {
                    tcTaxStatus.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("holding")) && !jsonObject.optString("holding").equalsIgnoreCase("null")
                        || (!TextUtils.isEmpty(jsonObject.optString("holdingNatureDescription")) && !jsonObject.optString("holdingNatureDescription").equalsIgnoreCase("null"))) {
                    tvHolding.setText(jsonObject.optString("holding"));
                } else {
                    tvHolding.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("createdAt")) && !jsonObject.optString("createdAt").equalsIgnoreCase("null")) {
                    tvCreateDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("createdAt")));
                } else {
                    tvCreateDate.setText(mContext.getString(R.string.not_available));
                }

                boolean isAddEnableProfile = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature35", Permissions.ADD);
                if(!isAddEnableProfile)
                    tvCompleteProfile.setVisibility(View.GONE);
                tvCompleteProfile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onProfileItemClick(position);

                    }
                });

                itemView.setOnClickListener(v -> listener.onItemClick(position, jsonObject));

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }

        }

    }

    public void updateList(List<JSONObject> list, String mLoginType, Boolean isSearch) {
        if (isSearch) {
            mDataList.clear();
        }
        mLoggedUserType = mLoginType;
        mDataList.addAll(list);


        notifyDataSetChanged();
    }

}
