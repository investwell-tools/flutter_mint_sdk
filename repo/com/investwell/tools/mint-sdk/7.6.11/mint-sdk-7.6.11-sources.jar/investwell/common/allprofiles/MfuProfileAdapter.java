package investwell.common.allprofiles;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.Utils;

public class MfuProfileAdapter extends RecyclerView.Adapter<MfuProfileAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private MfuProfileAdapter.OnItemClickListener listener;
    private String mLoggedUserType = "";
    private boolean mIsInvestmentProfile = false;

    public MfuProfileAdapter(Context context, boolean isInvestmentProfile, ArrayList<JSONObject> list, MfuProfileAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mIsInvestmentProfile = isInvestmentProfile;
    }

    @NotNull
    @Override
    public MfuProfileAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_invest_mfu_profile, viewGroup, false);
        return new MfuProfileAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MfuProfileAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject status, String name);

        void onCheckClick(int position, JSONObject status);

        void onProfileItemClick(int position);

        void onMandateItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvManageProfile, tvAddMandate, tv_profile_name, tv_holding_status, tvCan, tvJointHolderName, tvJointHolderName2;
        ImageView mIvActiveStatus, ivForward;
        LinearLayout  llButtons, llDesableView;
        View mViewLine, viewLine2;
        CardView cvMain;

        public ViewHolder(View view) {
            super(view);
            tv_profile_name = view.findViewById(R.id.tv_profile_name);
            tvCan = view.findViewById(R.id.tvIIN);
            tvJointHolderName = view.findViewById(R.id.tv_joint_holder_name);
            tvJointHolderName2 = view.findViewById(R.id.tv_joint_holder_name_2);
            tv_holding_status = view.findViewById(R.id.tv_holding_status);
            mIvActiveStatus = view.findViewById(R.id.ivStatus);
            tvManageProfile = view.findViewById(R.id.tvManageProfile);
            tvAddMandate = view.findViewById(R.id.tvAddMandate);
            llButtons = view.findViewById(R.id.llButtons);
            mViewLine = view.findViewById(R.id.viewLine);
            cvMain = view.findViewById(R.id.cvMain);
            llDesableView = view.findViewById(R.id.llDesableView);
            ivForward = view.findViewById(R.id.ivForward);
            viewLine2 = view.findViewById(R.id.viewLine2);

        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final MfuProfileAdapter.OnItemClickListener listener) {
            try {
                final JSONObject jsonObject = mDataList.get(position);

                if(jsonObject.optString("status").equalsIgnoreCase("incomplete")){
                    viewLine2.setVisibility(View.VISIBLE);
                    tvManageProfile.setVisibility(View.VISIBLE);

                }else if (jsonObject.optString("status").equalsIgnoreCase("AP")){
                    String source = jsonObject.optString("source").toLowerCase().toString();
                    String holdingCode = jsonObject.optString("holdingCode").toString();
                    if (!source.equals("bulkupload") && !source.equals("folio") && holdingCode.equals("SI")){
                        tvManageProfile.setVisibility(View.VISIBLE);
                    }else{
                        tvManageProfile.setVisibility(View.GONE);
                    }
                    tvAddMandate.setVisibility(View.VISIBLE);
                    mIvActiveStatus.setVisibility(View.VISIBLE);
                    mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_green);
                }else {
                    tvManageProfile.setVisibility(View.VISIBLE);
                    tvAddMandate.setVisibility(View.GONE);
                    mIvActiveStatus.setVisibility(View.VISIBLE);
                    mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_red);
                }

                if(tvManageProfile.getVisibility()==View.VISIBLE && tvAddMandate.getVisibility() == View.VISIBLE)
                    viewLine2.setVisibility(View.VISIBLE);
                else
                    viewLine2.setVisibility(View.GONE);

                if (mIsInvestmentProfile) {
                    llButtons.setVisibility(View.GONE);
                    mViewLine.setVisibility(View.GONE);
                    ivForward.setVisibility(View.VISIBLE);
                } else {
                    llButtons.setVisibility(View.VISIBLE);
                    mViewLine.setVisibility(View.VISIBLE);
                    ivForward.setVisibility(View.GONE);
                }


                jsonObject.put("LoginUserType", mLoggedUserType);

                if (!TextUtils.isEmpty(jsonObject.optString("JH1Name")) && !jsonObject.optString("JH1Name").equalsIgnoreCase("null")) {
                    tvJointHolderName.setText(jsonObject.optString("JH1Name"));
                    tvJointHolderName.setVisibility(View.VISIBLE);
                } else {
                    tvJointHolderName.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(jsonObject.optString("JH2Name")) && !jsonObject.optString("JH2Name").equalsIgnoreCase("null")) {
                    tvJointHolderName2.setText(jsonObject.optString("JH2Name"));
                    tvJointHolderName2.setVisibility(View.VISIBLE);
                } else {
                    tvJointHolderName2.setVisibility(View.GONE);
                }

                if((!TextUtils.isEmpty(jsonObject.optString("holdingCode")) && !jsonObject.optString("holdingCode").equalsIgnoreCase("null"))
                        ||(!TextUtils.isEmpty(jsonObject.optString("holdingNatureDescription")) && !jsonObject.optString("holdingNatureDescription").equalsIgnoreCase("null"))){
                    tv_holding_status.setVisibility(View.VISIBLE);
                } else {
                    tv_holding_status.setVisibility(View.GONE);
                }

                if (mLoggedUserType.equalsIgnoreCase("broker")) {
                    tv_profile_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                   if (jsonObject.has("holdingNatureDescription")){
                       tv_holding_status.setText(" | " + Utils.setFirstLetterCapital(jsonObject.optString("holdingNatureDescription")));
                   }else {
                       if(jsonObject.optString("holdingCode").equalsIgnoreCase("SI")){
                           tv_holding_status.setText(" | " + Utils.setFirstLetterCapital("SINGLE"));
                       }else  if(jsonObject.optString("holdingCode").equalsIgnoreCase("JO")){
                           tv_holding_status.setText(" | " + Utils.setFirstLetterCapital("JOINT"));
                       }else{
                           tv_holding_status.setText(" | " + Utils.setFirstLetterCapital("ANYONE OR SURVIVOR"));
                       }
                   }
                } else {
                    tv_profile_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                    if(jsonObject.optString("holdingCode").equalsIgnoreCase("SI")){
                        tv_holding_status.setText(" | " + Utils.setFirstLetterCapital("SINGLE"));
                    }else  if(jsonObject.optString("holdingCode").equalsIgnoreCase("JO")){
                        tv_holding_status.setText(" | " + Utils.setFirstLetterCapital("JOINT"));
                    }else{
                        tv_holding_status.setText(" | " + Utils.setFirstLetterCapital("ANYONE OR SURVIVOR"));
                    }
                }
                

                if ((!TextUtils.isEmpty(jsonObject.optString("canNumber")) && !jsonObject.optString("canNumber").equalsIgnoreCase("null"))) {
                    tvCan.setText(jsonObject.optString("canNumber"));
                    tvCan.setVisibility(View.VISIBLE);
                } else {
                    tvCan.setVisibility(View.GONE);
                }

                itemView.setOnClickListener(v -> listener.onItemClick(position, jsonObject, tv_profile_name.getText().toString()));
                tvManageProfile.setOnClickListener(v -> listener.onProfileItemClick(position));
                tvAddMandate.setOnClickListener(v -> listener.onMandateItemClick(position));
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


        }

    }


    public void updateList(List<JSONObject> list, String mLoginType, Boolean isSearch) {
        if (isSearch) {
            mDataList.clear();
        }
        mLoggedUserType = mLoginType;
        mDataList.addAll(list);


        notifyDataSetChanged();
    }


}

