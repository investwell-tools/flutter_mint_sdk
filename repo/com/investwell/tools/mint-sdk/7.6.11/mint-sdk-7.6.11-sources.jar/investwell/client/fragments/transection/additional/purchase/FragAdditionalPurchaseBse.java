package investwell.client.fragments.transection.additional.purchase;

import static investwell.utils.ExtensionsKt.formatRupees;
import static investwell.utils.ExtensionsKt.getUccCode;
import static investwell.utils.UtilityKotlin.checkFeaturePermissionsOnOff;
import static investwell.utils.UtilityKotlin.firstLetterCapitalOfSentence;
import static investwell.utils.UtilityKotlin.hasReAuthTimeNotValid;
import static investwell.utils.UtilityKotlin.setRefreshKeyInExistingApi;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.client.fragments.transection.BottomScreenPaymentMode;
import investwell.client.fragments.transection.FullScreenBsePopUpDialog;
import investwell.common.allorderstatus.MyOrdersActivity;
import investwell.common.alltransactions.NsePaymentBottomSheet;
import investwell.common.transactions.FullScreenPaymentStatus;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.CurrencyTextToWord;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.RecycleBankAdapter;
import investwell.client.adapter.RecycleMandateAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.allorderstatus.BseOrderStatusActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.customView.CustomDialog;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class FragAdditionalPurchaseBse extends BaseFragment implements View.OnClickListener ,BottomScreenPaymentMode.ResultListener{
    private TextView  mTvcardview_top_name_color,tvWordAmount;
    private RequestQueue requestQueue;
    private EditText mEtAmount;
    private final DecimalFormat myFormatter = new DecimalFormat("##,##,###.00");
    private ClientActivity mActivity;
    private AppSession mSession;
    private JSONObject mOldJsonObject, tranJsonObject, mObjNewScheme, mPlaceOderResponseObj;
    private ArrayList<JSONObject> mSchemeList, mBankList, mMandateList;
    private final long mMinAmount = 0;
    private final long mMaxAmount = 0;
    private final String mcardview_top_name_color = "";
    private String mTransactionType = "",mSelectedMemberCode="";
    private String mPaymentOption = "email";
    private RadioGroup mRadioGroup1;
    private AppApplication mAppplication;
    private ToolbarFragment mFragToolBar;
    private String orderNumber, message;
    private String mBseId = "";
    private LinearLayout mllPaynowOptions, mllUpiNeftField, mLLBankList, mLinerMandateList;
    private RelativeLayout rlMandateTitle;

    private Spinner mspPayNowOptions;
    private EditText etUPI;
    private TextView tvUpiNeftLavel,tvErrorMessage;
    private RecycleBankAdapter mBankAdapter;
    private ApiDataBase db;
    private List<JSONObject> mJsonARNList;
    private Spinner mSpArn,spDivedentFrequencySip;
    private LinearLayout mLlArn;
    private RecycleMandateAdapter mMandateAdapter;
    private String mFundName = "",mSchemeGroupId="",mPurchaseType="NRP";
    private JSONObject profileObject,paymentDetails;

    private BottomScreenPaymentMode bottomPaymentMode;
    private  String mPaymentMode;
    private FullScreenBsePopUpDialog popup;
    private boolean isNse2 = false;
    private String mExchange = "2";
    private String uccNumber = "",nseUccCode="",mSchemeType="G",mSchemeId = "",mSchemeName = "";
    private LinearLayout llschemeTypeMain,llSchemeType,llDividentFreqSip,llAmount;
    private ProgressBar pbLoaderOnSchemeType;
    private TextView tvGrowth,tvDividend,tvDividendReinvest,tvLabelMinAmount;
    private View line1,line2;
    private JSONArray mSIPDateArray = new JSONArray();
    private ArrayList<JSONObject> mJsonDividend = new ArrayList<>();
    private JSONObject mJsonObjNseInfo = new  JSONObject();
    private MaterialButton transact_btn;
    private MaterialButton tvCart;
    private LinearLayout llBottomButtons;

    private LinearLayout llPaymentOptions;
    private RadioGroup rgPaymentOptions;
    private boolean isAddToCartBseEnabled = false;
    private boolean isAddToCartNseInvestEnabled = false;
    private TextView tvArnLabel,tvArnValue,tvSubBrokerArnLabel,tvSubBrokerArnValue,tvSubBrokerCodeLabel,tvSubBrokerCodeValue,tvEuinLabel,tvEuinValue;
    private String defaultSchemeId = "";
    private boolean isSchemeChanged = false;
    private UtilityKotlin.MinAmountResult minAmountResult = null;


    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(
                url,
                req,
                res,
                AppConstants.ADDITIONAL_PURCHASE,
                dateTime,
                endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
      /*  if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.AdditionalPurchase), true, false, false, false, false, false, false);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_addition_purchase, container, false);
        db = ApiDataBase.getInstance(mActivity.getApplicationContext());

        setUpToolBar();

        mSpArn = view.findViewById(R.id.spArn);
        mLlArn = view.findViewById(R.id.llArn);
        llschemeTypeMain = view.findViewById(R.id.llschemeTypeMain);
        llSchemeType = view.findViewById(R.id.llSchemeType);
        pbLoaderOnSchemeType = view.findViewById(R.id.pbLoaderOnSchemeType);
        tvErrorMessage = view.findViewById(R.id.tvErrorMessage);
        tvGrowth = view.findViewById(R.id.tvGrowth);
        llAmount = view.findViewById(R.id.llAmount);

        tvGrowth.setOnClickListener(this);
        tvDividend =view.findViewById(R.id.tvDividend);
        llDividentFreqSip =view.findViewById(R.id.llDividentFreqSip);
        line1 =view.findViewById(R.id.line1);
        line2 =view.findViewById(R.id.line2);
        tvDividend.setOnClickListener(this);
        tvDividendReinvest =view.findViewById(R.id.tvDividendReinvest);
        spDivedentFrequencySip =view.findViewById(R.id.spDivedentFrequencySip);
        tvDividendReinvest.setOnClickListener(this);

        mLlArn.setVisibility(View.GONE);
//        if (mSession.getLoginType().equals("broker")) {
//            getArnList();
//        }

        TextView user_name = view.findViewById(R.id.user_name);
        TextView tvUcc = view.findViewById(R.id.tvUcc);
        TextView tvFolio = view.findViewById(R.id.tvFolio);
        mTvcardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);
        mEtAmount = view.findViewById(R.id.amount);
        tvWordAmount = view.findViewById(R.id.tvWordAmount);
        tvLabelMinAmount = view.findViewById(R.id.tvLabelMinAmount);
        mRadioGroup1 = view.findViewById(R.id.radioGroup1);
        rgPaymentOptions = view.findViewById(R.id.rgPaymentOptions);
        mLLBankList = view.findViewById(R.id.linerBankList);
        mSchemeList = new ArrayList<>();

        rlMandateTitle = view.findViewById(R.id.rlMandateTitle);
        mLinerMandateList = view.findViewById(R.id.llMandate);

        mllPaynowOptions = view.findViewById(R.id.llPaynowOptions);
        mllUpiNeftField = view.findViewById(R.id.llUpiNeftField);
        mspPayNowOptions = view.findViewById(R.id.spPayNowOptions);
        tvUpiNeftLavel = view.findViewById(R.id.tvUpiNeftLavel);
        etUPI = view.findViewById(R.id.etUPI);
        mllPaynowOptions.setVisibility(View.GONE);
        mllUpiNeftField.setVisibility(View.GONE);

        RecyclerView rvMandateList = view.findViewById(R.id.rvMandateList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        rvMandateList.setLayoutManager(layoutManager);
        rvMandateList.setHasFixedSize(true);
        WindowManager wm = (WindowManager) getActivity().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        int width = display.getWidth();
        mMandateAdapter = new RecycleMandateAdapter(getActivity(), new ArrayList<JSONObject>(), width, new RecycleMandateAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });
        rvMandateList.setAdapter(mMandateAdapter);

        setPaymentOption();

        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mOldJsonObject = new JSONObject(bundle.getString("oldObject"));
                defaultSchemeId = mOldJsonObject.getString("schid");
                tranJsonObject = new JSONObject(bundle.getString("tranJsonObject"));
                if (tranJsonObject.has("investmentType")){
                    mSchemeType =tranJsonObject.optString("investmentType");
                }else {
                    mSchemeType ="";
                }
                if (bundle.containsKey("nse2")){
                    isNse2 = bundle.getBoolean("nse2");
                    mExchange = bundle.getString("exchange");
                }else {
                    mExchange = "2";
                    isNse2 = false;
                }

                mFundName = mOldJsonObject.optString("fundName");
                mSchemeGroupId = mOldJsonObject.optString("schemeGroupId");
                mTransactionType = bundle.getString("transactionType");
                if (bundle.containsKey("sIinProfileObject")){
                    profileObject = new JSONObject(bundle.getString("sIinProfileObject"));
                    if (isNse2){
                        mBseId = profileObject.optString("nseInvestid");
                        nseUccCode= getUccCode(isNse2,profileObject,mOldJsonObject);
                    }else {
                        mBseId = profileObject.optString("bseid");
                        uccNumber= getUccCode(isNse2,profileObject,mOldJsonObject);
                    }
                }


                user_name.setText(mOldJsonObject.optString("applicant_name"));
                mTvcardview_top_name_color.setText(mOldJsonObject.optString("schemeName"));

                tvUcc.setText(getUccCode(isNse2,profileObject,mOldJsonObject));
                tvFolio.setText(mOldJsonObject.optString("folioNo"));

            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }

        Runnable apiCall = () -> {
            if (!TextUtils.isEmpty(mBseId)) {
                getBankList();
                getMandateList(mBseId);
            }
        };

        if ("broker".equals(mSession.getLoginType())) {
            getArnList(apiCall);
        } else {
            apiCall.run();
        }


        LinearLayoutManager layoutManager2 = new LinearLayoutManager(mActivity);
        layoutManager2.setOrientation(LinearLayoutManager.HORIZONTAL);
        RecyclerView recycleView = view.findViewById(R.id.recycleView);
        recycleView.setLayoutManager(layoutManager2);
        recycleView.setHasFixedSize(true);

        DisplayMetrics displaymetrics = new DisplayMetrics();
        mActivity.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        int screenWidth = displaymetrics.widthPixels;

        mBankList = new ArrayList<>();
        mMandateList = new ArrayList<>();
        mBankAdapter = new RecycleBankAdapter(mActivity, new ArrayList<JSONObject>(), screenWidth, new RecycleBankAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });
        recycleView.setAdapter(mBankAdapter);


        mRadioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio1) {
                        mPaymentOption = "payNow";
                        mllPaynowOptions.setVisibility(View.VISIBLE);
                        mllUpiNeftField.setVisibility(View.GONE);
                        setPaymentOption();
}
else if (checkedId == R.id.radio2) {
                        mLLBankList.setVisibility(View.GONE);
                        mLinerMandateList.setVisibility(View.GONE);
                        mPaymentOption = "email";
                        mllPaynowOptions.setVisibility(View.GONE);
                        mllUpiNeftField.setVisibility(View.GONE);
}
            }
        });

        view.findViewById(R.id.ivEdit).setOnClickListener(this);
        transact_btn = view.findViewById(R.id.transact_btn);
        transact_btn.setOnClickListener(this);
        tvCart = view.findViewById(R.id.tvCart);
        llBottomButtons = view.findViewById(R.id.llBottomButtons);
        llPaymentOptions = view.findViewById(R.id.llPaymentOptions);
        tvCart.setOnClickListener(this);

        applyDefaultButtonState();


        mEtAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String word ="";
                if (!TextUtils.isEmpty(charSequence)){
                    try {
                        if (charSequence.length() !=0){
                            word = CurrencyTextToWord.convertToIndianCurrency(requireContext(),charSequence.toString().trim());
                        }else {
                            word = firstLetterCapitalOfSentence("");
                        }
                    }catch (Exception e){
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }else {
                    word = firstLetterCapitalOfSentence("");
                }
                tvWordAmount.setText(word);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        getInvestmentType();
        return view;
    }


    private void valiedSchemeType(){
//        llSchemeView.visibility = View.VISIBLE
//        llschemeTypeMain.visibility = View.VISIBLE
//        tvScheme.setText(
//                mOldSchemeObj.optString("schemeGroupName", mOldSchemeObj.optString("schemeName"))
//        )
//        llSchemeView.isEnabled = false
//        tvScheme.isEnabled = false

//        pbLoaderOnSchemeType
//        llschemeTypeMain
        //tvErrorMessage
        //llSchemeType

    }



    private void updateSchemeTypeUi() {
        if (mSchemeType.equals("G")) {
            tvGrowth.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.login_btn_bg_two));
            tvGrowth.setSelected(true);
            tvDividend.setSelected(false);
            tvDividendReinvest.setSelected(false);
            tvDividend.setBackgroundColor(Color.TRANSPARENT);
            tvDividendReinvest.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.GONE);
            line1.setVisibility(View.GONE);
            line2.setVisibility(View.VISIBLE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3. Not Selected");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3. Not Selected");
            getSchemeDetails();

        } else if (mSchemeType.equals("DP")) {
            tvDividend.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.login_btn_bg_two));
            tvGrowth.setSelected(false);
            tvDividend.setSelected(true);
            tvDividendReinvest.setSelected(false);

            tvGrowth.setBackgroundColor(Color.TRANSPARENT);
            tvDividendReinvest.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.VISIBLE);
            line1.setVisibility(View.GONE);
            line2.setVisibility(View.GONE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3. Not Selected");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3. Not Selected");
            getSchemeDetails();
        } else if (mSchemeType.equals("DR")) {
            tvDividendReinvest.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.login_btn_bg_two));
            tvGrowth.setSelected(false);
            tvDividend.setSelected(false);
            tvDividendReinvest.setSelected(true);

            tvGrowth.setBackgroundColor(Color.TRANSPARENT);
            tvDividend.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.VISIBLE);
            line1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.GONE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3. Not Selected");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3. Not Selected");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3");
            getSchemeDetails();
        } else {
            tvDividend.setTextColor(ContextCompat.getColor(requireActivity(), R.color.black));
            tvGrowth.setTextColor(ContextCompat.getColor(requireActivity(), R.color.black));
            tvDividendReinvest.setTextColor(ContextCompat.getColor(requireActivity(), R.color.black));

            tvGrowth.setBackgroundColor(Color.TRANSPARENT);
            tvDividend.setBackgroundColor(Color.TRANSPARENT);
            tvDividendReinvest.setBackgroundColor(Color.TRANSPARENT);
            llDividentFreqSip.setVisibility(View.GONE);
            line1.setVisibility(View.VISIBLE);
            line2.setVisibility(View.VISIBLE);
            tvGrowth.setContentDescription(tvGrowth.getText().toString() + ". Tab 1 of 3. Not Selected");
            tvDividend.setContentDescription(tvDividend.getText().toString() + ". Tab 2 of 3. Not Selected");
            tvDividendReinvest.setContentDescription(tvDividendReinvest.getText().toString() + ". Tab 3 of 3. Not Selected");
        }

    }

    private void getInvestmentType() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){return;}

            String mUrl ="";
        try {
            String nseBseCode = "";
            if (isNse2){
                nseBseCode ="&hasNseInvestCode=true";
            }else {
                nseBseCode="&hasBseCode=true";
            }
            mUrl = "https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.GET_INVESTMENT_TYPE+
                    "schemeGroupId="+mSchemeGroupId+"&subType="+mPurchaseType+nseBseCode +
                    "&investorUid="+Utils.getSelectedUid(mSession)+"&selectedUser="+Utils.getSelectedUserObject(mSession);
            String refreshedUrl = setRefreshKeyInExistingApi(mUrl, mSession);
           mUrl=  URLDecoder.decode(refreshedUrl, "UTF-8");
        } catch (Exception e) {
        }
        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                mUrl,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        KtorCallBack.super.onLoading(isLoading);
                        if (isLoading)
                            pbLoaderOnSchemeType.setVisibility(View.VISIBLE);
                        else
                            pbLoaderOnSchemeType.setVisibility(View.GONE);
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                llschemeTypeMain.setVisibility(View.VISIBLE);
                                llSchemeType.setVisibility(View.VISIBLE);
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONObject objData = null;
                                if (jsonObject1 != null) {
                                    objData = jsonObject1.optJSONObject("data");
                                }
                                JSONArray mSchemeTypeJsonArray = null;
                                if (objData != null) {
                                    mSchemeTypeJsonArray = objData.optJSONArray("allowedInvestmentTypes");
                                }


                                tvGrowth.setEnabled(false);
                                tvDividend.setEnabled(false);
                                tvDividendReinvest.setEnabled(false);
                                mSchemeType = "";
                                if (mSchemeTypeJsonArray != null && mSchemeTypeJsonArray.length() > 0) {
                                    if (containsValue(mSchemeTypeJsonArray, "G") && containsValue(mSchemeTypeJsonArray, "D")) {
                                        tvGrowth.setEnabled(true);
                                        tvDividend.setEnabled(true);
                                        tvDividendReinvest.setEnabled(true);
                                        mSchemeType = "G";
                                    } else if (containsValue(mSchemeTypeJsonArray, "G")) {
                                        tvGrowth.setEnabled(true);
                                        mSchemeType = "G";
                                    } else {
                                        tvDividend.setEnabled(true);
                                        tvDividendReinvest.setEnabled(true);
                                        mSchemeType = "DP";
                                    }
                                    tvErrorMessage.setVisibility(View.GONE);
                                    llSchemeType.setVisibility(View.VISIBLE);
                                    transact_btn.setEnabled(true);
                                    updateSchemeTypeUi();
                                    if (mSchemeTypeJsonArray.length() == 1  && mSchemeType.equalsIgnoreCase("G")){
                                        llschemeTypeMain.setVisibility(View.GONE);
                                    }

                                } else {
                                    tvErrorMessage.setVisibility(View.VISIBLE);
                                    tvErrorMessage.setText(getString(R.string.no_scheme_type_available));
                                    llSchemeType.setVisibility(View.GONE);
//                                    checkPayNow.setVisibility(View.GONE);
                                    // disable button
                                    transact_btn.setEnabled(false);

                                }
                            } else if (jsonObject.optInt("status") == -1) {
//                                binding.llAfterSchemeType.setVisibility(View.GONE);
                                llSchemeType.setVisibility(View.GONE);
                                transact_btn.setEnabled(false);
                                Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                        }


                        //            llschemeTypeMain.setVisibility(View.VISIBLE);

                    }
                }
        );
    }

    public static boolean containsValue(JSONArray array, String value) {
        if (array == null || value == null) return false;

        for (int i = 0; i < array.length(); i++) {
            if (value.equals(array.optString(i))) {
                return true;
            }
        }
        return false;
    }



    private void getSchemeDetails() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
         String mUrl = "";
            try {
                String nseBseCode = "";
                if (isNse2){
                    nseBseCode ="&hasNseInvestCode=true";
                }else {
                    nseBseCode="&hasBseCode=true";
                }

                mUrl ="https://"+mSession.getUserBrokerDomain()+mSession.getHostingPath()+Config.GET_TARGET_SCHEME+"schemeGroupId="+mSchemeGroupId+"&investmentType="+mSchemeType+"&subType="+mPurchaseType+
                        nseBseCode+"&investorUid="+Utils.getSelectedUid(mSession)+"&selectedUser="+Utils.getSelectedUserObject(mSession);
                String refreshedUrl = setRefreshKeyInExistingApi(mUrl, mSession);
                mUrl =URLDecoder.decode(refreshedUrl, "UTF-8");

            }catch (Exception e){
            }

        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                mUrl,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        KtorCallBack.super.onLoading(isLoading);
                        if (isLoading){
                            ProgressBarCommon.showDialog(requireActivity());
                        }else{
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {
                        ArrayList<String> freqency = new ArrayList<>();
                        mSIPDateArray = new JSONArray();
                        try {
                            JSONObject jsonObject = new JSONObject(response.toString());
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                JSONObject jsonObj2 = jsonArray.getJSONObject(0);
                                mSchemeId = Utils.getSchemeIdFromAll(jsonObj2);
                                mSchemeName = jsonObj2.optString("name");
                                //new

                                JSONObject jsonObjectNew = jsonArray.optJSONObject(0);
                                mSIPDateArray = jsonObjectNew.optJSONArray("daysOfTheMonth");
                                mJsonDividend = new ArrayList();

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    var dividentFreq = jsonObject1.optString("dividendFrequency");
                                    if (!dividentFreq.equals("") && !dividentFreq.equalsIgnoreCase("null")) {
                                        dividentFreq = dividentFreq.toUpperCase(Locale.getDefault());
                                        dividentFreq = setUsername(dividentFreq);
                                        freqency.add(dividentFreq);
                                    }
                                    mJsonDividend.add(jsonObject1);
                                }
                                if (!mSchemeType.equalsIgnoreCase("G")) {
                                    setDividendFrequency(freqency);
                                }else {
                                    setMinAmount();
                                }
                                tvErrorMessage.setVisibility(View.GONE);
                                llAmount.setVisibility(View.VISIBLE);
                                //user is allowed to addToCart again if schid is changed
                                applyDefaultButtonState();
                                transact_btn.setEnabled(true);
                                llBottomButtons.setVisibility(View.VISIBLE);
                            } else {
                                llAmount.setVisibility(View.GONE);
                                transact_btn.setEnabled(false);
                                llBottomButtons.setVisibility(View.GONE);
                                tvErrorMessage.setVisibility(View.VISIBLE);
                                tvErrorMessage.setText(getString(R.string.not_available));
//                                relFrequency.setVisibility(View.GONE);
                                llDividentFreqSip.setVisibility(View.GONE);
                            }
                        } catch ( Exception e) {
                        }
                    }
                }
        );


    }

    private void setMinAmount() {
        int divFreqPos;
        if (mSchemeType.equalsIgnoreCase("G"))
            divFreqPos = 0;
        else
            divFreqPos = spDivedentFrequencySip.getSelectedItemPosition();

        String minAmountKey ;
        if(isSchemeChanged)
            minAmountKey = "minAmount";
        else
            minAmountKey = "minAdditionalAmount";

        minAmountResult = UtilityKotlin.getMinAmount(mJsonDividend, divFreqPos, minAmountKey);
        if (minAmountResult.getVisibility() == UtilityKotlin.MinAmountVisibility.HIDE) {
            tvLabelMinAmount.setVisibility(View.GONE);
        } else {
            tvLabelMinAmount.setVisibility(View.VISIBLE);
            Double minAmount = minAmountResult.getMinAmount();

            if (minAmount != null) {
                tvLabelMinAmount.setText("Min : "+formatRupees(this,minAmount));
            }
        }
    }

    private String setUsername(String name) {
        StringBuffer capBuffer = new StringBuffer();
        java.util.regex.Matcher capMatcher = java.util.regex.Pattern
                .compile("([a-z])([a-z]*)", java.util.regex.Pattern.CASE_INSENSITIVE)
                .matcher(name == null ? "" : name);
        while (capMatcher.find()) {
            String firstChar = capMatcher.group(1).toUpperCase(java.util.Locale.getDefault());
            String restChars = capMatcher.group(2).toLowerCase(java.util.Locale.getDefault());
            capMatcher.appendReplacement(capBuffer, firstChar + restChars);
        }
        capMatcher.appendTail(capBuffer);
        return capBuffer.toString();
    }


    private void setDividendFrequency(List<String> frequencyList) {
        try {
            llDividentFreqSip.setVisibility(View.VISIBLE);
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(
                    requireActivity(),
                    R.layout.spinner_bg,
                    frequencyList
            );
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            spDivedentFrequencySip.setAdapter(dataAdapter);

            spDivedentFrequencySip.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    // Handle item selected

                    //user is allowed to addToCart again if schid is changed
                    applyDefaultButtonState();
                    JSONObject jsonObject = mJsonDividend.get(position);
                    mSchemeId = Utils.getSchemeIdFromAll(jsonObject);
                    mSchemeName = jsonObject.optString("name");
                    setMinAmount();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Handle nothing selected
                }
            });
        } catch (Exception ignored) {
        }


    }



    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.back_arrow) {
                getActivity().getSupportFragmentManager().popBackStack();
}
else if (v.getId() == R.id.tvGrowth) {
                mSchemeType = "G";
                updateSchemeTypeUi();
}
else if (v.getId() == R.id.tvDividend) {
                mSchemeType = "DP";
                updateSchemeTypeUi();
}
else if (v.getId() == R.id.tvDividendReinvest) {
                mSchemeType = "DR";
                updateSchemeTypeUi();
}
else if (v.getId() == R.id.ivEdit) {
                if (mSchemeList.size() > 0) {
                    showSchemesDailog();
                } else {
                    isSchemeChanged = false;
                    getSchemes(mOldJsonObject.optString("fundid"));
                }
}
else if (v.getId() == R.id.transact_btn) {
                if(isValidInputNseBse("transact")){
                    if (isNse2){
                        NsePaymentBottomSheet bottomSheetDialog = getNsePaymentBottomSheet();

                        bottomSheetDialog.show(
                                requireActivity().getSupportFragmentManager(),
                                NsePaymentBottomSheet.class.getSimpleName()
                        );

                    }else{
                        if ((transact_btn.getText().toString().equalsIgnoreCase(getString(R.string.place_order)))){
                            placePurchageOrder(
                                    false,
                                    "",
                                    false,
                                    "",
                                    "",
                                    "",
                                    new JSONObject(),
                                    isNse2
                            );
                        }
                        else{
                            transactNowBtnClicked();
                        }
                    }
                }
}
else if (v.getId() == R.id.tvCart) {
                if (tvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {
                    if (isValidInputNseBse("cart"))
                        insertTxnInNseOrBseCart();
                } else {

                    Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                    intent.putExtra("url", UtilityKotlin.constructCartUrl(mSession));
                    intent.putExtra("isPopup", true);
                    intent.putExtra("comeFrom", "client");
                    startActivity(intent);
                    new Handler(Looper.getMainLooper()).postDelayed(this::addToCartBtnClicked, 1500);
                }
}
    }

    @NonNull
    private NsePaymentBottomSheet getNsePaymentBottomSheet() {
        NsePaymentBottomSheet bottomSheetDialog = new NsePaymentBottomSheet(
                mBankList,
                mMandateList,
                mSelectedMemberCode,
                nseUccCode
        );


        bottomSheetDialog.onValidateButtonClick((resultBundle, paymentMode) -> {
            paymentDetails = resultBundle;
            placePurchageOrder(
                    false,               // isIgnoreDuplicate
                    "",                  // otp
                    false,               // isValidated
                    "",                  // provisionalOrderid
                    "",                  // mode
                    "",                  // loopbackUrl
                    resultBundle,         // paymentDetails
                    isNse2
            );
            return null;
        });
        return bottomSheetDialog;
    }


    private boolean isValidInputNseBse(String clickedFrom){
        if(mSchemeType.isEmpty()){
            Toast.makeText(mActivity, getString(R.string.new_purchase_text_select_scheme_type), Toast.LENGTH_SHORT).show();
            return false;
        }

        else if(mEtAmount.getText().toString().isEmpty()){
            Toast.makeText(mActivity, getString(R.string.error_empty_amount), Toast.LENGTH_SHORT).show();
            return false;
        }

        else if (minAmountResult != null && minAmountResult.getVisibility() == UtilityKotlin.MinAmountVisibility.SHOW && Double.parseDouble(mEtAmount.getText().toString().trim()) < minAmountResult.getMinAmount()) {
            Toast.makeText(mActivity, getString(R.string.minimum_amount_should_be) + " " + formatRupees(this,minAmountResult.getMinAmount()), Toast.LENGTH_SHORT).show();
            return false;
        }

        else if (isNse2 && !mSchemeType.equalsIgnoreCase("G") && spDivedentFrequencySip.getSelectedItem().toString().isEmpty()) {
            Toast.makeText(mActivity, getString(R.string.please_select_div_frequency), Toast.LENGTH_SHORT).show();
        } else if (!isNse2 &&
                clickedFrom.equalsIgnoreCase("transact") &&
                mSession.getShowBseAuthPopup() &&
                llPaymentOptions.getVisibility() == View.VISIBLE &&
                rgPaymentOptions.getCheckedRadioButtonId() == -1) {
            Toast.makeText(mActivity, getString(R.string.new_purchase_text_select_payment), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void orderExistsDailog() {
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    if(isNse2){
                        placePurchageOrder(
                                true,
                                "",
                                false,
                                "",
                                "",
                                "",
                                paymentDetails,
                                true);
                    }else {
                        if (mSession.getShowBseAuthPopup()) {
                            Bundle mbBundle = new Bundle();
                            mbBundle.putString("mBseId",mBseId);
                            bottomPaymentMode = BottomScreenPaymentMode.create(
                                    requireActivity(),
                                    R.style.ModalBottomSheetDialog,
                                    mbBundle
                            );
                            bottomPaymentMode.setListener(this);
                            bottomPaymentMode.show();
                        }else{
                            placePurchageOrder(
                                    true,
                                    "",
                                    false,
                                    "",
                                    "",
                                    "",
                                    new JSONObject(),
                                    false);
                        }
                    }
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(getActivity(), getString(R.string.alert_dialog_order_exist_header_txt),
                getString(R.string.alert_dialog_order_exist_message_txt),
                getString(R.string.alert_dialog__order_exist_button1),
                getString(R.string.alert_dialog__order_exist_button2),
                true, true);
    }

    private void placePurchageOrder(
            boolean isIgnoreDuplicate,
            String otp,
            boolean isValidated,
            String provisonalOrderId,
            String paymentMode,
            String loopBackUrl,
            JSONObject paymentDetails,
            boolean isNse2Value
    ) {

        Utils.hideKeyBoardFromAnyWhere(requireActivity());
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        String url ="";
        if (isNse2Value){
            url ="https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +Config.NSE_INVEST_PLACE_ORDER;
        }else {
            url= "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.PLACE_PURCHAGE_ORDER;
        }
        JSONObject objectMain = new JSONObject();

        try {

            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            if (!isNse2Value && isValidated){
                objectMain.put("provisionalOrderid",provisonalOrderId);
                objectMain.put("otp", otp);
            }else {
                // common
                objectMain.put("txnType", "ADDITIONAL"); // or "FRESH/ADDITIONAL" as per logic

                objectMain.put("folioNo", mOldJsonObject.optString("folioNo"));
                objectMain.put("folioid", mOldJsonObject.optString("folioid"));
                if (mSession.getLoginType().equals("broker")) {
                    if (mJsonARNList.size() == 1) {
                        JSONObject folioObject = mJsonARNList.get(0);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    } else {
                        int position = mSpArn.getSelectedItemPosition();
                        if (position == 0)
                            objectMain.put("arnid", "");
                        else {
                            String marnId="";
                            try {
                                JSONObject folioObject = mJsonARNList.get(position - 1);
                                marnId = folioObject.optString("arnid");
                            } catch (Exception e) {
                                marnId ="";
                            }
                            objectMain.put("arnid", marnId);
                        }
                    }
                }else {
                    objectMain.put("arnid", "");
                }

                //mJsonDividend
                objectMain.put("schid", mSchemeId);


                if (isIgnoreDuplicate)
                    objectMain.put("ignoreDuplicate", "N");


                if (isNse2Value){
                    objectMain.put("nseInvestid", mBseId);
                    objectMain.put("nseUccCode", nseUccCode);
                    objectMain.put("txnMode", "P");
                    objectMain.put("amount", mEtAmount.getText().toString().trim());
//                    if (paymentDetails !=null){
//                        objectMain.put("paymentDetails",paymentDetails);
//                    }
                    Extensions.mergeJson(objectMain,paymentDetails);

                    String paymentOptions = mspPayNowOptions.getSelectedItem().toString();
                    if (paymentOptions.equalsIgnoreCase("Mandate")) {
                        objectMain.put("paymentMode", "mandate");
                        String seletedMandateId = "";
                        if (mMandateAdapter.mHashSelection.containsValue(true)) {
                            for (int i = 0; i < mMandateAdapter.mHashSelection.size(); i++) {
                                if (mMandateAdapter.mHashSelection.get(i)) {
                                    JSONObject jsonObject = mMandateAdapter.mDataList.get(i);
                                    seletedMandateId = jsonObject.optString("id");

                                }
                            }
                        }
                        objectMain.put("mandateId", seletedMandateId);
                    }


                }else {
                    objectMain.put("uccNumber", uccNumber);
                    objectMain.put("amount", mEtAmount.getText().toString().trim());


                    if (mPaymentOption.equalsIgnoreCase("payNow")) {
                        String paymentOptions = mspPayNowOptions.getSelectedItem().toString();
                        if (paymentOptions.equalsIgnoreCase("Mandate")) {
                            objectMain.put("paymentMode", "mandate");
                            String seletedMandateId = "";
                            if (mMandateAdapter.mHashSelection.containsValue(true)) {
                                for (int i = 0; i < mMandateAdapter.mHashSelection.size(); i++) {
                                    if (mMandateAdapter.mHashSelection.get(i)) {
                                        JSONObject jsonObject = mMandateAdapter.mDataList.get(i);
                                        seletedMandateId = jsonObject.optString("id");

                                    }
                                }
                            }
                            objectMain.put("mandateId", seletedMandateId);
                        }else if (paymentOptions.equalsIgnoreCase("Net Banking")) {
                            objectMain.put("paymentMode", "Net Banking");
                        } else if (paymentOptions.equalsIgnoreCase("NEFT/RTGS")) {
                            objectMain.put("paymentMode", "neft/rtgs");
                        } else if (paymentOptions.equalsIgnoreCase("UPI")) {
                            objectMain.put("paymentMode", "UPI");
                        }
                        objectMain.put("paymentMethod", mPaymentOption);
                    }
                    if (mSession.getShowBseAuthPopup()){
                        objectMain.put("loopbackUrl", loopBackUrl);
                        objectMain.put("paymentDetails",paymentDetails);
                        if (!isNse2 && rgPaymentOptions.getCheckedRadioButtonId() == R.id.rbLinkOnEmail)
                            objectMain.put("paymentMethod", "linkOnEmail");
                        else
                            objectMain.put("paymentMethod", "payNow");
                    }

                }
            }


        } catch (Exception e) {

        }
        final String finalUrl = "";//url;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);

                insertApiData(finalUrl, objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.PLACE_PURCHAGE_ORDER);

                mBar.dismiss();
                try {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        mPlaceOderResponseObj = jsonObject.optJSONObject("result");
                        if (!isNse2Value){
                            if (!mSession.getShowBseAuthPopup()){
                                if (!mPlaceOderResponseObj.optString("status").equalsIgnoreCase("failed")) {
                                    // else existing logic
                                    Bundle bundle = new Bundle();
                                    bundle.putString("bseid", mBseId);
                                    bundle.putString("payNowOptionType", mPaymentOption);
                                    bundle.putString("amount", mEtAmount.getText().toString().trim());
                                    mPlaceOderResponseObj.put("ClientCode", uccNumber);
                                    mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));
                                    bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                    bundle.putString("fundName", mFundName);
                                    Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                    intent.putExtras(bundle);
                                    startActivity(intent);
                                }else {
                                    Bundle bundle = new Bundle();
                                    bundle.putString("bseid", mBseId);
                                    bundle.putString("payNowOptionType", "");
                                    bundle.putString("amount", mEtAmount.getText().toString().trim());
                                    bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                    bundle.putString("fundName", mFundName);
                                    Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                    intent.putExtras(bundle);
                                    startActivity(intent);
                                }
                            }else {
                                // new flow
                                if (mSession.getShowBseAuthPopup() && isValidated){
                                    // dismiss the popup
                                    if (popup.isVisible()){popup.dismiss();}
                                    Bundle mBundle = new Bundle();
                                    String orderNumber = "";
                                    if (!mPlaceOderResponseObj.optString("OrderNumber").equals("null") && !mPlaceOderResponseObj.optString("OrderNumber").equals("")) {
                                        orderNumber = mPlaceOderResponseObj.optString("OrderNumber");
                                    }
                                    else if (!mPlaceOderResponseObj.optString("orderNo").equals("null") && !mPlaceOderResponseObj.optString("orderNo").equals("")) {
                                        orderNumber = mPlaceOderResponseObj.optString("orderNo");
                                    }

                                    String paymentData = "";
                                    if (!mPlaceOderResponseObj.optString("paymentData").equals("null") && !mPlaceOderResponseObj.optString("paymentData").equals("")) {
                                        paymentData = mPlaceOderResponseObj.optString("paymentData");
                                    }
                                    String status = mPlaceOderResponseObj.optString("status");

                                    if(!isNse2 && mSession.getLoginType().equalsIgnoreCase("broker") && mPlaceOderResponseObj.has("bseLinkOnMail") && mPlaceOderResponseObj.optBoolean("bseLinkOnMail")){
                                        mBundle = new Bundle();
                                        mBundle.putString("type", "success");
                                        mBundle.putString("title", getString(R.string.payment_link_sent));
                                        mBundle.putString("mode", mPaymentMode);
                                        mBundle.putString("mTitle", orderNumber);
                                        mBundle.putString("mDescription", getString(R.string.payment_email_message, mPlaceOderResponseObj.optString("email")));
                                        mBundle.putBoolean("lottie", true);
                                        mBundle.putString("message", "");
                                        mBundle.putString("paymentData", paymentData);
                                        mBundle.putBoolean("bseLinkOnMail", true);
                                        popupSuccessOrFailed(mBundle);
                                    }
                                    else if (!paymentData.isEmpty() && !status.equals("failed")){
                                        mBundle = new Bundle();
                                        mBundle.putString("type", "success");
                                        mBundle.putString("title", "Payment");
                                        mBundle.putString("mTitle", orderNumber);
                                        mBundle.putString("mode", paymentMode);
                                        mBundle.putString("mDescription", getString(R.string.txt_bse_order_status_des));
                                        mBundle.putBoolean("lottie", true);
                                        mBundle.putString("message", mPlaceOderResponseObj.optString("amount"));
                                        mBundle.putString("paymentData", paymentData);
                                        popupSuccessOrFailed(mBundle);
                                        //
                                        if (paymentMode.contains("Net Banking")){
                                            Intent netBankingContent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                                            netBankingContent.putExtra("title","Transaction");
                                            netBankingContent.putExtra("htmlContent",paymentData);
                                            netBankingContent.putExtra("endPointUrl", loopBackUrl);
                                            startActivity(netBankingContent);
                                        }

                                    }else if (!status.equals("failed") && paymentData.equalsIgnoreCase("")){
                                        //
                                        mBundle = new Bundle();
                                        mBundle.putString("type","failed");
                                        mBundle.putString("title","Couldn't proceed with the payment");
                                        mBundle.putBoolean("lottie",true);
                                        mBundle.putString("mode", paymentMode);
                                        mBundle.putString("message",getString(R.string.txt_bse_failed_order_message));
                                        popupSuccessOrFailed(mBundle);
                                    }else {
                                        // old screen failed
                                        mBundle = new Bundle();
                                        mBundle.putString("bseid", mBseId);
//                                    mBundle.putString("payNowOptionType", mPayNowOption);
                                        mBundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                        mBundle.putString("fundName", mFundName);
                                        mBundle.putBoolean("isOtpValidated", true);
                                        mBundle.putString("amount", mEtAmount.getText().toString().trim());
                                        Intent intent = new Intent(requireActivity(), BseOrderStatusActivity.class);
                                        intent.putExtras(mBundle);
                                        startActivity(intent);
                                    }

                                }else {
                                    // not validated
                                    showOTPAuth(
                                            true,
                                            mPlaceOderResponseObj.optString("provisionalOrderid"),
                                            paymentDetails,
                                            paymentMode,
                                            loopBackUrl
                                    );
                                }

                            }
                        }else {
                            Bundle bundle = new Bundle();
                            bundle.putString("nseInvestid", mBseId);
                            bundle.putString(
                                    "paymentMethod",
                                    paymentDetails != null
                                            ? paymentDetails.optString("paymentMethod", "payNow")
                                            : "payNow"
                            );
                            bundle.putString("payNowOptionType", mPaymentOption);
                            bundle.putString("amount", mEtAmount.getText().toString().trim());
                            mPlaceOderResponseObj.put("ClientCode", uccNumber);
                            mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));
                            bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                            bundle.putString("fundName", mFundName);
                            Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }


                    } else if (jsonObject.optInt("status") == 3) {
                        orderExistsDailog();
                    } else {
                        String message = jsonObject.optString("message");
                        appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                    }


                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void popupSuccessOrFailed( Bundle dataBunndle){
        FullScreenPaymentStatus popup = new FullScreenPaymentStatus();
        popup.setArguments(dataBunndle);
        popup.onValidateButtonClick(bundle -> {
            // show my orders
            popup.dismiss();
            Intent intent = new Intent(requireActivity(), MyOrdersActivity.class);
            startActivity(intent);
//            finish()
            return null;
        });
        popup.show(requireActivity().getSupportFragmentManager(), "FullScreenPopup");
    }

    private void showOTPAuth(
            boolean mIsIgnoreDuplicate,
            String mProvisionalOrderid,
            JSONObject mPaymentDetails,
            String mMode,
            String mLoopbackUrl
    ){
        popup = new FullScreenBsePopUpDialog();
        Bundle bundle = new Bundle();
        bundle.putString("profileData",profileObject.toString());
        bundle.putString("purchaseType","Additional");
        bundle.putString("funname",mSchemeName);
        bundle.putBoolean("ispurchase",false);
        bundle.putString("mProvisionalOrderid", mProvisionalOrderid);
        bundle.putString("mode", mMode);
        popup.setArguments(bundle);
        popup.onValidateButtonClick(new Function1<Bundle, Unit>() {
            @Override
            public Unit invoke(Bundle bundle) {
                // place order by otp
                try {

                    // place order by otp
                    String mOtp = bundle.getString("otp");
                    placePurchageOrder(
                            mIsIgnoreDuplicate,
                            mOtp,
                            true,
                            mProvisionalOrderid,
                            mMode,
                            mLoopbackUrl,
                            mPaymentDetails,
                            false
                    );

                   /* bundle.putString("bseid", mBseId);
                    bundle.putString("payNowOptionType", mPaymentOption);
                    bundle.putBoolean("isOtpValidated", true);
                    bundle.putString("amount", mEtAmount.getText().toString().trim());
                    mPlaceOderResponseObj.put("ClientCode", mOldJsonObject.optString("uccNumber"));
                    mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));
                    bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                    bundle.putString("fundName", mFundName);
                    Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);*/
                } catch (Exception e) {}

                return null;
            }
        });
        popup.show(requireActivity().getSupportFragmentManager(),"FullScreenPopup");
    }

    private void getBankList() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        String url = "";
        try {
            if (!isNse2){
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_BSEID + "arnid=" + mOldJsonObject.optString("lastTxnArnid")
                    + "&uccNumber=" + uccNumber +
                    "&appid=" + mOldJsonObject.optString("appid");
            }else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_NSE2_BANKS
                        + "nseInvestid=" + mBseId +"investorUid="+Utils.getSelectedUid(mSession);
            }
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }


        String finalUrl = url+"&selectedUser="+Utils.getSelectedUserObject(mSession);
        finalUrl = setRefreshKeyInExistingApi(finalUrl, mSession);
        String finalUrl1 = finalUrl;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, finalUrl,
                response -> {
                    insertApiData(finalUrl1, "GET REQ CONTAINS URL IN REQ", response,
                            TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_BSEID);

                    mBar.dismiss();

                    System.out.println();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("status") == 0) {
                            JSONArray bankArray =null;
                            if (!isNse2){
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.getJSONArray("data");
                                JSONObject mBseObject = jsonArray.optJSONObject(0);
                                mBseId = mBseObject.optString("bseid");
                                bankArray = mBseObject.getJSONArray("banks");
                            }else {
                                JSONArray resultArray = jsonObject.getJSONArray("result");
                                JSONObject firstItem = resultArray.getJSONObject(0);
                                mBseId = firstItem.optString("nseInvestid");
                                //bankDetails
                                bankArray = firstItem.getJSONArray("bankDetails");
                            }

                            mBankList = new ArrayList<>();
                            if (bankArray.length() > 0) {
                                for (int i = 0; i < bankArray.length(); i++) {
                                    JSONObject bankObject1 = bankArray.optJSONObject(i);
                                    mBankList.add(bankObject1);
                                }
                            }

                            if (mBankList.size() > 0) {
                                mBankAdapter.updateList(mBankList, "bankBSE");
                            } else {
                                JSONObject jsonObject2 = new JSONObject();
                                mBankList.add(jsonObject2);
                                mBankAdapter.updateList(mBankList, "bankBSE");
                            }

                        }

                    } catch (Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getMandateList(String bseID) {
        if (hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")) {
            return;
        }
        String url = "";
        try {

            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, 40);
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
            String date = simpleDateFormat.format(cal.getTime());
            if (!isNse2) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_MANDATE_LIST + "bseid=" + bseID
                        + "&paymentDate=" + date + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else {
                /*url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_MANDATE_NSE2_LIST + "nseInvestid=" + bseID
                        + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);*/
                String marnId ="";
                if (mSession.getLoginType().equals("broker")) {
                    if (mJsonARNList!=null){
                        try {
                            if (mJsonARNList.size() == 1) {
                                JSONObject folioObject = mJsonARNList.get(0);
                                marnId = folioObject.optString("arnid");
                            } else {
                                int position = mSpArn.getSelectedItemPosition();
                                if (position == 0)
                                    marnId ="";
                                else {
                                    try {
                                        JSONObject folioObject = mJsonARNList.get(position - 1);
                                        marnId = folioObject.optString("arnid");
                                    } catch (Exception e) {
                                        marnId ="";
                                    }
                                }
                            }
                        } catch (Exception e) {
                            marnId="";
                        }

                    }else{
                        marnId ="";
                    }

                }else {
                    marnId ="";
                }

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_PREPARE_ORDER_DATA_NSE2 + "nseInvestid=" + bseID+"&nseUccCode="+nseUccCode+"&schid="+mSchemeId+"&txnType=ADDITIONAL"
                        + "&approvedMandates=false&getBanks=true&arnid="+marnId+"&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            }
            url = setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }

        String finalUrl = url;

        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {
                    @Override
                    public void onSuccess(String response, int statusCode) {
                        insertApiData(finalUrl, "GET REQUEST IN BODY OF URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),
                                Config.GET_MANDATE_LIST);
                        try {
                            if (mMandateList != null) {
                                mMandateList.clear();
                            }

                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject != null) {
                                int status = jsonObject.optInt("status");
                                if (status == 0) {
                                    JSONObject result = jsonObject.optJSONObject("result");
                                    if (result != null) {
                                        //  profile → memberCode
                                        JSONObject profile = result.optJSONObject("profile");
                                        if (profile != null) {
                                            mSelectedMemberCode = profile.optString("memberCode", "");
                                        } else {
                                            mSelectedMemberCode = "";
                                        }

                                        // bankDetails
                                        JSONArray bankArray = result.optJSONArray("bankDetails");
                                        mBankList = new ArrayList<>();

                                        if (bankArray != null) {
                                            for (int i = 0; i < bankArray.length(); i++) {
                                                JSONObject obj = bankArray.optJSONObject(i);
                                                if (obj != null && obj.length() > 0) {
                                                    mBankList.add(obj);
                                                }
                                            }
                                        }

                                        // mandates
                                        JSONArray mandateArray;
                                        if(isNse2){
                                            mandateArray =result.optJSONArray("mandates");
                                        } else {
                                            mandateArray =result.optJSONArray("data");
                                        }
                                        mMandateList = new ArrayList<>();

                                        if (mandateArray != null) {
                                            for (int i = 0; i < mandateArray.length(); i++) {
                                                JSONObject obj = mandateArray.optJSONObject(i);
                                                if (obj != null && obj.length() > 0) {
                                                    mMandateList.add(obj);
                                                }
                                            }
                                        }
                                    }
                                    // Update adapter
                                    if (mMandateList.isEmpty()) {
                                        mMandateList = new ArrayList<>();
                                        mMandateList.add(new JSONObject());
                                        mMandateAdapter.updateList(mMandateList, "NoMandate");
                                    } else {
                                        mMandateAdapter.updateList(mMandateList, "MandateBse");
                                    }
//                                    showHideBrokerPlace(true);
                                } else if (status == -1) {
//                                    showHideBrokerPlace(false);

                                    String message = jsonObject.optString("message", "");

                                    if (mAppplication != null) {
                                        mAppplication.showCommonDailog(
                                                requireActivity(),
                                                "Failed",
                                                message,
                                                "message"
                                        );
                                    }

                                }
                            }

                        } catch (Exception ignore) {
                        }

                    }

                    @Override
                    public void onLoading(boolean isLoading) {
                        KtorCallBack.super.onLoading(isLoading);
                        if (isLoading){
                            ProgressBarCommon.showDialog(requireActivity());
                        }else{
                            ProgressBarCommon.dismissDialog();
                        }
                    }
                }
        );
    }

    private void showHideBrokerPlace(boolean isShow) {
        transact_btn.setVisibility(isShow ? View.VISIBLE : View.GONE);
        tvCart.setVisibility(isShow ? View.VISIBLE : View.GONE);
    }

    private void getSchemes(String fundId) {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {

            String varableForBSeMfu ="";
            if(isNse2) varableForBSeMfu ="&hasNseInvestCode=true"; else varableForBSeMfu ="&hasBseCode=true";

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_FUND_SCHEAMES + "fundid=" + fundId + "&exchange="+mExchange +varableForBSeMfu
                    + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = setRefreshKeyInExistingApi(url, mSession);
         /*   if (exchange.equals("3")) {
                url = url + "&hasMfuCode=true";
            }
*/

            /*https://spvithlani.investwell.app/webapi/client/investOnline/getFundSchemes?
            fundid=e09e7bff22c4a6cb67d00b399ecadedf&exchange=2&investorUid=67c025d3f470b
            86011712f7f974d669d&selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","
            levelNo":"100"}*/
        } catch (Exception e) {

        }


        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl, "GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_FUND_SCHEAMES);
                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.getJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    mSchemeList.add(jsonArray.optJSONObject(i));
                                }
                                showSchemesDailog();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getAllTransectionTypes() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        try {
            String nseBseCode = "";
            if (isNse2){
                nseBseCode ="&hasNseInvestCode=true";
            }else {
                nseBseCode="&hasBseCode=true";
            }
            String schemeId = Utils.getSchemeIdFromAll(mObjNewScheme);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_TRANSECTION_TYPE + "schid=" + schemeId+nseBseCode+
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession)+ "&bid=" + mSession.getBid() +
                    "&levelid=" + mSession.getLevelId();
            url = setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");


            /*https://spvithlani.investwell.app/webapi/client/investOnline/getSchemeNSEInfo?
            schid=9e539c7cf67bc5232e1e40581ba682ee
            &hasBseCode=true
            &bid=
            a14223ec0adf09805f758441c455d58a
            &levelid=7ecb1293761347d78cf6b8f857435249
            &investorUid=67c025d3f470b86011712f7f974d669d&selectedUser=
            {"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/

        } catch (Exception e) {

        }


        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl, "GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_TRANSECTION_TYPE);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                tranJsonObject = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = tranJsonObject.getJSONArray("allowedInvestmentTypes");
                                if (jsonArray.toString().contains(mTransactionType)) {

                                    mTvcardview_top_name_color.setText(mObjNewScheme.optString("name"));
                                    mSchemeId = mObjNewScheme.optString("schid");
                                } else {
                                    mObjNewScheme = null;
                                    showErrorDailog();
                                }

                            } else if (jsonObject.optInt("status") == -1) {

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void showErrorDailog() {
        CustomDialog customDialog = new CustomDialog(new CustomDialog.DialogBtnCallBack() {
            @Override
            public void onDialogBtnClick(View view) {
                if (view.getId() == R.id.btDone) {
                        //  mActivity.getSupportFragmentManager().popBackStack();
}
else if (view.getId() == R.id.btCalcel) {
}
            }
        });

        customDialog.showDialog(mActivity, getString(R.string.alert_dialog_error_txt),
                getString(R.string.alert_dialog_message_purchase_not_allowed),
                getString(R.string.alert_dialog_btn_txt),
                "",
                true, false);
    }


    private void getArnList(Runnable onComplete) {
        if (hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "investOnline");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ARN_LIST_NSE + "exchange="+mExchange+
                    "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

          /*  https://spvithlani.investwell.app/webapi/client/getArns?
            // exchange=2&investorUid=67c025d3f470b86011712f7f974d669d
            // &selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/
            url = setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mBar.dismiss();

                        mJsonARNList = new ArrayList<>();
                        ArrayList<String> arnList = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    arnList.add(jsonObject1.optString("arnNo"));
                                    mJsonARNList.add(jsonObject1);
                                }
                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(getActivity(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {

                        } finally {
                            if (mJsonARNList.size() > 1) {
                                mLlArn.setVisibility(View.VISIBLE);
                                setArnList(arnList);
                            }else{
                                mLlArn.setVisibility(View.GONE);
                            }
                            onComplete.run();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar !=null) mBar.dismiss();
                        onComplete.run();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }




    private void setArnList(List<String> list) {
        try {
            list.add(0, getString(R.string.select_arn_2));
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpArn.setAdapter(dataAdapter);
            mSpArn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                    if (isNse2 && i != 0){
                        getMandateList(mBseId);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
            //                             getMandateList(mNseInvestId)

        } catch (Exception e) {

        }
    }



    private void showSchemesDailog() {
        final Dialog dialog = new Dialog(mActivity);
        dialog.setContentView(R.layout.change_scheme);
        final Spinner mSchemeSpinner = dialog.findViewById(R.id.scheme);
        Button mSubmitBtn = dialog.findViewById(R.id.submit_btn);

        ArrayList<String> list = new ArrayList<>();
        list.add(0, getString(R.string.select_scheme));
        for (int i = 0; i < mSchemeList.size(); i++) {
            JSONObject jsonObject = mSchemeList.get(i);
            String data = jsonObject.optString("name");
            list.add(data);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        mSchemeSpinner.setAdapter(dataAdapter);
        mSchemeSpinner.setSelection(0);
        mSchemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int selectedPostion, long l) {
                if (selectedPostion > 0) {
                    mObjNewScheme = mSchemeList.get(selectedPostion - 1);

                    isSchemeChanged = !mObjNewScheme.optString("schid").equals(defaultSchemeId);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mObjNewScheme != null) {
                    mSchemeGroupId = mObjNewScheme.optString("schemeGroupId");
                    getInvestmentType();
                    getAllTransectionTypes();
                    applyDefaultButtonState();
                }

                dialog.dismiss();
            }
        });


        dialog.findViewById(R.id.close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
    }

    private void setPaymentOption() {
        try {
            List<String> list = new ArrayList<>();
            list.add(getString(R.string.select_payment_options));
            list.add("Mandate");
            list.add("Net Banking");
            list.add("NEFT/RTGS");
            list.add("UPI");


            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mspPayNowOptions.setAdapter(dataAdapter);
            mspPayNowOptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    if (position == 1) {
                        if (mPaymentOption.equalsIgnoreCase("payNow")) {
                            mLinerMandateList.setVisibility(View.VISIBLE);
                            rlMandateTitle.setVisibility(View.VISIBLE);

                            mLLBankList.setVisibility(View.GONE);
                        } else {
                            mLinerMandateList.setVisibility(View.GONE);
                            mLLBankList.setVisibility(View.GONE);
                            rlMandateTitle.setVisibility(View.VISIBLE);

                        }
                    } else {
                        if (position >0) {
                            if (mPaymentOption.equalsIgnoreCase("payNow")) {
                                mLLBankList.setVisibility(View.VISIBLE);
                                mLinerMandateList.setVisibility(View.GONE);
                                rlMandateTitle.setVisibility(View.VISIBLE);

                            } else {
                                mLLBankList.setVisibility(View.GONE);
                                mLinerMandateList.setVisibility(View.GONE);
                                rlMandateTitle.setVisibility(View.VISIBLE);

                            }
                        }
                    }


                    if (position == 3) {
                        mllUpiNeftField.setVisibility(View.VISIBLE);
                        tvUpiNeftLavel.setText("NEFT");
                        etUPI.setHint("NEFT Reference number");
                    } else if (position == 4) {
                        mllUpiNeftField.setVisibility(View.VISIBLE);
                        tvUpiNeftLavel.setText("UPI");
                        etUPI.setHint("UPI ID");
                    } else {
                        mllUpiNeftField.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

        } catch (Exception e) {

        }
    }


    @Override
    public void onDataReturned(@Nullable Bundle resultBundle) {
        //
        try {
//            val mOtp =resultBundle?.getString("otp")!!
            String mOrderId =resultBundle.getString("orderid");
            String loopbackUrl =resultBundle.getString("loopbackUrl");
            String mode =resultBundle.getString("mode");
            mPaymentMode = mode;
            JSONObject paymentDetails = new JSONObject(resultBundle.getString("paymentDetails"));

            bottomPaymentMode.dismiss();


            placePurchageOrder(
                     true,
                    "",
                    false,
                    "",
                    mode,
                    loopbackUrl,
                    paymentDetails,
                    false
            );

        }catch (Exception e){}
    }

    private void insertTxnInNseOrBseCart() {
        ProgressBarCommon.showDialog(mActivity);

        JSONObject objectMain = new JSONObject();
        try {
            objectMain.put("type", "purchase"); // static
            if(isNse2 )
                objectMain.put("exchange", "4");
            else
                objectMain.put("exchange", "2");
            objectMain.put("subType", "NRP");
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));

            JSONObject itemObject = getNseOrBseItemObject();
            objectMain.put("item", itemObject);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.INSERT_NSE_BSE_CART_ITEM;

        new ApiClient(mActivity, mSession).makeJsonPostRequest(
                url,
                objectMain,
                it -> {
                    if (it) {
                        ProgressBarCommon.showDialog(mActivity);
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                },
                response -> {
                    try {
                        if (response.optInt("status") == 0) {
                            addToCartBtnClicked();
                            Toast.makeText(mActivity,getString(R.string.added_successfully), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mActivity,response.optString("message"),Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception ignored) {
                    }
                    return null;
                },
                error -> {
                    UtilityKotlin.parseVolleyError(error, mSession, mActivity, "");
                    return null;
                },
                code -> {
                    if (code == 401) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(
                                mActivity,
                                getString(R.string.txt_session_expired),
                                getString(R.string.txt_please_login_again_for_continue),
                                "sessionExpired"
                        );
                    }
                    return null;
                }
        );
    }
    private JSONObject getNseOrBseItemObject() {
        JSONObject itemObject = new JSONObject();

        try {
            // Folio
            itemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            itemObject.put("folioid", mOldJsonObject.optString("folioid"));
            itemObject.put("txnType", "ADDITIONAL");
            if(isNse2) {
                itemObject.put("nseInvestid", mBseId);
                itemObject.put("nseUccCode", nseUccCode);
            }
            else{
                itemObject.put("uccNumber", uccNumber);
                itemObject.put("bseid", mBseId);
            }
            // ARN handling
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    itemObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        itemObject.put("arnid", "");
                    else {
                        String marnId="";
                        try {
                            JSONObject folioObject = mJsonARNList.get(position - 1);
                            marnId = folioObject.optString("arnid");
                        } catch (Exception e) {
                            marnId ="";
                        }
                        itemObject.put("arnid", marnId);
                    }
                }
            }else {
                itemObject.put("arnid", "");
            }
            itemObject.put("investmentType", mSchemeType);

            if (llDividentFreqSip.getVisibility() == View.VISIBLE) {
                itemObject.put("divFrequency",  String.valueOf(spDivedentFrequencySip.getSelectedItemPosition()));
            }

            itemObject.put("schid", mSchemeId);
            itemObject.put("schemeName", mSchemeName);
            itemObject.put("amount", mEtAmount.getText().toString());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return itemObject;
    }

    private void addToCartBtnClicked() {
        Utils.hideKeyboard(mActivity);

        if (tvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {

            transact_btn.setVisibility(View.GONE);
            tvCart.setText(getString(R.string.go_to_cart));

        } else {
            transact_btn.setVisibility(View.VISIBLE);
            tvCart.setText(getString(R.string.add_to_cart));
        }
    }

    private void transactNowBtnClicked() {
        Utils.hideKeyboard(requireActivity());

        if (transact_btn.getText().toString().equalsIgnoreCase(getString(R.string.TransactNow))) {

            tvCart.setVisibility(View.GONE);
            llPaymentOptions.setVisibility(View.VISIBLE);
            transact_btn.setText(getString(R.string.Choose_Payment_Mode));

        } else if (transact_btn.getText().toString().equalsIgnoreCase(getString(R.string.Choose_Payment_Mode))) {

            boolean isLinkOnEmailChecked = rgPaymentOptions.getCheckedRadioButtonId() == R.id.rbLinkOnEmail;

                Bundle bundle = new Bundle();
                bundle.putString("mBseId", mBseId);
                bundle.putBoolean("isLinkOnEmailSelected", isLinkOnEmailChecked);

                bottomPaymentMode = BottomScreenPaymentMode.create(requireActivity(), R.style.ModalBottomSheetDialog, bundle);
                mEtAmount.clearFocus();
                bottomPaymentMode.setListener(this);
                bottomPaymentMode.show();

        } else {
            if (isAddToCartBseEnabled) {
                tvCart.setVisibility(View.VISIBLE);
                llPaymentOptions.setVisibility(View.GONE);
                transact_btn.setText(getString(R.string.TransactNow));
            }
        }
    }

    private void applyDefaultButtonState() {
        isAddToCartNseInvestEnabled = checkFeaturePermissionsOnOff(mSession, "feature1053", Permissions.ADD);
        isAddToCartBseEnabled = checkFeaturePermissionsOnOff(mSession, "feature1043", Permissions.ADD);

        transact_btn.setVisibility(View.VISIBLE);
        setTextOfPaymentButton();

        boolean visible = (isNse2 && isAddToCartNseInvestEnabled) || (!isNse2 && mSession.getShowBseAuthPopup() && isAddToCartBseEnabled);
        tvCart.setVisibility(visible ? View.VISIBLE : View.GONE);
        tvCart.setText(getString(R.string.add_to_cart));

        llPaymentOptions.setVisibility(View.GONE);
        rgPaymentOptions.clearCheck();
    }

    private void setTextOfPaymentButton() {

        if (!isNse2 && mSession.getShowBseAuthPopup()) {
            if (mSession.getLoginType().equals("broker"))
                transact_btn.setText(getString(R.string.TransactNow));
            else
                transact_btn.setText(getString(R.string.Choose_Payment_Mode));

        } else
            transact_btn.setText(getString(R.string.place_order));
    }




}






