package investwell.client.fragments.mydoc;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.client.activity.ClientActivity;

/**
 * Created by binesh on 8/5/18.
 */

public class FragDocumentFolderAdapter extends RecyclerView.Adapter<FragDocumentFolderAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;

    public FragDocumentFolderAdapter(Context context,  ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_my_document, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        ImageView ivAdd;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);
                tvName.setText(jsonObject.optString("name"));

                ivAdd.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        ClientActivity clientActivity = (ClientActivity) mContext;
                        Bundle bundle = new Bundle();
                        bundle.putString("uid", jsonObject.optString("uid"));
                        clientActivity.displayViewOther(80, bundle);
                    }
                });


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
