package investwell.client.fragments.others;

import static investwell.utils.ExtensionsKt.convertDateTimeToDDMMYYYYWithoutTimeZone;
import static investwell.utils.ExtensionsKt.formatDateToYYYYMMDD;
import static investwell.utils.ExtensionsKt.getCurrentDateInFormat;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragMyOrderAdapter;
import investwell.utils.AppSession;
import investwell.utils.Config;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragMyOrders extends BaseFragment implements View.OnClickListener {
    private RecyclerView mRecyclerView;
    private ShimmerFrameLayout mShimmerViewContainer;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private boolean loading = false;
    private int mCurrentPageNo = 0;
    private LinearLayout fullScreenShedow, linerUsers;
    private FloatingActionButton mFilterIcon;
    private boolean isClickedApply = false;
    private RelativeLayout mRelFilterMain;
    private RelativeLayout singleShedow;
    private AppSession mSession;
    private int mMonthCount = 0;
    private String mStartingDate = "", mEndDate = "";
    private LinearLayout mLinFilterPart, mLinerCustomDuration, mLinerNoDataFound;
    private Animation slideUpAnimation, slideDownAnimation;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private FragMyOrderAdapter mAdapter;
    private TextView mTvStartDate, mTvEndDate, filterTitle;
    private boolean mIsFirstTime = true;
    private RadioGroup radioGroup;

    private Spinner mMemberSpinner, mSpUserType;
    private LinearLayout mLinerUserType, mLinerUsers;
    private List<JSONObject> mMemberList, mMemberTypesList;
    private int mSelectedPosition = 0, mSelectedUserTypePosition = 0, mSelectedTransType;
    private String mType = "system_orders";
    private boolean hasBrokerOrders = false;


    public FragMyOrders() {
        // Required empty public constructor
    }

    @Override
    public void onResume() {
        super.onResume();
   /*     if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.frag_my_orders, container, false);
        mRecyclerView = view.findViewById(R.id.recycleView);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mFilterIcon = view.findViewById(R.id.filters);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mLinerCustomDuration = view.findViewById(R.id.linerCustomDuration);
        mLinerCustomDuration.setVisibility(View.GONE);

        mMemberSpinner = view.findViewById(R.id.member_spinner);
        mSpUserType = view.findViewById(R.id.spUserType);
        mLinerUserType = view.findViewById(R.id.linerUserType);
        mLinerUsers = view.findViewById(R.id.linerUsers);

        mTvStartDate = view.findViewById(R.id.tvSTart);
        mTvEndDate = view.findViewById(R.id.tvEnd);
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        mFilterIcon.setOnClickListener(this);
        filterTitle = view.findViewById(R.id.filterTitle);
        filterTitle.setText(getString(R.string.txt_order_duration));

        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);
        mFilterIcon.setOnClickListener(this);
        mTvStartDate.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);
        radioGroup = view.findViewById(R.id.rdGroup);

        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("type")) {
            mType = bundle.getString("type");
            hasBrokerOrders = true;
        }else{
            hasBrokerOrders = false;
        }
        setUpToolBar();



        dateCalculation("default");
//        mTvLoading = view.findViewById(R.id.tvLoading);
//        mTvLoading.setVisibility(View.GONE);
        slideUpAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_down);
        mRecyclerView.setNestedScrollingEnabled(true);
        mAdapter = new FragMyOrderAdapter(new ArrayList<JSONObject>(), getContext());
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);

        if (mMainActivity != null)
            mMainActivity.setMainVisibility(this, null);
        else
            mBrokerActivity.setMainVisibility(this, null);

        mRecyclerView.setAdapter(mAdapter);

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 50;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getMyOrder(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        RadioGroup radioGroup = view.findViewById(R.id.rdGroup);
        // radioGroup.check(R.id.radio1);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                mLinerCustomDuration.setVisibility(View.GONE);
                int position = radioGroup.indexOfChild(view.findViewById(i));
                switch (position) {
                    case 0:
                        dateCalculation("currentMonth");
                        break;

                    case 1:
                        dateCalculation("prevMonth");
                        break;

                    case 2:
                        dateCalculation("currentYear");
                       /* String year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
                        mStartingDate = year + "-01-01";
                        mEndDate = year + "-12-31";*/
                        break;

                    case 3:
                        dateCalculation("custom");
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                }

            }


        });

        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);
              /*  if (!call_from.equals("broker_menu")) {
                    mActivity.mCvTabBarBottom.setVisibility(View.VISIBLE);
                } else {
                    mActivity.mCvTabBarBottom.setVisibility(View.GONE);
                }*/

                mFilterIcon.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            if (mSession.getClientObject().isEmpty()) {
                mLinerUserType.setVisibility(View.VISIBLE);
                mLinerUsers.setVisibility(View.VISIBLE);
                setSpinnerMemberType();
            } else {
                mLinerUserType.setVisibility(View.GONE);
                mLinerUsers.setVisibility(View.VISIBLE);
                getAllMembers("client");
            }
        } else {
            mLinerUserType.setVisibility(View.GONE);
            mLinerUsers.setVisibility(View.VISIBLE);
            getAllMembers("client");
        }

        getMyOrder(1);

        return view;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.filters) {
                mFilterIcon.setVisibility(View.GONE);
                mRelFilterMain.setVisibility(View.VISIBLE);
                mLinFilterPart.startAnimation(slideUpAnimation);
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                filterValidation();
}
else if (v.getId() == R.id.tvSTart) {
//                datePicker(true);
                showDatePickerDialog(
                        requireContext(),
                        this,
                        null,
                        mTvEndDate.getText().toString(),
                        mTvStartDate.getText().toString(),
                        inputFormat,
                        selectedDateFormatted -> {
                            try {
                                Date parsed = outputFormat.parse(selectedDateFormatted);
                                String apiDate = formatDateToYYYYMMDD(selectedDateFormatted);

                                mTvStartDate.setText(selectedDateFormatted);
                                mStartingDate = apiDate;

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            return null;
                        });
}
else if (v.getId() == R.id.tvEnd) {
//                datePicker(false);
                showDatePickerDialog(
                        requireContext(),
                        this,
                        mTvStartDate.getText().toString(),
                        getCurrentDateInFormat(inputFormat),
                        mTvEndDate.getText().toString(),
                        inputFormat,
                        selectedDateFormatted -> {

                            try {
                                Date parsed = outputFormat.parse(selectedDateFormatted);
                                String apiDate = formatDateToYYYYMMDD(selectedDateFormatted);

                                mTvEndDate.setText(selectedDateFormatted);
                                mEndDate = apiDate;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            return null;
                        });
}
else if (v.getId() == R.id.ivLeft) {
                getActivity().getSupportFragmentManager().popBackStack();
}
    }

    private void filterValidation() {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));

            // get selected radio button from radioGroup
            int selectedId = radioGroup.getCheckedRadioButtonId();
            if (selectedId == R.id.radio4) {
                Date date1 = formatter.parse(mStartingDate);
                Date date2 = formatter.parse(mEndDate);
                if (System.currentTimeMillis() < date1.getTime()) {
                    Toast.makeText(getActivity(), getString(R.string.invalid_start_date), Toast.LENGTH_SHORT).show();
                } else if (System.currentTimeMillis() < date2.getTime()) {
                    Toast.makeText(getActivity(), getString(R.string.invalid_end_date), Toast.LENGTH_SHORT).show();
                } else if (date1.getTime() > date2.getTime()) {
                    Toast.makeText(getActivity(), getString(R.string.please_check_start_date_and_end_date), Toast.LENGTH_SHORT).show();
                } else {
                    mLinFilterPart.startAnimation(slideDownAnimation);
                    isClickedApply = true;
                    getMyOrder(1);
                }
            } else {
                mLinFilterPart.startAnimation(slideDownAnimation);
                isClickedApply = true;
                getMyOrder(1);
            }


        } catch (ParseException e1) {
            e1.printStackTrace();
        }


    }


    private void getMyOrder(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        } else {
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";
        String uId = "";
        String levelNo = "";

        try {


            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "myOrderTable");

            JSONArray jsonArray = new JSONArray();
            JSONObject fromObject = new JSONObject();
            fromObject.put("fromDate", mStartingDate);
            jsonArray.put(fromObject);

            JSONObject toDateObject = new JSONObject();
            toDateObject.put("toDate", mEndDate);
            jsonArray.put(toDateObject);

            JSONObject investorObject = new JSONObject();
            if (mSelectedPosition != 0) {
                JSONObject jsonObject = mMemberList.get(mSelectedPosition - 1);
                investorObject.put("levelNo", jsonObject.optString("levelNo"));
                uId = jsonObject.optString("uid");
                investorObject.put("uid", uId);

                JSONObject selectedOject = new JSONObject();
                selectedOject.put("selectedUser", investorObject);
                jsonArray.put(selectedOject);

            } else {
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    if (mSession.getClientObject().isEmpty()) {
                        uId = mSession.getUid();
                        levelNo = mSession.getLevelNo();
                    } else {
                        uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                        levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                    }
                } else {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                }
                investorObject.put("uid", uId);
                investorObject.put("levelNo", levelNo);
            }


            String varableForBSeMfu = "";
            String exchange = Utils.getSelectedExchange(mSession);

            if (exchange.equalsIgnoreCase("1")) {
                exchange = "1";
            } else if (exchange.equalsIgnoreCase("2")) {
                exchange = "2";
                varableForBSeMfu = "&hasBseCode=true";
            } else if (exchange.equalsIgnoreCase("3")) {
                exchange = "3";
                varableForBSeMfu = "&hasMfuCode=true";
            }else if (exchange.equalsIgnoreCase("4")) {
                exchange = "4";
                varableForBSeMfu = "&hasNseInvestCode=true";
            }


            if (mSession.getLoginType().equals("broker")) {
                if (mSession.getClientObject().isEmpty()) {

                    if(mType.equalsIgnoreCase("all_orders")){
                        url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                                Config.GET_MY_ORDER_BROKER + "currentPage=" + pageNo + "&pageSize=50" + "&orderBy=updatedAt" +
                                "&orderByDesc=true" + "&exchange=" + exchange + varableForBSeMfu + "&allOrders=" +true+
                                "&filters=" + jsonArray ;
                    }else{
                        url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                                Config.GET_MY_ORDER_BROKER + "currentPage=" + pageNo + "&pageSize=50" + "&orderBy=updatedAt" +
                                "&orderByDesc=true" + "&exchange=" + exchange + varableForBSeMfu +
                                "&filters=" + jsonArray ;
                    }


                } else {
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                            Config.GET_MY_ORDER_CLIENT + "currentPage=" + pageNo + "&pageSize=50" + "&orderBy=updatedAt" +
                            "&orderByDesc=true" + "&exchange=" + exchange + varableForBSeMfu +
                            "&filters=" + jsonArray + "&investorUid=" + uId + "&selectedUser="
                            + investorObject.toString();
                }
            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.GET_MY_ORDER_CLIENT + "currentPage=" + pageNo + "&pageSize=50" + "&orderBy=updatedAt" +
                        "&orderByDesc=true" + "&exchange=" + exchange + varableForBSeMfu +
                        "&filters=" + jsonArray + "&investorUid=" + uId + "&selectedUser="
                        + investorObject.toString();
            }

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            System.out.println();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading = false;
                        List<JSONObject> list = new ArrayList<>();
                        if (pageNo > 1) {
                            list.addAll(mAdapter.mDataList);
                        }
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mAdapter.updateList(list, "");
                                mLinerNoDataFound.setVisibility(View.GONE);
//                                mTvLoading.setVisibility(View.GONE);
                            } else {
                                mAdapter.updateList(new ArrayList<JSONObject>(), "");
                                mLinerNoDataFound.setVisibility(View.VISIBLE);
//                                mTvLoading.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.txt_Myorder),
                    true, false, false, false, false, false, false);
        }
        if (hasBrokerOrders){
            fragToolBar.getView().setVisibility(View.GONE);
        }
    }

    private void dateCalculation(String durationType) {
        int mMonth = 0;
        int mDay = 0;
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy");
        if (durationType.equals("default")) {
            Date todayDate = calendar1.getTime();
            mEndDate = formatter.format(todayDate);

            calendar2.add(Calendar.MONTH, -1);
            Date firstDateOfCurrentMonth = calendar2.getTime();
            mStartingDate = formatter.format(firstDateOfCurrentMonth);
        } else if (durationType.equals("currentMonth")) {
            Date todayDate = calendar1.getTime();
            mEndDate = formatter.format(todayDate);

            calendar2.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfCurrentMonth = calendar2.getTime();
            mStartingDate = formatter.format(firstDateOfCurrentMonth);
        } else if (durationType.equals("prevMonth")) {
            calendar1.add(Calendar.MONTH, -1);
            calendar1.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfPreviousMonth = calendar1.getTime();
            mStartingDate = formatter.format(firstDateOfPreviousMonth);

            calendar2.add(Calendar.MONTH, -1);
            calendar2.set(Calendar.DATE, calendar2.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date lastDateOfPreviousMonth = calendar2.getTime();
            mEndDate = formatter.format(lastDateOfPreviousMonth);
        } else if (durationType.equals("currentYear")) {
            // Date date = new Date();
            // calendar1.setTime(date);
            calendar1.set(Calendar.MONTH, 0);
            calendar1.set(Calendar.DAY_OF_MONTH, 1);
            Date yearStartDate = calendar1.getTime();
            mStartingDate = formatter.format(yearStartDate);

            Date todayDate = calendar2.getTime();
            mEndDate = formatter.format(todayDate);
        } else {
            calendar1.add(Calendar.MONTH, -1);
            calendar1.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfPreviousMonth = calendar1.getTime();
            mStartingDate = formatter.format(firstDateOfPreviousMonth);

            calendar2.add(Calendar.MONTH, -1);
            calendar2.set(Calendar.DATE, calendar2.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date lastDateOfPreviousMonth = calendar2.getTime();
            mEndDate = formatter.format(lastDateOfPreviousMonth);


            mTvStartDate.setText(convertDateTimeToDDMMYYYYWithoutTimeZone(mStartingDate));
            mTvEndDate.setText(convertDateTimeToDDMMYYYYWithoutTimeZone(mEndDate));

        }

    }
    SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());


    private void datePicker(final boolean isStartDate) {
//        Calendar c = Calendar.getInstance();
//        int mYear = c.get(Calendar.YEAR);
//        int mMonth = c.get(Calendar.MONTH);
//        int mDay = c.get(Calendar.DAY_OF_MONTH);
//        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), (view, year, monthOfYear, dayOfMonth) -> {
//            if (view.isShown()) {
//                NumberFormat formatter = new DecimalFormat("00");
//                String day = formatter.format((dayOfMonth));
//                String month = formatter.format((monthOfYear + 1));
//                String date_time = year + "-" + month + "-" + day;
//                String date_for_text = day + "-" + month + "-" + year;
//
//                if (isStartDate) {
//                    mTvStartDate.setText(date_for_text);
//                    mStartingDate = date_time;
//                } else {
//                    mTvEndDate.setText(date_for_text);
//                    mEndDate = date_time;
//                }
//            }
//
//        }, mYear, mMonth, mDay);
//        datePickerDialog.show();

        showDatePickerDialog(
                requireContext(),
                this,
                null,
                null,
                null,
                inputFormat,
                outputFormat,
                selectedDateFormatted -> {


                    try {
                        Date parsed = outputFormat.parse(selectedDateFormatted);
                        String apiDate = inputFormat.format(parsed);

                        if (isStartDate) {
                            mTvStartDate.setText(selectedDateFormatted);
                            mStartingDate = apiDate;
                        } else {
                            mTvEndDate.setText(selectedDateFormatted);
                            mEndDate = apiDate;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    return null;
                }
        );

    }



    private void setSpinnerMemberType() {
        try {
            mMemberTypesList = new ArrayList<>();
            List<String> listMemType = new ArrayList<>();

            JSONArray jsonArray = new JSONArray(mSession.getLowerReportingLevels());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.optJSONObject(i);
                mMemberTypesList.add(jsonObject);
                listMemType.add(jsonObject.optString("levelName"));
            }


            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMemType);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpUserType.setAdapter(adapter);
            mSpUserType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedUserTypePosition = position;
                    getAllMembers("broker");
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }


    private void setSpinnerMembers(String rawData) {
        try {
            mMemberList = new ArrayList<>();
            List<String> listMem = new ArrayList<>();
            listMem.add("All");

            JSONObject jsonObject = new JSONObject(rawData);

            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    mMemberList.add(jsonObject1);
                    listMem.add(jsonObject1.optString("name"));
                }
            } else {
                String service_msg = jsonObject.optString("message");
                Toast.makeText(getActivity(), service_msg, Toast.LENGTH_SHORT).show();
            }

            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMem);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mMemberSpinner.setAdapter(adapter);
            mMemberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedPosition = position;
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getAllMembers(String type) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";

        JSONObject jsonObject1 = new JSONObject();
        try {
            String uId = "";
            String levelNo = "";
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                if (mSession.getClientObject().isEmpty()) {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                } else {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                }

            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            jsonObject1.put("uid", uId);
            jsonObject1.put("levelNo", levelNo);

            https:
//demo.investwell.app/webapi/auth/getLevelUsers?levelNo=
            // 98&componentForLoader={"componentName":"getLevelUser"}&selectedUser={}


            if (type.equals("broker")) {
                JSONObject jsonObject = mMemberTypesList.get(mSelectedUserTypePosition);
                levelNo = jsonObject.optString("levelNo");

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_MEMBERS + "levelNo=" + levelNo +
                        "&investorUid=" + uId ;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_MEMBERS + "levelNo=" + "100" +
                        "&investorUid=" + uId+ "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        setSpinnerMembers(response);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
