package investwell.common.lock;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.iw.mint.sdk.R;
import investwell.activity.AppApplication;
import investwell.admin.activity.AdminActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static android.content.Context.KEYGUARD_SERVICE;
import static investwell.common.lock.AppLockOptionActivity.DEFAULT_LOCK_CODE;


public class FragChangeAppSecurity extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    private RadioGroup mRadioGroup;
    private RadioButton mRadio1, mRadio2, mRadio3;
    private TextView mTvChangePinDetials;
    public ToolbarFragment fragToolBar;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AdminActivity mAdminActivity;
    private AppApplication mApplication;
    private String mSelected = "";
    private ImageView mRb1, mRb2, mRb3;
    private String mClickedView="default";
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(getActivity());

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(getActivity());

        }
        else if (context instanceof AdminActivity) {
            this.mAdminActivity = (AdminActivity) context;
            mSession = AppSession.getInstance(mAdminActivity);
            mApplication = (AppApplication) mAdminActivity.getApplication();
            mSession = AppSession.getInstance(getActivity());

        }

    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.pin_text_App_Security),
                    true, false, false, false,false,false,false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_change_security, container, false);
        mSession = AppSession.getInstance(getActivity());
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        }
       else if (mMainActivity != null) {
            mMainActivity.setMainVisibility(this, null);
        }


        setUpToolBar();
        mRadioGroup = view.findViewById(R.id.radioGroup1);
        mRb1 = view.findViewById(R.id.radioButton);
        mRb2 = view.findViewById(R.id.radioButton2);
        mRb3 = view.findViewById(R.id.radioButton3);
        view.findViewById(R.id.cl_radio_1).setOnClickListener(v -> {
            mClickedView="default";
            mSelected = "default";
            updateAccessibility(view);
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock);
            mRb1.setImageResource(R.drawable.ic_check_mark_active);
            mRb2.setImageResource(R.drawable.ic_check_mark);
            mRb3.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(null);
            mRb2.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb3.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            KeyguardManager km = (KeyguardManager) getActivity().getSystemService(KEYGUARD_SERVICE);
            if (km.isKeyguardSecure()) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    Intent i = km.createConfirmDeviceCredentialIntent(getString(R.string.txt_use_your_screen_lock_pattern_to_login), "");
                    startActivityForResult(i, DEFAULT_LOCK_CODE);
                }
            }
        });
        view.findViewById(R.id.cl_radio_2).setOnClickListener(v -> {
            mClickedView="pin";
            mSelected = "pin";
            updateAccessibility(view);
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock);
            mRb1.setImageResource(R.drawable.ic_check_mark);
            mRb2.setImageResource(R.drawable.ic_check_mark_active);
            mRb3.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb2.setImageTintList(null);
            mRb3.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            onOptionLockSelected();
        });
        view.findViewById(R.id.cl_radio_3).setOnClickListener(v -> {
            mClickedView="nothing";
            mSelected = "nothing";
            updateAccessibility(view);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
            mRb3.setImageResource(R.drawable.ic_check_mark_active);
            mRb1.setImageResource(R.drawable.ic_check_mark);
            mRb2.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb2.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb3.setImageTintList(null);
            onOptionLockSelected();
        });

        view.findViewById(R.id.btnContinue).setOnClickListener(this);
      /*  mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // TODO Auto-generated method stub
                int pos;
                pos = mRadioGroup.indexOfChild(mRadioGroup.findViewById(checkedId));

                switch (pos) {
                    case 0:
                        mSelected = "default";
                        break;

                    case 2:
                        mSelected = "pin";
                        break;

                    case 4:
                        mSelected = "nothing";
                        break;
                }
            }
        });
*/
        updateView(view);
        return view;
    }
private void onOptionLockSelected(){
    if (mSelected.equalsIgnoreCase("default")) {
        KeyguardManager km = (KeyguardManager) getActivity().getSystemService(KEYGUARD_SERVICE);
        if (km.isKeyguardSecure()) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                Intent i = km.createConfirmDeviceCredentialIntent(getString(R.string.txt_use_your_screen_lock_pattern_to_login), "");
                startActivityForResult(i, DEFAULT_LOCK_CODE);
            }
        }
    } else if (mSelected.equalsIgnoreCase("pin")) {
        Intent intent2 = new Intent(getActivity(), PinLockActivity.class);
        intent2.putExtra("type", "change_pin");
        startActivityForResult(intent2, 108);
    } else if (mSelected.equalsIgnoreCase("nothing")) {
        mSession.setAppLockType(mSelected);
        if (mBrokerActivity!=null){
            mBrokerActivity.getSupportFragmentManager().popBackStack();
            mSession.setHasAppLockEnable(false);
        }else if (mAdminActivity!=null){
            mAdminActivity.getSupportFragmentManager().popBackStack();
            mSession.setHasAppLockEnable(false);
        }else{
            mMainActivity.getSupportFragmentManager().popBackStack();
            mSession.setHasAppLockEnable(false);
        }

    }
}
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnContinue) {
                if (mSelected.equalsIgnoreCase("default")) {
                    KeyguardManager km = (KeyguardManager) getActivity().getSystemService(KEYGUARD_SERVICE);
                    if (km.isKeyguardSecure()) {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                            Intent i = km.createConfirmDeviceCredentialIntent(getString(R.string.txt_use_your_screen_lock_pattern_to_login), "");
                            startActivityForResult(i, DEFAULT_LOCK_CODE);
                        }
                    }
                } else if (mSelected.equalsIgnoreCase("pin")) {
                    Intent intent2 = new Intent(getActivity(), PinLockActivity.class);
                    intent2.putExtra("type", "change_pin");
                    startActivityForResult(intent2, 108);
                } else if (mSelected.equalsIgnoreCase("nothing")) {
                    mSession.setAppLockType(mSelected);
                    if (mBrokerActivity!=null){
                        mBrokerActivity.getSupportFragmentManager().popBackStack();
                        mSession.setHasAppLockEnable(false);
                    }else if (mAdminActivity!=null){
                        mAdminActivity.getSupportFragmentManager().popBackStack();
                        mSession.setHasAppLockEnable(false);
                    }else{
                        mMainActivity.getSupportFragmentManager().popBackStack();
                        mSession.setHasAppLockEnable(false);
                    }

                }
}
    }

    private void updateView(View view) {
        if (mSession.getAppLockType().equalsIgnoreCase("default")) {
            mClickedView = "default";
            mRb1.setImageResource(R.drawable.ic_check_mark_active);
            mRb2.setImageResource(R.drawable.ic_check_mark);
            mRb3.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(null);
            mRb2.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb3.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock);
        } else if (mSession.getAppLockType().equalsIgnoreCase("pin")) {
            mClickedView = "pin";
            mRb2.setImageResource(R.drawable.ic_check_mark_active);
            mRb1.setImageResource(R.drawable.ic_check_mark);
            mRb3.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb2.setImageTintList(null);
            mRb3.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock);
        } else if (mSession.getAppLockType().equalsIgnoreCase("nothing")) {
            mClickedView = "nothing";
            mRb3.setImageResource(R.drawable.ic_check_mark_active);
            mRb1.setImageResource(R.drawable.ic_check_mark);
            mRb2.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb2.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb3.setImageTintList(null);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
        } else {
            mClickedView = "default";
            mRb3.setImageResource(R.drawable.ic_check_mark_active);
            mRb1.setImageResource(R.drawable.ic_check_mark);
            mRb2.setImageResource(R.drawable.ic_check_mark);
            mRb1.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb2.setImageTintList(ContextCompat.getColorStateList(requireContext(),R.color.icon_color));
            mRb3.setImageTintList(null);
            view.findViewById(R.id.cl_radio_3).setBackgroundResource(R.drawable.bg_screen_lock_selected);
            view.findViewById(R.id.cl_radio_2).setBackgroundResource(R.drawable.bg_screen_lock);
            view.findViewById(R.id.cl_radio_1).setBackgroundResource(R.drawable.bg_screen_lock);
        }
        updateAccessibility(view);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK && requestCode == DEFAULT_LOCK_CODE)) {
            mSession.setAppLockType(mSelected);
            mSession.setHasAppLockEnable(true);
            getActivity().getSupportFragmentManager().popBackStack();
        }else if ((resultCode == RESULT_CANCELED && requestCode == DEFAULT_LOCK_CODE)) {

        } else if ((resultCode == RESULT_CANCELED && requestCode == 108)) {

        } else if (requestCode == 108) {
            mSession.setAppLockType(mSelected);
            mSession.setHasAppLockEnable(true);
            getActivity().getSupportFragmentManager().popBackStack();
        }
    }

    private void updateAccessibility(View view) {
        applyRadioContentDescription(
                1,
                view.findViewById(R.id.cl_radio_1),
                "default",
                getString(R.string.pin_text_default_screen_lock) + ". " + getString(R.string.pin_text_default_screen_lock_details)
        );

        applyRadioContentDescription(
                2,
                view.findViewById(R.id.cl_radio_2),
                "pin",
                getString(R.string.pin_text_Change_PIN) + ". " + getString(R.string.pin_text_Change_PIN_Details)
        );

        applyRadioContentDescription(
                3,
                view.findViewById(R.id.cl_radio_3),
                "nothing",
                getString(R.string.pin_text_SKIP) + ". " + getString(R.string.i_would_like_to_enter_my_username_and_password_everytime)
        );
    }
    private void applyRadioContentDescription(Integer index, View view, String value, String label) {
        boolean isSelected = value.equals(mClickedView);

        String description;

        if (isSelected) {
            description = label + ". In List. Button" +index +"of 3. selected";
        } else {
            description = label + ". In List. Button" +index +"of 3. not selected";
        }

        view.setContentDescription(description);
    }


}
