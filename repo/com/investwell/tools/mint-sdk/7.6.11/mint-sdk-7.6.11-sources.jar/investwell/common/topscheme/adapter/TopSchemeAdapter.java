package investwell.common.topscheme.adapter;

import static investwell.utils.UtilityKotlin.getPicassoTransform;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;
import investwell.utils.Config;

public class TopSchemeAdapter extends RecyclerView.Adapter<TopSchemeAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnTopSchemeClickListener listener;
    private String mSelectedData = "";
    private String mToolbarTitle = "";
    private AppSession mSession;
    private String mType = "";

    public TopSchemeAdapter(String type, Context context, ArrayList<JSONObject> list, OnTopSchemeClickListener listener) {
        mContext = context;
        mDataList = list;
        mSession = AppSession.getInstance(mContext);
        this.listener = listener;
        mType = type;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_top_scheme_new, viewGroup, false);
        return new TopSchemeAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final TopSchemeAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnTopSchemeClickListener {
        void onItemClick(int position, JSONObject mJsonData);

        void onTopSchemeNameClick(JSONObject mJObject);

        void onByClick(JSONObject mJObject);

        void onAddFavClick(JSONObject mJObject);
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llTopSchemeCart;
        TextView tvTopSchemeName, tvTopSchemeReturn;
        ImageView topSchemeCartadd, ivTopSchemeImage, ivFundPick;


        public ViewHolder(View view) {
            super(view);
            llTopSchemeCart = view.findViewById(R.id.ll_top_scheme_cart);
            tvTopSchemeName = view.findViewById(R.id.tv_top_scheme_name);
            topSchemeCartadd = view.findViewById(R.id.top_scheme_cartadd);
            ivFundPick = view.findViewById(R.id.ivFundPick);
            ivTopSchemeImage = view.findViewById(R.id.iv_top_scheme_image);
            tvTopSchemeReturn = view.findViewById(R.id.tv_top_scheme_return);
        }

        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final TopSchemeAdapter.OnTopSchemeClickListener listener) {
            JSONObject topSchemeData = mDataList.get(position);
            String type = "scheme";
            try {
                Boolean hasVisibilityFound = false;
                if (mSession.getAllowedFeatures().length() > 0) {
                    JSONObject jsonObject = new JSONObject(mSession.getAllowedFeatures());
                    JSONArray jsonArray = jsonObject.optJSONArray("data");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        if (jsonArray.optJSONObject(i).has("feature1017") && mSession.getExchangeNseBseMfu().equals("1")) {
                            hasVisibilityFound = true;
                        } else if (jsonArray.optJSONObject(i).has("feature1021") && mSession.getExchangeNseBseMfu().equals("2")) {
                            hasVisibilityFound = true;
                        } else if (jsonArray.optJSONObject(i).has("feature1024") && mSession.getExchangeNseBseMfu().equals("3")) {
                            hasVisibilityFound = true;
                        }else if (jsonArray.optJSONObject(i).has("feature1042") && mSession.getExchangeNseBseMfu().equals("4")) {
                            hasVisibilityFound = true;
                        }
                    }
                    if (hasVisibilityFound) {
                        llTopSchemeCart.setVisibility(View.VISIBLE);
                    } else {
                        llTopSchemeCart.setVisibility(View.INVISIBLE);
                    }
                }

                if (mSession.getLoginType().equalsIgnoreCase("broker") && mSession.getClientObject().isEmpty()) {
                    if (topSchemeData.optString("isAmcAllowed").equals("1")){
                        topSchemeCartadd.setVisibility(View.VISIBLE);
                    }else{
                        topSchemeCartadd.setVisibility(View.GONE);
                    }
                } else {
                    topSchemeCartadd.setVisibility(View.GONE);
                }



                if (!topSchemeData.optString("schemeGroupName").equals("") && !topSchemeData.optString("schemeGroupName").equals("null")) {
                    tvTopSchemeName.setText(topSchemeData.optString("schemeGroupName"));
                }
                if (topSchemeData.optInt("isRecommended") == 1) {
                    ivFundPick.setVisibility(View.VISIBLE);
                } else {
                    ivFundPick.setVisibility(View.GONE);
                }

                if (!TextUtils.isEmpty(topSchemeData.optString("fundName")) && !topSchemeData.optString("fundName").equals("null")) {
                    type = "fund";
                    String mSchemeImageUrl = Config.GET_FUND_IMAGE_URL + topSchemeData.optString("fundName") + ".png";
                    if (mSchemeImageUrl.contains("&")) {
                        mSchemeImageUrl = mSchemeImageUrl.replace("&", "");
                    }

                    mSchemeImageUrl = mSchemeImageUrl.replaceAll("\\s+", "");
                    Picasso.get().load(mSchemeImageUrl).error(R.mipmap.tranparent).transform(getPicassoTransform()).into(ivTopSchemeImage);
                }

                if (!TextUtils.isEmpty(mSelectedData)) {
                    if (mToolbarTitle.equals(mContext.getString(R.string.dashboard_top_sip_title))) {
                       if (mSelectedData.equals("1YearSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("1YearSIPReturn"));
                        } else if (mSelectedData.equals("3YearSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("3YearSIPReturn"));
                        } else if (mSelectedData.equals("5YearSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("5YearSIPReturn"));
                        } else if (mSelectedData.equals("10YearSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("10YearSIPReturn"));
                        } else if (mSelectedData.equals("15YearSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("15YearSIPReturn"));
                        }else if (mSelectedData.equals("20YearSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("20YearSIPReturn"));
                        } else if (mSelectedData.equals("sinceInceptionSIPReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("sinceInceptionSIPReturn"));
                        }
                    }else{
                        if (mSelectedData.equals("1Day")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("1Day"));
                        } else if (mSelectedData.equals("7Day")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("7Day"));
                        } else if (mSelectedData.equals("15Day")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("15Day"));
                        } else if (mSelectedData.equals("30Day")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("30Day"));
                        } else if (mSelectedData.equals("3Month")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("3Month"));
                        } else if (mSelectedData.equals("6Month")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("6Month"));
                        } else if (mSelectedData.equals("1Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("1Year"));
                        } else if (mSelectedData.equals("2Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("2Year"));
                        } else if (mSelectedData.equals("3Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("3Year"));
                        } else if (mSelectedData.equals("5Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("5Year"));
                        } else if (mSelectedData.equals("10Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("10Year"));
                        }

                        else if (mSelectedData.equals("15Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("15Year"));
                        }else if (mSelectedData.equals("20Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("20Year"));
                        }else if (mSelectedData.equals("25Year")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("25Year"));
                        }else if (mSelectedData.equals("sinceInceptionReturn")) {
                            setValue(tvTopSchemeReturn, topSchemeData.optString("sinceInceptionReturn"));
                        }
                    }



                }


            } catch (Exception e) {

            }
            itemView.setOnClickListener(v -> {
                listener.onItemClick(position, topSchemeData);
            });
            tvTopSchemeName.setOnClickListener(v -> listener.onTopSchemeNameClick(topSchemeData));
            topSchemeCartadd.setOnClickListener(v -> listener.onByClick(topSchemeData));
            topSchemeCartadd.setContentDescription(mContext.getString(R.string.add_scheme,tvTopSchemeName.getText()));
            itemView.setContentDescription(tvTopSchemeName.getText() + ". " + tvTopSchemeReturn.getText() + " return" + ". Open factsheet.");

        }

    }


    public void updateList(List<JSONObject> list, String mSelectedReturnDate, String toolbarTitle) {
        mDataList.clear();
        mSelectedData = mSelectedReturnDate;
        mToolbarTitle = toolbarTitle;
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    @SuppressLint({"DefaultLocale", "SetTextI18n"})
    private TextView setValue(TextView textView, String value) {
        try {
            if (value.contains("-")) {
                textView.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
            } else {
                textView.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
            }

            String formatedValue = "";
            if (value.isEmpty() || value.equals("null") || value.equals("0") || value.equals("0.0") || value.contains("0.00")) {
                textView.setText("-");
            } else {
                formatedValue = String.format("%.2f", Double.parseDouble(value));
                textView.setText(formatedValue + " %");
            }

        }catch (Exception e){

        }

        return  textView;
    }


}
