package investwell.broker.activity;

import static investwell.activity.AppApplication.sAppUpdateCalled;
import static investwell.di.core.LogExtKt.logD;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.BuildConfig;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.BaseActivity;
import investwell.activity.SplashActivity;
import investwell.broker.fragment.FragCreateNotification;
import investwell.broker.fragment.FragHome3WithoutLogin;
import investwell.broker.fragment.FragHome6WithoutLogin;
import investwell.broker.fragment.FragHomeBrokerV4;
import investwell.broker.fragment.FragHomeBrokerV5;
import investwell.broker.kyc.FragKycGenerate;
import investwell.broker.meetingnotes.fragment.FragCreateAndEdit;
import investwell.broker.meetingnotes.fragment.FragMeetingNotesHome;
import investwell.broker.meetingnotes.fragment.FragViewNote;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.folio.sharefolio.FragShareFolioLookupDetails;
import investwell.client.fragments.goal.FragAddNewGoals;
import investwell.client.fragments.goal.FragGoalForm;
import investwell.client.fragments.goal.FragUpdateGoal;
import investwell.client.fragments.home.FragHomeClient4;
import investwell.client.fragments.home.FragHomeClient5;
import investwell.client.fragments.home.FragHomeClient6;
import investwell.client.orderBse.FragOrderDash;
import investwell.common.casimport.FragSchemeMapping;
import investwell.common.casimport.FragTxnMapping;
import investwell.common.onboarding.ExchangeForAdditionalPurchase;
import investwell.common.permissions.NotificationPermissionHandler;
import investwell.common.permissions.NotificationPermissionManager;
import investwell.common.permissions.PermissionHandlerViewModel;
import investwell.common.transactions.fragments.FragAddTxnFD;
import investwell.common.transactions.fragments.FragAddTxnShareAndBond;
import investwell.common.transactions.fragments.FragTransactionHome;
import investwell.utils.CrmBuilder;
import investwell.utils.ExtensionsKt;
import investwell.utils.PermissionSet;
import investwell.utils.Permissions;
import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import investwell.activity.AppApplication;
import investwell.activity.BaseActivity;
import investwell.activity.WebViewActivity;
import investwell.broker.fragment.FragCreateNotification;
import investwell.broker.fragment.FragHome3WithoutLogin;
import investwell.broker.fragment.FragHomeBroker;
import investwell.broker.fragment.FragHomeBrokerV2;
import investwell.broker.fragment.FragHomeBrokerV4;
import investwell.broker.fragment.FragTopScheme;
import investwell.broker.fragment.clientSearch.FragClientSearch;
import investwell.broker.kyc.FragKycGenerate;
import investwell.broker.meetingnotes.fragment.FragCreateAndEdit;
import investwell.broker.meetingnotes.fragment.FragMeetingNotesHome;
import investwell.broker.meetingnotes.fragment.FragViewNote;
import investwell.client.fragments.SipMining.SipMiningClientDetail;
import investwell.client.fragments.SipMining.SipMiningFunds;
import investwell.client.fragments.SipMining.SipMiningScheme;
import investwell.client.fragments.SipMining.SipMininigClient;
import investwell.client.fragments.aum.FragAumReport;
import investwell.client.fragments.aum.FragAumReportByScheme;
import investwell.client.fragments.aum.FragAumReportByUser;
import investwell.client.fragments.folio.FragFolioLookup;
import investwell.client.fragments.folio.FragFolioLookupDetails;
import investwell.client.fragments.folio.Frag_SOA;
import investwell.client.fragments.goal.FragAddNewGoals;
import investwell.client.fragments.goal.FragGoalForm;
import investwell.client.fragments.goal.FragGoalList;
import investwell.client.fragments.goal.FragUpdateGoal;
import investwell.client.fragments.help.ContactFragment;
import investwell.client.fragments.help.ContactFragmentV2;
import investwell.client.fragments.help.FaqFragment;
import investwell.client.fragments.help.HelpHostFragment;
import investwell.client.fragments.help.MoreFragment;
import investwell.client.fragments.home.FragHomeClient;
import investwell.client.fragments.home.FragHomeClient2;
import investwell.client.fragments.home.FragHomeClient3;
import investwell.client.fragments.home.FragHomeClient4;
import investwell.client.fragments.home.FragHomeClient5;
import investwell.client.fragments.home.FragNotification;
import investwell.client.fragments.insurance.FragInsuranceHome;
import investwell.client.fragments.others.BottomSheetFragmentBroker;
import investwell.client.fragments.others.FragBrokerOrderHome;
import investwell.client.fragments.others.FragCapitalGainUnrealized;
import investwell.client.fragments.others.FragMyOrders;
import investwell.client.fragments.others.FragProfileSettings;
import investwell.client.fragments.others.Help_Frag;
import investwell.client.fragments.portfolio.FragPortfolioShareDetails;
import investwell.client.fragments.portfolio.PortfolioSchemeDetail;
import investwell.client.fragments.portfolioSummary.FragPtSummaryHome;
import investwell.client.fragments.transection.additional.common.FragRedeemNseBseMfu;
import investwell.client.fragments.transection.additional.common.FragStpBseMfu;
import investwell.client.fragments.transection.additional.common.FragSwitchNseBseMfu;
import investwell.client.fragments.transection.additional.common.FragSwpNseBse;
import investwell.client.fragments.transection.additional.purchase.FragAdditionalPurchaseBse;
import investwell.client.fragments.transection.additional.purchase.FragAdditionalPurchaseNse;
import investwell.client.fragments.transection.additional.sip.FragAdditionalSipBse;
import investwell.client.fragments.transection.additional.sip.FragAdditionalSipNse;
import investwell.client.fragments.transferholding.TransferHoldingInfo;
import investwell.client.orderBse.FragOrderDash;
import investwell.client.orderBse.FragOrdersBse;
import investwell.common.calculator.fragment.FragEducationCalculator;
import investwell.common.calculator.fragment.FragEmiCalculator;
import investwell.common.calculator.fragment.FragLumsumCal;
import investwell.common.calculator.fragment.FragMarriegeCalculator;
import investwell.common.calculator.fragment.FragRetirmentCalculator;
import investwell.common.calculator.fragment.FragSipCalculator;
import investwell.common.calculator.fragment.FragSipDelayCost;
import investwell.common.calculator.fragment.FragSipStepup;
import investwell.common.calculator.fragment.FragTaxInvestmentCal;
import investwell.common.casimport.FragCasArns;
import investwell.common.casimport.FragCasContainer;
import investwell.common.casimport.FragCasImportMain;
import investwell.common.casimport.FragCasOTPAuthenticate;
import investwell.common.casimport.FragSchemeMapping;
import investwell.common.casimport.FragTxnMapping;
import investwell.common.intro.IntroActivity;
import investwell.common.intro.SingleIntroActivity;
import investwell.common.lock.FragChangeAppSecurity;
import investwell.common.nav.FragLatestNav;
import investwell.common.onboarding.ExchangeForAdditionalPurchase;
import investwell.common.transactions.fragments.FragAddTxnFD;
import investwell.common.transactions.fragments.FragAddTxnShareAndBond;
import investwell.common.transactions.fragments.FragTransactionHome;
import investwell.di.ForceUpdate;
import investwell.utils.ApiRequestType;
import investwell.utils.AppConstants;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import investwell.utils.crop.CropImage;
import investwell.utils.customView.CustomDialog;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

public class BrokerActivity extends BaseActivity implements View.OnClickListener, NotificationPermissionHandler {
    public List<JSONObject> mSelectedCartsList;
    private AppSession mSession;
    private RelativeLayout mTab1, mTab2, mTab3, mTab4, mTab5;
    private TextView mTvMenu1, mTvMenu2, mTvMenu3, mTvMenu4, mTvMenu5;
    private ImageView mIvMenu1, mIvMenu2, mIvMenu3, mIvMenu4, mIvMenu5;
    public static int mTabCount = 1;
    private final String isBackFromCalc = "f";
    public CardView mCvTabBarBottom;
    private AppApplication mApplication;
    private Bundle mBundle;
    public JSONObject mProsPectStatusObject;
    public AppApplication mAppplication;
    public String mSelectedValue = "currentFY";
    private BottomSheetFragmentBroker bottomSheetFragment;

    private JSONObject appConfigObject;
    int mCalculatorToOpen = 0;
    String mCameFrom = "";

    private final int RC_APP_UPDATE = 0;
    private final int REQUEST_APP_UPDATE = 17362;
    private String mCallCommingFrom = "";
    private ReviewInfo reviewInfo;
    private ReviewManager reviewManager;

    private long backPressedTime = 0;
    private Toast backToast;
    private boolean returnedFromOtherActivity = false;
    private boolean isRecreated = false;
    private PermissionHandlerViewModel permissionViewModel;
    private NotificationPermissionManager permissionManager;

    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("MintLifeCycleLog broker Activity");
    }


    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    @Override
    public void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            registerReceiver(myReceiver, new IntentFilter("FBR-IMAGE"), RECEIVER_EXPORTED);
        } else {
            registerReceiver(myReceiver, new IntentFilter("FBR-IMAGE"));
        }
        permissionViewModel.updatePermissionStatus(this);
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        outState.putBoolean("isRecreated", true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ProgressBarCommon.dismissDialog();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        String appLinkAction = intent.getStringExtra("action");
        String appLinkData = intent.getStringExtra("data");
        System.out.println(appLinkAction + appLinkData);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode()==KeyEvent.KEYCODE_BACK && event.getAction()== KeyEvent.ACTION_UP){
            logD( "Intercepted back key in dispatchKeyEvent broker");
            handleCustomBackLogic();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    public void onBackPressedHandled() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
        int fragmentCount = getSupportFragmentManager().getBackStackEntryCount();

        if ((mSession.getHasLoging() && mSession.getLoginType().equalsIgnoreCase("broker")) || (mSession.getHasLoging() && mSession.getLoginType().equalsIgnoreCase("RM")) || (mSession.getHasLoging() && mSession.getLoginType().equals("SubBroker"))) {

            if (fragment instanceof FragHomeClient || fragment instanceof FragHomeClient2 || fragment instanceof FragHomeClient4 || fragment instanceof FragHomeClient5|| fragment instanceof FragHomeClient6) {
                getSupportFragmentManager().popBackStack();
            } else if (fragment instanceof FragClientSearch) {
                removeAllStack();
            } else {
                handleBackPressedCase(fragmentCount);
            }
        } else if (fragment instanceof FragHomeClient || fragment instanceof FragHomeClient5 || fragment instanceof FragHomeBroker||fragment instanceof FragHome6WithoutLogin|| fragment instanceof FragHomeBrokerV5 || fragment instanceof FragHome3WithoutLogin || fragment instanceof FragHomeBrokerV2 || fragment instanceof FragHomeBrokerV4 || fragment instanceof FragHomeClient4 || fragment instanceof FragHomeClient2) {
            super.onBackPressedHandled();
        } else if (fragment instanceof FragSipStepup || fragment instanceof FragEmiCalculator || fragment instanceof FragSipDelayCost ||
                fragment instanceof FragRetirmentCalculator || fragment instanceof FragEducationCalculator ||
                fragment instanceof FragMarriegeCalculator || fragment instanceof FragTaxInvestmentCal || fragment instanceof FragLumsumCal) {
            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) &&
                    appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                finish();
            } else if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) &&
                    appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                finish();
            } else {
                super.onBackPressedHandled();
            }
        } else {
            getSupportFragmentManager().popBackStack();
        }

        if (mCameFrom.equalsIgnoreCase("calculator")) {
            finish();
        }
    }

    public void handleCustomBackLogic(){
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
        int fragmentCount = getSupportFragmentManager().getBackStackEntryCount();
        logD( "Intercepted back key in dispatchKeyEvent broker fr");
        if ((mSession.getHasLoging() && mSession.getLoginType().equalsIgnoreCase("broker")) || (mSession.getHasLoging() && mSession.getLoginType().equalsIgnoreCase("RM")) || (mSession.getHasLoging() && mSession.getLoginType().equals("SubBroker"))) {

            if (fragment instanceof FragHomeClient || fragment instanceof FragHomeClient2 || fragment instanceof FragHomeClient4 || fragment instanceof FragHomeClient5) {
                getSupportFragmentManager().popBackStack();
            } else if (fragment instanceof FragClientSearch) {
                removeAllStack();
            } else {
                handleBackPressedCase(fragmentCount);
            }
        } else if (fragment instanceof FragHomeClient || fragment instanceof FragHomeClient5 || fragment instanceof FragHomeBroker || fragment instanceof FragHome3WithoutLogin || fragment instanceof FragHomeBrokerV2 || fragment instanceof FragHomeBrokerV4 || fragment instanceof FragHomeClient4 || fragment instanceof FragHomeClient2) {
            getOnBackPressedDispatcher().onBackPressed();
        } else if (fragment instanceof FragSipStepup || fragment instanceof FragEmiCalculator || fragment instanceof FragSipDelayCost ||
                fragment instanceof FragRetirmentCalculator || fragment instanceof FragEducationCalculator ||
                fragment instanceof FragMarriegeCalculator || fragment instanceof FragTaxInvestmentCal || fragment instanceof FragLumsumCal) {
            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) &&
                    appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                finish();
            } else if (getString(R.string.subdomain).equals("mintbyiw") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) &&
                    appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                finish();
            } else {
                getOnBackPressedDispatcher().onBackPressed();
            }
        } else {
            getSupportFragmentManager().popBackStack();
        }

        if (mCameFrom.equalsIgnoreCase("calculator")) {
            finish();
        }else {
            finish();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(myReceiver);
        } catch (Exception e) {
        }
    }

    private void handleBackPressedCase(int fragmentCount) {
        if (fragmentCount == 0) {
            if (backPressedTime + 2000 > System.currentTimeMillis()) {
                backToast.cancel();
                super.onBackPressedHandled();
            } else {
                backToast = Toast.makeText(this, getString(R.string.press_back_again_to_exit), Toast.LENGTH_SHORT);
                backToast.show();
            }
            backPressedTime = System.currentTimeMillis();
        } else {
            getSupportFragmentManager().popBackStack();
        }
    }


    /**********************************************************
     BroadCastReceiver for get notification Check
     ***********************************************************/
    public BroadcastReceiver myReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateNotificationCount();

        }
    };

    private void updateNotificationCount() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
        if (fragment instanceof FragHomeBroker) {
            ((FragHomeBroker) fragment).notificationCount();
        }
        else if (fragment instanceof FragHomeBrokerV2) {
            ((FragHomeBrokerV2) fragment).notificationCount();
        }
        else if (fragment instanceof FragHomeBrokerV5) {
            ((FragHomeBrokerV5) fragment).notificationCount();
        }
        else if (fragment instanceof FragHome6WithoutLogin) {
           // ((FragHome6WithoutLogin) fragment).notificationCount();
        }
    }


    public <T> void setMainVisibility(Fragment fragment, T object) {
        try {
            if (fragment instanceof FragHomeBroker ||fragment instanceof FragHome6WithoutLogin || fragment instanceof FragHomeBrokerV2 || fragment instanceof FragHomeBrokerV4|| fragment instanceof FragHomeBrokerV5 || fragment instanceof FragClientSearch || fragment instanceof FragAumReport || fragment instanceof BottomSheetFragmentBroker) {

                if (mSession.getHasLoging()) {
                    mCvTabBarBottom.setVisibility(View.VISIBLE);
                } else {
                    mCvTabBarBottom.setVisibility(View.GONE);
                }

                if (fragment instanceof FragHomeBroker || fragment instanceof FragHomeBrokerV2|| fragment instanceof FragHome6WithoutLogin) {
                    changeColorBrokerDash(1);
                    mTabCount = 1;
                } else if (fragment instanceof FragClientSearch) {
                    changeColorBrokerDash(2);
                    mTabCount = 2;
                } else if (fragment instanceof FragAumReport) {
                    changeColorBrokerDash(3);
                    mTabCount = 3;
                } else if (fragment instanceof BottomSheetFragmentBroker) {
                    changeColorBrokerDash(4);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mTabCount == 1) {
                                changeColorBrokerDash(1);
                            } else if (mTabCount == 2) {
                                changeColorBrokerDash(2);
                            } else if (mTabCount == 3) {
                                changeColorBrokerDash(3);
                            }
                        }
                    }, 500);

                } else {
                    changeColorBrokerDash(1);
                    mTabCount = 1;
                }
            } else {
                mCvTabBarBottom.setVisibility(View.GONE);
                if (bottomSheetFragment.isVisible()) {
                    bottomSheetFragment.dismiss();
                }
            }
        } catch (Exception e) {

        }
    }

/*
    @Override
    protected void onResume() {
        super.onResume();
        if(isBackFromCalc.equalsIgnoreCase("t")) {
            new FragHomeBrokerV2().toggleCalculators();
        }
    }
*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Utils.isTablet(this))
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setContentView(R.layout.broker_activity);
        permissionViewModel  = new ViewModelProvider(this).get(PermissionHandlerViewModel.class);
        permissionManager = new NotificationPermissionManager(
                this,
                granted -> {
                    permissionViewModel.updatePermissionStatus(BrokerActivity.this);
                    return null;
                }
        );
        permissionManager.register();
        mAppplication = (AppApplication) getApplication();
        mSession = AppSession.getInstance(this);
        Extensions.updateLocale(this,mSession.getAppLanguage());
        reviewManager = ReviewManagerFactory.create(this);
        if (savedInstanceState != null && savedInstanceState.getBoolean("isRecreated", false)) {
            isRecreated = true;
        }

        if (mSession.getHasLoging() && getIntent().hasExtra("transactionDeeplinkUrl")) {
            Toast.makeText(this, "This link not valid for broker login", Toast.LENGTH_SHORT).show();
        }

        Log.d("binesh", "onCreate: called");

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        mApplication = (AppApplication) getApplication();
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("coming_from")) {
            mCallCommingFrom = intent.getStringExtra("coming_from");
        }
        mBundle = intent.getExtras();

        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            } else {
                appConfigObject = new JSONObject();
            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        mTab1 = findViewById(R.id.relMenu1);
        mTab2 = findViewById(R.id.relMenu2);
        mTab3 = findViewById(R.id.relMenu3);
        mTab4 = findViewById(R.id.relMenu4);
        mTab5 = findViewById(R.id.relMenu5);

        mTvMenu1 = findViewById(R.id.tvMenu1);
        mTvMenu2 = findViewById(R.id.tvMenu2);
        mTvMenu3 = findViewById(R.id.tvMenu3);
        mTvMenu4 = findViewById(R.id.tvMenu4);
        mTvMenu5 = findViewById(R.id.tvMenu5);

        mIvMenu1 = findViewById(R.id.ivMenu1);
        mIvMenu2 = findViewById(R.id.ivMenu2);
        mIvMenu3 = findViewById(R.id.ivMenu3);
        mIvMenu4 = findViewById(R.id.ivMenu4);
        mIvMenu5 = findViewById(R.id.ivMenu5);
        mCvTabBarBottom = findViewById(R.id.ly_header);
        mCvTabBarBottom.setVisibility(View.GONE);

        mTab1.setOnClickListener(this);
        mTab2.setOnClickListener(this);
        mTab3.setOnClickListener(this);
        mTab4.setOnClickListener(this);
        mTab5.setOnClickListener(this);

        /***
         * code hide removed by this card https://trello.com/c/6mIqUXgz/3107-access-permission-use-for-clients-menu-to-be-removed-from-broker-portal

         try {
         boolean isViewEnabledClientSearch = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature2",Permissions.VIEW);
         if(!isViewEnabledClientSearch)
         mTab2.setVisibility(View.GONE);
         } catch (Exception e) {
         throw new RuntimeException(e);
         }
         */


        try {
            JSONObject jsoObject = new JSONObject(mSession.getAllowedFeatures());
            JSONArray jsonArray = jsoObject.optJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                if (jsonArray.optJSONObject(i).has("feature26")) {
                    mTab3.setVisibility(View.VISIBLE);
                    break;
                } else {
                    mTab3.setVisibility(View.GONE);
                }
            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        bottomSheetFragment = new BottomSheetFragmentBroker();
        mSelectedCartsList = new ArrayList<>();
        if (intent.hasExtra("calculator")) {
            mCalculatorToOpen = intent.getIntExtra("calculator", 0);

        }
        if (intent.hasExtra("cameFrom")) {
            mCameFrom = intent.getStringExtra("cameFrom");
        }

        if (!getString(R.string.subdomain).equals("mint")) {
            if (mSession.getAppInfo().isEmpty()) {
                getPublicInfo();
            } else {
                if (mCameFrom != null && mCalculatorToOpen != 0 && mCameFrom.equalsIgnoreCase("calculator")) {
                    displayViewCalculator(mCalculatorToOpen, null);
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("isAddBackToStack", "no");
                    displayViewOther(1, bundle);

                    openNotification();
                }

            }
        } else {
            if (mCameFrom != null && mCalculatorToOpen != 0 && mCameFrom.equalsIgnoreCase("calculator")) {
                displayViewCalculator(mCalculatorToOpen, null);
            } else {
                if (!mSession.getUserBrokerDomain().isEmpty()) {
                    if (mSession.getAppInfo().isEmpty()) {
                        getPublicInfo();
                    } else {
                        reDirectMethod();
                    }
                } else {
                    Bundle bundle = new Bundle();
                    bundle.putString("isAddBackToStack", "no");
                    displayViewOther(1, bundle);

                   openNotification();
                }

            }
        }
        if (!BuildConfig.DEBUG){
            new ForceUpdate(mSession).forceUpdateIfRequired(this);
        }

        if (intent.hasExtra("comeFromMfuCartWebView")) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("comeFromMfuCartWebView", true);
            displayViewOther(84, bundle);
        }

        if(intent.hasExtra("comeFromBseCartWebView")){
            Bundle bundle = new Bundle();
            bundle.putBoolean("comeFromBseCartWebView", true);
            displayViewOther(33, bundle);
        }
        if(intent.hasExtra("comeFromNseCartWebView")){
            Bundle bundle = new Bundle();
            bundle.putBoolean("comeFromNseCartWebView", true);
            displayViewOther(33, bundle);
        }

        if (sAppUpdateCalled) {
            sAppUpdateCalled = false;
            if(getString(R.string.subdomain).equals("mint")) requestNotificationPermission(false);
        }

        ViewCompat.setAccessibilityDelegate(findViewById(R.id.linerTabBar),
                new AccessibilityDelegateCompat() {
                    @Override
                    public void onInitializeAccessibilityNodeInfo(
                            View host,
                            AccessibilityNodeInfoCompat info) {

                        super.onInitializeAccessibilityNodeInfo(host, info);

                        info.setClassName("android.widget.TabWidget");

                        info.setCollectionInfo(
                                AccessibilityNodeInfoCompat.CollectionInfoCompat.obtain(
                                        1,      // rows
                                        4,      // columns (visible tabs)
                                        false
                                )
                        );
                    }
                });

       updateAccessibilityOfTab(0);
    }

    private void applyTabAccessibility(
            View tabView,
            String label,
            int index,
            boolean isSelected) {

        tabView.setFocusable(true);
        tabView.setClickable(true);
        tabView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);

        tabView.setContentDescription(
                label + ". tab " + (index + 1) + " of " + 4
                        + (isSelected ? ". selected" : ". not selected")
        );
    }
    private void updateAccessibilityOfTab(int index) {

        applyTabAccessibility(
                mTab1,
                mTvMenu1.getText().toString(),
                0,
                index == 0
        );

        applyTabAccessibility(
                mTab2,
                mTvMenu2.getText().toString(),
                1,
                index == 1
        );

        applyTabAccessibility(
                mTab3,
                mTvMenu3.getText().toString(),
                2,
                index == 2
        );

        applyTabAccessibility(
                mTab4,
                mTvMenu4.getText().toString(),
                3,
                index == 3
        );
    }



    @Override
    public void onClick(View v) {
        Bundle bundle = new Bundle();
        mSession.setClientObject("");
        Log.d("client_object_clear", "data clear onclick BrokerActivty");
        if (v.getId() == R.id.relMenu1) {
                removeAllStack();
                changeColorBrokerDash(1);
                updateAccessibilityOfTab(0);
                mTabCount = 1;
}
else if (v.getId() == R.id.relMenu2) {
                changeColorBrokerDash(2);
                mTabCount = 2;
                updateAccessibilityOfTab(1);
                Bundle bundle2 = new Bundle();
                bundle2.putString("searchType", "Group");
                bundle2.putString("searchValue", "");
                displayViewOther(2, bundle2);
}
else if (v.getId() == R.id.relMenu3) {
                changeColorBrokerDash(3);
                mTabCount = 3;
                updateAccessibilityOfTab(2);
                displayViewOther(24, null);
}
else if (v.getId() == R.id.relMenu4) {
                changeColorBrokerDash(4);
                updateAccessibilityOfTab(3);
                bottomSheetFragment.show(getSupportFragmentManager(), bottomSheetFragment.getTag());
}
else if (v.getId() == R.id.relMenu5) {
                changeColorBrokerDash(5);
                mTabCount = 5;
}
    }


    public void displayViewOther(int position, Bundle bundle) {
        Fragment fragment = null;
        switch (position) {
            case 1:
                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                    if (!mSession.getHasLoging()) {
                        fragment = new FragHome3WithoutLogin();
                        fragment.setArguments(bundle);
                    } else {
                        fragment = new FragHomeBroker();
                        fragment.setArguments(bundle);
                    }
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    if (!mSession.getHasLoging()) {
                        fragment = new FragHome6WithoutLogin();
                    } else {
                        fragment = new FragHomeBroker();
                    }
                    fragment.setArguments(bundle);
                } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                    fragment = new FragHomeBrokerV2();
                    fragment.setArguments(bundle);
                } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                    fragment = new FragHomeBrokerV5();
                    fragment.setArguments(bundle);
                } else if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                    fragment = new FragHomeBrokerV4();
                    fragment.setArguments(bundle);
                } else {
                    fragment = new FragHomeBroker();
                    fragment.setArguments(bundle);
                }
                break;

            case 2:
                fragment = new FragClientSearch();
                fragment.setArguments(bundle);
                break;

            case 3:
                if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                    fragment = new FragHomeClient4();
                    fragment.setArguments(bundle);
                } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                    fragment = new FragHomeClient2();
                    fragment.setArguments(bundle);
                } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                    fragment = new FragHomeClient3();
                    fragment.setArguments(bundle);
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    fragment = new FragHomeClient6();
                    fragment.setArguments(bundle);
                } else if (!mSession.getAppConfig().isEmpty() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                    fragment = new FragHomeClient5();
                    fragment.setArguments(bundle);
                } else {
                    fragment = new FragHomeClient();
                    fragment.setArguments(bundle);
                }

                break;

          /*  case 4:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                fragment = new Portfolio();
                fragment.setArguments(bundle);
                break;*/

          /*  case 4:
                fragment = new FragPortfolioHome();
                fragment.setArguments(bundle);
                break;

            case 5:
                fragment = new Portfolio_Detail();
                fragment.setArguments(bundle);
                break;*/

            case 6:
                fragment = new FragTransactionHome();
                fragment.setArguments(bundle);
                break;

            case 7:
                fragment = new PortfolioSchemeDetail();
                fragment.setArguments(bundle);
                break;

            case 8:
                fragment = new FragAdditionalPurchaseBse();
                fragment.setArguments(bundle);
                break;

            case 9:
                fragment = new FragAdditionalSipBse();
                fragment.setArguments(bundle);
                break;

            case 10:
                fragment = new FragSwitchNseBseMfu();
                fragment.setArguments(bundle);
                break;

            case 11:
                fragment = new FragSwpNseBse();
                fragment.setArguments(bundle);
                break;

            case 12:
                fragment = new FragStpBseMfu();
                fragment.setArguments(bundle);
                break;

            case 13:
                fragment = new FragRedeemNseBseMfu();
                fragment.setArguments(bundle);
                break;

            case 14:
                fragment = new FragFolioLookup();
                fragment.setArguments(bundle);
                break;

            case 15:
                fragment = new FragFolioLookupDetails();
                fragment.setArguments(bundle);
                break;

            case 16:
                fragment = new Frag_SOA();
                fragment.setArguments(bundle);
                break;

            case 17:
               // fragment = new FragCapitalGain();
               // fragment.setArguments(bundle);
                break;

            case 18:
                fragment = new FragPortfolioShareDetails();
                fragment.setArguments(bundle);
                break;

            case 19:
                fragment = new FragPtSummaryHome();
                fragment.setArguments(bundle);
                break;

            case 20:
                fragment = new FragCapitalGainUnrealized();
                fragment.setArguments(bundle);
                break;

            case 21:
                fragment = new FragInsuranceHome();
                fragment.setArguments(bundle);
                break;


            case 24:
                fragment = new FragAumReport();
                fragment.setArguments(bundle);
                break;

            case 25:
                fragment = new FragAumReportByScheme();
                fragment.setArguments(bundle);
                break;

            case 26:
                fragment = new FragAumReportByUser();
                fragment.setArguments(bundle);
                break;


            case 27:
                fragment = new FragAdditionalPurchaseNse();
                fragment.setArguments(bundle);
                break;

            case 28:
                fragment = new FragAdditionalSipNse();
                fragment.setArguments(bundle);
                break;

            case 29:
                fragment = new SipMiningFunds();
                fragment.setArguments(bundle);
                break;

            case 30:
                fragment = new SipMiningScheme();
                fragment.setArguments(bundle);
                break;

            case 31:
                fragment = new SipMininigClient();
                fragment.setArguments(bundle);
                break;

            case 32:
                fragment = new SipMiningClientDetail();
                fragment.setArguments(bundle);
                break;

            case 33:
                String selectedExchange = Utils.getSelectedExchange(mSession);
                if (selectedExchange.equals("1")) {
                    fragment = new FragOrderDash();
                    fragment.setArguments(bundle);
                } else if (selectedExchange.equals("2")) {
                    fragment = new FragOrderDash();
                    fragment.setArguments(bundle);
                } else if (selectedExchange.equals("3")) {
                    fragment = new FragMyOrders();
                }else if (selectedExchange.equals("4")) {
                    fragment = new FragOrdersBse();
                } else {
                    fragment = new FragBrokerOrderHome();
                    fragment.setArguments(bundle);
                }
                break;


            case 39:
                JSONObject mAppJSONObject = new JSONObject();
                String mContactThemeType = "v2";
                if (!TextUtils.isEmpty(mSession.getAppInfo())) {
                    try {
                        mAppJSONObject = new JSONObject(mSession.getAppInfo());
                    } catch (Exception ignored) {

                    }
                }
                if (mAppJSONObject.has("contacttheme")) {
                    String contactThemeType = mAppJSONObject.optString("contacttheme");
                    if (contactThemeType == "null" || contactThemeType.isEmpty()) {
                        mContactThemeType = "v2";
                    } else if (contactThemeType.equals("1")) {
                        mContactThemeType = "v1";
                    } else if (contactThemeType.equals("2")) {
                        mContactThemeType = "v2";
                    } else {
                        mContactThemeType = "v2";
                    }
                }
                if (mContactThemeType.equals("v2")) {
                    fragment = new ContactFragmentV2();
                    fragment.setArguments(bundle);
                } else {
                    fragment = new HelpHostFragment();
                    fragment.setArguments(bundle);
                }
                break;
            case 40:
                fragment = new ContactFragment();
                fragment.setArguments(bundle);
                break;
            case 41:
                fragment = new FaqFragment();
                fragment.setArguments(bundle);
                break;
            case 42:
                fragment = new MoreFragment();
                fragment.setArguments(bundle);
                break;

            case 46:
                fragment = new FragNotification();
                fragment.setArguments(bundle);
                break;

            case 49:
                fragment = new FragGoalList();
                fragment.setArguments(bundle);
                break;


            case 62:
                fragment = new FragProfileSettings();
                fragment.setArguments(bundle);
                break;

            case 63:
                fragment = new Help_Frag();
                fragment.setArguments(bundle);
                break;

            case 64:
                fragment = new FragChangeAppSecurity();
                fragment.setArguments(bundle);
                break;

            case 65:
                fragment = new FragTopScheme();
                fragment.setArguments(bundle);
                break;

            case 66:
                fragment = new ExchangeForAdditionalPurchase();
                fragment.setArguments(bundle);
                break;
            case 67:
                fragment = new FragAddNewGoals();
                fragment.setArguments(bundle);
                break;

            case 68:
                fragment = new FragUpdateGoal();
                fragment.setArguments(bundle);
                break;

            case 69:
                fragment = new FragGoalForm();
                fragment.setArguments(bundle);
                break;

            case 70:
                fragment = new FragMeetingNotesHome();
                fragment.setArguments(bundle);
                break;

            case 71:
                fragment = new FragViewNote();
                fragment.setArguments(bundle);
                break;

            case 72:
                fragment = new FragCreateAndEdit();
                fragment.setArguments(bundle);
                break;

            case 73:
                fragment = new FragCreateNotification();
                fragment.setArguments(bundle);
                break;
            // cas import
            case 74:
                fragment = new FragCasImportMain();
                fragment.setArguments(bundle);
                break;
            case 75:
                fragment = new FragCasOTPAuthenticate();
                fragment.setArguments(bundle);
                break;

            case 76:
                fragment = new FragCasContainer();
                fragment.setArguments(bundle);
                break;

            case 77:
                fragment = new FragCasArns();
                fragment.setArguments(bundle);
                break;

            case 78:
                fragment = new FragSchemeMapping();
                fragment.setArguments(bundle);
                break;
            case 79:
                fragment = new FragTxnMapping();
                fragment.setArguments(bundle);
                break;

            case 80:
                fragment = new FragAddTxnShareAndBond();
                fragment.setArguments(bundle);
                break;

            case 81:
                fragment = new FragAddTxnFD();
                fragment.setArguments(bundle);
                break;

            // generate kyc
            case 82:
                fragment = new FragKycGenerate();
                fragment.setArguments(bundle);
                break;

            case 83:
                fragment = new TransferHoldingInfo();
                fragment.setArguments(bundle);
                break;

            case 84:
                fragment = new FragMyOrders();
                fragment.setArguments(bundle);
                break;

            case 85:
                fragment = new FragLatestNav();
                fragment.setArguments(bundle);
                break;

            case 86:
                fragment = new FragShareFolioLookupDetails();
                fragment.setArguments(bundle);
                break;

        }

        if (fragment != null) {

            if (bundle != null && bundle.containsKey("isAnimation")) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction().addToBackStack(null);
                transaction.setCustomAnimations(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left, R.anim.anim_slide_in_righ, R.anim.anim_slide_out_right);
                transaction.replace(R.id.content_frame, fragment);
                transaction.commit();
            } else {
                if (bundle != null && bundle.containsKey("isAddBackToStack")) {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
                } else {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    int count = getSupportFragmentManager().getBackStackEntryCount();
                    fragmentManager.beginTransaction().addToBackStack(null).replace(R.id.content_frame, fragment, "" + count).commit();
                }
            }
        }
    }


    public void displayViewCalculator(int position, Bundle bundle) {
        Fragment fragment = null;
        switch (position) {

            case 1:
                fragment = new FragSipCalculator();
                fragment.setArguments(bundle);
                break;

            case 3:
                fragment = new FragSipStepup();
                fragment.setArguments(bundle);
                break;

            case 4:
                fragment = new FragEmiCalculator();
                fragment.setArguments(bundle);
                break;

            case 5:
                fragment = new FragSipDelayCost();
                fragment.setArguments(bundle);
                break;

            case 6:
                fragment = new FragRetirmentCalculator();
                fragment.setArguments(bundle);
                break;

            case 7:
                fragment = new FragEducationCalculator();
                fragment.setArguments(bundle);
                break;

            case 8:
                fragment = new FragMarriegeCalculator();
                fragment.setArguments(bundle);
                break;

            case 9:
                fragment = new FragTaxInvestmentCal();
                fragment.setArguments(bundle);
                break;

            case 10:
                fragment = new FragLumsumCal();
                fragment.setArguments(bundle);
                break;


        }
        if (position == 0) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
        } else {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().addToBackStack(null).replace(R.id.content_frame, fragment).commit();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (resultCode == 100) {
            returnedFromOtherActivity = true;
            if (mSession.getAppType().equals("N")) {
                String isSingUploaded = result.getStringExtra("signUploaded");
                String ucc_code = result.getStringExtra("ucc_code");
                Bundle bundle = new Bundle();
                bundle.putString("ucc_code", ucc_code);
                if (isSingUploaded.equals("yes")) {
                    displayViewOther(10, bundle);
                }
            } else {
                String isSingUploaded = result.getStringExtra("signUploaded");
                if (isSingUploaded.equals("yes")) {
                    displayViewOther(11, new Bundle());
                }
            }
        } else if (resultCode == 500) {//ClientG Client
            returnedFromOtherActivity = true;
            if ((mSession.getHasLoging() && mSession.getLoginType().equals("ClientG")) || mSession.getHasLoging() && mSession.getLoginType().equals("Client")) {
                removeAllStack();
                displayViewOther(3, null);
                // displayViewOther(15, null);
            } else if ((mSession.getHasLoging() && mSession.getLoginType().equals("SubBroker")) || mSession.getHasLoging() && mSession.getLoginType().equals("RM") || mSession.getHasLoging() && mSession.getLoginType().equals("Broker")) {
                removeAllStack();
                //displayViewOther(3, null);
                displayViewOther(26, null);

            } else {
                removeAllStack();
                // displayViewOther(3, null);
                displayViewOther(15, null);
            }
        }
        if (requestCode == 300) {
            returnedFromOtherActivity = true;
            CropImage.ActivityResult imageResult = CropImage.getActivityResult(result);
            try {
                Uri selectedImage = imageResult.getUri();
                if (selectedImage != null) {
                    Bitmap gallery_bit = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                    mSession.setImageRawData(selectedImage.getPath());
                    // if (gallery_bit != null)
                    //  mProfileImage.setImageBitmap(RoundedImageView.getCroppedBitmap(gallery_bit, 150));
                    //saveProfileAccount();
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }

        } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
            Toast.makeText(this, R.string.cropping_failed, Toast.LENGTH_LONG).show();
        }


    }


    public void removeAllStack() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.getBackStackEntryCount();
        for (int i = 0; i < fragmentManager.getBackStackEntryCount(); i++)
            fragmentManager.popBackStack();
    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showCommonDailog(Context context, String title, String message) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.comom_dialog, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();


        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView tvMessage = dialogView.findViewById(R.id.tvMessage);
        Button tvOk = dialogView.findViewById(R.id.btDone);
        RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);

        tvTitle.setText(title);
        tvMessage.setText(message);

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_background_inset));
            relSubMenu.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_header_background));
            GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
            drawable.setColor(ContextCompat.getColor(getApplicationContext(), R.color.filterToolbar));
        } else {
            relSubMenu.setBackgroundColor(ContextCompat.getColor(this, R.color.filterToolbar));
        }

        tvOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
            }
        });

        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    public void convertIntoCurrencyFormat(String amount, EditText editText) {
        try {
            Format format = NumberFormat.getNumberInstance(new Locale("en", "IN"));
            String str = format.format(Double.parseDouble(amount));
            editText.setText(str);
            editText.setSelection(editText.getText().toString().length());
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    private void reDirectMethod() {
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            } else {
                appConfigObject = new JSONObject();
            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        if (!mSession.getHasFirstTimeAppIntroLaunched() && ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2")))) {
            Intent intent = new Intent(getApplicationContext(), SingleIntroActivity.class);
            startActivity(intent);
            finish();
        } else if (!mSession.getHasFirstTimeAppIntroLaunched() && ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3")))) {
            Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
            startActivity(intent);
            finish();
        }else if (!mSession.getHasFirstTimeAppIntroLaunched() && ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6")))) {
            Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
            startActivity(intent);
            finish();
        } else {
            if (mCameFrom != null && mCalculatorToOpen != 0 && mCameFrom.equalsIgnoreCase("calculator")) {
                displayViewCalculator(mCalculatorToOpen, null);
            } else {
                Bundle bundle = new Bundle();
                bundle.putString("isAddBackToStack", "no");
                displayViewOther(1, bundle);
                openNotification();
            }
        }
    }

    private void openNotification(){
        if(getString(R.string.subdomain).equals("mint")) {
            return;
        }
        String source = "";
        if (mBundle==null){
            mBundle = getIntent().getExtras();
        }
        if (mBundle != null) {
            try {
                JSONObject json = new JSONObject(mBundle.getString("data", "{}"));
                source = json.optString("source", "");
            } catch (Exception ignored) {}
        }
        boolean isCrm = !TextUtils.isEmpty(source);
        boolean isLoggedIn = mSession.getHasLoging();
        if (isCrm && !isLoggedIn){
            CrmBuilder.createNotificationBundle(mBundle);
        }
        if ("notification".equalsIgnoreCase(mCallCommingFrom) && (!isCrm || isLoggedIn)) {
            displayViewOther(46, mBundle);
        }
    }
    public void getPublicInfo() {
        logD("getPublicInfo: called on BrokerActivity");
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_BROKER_PUBLIC_INFO + "brokerDomain=" + mSession.getUserBrokerDomain() + "&userBusinessCode=" + AppConstants.SUB_BROKER_BUSINESS_CODE;
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.OPEN_API, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        //jsonObject1.put("layout", "5");
                        mSession.setShowBseAuthPopup("1".equals(jsonObject1.optString("showBseAuthPopup").trim()));


                        mSession.setFutureProjectionCalculator(jsonObject1.optInt("futureProjectionCalculator"));
                        mSession.setSIPCalculator(jsonObject1.optInt("SIPCalculator"));

                        mSession.setAppLogoName(jsonObject1.optString("logo"));
                        mSession.setPlayStoreLink(jsonObject1.optString("androidAppLink"));
                        mSession.setAppStoreLink(jsonObject1.optString("iosAppLink"));
                        mSession.setForceUpdate(jsonObject1.optInt("majorUpdate")==1);
                        mSession.setCompanyName(jsonObject1.optString("compName"));
                        mSession.setOnBoarding(jsonObject1.optInt("allowOnboarding"));
                        mSession.setUserEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));

                        mSession.setAllowedMobileOTPLogin(jsonObject1.optInt("allowMobileOtpLogin"));
                        mSession.setWebsite(jsonObject1.optString("website").equalsIgnoreCase("null") ? "" : jsonObject1.optString("website"));
                        mSession.setMobileNumber(jsonObject1.optString("mobileNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("mobileNo1"));
                        mSession.setTelNumber(jsonObject1.optString("telNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("telNo1"));
                        mSession.setVoltPartnerCode(jsonObject1.optString("voltPartnerCode").equalsIgnoreCase("null") ? "" : jsonObject1.optString("voltPartnerCode"));
                        mSession.setIsRiskProfileMandatory(jsonObject1.optInt("isRiskProfileManadatory"));
                        mSession.setAllowedCrm(jsonObject1.optInt("allowCrm",0)==1);
                        String address = "";
                        address = UtilityKotlin.checkAndGetCompanyAddress(jsonObject1);
                        mSession.setAddress(address);
                        mSession.setCustomURL(jsonObject1.getString("customURL").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customURL"));

                        String domain = jsonObject1.optString("domain");
                        if (!domain.equalsIgnoreCase("null") && !domain.isEmpty()) {
                            mSession.setUserBrokerDomain(domain);
                        }
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
                            jsonObject1.put("layout", 6);
                        }
                        mSession.setAppInfo("" + jsonObject1);
                        setCustomLinksData(jsonObject1.getString("customLinks").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customLinks"));



                        String slogan = jsonObject1.optString("slogan");
                        if (!slogan.equalsIgnoreCase("null") && !slogan.isEmpty()) {
                            mSession.setSloganOnLogo(slogan);
                        }
                        try {
                            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                                appConfigObject = new JSONObject(mSession.getAppInfo());
                            } else {
                                appConfigObject = new JSONObject();
                            }
                        } catch (JSONException ignored) {

                        }
                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        mSession.setHasShowXirr(jsonObject1.optString("showXIRR").equals("1"));

                    }
                } catch (Exception ignored) {

                } finally {
                    reDirectMethod();
                }
            }
        });

    }


    private void setCustomLinksData(String data) {
        List<String> keywords = List.of(getString(R.string.txt_policies_agreements), getString(R.string.txt_grievance_redressal), getString(R.string.txt_legal_regulatory));
        JSONArray jsonArray = null;
        ArrayList<JSONObject> jsonObjects = new ArrayList<>();
        try {
            if (data.length() != 0) {
                jsonArray = new JSONArray(data);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String title = jsonObject.optString("title");
                    if (keywords.contains(title)) {
                        // matching keywords
                        jsonObjects.add(jsonObject);
                    }
                }
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        } finally {
            mSession.setCustomLinksForContactUs("" + jsonObjects);
        }
    }


    public void showLogOutAlert() {


        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    LogoutMethod();
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(
                this,
                getResources().getString(R.string.Confirm),
                getResources().getString(R.string.Are_you_sure_logout),
                getString(R.string.yes),
                getString(R.string.no),
                true,
                true
        );
    }


    private void LogoutMethod() {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.LOGOUT;
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.LOGOUT, new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading){
                    ProgressBarCommon.showDialog(BrokerActivity.this);
                }else{
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mApplication.goToLogin("logout");
            }
        });
    }


    public String setUsername(String name) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(name);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

    // for text Color
    public void changeColorBrokerDash(int index) {
        Boolean isActiveInactiveBothDiffColor = false;

        mTvMenu1.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
        mTvMenu2.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
        mTvMenu3.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
        mTvMenu4.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
        mTvMenu5.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));

        if (index == 1) mTvMenu1.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
        else if (index == 2)
            mTvMenu2.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
        else if (index == 3)
            mTvMenu3.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
        else if (index == 4)
            mTvMenu4.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
        else if (index == 5)
            mTvMenu5.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));

        if (!mSession.getAppConfig().isEmpty() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
            if (Utils.getConfigData(mSession).has("FeatureList") && Objects.requireNonNull(Utils.getConfigData(mSession).optJSONArray("FeatureList")).length() > 0) {
                JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
                for (int i = 0; i < sectionJSONArray.length(); i++) {
                    JSONObject jsonObject = sectionJSONArray.optJSONObject(i);
                    if (jsonObject.optString("FeatureName").equalsIgnoreCase("layout") && jsonObject.optString("AdditionalSetting").equalsIgnoreCase("2")) {
                        isActiveInactiveBothDiffColor = true;
                    }
                }
            }
        }

        if (!mSession.getAppConfig().isEmpty() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
            if (Utils.getConfigData(mSession).has("FeatureList") && Objects.requireNonNull(Utils.getConfigData(mSession).optJSONArray("FeatureList")).length() > 0) {
                JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
                for (int i = 0; i < sectionJSONArray.length(); i++) {
                    JSONObject jsonObject = sectionJSONArray.optJSONObject(i);
                    if (jsonObject.optString("FeatureName").equalsIgnoreCase("layout") && jsonObject.optString("AdditionalSetting").equalsIgnoreCase("2")) {
                        isActiveInactiveBothDiffColor = true;
                    }
                }
            }
        }
        changeImageColor(index, isActiveInactiveBothDiffColor);
    }

    // for Image color
    private void changeImageColor(int index, boolean isActiveInactiveBothDiffColor) {

        if(isActiveInactiveBothDiffColor){
            setSameIcon(mIvMenu1, R.mipmap.home, false);
            setSameIcon(mIvMenu2, R.mipmap.clients, false);
            setSameIcon(mIvMenu3, R.mipmap.aum, false);
            setSameIcon(mIvMenu4, R.mipmap.more, false);
            setSameIcon(mIvMenu5, R.mipmap.menu5, false);

            if (index == 1) setSameIcon(mIvMenu1, R.mipmap.home, true);
            else if (index == 2) setSameIcon(mIvMenu2, R.mipmap.clients, true);
            else if (index == 3) setSameIcon(mIvMenu3, R.mipmap.aum, true);
            else if (index == 4) setSameIcon(mIvMenu4, R.mipmap.more, true);
            else if (index == 5) setSameIcon(mIvMenu5, R.mipmap.menu5, true);

        } else {
            highlight(mIvMenu1, R.mipmap.home, false);
            highlight(mIvMenu2, R.mipmap.clients, false);
            highlight(mIvMenu3, R.mipmap.aum, false);
            highlight(mIvMenu4, R.mipmap.more, false);
            highlight(mIvMenu5, R.mipmap.menu5, false);

            if (index == 1) highlight(mIvMenu1, R.mipmap.home_active, true);
            else if (index == 2) highlight(mIvMenu2, R.mipmap.clients_active, true);
            else if (index == 3) highlight(mIvMenu3, R.mipmap.aum_active, true);
            else if (index == 4) highlight(mIvMenu4, R.mipmap.more_active, true);
            else if (index == 5) highlight(mIvMenu5, R.mipmap.menu5, true);
        }
    }

    private void setSameIcon(ImageView iv, int drawableid, boolean enable){
        Drawable drawable = ContextCompat.getDrawable(BrokerActivity.this, drawableid);
        iv.setImageDrawable(drawable);

    }

    void highlight(ImageView iv, int drawableid, boolean enable) {
        if (enable) {
            Drawable drawable = ContextCompat.getDrawable(this, drawableid);
            drawable.setColorFilter(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor), PorterDuff.Mode.SRC_ATOP);
            iv.setImageDrawable(drawable);

        } else {
            Drawable drawable = ContextCompat.getDrawable(this, drawableid);
            drawable.setColorFilter(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor), PorterDuff.Mode.SRC_ATOP);
            iv.setImageDrawable(drawable);
        }
    }

    /****************************************************
     * Method shows a common dialog throughout the app
     * @param context provide the context
     * @param title  specify the title
     * @param message specify the message
     *********************************************************/
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showCommonDialog(Context context, String title, String message) {
        if (getWindow() != null) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            @SuppressLint("InflateParams") View dialogView = inflater.inflate(R.layout.comom_dialog, null);
            dialogBuilder.setView(dialogView);
            final AlertDialog alertDialog = dialogBuilder.create();
            if (alertDialog != null && alertDialog.isShowing()) return;

            LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
            TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
            TextView tvMessage = dialogView.findViewById(R.id.tvMessage);
            tvTitle.setText(title);
            tvMessage.setText(message);

            Button tvOk = dialogView.findViewById(R.id.btDone);
            RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                if (alertDialog != null) {
                    Objects.requireNonNull(alertDialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                }
            }

            if (Build.VERSION.SDK_INT >= 21) {
                linerMain.setBackground(ContextCompat.getDrawable(context, R.drawable.dialog_background_inset));
                relSubMenu.setBackground(ContextCompat.getDrawable(context, R.drawable.dialog_header_background));
                GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
                drawable.setColor(ContextCompat.getColor(context, R.color.gray));
            } else {
                relSubMenu.setBackgroundColor(ContextCompat.getColor(context, R.color.gray));
            }


            tvOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (alertDialog != null) {
                        alertDialog.dismiss();
                    }
                }
            });
            if (alertDialog != null) {
                alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialogInterface) {
                    }
                });
            }

            if (alertDialog != null) {
                alertDialog.setCancelable(false);
                if (alertDialog.isShowing()) {
                    alertDialog.dismiss();
                } else {
                    alertDialog.show();
                }
            }


        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showCommonDownload(Context context, String title, String message, final String type, final File file, Uri uri) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.common_dailog3, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();


        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView tvMessage = dialogView.findViewById(R.id.heading);
        TextView tvShare = dialogView.findViewById(R.id.tvShare);
        TextView tvOpen = dialogView.findViewById(R.id.tvOpen);
        RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);

        tvTitle.setText(title);
        tvMessage.setText(message);

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_background_inset));
            relSubMenu.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_header_background));
            GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
            drawable.setColor(ContextCompat.getColor(getApplicationContext(), R.color.filterToolbar));
        } else {
            relSubMenu.setBackgroundColor(ContextCompat.getColor(this, R.color.filterToolbar));
        }

        tvShare.setOnClickListener(v -> {
            alertDialog.dismiss();
            // Uri imageUri = Uri.parse(file.getAbsolutePath());

            Uri imageUri = null;
            if (uri != null && !uri.toString().equals(""))
                imageUri = uri;
            else {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                    imageUri = Uri.fromFile(file);
                } else {
                    imageUri = FileProvider.getUriForFile(getApplicationContext(), com.iw.mint.sdk.BuildConfig.LIBRARY_PACKAGE_NAME + ".fileprovider", file);
                }
            }


            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_STREAM, imageUri);
            startActivity(Intent.createChooser(intent, "Share with"));
        });

        tvOpen.setOnClickListener(v -> {
            if (type.equals("pdf")) {
                Intent intentUrl = new Intent(Intent.ACTION_VIEW);
                if (uri != null && !uri.toString().equals("")) {
                    intentUrl.setDataAndType(uri, "application/" + type);
                } else {
                    Uri contentUri = FileProvider.getUriForFile(getBaseContext(), com.iw.mint.sdk.BuildConfig.LIBRARY_PACKAGE_NAME + ".fileprovider", file);
                    intentUrl.setDataAndType(contentUri, "application/pdf");
                }
                intentUrl.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intentUrl.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                try {
                    startActivity(intentUrl);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(BrokerActivity.this, getString(R.string.txt_no_pdf_viewer_installed), Toast.LENGTH_LONG).show();
                }
            } else if (type.equals("xls") || type.equals("vnd.ms-excel") || type.equals("jpg") || type.equals("jpeg") || type.equals("png")) {
                Intent intentUrl = new Intent(Intent.ACTION_VIEW);
                if (uri != null && !uri.toString().isEmpty()) {
                    intentUrl.setDataAndType(uri, "image/" + type);
                } else {
                    Uri contentUri = FileProvider.getUriForFile(getBaseContext(), com.iw.mint.sdk.BuildConfig.LIBRARY_PACKAGE_NAME + ".fileprovider", file);
                    intentUrl.setDataAndType(contentUri, "image/" + type);
                }
                intentUrl.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intentUrl.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                try {
                    startActivity(intentUrl);
                } catch (ActivityNotFoundException e) {
                    if (type.equals("vnd.ms-excel") || type.equals("xls"))
                        Toast.makeText(BrokerActivity.this, getString(R.string.txt_no_xls_viewer_installed), Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(BrokerActivity.this, getString(R.string.txt_no_image_viewer_installed), Toast.LENGTH_SHORT).show();
                }
            }

            alertDialog.dismiss();

        });

        //alertDialog.setCancelable(false);
        alertDialog.show();
    }




    @Override
    public void requestNotificationPermission() {
        if (!com.iw.mint.sdk.BuildConfig.IS_ENV_SDK){
            requestNotificationPermission(false);        }

    }

    public void requestNotificationPermission(boolean fromBanner) {
        permissionManager.requestPermission(fromBanner);
    }
    public boolean shouldShowNotification() {
       return permissionManager.shouldShowNotificationBanner();
    }
    public void userDidAction(String currentScreenName) {
        mSession.setActionCount(mSession.getActionCount() + 1);
        whenToShowAppReview(currentScreenName);
    }

    /**
     * app open days should be be 8
     * number of days the app has been opened at least once
     * app is opened multiple times in a same day, the count will only be 1
     * <p>
     * Actions/ Screen Visits
     * If the user does any of the below,
     * Visits Portfolio Report Screen
     * Does a transaction from anywhere // + response success
     * an action is considered. The action count should be 10
     * Rating should be shown in their respective homescreens / elegible
     * homescreens(Client,Sub broker,broker etc)
     * <p>
     * Rating Case
     * Rating Submitted
     * If the user submits a rating in , then the rating should not be shown to the user again.
     * Thumbs down Clicked
     * For such users, show the rating screen again after 20 app open days and continue the rating screen cycle.
     * Reset
     * For all other cases, reset the eligibility parameters and continue the rating screen cycle
     * <p>
     * close tab reset
     * don't show logo while mint app.
     *
     * @param screen contains screen name where in-app review will call
     */

    public void whenToShowAppReview(String screen) {
        if (screen == null || screen.isEmpty()) return;

        //  Never show again if already submitted
        if (mSession.getRatingSubmitted()) {
            return;
        }
        int noOfAppOpen = mSession.getCountOfAppOpen();
        int actionCount = mSession.getActionCount();
        boolean thumbsDownClicked = mSession.getThumbsDownClicked();
        // Count app open only once per day
        String today = Utils.getTodayDateString();
        String lastShownDate = mSession.getShownDateOfReview();
        if (lastShownDate == null || !lastShownDate.equals(today)) {
            noOfAppOpen++;
            mSession.setCountOfAppOpen(noOfAppOpen);
            mSession.setShownDateOfReview(today);
        }

        //  Thumbs down case → show after 20 open days
        if (thumbsDownClicked) {
            if (noOfAppOpen >= 20) {
                isReleventScreen(screen);
            }
            return;
        }

        //  Normal case → 8 app open days + 10 actions
        if (noOfAppOpen >= 8 && actionCount >= 10) {
            isReleventScreen(screen);
        }

    }

    private void isReleventScreen(String screen) {
        // show only respective screens
        if (!screen.equalsIgnoreCase("")) {
            reviewAndRating();
//            resetReviewParameters();
        }
    }

    private void resetReviewParameters() {
        mSession.setCountOfAppOpen(0);
        mSession.setActionCount(0);
        mSession.setThumbsDownClicked(false);
        mSession.setAskMeLater(false);
        mSession.setShownDateOfReview(null);
    }

    private boolean isSameDay(Date d1, Date d2) {
        SimpleDateFormat sdf =
                new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        return sdf.format(d1).equals(sdf.format(d2));
    }

    /**
     * @implNote reviewAndRating() will call while review condition is meet
     * @see
     */

    public void reviewAndRating() {
        BottomSheetDialog bottomSheet = new BottomSheetDialog(this, R.style.Bottom_Sheet_Style);
        bottomSheet.setContentView(R.layout.layout_new_review);
        // init view
        ImageView mRLogo = bottomSheet.findViewById(R.id.ivLogo);
        ImageView mRClose = bottomSheet.findViewById(R.id.iv_close);
        ImageView ivDislike = bottomSheet.findViewById(R.id.ivDislike);
        ImageView ivLike = bottomSheet.findViewById(R.id.ivLike);
        LinearLayout ll_review_suggestion = bottomSheet.findViewById(R.id.ll_review_suggestion);
        LinearLayout ll_review_main = bottomSheet.findViewById(R.id.ll_review_main);
        // hide logo in-case of mint app
        if (getString(R.string.subdomain).equals("mint")) {
            mRLogo.setVisibility(View.GONE);
        } else {
            int squareLogo = UtilityKotlin.checkExistResources("app_logo_square", "mipmap", this);
            int circleLogo = UtilityKotlin.checkExistResources("app_logo_round", "mipmap", this);
            if (squareLogo != 0) {
                mRLogo.setImageResource(squareLogo);
            } else if (circleLogo != 0) {
                mRLogo.setImageResource(circleLogo);
            } else {
                mRLogo.setImageResource(R.mipmap.app_logo);
            }
        }
        Window window = getWindow();
        window.setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.alpha = 1.0f;
        lp.dimAmount = 0.0f;
        window.setAttributes(lp);

        mRClose.setOnClickListener(view -> {
            bottomSheet.dismiss();
            resetReviewParameters();
        });

        ivDislike.setOnClickListener(view -> {
            ll_review_main.setVisibility(View.GONE);
            ll_review_suggestion.setVisibility(View.VISIBLE);
            mSession.setThumbsDownClicked(true);
            // Start 20-day new cycle
            mSession.setCountOfAppOpen(0);
            mSession.setActionCount(0);
        });
        ivLike.setOnClickListener(view -> {
//            mSession.setRatingSubmitted(true);
            bottomSheet.dismiss();
            reviewRequest();
        });
//        mSession.setHasFirstTimeReviewShown(true);

        bottomSheet.setCancelable(false);
        bottomSheet.show();
    }


    private void reviewRequest() {
        Task<ReviewInfo> request = reviewManager.requestReviewFlow();
        request.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                reviewInfo = task.getResult();
                Task<Void> flow =
                        reviewManager.launchReviewFlow(this, reviewInfo);
                flow.addOnCompleteListener(task2 -> {
                    // Google does not confirm actual submission.
                    // Once flow completes, consider review done.
                    mSession.setRatingSubmitted(true);
                    onReviewSubmitted();
                });
            } else {
                onReviewSubmissionFailed();
            }
        });
        request.addOnFailureListener(e -> onReviewSubmissionFailed());

    }

    /***
     *  Display the in-app review dialog
     *  get submitted and failed
     */
    private void onReviewSubmitted() {
        // Never show again
        resetReviewParameters();
    }

    private void onReviewSubmissionFailed() {

//        resetReviewParameters();
    }

    private void showToast(String message){
        Toast.makeText(BrokerActivity.this,message , Toast.LENGTH_SHORT).show();
    }
    public void callVoltApi(){
        try {
            String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.BROKER_VOLT;
            JSONObject paramObject = new JSONObject();
            paramObject.put("bid",mSession.getBid());

            KtorCallBack ktorCallBack = new KtorCallBack() {
                @Override
                public void onLoading(boolean isLoading) {
                    KtorCallBack.super.onLoading(isLoading);
                    if(isLoading){
                        ProgressBarCommon.showDialog(BrokerActivity.this);
                    }else {
                        ProgressBarCommon.dismissDialog();
                    }
                }

                @Override
                public void onSuccess(String response, int statusCode) {
                    try {
                        JSONObject responseObject = new JSONObject(response);
                        if (responseObject.optInt("status") == 0) {
                            JSONObject jsonObjectMain = responseObject.optJSONObject("result");
                            if (jsonObjectMain !=null){
                                String voltLoginUrl = jsonObjectMain.optString("loginUrl");
                                Intent intent = new Intent(BrokerActivity.this, WebViewActivity.class);
                                intent.putExtra("title",getString(R.string.txt_loan_against_mf));
                                intent.putExtra("url",voltLoginUrl);
                                startActivity(intent);
                            }

                        }else {
                            showToast(responseObject.optString("message"));
                        }


                    }catch (Exception e){}
                }
                @Override
                public void onError(String error, int statusCode) {
                    showToast(error);
                }
            };
            KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, paramObject, AppHeaderType.AFTER_LOGIN, ktorCallBack);

        }catch (Exception e){logD(e);}
    }

}
