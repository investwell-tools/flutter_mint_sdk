package investwell.broker.bseOnboarding;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;

public class BrokerBse_ChequeAdapter extends RecyclerView.Adapter<BrokerBse_ChequeAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;
private AppSession mSession;

    public BrokerBse_ChequeAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public BrokerBse_ChequeAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.broker_bse_checque_sig_adapter, viewGroup, false);
        mSession=AppSession.getInstance(mContext);
        return new BrokerBse_ChequeAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final BrokerBse_ChequeAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int pos, JSONObject jsonObject, String type);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView  tvNameType, tvName, tvAccPan;
        ImageView mIvCheck, mIvUpload;

        public ViewHolder(View view) {
            super(view);
            mIvCheck = view.findViewById(R.id.iv_check);
            mIvUpload = view.findViewById(R.id.iv_upload);

            tvNameType = view.findViewById(R.id.tvNameType);
            tvName = view.findViewById(R.id.tvName);
            tvAccPan = view.findViewById(R.id.tvAccPan);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                final JSONObject jsonObject = mDataList.get(position);

                if (jsonObject.optBoolean("isSubmitted")) {
                    mIvCheck.setImageResource(R.drawable.check_green);
                    mIvUpload.setImageResource(R.drawable.reload);
                } else {
                    mIvCheck.setImageResource(R.drawable.check_gray);
                    mIvUpload.setImageResource(R.drawable.upload);
                }

                tvName.setText(jsonObject.optString("bankName"));
                tvAccPan.setText(jsonObject.optString("accountNo"));

                mIvUpload.setOnClickListener(view -> listener.onItemClick(position, jsonObject, "cheque"));
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
