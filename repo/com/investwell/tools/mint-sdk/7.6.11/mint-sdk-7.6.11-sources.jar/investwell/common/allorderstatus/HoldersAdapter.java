package investwell.common.allorderstatus;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.Utils;

public class HoldersAdapter extends RecyclerView.Adapter<HoldersAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private HoldersAdapter.OnItemClickListener listener;
    boolean mIsHideButton;
    private String mType = "";

    public HoldersAdapter(Context context, ArrayList<JSONObject> list, HoldersAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public HoldersAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.ucc_holder_items, viewGroup, false);
        return new HoldersAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final HoldersAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject status);

        void onProfileItemClick(int position);

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAuthenticate, tvName, tvType;
        View viewLine;
        RelativeLayout relAuth;
        ProgressBar pbLoader;

        public ViewHolder(View view) {
            super(view);
            tvAuthenticate = view.findViewById(R.id.tvAuthenticate);
            viewLine = view.findViewById(R.id.viewLine);
            tvName = view.findViewById(R.id.tvName);
            tvType = view.findViewById(R.id.tvType);
            pbLoader = view.findViewById(R.id.pbLoader);
            relAuth = view.findViewById(R.id.relAuth);

        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final HoldersAdapter.OnItemClickListener listener) {
            try {
                final JSONObject jsonObject = mDataList.get(position);

                tvName.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                tvType.setText(jsonObject.optString("holderType"));

                if (mType.equalsIgnoreCase("alreadyAuthByWeb")) {
                    relAuth.setVisibility(View.GONE);
                } else {
                    relAuth.setVisibility(View.VISIBLE);
                    if (jsonObject.has("isAuthenticate")) {
                        if (jsonObject.optBoolean("isAuthenticate")) {
                            tvAuthenticate.setBackgroundResource(R.drawable.broder_rounded_orange2);
                            tvAuthenticate.setTextColor(ContextCompat.getColor(mContext, R.color.dailog_color));
                            pbLoader.setVisibility(View.GONE);
                        } else {
                            tvAuthenticate.setBackgroundResource(R.drawable.edittext_square3);
                            tvAuthenticate.setTextColor(ContextCompat.getColor(mContext, R.color.gray));
                            if (mIsHideButton) {
                                pbLoader.setVisibility(View.GONE);
                                tvAuthenticate.setVisibility(View.GONE);
                            } else {
                                pbLoader.setVisibility(View.VISIBLE);
                                tvAuthenticate.setVisibility(View.VISIBLE);
                            }
                        }
                    } else {
                        pbLoader.setVisibility(View.GONE);
                    }
                    tvAuthenticate.setOnClickListener(v -> listener.onProfileItemClick(position));
                }

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }


        }

    }

    public void updateList(List<JSONObject> list, boolean isHideBotton, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mIsHideButton = isHideBotton;
        mType = type;
        notifyDataSetChanged();
    }


}

