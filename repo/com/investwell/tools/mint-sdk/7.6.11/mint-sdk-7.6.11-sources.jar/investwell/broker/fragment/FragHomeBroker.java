package investwell.broker.fragment;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.UtilityKotlin.applyAccessibilityList;
import static investwell.utils.UtilityKotlin.hasReAuthTimeNotValid;
import static investwell.utils.UtilityKotlin.isDarkTheme;
import static investwell.utils.UtilityKotlin.showSnackbar;
import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.accessibility.AccessibilityManager;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.activity.DomainActivity;
import investwell.activity.LoginActivity;
import investwell.activity.ShareDeepLinkActivity;
import investwell.activity.WebActivity;
import investwell.activity.WebViewActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.broker.adapter.LeadsAdapter;
import investwell.charts.mikephil.charting.charts.PieChart;
import investwell.charts.mikephil.charting.data.PieData;
import investwell.charts.mikephil.charting.data.PieDataSet;
import investwell.charts.mikephil.charting.data.PieEntry;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.ElssRetirement;
import investwell.client.adapter.ElssRetirementAdapter;
import investwell.client.adapter.OnElssRetirementClick;
import investwell.common.debugmode.DebugActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.common.newCalculator.ui.NewCalculatorActivity;
import investwell.common.newCalculator.domain.model.CalculatorType;
import investwell.common.nfo.NfoActivity;
import investwell.common.onboarding.marketupdate.MarketUpdateActivity;
import investwell.common.permissions.PermissionHandlerViewModel;
import investwell.common.topscheme.TopSchemeActivity;
import investwell.mintSdk.MintAppConfiguration;
import investwell.textview.AppTextView;
import investwell.textview.AppTextViewTitle;
import investwell.utils.ApiRequestType;
import investwell.utils.AppConstants;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.CrmBuilder;
import investwell.utils.CrmLeadsItem;
import investwell.utils.CrmPage;
import investwell.utils.Extensions;
import investwell.utils.ExtensionsKt;
import investwell.utils.FilterType;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.TimeDateUtils;
import investwell.utils.UtilityKotlin;
import investwell.utils.customView.ZoomClass;
import kotlin.Unit;


public class FragHomeBroker extends BaseFragment implements View.OnClickListener, OnElssRetirementClick {
    private View view;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private LinearLayout mCardView;
    private LinearLayout mLinerWithoutLogin, llUpdation;
    private RelativeLayout rl_calculators;
    private TextView tvAUM, tvInvestor, tvSip, tvSipPerMonth, tvAsOndate;
    private MaterialButton mTvReadMore;
    private AppTextView mTvSpecialMsg;
    private final String mSearchType = "Group";
    private TextView mTvUserName;
    private ImageView ivCrossMsg;
    private LinearLayout mllCalculator, mLlCross;
    private View mContentSpecialMsgView;
    private String specialMsgUrl = "";
    private FrameLayout fl_notifications;
    private View includeNotificationBanner;
    private TextView tv_notification_badge, tvLavelSipPerMonth, tvLavelSipNo;
    private int mClickCount = 0;
    private ApiDataBase db;
    private SwipeRefreshLayout swipeRefreshLayout;
    private TextView mTvFundPick;
    String localImagePath = "";
    private RecyclerView rvElssRetirement;
    private ElssRetirementAdapter elssRetirementAdapter;
    private List<ElssRetirement> elssRetirementArrayList;
    private AccessibilityManager accessibilityManager;
    private AccessibilityManager.AccessibilityStateChangeListener accessibilityListener;


    private LinearLayout llCrmMain;
    private RecyclerView rvLeads;
    private LeadsAdapter mLeadsAdapter;

    private boolean isCrmTasksEmpty =false,isCrmLeadsEmpty=false;
    private JSONObject crmTaskJsonObject = new JSONObject();
    private JSONObject crmLeadJsonObject = new JSONObject();
    private ArrayList<CrmLeadsItem> leadsData  = new ArrayList<>();
    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(

                url,
                req,
                res,
                AppConstants.HOME_WITHOUT,
                dateTime,
                endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    private String crmUID="",crmLevelNo="";
    private PermissionHandlerViewModel permissionViewModel;


    @Override
    public void onResume() {
        super.onResume();
        permissionViewModel.updatePermissionStatus(requireActivity());
    /*    if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onStart() {
        super.onStart();
        System.out.println("MintLifeCycleLog FragBroker");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        ProgressBarCommon.dismissDialog();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            CrmBuilder.init(mSession);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            CrmBuilder.init(mSession);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        if (view == null) view = inflater.inflate(R.layout.frag_home, container, false);
        permissionViewModel  = new ViewModelProvider(this).get(PermissionHandlerViewModel.class);
        if (mBrokerActivity != null) {
            db = ApiDataBase.getInstance(mBrokerActivity.getApplicationContext());
//                mBrokerActivity.notificationPermission();
        } else {
            db = ApiDataBase.getInstance(mMainActivity.getApplicationContext());
//                mMainActivity.notificationPermission();
        }
        mTvFundPick = view.findViewById(R.id.tv_invest_fund_picks_title);
        llCrmMain = view.findViewById(R.id.llCrmMain);
        rvLeads = view.findViewById(R.id.rvLeads);

        llUpdation = view.findViewById(R.id.llUpdation);
        rvElssRetirement = view.findViewById(R.id.rv_elss_retirement);

        ImageView ivBack = view.findViewById(R.id.ivLeft);
        if (MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()){
            ivBack.setVisibility(View.GONE);
        }else {
            ivBack.setVisibility(View.VISIBLE);
        }
        ivBack.setOnClickListener(v -> mBrokerActivity.handleCustomBackLogic());


        LinearLayoutManager layoutManager
                = new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false);
        rvElssRetirement.setLayoutManager(layoutManager);

        mTvFundPick.setText(R.string.fund_picks);
        mContentSpecialMsgView = view.findViewById(R.id.content_dashboard_special_message);
        mTvSpecialMsg = mContentSpecialMsgView.findViewById(R.id.tv_special_message);
        mTvReadMore = mContentSpecialMsgView.findViewById(R.id.tvReadMore);
        mLlCross = mContentSpecialMsgView.findViewById(R.id.llCross);
        ivCrossMsg = mContentSpecialMsgView.findViewById(R.id.ivCross);
        tvLavelSipPerMonth = view.findViewById(R.id.tvLavelSipPerMonth);
        tvLavelSipNo = view.findViewById(R.id.tvLavelSipNo);
        rl_calculators = view.findViewById(R.id.rl_calculators);

        tv_notification_badge = view.findViewById(R.id.tv_notification_badge);
        fl_notifications = view.findViewById(R.id.fl_notifications);
        fl_notifications.setOnClickListener(this);
        view.findViewById(R.id.iv_notification).setOnClickListener(this);

        includeNotificationBanner = view.findViewById(R.id.includeNotificationBanner);
        AppTextView tvNotificationDisabledMessage = includeNotificationBanner.findViewById(R.id.tvNotificationDisabledMessage);
        String text = getString(R.string.notification_disabled_banner_text) + " " + getString(R.string.enable_now);
        tvNotificationDisabledMessage.setText(text);
        includeNotificationBanner.findViewById(R.id.ivNotificationDisabledClose).setOnClickListener(this);
        ExtensionsKt.setClickableText(
                tvNotificationDisabledMessage,
                tvNotificationDisabledMessage.getText().toString(),
                getString(R.string.enable_now),
                () -> {
                    mBrokerActivity.requestNotificationPermission(true);
                    return Unit.INSTANCE;
                }
        );


        swipeRefreshLayout = view.findViewById(R.id.swipe_layout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(false);
                Calendar calendar = Calendar.getInstance();
                mApplication.sRefreshTimeBrokerDashBoard = calendar.getTimeInMillis();
                if (mSession.getHasLoging()) {
                    getBrokerSummery();
                }
            }
        });


        JSONObject appConfigObject = null;
        try {
            appConfigObject = new JSONObject(mSession.getAppInfo());
            /* if (!getString(R.string.subdomain).equals("mint")) {*/
            if (!TextUtils.isEmpty(appConfigObject.optString("specialMessage")) && !appConfigObject.optString("specialMessage").equalsIgnoreCase("null")) {
                mContentSpecialMsgView.setVisibility(View.VISIBLE);
            } else {
                mContentSpecialMsgView.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(appConfigObject.optString("specialMessage")) && !appConfigObject.optString("specialMessage").equalsIgnoreCase("null")) {
                mTvSpecialMsg.setVisibility(View.VISIBLE);
                mTvSpecialMsg.setText(appConfigObject.optString("specialMessage"));
            } else {
                mTvSpecialMsg.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(appConfigObject.optString("specialMessageLink")) && !appConfigObject.optString("specialMessageLink").equalsIgnoreCase("null")) {
                mTvReadMore.setVisibility(View.VISIBLE);
                specialMsgUrl = appConfigObject.optString("specialMessageLink");
            } else {
                mTvReadMore.setVisibility(View.GONE);
            }
            if (((!appConfigObject.optString("popupMessage").isEmpty() && !appConfigObject.optString("popupMessage").equalsIgnoreCase("null")) ||
                    (!appConfigObject.optString("popupURL").isEmpty() && !appConfigObject.optString("popupURL").equalsIgnoreCase("null"))
                    || (!appConfigObject.optString("popupImagePath").isEmpty() &&
                    !appConfigObject.optString("popupImagePath").equalsIgnoreCase("null")))) {

                localImagePath = appConfigObject.optString("popupImagePath");
                if (!localImagePath.equals(mSession.getShowDialogByCurrentDate())) {
                    if (!mSession.getHasLoging()) {
                        showPopUpDialog(appConfigObject);
                    } else {
                       /* if (mSession.getHasLoging()){
                            showPopUpDialog(appConfigObject);
                        }*/
                        if (!Config.sOncePopupPerLoginSession) {
                            showPopUpDialog(appConfigObject);
                            Config.sOncePopupPerLoginSession = true; // reson is that when close without check then
                            // sOncePopupPerLoginSession= true so thats why it will never call method while the user not checked that's no need to call
                        }
                    }

                }
            }
            /*}*/
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        setUpInvestRouteStaticUi();
        setDynamicLavelName();

        mCardView = view.findViewById(R.id.cardWithValue);
        mLinerWithoutLogin = view.findViewById(R.id.linerWithoutLogin);
        tvAUM = view.findViewById(R.id.market_value);
        tvInvestor = view.findViewById(R.id.purchase_cost);
        tvSipPerMonth = view.findViewById(R.id.days_change);
        tvSip = view.findViewById(R.id.gain);
        mTvUserName = view.findViewById(R.id.tvName);
        tvAsOndate = view.findViewById(R.id.asOndate);
        ImageView ivAppLogo = view.findViewById(R.id.ivAppLogo);
        mllCalculator = view.findViewById(R.id.llCalculator);


        //no need of permission for calculatorFra in broker dashboard according to pm rabab
//        try {
//            appConfigObject = new JSONObject(mSession.getAppInfo());
//            String futureProjectionCalculator = appConfigObject.optString("futureProjectionCalculator");
//            if (futureProjectionCalculator.isEmpty() || futureProjectionCalculator.equalsIgnoreCase("null")) {
//                mllCalculator.setVisibility(View.VISIBLE);
//            } else if (futureProjectionCalculator.equalsIgnoreCase("1")) {
//                mllCalculator.setVisibility(View.VISIBLE);
//            } else {
//                mllCalculator.setVisibility(View.GONE);
//            }
//
//        } catch (Exception e) {
//            mllCalculator.setVisibility(View.VISIBLE);
//        }

        String imagePath = mSession.getAppLogo();
        // String imagePath = Config.IMAGE_PATH_SMALL +mSession.getUserBrokerDomain() + "_Logo.png";
        setTintColorIfDark(requireActivity(), ivAppLogo);

        ivAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getString(R.string.subdomain).equals("mint")) {
            fl_notifications.setVisibility(View.INVISIBLE);
            if (!imagePath.equals("")) {
                Picasso.get().load(imagePath)
                        .error(R.drawable.app_logo_secondry_mint).into(ivAppLogo);
            } else {
                ivAppLogo.setImageResource(R.drawable.app_logo_secondry_mint);
            }
        } else {
            fl_notifications.setVisibility(View.VISIBLE);
            ivAppLogo.setImageResource(R.mipmap.app_logo_secondry);
        }
        if (BuildConfig.IS_ENV_SDK){
            fl_notifications.setVisibility(View.GONE);
        }


        view.findViewById(R.id.login_btn).setOnClickListener(this);
        view.findViewById(R.id.signup_btn).setOnClickListener(this);
        // ivRight.setOnClickListener(this);
        view.findViewById(R.id.sip_cal).setOnClickListener(this);
        view.findViewById(R.id.lumpsum_cal).setOnClickListener(this);
        view.findViewById(R.id.cost_cal).setOnClickListener(this);
        view.findViewById(R.id.education_cal).setOnClickListener(this);
        view.findViewById(R.id.marriage_cal).setOnClickListener(this);
        view.findViewById(R.id.retirement_cal).setOnClickListener(this);
        view.findViewById(R.id.tvSipPlanner).setOnClickListener(this);
        view.findViewById(R.id.tvSwpPlanner).setOnClickListener(this);
        view.findViewById(R.id.tvStpPlanner).setOnClickListener(this);
        view.findViewById(R.id.sip_tenure).setOnClickListener(this);
        view.findViewById(R.id.tvEmiCal).setOnClickListener(this);
        view.findViewById(R.id.tvStepUpCal).setOnClickListener(this);
        view.findViewById(R.id.tvSTPCalculator).setOnClickListener(this);
        view.findViewById(R.id.tvSWPCalculator).setOnClickListener(this);
        view.findViewById(R.id.ivRefresh).setOnClickListener(this);
        view.findViewById(R.id.rl_additional_sec_container).setOnClickListener(this);

        int imageId = UtilityKotlin.checkExistResources("step_up_cal", "mipmap", requireActivity());
        if (imageId != 0) {
            TextView tvTenure = view.findViewById(R.id.tvStepUpCal);
            tvTenure.setCompoundDrawablesWithIntrinsicBounds(0, imageId, 0, 0);
        }

        view.findViewById(R.id.iv_contact_us).setOnClickListener(this);
        mTvReadMore.setOnClickListener(this);
        mLlCross.setOnClickListener(this);
        ivCrossMsg.setOnClickListener(this);
        if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
            if (!getString(R.string.subdomain).equals("mint")) {
                if (!mSession.getHasLoging())
                    view.findViewById(R.id.iv_contact_us).setVisibility(View.VISIBLE);
                else
                    view.findViewById(R.id.iv_contact_us).setVisibility(View.VISIBLE);
            } else {
                view.findViewById(R.id.iv_contact_us).setVisibility(View.VISIBLE);
            }
        } else {
            view.findViewById(R.id.iv_contact_us).setVisibility(View.VISIBLE);
        }

        if (mSession.getUserBrokerDomain().equals(""))
            view.findViewById(R.id.iv_contact_us).setVisibility(View.GONE);


       /* if (mSession.getLead().equalsIgnoreCase("1")) {
            view.findViewById(R.id.ll_profile_not_complete).setVisibility(View.VISIBLE);
            view.findViewById(R.id.ll_profile_not_complete).setOnClickListener(this);

        } else {
            view.findViewById(R.id.ll_profile_not_complete).setVisibility(View.GONE);
        }*/
        if (mSession.getOnBoarding() == 1) {
            view.findViewById(R.id.signup_btn).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.signup_btn).setVisibility(View.GONE);

        }
        view.findViewById(R.id.cl_latest_nav).setOnClickListener(this);
        view.findViewById(R.id.cl_market_update).setOnClickListener(this);
        view.findViewById(R.id.cl_top_sip_scheme).setOnClickListener(this);
        view.findViewById(R.id.cl_top_scheme).setOnClickListener(this);
        view.findViewById(R.id.cl_fund_picks).setOnClickListener(this);
        view.findViewById(R.id.cl_nfo).setOnClickListener(this);
        if (mSession.getHasLoging() && mSession.getOnBoarding() == 1) {
            view.findViewById(R.id.cl_refer).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.cl_refer).setVisibility(View.GONE);

        }

        view.findViewById(R.id.cl_refer).setOnClickListener(v -> generateShortUrl());
        if (view.findViewById(R.id.cl_refer).getVisibility() == View.VISIBLE) {
            view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);
        }
        notificationCount();

        accessibilityManager = (AccessibilityManager) requireContext().getSystemService(Context.ACCESSIBILITY_SERVICE);

        if (accessibilityManager != null) {

            accessibilityListener = enabled -> {
                if (!enabled) {
                    ivAppLogo.setOnClickListener(v -> {
                        if (mSession.getEnableDebug()) {
                            UtilityKotlin.showDebugModeLoading(mBrokerActivity);
                            new Handler().postDelayed(() -> startActivity(new Intent(mBrokerActivity, DebugActivity.class)), 3000);

                        } else {
                            mClickCount = mClickCount + 1;
                            if (mClickCount == 50) {
                                UtilityKotlin.launchDebugMode(mBrokerActivity);
                                mClickCount = 0;
                            }
                        }
                    });
                }
            };

            accessibilityManager.addAccessibilityStateChangeListener(accessibilityListener);
        }
        ViewCompat.setAccessibilityDelegate(ivAppLogo, new AccessibilityDelegateCompat() {
            @Override
            public void onInitializeAccessibilityNodeInfo(
                    View host, AccessibilityNodeInfoCompat info) {
                super.onInitializeAccessibilityNodeInfo(host, info);

                info.setClassName(ImageView.class.getName());
                info.setRoleDescription("Image");
            }
        });
        if (mSession.getAllowedCrm() && mSession.getHasLoging()){
            checkCrmPermissions();
        }
        updateApiData();

        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }
//        checkCalculatorPermission();
        checkLoanAgainstMfPermission();


        applyAccessibilityList(view.findViewById(R.id.rl_investment_routes_container));
        applyAccessibilityList(view.findViewById(R.id.rl_sec_container));

        leadsInit();
        observePermission();

        if(!isDarkTheme(requireContext()))
            mCardView.setBackgroundResource(R.mipmap.card_blank);

        return view;

    }

    private void observePermission() {
        permissionViewModel.isPermissionGrantedLiveData().observe(getViewLifecycleOwner(), this::updateBellIcon);
    }

    private void updateBellIcon(boolean isGranted) {
        ImageView ivNotification =view.findViewById(R.id.iv_notification);
        if (isGranted) {
            ivNotification.setImageResource(R.mipmap.ic_app_notification);
        }else{
            ivNotification.setImageResource(R.mipmap.ic_app_notification_red);
            ivNotification.clearColorFilter();
            ImageViewCompat.setImageTintList(ivNotification, null);
            ivNotification.clearColorFilter();
            ivNotification.invalidate();
            ivNotification.requestLayout();
        }
        boolean isCustomApp = !getString(R.string.subdomain).equals("mint");
        if (isCustomApp && !isGranted && mBrokerActivity.shouldShowNotification()) {
            includeNotificationBanner.setVisibility(View.VISIBLE);
        }
        else{
            includeNotificationBanner.setVisibility(View.GONE);
        }
    }


    private void leadsInit(){
    try {
        mLeadsAdapter = new LeadsAdapter(requireActivity(), (position, filterType) ->
                CrmBuilder.openCrmApp(CrmPage.LEADS,filterType,false,requireActivity(),startForCrmResult)
        );
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 2);
        rvLeads.setLayoutManager(gridLayoutManager);
        rvLeads.setHasFixedSize(true);
        rvLeads.setAdapter(mLeadsAdapter);
    } catch (Exception e) {
        if (BuildConfig.DEBUG) e.printStackTrace();
    }
}

    private void checkCrmPermissions(){
        if (hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = CrmBuilder.prepareCrmBaseUrl() +Config.CRM_GET_LOGGED_IN;

        KtorCallBack mCallback =new KtorCallBack() {
            @Override
            public void onSuccess(String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    int status = jsonObject.optInt("status",-1);
                    if (status==0){
                        JSONObject objectResult = jsonObject.optJSONObject("result");
                        if (objectResult !=null){
                            crmUID =objectResult.optString("uid","");
                            crmLevelNo =objectResult.optString("levelNo","");
                            brokerCrmSetUp();
                        }
                    }else if (status==-1){
                        crmUID="";
                        crmLevelNo="";
                        showSnackbar(llCrmMain,jsonObject.optString("message"));
                    }
                    else{
                        showSnackbar(llCrmMain,jsonObject.optString("message"));
                    }
                }catch (Exception e){}
            }

            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                showHideLoader(isLoading);
            }
        };
        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, mCallback);


        }

    private ActivityResultLauncher<Intent> startForCrmResult =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == Activity.RESULT_OK) {
                            brokerCrmSetUp();
                        }
                    }
            );
    private void brokerCrmSetUp(){
        if (view == null || !isAdded()) {
            return;
        }
        if (!mSession.getHasLoging() || !"broker".equalsIgnoreCase(mSession.getLoginType())) {
            llCrmMain.setVisibility(View.GONE);
            return;
        }
        if (crmUID.equalsIgnoreCase("") && crmLevelNo.equalsIgnoreCase("")){
            llCrmMain.setVisibility(View.GONE);
        }

        llCrmMain.setVisibility(View.VISIBLE);
        view.findViewById(R.id.ivLeads).setOnClickListener(this);
        view.findViewById(R.id.layoutLeadHeader).setOnClickListener(this);
        view.findViewById(R.id.emptyTaskCard).setOnClickListener(this);
        view.findViewById(R.id.emptyLeadCard).setOnClickListener(this);
        view.findViewById(R.id.ivTasks).setOnClickListener(this);
        view.findViewById(R.id.layoutTaskHeader).setOnClickListener(this);
        fetchBrokerTasksSummary();
        fetchBrokerLeadsSummary();
    }


    private void setEmptyTaskView(){
        if(!isAdded()) return;
        view.findViewById(R.id.emptyTaskCard).setVisibility(View.VISIBLE);
        view.findViewById(R.id.cvTasks).setVisibility(View.GONE);
        setCrmEmptyStateContent(
                R.id.emptyTaskCard,
                getString(R.string.txt_create_your_tasks),
                getString(R.string.txt_plan_your_day_and_complete_tasks_efficiently),
                R.drawable.ic_crm_tasks
        );
    }
    private void setEmptyLeadsView(){
        if(!isAdded()) return;
        view.findViewById(R.id.cvLeads).setVisibility(View.GONE);
//        Extensions.setOpacityPercent(view.findViewById(R.id.cvLeads),6);
        view.findViewById(R.id.emptyLeadCard).setVisibility(View.VISIBLE);
        setCrmEmptyStateContent(
                R.id.emptyLeadCard,
                getString(R.string.txt_add_leads),
                getString(R.string.txt_start_tracking_and_converting_today),
                R.drawable.ic_crm_leads
        );
    }
    private void showHideLoader(boolean isLoading){
       // no need to show loader
        /*if (!isAdded()) return;
        if (isLoading){
            ProgressBarCommon.showDialog(requireActivity());
        }else{
            ProgressBarCommon.dismissDialog();
        }*/
    }

    private void fetchBrokerTasksSummary() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = CrmBuilder.prepareCrmBaseUrl() +Config.CRM_GET_TASKS_SUMMARY +"selectedUser="
                + CrmBuilder.preparedCrmSelectedUser(crmUID,crmLevelNo) + "&tasksSummary=1";
        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                boolean hasData = false;
                try {
                    crmTaskJsonObject = new JSONObject();
                    JSONObject jsonObject = new JSONObject(response);
                    int status = jsonObject.optInt("status",-1);
                    if (status==0){
                        JSONArray resultArray = jsonObject.optJSONArray("result");
                        if (resultArray != null && resultArray.length() > 0) {
                            crmTaskJsonObject = resultArray.optJSONObject(0);
                            hasData = hasTaskData(crmTaskJsonObject);
                            isCrmTasksEmpty = !hasData;
                        } else {
                            isCrmTasksEmpty = true;
                        }
                    }else if (status==-1){
                        showSnackbar(llCrmMain,jsonObject.optString("message"));
                    }
                    else{
                        showSnackbar(llCrmMain,jsonObject.optString("message"));
                    }
                } catch (Exception ignored) {}
                finally {
                    if (crmTaskJsonObject != null && hasData) {
                        setCrmTaskCard(crmTaskJsonObject);
                    } else {
                        setEmptyTaskView();
                    }
                }
            }

            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                showHideLoader(isLoading);
            }
        });
    }

    /***
     * check statusSummary all keys and dueSummary - total unresolved
     * @param result
     * @return
     */

    private boolean hasTaskData(JSONObject result) {
        if (result == null) return false;

        JSONObject statusSummary = result.optJSONObject("statusSummary");
        JSONObject dueSummary = result.optJSONObject("dueSummary");

        boolean hasStatusData = statusSummary != null &&
                (statusSummary.optInt("pending", 0) > 0 ||
                        statusSummary.optInt("inProgress", 0) > 0 ||
                        statusSummary.optInt("onHold", 0) > 0);
        boolean hasDueData = dueSummary != null && dueSummary.optInt("totalUnresolved", 0) > 0;
        return hasStatusData || hasDueData;
    }
    private boolean hasLeadsData(JSONObject result) {
        if (result == null) return false;
        JSONArray todayArray = result.optJSONArray("todaySummary");
        if (todayArray == null || todayArray.length() == 0) return false;

        JSONObject todaySummary = todayArray.optJSONObject(0);
        if (todaySummary == null) return false;

        return todaySummary.optInt("convertedToday", 0) > 0 ||
                todaySummary.optInt("lostToday", 0) > 0 ||
                todaySummary.optInt("receivedToday", 0) > 0 ||
                todaySummary.optInt("totalPending", 0) > 0;
    }



    @SuppressLint("ClickableViewAccessibility")
    private void setCrmTaskCard(JSONObject data) {

        view.findViewById(R.id.emptyTaskCard).setVisibility(View.GONE);
//        view.findViewById(R.id.emptyLeadCard).setVisibility(View.GONE);
        view.findViewById(R.id.cvTasks).setVisibility(View.VISIBLE);

        // Views
        TextView tvPending = view.findViewById(R.id.tvPendingValue);
        TextView tvProgress = view.findViewById(R.id.tvProgressValue);
        TextView tvHold = view.findViewById(R.id.tvHoldValue);

        PieChart mainPie = view.findViewById(R.id.pieChartMain);
        // Clicks
        int[] clickableIds = {
                R.id.pieChartMain,
                R.id.llPending,
                R.id.llProgress,
                R.id.llHold
        };
        mainPie.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.performClick();
            }
            return false;
        });
        for (int id : clickableIds) {
            view.findViewById(id).setOnClickListener(this);
        }

        JSONObject due = data.optJSONObject("dueSummary");
        JSONObject status = data.optJSONObject("statusSummary");

        int pending = status != null ? status.optInt("pending", 0) : 0;
        int progress = status != null ? status.optInt("inProgress", 0) : 0;
        int hold = status != null ? status.optInt("onHold", 0) : 0;

        int unresolved = due != null ? due.optInt("totalUnresolved", 0) : 0;

        // Set Text
        tvPending.setText(String.valueOf(pending));
        tvProgress.setText(String.valueOf(progress));
        tvHold.setText(String.valueOf(hold));
        if (pending==0){
            view.findViewById(R.id.llPending).setClickable(false);
        }
        if (progress==0){
            view.findViewById(R.id.llProgress).setClickable(false);
        }
        if (hold==0){
            view.findViewById(R.id.llHold).setClickable(false);
        }
        //
        setupMainPie(mainPie, pending, progress, hold,unresolved);

    }

    private void setupMainPie(PieChart chart, int pending, int progress, int hold,int unresolved) {
        try {
            int total = pending + progress + hold;
            if (total == 0) {
                chart.clear();
                return;
            }
            List<PieEntry> entries = new ArrayList<>();
            entries.add(new PieEntry(pending));
            entries.add(new PieEntry(progress));
            entries.add(new PieEntry(hold));
            PieDataSet dataSet = new PieDataSet(entries, "");
            List<Integer> colors = new ArrayList<>();
            colors.add(ContextCompat.getColor(chart.getContext(), R.color.crm_in_pending));
            colors.add(ContextCompat.getColor(chart.getContext(), R.color.crm_in_progress));
            colors.add(ContextCompat.getColor(chart.getContext(), R.color.crm_on_hold));

            dataSet.setColors(colors);
            dataSet.setDrawValues(false);
            chart.setUsePercentValues(false);
            int labelColor = requireActivity().getColor(R.color.value_text_color);
            Extensions.setCrmCenterValue(chart,unresolved,getString(R.string.txt_unresolved),labelColor);
            chart.setData(new PieData(dataSet));
            chart.getDescription().setEnabled(false);
            chart.getLegend().setEnabled(false);
            chart.setDrawEntryLabels(false);
            chart.setTouchEnabled(false);
            chart.setHoleRadius(70f);
            chart.setTransparentCircleRadius(75f);
            chart.setHoleColor(Color.TRANSPARENT);
            chart.invalidate();
        } catch (Exception e) {

        }
    }



    private void fetchBrokerLeadsSummary() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = CrmBuilder.prepareCrmBaseUrl() + Config.CRM_GET_LEADS_SUMMARY+"selectedUser="
                + CrmBuilder.preparedCrmSelectedUser(crmUID,crmLevelNo) + "&leadsSummary=1";
        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                boolean hasData = false;
                try {
                    crmLeadJsonObject = new JSONObject();
                    leadsData = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(response);
                    int status = jsonObject.optInt("status",-1);
                    if (status==0){
                        JSONArray resultArray = jsonObject.optJSONArray("result");
                        if (resultArray != null && resultArray.length() > 0) {
                            crmLeadJsonObject = resultArray.optJSONObject(0);
                            hasData = hasLeadsData(crmLeadJsonObject);
                            isCrmLeadsEmpty = !hasData;
                            JSONArray todayArray = crmLeadJsonObject.optJSONArray("todaySummary");
                            leadsData = CrmBuilder.extractTodaySummary(mSession,todayArray,requireActivity());
                        } else {
                            isCrmLeadsEmpty = true;
                        }
                    }else if (status==-1){
                        showSnackbar(llCrmMain,jsonObject.optString("message"));
                    }
                    else{
                        showSnackbar(llCrmMain,jsonObject.optString("message"));
                    }
                } catch (Exception ignored) {}
                finally {
                    if (leadsData != null && hasData) {
                        view.findViewById(R.id.emptyLeadCard).setVisibility(View.GONE);
                        view.findViewById(R.id.cvLeads).setVisibility(View.VISIBLE);
                        rvLeads.setVisibility(View.VISIBLE);
                        mLeadsAdapter.update(leadsData);
                    } else {
                        setEmptyLeadsView();
                    }
                }
            }

            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                showHideLoader(isLoading);
            }
        });
    }

    private void setCrmEmptyStateContent(int containerId, String title, String subtitle,int icon) {
        View container = view.findViewById(containerId);
        if (container == null) {
            return;
        }
        TextView titleView = container.findViewById(R.id.tvTitle1);
        TextView subTitleView = container.findViewById(R.id.tvSub1);
        ImageView sbImageView = container.findViewById(R.id.iconTasks);
        if (sbImageView !=null){
            sbImageView.setImageResource(icon);
        }
        if (titleView != null) {
            titleView.setText(title);
        }
        if (subTitleView != null) {
            subTitleView.setText(subtitle);
        }
    }




    private void checkLoanAgainstMfPermission() {
        try {
            boolean isVoltSDKEnabled = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature111", Permissions.VIEW);
            if (isVoltSDKEnabled && mSession.getHasLoging()){
                view.findViewById(R.id.cv_dashboard_loan).setVisibility(View.VISIBLE);
                TextView loanTitle =view.findViewById(R.id.tv_loan_against_mf_title);
                TextView loanDesc =view.findViewById(R.id.tv_loan_against_mf_desc);
                loanTitle.setText(R.string.loan_against_mf1);
                loanDesc.setText(R.string.track_and_manage_investor_loan);
            }else {
                view.findViewById(R.id.cv_dashboard_loan).setVisibility(View.GONE);
            }

        }catch (Exception e){
            logD(e);
            view.findViewById(R.id.cv_dashboard_loan).setVisibility(View.GONE);
        }
    }

    //no need of permission for calculatorFra in broker dashbaord according to pm rabab
//    private void checkCalculatorPermission() {
//        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
//            rl_calculators.setVisibility(View.VISIBLE);
//        }
//        else{
//            if (mSession.getFutureProjectionCalculator() != 0) {
//                rl_calculators.setVisibility(View.VISIBLE);
//                if (mSession.getSIPCalculator() == 0) {
//                    view.findViewById(R.id.tvSipPlanner).setVisibility(View.INVISIBLE);
//                    view.findViewById(R.id.tvStpPlanner).setVisibility(View.INVISIBLE);
//                    view.findViewById(R.id.tvSwpPlanner).setVisibility(View.INVISIBLE);
//                    view.findViewById(R.id.view_planner2).setVisibility(View.GONE);
//                    view.findViewById(R.id.view_planner1).setVisibility(View.GONE);
//                }
//            } else {
//                rl_calculators.setVisibility(View.GONE);
//            }
//        }
//
//    }

    private void updateApiData() {
        try {
            Calendar calendar = Calendar.getInstance();
            long currentTimeInMilli = calendar.getTimeInMillis();
            long difference = currentTimeInMilli - mApplication.sRefreshTimeBrokerDashBoard;
            long minutes = (difference / 1000) / 60;
            if (minutes >= 10) {
                if (mSession.getHasLoging()) {
                    mCardView.setVisibility(View.VISIBLE);
                    mLinerWithoutLogin.setVisibility(View.GONE);
                    if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                        mApplication.sRefreshTimeBrokerDashBoard = calendar.getTimeInMillis();
                        if (!mSession.getHasBDCardWithStar()) {
                            getBrokerSummery();
                        }
                    }

                } else {
                    mCardView.setVisibility(View.GONE);
                    mLinerWithoutLogin.setVisibility(View.VISIBLE);
                }
            } else {
                if (mSession.getHasLoging()) {
                    mCardView.setVisibility(View.VISIBLE);
                    mLinerWithoutLogin.setVisibility(View.GONE);
                    if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                        if (AppApplication.DASHBOARD_BROKER.equals("")) {
                            mApplication.sRefreshTimeBrokerDashBoard = calendar.getTimeInMillis();
                            if (!mSession.getHasBDCardWithStar()) {
                                getBrokerSummery();
                            }
                        } else {
                            setSummary();
                            if (!Config.asOnDate.isEmpty()) {
                                tvAsOndate.setText(Config.asOnDate);
                            } else {
                                setMaxNavDate();
                            }
                        }
                    }

                } else {
                    mCardView.setVisibility(View.GONE);
                    mLinerWithoutLogin.setVisibility(View.VISIBLE);

                }
            }
            if (mSession.getHasBDCardWithStar()) {
                mCardView.setVisibility(View.GONE);
            }


        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }

    private void refer(String url) {
        Intent sharingIntent;
        if (mBrokerActivity != null) {
            sharingIntent = new Intent(mBrokerActivity, ShareDeepLinkActivity.class);
        } else {
            sharingIntent = new Intent(mMainActivity, ShareDeepLinkActivity.class);
        }
        sharingIntent.putExtra("url", url);
        startActivity(sharingIntent);
    }


    private void generateShortUrl() {
        String referUrl = "";
        if (mSession.getCustomURL() != null && !mSession.getCustomURL().isEmpty()) {
            referUrl = "https://" + mSession.getCustomURL() + "/" + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        } else {
            referUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath().replace("/webapi", "") + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        }
        String url = Config.DEEP_LINKING_SHORT_URL + referUrl + "&signature=11d3c107e3" + "&format=json&action=shorturl";

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isAdded()) {
                    if (isLoading) {
                        ProgressBarCommon.showDialog(requireActivity());
                    } else {
                        ProgressBarCommon.dismissDialog();

                    }
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),
                            Config.DEEP_LINKING_SHORT_URL);

                    if (jsonObject.optInt("statusCode") == 200) {
                        String shorturl = jsonObject.optString("shorturl");
                        refer(shorturl);
                    }
                } catch (Exception ignored) {

                }
            }
        });

    }

    /*************************************************
     * Method called to calculate notification count
     ***********************************************************/
    @SuppressLint("SetTextI18n")
    public void notificationCount() {
        try {
            if (!mSession.getNotification().isEmpty()) {
                JSONArray jsonArray = new JSONArray(mSession.getNotification());
                tv_notification_badge.setVisibility(View.VISIBLE);

                List<JSONObject> newNotificationList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.optJSONObject(i);
                    if (!object.optBoolean("isReadNotification")) {
                        newNotificationList.add(object);
                    }
                }
                if (!newNotificationList.isEmpty()) {
                    tv_notification_badge.setVisibility(View.VISIBLE);
                    tv_notification_badge.setText("" + newNotificationList.size());
                } else {
                    tv_notification_badge.setVisibility(View.GONE);
                }
            } else {
                tv_notification_badge.setVisibility(View.GONE);
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }


    private void setUpInvestRouteStaticUi() {
        try {
            boolean hasVisibelAnyThing = false;
            JSONObject appConfigObject = new JSONObject();
            if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }

            if (mSession.getHasLoging()) {
                view.findViewById(R.id.cv_dashboard_sec).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.v_refer).setVisibility(View.VISIBLE);
                view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_market_update).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_fund_picks).setVisibility(View.VISIBLE);


            } else {
                view.findViewById(R.id.cl_fund_picks).setVisibility(View.GONE);
                if ((!TextUtils.isEmpty(appConfigObject.optString("topSchemes")) && !appConfigObject.optString("topSchemes").equalsIgnoreCase("null"))
                        && appConfigObject.optString("topSchemes").equalsIgnoreCase("1")) {
                    view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                    hasVisibelAnyThing = true;
                } else {
                    view.findViewById(R.id.cl_top_scheme).setVisibility(View.GONE);

                }

                if ((!TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes")) && !appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null"))
                        && appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1")) {
                    view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                } else {
                    view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.GONE);

                }
                if ((!TextUtils.isEmpty(appConfigObject.optString("NFO")) && !appConfigObject.optString("NFO").equalsIgnoreCase("null"))
                        && appConfigObject.optString("NFO").equalsIgnoreCase("1")) {
                    view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);
                    hasVisibelAnyThing = true;
                } else {
                    view.findViewById(R.id.cl_nfo).setVisibility(View.GONE);

                }

                if (((TextUtils.isEmpty(appConfigObject.optString("latestNav")) || appConfigObject.optString("latestNav").equalsIgnoreCase("null"))
                        || !appConfigObject.optString("latestNav").equalsIgnoreCase("1"))) {
                    view.findViewById(R.id.cl_latest_nav).setVisibility(View.GONE);

                } else {
                    view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);

                }
                if (((TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes")) || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null"))
                        || !appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1"))) {
                    view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.GONE);

                } else {
                    view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);

                }

                if (((TextUtils.isEmpty(appConfigObject.optString("latestNav")) || appConfigObject.optString("latestNav").equalsIgnoreCase("null"))
                        || !appConfigObject.optString("latestNav").equalsIgnoreCase("1")) &&
                        ((TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes")) || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null"))
                                || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1"))) {

                    view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.v_sip).setVisibility(View.GONE);
                }

                if (hasVisibelAnyThing) {
                    view.findViewById(R.id.llInvestmentRoute).setVisibility(View.VISIBLE);
                } else {
                    view.findViewById(R.id.llInvestmentRoute).setVisibility(View.GONE);
                }
            }

            // rename invest in top performers to Scheme Performance and top scheme as per sumit saini
            if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){

                TextView tvInvestTopSchemeTitle = view.findViewById(R.id.tv_invest_top_scheme_title);
                TextView tvTopSipTitle = view.findViewById(R.id.tv_top_sip_title);
                tvInvestTopSchemeTitle.setText(R.string.scheme_performance);
                tvTopSipTitle.setText(R.string.sip_scheme_performance);

            }


        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        } finally {
            if (mSession.getUserBrokerDomain().equals("")) {
                view.findViewById(R.id.llInvestmentRoute).setVisibility(View.VISIBLE);
                view.findViewById(R.id.llInvestmentRoute).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cv_dashboard_sec).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.v_refer).setVisibility(View.VISIBLE);
                view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);

                view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_market_update).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_fund_picks).setVisibility(View.GONE);

            }
            view.findViewById(R.id.cv_dashboard_sec).setVisibility(View.VISIBLE);
            view.findViewById(R.id.cl_market_update).setVisibility(View.VISIBLE);

            String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
            TextView tvInvestTopSchemeTitle = view.findViewById(R.id.tv_invest_top_scheme_title);
            TextView tvTopSchemeDesc = view.findViewById(R.id.tv_invest_route_top_scheme_desc);
            TextView topSipPerformance = view.findViewById(R.id.tv_top_sip_title);
            TextView tvGoalDesc = view.findViewById(R.id.tv_goal_desc);
            TextView tvGoal = view.findViewById(R.id.tv_goal_title);
            // TODO: mf bazaar
            if (mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")) {
                if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
                    JSONObject mJsoObject = null;
                    try {
                        mJsoObject = new JSONObject(allowedFeatured);
                        JSONArray jsonArray = mJsoObject.optJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            if (jsonArray.optJSONObject(i).has("feature1007")) {
                                view.findViewById(R.id.cl_goal).setVisibility(View.VISIBLE);
                            }
                        }

                    } catch (JSONException e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }
                view.findViewById(R.id.cl_goal).setOnClickListener(this);

                ImageView goalIcon = view.findViewById(R.id.iv_goal);
                ImageView ivExistingScheme = view.findViewById(R.id.iv_existing_scheme);
                goalIcon.setImageResource(R.mipmap.goal_colorfull);

                int icon = UtilityKotlin.checkExistResources("existing_schemes", "mipmap", requireActivity());
                if (icon != 0) {
                    ivExistingScheme.setImageResource(icon);
                }

                ImageView ivtransferHolding = view.findViewById(R.id.iv_transfer_holding);
                int iconHolding = UtilityKotlin.checkExistResources("transfer_holding", "mipmap", requireActivity());
                if (iconHolding != 0) {
                    ivtransferHolding.setImageResource(iconHolding);
                }
                // top fund scheme performance
                if (getString(R.string.subdomain).equals("mfbazaar")) {
                    tvInvestTopSchemeTitle.setText(getString(R.string.top_fund_scheme_performance_mf_bazaar));
                }else{
                    tvInvestTopSchemeTitle.setText(getString(R.string.top_fund_scheme_performance));
                }
                tvTopSchemeDesc.setText(R.string.view_performance_of_all_mutual_funds_schemes);

                // Search by amc show only while loged out


                // top sip performance
                if (getString(R.string.subdomain).equals("mfbazaar")) {
                    topSipPerformance.setText(getString(R.string.top_sip_scheme_performance_mf_bazaar));
                }else{
                    topSipPerformance.setText(getString(R.string.top_sip_scheme_performance));
                }
                // transfer holding
                view.findViewById(R.id.cl_transfer_holding).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_transfer_holding).setOnClickListener(this);
                // invest in existing scheme
                if (!mSession.getHasLoging()){
                    view.findViewById(R.id.cl_amc).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.cl_existing_scheme).setVisibility(View.VISIBLE);

                    view.findViewById(R.id.cl_amc).setOnClickListener(this);
                    TextView tvAmcTitle = view.findViewById(R.id.tv_amc_title);
                    TextView tvAmcDesc = view.findViewById(R.id.tv_amc_desc);
                    tvAmcTitle.setText(R.string.search_by_amc);
                    tvAmcDesc.setText(R.string.select_amc_choose_fund_to_invest);
                }else {
                    view.findViewById(R.id.cl_amc).setVisibility(View.GONE);
                    view.findViewById(R.id.cl_goal).setVisibility(View.GONE);
                    view.findViewById(R.id.cl_existing_scheme).setVisibility(View.GONE);
                    view.findViewById(R.id.cl_transfer_holding).setVisibility(View.VISIBLE);
                }

                view.findViewById(R.id.cl_existing_scheme).setOnClickListener(this);
                // elss retirement list
                view.findViewById(R.id.rl_elss_retirement).setVisibility(View.VISIBLE);
                TextView tv_dashboard_items_title3 = view.findViewById(R.id.tv_dashboard_items_title3);
                tv_dashboard_items_title3.setText(getString(R.string.txt_elss_retirement_children_liquid_gold_fund_mf_bazaar));

                // set elss rv
                elssRetirementArrayList = new ArrayList<>();

                elssRetirementAdapter = new ElssRetirementAdapter(requireActivity(),this);
                rvElssRetirement.setAdapter(elssRetirementAdapter);
                getObjectives();
            } else if (mSession.getUserBrokerDomain().equalsIgnoreCase("goalchicapital")) {
                tvGoal.setText(R.string.your_goals_our_solutions);
                tvGoalDesc.setText(R.string.your_financial_goals);
                tvInvestTopSchemeTitle.setText(R.string.mutual_funds_scheme_performance);
                tvTopSchemeDesc.setText(R.string.get_detailed_info_on_every_fund_to_make_the_best_informed_decisions);
                topSipPerformance.setText(R.string.sip_performance_metrics);
            }
        }
    }


    private void getObjectives(){
        String url = "";
        if (!TextUtils.isEmpty(mSession.getUserBrokerDomain())) {
            if (!mSession.getHasLoging()) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TOP_SCHEME_OPEN_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
            } else {
                if (hasReAuthTimeNotValid(mSession, requireActivity())) {
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TOP_SCHEME_BROKER_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";

            }
        } else {
            if (!mSession.getHasLoging()) {
                url = "https://demo" + mSession.getHostingPath() + Config.GET_TOP_SCHEME_OPEN_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
            } else {
                url = "https://demo" + mSession.getHostingPath() + Config.GET_TOP_SCHEME_BROKER_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
            }
        }

        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isAdded()) {
                    if (isLoading) {
                        ProgressBarCommon.showDialog(requireActivity());
                    } else {
                        ProgressBarCommon.dismissDialog();

                    }
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {

                        JSONArray jsonArray = jsonObject.optJSONArray("result");
                        for (int i = 0; i< (jsonArray != null ? jsonArray.length() : 0); i++){
                            JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                            String objective = jsonObject1.optString("objective");
                            String objectiveId = jsonObject1.optString("objectiveid");

                            if (objective.equalsIgnoreCase("Equity: ELSS")){
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.elss_funds,"Equity ELSS",1,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            } else if (objective.equalsIgnoreCase("Solution: Retirement Debt")) {
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.debt_retirement,"Invest in Retirement Debt",2,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            } else if (objective.equalsIgnoreCase("Solution: Retirement Equity")) {
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.retirement_equity,"Invest in  Retirement Equity",3,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            }else if (objective.equalsIgnoreCase("Solution: Children Debt")) {
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.debt_child_education,"Invest in Children Debt",4,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            }else if (objective.equalsIgnoreCase("Solution: Children Equity")) {
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.children_funds,"Invest in  Children Equity",5,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            }else if (objective.equalsIgnoreCase("Debt: Liquid")) {
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.liquid_funds,"Invest in Liquid Funds",6,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            }else if (objective.equalsIgnoreCase("Gold: Gold Funds")) {
                                ElssRetirement el1 = new ElssRetirement(R.mipmap.gold_funds,"Invest in Gold Funds",7,objective,objectiveId);
                                elssRetirementArrayList.add(el1);
                            }
                        }
                        Collections.sort(elssRetirementArrayList, (o1, o2) -> Integer.compare(o1.getAction(), o2.getAction()));

                    }else {
                        UtilityKotlin.onSnackFailure(
                                rvElssRetirement,
                                jsonObject.optString("message"),
                                requireContext()
                        );
                    }
                } catch (JSONException ignored) {
                }finally {
                    ProgressBarCommon.dismissDialog();
                    if (!elssRetirementArrayList.isEmpty()){
                        elssRetirementAdapter.update(elssRetirementArrayList);
                    }
                }
            }
        });



    }


    @Override
    public void onElssRetirement(int action, @Nullable String objectiveId,String mTitle) {
        /*switch (action) {
            case 1:
                taxSaverTopScheme(objectiveId);
                break;
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
        }*/
        taxSaverTopScheme(objectiveId,mTitle);
    }

    private void taxSaverTopScheme(String objId,String mTitle){
        Intent intent= null;
        if (mBrokerActivity != null) {
            intent = new Intent(mBrokerActivity, TopSchemeActivity.class);
            AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
        } else {
            intent = new Intent(mMainActivity, TopSchemeActivity.class);
            AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
        }
        intent.putExtra("objId", objId);
        intent.putExtra("filter", "no");
        if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){
            intent.putExtra("toolBarTitle", getString(R.string.scheme_performance));
        } else if (mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")){
            intent.putExtra("toolBarTitle", mTitle);
        }
                  /*  intent.putExtra("title", getString(R.string.txt_top_scheme));
                    intent.putExtra("isShowToolBar", "yes");
                    intent.putExtra("url", requireActivity().getResources().getString(R.string.top_scheme_url));*/
        startActivity(intent);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showLoginDialog(Context context) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_factsheet_pdf, null);
        dialogBuilder.setView(dialogView);
        AlertDialog alertDialog = dialogBuilder.create();

        AppTextViewTitle tvTitle = dialogView.findViewById(R.id.textView28);
        tvTitle.setText(getString(R.string.alert));

        AppTextView tvCancel = dialogView.findViewById(R.id.textView31);
        tvCancel.setText(getString(R.string.txt_cancel));

        AppTextView tvLogin = dialogView.findViewById(R.id.textView36);
        tvLogin.setText(getString(R.string.login));

        AppTextView tvMessage = dialogView.findViewById(R.id.textView30);
        tvMessage.setText(getString(R.string.login_dailog_msg));

        ImageView ivLogoutImage = dialogView.findViewById(R.id.imageView15);
        ivLogoutImage.setImageResource(R.mipmap.logout_128);

        tvTitle.setSelected(true);
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!getString(R.string.subdomain).equals("mint")) {
                    if (mBrokerActivity != null) {
                        startActivity(new Intent(mBrokerActivity, DomainActivity.class));
                    }else {
                        startActivity(new Intent(mMainActivity, DomainActivity.class));
                    }
                } else {
                    if (mBrokerActivity != null) {
                        startActivity(new Intent(mBrokerActivity, LoginActivity.class));
                    }else {
                        startActivity(new Intent(mMainActivity, LoginActivity.class));
                    }

                }
                alertDialog.dismiss();
            }
        });

        alertDialog.show();
    }


    private void showPopUpDialog(JSONObject appConfigObject) {
        final Dialog dialog;
        if (mBrokerActivity != null) {
            dialog = new Dialog(mBrokerActivity);
        } else {
            dialog = new Dialog(mMainActivity);
        }
        dialog.setContentView(R.layout.special_message_popup);
        ImageView mIvBanner = dialog.findViewById(R.id.ivBanner);
        RelativeLayout mRlCont = dialog.findViewById(R.id.rl_cont);
        ImageView mIvExp = dialog.findViewById(R.id.iv_exp);
        MaterialButton mIvClose = dialog.findViewById(R.id.ivClose);
        mIvClose.setTransformationMethod(null);
        AppTextView mTvMessage = dialog.findViewById(R.id.tvMessage);
        MaterialButton mBtnKnowMore = dialog.findViewById(R.id.btnKnowMore);
        CheckBox mCheckBox = dialog.findViewById(R.id.checkBox);
        dialog.setCancelable(false);

        if (!appConfigObject.optString("popupURL").isEmpty() && !appConfigObject.optString("popupURL").equalsIgnoreCase("null")) {
            mBtnKnowMore.setVisibility(View.VISIBLE);

        } else {
            mBtnKnowMore.setVisibility(View.GONE);

        }
        if (!appConfigObject.optString("popupMessage").isEmpty() && !appConfigObject.optString("popupMessage").equalsIgnoreCase("null")) {
            mTvMessage.setText(appConfigObject.optString("popupMessage"));
            mTvMessage.setVisibility(View.VISIBLE);
        } else {
            mTvMessage.setVisibility(View.GONE);
        }


        mBtnKnowMore.setOnClickListener(view -> {
            Intent intent;
            if (mBrokerActivity != null) {
                intent = new Intent(mBrokerActivity, WebViewActivity.class);
            } else {
                intent = new Intent(mMainActivity, WebViewActivity.class);
            }
            intent.putExtra("title", getString(R.string.information));
            intent.putExtra("url", appConfigObject.optString("popupURL"));
            startActivity(intent);
            dialog.dismiss();
        });
        mIvClose.setOnClickListener(v -> {
//            mSession.setShowCrossDialog(false);
            dialog.dismiss();
        });


        mCheckBox.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                // mSession.setShowDialog(false);

                mSession.setShowDialogByCurrentDate(localImagePath);

            }
        });
        mIvBanner.setOnClickListener(v -> {
            boolean isFound = appConfigObject.optString("popupImagePath").contains("http");
            boolean isF2 = appConfigObject.optString("popupImagePath").contains("https");
            String url = "";
            if (isFound || isF2) {
                url = appConfigObject.optString("popupImagePath");
            } else {
                url = "https://" + appConfigObject.optString("popupImagePath");
            }
            showCustomDialo(url);

        });

        if (!TextUtils.isEmpty(appConfigObject.optString("popupImagePath")) && !appConfigObject.optString("popupImagePath").equalsIgnoreCase("null")) {
            mIvBanner.setVisibility(View.VISIBLE);
            boolean isFound = appConfigObject.optString("popupImagePath").contains("http");
            boolean isF2 = appConfigObject.optString("popupImagePath").contains("https");
            String url = "";
            if (isFound || isF2) {
                url = appConfigObject.optString("popupImagePath");
            } else {
                url = "https://" + appConfigObject.optString("popupImagePath");
            }
            Picasso.get().load(url).memoryPolicy(MemoryPolicy.NO_CACHE)
                    .networkPolicy(NetworkPolicy.NO_CACHE).into(mIvBanner, new Callback() {
                        @Override
                        public void onSuccess() {
                            if (!isAdded())
                                return;
                            dialog.show();
                        }

                        @Override
                        public void onError(Exception exception) {
                            mIvBanner.setVisibility(View.GONE);

                        }
                    });

        } else {
            dialog.show();
            mIvBanner.setVisibility(View.GONE);
        }


    }

    private void showCustomDialo(String s) {
        final Dialog d = new Dialog(mBrokerActivity, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        d.setContentView(R.layout.dialog_zoom);
        ImageView mIvClose = d.findViewById(R.id.ivClose);
        ZoomClass mIvBanner = d.findViewById(R.id.iv_zoom);
        if (!TextUtils.isEmpty(s) && !s.equalsIgnoreCase("null")) {
            mIvBanner.setVisibility(View.VISIBLE);
            if (mBrokerActivity != null) {

                Picasso.get().load(s).into(mIvBanner);
            }
        } else {
            mIvBanner.setVisibility(View.GONE);
        }

        mIvClose.setOnClickListener(view -> d.dismiss());
        d.show();
    }

    private void showCustomDialog(View v, String s) {
        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = v.findViewById(android.R.id.content);

        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(mBrokerActivity).inflate(R.layout.dialog_zoom, viewGroup, false);
        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(mBrokerActivity);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        AlertDialog alertDialog = builder.create();
        ImageView mIvClose = dialogView.findViewById(R.id.ivClose);
        ImageView mIvBanner = dialogView.findViewById(R.id.iv_zoom);
        if (!TextUtils.isEmpty(s) && !s.equalsIgnoreCase("null")) {
            mIvBanner.setVisibility(View.VISIBLE);
            if (mBrokerActivity != null) {
                String url = "https://" + s;
                new Handler().postDelayed(() -> Picasso.get().load(url).into(mIvBanner), 2000);
            } else {
                Picasso.get().load(s).into(mIvBanner);
            }
        } else {
            mIvBanner.setVisibility(View.GONE);
        }

        mIvClose.setOnClickListener(view -> alertDialog.dismiss());
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        if (v.getId() == R.id.login_btn) {
                if (mBrokerActivity != null) {
                    if (mSession.getUserBrokerDomain().length() > 0) {
                        intent = new Intent(mBrokerActivity, LoginActivity.class);
                    } else {
                        intent = new Intent(mBrokerActivity, DomainActivity.class);
                    }
                } else {
                    if (mSession.getUserBrokerDomain().length() > 0 && mSession.getUserBrokerDomain().length() > 0) {
                        intent = new Intent(mMainActivity, LoginActivity.class);
                    } else {
                        intent = new Intent(mMainActivity, DomainActivity.class);
                    }
                }
                intent.putExtra("login_come_from", "Dashboard");
                intent.putExtras(CrmBuilder.getNotificaionBundle());
                startActivity(intent);
      /*      case R.id.ll_profile_not_complete:
                if (mBrokerActivity != null) {
                    if (!TextUtils.isEmpty(mSession.getIinId())) {
                        mBrokerActivity.callTempIInApi();
                    } else {
                        mBrokerActivity.callClientInfoApi();
                    }
                }else {
                    if (!TextUtils.isEmpty(mSession.getIinId())) {
       *//*                 mMainActivity.callTempIInApi();*//*
                    } else {
                        mMainActivity.callClientInfoApi();
                    }
                }
                break;*/
}
else if (v.getId() == R.id.cl_transfer_holding) {
                if (!mSession.getHasLoging()){
                    if (mBrokerActivity !=null){
                        showLoginDialog(mBrokerActivity);
                    }else {
                        showLoginDialog(mMainActivity);
                    }
                }else {
                    // continue
                    if (mBrokerActivity!=null){
                        mBrokerActivity.displayViewOther(83,null);
                    }
                }
}
else if (v.getId() == R.id.ivTasks) {
}
else if (v.getId() == R.id.layoutTaskHeader) {
                CrmBuilder.openCrmApp(CrmPage.TASKS,null,false,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.llPending) {
                CrmBuilder.openCrmApp(CrmPage.TASKS,FilterType.TasksPending,false,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.llProgress) {
                CrmBuilder.openCrmApp(CrmPage.TASKS,FilterType.TasksInProgress,false,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.llHold) {
                CrmBuilder.openCrmApp(CrmPage.TASKS,FilterType.TasksOnHold,false,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.pieChartMain) {
                CrmBuilder.openCrmApp(CrmPage.TASKS,FilterType.TasksTotalUnresolved,false,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.emptyTaskCard) {
                CrmBuilder.openCrmApp(CrmPage.TASKS,null,true,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.cvLeads) {
}
else if (v.getId() == R.id.layoutLeadHeader) {
                CrmBuilder.openCrmApp(CrmPage.LEADS,null,false,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.emptyLeadCard) {
                CrmBuilder.openCrmApp(CrmPage.LEADS,null,true,requireActivity(),startForCrmResult);
}
else if (v.getId() == R.id.cl_goal) {
                if (!mSession.getHasLoging()){
                    if (mBrokerActivity !=null){
                        showLoginDialog(mBrokerActivity);
                    }else {
                        showLoginDialog(mMainActivity);
                    }
                }
                // never show while broker login
}
else if (v.getId() == R.id.cl_existing_scheme) {
                if (!mSession.getHasLoging()){
                    if (mBrokerActivity !=null){
                        showLoginDialog(mBrokerActivity);
                    }else {
                        showLoginDialog(mMainActivity);
                    }
                }// never show to broker
}
else if (v.getId() == R.id.cl_amc) {
                if (!mSession.getHasLoging()){
                    if (mBrokerActivity !=null){
                        showLoginDialog(mBrokerActivity);
                    }else {
                        showLoginDialog(mMainActivity);
                    }
                }
}
else if (v.getId() == R.id.rl_additional_sec_container) {
                if (mSession.getHasLoging() && mBrokerActivity!=null){
                    mBrokerActivity.callVoltApi();
                }
}
else if (v.getId() == R.id.iv_contact_us) {
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewOther(39, null);
                } else {
                    mMainActivity.displayViewOther(39, null);
                }
}
else if (v.getId() == R.id.signup_btn) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, DomainActivity.class);
                } else {
                    intent = new Intent(mMainActivity, DomainActivity.class);
                }
                intent.putExtra("login_come_from", "Register");
                startActivity(intent);
}
else if (v.getId() == R.id.cl_top_scheme) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, TopSchemeActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                } else {
                    intent = new Intent(mMainActivity, TopSchemeActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                }
                intent.putExtra("fundPick", "no");
                if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){
                    intent.putExtra("toolBarTitle", getString(R.string.scheme_performance));
                }
                  /*  intent.putExtra("title", getString(R.string.txt_top_scheme));
                    intent.putExtra("isShowToolBar", "yes");
                    intent.putExtra("url", requireActivity().getResources().getString(R.string.top_scheme_url));*/
                startActivity(intent);
}
else if (v.getId() == R.id.cl_fund_picks) {
                intent = new Intent(requireActivity(), TopSchemeActivity.class);
                intent.putExtra("toolBarTitle", getString(R.string.txt_fund_pick_name));
                startActivity(intent);
            /*
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, FundPicksActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                } else {
                    intent = new Intent(mMainActivity, FundPicksActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                }
                intent.putExtra("fundPick", "yes");
                startActivity(intent);*/
}
else if (v.getId() == R.id.cl_top_sip_scheme) {
                intent = new Intent(requireActivity(), TopSchemeActivity.class);
                if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){
                    intent.putExtra("toolBarTitle", getString(R.string.sip_scheme_performance));
                }else {
                    intent.putExtra("toolBarTitle", getString(R.string.dashboard_top_sip_title));
                }
                startActivity(intent);

              /*  if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, WebActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                } else {
                    intent = new Intent(mMainActivity, WebActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                }

                intent.putExtra("title", getString(R.string.txt_top_sip_schemes));
                intent.putExtra("isShowToolBar", "yes");
                intent.putExtra("url", getString(R.string.top_sip_url));
                startActivity(intent);*/
}
else if (v.getId() == R.id.cl_latest_nav) {
                mBrokerActivity.displayViewOther(85,new Bundle());
}
else if (v.getId() == R.id.cl_market_update) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, MarketUpdateActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                } else {
                    intent = new Intent(mMainActivity, MarketUpdateActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                }
                startActivity(intent);
}
else if (v.getId() == R.id.cl_nfo) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, NfoActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                } else {
                    intent = new Intent(mMainActivity, NfoActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                }

                startActivity(intent);
}
else if (v.getId() == R.id.ivCross) {
}
else if (v.getId() == R.id.llCross) {
                mContentSpecialMsgView.setVisibility(View.GONE);
}
else if (v.getId() == R.id.tvReadMore) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, WebActivity.class);
                } else {
                    intent = new Intent(mMainActivity, WebActivity.class);
                }
                intent.putExtra("title", getString(R.string.information));
                intent.putExtra("isShowToolBar", "yes");
                intent.putExtra("url", specialMsgUrl);
                startActivity(intent);
}
else if (v.getId() == R.id.ivRight) {
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewOther(62, null);
                } else {
                    mMainActivity.displayViewOther(62, null);
                }
}
else if (v.getId() == R.id.sip_cal) {
            if (mBrokerActivity != null) {
                startActivity(
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.SIP.GoalAmount.INSTANCE.getKey())
                );
            } else {
                startActivity(new Intent(mMainActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SIP.GoalAmount.INSTANCE.getKey()));
            }
}
else if (v.getId() == R.id.tvStepUpCal) {
                if (mBrokerActivity != null) {
                    startActivity(new Intent(mBrokerActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SipStepUp.INSTANCE.getKey()));
                } else {
                    startActivity(new Intent(mMainActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SipStepUp.INSTANCE.getKey()));
                }
}
else if (v.getId() == R.id.lumpsum_cal) {
                if (mBrokerActivity != null) {
                    startActivity(new Intent(mBrokerActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.LUMPSUM.INSTANCE.getKey()));
                } else {
                    startActivity(new Intent(mMainActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.LUMPSUM.INSTANCE.getKey()));
                }
}
else if (v.getId() == R.id.cost_cal) {
                if (mBrokerActivity != null) {
                    startActivity(new Intent(mBrokerActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.CostOfDelay.INSTANCE.getKey()));
                } else {
                    startActivity(new Intent(mMainActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.CostOfDelay.INSTANCE.getKey()));
                }
}
else if (v.getId() == R.id.education_cal) {
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewCalculator(7, null);
                } else {
                    mMainActivity.displayViewCalculator(7, null);
                }
}
else if (v.getId() == R.id.marriage_cal) {
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewCalculator(8, null);
                } else {
                    mMainActivity.displayViewCalculator(8, null);
                }
}
else if (v.getId() == R.id.retirement_cal) {
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewCalculator(6, null);
                } else {
                    mMainActivity.displayViewCalculator(6, null);
                }
}
else if (v.getId() == R.id.sip_tenure) {
                Intent intent2 = null;
                if (mBrokerActivity != null) {
                    intent2 = new Intent(mBrokerActivity, WebActivity.class);
                } else {
                    intent2 = new Intent(mMainActivity, WebActivity.class);
                }

                intent2.putExtra("title", getString(R.string.sip_tenure));
                intent2.putExtra("url", "https://www.investwell.in/updation/parameter/Calculator/par_siptenure_calculatorM.jsp?bid=10003");
                startActivity(intent2);
}
else if (v.getId() == R.id.tvSipPlanner) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, WebActivity.class);
                } else {
                    intent = new Intent(mMainActivity, WebActivity.class);
                }

                intent.putExtra("title", getString(R.string.sip_planner));
                intent.putExtra("url", getString(R.string.sip_planner_url));
                startActivity(intent);
}
else if (v.getId() == R.id.tvStpPlanner) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, WebActivity.class);
                } else {
                    intent = new Intent(mMainActivity, WebActivity.class);
                }

                intent.putExtra("title", getString(R.string.stp_planner));
                intent.putExtra("url", getString(R.string.stp_planner_url));
                startActivity(intent);
}
else if (v.getId() == R.id.tvSwpPlanner) {
                if (mBrokerActivity != null) {
                    intent = new Intent(mBrokerActivity, WebActivity.class);
                } else {
                    intent = new Intent(mMainActivity, WebActivity.class);
                }

                intent.putExtra("title", getString(R.string.swp_planner));
                intent.putExtra("url", getString(R.string.swp_planner_url));
                startActivity(intent);
}
else if (v.getId() == R.id.tvEmiCal) {
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewCalculator(4, null);
                } else {
                    mMainActivity.displayViewCalculator(4, null);
                }
}
else if (v.getId() == R.id.iv_notification) {
}
else if (v.getId() == R.id.fl_notifications) {
            if (permissionViewModel.isPermissionGranted().getValue()){
                if (mBrokerActivity != null) {
                    mBrokerActivity.displayViewOther(46, null);
                } else if (mMainActivity != null) {
                    mMainActivity.displayViewOther(46, null);
                }
            }else{
                mBrokerActivity.requestNotificationPermission();
            }
} else if (v.getId() == R.id.tvSTPCalculator){
            if (mBrokerActivity != null) {
                startActivity(new Intent(mBrokerActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.STP.INSTANCE.getKey()));
            } else {
                startActivity(new Intent(mMainActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.STP.INSTANCE.getKey()));
            }
        }else if (v.getId() == R.id.tvSWPCalculator){
            if (mBrokerActivity != null) {
                startActivity(new Intent(mBrokerActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SWP.INSTANCE.getKey()));
            } else {
                startActivity(new Intent(mMainActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SWP.INSTANCE.getKey()));
            }
        }else if (v.getId() == R.id.ivNotificationDisabledClose) {
            mSession.setNotificationBannerCloseTime(System.currentTimeMillis());
            includeNotificationBanner.setVisibility(View.GONE);

        } else if (v.getId() == R.id.ivRefresh) {
            Calendar calendar = Calendar.getInstance();
            mApplication.sRefreshTimeBrokerDashBoard = calendar.getTimeInMillis();
            getBrokerSummery();
}
    }



    private void setSummary() {
        try {
            JSONObject jsonObject = new JSONObject(AppApplication.DASHBOARD_BROKER);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = jsonObjectMain.optDouble("AUMEquity");
                double currentValue2 = jsonObjectMain.optDouble("AUMNonEquity");
                double finalcurrentValue = currentValue + currentValue2;
                String strCurrentAmount = format.format(finalcurrentValue);
                tvAUM.setText(strCurrentAmount);

                tvInvestor.setText(jsonObjectMain.optString("noOfInvestors"));
                tvSip.setText(jsonObjectMain.optString("noOfSIP"));

                double amountOfSIPPerMonth = jsonObjectMain.optDouble("amountOfSIPPerMonth");
                String strCamountOfSIPPerMonth = format.format(amountOfSIPPerMonth);
                tvSipPerMonth.setText(strCamountOfSIPPerMonth);
                mTvUserName.setText(mSession.getName());

                if (jsonObjectMain.optBoolean("foliosUnderProcess")) {
                    llUpdation.setVisibility(View.VISIBLE);
                } else {
                    llUpdation.setVisibility(View.GONE);
                }

            } else {
                String errorMessge = jsonObject.optString("message");
                if (!errorMessge.equalsIgnoreCase("invalid request"))
                    Toast.makeText(mBrokerActivity, errorMessge, Toast.LENGTH_SHORT).show();

            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();

        }
    }

    private void setMaxNavDate() {
        if (!isAdded())
            return;
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MAX_NAVDATE;
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.OPEN_API, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    if (!isAdded())
                        return;
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        tvAsOndate.setText(String.format("(as on %s)", UtilityKotlin.dateFormat2(jsonObjectMain != null ? jsonObjectMain.optString("navUpdatedUpTo") : "")));
                    }
                } catch (JSONException ignored) {
                }
            }
        });
    }

    private void getBrokerSummery() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_DASHBOARD_SUMMARY ;
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        String finalUrl = url;
        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isAdded()) {
                    if (isLoading) {
                        ProgressBarCommon.showDialog(requireActivity());
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                AppApplication.DASHBOARD_BROKER = response;
                setSummary();
                if (!Config.asOnDate.isEmpty()) {
                    tvAsOndate.setText(Config.asOnDate);
                } else {
                    setMaxNavDate();
                }
            }
        });

    }

    private void setDynamicLavelName() {
        SimpleDateFormat format = new SimpleDateFormat("MMM yy", new Locale("en", "in"));
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DATE, 1);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        cal.set(Calendar.DATE, 1);

        String dateStr = format.format(cal.getTime());
        String[] splitDate = dateStr.split(" ");
        String formatedDate = splitDate[0] + "'" + splitDate[1];
        tvLavelSipNo.setText(getString(R.string.sip_count_in,formatedDate));
        tvLavelSipPerMonth.setText(getString(R.string.sip_amount_in,formatedDate));
    }


}
