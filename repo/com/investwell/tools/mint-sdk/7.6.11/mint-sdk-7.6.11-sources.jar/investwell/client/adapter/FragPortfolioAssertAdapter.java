package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FragPortfolioAssertAdapter extends RecyclerView.Adapter<FragPortfolioAssertAdapter.MyViewHolder> {
    private ArrayList<JSONObject> jsonObjects;
    Context context;
    private AppSession mSession;
    private ClientActivity mActivity;

    public FragPortfolioAssertAdapter(Context context, ArrayList<JSONObject> jsonObjects) {

        this.context = context;
        this.jsonObjects = jsonObjects;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.frag_portfolio_assert_adapter, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        mActivity = (ClientActivity) context;

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);


        final JSONObject jsonObject = jsonObjects.get(position);
        mSession = AppSession.getInstance(context);

        holder.mTvName.setText(jsonObject.optString("applicantName"));
        holder.mTvSchemeName.setText(jsonObject.optString("assetName"));

        double currentValue = jsonObject.optDouble("purchaseValue");
        String strCurrentAmount = format.format(currentValue);
        holder.mTvInvest.setText(strCurrentAmount);

        double purchaseValue = jsonObject.optDouble("currentValue");
        String strPurchaseValue = format.format(purchaseValue);
        holder.mTvCurrent.setText(strPurchaseValue);

        double devidenValue = jsonObject.optDouble("sellValue");
        String strDEdidentValue = format.format(devidenValue);
        holder.mTvInterest.setText(strDEdidentValue);

        double gaine = jsonObject.optDouble("gain");
        String strGain = format.format(gaine);
        holder.mTvGain.setText(strGain);

        UtilityKotlin.safeDisplayXirrPercentValue(jsonObject, "XIRR", "-", "%", 2, false, holder.mTvCgar);

        holder.tvDate.setText(Utils.formatedDate(jsonObject.optString("startDate")));


      //  holder.tvDate.setText(stReturnValue);



        holder.top_linear_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("applicant_name", jsonObject.optString("applicantName"));
                bundle.putString("appid", jsonObject.optString("appid"));
                bundle.putString("folioid", jsonObject.optString("folioid"));
                //mActivity.displayViewOther(5, bundle);


            }
        });


    }

    @Override
    public int getItemCount() {

        return jsonObjects.size();
    }

    public void updateList(List<JSONObject> list) {

        jsonObjects.clear();
        jsonObjects.addAll(list);
        notifyDataSetChanged();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView mTvSchemeName, mTvName, mTvInvest, mTvCurrent, mTvInterest, mTvGain, tvDate, mTvCgar;
        LinearLayout top_linear_layout;

        public MyViewHolder(View view) {
            super(view);

            mTvSchemeName = view.findViewById(R.id.tvSchemeName);
            mTvName = view.findViewById(R.id.tvName);
            mTvInvest = view.findViewById(R.id.tvInvestment);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            tvDate = view.findViewById(R.id.tvDate);
            mTvInterest = view.findViewById(R.id.tvInterest);
            mTvGain = view.findViewById(R.id.tvGain);
            mTvCgar = view.findViewById(R.id.tvCagr);
            top_linear_layout = view.findViewById(R.id.top_linear_layout);

        }
    }

}
