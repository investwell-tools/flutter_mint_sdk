package investwell.client.fragments.portfolio;


import static android.os.Build.VERSION.SDK_INT;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.KtorHelper.requestCallDownload;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;
import com.google.android.material.tabs.TabLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;


import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragViewPagerAdapter;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.CustomViewPager;
import investwell.utils.InputStreamVolleyRequest;
import investwell.utils.UtilityKotlin;


public class FragPortfolioHome extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    public static CustomViewPager mViewPager;
    public FragViewPagerAdapter mPagerAdapter;
    public TabLayout mTabLayout;
    private TextView mTvTitle;
    private ClientActivity mActivity;
    private AppApplication mAppplication;

    @Override
    public void onResume() {
        super.onResume();
    /*    if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    public void onStart() {
        super.onStart();
        mActivity.setMainVisibility(this, null);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_portfolio_home, container, false);

        mActivity.setMainVisibility(this, null);

        mViewPager = view.findViewById(R.id.pager);
        mTabLayout = view.findViewById(R.id.tabLayout);
        mTvTitle = view.findViewById(R.id.tvTitle);
        view.findViewById(R.id.ivRight).setOnClickListener(this);

        updateViewPagerView();
        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivRight) {
                downloadFile2();
}
    }

    public void updateViewPagerView() {
        List<Fragment> fragList = new ArrayList<>();
        Fragment fragment1 = null;

        // LavelNo = 98 family Head
        // lavelNo = 100 Single

        if (mSession.getLevelNo().equals("100")) {
            fragment1 = new Portfolio_Detail();
        } else {
            fragment1 = new FragPortfolioMutualFund();
        }


        Fragment fragment2 = new FragPortfolioShare();
        Fragment fragment3 = new FragPortfolioFD();
        Fragment fragment4 = new FragPortfolioAssert();

        fragList.add(fragment1);
        fragList.add(fragment2);
        fragList.add(fragment3);
        fragList.add(fragment4);
        mPagerAdapter = new FragViewPagerAdapter(getChildFragmentManager(), fragList);
        mViewPager.setAdapter(mPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);

        mTabLayout.getTabAt(0).setText(getString(R.string.mutual_fund));
        mTabLayout.getTabAt(1).setText(getString(R.string.share_bond));
        mTabLayout.getTabAt(2).setText(R.string.fixed_deposit);
        mTabLayout.getTabAt(3).setText(R.string.other_assets);
        mTvTitle.setText(getString(R.string.portfolio));

        mViewPager.addOnPageChangeListener(onViewPageChange);

    }

    private void downloadFile2() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }

        String url = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(UtilityKotlin.getOneDayEarlier());


            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_PORTFOLIO_REPORT + "filters=" + jsonArray.toString() + "&groupBy=fixedSubAssetid"
                    + "&group=appid&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession) + "" + "&clubTxns=true";

            /*https://demo.investwell.app/webapi/client/reports/downloadPortfolioReport?filters=
            [{"endDate":"2019-08-28"}]&investorUid=5553ce3575b8e1a64181794eb86c5b27&group=
            appid&selectedUser={"uid":"5553ce3575b8e1a64181794eb86c5b27","levelNo":"98"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "portfolio_performance_", "", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_portfolio_report_download_successfully), "pdf", mFileSave,uri);
                    }
                });

    }


    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions){
            requestMultiPermissions(permissionList);
        }else {
            logD("DB", "PERMISSION GRANTED");
        }
    }
    private void requestMultiPermissions( String[] permissionList){
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }
    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)){
            Log.d("DB", "PERMISSION GRANTED");
        }else {
            isGranted = false;
            Toast.makeText(mActivity, getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2();
        }
    });


    ViewPager.OnPageChangeListener onViewPageChange = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(final int position) {

            switch (position) {
                case 0:
                    // mTvTitle.setText("Mutual Fund");

                    break;

                case 1:
                    //mTvTitle.setText("Share & Bond");
                    break;

                case 2:
                    //mTvTitle.setText("Fixed Deposit");
                    break;

                case 3:
                    //mTvTitle.setText("Others Assets");
                    break;


            }
        }


        @Override
        public void onPageScrollStateChanged(int state) {


        }
    };

}
