package investwell.client.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.iw.mint.sdk.R;
import investwell.client.activity.ClientActivity;
import investwell.utils.Utils;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by binesh on 8/5/18.
 */
public class RecyCleProfilesAdapter extends RecyclerView.Adapter<RecyCleProfilesAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private RecyCleProfilesAdapter.OnItemClickListener listener;

    public RecyCleProfilesAdapter(Context context, ArrayList<JSONObject> list, RecyCleProfilesAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycle_profile_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView bucket_icon, ivArrow;
        TextView tvName, tvUCC,tvTaxStatus, tvHolding;

        public ViewHolder(View view) {
            super(view);
            bucket_icon = view.findViewById(R.id.ivProfile);
            ivArrow = view.findViewById(R.id.ivArrow);
            tvName = view.findViewById(R.id.tvName);
            tvUCC = view.findViewById(R.id.tvUCC);
            tvTaxStatus = view.findViewById(R.id.tvTaxStatus);
            tvHolding = view.findViewById(R.id.tvHolding);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            final JSONObject jsonObject = mDataList.get(position);
            tvName.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
            tvHolding.setText(Utils.setFirstLetterCapital(jsonObject.optString("holding")));
            tvUCC.setText(jsonObject.optString("ucc"));
            tvTaxStatus.setText(Utils.setFirstLetterCapital(jsonObject.optString("taxStatus")));
/*"uid":"2e93c3951efb806c6aa7532bef18e1fb",
"levelNo":100,
"nomineeName":"AMIT KUMAR",
"nomineeRelation":"Amit Kumar",
"bseid":"2b9b8ef46afcf5d3ae2ca7841ba48d27",
"name":"MONIKA RANI",
"arnNo":"ARN-113150",
"pan":"BFXPR7529J",
"dob":"21-May-1988",
"email":"AMITKUMAR0239@GMAIL.COM",
"ucc":"IW10010132",
"status":"active",
"taxStatusCode":null,
"taxStatus":"INDIVIDUAL",
"holding":"SINGLE",
"holdingCode":null,
"JH1Name":"",
"JH2Name":"",
"isFatcaReg":"N",
"createdAt":"2018-11-12T07:35:05.000Z",
"mandateAmount":null*/
            final ClientActivity mainActivity = (ClientActivity) mContext;
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


}
