package investwell.client.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by binesh on 8/5/18.
 */

public class FragEscalationMatrixAdapter extends RecyclerView.Adapter<FragEscalationMatrixAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private FragEscalationMatrixAdapter.OnItemClickListener listener;

    public FragEscalationMatrixAdapter(Context context, ArrayList<JSONObject> list, FragEscalationMatrixAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_excalation_matrix, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNameLevel, tvName, tvEmail, tvNumber;

        public ViewHolder(View view) {
            super(view);
            tvNameLevel = view.findViewById(R.id.tvNameLevel);
            tvName = view.findViewById(R.id.tvName);
            tvEmail = view.findViewById(R.id.tvEmail);
            tvNumber = view.findViewById(R.id.tvNumber);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                final JSONObject jsonObject = mDataList.get(position);
                String levelName = jsonObject.optString("levelName")+" - ";
                tvNameLevel.setText(levelName);
                tvName.setText(jsonObject.optString("name"));
                tvEmail.setText(jsonObject.optString("email"));
                tvEmail.setContentDescription("Email. "+jsonObject.optString("email"));
                tvNumber.setContentDescription("Phone number. "+jsonObject.optString("phone"));
                tvNumber.setText(jsonObject.optString("phone"));

                tvEmail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String brokerName = "";


                        String recepientEmail = tvEmail.getText().toString(); // your destination email or leave empty
                        String subject = "Query From " + brokerName;

                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{recepientEmail});
                        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                        intent.putExtra(Intent.EXTRA_TEXT, "");
                        intent.setType("message/rfc822");
                        intent.setPackage("com.google.android.gm");

                        try {
                            mContext.startActivity(intent);
                        } catch (android.content.ActivityNotFoundException ex) {
                            Toast.makeText(mContext, "Gmail app not found", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                tvNumber.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String call4 = tvNumber.getText().toString();
                        if (call4.contains(",")) {
                            call4 = call4.replaceAll("[^0-9]", "");
                        }
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:" + call4));
                        mContext.startActivity(intent);
                    }
                });

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }

    }



    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
