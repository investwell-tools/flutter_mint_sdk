package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.iw.mint.sdk.R;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;


public class Portfolio_Detail_Adapter extends RecyclerView.Adapter<Portfolio_Detail_Adapter.MyViewHolder> {


    private ArrayList<JSONObject> jsonObject1;
    private String CID;
    private AppSession mSession;
    Context context;
    private String Name;
    private ClientActivity mAvtivity;

    public Portfolio_Detail_Adapter(Context context, ArrayList<JSONObject> jsonObject1, String CID) {

        this.context = context;
        this.jsonObject1 = jsonObject1;
        this.CID = CID;

    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.portfolio_client, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        mAvtivity = (ClientActivity) context;
        final JSONObject jsonObject = jsonObject1.get(position);

        mSession = AppSession.getInstance(context);

      DecimalFormat decimalFormat = new DecimalFormat("#0.00");

        if (jsonObject.optString("gain").contains("-")) {
            holder.gain_arrow.setBackgroundResource(R.drawable.menu_down);
        } else {
            holder.gain_arrow.setBackgroundResource(R.drawable.menu_up);
        }
        if (jsonObject.optString("CAGR").contains("-")) {
            holder.cagr_arrow.setBackgroundResource(R.drawable.menu_down);
        } else {
            holder.cagr_arrow.setBackgroundResource(R.drawable.menu_up);
        }

        holder.folio.setVisibility(View.VISIBLE);

        holder.applicant_name.setText(jsonObject.optString("schemeName"));
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
        double purchaseValue = jsonObject.optDouble("purchaseValue");
        String strPurchaseValue = format.format(purchaseValue);
        holder.purchase_cost.setText(strPurchaseValue);

        double currentValue = jsonObject.optDouble("currentValue");
        String strCurrentValue = format.format(currentValue);
        holder.market_value.setText(strCurrentValue);

        double Gain = jsonObject.optDouble("gain");
        String strCurrentAmount = format.format(Gain);
        holder.gain.setText(strCurrentAmount);

        String cagrStr = jsonObject.optString("CAGR");
        if (!cagrStr.equalsIgnoreCase("null")){
            holder.cagr.setText(decimalFormat.format(Double.parseDouble(cagrStr)) + "%");
        }else{
            holder.cagr.setText(mAvtivity.getString(R.string.not_available));
        }

        holder.folio.setText(jsonObject.optString("folioNo"));

        holder.top_linear_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Bundle bundle = new Bundle();
                    // bundle.putString("applicant_name", Name);
                    jsonObject.put("applicant_name", Name);
                    bundle.putString("data", jsonObject.toString());
                    mAvtivity.displayViewOther(7, bundle);
                } catch (Exception e) {

                }
            }
        });

    }

    @Override
    public int getItemCount() {

        return jsonObject1.size();
    }

    public void updateList(List<JSONObject> list, String name) {

        jsonObject1.clear();
        jsonObject1.addAll(list);
        Name = name;
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView applicant_name, purchase_cost, market_value, gain, cagr, folio;
        ImageView next_arrow, gain_arrow, cagr_arrow;
        LinearLayout top_linear_layout;

        @Override
        public boolean equals(@Nullable Object obj) {
            return super.equals(obj);
        }

        public MyViewHolder(View view) {
            super(view);

            applicant_name = view.findViewById(R.id.applicant_name);
            purchase_cost = view.findViewById(R.id.purchase_cost);
            market_value = view.findViewById(R.id.market_value);
            gain = view.findViewById(R.id.gain);
            cagr = view.findViewById(R.id.cagr);
            folio = view.findViewById(R.id.folio);
            next_arrow = view.findViewById(R.id.next_arrow);
            gain_arrow = view.findViewById(R.id.gain_arrow);
            cagr_arrow = view.findViewById(R.id.cagr_arrow);
            top_linear_layout = view.findViewById(R.id.top_linear_layout);

        }
    }
}
