package investwell.client.adapter;

import static investwell.utils.UtilityKotlin.isAccessibilityOn;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.folio.FragFolioLookup;
import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FolioLookupAdapter extends RecyclerView.Adapter<FolioLookupAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private FolioLookupAdapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragFolioLookup mFragmenFolioLookup;
    private AppSession mSession;

    public FolioLookupAdapter(Context context, FragFolioLookup fragFolioLookup, ArrayList<JSONObject> list, FolioLookupAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mFragmenFolioLookup = fragFolioLookup;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_folio_lookup_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, text1, text2, text3, text4, text5, text6, tvNseBse;
        CardView card_view;
        ImageView ivThreeDots;
        View ivThreeUpper;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            text1 = view.findViewById(R.id.text1);
            text2 = view.findViewById(R.id.text2);
            text3 = view.findViewById(R.id.text3);
            text4 = view.findViewById(R.id.text4);
            text5 = view.findViewById(R.id.text5);
            text6 = view.findViewById(R.id.text6);
            card_view = view.findViewById(R.id.card_view);
            ivThreeDots = view.findViewById(R.id.ivThreeDots);
            tvNseBse = view.findViewById(R.id.tvNseBse);
            ivThreeUpper = view.findViewById(R.id.ivThreeUpper);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                if (mSession.getExchangeNseBseMfu().equals("1")) {
                    tvNseBse.setText(mContext.getString(R.string.inn));
                } else if (mSession.getExchangeNseBseMfu().equals("2") || mSession.getExchangeNseBseMfu().equals("4")) {
                    tvNseBse.setText(mContext.getString(R.string.ucc));
                } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                    tvNseBse.setText(mContext.getString(R.string.can));
                }

                final JSONObject jsonObject = mDataList.get(position);

                tvName.setText(jsonObject.optString("schemeName"));
                double balanceUnits = jsonObject.optDouble("AUM");
                String strPurchaseValue = format.format(balanceUnits);
                text1.setText(strPurchaseValue);
                text2.setText(jsonObject.optString("folioNo"));
                text4.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));


                String pan = jsonObject.optString("pan");
                if (pan.equals("") || pan.equalsIgnoreCase("null")){
                    text6.setText(mContext.getResources().getString(R.string.not_available));
                }else {
                    text6.setText(pan);
                }

                String holding = jsonObject.optString("holding");
                if (holding.equals("") || holding.equalsIgnoreCase("null")){
                    text5.setText(mContext.getResources().getString(R.string.not_available));
                }else{
                    text5.setText(Utils.SchemeNameFormat(jsonObject.optString("holding")));
                }

                String uccIinMfu = "";
                if (mSession.getExchangeNseBseMfu().equals("1")) {
                    if (jsonObject.has("iinNumber")){
                        uccIinMfu = jsonObject.optString("iinNumber");
                    }else{
                        uccIinMfu = jsonObject.optString("iinNo");
                    }

                } else if (mSession.getExchangeNseBseMfu().equals("2")) {
                    uccIinMfu = jsonObject.optString("uccNumber");
                } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                    uccIinMfu = jsonObject.optString("canNumber");
                }else if (mSession.getExchangeNseBseMfu().equals("4")) {
                    uccIinMfu = jsonObject.optString("nseUccCode");
                }
                if (uccIinMfu.equalsIgnoreCase("") || uccIinMfu.equalsIgnoreCase("null")) {
                    text3.setText(mContext.getString(R.string.not_available));
                } else {
                    text3.setText(uccIinMfu);
                }

                ivThreeDots.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onClick(View v) {

                        Context popupContext = new ContextThemeWrapper(mContext, R.style.AppPopupMenuStyle);

                        PopupMenu menu = new PopupMenu(popupContext, ivThreeUpper);
                        menu.inflate(R.menu.menu_folio);

                        if (mSession.getLoginType().equalsIgnoreCase("client")) {
                            menu.getMenu().findItem(R.id.item1).setVisible(false);
                        } else {
                            menu.getMenu().findItem(R.id.item1).setVisible(true);
                        }

                        menu.setOnMenuItemClickListener(item -> {
                            Bundle bundle1 = new Bundle();
                            ClientActivity mainActivity = null;
                            BrokerActivity brokerActivity = null;
                            if (mContext instanceof BrokerActivity) {
                                brokerActivity = (BrokerActivity) mContext;
                            } else if (mContext instanceof ClientActivity) {
                                mainActivity = (ClientActivity) mContext;
                            }

                            if (item.getItemId() == R.id.item1) {
                                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                                    String schemeId = Utils.getSchemeIdFromAll(jsonObject);
                                    bundle1.putString("schid", schemeId);
                                    bundle1.putString("isAnimation", "true");
                                    if (mainActivity != null)
                                        mainActivity.displayViewOther(16, bundle1);
                                    else {
                                        brokerActivity.displayViewOther(16, bundle1);
                                    }
}
else if (item.getItemId() == R.id.item2) {
                                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                                    String schemeId2 = Utils.getSchemeIdFromAll(jsonObject);
                                    bundle1.putString("schid", schemeId2);
                                    bundle1.putString("isAnimation", "true");
                                    if (mainActivity != null)
                                        mainActivity.displayViewOther(15, bundle1);
                                    else {
                                        brokerActivity.displayViewOther(15, bundle1);
                                    }
}
else if (item.getItemId() == R.id.item3) {
                                    mFragmenFolioLookup.downloadFile2(jsonObject.optString("folioid"), Utils.getSchemeIdFromAll(jsonObject));
}
                            return true;
                        });

                        MenuPopupHelper menuHelper = new MenuPopupHelper(popupContext, (MenuBuilder) menu.getMenu(), ivThreeUpper);
                        menuHelper.setForceShowIcon(true);
                        menuHelper.show();

                    }
                });
                if (mSession.getExchangeNseBseMfu().equalsIgnoreCase("4")){
                    tvNseBse.setVisibility(View.INVISIBLE);
                    text3.setVisibility(View.INVISIBLE);
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
           AccessibilityManager accessibilityManager = (AccessibilityManager) mContext.getSystemService(Context.ACCESSIBILITY_SERVICE);

            if (accessibilityManager != null) {
               AccessibilityManager.AccessibilityStateChangeListener accessibilityListener = enabled -> {
                    if (!enabled)
                        itemView.setOnClickListener(v -> listener.onItemClick(position));
                };
                accessibilityManager.addAccessibilityStateChangeListener(accessibilityListener);

            }


        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


}
