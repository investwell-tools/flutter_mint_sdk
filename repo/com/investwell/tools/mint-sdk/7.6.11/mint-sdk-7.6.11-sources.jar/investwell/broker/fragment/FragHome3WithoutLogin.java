package investwell.broker.fragment;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.ArrayList;

import investwell.activity.AppApplication;
import investwell.activity.DomainActivity;
import investwell.activity.LoginActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragCalculatorsAdapter;
import investwell.common.calculator.CalculatorsActivity;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.ProgressBarCommon;


public class FragHome3WithoutLogin extends BaseFragment implements View.OnClickListener {
    private View view;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private FragCalculatorsAdapter mCalculatorsAdapter;
    private AppApplication mApplication;
    private ImageView mIvLogo;


    @Override
    public void onDestroy() {
        super.onDestroy();
        ProgressBarCommon.dismissDialog();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.frag_home3_without_login, container, false);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
//            mBrokerActivity.notificationPermission();
        } else {
            mMainActivity.setMainVisibility(this, null);
//            mMainActivity.notificationPermission();
        }

        view.findViewById(R.id.btLogin).setOnClickListener(this);
        view.findViewById(R.id.btSignup).setOnClickListener(this);
        view.findViewById(R.id.tvViewAllCalculators).setOnClickListener(this);
        view.findViewById(R.id.cardView1).setOnClickListener(this);
        view.findViewById(R.id.cardView2).setOnClickListener(this);
        view.findViewById(R.id.cardView3).setOnClickListener(this);
        view.findViewById(R.id.cardView4).setOnClickListener(this);
        mIvLogo = view.findViewById(R.id.ivAppLogo);
        if (getString(R.string.subdomain).equalsIgnoreCase("aaamerbank") || mSession.getUserBrokerDomain().equalsIgnoreCase("aaamerbank")){
            view.findViewById(R.id.tvIntro).setVisibility(View.GONE);
            view.findViewById(R.id.ivAppLogo).setVisibility(View.GONE);
        }else{
            view.findViewById(R.id.tvIntro).setVisibility(View.VISIBLE);
            view.findViewById(R.id.ivAppLogo).setVisibility(View.VISIBLE);
        }

        if (getString(R.string.subdomain).equalsIgnoreCase("hlkapoor") || getString(R.string.subdomain).equalsIgnoreCase("aaamerbank")){
            view.findViewById(R.id.tvIntro).setVisibility(View.GONE);
        }else{
            view.findViewById(R.id.tvIntro).setVisibility(View.VISIBLE);
        }

        if (mSession.getOnBoarding() == 1) {
            view.findViewById(R.id.btSignup).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.btSignup).setVisibility(View.GONE);
        }
        setTintColorIfDark(requireActivity(), mIvLogo);

        mIvLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getString(R.string.subdomain).equals("mint")) {
            String imagePath = mSession.getAppLogo();
            if (!imagePath.equals("")) {
                Picasso.get().load(imagePath)
                        .error(R.drawable.app_logo_secondry_mint).into(mIvLogo);

            } else {
                mIvLogo.setImageResource(R.drawable.app_logo_secondry_mint);
            }
        } else {
            mIvLogo.setImageResource(R.mipmap.app_logo_secondry);
        }

        RecyclerView rvCalculators = view.findViewById(R.id.rvCalculators);
        rvCalculators.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        mCalculatorsAdapter = new FragCalculatorsAdapter(getActivity(), new ArrayList<JSONObject>(), new FragCalculatorsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                if (mMainActivity!=null){
                    if (position == 0) {
                        mMainActivity.displayViewCalculator(7, null);
                    } else if (position == 1) {
                        mMainActivity.displayViewCalculator(8, null);
                    } else if (position == 2) {
                        mMainActivity.displayViewCalculator(6, null);
                    } else if (position == 3) {
                        mMainActivity.displayViewCalculator(4, null);
                    }
                }else{
                    if (position == 0) {
                        mBrokerActivity.displayViewCalculator(7, null);
                    } else if (position == 1) {
                        mBrokerActivity.displayViewCalculator(8, null);
                    } else if (position == 2) {
                        mBrokerActivity.displayViewCalculator(6, null);
                    } else if (position == 3) {
                        mBrokerActivity.displayViewCalculator(4, null);
                    }
                }


            }
        });
        rvCalculators.setAdapter(mCalculatorsAdapter);
        return view;
    }


    @Override
    public void onClick(View v) {
        Intent intent;
        int id = v.getId();
        if (id == R.id.cardView1 || id == R.id.cardView2 || id == R.id.cardView3 || id == R.id.cardView4 || id == R.id.btLogin) {
            if (mSession.getUserBrokerDomain().length() > 0 && mSession.getUserBrokerDomain().length() > 0) {
                intent = new Intent(getActivity(), LoginActivity.class);
            } else {
                intent = new Intent(getActivity(), DomainActivity.class);
            }

            intent.putExtra("login_come_from", "Dashboard");
            startActivity(intent);
            requireActivity().overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
        } else if (id == R.id.btSignup) {
            intent = new Intent(getActivity(), DomainActivity.class);
            intent.putExtra("login_come_from", "Register");
            startActivity(intent);
        } else if (id == R.id.tvViewAllCalculators) {
            intent = new Intent(requireActivity(), CalculatorsActivity.class);
            startActivity(intent);
            requireActivity().overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
        }
    }


}
