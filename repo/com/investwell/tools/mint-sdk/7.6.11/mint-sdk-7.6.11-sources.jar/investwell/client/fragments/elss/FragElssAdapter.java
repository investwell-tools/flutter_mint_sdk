package investwell.client.fragments.elss;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * Created by Dev on 16/08/2021.
 */

public class FragElssAdapter extends RecyclerView.Adapter<FragElssAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private FragElssAdapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragELSS1User mFragELSS;
    private AppSession mSession;
    private String mType = "";

    public FragElssAdapter(Context context, String type, ArrayList<JSONObject> list, FragElssAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mType = type;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_elss_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvAmount;
        CardView card_view;
        View ivThreeUpper;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvAmount = view.findViewById(R.id.tvAmount);

            card_view = view.findViewById(R.id.card_view);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObject = mDataList.get(position);
                double purchaseValue;
                if (jsonObject.has("amount")) {
                    purchaseValue = jsonObject.optDouble("amount", 0.0);
                } else {
                    JSONObject summaryObject = jsonObject.optJSONObject("schemes").optJSONObject("summary");
                    if (summaryObject != null) {
                        purchaseValue = summaryObject.optDouble("amount", 0.0);
                    } else {
                        purchaseValue = 0.0;
                    }
                }

                if (mType.equalsIgnoreCase("type_user")) {
                    tvName.setText(Utils.setFirstLetterCapital(jsonObject.optString("clientName")));
                    tvName.setTextColor(ContextCompat.getColor(mContext, R.color.black));

//                    double purchaseValue = jsonObject.optDouble("amount");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvAmount.setText(strPurchaseValue);
                } else if (mType.equalsIgnoreCase("type_scheme")) {
                    tvName.setText(jsonObject.optString("schemeName"));
                    tvName.setTextColor(ContextCompat.getColor(mContext, R.color.cardview_top_name_color));
//                    double purchaseValue = jsonObject.optDouble("amount");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvAmount.setText(strPurchaseValue);
                }

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });

        }
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


}
