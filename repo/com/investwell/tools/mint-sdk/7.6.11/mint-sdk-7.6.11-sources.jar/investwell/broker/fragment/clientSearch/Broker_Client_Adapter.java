package investwell.broker.fragment.clientSearch;

import static android.content.Context.INPUT_METHOD_SERVICE;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.UtilityKotlin.loadImageBrokerSeArchWithAuthentication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.ImageLoader;
import investwell.utils.ProgressBarCommon;
import investwell.utils.RoundedImageView;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class Broker_Client_Adapter extends ListAdapter<JSONObject, Broker_Client_Adapter.MyViewHolder> {
    private static final DiffUtil.ItemCallback<JSONObject> DIFF_CALLBACK =
            new DiffUtil.ItemCallback<>() {

                @Override
                public boolean areItemsTheSame(@NonNull JSONObject oldItem, @NonNull JSONObject newItem) {
                    return oldItem.optString("uid").equals(newItem.optString("uid"));
                }

                @Override
                public boolean areContentsTheSame(@NonNull JSONObject oldItem, @NonNull JSONObject newItem) {
                    return oldItem.toString().equals(newItem.toString());
                }
            };
    Context context;
    private AppSession mSession;
    private final AppApplication appApplication;
    private long lastClickTime = 0;
    private long clickThreshold = 2000;
    private ClientFilterOptionEnum mSearchType = ClientFilterOptionEnum.NAME;


    public Broker_Client_Adapter(Context context) {
        super(DIFF_CALLBACK);
        this.context = context;
        appApplication = (AppApplication) context.getApplicationContext();
    }


    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.broker_client_adapter, parent, false);
        return new MyViewHolder(v);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NotNull MyViewHolder holder, final int position) {

        try {
            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
            format.setMinimumFractionDigits(0);
            format.setMaximumFractionDigits(0);

            final JSONObject jsonObject = getItem(position);
            mSession = AppSession.getInstance(context);

            String name = Utils.setFirstLetterCapital(jsonObject.optString("name"));
            String familyHead = Utils.setFirstLetterCapital(jsonObject.optString("familyHead"));
            if (familyHead.equalsIgnoreCase("null") || familyHead.equalsIgnoreCase("")) {
                holder.tvFamilyHead.setVisibility(View.GONE);
            } else if (familyHead.equalsIgnoreCase("self")) {
                holder.tvFamilyHead.setVisibility(View.VISIBLE);
                holder.tvFamilyHead.setText(name + " (FH)");
            } else {
                holder.tvFamilyHead.setVisibility(View.VISIBLE);
                holder.tvFamilyHead.setText(familyHead + " (FH)");
            }

            if (mSearchType == ClientFilterOptionEnum.EQUITY_CODE_1) {
                String equityCode = jsonObject.optString("name");
                if (!equityCode.equalsIgnoreCase("null") && !equityCode.isEmpty()) {
                    holder.llEquityCode.setVisibility(View.VISIBLE);
                    holder.tvEquityCode.setText(equityCode);
                } else {
                    holder.llEquityCode.setVisibility(View.GONE);
                }
            } else {
                holder.llEquityCode.setVisibility(View.GONE);
            }


            holder.tvName.setText(name);

            String pan = jsonObject.optString("pan");
            if (pan.equalsIgnoreCase("null") || pan.isEmpty()) {
                holder.tvPAN.setVisibility(View.GONE);
            } else {
                holder.tvPAN.setVisibility(View.VISIBLE);
                holder.tvPAN.setText(pan);
            }

            String profileImage = jsonObject.optString("profileImage");
            if (profileImage.isEmpty() || profileImage.equals("null")) {
                holder.tvNameSymbol.setVisibility(View.VISIBLE);
                holder.ivProfilePic.setVisibility(View.GONE);
            } else {
                holder.tvNameSymbol.setVisibility(View.GONE);
                holder.ivProfilePic.setVisibility(View.VISIBLE);
                // loadImageBrokerSeArchWithAuthentication(context, mSession ,holder.ivProfilePic, false, jsonObject.optString("uid"),profileImage);

                ImageLoader.loadImageWithAuthentication(
                        context,
                        mSession,
                        holder.ivProfilePic,
                        false,
                        jsonObject.optString("uid"),
                        holder.progressBar,
                        profileImage);

               /* image_path = image_path + "connect.sid=" + mSession.getServerToken();
                Picasso.get()
                        .load(image_path)
                        .tag(context)
                        .placeholder(R.mipmap.profileplaceholder)
                        .error(R.mipmap.profileplaceholder)
                        .into(holder.ivProfilePic);*/
            }

            holder.ivShare.setOnClickListener(v -> getInviteMessage(jsonObject));

            final String phoneNumber = jsonObject.optString("mobile");
            if (!phoneNumber.isEmpty() && !phoneNumber.equalsIgnoreCase("null")) {
                holder.tvPhone.setVisibility(View.VISIBLE);
                holder.tvPhone.setText(phoneNumber);
            } else {
                holder.tvPhone.setVisibility(View.GONE);
            }

            holder.tvPhone.setOnClickListener(v -> {
                if (phoneNumber == null || phoneNumber.trim().isEmpty() || phoneNumber.equalsIgnoreCase("null")) {
                    Toast.makeText(v.getContext(), v.getContext().getString(R.string.text_phone_number_client), Toast.LENGTH_SHORT).show();
                    return;
                }
                String safeNumber = Uri.encode(phoneNumber.trim());
                Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + safeNumber));
                Context activityContext = v.getContext();
                try {
                    activityContext.startActivity(callIntent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(activityContext, R.string.txt_no_dialer_app_found, Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(activityContext, R.string.txt_unable_to_open_dialer, Toast.LENGTH_SHORT).show();
                }
            });


            if (!pan.equalsIgnoreCase("null") && !pan.isEmpty()
                    && !phoneNumber.isEmpty() && !phoneNumber.equalsIgnoreCase("null")) {
                holder.v_Phone_Pan.setVisibility(View.VISIBLE);
            } else {
                holder.v_Phone_Pan.setVisibility(View.GONE);
            }

            try {
                if (mSearchType == ClientFilterOptionEnum.EQUITY_CODE_1 && jsonObject.has("equityCode1")) {
                    String equityCode = jsonObject.optString("equityCode1");
                    if (!equityCode.equalsIgnoreCase("null") && !equityCode.isEmpty()) {
                        holder.llEquityCode.setVisibility(View.VISIBLE);
                        holder.tvEquityCode.setText(equityCode);

                        if (!pan.equalsIgnoreCase("null") && !pan.isEmpty()
                                || !phoneNumber.isEmpty() && !phoneNumber.equalsIgnoreCase("null")) {
                            holder.v_equityCode.setVisibility(View.VISIBLE);
                        } else {
                            holder.v_equityCode.setVisibility(View.GONE);
                        }

                    } else {
                        holder.llEquityCode.setVisibility(View.GONE);
                    }
                } else {
                    holder.llEquityCode.setVisibility(View.GONE);
                }
            } catch (Exception e) {

            }
            View.OnClickListener onClientClick = view1 -> {
                long currentTime = System.currentTimeMillis();
                long diff = currentTime - lastClickTime;
                if (diff < clickThreshold) {
                    logD("client_object_clear , clicked Difference = " + diff);
                    return;
                }
                lastClickTime = currentTime;
                logD("client_object_clear method called first time");
                callPermissionsApi(name, phoneNumber, jsonObject);
                InputMethodManager imm = (InputMethodManager) context.getSystemService(INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(view1.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);
            };

            /*
              every view treat as TL TD in here textview click
             */
            holder.itemView.setOnClickListener(onClientClick);
            holder.relMain.setOnClickListener(onClientClick);
            holder.tvName.setOnClickListener(onClientClick);
            holder.tvFamilyHead.setOnClickListener(onClientClick);
            holder.tvPAN.setOnClickListener(onClientClick);
//            holder.itemView.findViewById(R.id.tvLavelFamilyHead).setOnClickListener(onClientClick);
//            holder.itemView.findViewById(R.id.tv_label_pan).setOnClickListener(onClientClick);

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        } finally {
            String[] array = context.getResources().getStringArray(R.array.colors);
            String randomStr = array[new Random().nextInt(array.length)];
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                holder.tvNameSymbol.getBackground().setTint(Color.parseColor(randomStr));
            }

            String name = holder.tvName.getText().toString();
            name = name.trim();
            if (!name.isEmpty()) {
                String usertext = "";
                String[] n = name.split(" ", 2);
                for (String s : n) {
                    usertext = usertext + s.charAt(0);
                }
                holder.tvNameSymbol.setText(usertext);
            }
        }
    }

    private void callPermissionsApi(String name, String phoneNumber, JSONObject jsonObject) {
        String uId = "";
        String levelNo = "";
        String url = "";
        JSONObject selectedUser = new JSONObject();
        try {
            uId = jsonObject.optString("uid");
            String familyHead1 = jsonObject.optString("familyHead");
            if (familyHead1.equals("self")) {
                jsonObject.put("levelNo", 98);
            } else if (familyHead1.equals("null")) {
                jsonObject.put("levelNo", 100);
            } else {
                jsonObject.put("levelNo", 100);
            }

            levelNo = jsonObject.optString("levelNo");
            if (selectedUser != null) {
                selectedUser.put("uid", uId);
                selectedUser.put("levelNo", levelNo);
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_ALLOWED_FEATURES + selectedUser;
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        ApiClient client = new ApiClient(context, mSession);
        client.makeGetRequest(url,
                isLoading -> {
                    if (isLoading) {
                        ProgressBarCommon.showDialog(context);
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                }, response -> {
                    JSONObject jsonObjectRes = null;
                    try {
                        jsonObjectRes = new JSONObject(response);
                        JSONObject resultData = jsonObjectRes.optJSONObject("result");
                        if (jsonObjectRes.optInt("status") == 0) {

                            if (resultData != null) {
                                AppApplication.TMP_ALLOWED_FEATURED = resultData.toString();
                            }

                            try {
                                String familyHead1 = jsonObject.optString("familyHead");
                                String mUserType = "";
                                if (familyHead1.equals("self")) {
                                    jsonObject.put("levelNo", 98);
                                    mUserType = "familyHead";
                                } else if (familyHead1.equals("null")) {
                                    jsonObject.put("levelNo", 100);
                                    mUserType = "single";
                                } else {
                                    jsonObject.put("levelNo", 100);
                                    mUserType = "single";
                                }
                                //  mSession.setUserTypeFamilyHead(mUserType);
//callAllowedFeatures();
                                mSession.setClientObject(jsonObject.toString());
                                logD("client_object_clear ,data Assigned: Broker_Client_adapter");
                                AppApplication.CLIENT_DASHBOARD_BAL_SUMMARY = "";
                                AppApplication.DASHBOARD_PORTFOLIO = "";
                                AppApplication.DASHBOARD_PORTFOLIO_FD = "";
                                AppApplication.DASHBOARD_PORTFOLIO_ASSERT = "";
                                // AppApplication.DASHBOARD_BROKER = "";
                                AppApplication.DASHBOARD_TRAN_MEMBERS = "";
                                AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                                mSession.setPersonName(name);
                                mSession.setUserMob(phoneNumber);
                                // AppApplication.DASHBOARD_BROKER = "";
                                Intent intent = new Intent(context, ClientActivity.class);
                                intent.putExtra("coming_from", "broker");
                                context.startActivity(intent);
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG)
                                    e.printStackTrace();
                            }


                        } else {
                            String errorMessge = jsonObjectRes.optString("message");
                            if (!errorMessge.equalsIgnoreCase("invalid request"))
                                Toast.makeText(context, errorMessge, Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        System.out.println();
                    }
                    return null;
                }, volleyError -> {
//                    if (mBar != null)
//                        mBar.dismiss();
                    if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                        VolleyError error = new VolleyError(new String(volleyError.networkResponse.data));
                        try {
                            JSONObject jsonObject2 = new JSONObject(error.getMessage());
                            Toast.makeText(context, jsonObject2.optString("error"), Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    } else if (volleyError instanceof NoConnectionError) {
                        Toast.makeText(context, context.getResources().getString(R.string.no_internet), Toast.LENGTH_LONG).show();
                    } else {
                        String error = volleyError.getLocalizedMessage();
                    }

                    return null;
                }, status -> {
                    if (status == 401) {
                        appApplication.showCommonDailog(context, context.getString(R.string.txt_session_expired), context.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }
                    return null;
                });

    }


    public void updateList(List<JSONObject> list, ClientFilterOptionEnum searchType) {
        mSearchType = searchType;
        submitList(new ArrayList<>(list));
    }

    public void clearList() {
        submitList(new ArrayList<>());
    }


    private void getInviteMessage(final JSONObject jsonObject) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, context)) {
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(context, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_INVITE_MESSAGE
                    + "uid=" + jsonObject.optString("uid");
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

//http://demo.investwellonline.com/webapi/broker/mobile/getInviteMessage?uid=
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject mainObject = new JSONObject(response);

                            if (mainObject.optInt("status") == 0) {
                                JSONObject jsonObject1 = mainObject.optJSONObject("result");

                                String commonMessage = jsonObject1.optString("inviteMessage");
                                if (commonMessage.isEmpty()) {
                                    getShareData(jsonObject);
                                } else {
                                    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                                    sharingIntent.setType("text/plain");
                                    sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, context.getString(R.string.app_name));
                                    sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, commonMessage);
                                    context.startActivity(Intent.createChooser(sharingIntent, context.getString(R.string.txt_share_using)));
                                }
                            } else {
                                getShareData(jsonObject);
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        UtilityKotlin.parseVolleyError(volleyError, mSession, context, "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, context);
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, context);
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    appApplication.showCommonDailog(context, context.getString(R.string.txt_session_expired), context.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getShareData(final JSONObject jsonObject) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, context)) {
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(context, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_Password_Reset_Data
                    + "appid=" + jsonObject.optString("appid");

            //https://finnovators.investwell.app/webapi/broker/mobile/getResetPasswordLink?appid=f15b68a09649b757434b6b156d357958

            url = URLDecoder.decode(url, "UTF-8");
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {

                    if (mBar != null)
                        mBar.dismiss();
                    try {
                        JSONObject mainObject = new JSONObject(response);

                        if (mainObject.optInt("status") == 0) {
                            JSONObject jsonObject1 = mainObject.optJSONObject("result");
                            // String playstoreLink = mSession.getPlayStoreLink();

                            final String appPackageName = context.getPackageName();
                            String playstoreLink = "https://play.google.com/store/apps/details?id=" + appPackageName;
                            String appStore = mSession.getAppStoreLink();

                            String resetUrl = jsonObject1.optString("url");
                            String mainMessage = context.getString(R.string.broker_share_text_dear) + " "
                                    + jsonObject.optString("name") + "\n\n"
                                    + context.getString(R.string.broker_share_reset_text)
                                    + "\n\n" + context.getString(R.string.broker_share_reset_link_text)
                                    + "\n" + resetUrl
                                    + "\n\n" + context.getString(R.string.broker_share_Broker_Domaintext)
                                    + " " + mSession.getUserBrokerDomain()
                                    + "\n\n" + context.getString(R.string.broker_share_text_username)
                                    + " " + jsonObject1.optString("username")
                                    + "\n\n" + context.getString(R.string.broker_share_download_app_text)
                                    + playstoreLink
                                    + "\n\n" + context.getString(R.string.broker_share_download_appstore_text)
                                    + appStore
                                    + "\n\n" + context.getString(R.string.broker_share_data_privacy_text);

/*      JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
                           String commonMessage = appConfigObject.optString("inviteMessage");*/
                            Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                            sharingIntent.setType("text/plain");
                            sharingIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name));
                            sharingIntent.putExtra(Intent.EXTRA_TEXT, mainMessage);
                            context.startActivity(Intent.createChooser(sharingIntent, context.getString(R.string.txt_share_using)));

                            /*Dear Aadam Nuruddin Sadikot

We have launched an all new Portfolio access for you. All your Investments will be updated with their Daily end of day prices. You can see your Portfolio’s return on investment and see your hard work pay off.  Please use the link below to generate a password.

Your Username
spvithlani.investwell.app/app/#/resetpassword/GYIPS6817M/a5ece8aa618d39c98e73f1a2cffefc2fcd715b17fdbdeb2eb407708c55d3b278

Broker Domain asked in Mobile app login : spvithlani
Reset Password link - spvithlani.investwell.app/app/#/resetpassword/GYIPS6817M/a5ece8aa618d39c98e73f1a2cffefc2fcd715b17fdbdeb2eb407708c55d3b278
Download the app -https://itunes.apple.com/us/app/Mint/id1479042500?mt=8
We are committed to ensuring your data privacy. This link will expire in 2 days time.*/

                        }

                    } catch (Exception e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        UtilityKotlin.parseVolleyError(volleyError, mSession, context, "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, context);
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, context);
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    appApplication.showCommonDailog(context, context.getString(R.string.txt_session_expired), context.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvFamilyHead, tvPhone, tvPAN, tvNameSymbol, tvEquityCode;
        RelativeLayout relMain;
        LinearLayout llEquityCode;
        ImageView ivShare;
        View v_Phone_Pan, v_equityCode;
        RoundedImageView ivProfilePic;
        ProgressBar  progressBar;

        public MyViewHolder(View view) {
            super(view);
            ivProfilePic = view.findViewById(R.id.ivProfile);
            tvName = view.findViewById(R.id.name);
            tvNameSymbol = view.findViewById(R.id.tvNameSymbol);
            tvFamilyHead = view.findViewById(R.id.tvFamilyHead);
            //  tvPhone = view.findViewById(R.id.phone);
            tvPAN = view.findViewById(R.id.tvPAN);
            relMain = view.findViewById(R.id.relMain);
            ivShare = view.findViewById(R.id.ivShare);
            tvPhone = view.findViewById(R.id.tvPhoneNumber);
            v_Phone_Pan = view.findViewById(R.id.v_mobile);
            v_equityCode = view.findViewById(R.id.v_equityCode);
            tvEquityCode = view.findViewById(R.id.tvEquityCode);
            llEquityCode = view.findViewById(R.id.llEquityCode);
            progressBar = view.findViewById(R.id.progressBar);


        }
    }

}
