package investwell.client.adapter;

import static investwell.utils.ExtensionsKt.checkSecondHolderName;
import static investwell.utils.ExtensionsKt.checkThirdHolderName;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.utils.AppSession;
import investwell.utils.Extensions;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class IinbyFolioAdapter extends RecyclerView.Adapter<IinbyFolioAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private IinbyFolioAdapter.OnItemClickListener listener;
    private NumberFormat format;
    public HashMap<Integer, Boolean> mHashSelection = new HashMap<>();
    private AppSession mSession;

    public IinbyFolioAdapter(Context context, ArrayList<JSONObject> list, int width, IinbyFolioAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);

        format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.iin_by_folio_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {

        return mDataList.size();

    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvText1, tvText2, tvText3, tvText4, tvText5, tvNominee, tvTaxStatus;
        TextView tvLevel4, tvLevel5, tvLevelTaxStatus, tvArn;
        LinearLayout lliinType;
        RelativeLayout relMain;
        ImageView ivSelected;
        CardView mainCardView;
        CheckBox cbSelected;


        public ViewHolder(View view) {
            super(view);
            tvText1 = view.findViewById(R.id.tvText1);
            tvText2 = view.findViewById(R.id.tvText2);
            tvText3 = view.findViewById(R.id.tvText3);
            tvText4 = view.findViewById(R.id.tvText4);
            tvText5 = view.findViewById(R.id.tvText5);
            tvTaxStatus = view.findViewById(R.id.tvTaxStatus);
            tvNominee = view.findViewById(R.id.tvNominee);
            tvLevel4 = view.findViewById(R.id.tvLevel4);
            tvLevel5 = view.findViewById(R.id.tvLevel5);
            lliinType = view.findViewById(R.id.ll_iinType);
            relMain = view.findViewById(R.id.relMain);
            mainCardView = view.findViewById(R.id.cardMainLayout);
            ivSelected = view.findViewById(R.id.ivSelected);
            cbSelected = view.findViewById(R.id.cbSelected);
            tvLevelTaxStatus = view.findViewById(R.id.tvLevelTaxStatus);
            tvArn = view.findViewById(R.id.tvArn);


        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                JSONObject jsonObject = mDataList.get(position);

                String exchange = "";
                if (mSession.getHasMultiExchange()) {
                    exchange = AppApplication.sExchangeType;
                    if (exchange == "") exchange = mSession.getExchangeNseBseMfu();
                } else {
                    if (mSession.getHasNseOpted()) {
                        exchange = "1";
                    } else if (mSession.getHasBseOpted()) {
                        exchange = "2";
                    } else if (mSession.getHasMfuOpted()) {
                        exchange = "3";
                    }  else if (mSession.getHasNse2Opted()) {
                        exchange = "4";
                    }else {
                        // exchange = mSession.getExchangeNseBseMfu();
                    }
                }

                if (exchange.equals("1")) {
                    tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                    tvText2.setText(jsonObject.optString("pan"));


                    tvText4.setText(jsonObject.optString("iinNo"));
                    tvLevel4.setText(mContext.getString(R.string.inn));

                    String joint1 = jsonObject.optString("JH1Name", "");
                    String joint2 = jsonObject.optString("JH2Name", "");

                    if (!Utils.isEmptyOrNull(joint1)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    } else if (!Utils.isEmptyOrNull(joint2)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint2));
                    } else if (!Utils.isEmptyOrNull(joint1) && !Utils.isEmptyOrNull(joint2)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint1) + "," + Utils.setFirstLetterCapital(joint2));
                    } else {
                        tvText3.setText(mContext.getString(R.string.not_available));
                    }


                    String nomineeName = "";
                    if (jsonObject.has("nomineeName")) {
                        nomineeName = jsonObject.optString("nomineeName");
                    } else if (jsonObject.has("nominee1Name")) {
                        nomineeName = jsonObject.optString("nominee1Name");
                    }

                    if (!nomineeName.equalsIgnoreCase("null") && !nomineeName.isEmpty())
                        tvNominee.setText(Utils.setFirstLetterCapital(nomineeName));
                    else tvNominee.setText(mContext.getString(R.string.not_available));


                    String value1 = jsonObject.optString("taxStatusDescription");
                    String value2 = jsonObject.optString("holdingNatureDescription");
                    if (!value1.equalsIgnoreCase("null") && !value1.equalsIgnoreCase(""))
                        if (!value2.equalsIgnoreCase("null") && !value2.equalsIgnoreCase(""))
                            tvTaxStatus.setText(value1 + "\n (" + value2 + ")");
                        else
                            tvTaxStatus.setText(value1);
                    else {
                        tvLevelTaxStatus.setVisibility(View.GONE);
                    }

                } else if (exchange.equals("2") || exchange.equals("4")) {
                    String investorName ="";
                    if (jsonObject.has("investorName")){
                        investorName= jsonObject.optString("investorName");
                    }else {
                        investorName = jsonObject.optString("name");
                    }
                    tvText1.setText(Utils.setFirstLetterCapital(investorName));

                    String value1 = Utils.setFirstLetterCapital(jsonObject.optString("taxStatus"));
                    String value2 =  "(" + jsonObject.optString("holding", "") + ")";
                    if (!value2.equalsIgnoreCase("null") && !value2.equalsIgnoreCase(""))
                        tvTaxStatus.setText(value1 + "\n" + value2);
                    else
                        tvTaxStatus.setText(value1);

                    String joint1 = checkSecondHolderName(jsonObject);//jsonObject.optString("JH1Name", "");
                    String joint2 = checkThirdHolderName(jsonObject);//jsonObject.optString("JH2Name", "");

                    if (!Utils.isEmptyOrNull(joint1)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    } else if (!Utils.isEmptyOrNull(joint2)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint2));
                    } else if (!Utils.isEmptyOrNull(joint1) && !Utils.isEmptyOrNull(joint2)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint1) + "," + Utils.setFirstLetterCapital(joint2));
                    } else {
                        tvText3.setText(mContext.getString(R.string.not_available));
                    }

                    String nomineeName = "";
                    if (jsonObject.has("nomineeName")) {
                        nomineeName = jsonObject.optString("nomineeName");
                    } else if (jsonObject.has("nominee1Name")) {
                        nomineeName = jsonObject.optString("nominee1Name");
                    }

                    if (!nomineeName.equalsIgnoreCase("null") && !nomineeName.isEmpty())
                        tvNominee.setText(Utils.setFirstLetterCapital(nomineeName));
                    else tvNominee.setText(mContext.getString(R.string.not_available));

                    String uccNumberOrCode ="";
                    String firstHolderPanOrPan ="";
                    if (exchange.equalsIgnoreCase("2")){
                        uccNumberOrCode = jsonObject.optString("uccNumber");
                        firstHolderPanOrPan= jsonObject.optString("firstHolderPAN");
                    }else {
                        uccNumberOrCode = jsonObject.optString("nseUccCode");
                        firstHolderPanOrPan= jsonObject.optString("pan");
                    }
                    tvText2.setText(firstHolderPanOrPan);
                    tvText4.setText(uccNumberOrCode);
                    tvLevel4.setText(mContext.getString(R.string.ucc));

                    tvLevel5.setText(mContext.getString(R.string.txt_ucc_type));
                    String isDemateType = "";
                    lliinType.setVisibility(View.VISIBLE);
                    isDemateType = jsonObject.optString("isDematAccount").equalsIgnoreCase("null") ? "" : jsonObject.optString("isDematAccount");
                    if (isDemateType.equalsIgnoreCase("y")) {
                        tvText5.setText(mContext.getString(R.string.text_demate));
                    } else {
                        tvText5.setText(mContext.getString(R.string.text_physical));
                    }


                } else if (exchange.equals("3")) {
/*"investorName":"CHINMAY DARGAR",
"firstHolderPAN":"MNBVC1234X",
"canNumber":"14157AKA03",
"JH1Name":null,
"JH2Name":null,
"mfuid":"2edf844a56fc63dc2420a7d75350e98e",
"holdingCode":"SI",
"taxStatusCode":"RI",
"nominees":[
],
"source":"mint",
"holding":"Single",
"taxStatus":"Individual",
"nomineeName":""*/

                    tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                    tvText2.setText(jsonObject.optString("firstHolderPAN"));

                    String value1 = jsonObject.optString("taxStatus");
                    String value2 = jsonObject.optString("holdingNature");
                    if (!value1.equalsIgnoreCase("null") && !value1.equalsIgnoreCase("")) {
                        if (!value2.equalsIgnoreCase("null") && !value2.equalsIgnoreCase(""))
                            tvTaxStatus.setText(value1 + "\n (" + value2 + ")");
                        else
                            tvTaxStatus.setText(value1);
                    }

                    else {
                        tvLevelTaxStatus.setVisibility(View.GONE);
                    }

                    String joint1 = jsonObject.optString("JH1Name", "");
                    String joint2 = jsonObject.optString("JH2Name", "");

                    if (!Utils.isEmptyOrNull(joint1)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint1));
                    } else if (!Utils.isEmptyOrNull(joint2)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint2));
                    } else if (!Utils.isEmptyOrNull(joint1) && !Utils.isEmptyOrNull(joint2)) {
                        tvText3.setText(Utils.setFirstLetterCapital(joint1) + "," + Utils.setFirstLetterCapital(joint2));
                    } else {
                        tvText3.setText(mContext.getString(R.string.not_available));
                    }

                    String nomineeName = "";
                    if (jsonObject.has("nomineeName")) {
                        nomineeName = jsonObject.optString("nomineeName");
                    } else if (jsonObject.has("nominee1Name")) {
                        nomineeName = jsonObject.optString("nominee1Name");
                    }

                    if (!nomineeName.equalsIgnoreCase("null") && !nomineeName.isEmpty())
                        tvNominee.setText(Utils.setFirstLetterCapital(nomineeName));
                    else tvNominee.setText(mContext.getString(R.string.not_available));

                    tvText4.setText(jsonObject.optString("canNumber"));
                    tvLevel4.setText(mContext.getString(R.string.can));

                    lliinType.setVisibility(View.VISIBLE);
                }

                String arnNo = jsonObject.optString("arnNo");
                if (!arnNo.equalsIgnoreCase("null") && !arnNo.isEmpty())
                    tvArn.setText(arnNo);
                else tvArn.setText(mContext.getString(R.string.not_available));

                if (mHashSelection.get(position) == true) {
                    cbSelected.setChecked(true);
                    listener.onItemClick(position);
                } else {
                    cbSelected.setChecked(false);
                }


                cbSelected.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mHashSelection.get(position) == true) {
                            for (int i = 0; i < mHashSelection.size(); i++) {
                                mHashSelection.put(i, false);
                            }
                            notifyDataSetChanged();

                        } else {
                            for (int i = 0; i < mHashSelection.size(); i++) {
                                mHashSelection.put(i, false);
                            }
                            mHashSelection.put(position, true);
                            notifyDataSetChanged();

                        }
                        //listener.onItemClick(position);

                    }
                });

            } catch (Exception e) {

            }


        }

    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        for (int i = 0; i < list.size(); i++) {
            mHashSelection.put(i, false);
        }
        notifyDataSetChanged();
    }


}
