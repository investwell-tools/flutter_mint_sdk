package investwell.client.fragments.home;


import static investwell.charts.mikephil.charting.animation.Easing.EaseInOutQuad;
import static investwell.di.core.LogExtKt.logD;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import investwell.charts.mikephil.charting.charts.PieChart;
import investwell.charts.mikephil.charting.data.PieData;
import investwell.charts.mikephil.charting.data.PieDataSet;
import investwell.charts.mikephil.charting.data.PieEntry;
import investwell.charts.mikephil.charting.formatter.PercentFormatter;
import investwell.charts.mikephil.charting.utils.MPPointF;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class FragGraphHome1 extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private AssetAllocationAdapter mAdapter;
    private RecyclerView recyclerView;
    private TextView mTvNothing, tvCurrentValueLavel;
    private String mGraphType = "";
    private PieChart mAssetChart;
    private CardView mCardView;
    private TextView tvTitleName, mSharePer;



    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser && isResumed()) {
            getGraphChatData();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Check visibility when fragment resumes
        if (getUserVisibleHint()) {
            getGraphChatData();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mMainActivity = (ClientActivity) context;
        mSession = AppSession.getInstance(mMainActivity);
        mApplication = (AppApplication) mMainActivity.getApplication();
        mSession = AppSession.getInstance(mMainActivity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_graph_chat, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle bundle = getArguments();
        if (bundle != null)
            mGraphType = bundle.getString("type");

        logD("graphAPI");
        tvTitleName = view.findViewById(R.id.tvTitleName);
        mSharePer = view.findViewById(R.id.share);
        recyclerView = view.findViewById(R.id.recycleView);
        mTvNothing = view.findViewById(R.id.tvNothing);
        mAssetChart = view.findViewById(R.id.animatedPieView);
        mCardView = view.findViewById(R.id.cardview);
        tvCurrentValueLavel = view.findViewById(R.id.tvCurrentValueLavel);

        RecyclerView mAssetRecycle = view.findViewById(R.id.asset_recycle);
        mAssetRecycle.setHasFixedSize(true);
        mAssetRecycle.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mAdapter = new AssetAllocationAdapter(getActivity(), new ArrayList<JSONObject>());
        mAssetRecycle.setAdapter(mAdapter);

        if (mGraphType.equals("tab1")) {
            tvCurrentValueLavel.setVisibility(View.VISIBLE);
            tvTitleName.setText(getString(R.string.txt_asserts));
        } else if (mGraphType.equals("tab2")) {
            tvCurrentValueLavel.setVisibility(View.VISIBLE);
            tvTitleName.setText(getString(R.string.Category));
        } else if (mGraphType.equals("tab3")) {
            tvCurrentValueLavel.setVisibility(View.VISIBLE);
            tvTitleName.setText(getString(R.string.Investor));
        } else if (mGraphType.equals("tab4")) {
            tvCurrentValueLavel.setVisibility(View.VISIBLE);
            tvTitleName.setText(getString(R.string.txt_funds));
        }
        setchartfeature();


        try{
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
                if (!mSession.getUserBrokerDomain().isEmpty() && appConfigObject.optString("layout").equals("5")){
                    mAssetRecycle.addOnItemTouchListener(mScrollTouchListener);
                }
            }
        }catch (Exception ignored){

        }
    }

    RecyclerView.OnItemTouchListener mScrollTouchListener = new RecyclerView.OnItemTouchListener() {
        @Override
        public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, MotionEvent e) {
            int action = e.getAction();
            if (action == MotionEvent.ACTION_MOVE) {
                rv.getParent().requestDisallowInterceptTouchEvent(true);
            }
            return false;
        }

        @Override
        public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    };


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

    public void getGraphChatData() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {

            JSONArray filterArray = new JSONArray();
            JSONObject filterObject = new JSONObject();
            filterObject.put("selectedUser", Utils.getSelectedUserObject(mSession));

            JSONArray viewTypeArray = new JSONArray();
            JSONObject viewTypeObject = new JSONObject();

            if (mGraphType.equals("tab1")) {
                viewTypeObject.put("asset", true);
            } else if (mGraphType.equals("tab2")) {
                viewTypeObject.put("category", true);
            } else if (mGraphType.equals("tab3")) {
                viewTypeObject.put("investor", true);
            } else if (mGraphType.equals("tab4")) {
                viewTypeObject.put("fund", true);
            }
            viewTypeArray.put(viewTypeObject);
            filterObject.put("viewType", viewTypeArray);
            filterArray.put(filterObject);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_GRAPH_CHAT_DATA + "filters=" + filterArray + "&pageSize=100" + "&currentPage=1" + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

        } catch (Exception e) {

        }
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            setGraph(response);


        }, volleyError -> {

            if (!isAdded()) return;

            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    mApplication.showCommonDailog(requireActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(requireActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void setchartfeature() {
        mAssetChart.setUsePercentValues(true);
        mAssetChart.getDescription().setEnabled(false);
        mAssetChart.setExtraOffsets(5, 10, 5, 5);
        mAssetChart.setDragDecelerationFrictionCoef(0.95f);
        mAssetChart.setDrawHoleEnabled(true);
        mAssetChart.setHoleColor(Color.WHITE);
        mAssetChart.setTransparentCircleColor(Color.WHITE);
        mAssetChart.setTransparentCircleAlpha(110);
       /* mAssetChart.setHoleRadius(65f);
        mAssetChart.setTransparentCircleRadius(60f);*/
        // mAssetChart.setDrawCenterText(true);
        mAssetChart.setRotationEnabled(true);
        mAssetChart.setHighlightPerTapEnabled(true);
        mAssetChart.getLegend().setEnabled(false);
        mAssetChart.setEntryLabelColor(Color.TRANSPARENT);
        mAssetChart.setEntryLabelTextSize(10f);
        mAssetChart.setDrawHoleEnabled(false);
        mAssetChart.setRotationAngle(0);
    }


    private void setGraph(String response) {
        if (!isAdded()) return;
        try {
            List<JSONObject> jsonArrayList = new ArrayList<>();
            List<JSONObject> filterjsonArrayList = new ArrayList<>();
            ArrayList<PieEntry> entries = new ArrayList<PieEntry>();
            ArrayList<Integer> colorList = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = new JSONArray();
                if (mGraphType.equals("tab1")) {
                    if (jsonObjectMain.has("asset")) {
                        jsonArray = jsonObjectMain.optJSONArray("asset");
                    } else {
                        jsonArray = jsonObjectMain.optJSONArray("summary");
                    }

                } else if (mGraphType.equals("tab2")) {
                    JSONObject categoryObject = jsonObjectMain.optJSONObject("category");
                    jsonArray = categoryObject.optJSONArray("data");

                } else if (mGraphType.equals("tab3")) {
                    JSONObject categoryObject = jsonObjectMain.optJSONObject("investor");
                    jsonArray = categoryObject.optJSONArray("allocation");

                } else if (mGraphType.equals("tab4")) {
                    JSONObject categoryObject = jsonObjectMain.optJSONObject("fund");
                    jsonArray = categoryObject.optJSONArray("allocation");

                }

                if (jsonArray != null && jsonArray.length() > 0) {

                    String[] pieChartTab1 = getActivity().getResources().getStringArray(R.array.piechartcolors);


                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        if (mGraphType.equals("tab1")) {
                            jsonObject1.put("share", jsonObject1.optString("percentage"));
                        }
                        Double aDouble = Double.parseDouble(jsonObject1.optString("share"));
                        DecimalFormat twoDForm = new DecimalFormat("#.00");
                        double newGraphData = 0;
                        try {
                            newGraphData = Double.parseDouble(twoDForm.format(aDouble));
                        } catch (NumberFormatException ex) { // handle your exception
                            System.out.println("number format exception");
                        }
                        jsonObject1.put("share", "" + newGraphData);
                        jsonArrayList.add(jsonObject1);
                    }

                    Collections.sort(jsonArrayList, new SortData("share"));
                    Collections.reverse(jsonArrayList);

                    for (int i = 0; i < jsonArrayList.size(); i++) {
                        JSONObject jsonObject1 = jsonArrayList.get(i);

                        int code = 0;
                        if (i >= 15) {
                            mAssetChart.setVisibility(View.GONE);
                            mCardView.setVisibility(View.VISIBLE);
                            code = Color.parseColor("#00000000");

                            if (mGraphType.equals("tab1")) {
                            } else if (mGraphType.equals("tab2")) {
                                jsonObject1.put("category", jsonObject1.optString("subCategory"));
                            } else if (mGraphType.equals("tab3")) {
                                jsonObject1.put("category", jsonObject1.optString("investorName"));
                            } else if (mGraphType.equals("tab4")) {
                                jsonObject1.put("category", jsonObject1.optString("fundName"));
                            }
                        } else {
                            mAssetChart.setVisibility(View.VISIBLE);
                            mCardView.setVisibility(View.VISIBLE);
                            if (mGraphType.equals("tab1")) {
                                if (jsonObject1.optString("category").equalsIgnoreCase("equity")) {
                                    code = Color.parseColor("#5DA9E9");
                                } else if (jsonObject1.optString("category").equalsIgnoreCase("debt")) {
                                    code = Color.parseColor("#3BB273");
                                } else if (jsonObject1.optString("category").equalsIgnoreCase("gold")) {
                                    code = Color.parseColor("#FFD639");
                                } else if (jsonObject1.optString("category").equalsIgnoreCase("global equity")) {
                                    code = Color.parseColor("#2B50AA");
                                } else if (jsonObject1.optString("category").equalsIgnoreCase("other")) {
                                    code = Color.parseColor("#FED4E7");
                                } else if (jsonObject1.optString("category").equalsIgnoreCase("arbitrage")) {
                                    code = Color.parseColor("#673ab7");
                                } else if (jsonObject1.optString("category").contains("liquid and")) {
                                    code = Color.parseColor("#6689a2");
                                }else if (jsonObject1.optString("category").equalsIgnoreCase("real estate")) {
                                    code = Color.parseColor("#ff9800");
                                }else{
                                    code = Color.parseColor("#006a4e");
                                }

                            } else if (mGraphType.equals("tab2")) {
                                code = Color.parseColor(pieChartTab1[i]);
                                jsonObject1.put("category", jsonObject1.optString("subCategory"));
                            } else if (mGraphType.equals("tab3")) {
                                code = Color.parseColor(pieChartTab1[i]);
                                jsonObject1.put("category", jsonObject1.optString("investorName"));
                            } else if (mGraphType.equals("tab4")) {
                                code = Color.parseColor(pieChartTab1[i]);
                                jsonObject1.put("category", jsonObject1.optString("fundName"));
                            }

                            Double aDouble = Double.parseDouble(jsonObject1.optString("share"));
                            DecimalFormat twoDForm = new DecimalFormat("#.00");
                            double newGraphData = 0;
                            try {
                                newGraphData = Double.parseDouble(twoDForm.format(aDouble));

                            } catch (NumberFormatException ex) { // handle your exception
                                System.out.println("number format exception");
                            }
                            entries.add(new PieEntry((float) newGraphData, jsonObject1.optString("category")));
                        }
                        jsonObject1.put("colorCode", code);
                        colorList.add(code);
                        filterjsonArrayList.add(jsonObject1);
                    }


                  /* // total summarry added
                    if (mGraphType.equals("tab1")) {
                        JSONObject totalObject = new JSONObject();
                        totalObject.put("category", "Total");
                        totalObject.put("share", "100");
                        int code = Color.parseColor("#00000000");
                        totalObject.put("colorCode", code);
                        filterjsonArrayList.add(0, totalObject);
                    } else if (mGraphType.equals("tab2")) {
                        JSONObject categoryObject = jsonObjectMain.optJSONObject("subCategory");
                        JSONObject totalObject = categoryObject.optJSONObject("summary");
                        totalObject.put("category", "Total");
                        totalObject.put("currentAmount", totalObject.optString("currentAmount"));
                        totalObject.put("share", totalObject.optString("share"));
                        int code = Color.parseColor("#00000000");
                        totalObject.put("colorCode", code);
                        filterjsonArrayList.add(0, totalObject);
                    } else if (mGraphType.equals("tab3")) {
                        JSONObject categoryObject = jsonObjectMain.optJSONObject("investor");
                        JSONObject totalObject = categoryObject.optJSONObject("summary");
                        totalObject.put("category", "Total");
                        totalObject.put("currentAmount", totalObject.optString("currentAmount"));
                        totalObject.put("share", totalObject.optString("share"));
                        int code = Color.parseColor("#00000000");
                        totalObject.put("colorCode", code);
                        filterjsonArrayList.add(0, totalObject);
                    } else if (mGraphType.equals("tab4")) {
                        JSONObject categoryObject = jsonObjectMain.optJSONObject("fund");
                        JSONObject totalObject = categoryObject.optJSONObject("summary");
                        totalObject.put("category", "Total");
                        totalObject.put("currentAmount", totalObject.optString("currentAmount"));
                        totalObject.put("share", totalObject.optString("share"));
                        int code = Color.parseColor("#00000000");
                        totalObject.put("colorCode", code);
                        filterjsonArrayList.add(0, totalObject);
                    }*/


                    mAdapter.updateList(filterjsonArrayList);

                    PieDataSet dataSet = new PieDataSet(entries, "");
                    dataSet.setDrawIcons(false);
                    dataSet.setSliceSpace(0.1f);
                    dataSet.setSelectionShift(7f);
                    dataSet.setIconsOffset(new MPPointF(0, 40));
                    dataSet.setYValuePosition(PieDataSet.ValuePosition.INSIDE_SLICE);
                    dataSet.setColors(colorList);

                    dataSet.setValueLinePart1OffsetPercentage(80.f);
                    dataSet.setValueLinePart1Length(0.2f);
                    dataSet.setValueLinePart2Length(0.4f);
                    PieData data = new PieData(dataSet);
                    data.setValueFormatter(new PercentFormatter());
                    data.setValueTextSize(8f);
                    data.setValueTextColor(Color.TRANSPARENT);

                    //  data.setValueTypeface(mTfLight);
                    mAssetChart.setData(data);
                    mAssetChart.setRotationEnabled(false);
                    mAssetChart.animateY(1400, EaseInOutQuad);
                    // undo all highlights
                    mAssetChart.highlightValues(null);
                    mAssetChart.invalidate();

                } else {
                    mTvNothing.setVisibility(View.VISIBLE);
                    mCardView.setVisibility(View.GONE);
                    mAssetChart.setVisibility(View.GONE);
                }
            } else {
                mTvNothing.setVisibility(View.VISIBLE);
                mCardView.setVisibility(View.GONE);
                mAssetChart.setVisibility(View.GONE);
            }

        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
            mTvNothing.setVisibility(View.VISIBLE);
        }
    }


    public class AssetAllocationAdapter extends RecyclerView.Adapter<AssetAllocationAdapter.MyViewHolder> {
        public ArrayList<JSONObject> mDataList;
        Context context;

        public AssetAllocationAdapter(Context context, ArrayList<JSONObject> jsonObject) {
            this.context = context;
            this.mDataList = jsonObject;
        }

        @Override
        public AssetAllocationAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.categoryallocationitems, parent, false);
            AssetAllocationAdapter.MyViewHolder vh = new AssetAllocationAdapter.MyViewHolder(v);

            return vh;
        }

        @Override
        public void onBindViewHolder(final AssetAllocationAdapter.MyViewHolder holder, final int position) {
            DecimalFormat twoDForm = new DecimalFormat("#.00");
            final JSONObject jsonObject1 = mDataList.get(position);

           /* if (position == 0) {
                holder.mValue.setTypeface(null, Typeface.BOLD);
                holder.mCategory.setTypeface(null, Typeface.BOLD);
                holder.mPercentage.setTypeface(null, Typeface.BOLD);
            } else {
                holder.mValue.setTypeface(null, Typeface.NORMAL);
                holder.mCategory.setTypeface(null, Typeface.NORMAL);
                holder.mPercentage.setTypeface(null, Typeface.NORMAL);
            }*/

            if (mDataList.size() > 15) {
                holder.tvColor.setVisibility(View.GONE);
            } else {
                holder.tvColor.setVisibility(View.VISIBLE);
            }

            try{

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                double purchaseValue = 0.0;
                if (mGraphType.equals("tab1")) {
                    purchaseValue = jsonObject1.optDouble("amount");
                } else {
                     purchaseValue = jsonObject1.optDouble("currentAmount");
                }

                String strPurchaseValue = format.format(purchaseValue);
                holder.mValue.setText(strPurchaseValue);
                holder.mValue.setContentDescription(tvCurrentValueLavel.getText() + ". " +  strPurchaseValue);

                holder.mCategory.setText(Utils.setFirstLetterCapital(jsonObject1.optString("category")));
                holder.mCategory.setContentDescription(tvTitleName.getText() + ". " + Utils.setFirstLetterCapital(jsonObject1.optString("category")));
                holder.mCategory.setSelected(true);

                Double aDouble = Double.parseDouble(jsonObject1.optString("share"));
                double percentage = Double.parseDouble(twoDForm.format(aDouble));
                holder.mPercentage.setText("" + percentage + "%");
                holder.mPercentage.setContentDescription(mSharePer.getText() + ". " + percentage + "%");

                holder.tvColor.setBackgroundColor(jsonObject1.optInt("colorCode"));
            } catch(NumberFormatException ex){
                System.out.println();
            }


        }

        @Override
        public int getItemCount() {
            return mDataList.size();
        }

        public void updateList(List<JSONObject> list) {
            mDataList.clear();
            mDataList.addAll(list);
            notifyDataSetChanged();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            TextView mCategory, mValue, mPercentage, tvColor,mSharePer;

            public MyViewHolder(View view) {
                super(view);
                mCategory = view.findViewById(R.id.category);
                mValue = view.findViewById(R.id.tv_market_value);
                mPercentage = view.findViewById(R.id.percent);
                tvColor = view.findViewById(R.id.tvColor);
            }
        }
    }


    public class SortData implements Comparator {
        String keyname = "";

        public SortData(String df) {
            keyname = df;
        }

        @Override
        public int compare(Object o1, Object o2) {
            String a = "0";
            String b = "0";
            a = ((JSONObject) o1).optString(keyname);
            b = ((JSONObject) o2).optString(keyname);

            int ia = 0, ib = 0;
            int nza = 0, nzb = 0;
            char ca, cb;
            int result;

            while (true) {
                // only count the number of zeroes leading the last number compared
                nza = nzb = 0;

                ca = charAt(a, ia);
                cb = charAt(b, ib);

                // skip over leading spaces or zeros
                while (Character.isSpaceChar(ca) || ca == '0') {
                    if (ca == '0') {
                        nza++;
                    } else {
                        // only count consecutive zeroes
                        nza = 0;
                    }

                    ca = charAt(a, ++ia);
                }

                while (Character.isSpaceChar(cb) || cb == '0') {
                    if (cb == '0') {
                        nzb++;
                    } else {
                        // only count consecutive zeroes
                        nzb = 0;
                    }

                    cb = charAt(b, ++ib);
                }

                // process run of digits
                if (Character.isDigit(ca) && Character.isDigit(cb)) {
                    if ((result = compareRight(a.substring(ia), b.substring(ib))) != 0) {
                        return result;
                    }
                }

                if (ca == 0 && cb == 0) {
                    // The strings compare the same. Perhaps the caller
                    // will want to call strcmp to break the tie.
                    return nza - nzb;
                }

                if (ca < cb) {
                    return -1;
                } else if (ca > cb) {
                    return +1;
                }

                ++ia;
                ++ib;
            }
        }

        private char charAt(String s, int i) {
            if (i >= s.length()) {
                return 0;
            } else {
                return s.charAt(i);
            }
        }

        int compareRight(String a, String b) {
            int bias = 0;
            int ia = 0;
            int ib = 0;

            // The longest run of digits wins. That aside, the greatest
            // value wins, but we can't know that it will until we've scanned
            // both numbers to know that they have the same magnitude, so we
            // remember it in BIAS.
            for (; ; ia++, ib++) {
                char ca = charAt(a, ia);
                char cb = charAt(b, ib);

                if (!Character.isDigit(ca) && !Character.isDigit(cb)) {
                    return bias;
                } else if (!Character.isDigit(ca)) {
                    return -1;
                } else if (!Character.isDigit(cb)) {
                    return +1;
                } else if (ca < cb) {
                    if (bias == 0) {
                        bias = -1;
                    }
                } else if (ca > cb) {
                    if (bias == 0)
                        bias = +1;
                } else if (ca == 0 && cb == 0) {
                    return bias;
                }
            }
        }
    }


}
