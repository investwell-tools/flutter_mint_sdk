package investwell.common.alltransactions;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.iw.mint.sdk.R;
import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class SearchFundsAdapter extends RecyclerView.Adapter<SearchFundsAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnTopSchemeClickListener listener;
    private String mType = "";

    public SearchFundsAdapter(Context context, ArrayList<JSONObject> list, OnTopSchemeClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.search_fund_adapter, viewGroup, false);
        return new SearchFundsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SearchFundsAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnTopSchemeClickListener {
        void onItemClick(int position, JSONObject mJsonData);

        void onTopSchemeNameClick(JSONObject mJObject);

        void onByClick(JSONObject mJObject);

        void onAddFavClick(JSONObject mJObject);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvFundName;


        public ViewHolder(View view) {
            super(view);
            tvFundName = view.findViewById(R.id.tvFundName);
        }

        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final SearchFundsAdapter.OnTopSchemeClickListener listener) {
            JSONObject jsonObject = mDataList.get(position);
            if (mType.equalsIgnoreCase("fund")) {
                tvFundName.setText(jsonObject.optString("fundName"));
            } else if (mType.equalsIgnoreCase("transferHolding")) {
                String mName ="";
                if (!jsonObject.optString("schemeGroupName").equalsIgnoreCase("")){
                    mName = jsonObject.optString("schemeGroupName");
                }else {
                    mName =jsonObject.optString("name");
                }
                tvFundName.setText(mName);
            } else{
                String schemeName  = "";
                if (jsonObject.has("schemeGroupName")) {
                     schemeName = jsonObject.optString("schemeGroupName");
                } else {
                   schemeName = jsonObject.optString("schemeName");
                }
                tvFundName.setText(schemeName);
            }

            itemView.setOnClickListener(v -> {
                listener.onItemClick(position, jsonObject);
            });

        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mType = type;
        notifyDataSetChanged();
    }

}
