package investwell.utils;

public abstract interface KtorCallBack {
    default void onLoading(boolean isLoading){}
    void onSuccess(String response,int statusCode);
    default void onError(String errorMessage,int statusCode){}
}
