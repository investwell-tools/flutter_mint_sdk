package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.Utils;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FragPortfolioShareDetailAdapter extends RecyclerView.Adapter<FragPortfolioShareDetailAdapter.MyViewHolder> {


    private ArrayList<JSONObject> jsonObjects;
    Context context;
    private AppSession mSession;
    private ClientActivity mActivity;


    public FragPortfolioShareDetailAdapter(Context context, ArrayList<JSONObject> jsonObjects) {

        this.context = context;
        this.jsonObjects = jsonObjects;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.portfolio_share_details_adapter, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        mActivity = (ClientActivity) context;

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
/*"pan":"AYNPJ1635M",
"txnType":"SWI",
"purchaseDate":"2018-06-13T18:30:00.000Z",
"nav":34.58,
"currentNav":34.76,
"fundid":"e91b4a124304ddbee8ea1cf06f706570",
"fundName":"Edelweiss Mutual Fund",
"folioid":"a545f95d943d5fa8f7216cbfdc92e220",
"appid":"85a776b8f550d6b8b32c8750f510e323",
"applicantName":"P K Gupta",
"objectiveName":"Equity: Large Cap",
"objectiveid":"bc45cf9607b92a2760b017b30eaafac2",
"schemeName":"Edelweiss - Large Cap Fund (G)",
"schid":"e13fd6431f8bf264a26b817699cb8ec9",
"folioNo":"3001018448",
"purchaseValue":5000,
"currentValue":5026.01792,
"balanceUnits":144.592,
"dividend":0,
"avgHoldingDays":439,
"gain":26.01792000000023,
"CAGR":0.43259915968016927,
"absoluteReturn":0.5203584000000046,
"uccNumber":null,
"lastTxnArnid":"5d940f2868946688cfc3d7eac6980618"*/

        final JSONObject jsonObject = jsonObjects.get(position);
        mSession = AppSession.getInstance(context);

        holder.mTvSchemeName.setText(jsonObject.optString("schemeName"));

        double currentValue = jsonObject.optDouble("purchaseValue");
        String strCurrentAmount = format.format(currentValue);
        holder.tvPurchase.setText(strCurrentAmount);

        double purchaseValue = jsonObject.optDouble("currentValue");
        String strPurchaseValue = format.format(purchaseValue);
        holder.mTvCurrent.setText(strPurchaseValue);

        double dividend = jsonObject.optDouble("dividend");
        String strdividend = format.format(dividend);
        holder.tvDevident.setText(strdividend);

        holder.tvDate.setText(Utils.formatedDate(jsonObject.optString("purchaseDate")));

        try {

            double avgHoldingDays = jsonObject.optDouble("avgHoldingDays");
            long rounded = Math.round(avgHoldingDays);
            int days = (rounded <= Integer.MAX_VALUE) ? (int) rounded : Integer.MAX_VALUE;
            holder.tvDays.setText("" + days);
        }
        catch (Exception e){
            holder.tvDays.setText("");
        }



        double gaine = jsonObject.optDouble("gain");
        String strGain = format.format(gaine);
        holder.mTvGain.setText(strGain);

        double cgrValue = jsonObject.optDouble("CAGR");
        String data2 = String.format("%.2f", cgrValue) + "%";
        holder.mTvCgar.setText(data2);

        double returnValue = jsonObject.optDouble("absoluteReturn");
        String stReturnValue = String.format("%.2f", returnValue) + "%";
        holder.tvAbsReturn.setText(stReturnValue);





        holder.top_linear_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("applicant_name", jsonObject.optString("applicantName"));
                bundle.putString("appid", jsonObject.optString("appid"));
                bundle.putString("folioid", jsonObject.optString("folioid"));
               // mActivity.displayViewOther(5, bundle);


            }
        });


    }

    @Override
    public int getItemCount() {

        return jsonObjects.size();
    }

    public void updateList(List<JSONObject> list) {

        jsonObjects.clear();
        jsonObjects.addAll(list);
        notifyDataSetChanged();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView mTvSchemeName, tvPurchase,  mTvCurrent, mTvCgar, tvDate,tvDays, tvDevident,  mTvGain, tvAbsReturn;
        LinearLayout top_linear_layout;

        public MyViewHolder(View view) {
            super(view);

            mTvSchemeName = view.findViewById(R.id.tvSchemeName);
            tvPurchase = view.findViewById(R.id.tvPurchase);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvCgar = view.findViewById(R.id.tvCagr);
            tvDate = view.findViewById(R.id.tvDate);
            tvDays = view.findViewById(R.id.tvDays);
            tvDevident = view.findViewById(R.id.tvDevident);
            tvDevident = view.findViewById(R.id.tvDevident);
            mTvGain = view.findViewById(R.id.tvGain);
            tvAbsReturn = view.findViewById(R.id.tvAbsReturn);

            top_linear_layout = view.findViewById(R.id.top_linear_layout);

        }
    }

}
