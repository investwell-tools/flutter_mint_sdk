package investwell.client.fragments.home.adapter;

import static androidx.core.content.ContextCompat.startActivity;
import static investwell.utils.UtilityKotlin.getNetworkResponse;
import static investwell.utils.UtilityKotlin.returnHeaderAfterLogin;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.imageview.ShapeableImageView;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.DomainActivity;
import investwell.activity.LoginActivity;
import investwell.activity.ShareDeepLinkActivity;
import investwell.activity.WebActivity;
import investwell.activity.WebViewActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.broker.fragment.FragHomeBrokerV5;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.home.FragHomeClient5;
import investwell.common.calculator.CalculatorsActivity;
import investwell.common.newCalculator.ui.NewCalculatorActivity;
import investwell.common.newCalculator.domain.model.CalculatorType;
import investwell.common.nfo.NfoActivity;
import investwell.common.onboarding.marketupdate.MarketUpdateActivity;
import investwell.common.topscheme.TopSchemeActivity;
import investwell.textview.AppTextView;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;

public class MultiViewTypeAdapterFlavourOne extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context mContext;
    public ArrayList<JSONObject> sectionArrayList;
    private AppSession mSession;
    private Intent intent;
    private String viewType = "", imgType = "";
    private static int TYPE_CARD = 1;
    private static int TYPE_GRID = 2;
    private static int TYPE_SLIDER = 3;
    private ClientActivity mClientActivity = null;
    private BrokerActivity mBrokerActivity = null;
    private int mScreenWidth = 0;
    private Fragment fragment;

    public MultiViewTypeAdapterFlavourOne(Context context, ArrayList<JSONObject> sectionArrayList, Fragment fragmentInstance) {
        this.sectionArrayList = sectionArrayList;
        mContext = context;
        mSession = AppSession.getInstance(mContext);
        if (mContext instanceof BrokerActivity) {
            mBrokerActivity = (BrokerActivity) mContext;
        } else {
            mClientActivity = (ClientActivity) mContext;
        }

        fragment = fragmentInstance;
    }

    private int getDisplayWidth() {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        if (mClientActivity != null) {
            mClientActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        } else {
            mBrokerActivity.getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        }

        return displayMetrics.widthPixels;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view;
        mScreenWidth = getDisplayWidth();
        if (viewType == TYPE_CARD) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.client_home_with_inside_layout5, viewGroup, false);
            return new CardViewHolder(view);

        } else if (viewType == TYPE_SLIDER) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.client_home_with_inside_slider_layout5, viewGroup, false);
            return new SliderViewHolder(view);

        } else if (viewType == TYPE_GRID) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.client_home_with_inside_grid_layout5, viewGroup, false);
            return new GridViewHolder(view);
        }
        return null;
    }

    @Override
    public int getItemViewType(int position) {
        if (!TextUtils.isEmpty(viewType) && viewType.equalsIgnoreCase("Slider")) {
            return TYPE_SLIDER;

        } else if (!TextUtils.isEmpty(viewType) && viewType.equalsIgnoreCase("Grid")) {
            return TYPE_GRID;

        } else {
            return TYPE_CARD;
        }
    }

    public void updateSectionsTypeList(List<JSONObject> list, String viewsType, String imgTypes) {

        sectionArrayList.clear();
        sectionArrayList.addAll(list);
        viewType = viewsType;
        imgType = imgTypes;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        if (getItemViewType(position) == TYPE_CARD) {
            ((CardViewHolder) viewHolder).setCardViews(sectionArrayList.get(position));
        } else if (getItemViewType(position) == TYPE_SLIDER) {
            JSONObject jsonObject = sectionArrayList.get(position);
            if (!jsonObject.optString("ChildCode").equals("CustomSection") && jsonObject.optString("ChildBrief").isEmpty()) {
                if (sectionArrayList.size() == 3) {
                    int newWidth = (mScreenWidth / 3) - 32;
                    viewHolder.itemView.getLayoutParams().width = newWidth;
                } else {
                    viewHolder.itemView.getLayoutParams().width = (int) (mScreenWidth / 3.7);
                }
            } else {
                viewHolder.itemView.getLayoutParams().width = (int) (mScreenWidth / 2.8);
            }
            ((SliderViewHolder) viewHolder).setSliderViews(sectionArrayList.get(position), position);
        } else if (getItemViewType(position) == TYPE_GRID) {
            ((GridViewHolder) viewHolder).setGridViews(sectionArrayList.get(position));
        }
    }

    @Override
    public int getItemCount() {
        return sectionArrayList.size();
    }

    /*****************************CARD VIEWS*******************/
    class CardViewHolder extends RecyclerView.ViewHolder {
        ImageView ivIcon;
        AppTextViewTitle tvHeader;
        AppTextView tvDescription;
        AppTextView tvFullDescription;
        LinearLayout llInvestmentRoute;

        CardViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivIcon);
            tvHeader = itemView.findViewById(R.id.tvHeader);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvFullDescription = itemView.findViewById(R.id.tvFullDescription);
            llInvestmentRoute = itemView.findViewById(R.id.llInvestmentRoute);
        }

        /*****************Set Card Views Data************************************/
        void setCardViews(final JSONObject jsonObject) {
            String title = jsonObject.optString("ChildTitle");
            if (jsonObject.optString("ChildCode").equalsIgnoreCase("FilteredFundPicks") && title.contains("@")) {
                String[] titleParts = title.split("@");
                tvHeader.setText(titleParts[0]);
            } else {
                tvHeader.setText(!TextUtils.isEmpty(title) ? title : "");
            }
            if (!jsonObject.optString("ChildBrief").isEmpty()) {
                tvDescription.setVisibility(View.VISIBLE);
                tvDescription.setText(jsonObject.optString("ChildBrief"));
            } else {
                tvDescription.setVisibility(View.GONE);
            }

            if (!jsonObject.optString("ChildDescription").isEmpty()) {
                tvFullDescription.setVisibility(View.VISIBLE);
                tvFullDescription.setText(jsonObject.optString("ChildDescription"));
            } else {
                tvFullDescription.setVisibility(View.GONE);
            }

            setIcon(jsonObject, ivIcon);
            llInvestmentRoute.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickAction(jsonObject);
                }
            });
        }


    }

    class SliderViewHolder extends RecyclerView.ViewHolder {
        ShapeableImageView ivIcon;
        ImageView ivBg1, ivBg2, ivIcon2, ivIcon3;
        TextView tvHeader, tvHeader2, tvHeader3;
        TextView tvDescription, tvDescription2;
        CardView llInvestmentRoute;

        RelativeLayout relTitleBottom, relTitleTop, relTitleBottomSmall;

        SliderViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivIcon);
            ivBg1 = itemView.findViewById(R.id.ivBg);
            tvHeader = itemView.findViewById(R.id.tvHeader);
            tvHeader3 = itemView.findViewById(R.id.tvHeader3);
            ivIcon3 = itemView.findViewById(R.id.ivIcon3);
            tvDescription = itemView.findViewById(R.id.tvDescription);

            relTitleBottomSmall = itemView.findViewById(R.id.relTitleBottomSmall);
            relTitleBottom = itemView.findViewById(R.id.relTitleBottom);
            relTitleTop = itemView.findViewById(R.id.relTitleTop);
            ivBg2 = itemView.findViewById(R.id.ivBg2);
            ivIcon2 = itemView.findViewById(R.id.ivIcon2);
            tvHeader2 = itemView.findViewById(R.id.tvHeader2);
            tvDescription2 = itemView.findViewById(R.id.tvDescription2);
            llInvestmentRoute = itemView.findViewById(R.id.llInvestmentRoute);
        }


        void setSliderViews(final JSONObject jsonObject, int position) {
            float scale = mContext.getResources().getDisplayMetrics().density;
            if (jsonObject.optString("ChildCode").equals("CustomSection")) {
                relTitleTop.setVisibility(View.VISIBLE);
                relTitleBottom.setVisibility(View.GONE);
                tvHeader.setText(jsonObject.optString("title"));
                tvDescription.setText(jsonObject.optString("description"));
                String mUrl = jsonObject.optString("link");
                String image = jsonObject.optString("image");

                if (!image.isEmpty()) {
                    Picasso.get().load(image).error(R.mipmap.insurance).into(ivIcon);
                } else {
                    ivIcon.setImageResource(R.mipmap.insurance);
                }
                llInvestmentRoute.setCardBackgroundColor(UtilityKotlin.returnTenColors(mContext, position));
                llInvestmentRoute.setOnClickListener(v -> {
                    if (!jsonObject.optString("link").isEmpty()) {
                        Intent mIntent = new Intent(mContext, WebViewActivity.class);
                        mIntent.putExtra("title", jsonObject.optString("title"));
                        mIntent.putExtra("url", mUrl);
                        mContext.startActivity(mIntent);
                    }else{
                        Toast.makeText(mContext, R.string.url_is_missing,Toast.LENGTH_SHORT).show();
                    }
                });

            } else {
                relTitleTop.setVisibility(View.GONE);
                relTitleBottom.setVisibility(View.VISIBLE);
                relTitleBottomSmall.setVisibility(View.GONE);
                String title = jsonObject.optString("ChildTitle");
                if (jsonObject.optString("ChildCode").equalsIgnoreCase("FilteredFundPicks") && title.contains("@")) {
                    String[] titleParts = title.split("@");
                    tvHeader2.setText(titleParts[0]);
                } else {
                    tvHeader2.setText(!TextUtils.isEmpty(title) ? title : "");
                }
                RelativeLayout.LayoutParams layoutParams1 = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.WRAP_CONTENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT
                );
                if (!jsonObject.optString("ChildBrief").isEmpty()) {
                    tvDescription2.setVisibility(View.VISIBLE);
                    tvDescription2.setText(jsonObject.optString("ChildBrief"));
                    tvDescription2.setGravity(Gravity.START);
                    tvHeader2.setGravity(Gravity.START);
                    //  layoutParams1.addRule(RelativeLayout.ALIGN_START, RelativeLayout.TRUE);
                    //  ivIcon2.setLayoutParams(layoutParams1);

                    int heightInDpLogo = 50;
                    int heightInPixelsLogo = (int) (heightInDpLogo * scale + 0.5f);
                    layoutParams1.width = heightInPixelsLogo;
                    layoutParams1.height = heightInPixelsLogo;
                    layoutParams1.addRule(RelativeLayout.ALIGN_START, RelativeLayout.TRUE);
                    ivIcon2.setLayoutParams(layoutParams1);

                    ViewGroup.LayoutParams layoutParams = llInvestmentRoute.getLayoutParams();

                    int heightInDp = 150; // Desired height in dp
                    int heightInPixels = (int) (heightInDp * scale + 0.5f);
                    layoutParams.height = heightInPixels;
                    llInvestmentRoute.setLayoutParams(layoutParams);
                    setIcon(jsonObject, ivIcon2);

                } else if (!jsonObject.optString("ChildTitle").isEmpty() && jsonObject.optString("ChildBrief").isEmpty()) {
                    relTitleBottom.setVisibility(View.GONE);
                    relTitleTop.setVisibility(View.GONE);
                    relTitleBottomSmall.setVisibility(View.VISIBLE);
                    if (jsonObject.optString("ChildCode").equalsIgnoreCase("FilteredFundPicks") && title.contains("@")) {
                        String[] titleParts = title.split("@");
                        tvHeader3.setText(titleParts[0]);
                    } else {
                        tvHeader3.setText(!TextUtils.isEmpty(title) ? title : "");
                    }

                    setIcon(jsonObject, ivIcon3);

                    ViewGroup.LayoutParams layoutParams = llInvestmentRoute.getLayoutParams();
                    int heightInDp = 100;
                    layoutParams.height = (int) ((heightInDp * scale) + 0.5f);

                 /*  int oneItemWidth =  (mScreenWidth-100)/3;
                    layoutParams.width = oneItemWidth;*/
                    llInvestmentRoute.setLayoutParams(layoutParams);
                } else {
                    tvDescription2.setVisibility(View.GONE);
                    tvHeader2.setGravity(Gravity.CENTER_HORIZONTAL);

                    int heightInDpLogo = 50;
                    int heightInPixelsLogo = (int) (heightInDpLogo * scale + 0.5f);
                    layoutParams1.width = heightInPixelsLogo;
                    layoutParams1.height = heightInPixelsLogo;
                    layoutParams1.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
                    ivIcon2.setLayoutParams(layoutParams1);
                    //ivIcon2.setLayoutParams(layoutParams1);

                    ViewGroup.LayoutParams layoutParams = llInvestmentRoute.getLayoutParams();
                    // tvHeader2.setText("Binesh Kumar Singh");
                    int heightInDp = 115;
                    if (tvHeader2.getText().toString().length() >= 1) {
                        heightInDp = 135;
                    }

                    int heightInPixels = (int) (heightInDp * scale + 0.5f);
                    layoutParams.height = heightInPixels;
                    llInvestmentRoute.setLayoutParams(layoutParams);
                }
                llInvestmentRoute.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        clickAction(jsonObject);
                    }
                });
            }

        }

    }

    /****************GRID VIEWS*********************************/
    class GridViewHolder extends RecyclerView.ViewHolder {
        ImageView ivIcon, iv_home_bg;
        TextView tvHeader;
        LinearLayout llInvestmentRoute;

        GridViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivIcon);
            iv_home_bg = itemView.findViewById(R.id.ivBg);
            tvHeader = itemView.findViewById(R.id.tvHeader);
            llInvestmentRoute = itemView.findViewById(R.id.llInvestmentRoute);
        }

        /*****************Set Card Views Data************************************/
        void setGridViews(final JSONObject jsonObject) {
            String title = jsonObject.optString("ChildTitle");
            if (jsonObject.optString("ChildCode").equalsIgnoreCase("FilteredFundPicks") && title.contains("@")) {
                String[] titleParts = title.split("@");
                tvHeader.setText(titleParts[0]);
            } else {
                tvHeader.setText(!TextUtils.isEmpty(title) ? title : "");
            }

            setIcon(jsonObject, ivIcon);
            llInvestmentRoute.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickAction(jsonObject);
                }
            });


        }
    }

    private void setIcon(JSONObject jsonObject, ImageView ivIcon) {
        if (jsonObject.optString("ChildCode").equals("topSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.pick);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }

        } else if (jsonObject.optString("ChildCode").equals("NFO")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.nfo);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("fundPicks")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.ic_fund_pick);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("FilteredFundPicks")) {
            String title = jsonObject.optString("ChildTitle");
            String iconName = "";
            if (jsonObject.optString("ChildCode").equalsIgnoreCase("FilteredFundPicks") && title.contains("@")) {
                try {
                    String[] titleParts = title.split("@");
                    iconName = titleParts[2];
                    int iconHolding = UtilityKotlin.checkExistResources(iconName, "mipmap", mContext);
                    if (iconHolding != 0) {
                        ivIcon.setImageResource(iconHolding);
                    } else {
                        ivIcon.setImageResource(R.mipmap.default_generic_icon);
                    }
                } catch (NullPointerException ignored) {
                    ivIcon.setImageResource(R.mipmap.default_generic_icon);
                }
            } else {
                if (jsonObject.optString("ChildType").equals("Module")) {
                    ivIcon.setImageResource(R.mipmap.ic_fund_pick);
                } else {
                    Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
                }
            }


        } else if (jsonObject.optString("ChildCode").equals("topSIPSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.top_sip);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("feature1007")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.goal_colorfull);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("MyJourney")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.myjourney);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("feature1044")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_loan_mf);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        }else if (jsonObject.optString("ChildCode").equals("feature111")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_loan_mf);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        }else if (jsonObject.optString("ChildCode").equals("LumpsumCalc")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.sip);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("SIPCalculator")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.step);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("CostofDelay")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.cost);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("EducationCalc")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.edu);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("MarriageCalc")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.mar);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("RetireCalc")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.ret);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("SIPTenure")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.edu_cal);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("EMICalc")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.emi);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("SIPStepUpCalc")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.step_up_cal);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        }
        else if (jsonObject.optString("ChildCode").equals("STPCalculator")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.stp_cal);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        }
        else if (jsonObject.optString("ChildCode").equals("SWPCalculator")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.swp_cal);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        }
        else if (jsonObject.optString("ChildCode").equals("SIPPlanner")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.sip_planner);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("STPPlanner")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.stp_planner);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("SWPPlanner")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.swp_planner);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("MarketUpdate")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.market_update);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("latestNav")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.nav);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("transferHolding")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                int iconHolding = UtilityKotlin.checkExistResources("transfer_holding", "mipmap", mContext);
                if (iconHolding != 0) {
                    ivIcon.setImageResource(iconHolding);
                } else {
                    ivIcon.setImageResource(R.mipmap.transfer_holdings);
                }
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("SearchAMC")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.amc);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").isEmpty() && jsonObject.optString("ChildType").equals("Custom")) {
            if (jsonObject.optString("ImageFile").isEmpty()) {
                ivIcon.setImageResource(R.drawable.ic_quick_goal);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopLargeCapSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_colection_top_companies);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopMultiCapSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_collection_high_return);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopMidCapSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_collection_sip);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopSmallCapSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.smallcap);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopMultiCapSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_quick_goal);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopSectorBetSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_collection_sector_bets);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopGlobalSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_quick_global_fund);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopGoldSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_quick_gold_fund);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopELSSSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_collection_tax_saving);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("TopLiquidSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_collection_fd);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("FinTools")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.drawable.ic_quick_calculators);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("InvestInExistingSchemes")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.existing_schemes);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else if (jsonObject.optString("ChildCode").equals("inviteForSignup")) {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.new_invite_client);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        } else {
            if (jsonObject.optString("ChildType").equals("Module")) {
                ivIcon.setImageResource(R.mipmap.default_generic_icon);
            } else {
                Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
            }
        }
    }

    private void clickAction(JSONObject jsonObject) {
        if (jsonObject.optString("ChildType").equals("Custom")) {
            if (jsonObject.optString("CustomType").equals("URL")) {
                intent = new Intent(mContext, WebActivity.class);
                intent.putExtra("title", jsonObject.optString("ChildTitle"));
                intent.putExtra("url", jsonObject.optString("TargetURL"));
                mContext.startActivity(intent);
            } else {
                // to Do
            }


        } else if (jsonObject.optString("ChildCode").equals("topSchemes")) {
            intent = new Intent(mContext, TopSchemeActivity.class);
            AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
            intent.putExtra("fundPick", "no");
            if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")) {
                intent.putExtra("toolBarTitle", mContext.getString(R.string.scheme_performance));
            }
            mContext.startActivity(intent);

        } else if (jsonObject.optString("ChildCode").equals("NFO")) {
            intent = new Intent(mContext, NfoActivity.class);
            AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("fundPicks")) {
            if (mSession.getHasLoging()) {
                intent = new Intent(mContext, TopSchemeActivity.class);
                intent.putExtra("toolBarTitle", jsonObject.optString("ChildTitle"));
                intent.putExtra("isDynamicFundPick", true);
                mContext.startActivity(intent);
            } else {
                showLoginDialog(mContext);
            }

        } else if (jsonObject.optString("ChildCode").equals("FilteredFundPicks")) {
            if (mSession.getHasLoging()) {
                try {
                    String title = jsonObject.optString("ChildTitle");
                    String filterName = "";
                    String titleName = "";
                    if (jsonObject.optString("ChildCode").equalsIgnoreCase("FilteredFundPicks") && title.contains("@")) {
                        String[] titleParts = title.split("@");
                        titleName = titleParts[0].replace("@", "");
                        filterName = titleParts[1].replace("@", "");
                    }
                    newFundPick(titleName, filterName);
                   /* intent = new Intent(mContext, TopSchemeActivity.class);
                    intent.putExtra("toolBarTitle", mContext.getString(R.string.txt_fund_pick_name));
                    intent.putExtra("fundPickFilter", filterName);
                    mContext.startActivity(intent);*/
                } catch (Exception ignored) {

                }
            } else {
                showLoginDialog(mContext);
            }

        } else if (jsonObject.optString("ChildCode").equals("topSIPSchemes")) {
            intent = new Intent(mContext, TopSchemeActivity.class);
            if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")) {
                intent.putExtra("toolBarTitle", mContext.getString(R.string.sip_scheme_performance));
            } else {
                intent.putExtra("toolBarTitle", mContext.getString(R.string.dashboard_top_sip_title));
            }
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("feature1007")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewOther(49, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("MyJourney")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewOther(82, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("feature1044")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewOther(81, null);
            }
        }else if (jsonObject.optString("ChildCode").equals("feature111")) {
            if (mSession.getHasLoging() && mBrokerActivity!=null){
                mBrokerActivity.callVoltApi();
            }
        } else if (jsonObject.optString("ChildCode").equals("transferHolding")) {
            if (mSession.getHasLoging()) {
                if (mClientActivity != null) {
                    mClientActivity.displayViewOther(89, null);
                }
            } else {
                showLoginDialog(mContext);
            }
        } else if (jsonObject.optString("ChildCode").equals("SearchAMC")) {
            if (mSession.getHasLoging()) {
                if (mClientActivity != null) {
                    mClientActivity.displayViewOther(90, null);
                }
            } else {
                showLoginDialog(mContext);
            }
        } else if (jsonObject.optString("ChildCode").equals("MarketUpdate")) {
            intent = new Intent(mContext, MarketUpdateActivity.class);
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("latestNav")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewOther(99, null);
            }else{
                mBrokerActivity.displayViewOther(85, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("LumpsumCalc")) {
            if (mBrokerActivity != null) {
                startActivity(
                        mContext,
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.LUMPSUM.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            } else {
                startActivity(
                        mContext,
                        new Intent(mClientActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.LUMPSUM.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            }
        } else if (jsonObject.optString("ChildCode").equals("SIPCalculator")) {
            if (mBrokerActivity != null) {
                startActivity(
                        mContext,
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.SIP.GoalAmount.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            } else {
                startActivity(
                        mContext,
                        new Intent(mClientActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.LUMPSUM.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            }
        } else if (jsonObject.optString("ChildCode").equals("CostofDelay")) {
            if (mBrokerActivity != null) {
                startActivity(
                        mContext,
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.CostOfDelay.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            } else {
                startActivity(
                        mContext,
                        new Intent(mClientActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.CostOfDelay.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            }
        } else if (jsonObject.optString("ChildCode").equals("EducationCalc")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewCalculator(7, null);
            }else{
                mBrokerActivity.displayViewCalculator(7, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("MarriageCalc")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewCalculator(8, null);
            }else{
                mBrokerActivity.displayViewCalculator(8, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("RetireCalc")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewCalculator(6, null);
            }else{
                mBrokerActivity.displayViewCalculator(6, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("SIPTenure")) {
            Intent intent2 = new Intent(mContext, WebActivity.class);
            intent2.putExtra("title", mContext.getString(R.string.sip_tenure));
            intent2.putExtra("url", mContext.getString(R.string.sip_tenure_link));
            mContext.startActivity(intent2);
        } else if (jsonObject.optString("ChildCode").equals("EMICalc")) {
            if (mClientActivity != null) {
                mClientActivity.displayViewCalculator(4, null);
            }else{
                mBrokerActivity.displayViewCalculator(4, null);
            }
        } else if (jsonObject.optString("ChildCode").equals("SIPStepUpCalc")) {
            if (mBrokerActivity != null) {
                startActivity(
                        mContext,
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.SipStepUp.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            } else {
                startActivity(
                        mContext,
                        new Intent(mClientActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.SipStepUp.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            }
        } else if (jsonObject.optString("ChildCode").equals("STPCalculator")) {
            if (mBrokerActivity != null) {
                startActivity(
                        mContext,
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.STP.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            } else {
                startActivity(
                        mContext,
                        new Intent(mClientActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.STP.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            }
        }
        else if (jsonObject.optString("ChildCode").equals("SWPCalculator")) {
            if (mBrokerActivity != null) {
                startActivity(
                        mContext,
                        new Intent(mBrokerActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.SWP.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            } else {
                startActivity(
                        mContext,
                        new Intent(mClientActivity, NewCalculatorActivity.class)
                                .putExtra("calculatorType", CalculatorType.SWP.INSTANCE.getKey())
                                .putExtra("title", jsonObject.optString("ChildTitle")),
                        new Bundle()
                );
            }
        }
        else if (jsonObject.optString("ChildCode").equals("SIPPlanner")) {
            intent = new Intent(mContext, WebActivity.class);
            intent.putExtra("title", mContext.getString(R.string.sip_planner));
            intent.putExtra("url", mContext.getString(R.string.sip_planner_url));
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("STPPlanner")) {
            intent = new Intent(mContext, WebActivity.class);
            intent.putExtra("title", mContext.getString(R.string.stp_planner));
            intent.putExtra("url", mContext.getString(R.string.stp_planner_url));
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("SWPPlanner")) {
            intent = new Intent(mContext, WebActivity.class);
            intent.putExtra("title", mContext.getString(R.string.swp_planner));
            intent.putExtra("url", mContext.getString(R.string.swp_planner_url));
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("SWPPlanner")) {
            intent = new Intent(mContext, WebActivity.class);
            intent.putExtra("title",  mContext.getString(R.string.swp_planner));
            intent.putExtra("url", mContext.getString(R.string.swp_planner_url));
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("TopLargeCapSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: Large Cap");
        } else if (jsonObject.optString("ChildCode").equals("TopMultiCapSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: Multi Cap");
        } else if (jsonObject.optString("ChildCode").equals("TopMidCapSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: Mid Cap");
        } else if (jsonObject.optString("ChildCode").equals("TopSmallCapSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: Small Cap");
        } else if (jsonObject.optString("ChildCode").equals("TopSectorBetSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: Sectoral");
        } else if (jsonObject.optString("ChildCode").equals("TopGlobalSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: Global");
        } else if (jsonObject.optString("ChildCode").equals("TopGoldSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Gold: Gold Funds");
        } else if (jsonObject.optString("ChildCode").equals("TopELSSSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Equity: ELSS");
        } else if (jsonObject.optString("ChildCode").equals("TopLiquidSchemes")) {
            callCollectionApiByName(jsonObject.optString("ChildTitle"), "Debt: Liquid");
        } else if (jsonObject.optString("ChildCode").equals("FinTools")) {
            intent = new Intent(mContext, CalculatorsActivity.class);
            mContext.startActivity(intent);
        } else if (jsonObject.optString("ChildCode").equals("inviteForSignup")) {
            if (mSession.getHasLoging()) {
                generateShortUrl();
            } else {
                showLoginDialog(mContext);
            }
        }else if (jsonObject.optString("ChildCode").equals("InvestInExistingSchemes")) {
            if (mSession.getHasLoging()) {
                if (mClientActivity != null) {
                    mClientActivity.displayViewOther(30, null);
                }
            } else {
                showLoginDialog(mContext);
            }
        }

    }

    public void callCollectionApiByName(String titleName, String matchingName) {
        Intent intent;
        JSONArray jsonArray = new JSONArray();
        if (fragment instanceof FragHomeBrokerV5) {
            jsonArray = ((FragHomeBrokerV5) fragment).getMObjectiveIDArray();
        }else if (fragment instanceof FragHomeClient5) {
            jsonArray = ((FragHomeClient5) fragment).getMObjectiveIDArray();
        } else {
            jsonArray = new JSONArray();
        }
        if (jsonArray.length() > 0) {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.optJSONObject(i);
                if (jsonObject.optString("objective").equalsIgnoreCase(matchingName)) {
                    intent = new Intent(mContext, TopSchemeActivity.class);
                    intent.putExtra("toolBarTitle", titleName);
                    intent.putExtra("objId", jsonObject.optString("objectiveid"));
                    intent.putExtra("objective", jsonObject.optString("objective"));
                    intent.putExtra("filter", "no");
                    mContext.startActivity(intent);
                }
            }
        }
    }

    public void newFundPick(String titleName, String matchingName) {
        Intent intent;
        JSONArray jsonArray = new JSONArray();
        if (fragment instanceof FragHomeBrokerV5) {
            jsonArray = ((FragHomeBrokerV5) fragment).getMObjectiveIDArray();
        }else if (fragment instanceof FragHomeClient5) {
            jsonArray = ((FragHomeClient5) fragment).getMObjectiveIDArray();
        }  else {
            jsonArray = new JSONArray();
        }
        if (jsonArray.length() > 0) {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.optJSONObject(i);
                if (jsonObject.optString("objective").equalsIgnoreCase(matchingName)) {
                    intent = new Intent(mContext, TopSchemeActivity.class);
                    intent.putExtra("toolBarTitle", titleName);
                    intent.putExtra("isDynamicFundPick", true);
                    intent.putExtra("objId", jsonObject.optString("objectiveid"));
                    intent.putExtra("objective", jsonObject.optString("objective"));
                    mContext.startActivity(intent);
                }
            }
        }
    }


    public void showLoginDialog(Context context) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_factsheet_pdf, null);
        dialogBuilder.setView(dialogView);

        AlertDialog alertDialog = dialogBuilder.create();

        TextView tvTitle = dialogView.findViewById(R.id.textView28);
        tvTitle.setText(context.getString(R.string.alert));

        TextView tvCancel = dialogView.findViewById(R.id.textView31);
        tvCancel.setText(context.getString(R.string.txt_cancel));

        TextView tvLogin = dialogView.findViewById(R.id.textView36);
        tvLogin.setText(context.getString(R.string.login));

        TextView tvMessage = dialogView.findViewById(R.id.textView30);
        tvMessage.setText(context.getString(R.string.login_dailog_msg));

        ImageView ivLogoutImage = dialogView.findViewById(R.id.imageView15);
        ivLogoutImage.setImageResource(R.mipmap.logout_128);

        tvTitle.setSelected(true);

        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!context.getString(R.string.subdomain).equalsIgnoreCase("mint")) {
                    context.startActivity(new Intent(context, DomainActivity.class));
                } else {
                    context.startActivity(new Intent(context, LoginActivity.class));
                }
                alertDialog.dismiss();
            }
        });

        alertDialog.show();
    }

    private void generateShortUrl() {
        ProgressBarCommon.showDialog(mContext);
        String referUrl = "";
        if (mSession.getCustomURL() != null && !mSession.getCustomURL().isEmpty()) {
            referUrl = "https://" + mSession.getCustomURL() + "/" + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        } else {
            referUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath().replace("/webapi", "") + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        }
//        String referUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath().replace("/api", "") + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        String url = Config.DEEP_LINKING_SHORT_URL + referUrl + "&signature=11d3c107e3" + "&format=json&action=shorturl";

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ProgressBarCommon.dismissDialog();
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        if (jsonObject.optInt("statusCode") == 200) {
                            String shorturl = jsonObject.optString("shorturl");
                            Intent sharingIntent;
                            sharingIntent = new Intent(mContext, ShareDeepLinkActivity.class);
                            sharingIntent.putExtra("url", shorturl);
                            mContext.startActivity(sharingIntent);
                        }
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }
                },
                volleyError -> {
                    ProgressBarCommon.dismissDialog();
                    UtilityKotlin.parseVolleyError(volleyError, mSession, mContext, "");
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return returnHeaderAfterLogin(mSession, mContext);
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                getNetworkResponse(mSession, response, mContext);
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    if (mClientActivity != null){
                        AppApplication appApplication = (AppApplication) mClientActivity.getApplication();
                        appApplication.showCommonDailog(mContext, mContext.getString(R.string.txt_session_expired), mContext.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }else{
                        AppApplication appApplication = (AppApplication) mBrokerActivity.getApplication();
                        appApplication.showCommonDailog(mContext, mContext.getString(R.string.txt_session_expired), mContext.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }

                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(mContext);
        requestQueue.add(stringRequest);
    }


}







