package investwell.client.fragments.portfolioSummary;


import static android.os.Build.VERSION.SDK_INT;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;
import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UtilityKotlin.getOneDayEarlier;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragViewPagerAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.CustomViewPager;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import investwell.utils.WhatsAppShare;
import investwell.utils.customView.CustomDialog;
import kotlin.Pair;


public class FragPtSummaryHome extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback,  CustomDialog.DialogBtnCallBack {
    private AppSession mSession;
    public CustomViewPager mViewPager;
    public FragViewPagerAdapter mPagerAdapter;
    public TabLayout mTabLayout;
    private ClientActivity mActivity;

    //filter items
    private ImageView ivCloseFilter;
    private FloatingActionButton mFabAddTxn;
    private RelativeLayout mRelFilterMain;
    private RadioGroup radioGroupPortfolio;
    private LinearLayout mLinFilterPart, mLinerCustomDuration, mLinerCustomDurationP;
    private Animation slideUpAnimation, slideDownAnimation;
    private boolean isClickedApply = false;
    private int mMonthCount = 0;
    public static String mStartingDate = "", mEndDate = "", mValuationDate;
    public static int mSelectedPosition = 0;
    public static List<JSONObject> mMemberList;


    private TextView mTvStartDate, mTvEndDate, mTvStartDateP, mTvEndDateP, tvValuationDate;
    private boolean mIsFirstTime = true;
    private Spinner mMemberSpinner;
    RequestQueue requestQueue;
    private AppApplication mAppplication;
    private String mSelectedTime = "";
    private AlertDialog alertDialog;
    private AlertDialog.Builder dialogBuilder;
    private String mGroupById = "";
    private String mTabType = "";

    private Boolean canAddTxn = true;

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mActivity.setMainVisibility(this, null);
    }

    private void setUpToolBar(boolean isShowDownloadShareBtn) {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(requireActivity().getResources().getString(R.string.portfolio), false, isShowDownloadShareBtn, false, isShowDownloadShareBtn, false, false, false);
            fragToolBar.setCallback(this);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mStartingDate = "";
        mEndDate = "";
        mSelectedPosition = 0;
        mMemberList = null;
        mActivity.ptMFSelectedFilter = new Pair<>("0",true);
        ProgressBarCommon.dismissDialog();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_pt_summary_home, container, false);

        mViewPager = view.findViewById(R.id.pager);
        mFabAddTxn = view.findViewById(R.id.fabAddTxn);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mLinerCustomDuration = view.findViewById(R.id.linerCustomDuration);
        mTvStartDate = view.findViewById(R.id.tvSTart);
        mTvEndDate = view.findViewById(R.id.tvEnd);
        mMemberSpinner = view.findViewById(R.id.member_spinner);
        slideUpAnimation = AnimationUtils.loadAnimation(mActivity, R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(mActivity, R.anim.slide_down);


        JSONObject appConfigObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }
        }catch (Exception e){

        }
        if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
            view.findViewById(R.id.tabLayout2).setVisibility(View.VISIBLE);
            view.findViewById(R.id.tabLayout).setVisibility(View.GONE);
            mTabLayout = view.findViewById(R.id.tabLayout2);
        }else{
            view.findViewById(R.id.tabLayout2).setVisibility(View.GONE);
            view.findViewById(R.id.tabLayout).setVisibility(View.VISIBLE);
            mTabLayout = view.findViewById(R.id.tabLayout);
        }

        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);
        mFabAddTxn.setOnClickListener(this);
        mTvStartDate.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);

        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            if (levelNo.equals("100")) {
                mGroupById = "1005";
            } else {
                mGroupById = "100";
            }
        } else {
            if (mSession.getLevelNo().equals("100")) {
                mGroupById = "1005";
            } else {
                mGroupById = "100";
            }
        }

        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("tabName")) {
            mTabType = bundle.getString("tabName");
        }

        getPortfolio();

        RadioGroup radioGroup = view.findViewById(R.id.rdGroup);
        radioGroup.check(R.id.rbCurrentMonth);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                mLinerCustomDuration.setVisibility(View.GONE);
                int position = radioGroup.indexOfChild(view.findViewById(i));
                switch (position) {
                    case 0:
                        mMonthCount = 0;
                        dateCalculation(true);
                        break;

                    case 1:
                        mMonthCount = 0;
                        dateCalculation(true);

                        mMonthCount = mMonthCount - 1;
                        dateCalculation(true);
                        break;

                    case 2:
                        String year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
                        mStartingDate = year + "-01-01";
                        mEndDate = year + "-12-31";
                        break;

                    case 3:
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        mMonthCount = 0;
                        dateCalculation(true);
                        break;
                }
            }
        });

        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);

                mFabAddTxn.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        mActivity.userDidAction("");
        getAllMembers();

        // check feature permission feature1011 and feature1011 if exist then show download
        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
        boolean isShowDownloadShareBtn = false;
        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
            JSONObject mJsoObject = null;
            try {
                mJsoObject = new JSONObject(allowedFeatured);
                JSONArray jsonArray = mJsoObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.optJSONObject(i).has("feature1011") || jsonArray.optJSONObject(i).has("feature1012")) {
                        isShowDownloadShareBtn = true;
                    }

                    if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
                        canAddTxn =  UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature57", Permissions.ADD);
                    } else {
                        canAddTxn =  UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature1003", Permissions.ADD);
                    }
                }
                setUpToolBar(isShowDownloadShareBtn);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }


        return view;
    }

    private void updateTab(){
        if (mTabType.equalsIgnoreCase("shareBond")) {
            mViewPager.setCurrentItem(1);
        } else if (mTabType.equalsIgnoreCase("fixedDeposit")) {
            mViewPager.setCurrentItem(2);
        } else if (mTabType.equalsIgnoreCase("Others")) {
            mViewPager.setCurrentItem(3);
        }
    }

    private void dialogFilterPortfolioValuation() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.portfolio_valuation_filter, null);
        dialogBuilder.setView(dialogView);
        AlertDialog alertDialog2 = dialogBuilder.create();
        // filter

        tvValuationDate = dialogView.findViewById(R.id.tvValuationDate);
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -1);
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);

        NumberFormat formatter = new DecimalFormat("00");
        String day = formatter.format((mDay));
        String month = formatter.format((mMonth + 1));
        String date_time = mYear + "-" + month + "-" + day;
        String date_for_text = day + "-" + month + "-" + mYear;
        tvValuationDate.setText(date_for_text);
        mValuationDate = date_time;

        dialogView.findViewById(R.id.apply_btnP).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog2.dismiss();
                downloadFileValuation();
            }
        });

        dialogView.findViewById(R.id.ivClose_performance).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog2.dismiss();
            }
        });

        tvValuationDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker(false, true);
            }
        });
        alertDialog2.setCancelable(true);
        alertDialog2.show();
    }

    private void dialogFilterPortfolio() {
        dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.portfolio_performance_filter, null);
        dialogBuilder.setView(dialogView);
        alertDialog = dialogBuilder.create();
        // filter
        mLinerCustomDurationP = dialogView.findViewById(R.id.linerCustomDurationp);
        ivCloseFilter = dialogView.findViewById(R.id.ivClose_performance);

        mTvStartDateP = dialogView.findViewById(R.id.tvSTartp);
        mTvEndDateP = dialogView.findViewById(R.id.tvEndp);
        radioGroupPortfolio = dialogView.findViewById(R.id.rdGroupP);
        radioGroupPortfolio.check(R.id.radio0);
        mSelectedTime = "SI";
        dialogView.findViewById(R.id.apply_btnP).setOnClickListener(this);
        radioGroupPortfolio.setOnCheckedChangeListener((radioGroup, checkId) -> {
            mLinerCustomDurationP.setVisibility(View.GONE);
            String year2 = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            Date todayDate = Calendar.getInstance().getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));

            /*CF,PF,CU,SI*/
            if (checkId == R.id.radio0) {
                    mSelectedTime = "SI";
}
else if (checkId == R.id.radio1) {
                    mSelectedTime = "CF";
                    mStartingDate = getCurrentFinYear();
                    mEndDate = formatter.format(todayDate);
}
else if (checkId == R.id.radio2) {
                    mSelectedTime = "PF";
                    // mStartingDate = Integer.parseInt(year2) - 1 +"-01-04";
                    mStartingDate = getLast1Year();
                    mEndDate = formatter.format(todayDate);
}
else if (checkId == R.id.radio3) {
                    mSelectedTime = "CU";
                    mLinerCustomDurationP.setVisibility(View.VISIBLE);
                    /*mStartingDate = year2 + "-01-01";

                    mEndDate = formatter.format(todayDate);

                    mTvStartDateP.setText(mStartingDate);
                    mTvEndDateP.setText(mEndDate);*/
}else if (checkId == R.id.radio4){
                mSelectedTime = "LF";
                mStartingDate = getLastFinYearStart();
                mEndDate = getLastFinYearEnd();

            }
        });
        mTvEndDateP.setOnClickListener(this);
        mTvStartDateP.setOnClickListener(this);
        ivCloseFilter.setOnClickListener(this);
        alertDialog.setCancelable(true);
        alertDialog.show();
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvSTartp) {
                datePicker(true, false);
}
else if (v.getId() == R.id.tvEndp) {
                datePicker(false, false);
}
else if (v.getId() == R.id.apply_btnP) {
                if (!mSelectedTime.equals("CU")) {
//                    isClickedApply = true;
                    if (alertDialog.isShowing()) {
                        alertDialog.dismiss();
                    }
                    downloadFileSummary();
                } else {
                    if (!mStartingDate.isEmpty() && !mEndDate.isEmpty()) {
                        if (alertDialog.isShowing()) {
                            alertDialog.dismiss();
                        }
                        downloadFileSummary();
                    } else {
                        Toast.makeText(mAppplication, getString(R.string.please_choose_time_period), Toast.LENGTH_SHORT).show();
                    }
                }
}
else if (v.getId() == R.id.tvSTart) {
                System.out.println();
                datePicker(true, false);
}
else if (v.getId() == R.id.tvEnd) {
                datePicker(false, false);
}
else if (v.getId() == R.id.fabAddTxn) {
//                mFilterIcon.setVisibility(View.GONE);
//                mRelFilterMain.setVisibility(View.VISIBLE);
//                mLinFilterPart.startAnimation(slideUpAnimation);
                    Bundle bundle = new Bundle();
                    bundle.putBoolean("isFromPortfolio", true);
                    int currentTabPos = mViewPager.getCurrentItem();
                    bundle.putInt("tabPos", currentTabPos);
                    mActivity.goToTransactionTab(bundle);
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.ivClose_performance) {
                alertDialog.dismiss();
}
else if (v.getId() == R.id.apply_btn) {
                mLinFilterPart.startAnimation(slideDownAnimation);
                isClickedApply = true;

                int pos = mViewPager.getCurrentItem();
                Fragment activeFragment = mPagerAdapter.getItem(pos);
                if (pos == 0) {
                    ((FragPtSummaryMFNotUsed) activeFragment).getPtSummaryMutualFund();
                }

                //getPtSummaryMutualFund();
}
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                showPopMenuItemDownload(view);
}
else if (view.getId() == R.id.iv_share) {
                showPopMenuItemShare(view);
}
    }

    private String getCurrentFinYear() {
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
        int TodayDay = Calendar.getInstance().get(Calendar.DATE);

        String finYearStardDate = "";
        if (month < 3) {
            finYearStardDate = (year - 1) + "-04-01";
        } else if (month == 3 && TodayDay <= 31) {
            finYearStardDate = (year - 1) + "-04-01";
        } else {
            finYearStardDate = year + "-04-01";
        }
        return finYearStardDate;
    }


    private String getLastFinYearStart() {
        return UtilityKotlin.getLastFinYearStart();
    }


    private String getLastFinYearEnd() {
        return UtilityKotlin.getLastFinYearEnd();
    }


    private String getLast1Year() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -1);
        String date = formatter.format(calendar.getTimeInMillis());
        return date;
    }

    private void updateViewPagerView(boolean isFamilyHead, JSONObject jsonObject) {
        List<Fragment> fragList = new ArrayList<>();
        // LavelNo = 98 family Head
        // lavelNo = 100 Single

        JSONObject appConfigObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }
        }catch (Exception e){

        }


            Fragment fragment1 = null;
        if (isFamilyHead) {
       if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
           fragment1 = new FragPtSummaryMutualFamilyHeadLayout6();

       }else{
           fragment1 = new FragPtSummaryMutualFamilyHead();

       }

        } else {
            Bundle bundle = new Bundle();
            bundle.putBoolean("isHideToolBar", true);
            bundle.putString("data", jsonObject.toString());
            bundle.putBoolean("isActiveFolio", true);
            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                fragment1 = new FragPtSummaryMutualFundSingleLayout6();
            }else{
                fragment1 = new FragPtSummaryMutualFundSingle();
            }
            fragment1.setArguments(bundle);
        }

        Fragment fragment2 = null;
        Bundle bundle = new Bundle();
        if (isFamilyHead) {
            fragment2 = new FragPtSummaryShareBonds();
        } else {
            bundle.putBoolean("isHideToolBar", true);
            fragment2 = new FragPtSummaryShareBonds2();
        }
        fragment2.setArguments(bundle);
        Fragment fragment3 = null;
        if (isFamilyHead){
            fragment3 = new FragPtFamilySummaryFD();
        }else {
            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                fragment3 = new FragPtSummaryFDLayout6();
            }else{
                fragment3 = new FragPtSummaryFD();
            }

        }
        fragment3.setArguments(bundle);
        Fragment fragment4 = new FragPtSummaryAsserts();

        fragList.add(fragment1);
        fragList.add(fragment2);
        fragList.add(fragment3);

        fragList.add(fragment4);
        if (!isAdded()) return;
        mPagerAdapter = new FragViewPagerAdapter(getChildFragmentManager(), fragList);
        mViewPager.setAdapter(mPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);

        mTabLayout.getTabAt(0).setText(R.string.mutual_funds);
        mTabLayout.getTabAt(1).setText(R.string.share_bonds);
        mTabLayout.getTabAt(2).setText(R.string.fixed_deposits);
        mTabLayout.getTabAt(3).setText(R.string.other_assets);

        mViewPager.addOnPageChangeListener(onViewPageChange);
        updateTab();

        ViewGroup tabStrip = (ViewGroup) mTabLayout.getChildAt(0);

        for (int i = 0; i < tabStrip.getChildCount(); i++) {
            View tabView = tabStrip.getChildAt(i);
            ViewGroup.MarginLayoutParams params =
                    (ViewGroup.MarginLayoutParams) tabView.getLayoutParams();
            params.setMargins(10, 15, 10, 10);
            tabView.setLayoutParams(params);
        }
    }


    private void getPortfolio() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        ProgressBarCommon.showDialog(requireActivity());
        String url = "";
        try {
            @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            JSONArray jsonArray = new JSONArray();

            JSONObject selectedObject = new JSONObject();
            selectedObject.put("selectedUser", Utils.getSelectedUserObject(mSession));
            jsonArray.put(selectedObject);

            JSONObject dateObject = new JSONObject();
            Date date = getOneDayEarlier();
            if (date != null) {
                dateObject.put("endDate", formatter.format(date));
            }
            jsonArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSource);


            if (mSession.getHasShowXirr()) {
                JSONObject activeFolioObject = new JSONObject();
                activeFolioObject.put("activeFoliosOnly", mActivity.ptMFSelectedFilter.getSecond());
                jsonArray.put(activeFolioObject);
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.XIRR_PORTFOLIO_RETURN_NEW_API + "&filters=" + jsonArray + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            } else {

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CAGR_PORTFOLIO_RETURN_NEW_API + "filters=" + jsonArray + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            ProgressBarCommon.dismissDialog();
            AppApplication.DASHBOARD_PORTFOLIO = response;
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.optInt("status") == 0) {
                    JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                    if (jsonObjectMain ==null){
                        jsonObjectMain = new JSONObject();
                    }
                    JSONArray jsonArray = jsonObjectMain.optJSONArray("data");

                    if (jsonArray !=null && jsonArray.length()>0){
                        String levelNo = "";
                        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                             levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                        } else {
                             levelNo = mSession.getLevelNo();
                        }

                        if (levelNo.equals("98")) {
                            updateViewPagerView(true, new JSONObject());
                        } else {
                            JSONObject jsonObject1 = jsonArray.optJSONObject(0);
                            updateViewPagerView(false, jsonObject1);
                        }


                    }else {
                        updateViewPagerView(true, new JSONObject());
                    }

                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
               // updateViewPagerView(true, new JSONObject());
            }
        }, volleyError -> {
            if (!isAdded())
                return;
            ProgressBarCommon.dismissDialog();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
            return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void showPopMenuItemDownload(View view) {
        Context popupContext = new ContextThemeWrapper(mActivity, R.style.AppPopupMenuStyle2);

        PopupMenu popup = new PopupMenu(popupContext, view);
        popup.getMenuInflater().inflate(R.menu.menu_portfolio_download, popup.getMenu());
        MenuItem itemValuationD = popup.getMenu().findItem(R.id.itemPtValuationD);
        MenuItem itemSummaryD = popup.getMenu().findItem(R.id.itemPtSummaryD);// summary

        itemValuationD.setVisible(false);
        itemSummaryD.setVisible(false);
        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession, AppApplication.TMP_ALLOWED_FEATURED);
        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
            JSONObject mJsoObject = null;
            try {
                mJsoObject = new JSONObject(allowedFeatured);
                JSONArray jsonArray = mJsoObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.optJSONObject(i).has("feature1011")) {
                        itemValuationD.setVisible(true);
                    } else if (jsonArray.optJSONObject(i).has("feature1012")) {
                        itemSummaryD.setVisible(true);
                    }
                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }

        }

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.itemPtValuationD) {
                        dialogFilterPortfolioValuation();
}
else if (item.getItemId() == R.id.itemPtSummaryD) {
                        dialogFilterPortfolio();
}
                return true;
            }
        });
        popup.show();//showing popup menu


    }

    private void showPopMenuItemShare(View view) {
        Context popupContext = new ContextThemeWrapper(mActivity, R.style.AppPopupMenuStyle2);

        PopupMenu popup = new PopupMenu(popupContext, view);
        popup.getMenuInflater().inflate(R.menu.menu_pdf, popup.getMenu());

        try {
            Field field = popup.getClass().getDeclaredField("mPopup");
            field.setAccessible(true);
            Object mPopup = field.get(popup);
            mPopup.getClass().getDeclaredMethod("setForceShowIcon", boolean.class)
                    .invoke(mPopup, true);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.itemPtSummaryE) {
                        sendPortfolioSummaryOnEmail();
}
else if (item.getItemId() == R.id.itemPtValuationE) {
                        sendEmailValuation();
}
else if (item.getItemId() == R.id.itemPtValuationW) {
                        sendReportOnWhatsapp("portfolioValuation");
}
else if (item.getItemId() == R.id.itemPtSummaryW) {
                        sendReportOnWhatsapp("portfolioSummary");
}
                return true;
            }
        });
        popup.show();//showing popup menu


    }




    private void setSpinnerMembers(String rawData) {
        try {
            mMemberList = new ArrayList<>();
            List<String> listMem = new ArrayList<>();
            listMem.add("All");

            JSONObject jsonObject;
            jsonObject = new JSONObject(rawData);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    mMemberList.add(jsonObject1);
                    listMem.add(jsonObject1.optString("name"));
                }
            } else {
                String service_msg = jsonObject.optString("message");
                Toast.makeText(mActivity, service_msg, Toast.LENGTH_SHORT).show();
            }

            ArrayAdapter adapter = new ArrayAdapter(mActivity, R.layout.spinner_bg, listMem);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mMemberSpinner.setAdapter(adapter);
            mMemberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedPosition = position;
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }


    private void getAllMembers() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MEMBERS + "levelNo=" + Utils.getSelectedLevelNo(mSession) + "&investorUid=" + Utils.getSelectedUid(mSession)+"&selectedUser=" + Utils.getSelectedUserObject(mSession);

            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                setSpinnerMembers(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void datePicker2(final boolean isStartDate, final boolean isDateForValuation)  {
        Calendar calendar = Calendar.getInstance();
        if (isDateForValuation){
            calendar.add(Calendar.DAY_OF_MONTH, -1);
        }
        int mYear = calendar.get(Calendar.YEAR);
        int mMonth = calendar.get(Calendar.MONTH);
        int mDay = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(mActivity, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                if (view.isShown()) {
                    NumberFormat formatter = new DecimalFormat("00");
                    String day = formatter.format((dayOfMonth));
                    String month = formatter.format((monthOfYear + 1));
                    String date_time = year + "-" + month + "-" + day;
                    String date_for_text = day + "-" + month + "-" + year;

                    if (isDateForValuation){
                        tvValuationDate.setText(date_for_text);
                        mValuationDate = date_time;
                    }else{
                        if (isStartDate) {
                            mTvStartDate.setText(date_for_text);
                            mStartingDate = date_time;
                            mTvStartDateP.setText(date_for_text);
                        } else {
                            mTvEndDate.setText(date_for_text);
                            mTvEndDateP.setText(date_for_text);
                            mEndDate = date_time;
                        }
                    }

                }

            }
        }, mYear, mMonth, mDay);

        if (isDateForValuation){
            datePickerDialog.getDatePicker().setMaxDate(calendar.getTimeInMillis());
        }
        datePickerDialog.show();
    }

    private void datePicker(final boolean isStartDate, final boolean isDateForValuation) {

        SimpleDateFormat apiFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat displayFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        Calendar calendar = Calendar.getInstance();

        String defaultDateString;
        if(isStartDate) {
            defaultDateString = mTvStartDateP.getText().toString();
        }else if(isDateForValuation) {
            defaultDateString = tvValuationDate.getText().toString();
        } else {
            defaultDateString = mTvEndDateP.getText().toString();
        }
        String minDate = null;
        if (!isStartDate && !isDateForValuation && !mTvStartDateP.getText().toString().isEmpty())
            minDate = mTvStartDateP.getText().toString();

        String maxDate = null;
        if (isStartDate && !mTvEndDateP.getText().toString().isEmpty())
            maxDate = mTvEndDateP.getText().toString();
        else if (isDateForValuation) {
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            maxDate = displayFormat.format(calendar.getTime());
        }

        showDatePickerDialog(
                mActivity,
                mActivity,
                minDate,
                maxDate,
                defaultDateString,
                displayFormat,
                selectedDisplayDate -> {  // callback

                    try {
                        // Convert back to yyyy-MM-dd
                        Date parsed = displayFormat.parse(selectedDisplayDate);
                        String apiDate = apiFormat.format(parsed);

                        if (isDateForValuation) {
                            tvValuationDate.setText(selectedDisplayDate);
                            mValuationDate = apiDate;
                        } else {
                            if (isStartDate) {
                                if (mTvStartDate != null)
                                    mTvStartDate.setText(selectedDisplayDate);
                                if (mTvStartDateP != null)
                                    mTvStartDateP.setText(selectedDisplayDate);
                                mStartingDate = apiDate;
                            } else {
                                if (mTvEndDate != null)
                                    mTvEndDate.setText(selectedDisplayDate);
                                if (mTvEndDateP != null)
                                    mTvEndDateP.setText(selectedDisplayDate);
                                mEndDate = apiDate;
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return  null;
                }
        );
    }


    private void dateCalculation(boolean isPreviousMonthClicked) {
        Calendar mCalender = Calendar.getInstance();

        if (mIsFirstTime) {
            mIsFirstTime = false;
            mCalender.add(Calendar.MONTH, 0);
        } else if (mMonthCount == 0) {
            mCalender.add(Calendar.MONTH, 0);
        } else {
            if (isPreviousMonthClicked) mCalender.add(Calendar.MONTH, mMonthCount);
            else mCalender.add(Calendar.MONTH, mMonthCount);
        }
        mCalender.set(Calendar.DAY_OF_MONTH, 1);
        Date firstDateOfPreviousMonth = mCalender.getTime();
        mCalender.set(Calendar.DATE, mCalender.getActualMaximum(Calendar.DATE)); // changed calendar to mCalender

        Date lastDateOfPreviousMonth = mCalender.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy");
        mStartingDate = formatter.format(firstDateOfPreviousMonth);
        mEndDate = formatter.format(lastDateOfPreviousMonth);

        String dateForString = formatterForText.format(lastDateOfPreviousMonth);

        mTvStartDate.setText(dateForString);
        mTvEndDate.setText(dateForString);

    }


    private void downloadFileSummary() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }

        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }

        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        String url = "";
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(getOneDayEarlier());

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            if (mSelectedTime.equalsIgnoreCase("SI")) {
                dateObject.put("endDate", endDate);
            } else {
                dateObject.put("startDate", mStartingDate);
                dateObject.put("endDate", mEndDate);
            }

            jsonArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSource);


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_COMPLETE_PORTFOLIO_SUMMARY_PDF + "filters=" + jsonArray + "&selectedUser=" + Utils.getSelectedUserObject(mSession);




/*https://profitcentre.investwell.app/webapi/client/dashboard/downloadCompletePortfolioSummary?
filters=[{"endDate":"2020-04-12"},{},{"activeFoliosOnly":"false"}]&selectedUser=
{"uid":"cc194cc3026338f87fc640c8b93e7130","levelNo":"98"}*/

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "portfolio_performance_","", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_portfolio_summary_download_successfully), "pdf", mFileSave,uri);
                    }
                });
    }

    private void downloadFileValuation() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        String url = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(getOneDayEarlier());

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", mValuationDate);
            jsonArray.put(dateObject);

            JSONObject dateObject2 = new JSONObject();
            dateObject2.put("isSummary", true);
            jsonArray.put(dateObject2);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSource);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_PORTFOLIO_REPORT + "filters=" + jsonArray + "&group=appid" + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "&clubTxns=true";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
           /*https://demo.investwell.app/webapi/client/reports/downloadPortfolioReport?filters=
    [{"endDate":"2020-04-29","isSummary":true}]&investorUid=106ca28e2c51d6c6a787e74837d300aa&group
    =appid&selectedUser={"uid":"106ca28e2c51d6c6a787e74837d300aa","levelNo":"98"}&clubTxns=true*/

            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "portfolio_valuation_", "",new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_portfolio_report_download_successfully), "pdf", mFileSave,uri);
                    }
                });

    }

    private void sendPortfolioSummaryOnEmail() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }

        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        String url = "";
        JSONArray filterArray = new JSONArray();
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));

            JSONObject dateObject = new JSONObject();
            String endDate = formatter.format(new Date());
            dateObject.put("endDate", endDate);
            filterArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            filterArray.put(dataSource);
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "SendReportOptions");
            JSONObject selectedUserObj = new JSONObject();
            selectedUserObj.put("selectedUser", Utils.getSelectedUserObject(mSession));
            filterArray.put(selectedUserObj);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL +
                    "purpose=Portfolio Summary&" +
                    "purposeVal=PS" +
                    "&filters=" + filterArray +
                    "&ccWithRm=false&brokerUid=" + mSession.getBrokerUID() +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +
                    "&selectedUser=" + Utils.getSelectedUserObject(mSession) +
                    "&endDate=" + endDate ;


           /* if (mSession.getLoginType().equals("broker")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "purpose=Portfolio Summary&purposeVal=PS&" + "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "" + "&endDate=" + endDate ;
            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "purpose=Portfolio Summary&purposeVal=PS&" + "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() + "&endDate=" + endDate + "componentForLoader=" + componentObject.toString() + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }*/

            url = URLDecoder.decode(url, "UTF-8");

            /*https://spvithlani.investwell.app/webapi/client/reports/sendReportEmailToUsers?
            purpose=Portfolio Summary&purposeVal=PS&ccWithRm=false&brokerUid=
            2357bdb419d9924c630e60bf99535a20&endDate=2020-04-19&componentForLoader=
            {"componentName":"SendReportOptions"}*/

            /*https://spvithlani.investwell.app/webapi/client/reports/sendReportEmailToUsers?
            purpose=Portfolio Summary&purposeVal=PS&ccWithRm=false&selectedUser=
            {"uid":"da4701a5ba3d6178dbee5e2271afbdce","levelNo":"100"}&brokerUid=2357bdb419d9924c630
            e60bf99535a20&endDate=2020-04-19&componentForLoader={"componentName":"SendReportOptions"}
            &investorUid=da4701a5ba3d6178dbee5e2271afbdce*/
        } catch (Exception e) {
            if (mBar != null && mActivity != null) mBar.dismiss();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                if (mBar != null && mActivity != null) mBar.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (mBar != null && mActivity != null) mBar.dismiss();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void sendEmailValuation() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        String url = "";

        JSONArray filterArray = new JSONArray();
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "true");

            JSONObject dateObject = new JSONObject();
            String endDate = formatter.format(new Date());
            dateObject.put("endDate", endDate);
            filterArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            filterArray.put(dataSource);
            JSONObject selectedUserObj = new JSONObject();
            selectedUserObj.put("selectedUser", Utils.getSelectedUserObject(mSession));
            filterArray.put(selectedUserObj);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL +
                    "purpose=Portfolio Valuation"+
                    "&purposeVal=PR" +
                    "&filters=" + filterArray +
                    "&ccWithRm=false" +
                    "&brokerUid=" + mSession.getBrokerUID() +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +
                    "&selectedUser=" + Utils.getSelectedUserObject(mSession) +
                    "&endDate=" + endDate ;

            url = URLDecoder.decode(url, "UTF-8");

            //  https://spvithlani.investwell.app/webapi/client/reports/sendReportEmailToUsers?
            //  purpose=Portfolio Return&purposeVal=PR&ccWithRm=false&selectedUser=
            //  {"uid":"6158fa1dba4bf04015e91d2e2caf5bcc","levelNo":"98"}&brokerUid=
            //  2357bdb419d9924c630e60bf99535a20&endDate=2020-05-21&componentForLoader=
            //  {"componentName":"SendReportOptions"}&investorUid=6158fa1dba4bf04015e91d2e2caf5bcc


        } catch (Exception e) {
            if (mBar != null) mBar.dismiss();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                if (mBar != null) mBar.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (mBar != null) mBar.dismiss();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void sendReportOnWhatsapp(String reportType){
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        JSONArray filterArray = new JSONArray();
        try {

            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));

            JSONObject dateObject = new JSONObject();
            String endDate = formatter.format(new Date());
            dateObject.put("endDate", endDate);
            filterArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            filterArray.put(dataSource);

        }catch (JSONException e) {
            throw new RuntimeException(e);
        }
        String url;
        if(mSession.getCustomURL().isEmpty())
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_WHATSAPP;
        else
            url = "https://" + mSession.getCustomURL() + "/webapi/" + Config.SEND_REPORT_ON_WHATSAPP;


        url = url + "filters=" + filterArray +
                "&clubTxns=true" +
                "&reportType=" + reportType +
                "&investorUid=" + Utils.getSelectedUid(mSession) +
                "&selectedUser=" + Utils.getSelectedUserObject(mSession);

        new ApiClient(requireContext(),mSession).makeGetRequest(
                url,
                isLoading->{
                    if (isLoading){
                        ProgressBarCommon.showDialog(requireContext());
                    }else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                }, response->{
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("status") == 0) {
                            JSONObject result = jsonObject.optJSONObject("result");
                            String whatsappUrl = result != null ? result.optString("url") : "";
                            if (!whatsappUrl.isEmpty()) {
                                if (WhatsAppShare.isAnyWhatsappInstalled(requireActivity())) {
                                    WhatsAppShare.shareOnWhatsApp(requireActivity(), whatsappUrl);
                                } else {
                                    showWhatsAppOptionsDialog();
                                }
                            }
                        }
                        else
                            Toast.makeText(requireContext(), jsonObject.optString("message"), Toast.LENGTH_LONG).show();

                    }catch (Exception e){
                        System.out.println();
                    }
                    return null;
                }, volleyError -> {
//                    if (mBar != null)
//                        mBar.dismiss();
                    if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                        VolleyError error = new VolleyError(new String(volleyError.networkResponse.data));
                        try {
                            JSONObject jsonObject2 = new JSONObject(error.getMessage());
                            Toast.makeText(requireContext(), jsonObject2.optString("error"), Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    } else if (volleyError instanceof NoConnectionError) {
                        Toast.makeText(requireContext(), requireContext().getResources().getString(R.string.no_internet), Toast.LENGTH_LONG).show();
                    } else {
                        String error = volleyError.getLocalizedMessage();
                    }

                    return null;
                },status->{
                    if (status == 401) {
                        mAppplication.showCommonDailog(requireContext(), requireContext().getString(R.string.txt_session_expired), requireContext().getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }
                    return null;
                });
    }

    private void showWhatsAppOptionsDialog(){
        CustomDialog customDialog = new CustomDialog(this);
        customDialog.showDialog(
                requireContext(),
                getString(R.string.alert),
                getString(R.string.whatsapp_not_installed),
                getString(R.string.install),
                getString(R.string.cancel),
                true,
                true
        );
    }
    @Override
    public void onDialogBtnClick(View view) {
        if (view.getId() == R.id.btDone) {
                redirectToPlayStore(requireContext());
}
else if (view.getId() == R.id.btCalcel) {
}
    }


    public void redirectToPlayStore(Context context) {
        String packageName = "com.whatsapp";
        PackageManager packageManager = context.getPackageManager();

        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName));
        if (playStoreIntent.resolveActivity(packageManager) != null) {
            context.startActivity(playStoreIntent);
        } else {
            // Play Store is not installed, open in browser
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
            context.startActivity(webIntent);
        }
    }


    @TargetApi(Build.VERSION_CODES.Q)
    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions){
            requestMultiPermissions(permissionList);
        }else {
            logD("DB", "PERMISSION GRANTED");
        }
    }
    private void requestMultiPermissions( String[] permissionList){
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }
    private final ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)){
            Log.d("DB", "PERMISSION GRANTED");
        }else {
            isGranted = false;
            Toast.makeText(mActivity, getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFileValuation();
        }
    });



    ViewPager.OnPageChangeListener onViewPageChange = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(final int position) {

            setVisibilityOfAddButton();
            switch (position) {
                case 0:
                    // mTvTitle.setText("Mutual Fund");
                    break;

                case 1:
                    //mTvTitle.setText("Share & Bond");
                    break;

                case 2:
                    //mTvTitle.setText("Fixed Deposit");
                    break;

                case 3:
                    //mTvTitle.setText("Others Asserts");
                    break;


            }
        }


        @Override
        public void onPageScrollStateChanged(int state) {


        }
    };

    public void setVisibilityOfAddButton() {
        int currentPageSelected = mViewPager.getCurrentItem();
        Fragment fragment = (Fragment) Objects.requireNonNull(mViewPager.getAdapter()).instantiateItem(mViewPager, currentPageSelected);

        if (fragment instanceof FragPtSummaryMutualFamilyHead ||fragment instanceof FragPtSummaryMutualFamilyHeadLayout6 || fragment instanceof FragPtSummaryMutualFundSingle|| fragment instanceof FragPtSummaryMutualFundSingleLayout6) {
            hideAddButton(0);
        }
        else if (fragment instanceof FragPtSummaryShareBonds) {

            if (((FragPtSummaryShareBonds) fragment).isShareBondListEmpty()) {
                hideAddButton(currentPageSelected);
            } else {
                showAddButton(currentPageSelected);
            }
        }
        else if (fragment instanceof FragPtSummaryShareBonds2) {
            if (((FragPtSummaryShareBonds2) fragment).isShareBondListEmpty()) {
                hideAddButton(currentPageSelected);
            } else {
                showAddButton(currentPageSelected);
            }
        }
        else if (fragment instanceof FragPtSummaryFD) {
            if (((FragPtSummaryFD) fragment).isFDListEmpty()) {
                hideAddButton(currentPageSelected);
            } else {
                showAddButton(currentPageSelected);
            }
        }else if (fragment instanceof FragPtSummaryFDLayout6) {
            if (((FragPtSummaryFDLayout6) fragment).isFDListEmpty()) {
                hideAddButton(currentPageSelected);
            } else {
                showAddButton(currentPageSelected);
            }
        }
        else if (fragment instanceof FragPtFamilySummaryFD) {
            if (((FragPtFamilySummaryFD) fragment).isFDListEmpty()) {
                hideAddButton(currentPageSelected);
            } else {
                showAddButton(currentPageSelected);
            }
        }
        else {
            hideAddButton(currentPageSelected);
        }
    }
    public void hideAddButton(int senderPageIndex) {
        if(canAddTxn){
        int currentPageSelected = mViewPager.getCurrentItem();
        if (currentPageSelected == senderPageIndex) {
           mFabAddTxn.setVisibility(View.GONE);
        }
        }
    }
    public void showAddButton(int senderPageIndex) {
        if(canAddTxn) {
            int currentPageSelected = mViewPager.getCurrentItem();
            if (currentPageSelected == senderPageIndex) {
                mFabAddTxn.setVisibility(View.VISIBLE);
            }
        }
    }



}
