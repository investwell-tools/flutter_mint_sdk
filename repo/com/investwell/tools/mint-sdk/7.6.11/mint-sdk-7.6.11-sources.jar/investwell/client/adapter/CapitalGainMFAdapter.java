package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import investwell.utils.AppSession;

public class CapitalGainMFAdapter  extends RecyclerView.Adapter<CapitalGainMFAdapter.ItemRowHolder> {
    private ArrayList<JSONObject> dataList;
    private Context mContext;
    private NumberFormat format;
    private AppSession mSession;
    private String mClient = "";

    public CapitalGainMFAdapter(Context context, ArrayList<JSONObject> dataList) {
        this.dataList = dataList;
        this.mContext = context;

        format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public CapitalGainMFAdapter.ItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.primary_scheme_item, viewGroup, false);

        CapitalGainMFAdapter.ItemRowHolder mh = new CapitalGainMFAdapter.ItemRowHolder(view);
        return mh;
    }

    @Override
    public void onBindViewHolder(CapitalGainMFAdapter.ItemRowHolder itemRowHolder, int i) {
        // tvCapGainDebt forDebt forEquity
        try{
            JSONObject jsonObject = dataList.get(i);
            itemRowHolder.tvHeader1.setText(jsonObject.optString("name"));
            itemRowHolder.flxform.removeAllViews();
            if(jsonObject.optString("name").equals("Long Term Equity") && jsonObject.optString("type").equals("MF")) {
                JSONObject jsonDataLongTermBeforeJan18 = jsonObject.optJSONObject("longTermBeforeJan18");
                JSONObject jsonDataLongTermAfterJan18 = jsonObject.optJSONObject("longTermAfterJan18");
                JSONObject jsonSummary = jsonObject.optJSONObject("summary");

                if(jsonDataLongTermBeforeJan18!=null) {

                    JSONArray jsonArrayBeforeFifo = jsonDataLongTermBeforeJan18.optJSONArray("fifo");
                    JSONObject jsonArrayBeforesummary = jsonDataLongTermBeforeJan18.optJSONObject("summary");
                    for (int j = 0; j < jsonArrayBeforeFifo.length(); j++) {
                        JSONObject innerObject = jsonArrayBeforeFifo.optJSONObject(j);
                        JSONObject schemeSummaryObject = innerObject.optJSONObject("summary");
                        View child = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);
                        TextView tvSchemeName = child.findViewById(R.id.tvSchemeName);
                        TextView tvUnitSold = child.findViewById(R.id.tvUnitSold);
                        TextView tvAmtRecieved = child.findViewById(R.id.tvAmtRecieved);
                        TextView tvPurCost = child.findViewById(R.id.tvPurCost);
                        TextView tvAdjAmt = child.findViewById(R.id.tvAdjAmt);
                        TextView tvCapGain = child.findViewById(R.id.tvCapGain);
                        LinearLayout llSchemeData = child.findViewById(R.id.llSchemeData);
                        LinearLayout llSummary = child.findViewById(R.id.llSummary);
                        llSummary.setVisibility(View.GONE);
                        RelativeLayout tvLTNameLay = child.findViewById(R.id.tvLTNameLay);
                        TextView tvLTName = child.findViewById(R.id.tvLTName);

                        RelativeLayout forEquity = child.findViewById(R.id.forEquity);
                        RelativeLayout forDebt = child.findViewById(R.id.forDebt);
                        TextView tvCapGainDebt = child.findViewById(R.id.tvCapGainDebt);
                        LinearLayout forEquitylast = child.findViewById(R.id.forEquitylast);

                        forDebt.setVisibility(View.GONE);
                        forEquity.setVisibility(View.VISIBLE);
                        forEquitylast.setVisibility(View.VISIBLE);


                        if (j == 0) {
                            tvLTNameLay.setVisibility(View.VISIBLE);
                            tvLTName.setText(R.string.long_term_before_jan_2018);
                        } else {
                            tvLTNameLay.setVisibility(View.GONE);
                        }

                        double strikedUnits = schemeSummaryObject.optDouble("strikedUnits");
                        double purchaseAmount = schemeSummaryObject.optDouble("purchaseAmount");
                        double adjustedCost = schemeSummaryObject.optDouble("adjustedCost");
                        double sellAmount = schemeSummaryObject.optDouble("sellAmount");
                        double taxableGain = schemeSummaryObject.optDouble("taxableGain");

                        if(taxableGain>0) {
                            tvCapGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                            tvCapGainDebt.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }else{
                            tvCapGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                            tvCapGainDebt.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        }

                        tvSchemeName.setText(innerObject.optString("schemeName") + " [" + innerObject.optString("folioNo") + "]");
                        tvUnitSold.setText(String.format("%.4f", strikedUnits));

                        tvAmtRecieved.setText(format.format(sellAmount));
                        tvPurCost.setText(format.format(purchaseAmount));
                        tvAdjAmt.setText(format.format(adjustedCost));
                        tvCapGain.setText(format.format(taxableGain));
                        tvCapGainDebt.setText(format.format(taxableGain));

                        itemRowHolder.flxform.addView(child);
                        child.setTag("" + innerObject);
                    }
                    if(jsonArrayBeforeFifo.length()>0){
                        /// long term summary
                        View child1 = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);

                        LinearLayout longTermSummary = child1.findViewById(R.id.longTermSummary);
                        longTermSummary.setVisibility(View.VISIBLE);
                        TextView tvSummaryPurCost = child1.findViewById(R.id.tvLTSummaryPurCost);
                        TextView tvSummaryAmtRec = child1.findViewById(R.id.tvLTSummaryAmtRec);
                        TextView tvSummaryTaxGain = child1.findViewById(R.id.tvLTSummaryTaxGain);
                        TextView tvTotal = child1.findViewById(R.id.tvLTTotal);
                        LinearLayout llSchemeData = child1.findViewById(R.id.llSchemeData);
                        llSchemeData.setVisibility(View.GONE);
                        LinearLayout llSummary = child1.findViewById(R.id.llSummary);
                        llSummary.setVisibility(View.GONE);

                        // tvLTSummaryAmtRec tvLTSummaryPurCost tvLTSummaryTaxGain
                        tvTotal.setText(R.string.long_term_before_jan_2018_total);
                        double purchaseAmountSumm = jsonArrayBeforesummary.optDouble("purchaseAmount");
                        double sellAmountSumm = jsonArrayBeforesummary.optDouble("sellAmount");
                        double taxableGainSumm = jsonArrayBeforesummary.optDouble("taxableGain");

                        if(taxableGainSumm>0) {
                            tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }else{
                            tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        }

                        tvSummaryAmtRec.setText(format.format(sellAmountSumm));
                        tvSummaryPurCost.setText(format.format(purchaseAmountSumm));
                        tvSummaryTaxGain.setText(format.format(taxableGainSumm));
                        itemRowHolder.flxform.addView(child1);
                    }

                }
                if(jsonDataLongTermAfterJan18!=null) {
                    JSONArray jsonArrayAfterFifo = jsonDataLongTermAfterJan18.optJSONArray("fifo");
                    JSONObject jsonArrayAftersummary = jsonDataLongTermAfterJan18.optJSONObject("summary");
                    for (int j = 0; j < jsonArrayAfterFifo.length(); j++) {
                        JSONObject innerObject = jsonArrayAfterFifo.optJSONObject(j);
                        JSONObject schemeSummaryObject = innerObject.optJSONObject("summary");

                        View child = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);
                        TextView tvSchemeName = child.findViewById(R.id.tvSchemeName);
                        TextView tvUnitSold = child.findViewById(R.id.tvUnitSold);
                        TextView tvAmtRecieved = child.findViewById(R.id.tvAmtRecieved);
                        TextView tvPurCost = child.findViewById(R.id.tvPurCost);
                        TextView tvAdjAmt = child.findViewById(R.id.tvAdjAmt);
                        TextView tvCapGain = child.findViewById(R.id.tvCapGain);
                        LinearLayout llSchemeData = child.findViewById(R.id.llSchemeData);
                        LinearLayout llSummary = child.findViewById(R.id.llSummary);
                        llSummary.setVisibility(View.GONE);
                        RelativeLayout tvLTNameLay = child.findViewById(R.id.tvLTNameLay);
                        TextView tvLTName = child.findViewById(R.id.tvLTName);

                        RelativeLayout forEquity = child.findViewById(R.id.forEquity);
                        RelativeLayout forDebt = child.findViewById(R.id.forDebt);
                        TextView tvCapGainDebt = child.findViewById(R.id.tvCapGainDebt);
                        LinearLayout forEquitylast = child.findViewById(R.id.forEquitylast);

                        forDebt.setVisibility(View.GONE);
                        forEquity.setVisibility(View.VISIBLE);
                        forEquitylast.setVisibility(View.VISIBLE);

                        if (j == 0) {
                            tvLTNameLay.setVisibility(View.VISIBLE);
                            tvLTName.setText(R.string.long_term_after_jan_2018);
                        } else {
                            tvLTNameLay.setVisibility(View.GONE);
                        }

                        double strikedUnits = schemeSummaryObject.optDouble("strikedUnits");
                        double purchaseAmount = schemeSummaryObject.optDouble("purchaseAmount");
                        double adjustedCost = schemeSummaryObject.optDouble("adjustedCost");
                        double sellAmount = schemeSummaryObject.optDouble("sellAmount");
                        double taxableGain = schemeSummaryObject.optDouble("taxableGain");

                        if(taxableGain>0) {
                            tvCapGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                            tvCapGainDebt.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }else{
                            tvCapGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                            tvCapGainDebt.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        }

                        tvSchemeName.setText(innerObject.optString("schemeName") + " [" + innerObject.optString("folioNo") + "]");
                        tvUnitSold.setText(String.format("%.4f", strikedUnits));

                        tvAmtRecieved.setText(format.format(sellAmount));
                        tvPurCost.setText(format.format(purchaseAmount));
                        tvAdjAmt.setText(format.format(adjustedCost));
                        tvCapGain.setText(format.format(taxableGain));
                        tvCapGainDebt.setText(format.format(taxableGain));

                        itemRowHolder.flxform.addView(child);
                        child.setTag("" + innerObject);
                    }

                    if (jsonArrayAfterFifo.length() > 0) {
                        /// long term summary
                        View child1 = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);
                        LinearLayout longTermSummary = child1.findViewById(R.id.longTermSummary);
                        longTermSummary.setVisibility(View.VISIBLE);
                        TextView tvSummaryPurCost = child1.findViewById(R.id.tvLTSummaryPurCost);
                        TextView tvSummaryAmtRec = child1.findViewById(R.id.tvLTSummaryAmtRec);
                        TextView tvSummaryTaxGain = child1.findViewById(R.id.tvLTSummaryTaxGain);
                        TextView tvTotal = child1.findViewById(R.id.tvLTTotal);
                        LinearLayout llSchemeData = child1.findViewById(R.id.llSchemeData);
                        llSchemeData.setVisibility(View.GONE);
                        LinearLayout llSummary = child1.findViewById(R.id.llSummary);
                        llSummary.setVisibility(View.GONE);

                        // tvLTSummaryAmtRec tvLTSummaryPurCost tvLTSummaryTaxGain
                        tvTotal.setText(R.string.long_term_after_jan_2018_total);
                        double purchaseAmountSumm = jsonArrayAftersummary.optDouble("purchaseAmount");
                        double sellAmountSumm = jsonArrayAftersummary.optDouble("sellAmount");
                        double taxableGainSumm = jsonArrayAftersummary.optDouble("taxableGain");

                        if(taxableGainSumm>0) {
                            tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }else{
                            tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        }

                        tvSummaryAmtRec.setText(format.format(sellAmountSumm));
                        tvSummaryPurCost.setText(format.format(purchaseAmountSumm));
                        tvSummaryTaxGain.setText(format.format(taxableGainSumm));
                        itemRowHolder.flxform.addView(child1);
                    }
                }
                if(jsonDataLongTermBeforeJan18!=null || jsonDataLongTermAfterJan18!=null ) {
                    /// long term summary
                    View child1 = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);
                    TextView tvSummaryPurCost = child1.findViewById(R.id.tvSummaryPurCost);
                    TextView tvSummaryAmtRec = child1.findViewById(R.id.tvSummaryAmtRec);
                    TextView tvSummaryTaxGain = child1.findViewById(R.id.tvSummaryTaxGain);
                    TextView tvTotal = child1.findViewById(R.id.tvTotal);

                    LinearLayout llSchemeData = child1.findViewById(R.id.llSchemeData);
                    llSchemeData.setVisibility(View.GONE);
                    LinearLayout llSummary = child1.findViewById(R.id.llSummary);
                    llSummary.setVisibility(View.VISIBLE);
                    // tvSummaryAmtRec tvSummaryPurCost tvSummaryTaxGain

                    tvTotal.setText(jsonObject.optString("name") + mContext.getString(R.string.total_space));
                    double purchaseAmountSumm = jsonSummary.optDouble("purchaseAmount");
                    double sellAmountSumm = jsonSummary.optDouble("sellAmount");
                    double taxableGainSumm = jsonSummary.optDouble("taxableGain");

                    if(taxableGainSumm>0) {
                        tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    }else{
                        tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }

                    tvSummaryAmtRec.setText(format.format(sellAmountSumm));
                    tvSummaryPurCost.setText(format.format(purchaseAmountSumm));
                    tvSummaryTaxGain.setText(format.format(taxableGainSumm));
                    itemRowHolder.flxform.addView(child1);
                }
            } else {
                /// for all terms
                JSONObject jsonData = jsonObject.optJSONObject("data");
                JSONArray jsonArray = jsonData.optJSONArray("fifo");
                JSONObject jsonSummary = jsonData.optJSONObject("summary");

                for (int j = 0; j < jsonArray.length(); j++) {
                    JSONObject innerObject = jsonArray.optJSONObject(j);
                    JSONObject schemeSummaryObject = innerObject.optJSONObject("summary");
                    View child = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);
                    TextView tvSchemeName = child.findViewById(R.id.tvSchemeName);
                    TextView tvUnitSold = child.findViewById(R.id.tvUnitSold);
                    TextView tvUnitSoldHeading = child.findViewById(R.id.tvUnitSoldHeading);
                    TextView tvAmtRecieved = child.findViewById(R.id.tvAmtRecieved);
                    TextView tvPurCost = child.findViewById(R.id.tvPurCost);
                    TextView tvAdjAmt = child.findViewById(R.id.tvAdjAmt);
                    TextView tvCapGain = child.findViewById(R.id.tvCapGain);
                    LinearLayout llSchemeData = child.findViewById(R.id.llSchemeData);
                    LinearLayout llSummary = child.findViewById(R.id.llSummary);
                    llSummary.setVisibility(View.GONE);

                    RelativeLayout forEquity = child.findViewById(R.id.forEquity);
                    RelativeLayout forDebt = child.findViewById(R.id.forDebt);
                    TextView tvCapGainDebt = child.findViewById(R.id.tvCapGainDebt);
                    LinearLayout forEquitylast = child.findViewById(R.id.forEquitylast);

                    if(jsonObject.optString("name").contains("Debt")){
                        forDebt.setVisibility(View.VISIBLE);
                        forEquity.setVisibility(View.GONE);
                        forEquitylast.setVisibility(View.GONE);
                    }else{
                        forDebt.setVisibility(View.GONE);
                        forEquity.setVisibility(View.VISIBLE);
                        forEquitylast.setVisibility(View.VISIBLE);
                    }
                    // tvCapGainDebt forDebt forEquity

                    //  tvCapGain  tvAdjAmt   tvPurCost  tvAmtRecieved  tvUnitSold
                    //  strikedUnits  sellAmount purchaseAmount  taxableGain   adjustedCost
                    double strikedUnits = schemeSummaryObject.optDouble("strikedUnits");
                    double purchaseAmount = schemeSummaryObject.optDouble("purchaseAmount");
                    double adjustedCost = schemeSummaryObject.optDouble("adjustedCost");
                    double sellAmount = schemeSummaryObject.optDouble("sellAmount");
                    double taxableGain = schemeSummaryObject.optDouble("taxableGain");

                    if(taxableGain>0) {
                        tvCapGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        tvCapGainDebt.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    }else{
                        tvCapGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        tvCapGainDebt.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }

                    if (jsonObject.optString("type").equals("MF")) {
                        tvUnitSoldHeading.setText("Unit Sold");
                        tvSchemeName.setText(innerObject.optString("schemeName") + " [" + innerObject.optString("folioNo") + "]");
                        tvUnitSold.setText(String.format("%.4f", strikedUnits));
                    } else {
                        tvUnitSoldHeading.setText("Quantity");
                        tvSchemeName.setText(innerObject.optString("schemeName"));
                        tvUnitSold.setText(String.format("%.0f", strikedUnits));
                    }

                    tvAmtRecieved.setText(format.format(sellAmount));
                    tvPurCost.setText(format.format(purchaseAmount));
                    tvAdjAmt.setText(format.format(adjustedCost));
                    tvCapGain.setText(format.format(taxableGain));
                    tvCapGainDebt.setText(format.format(taxableGain));

                    itemRowHolder.flxform.addView(child);
                    child.setTag("" + innerObject);
                }

                View child1 = View.inflate(mContext, R.layout.capitalgain_scheme_item, null);
                TextView tvSummaryPurCost = child1.findViewById(R.id.tvSummaryPurCost);
                TextView tvSummaryAmtRec = child1.findViewById(R.id.tvSummaryAmtRec);
                TextView tvSummaryTaxGain = child1.findViewById(R.id.tvSummaryTaxGain);
                TextView tvTotal = child1.findViewById(R.id.tvTotal);

                LinearLayout llSchemeData = child1.findViewById(R.id.llSchemeData);
                llSchemeData.setVisibility(View.GONE);
                LinearLayout llSummary = child1.findViewById(R.id.llSummary);
                llSummary.setVisibility(View.VISIBLE);
                // tvSummaryAmtRec tvSummaryPurCost tvSummaryTaxGain

                tvTotal.setText(jsonObject.optString("name") + mContext.getString(R.string.total_space));
                double purchaseAmountSumm = jsonSummary.optDouble("purchaseAmount");
                double sellAmountSumm = jsonSummary.optDouble("sellAmount");
                double taxableGainSumm = jsonSummary.optDouble("taxableGain");

                if(taxableGainSumm>0) {
                    tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                }else{
                    tvSummaryTaxGain.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                }

                tvSummaryAmtRec.setText(format.format(sellAmountSumm));
                tvSummaryPurCost.setText(format.format(purchaseAmountSumm));
                tvSummaryTaxGain.setText(format.format(taxableGainSumm));
                itemRowHolder.flxform.addView(child1);
            }
        }catch(Exception e){
            System.out.println("=====Adeptor Error========"+e.toString());
        }
    }

    @Override
    public int getItemCount() {
        return (null != dataList ? dataList.size() : 0);
    }

    public class ItemRowHolder extends RecyclerView.ViewHolder {
        protected TextView tvHeader1, tvMenu1, tvMenu2, tvMenu3, tvMenu4;
        protected LinearLayout flxform;

        public ItemRowHolder(View view) {
            super(view);

            this.tvHeader1 = view.findViewById(R.id.tvHeader1);
            this.tvMenu1 = view.findViewById(R.id.tvMenu1);
            this.tvMenu2 = view.findViewById(R.id.tvMenu2);
            this.tvMenu3 = view.findViewById(R.id.tvMenu3);
            this.tvMenu4 = view.findViewById(R.id.tvMenu4);
            this.flxform = view.findViewById(R.id.flxform);
        }
    }

    public void updateList(List<JSONObject> list) {
        dataList.clear();
        dataList.addAll(list);
        notifyDataSetChanged();
    }
}

