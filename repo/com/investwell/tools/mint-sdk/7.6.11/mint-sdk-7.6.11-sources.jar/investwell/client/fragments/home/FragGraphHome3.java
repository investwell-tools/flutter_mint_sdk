package investwell.client.fragments.home;


import static investwell.charts.mikephil.charting.animation.Easing.EaseInOutQuad;
import static investwell.di.core.LogExtKt.logD;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import investwell.charts.mikephil.charting.charts.PieChart;
import investwell.charts.mikephil.charting.data.PieData;
import investwell.charts.mikephil.charting.data.PieDataSet;
import investwell.charts.mikephil.charting.data.PieEntry;
import investwell.charts.mikephil.charting.formatter.PercentFormatter;
import investwell.charts.mikephil.charting.utils.MPPointF;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Utils;


public class FragGraphHome3 extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private TextView mTvNothing;
    private PieChart mAssetChart;
    private TextView tvTitleName;
    private JSONObject mJSONGraphObject;
    private TextView tvOtherAssets, tvFixedDeposit, tvShareBond, tvMf;


    @Override
    public void onResume() {
        super.onResume();
        //FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mMainActivity = (ClientActivity) context;
        mSession = AppSession.getInstance(mMainActivity);
        mApplication = (AppApplication) mMainActivity.getApplication();
        mSession = AppSession.getInstance(mMainActivity);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_graph_layout3, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        logD("graphAPI3");
        try {
            JSONObject jsonObject = new JSONObject(AppApplication.VALUE_ASSETS_WISE);
            mJSONGraphObject = new JSONObject();

            if (jsonObject.optInt("status") == 0) {
                mJSONGraphObject = jsonObject.optJSONObject("result");

            }
        } catch (Exception e) {
        }


        tvTitleName = view.findViewById(R.id.tvTitleName);
        mTvNothing = view.findViewById(R.id.tvNothing);
        mAssetChart = view.findViewById(R.id.animatedPieView);

        tvMf = view.findViewById(R.id.tvMf);
        tvShareBond = view.findViewById(R.id.tvShareBond);
        tvFixedDeposit = view.findViewById(R.id.tvFixedDeposit);
        tvOtherAssets = view.findViewById(R.id.tvOtherAssets);

        view.findViewById(R.id.llMutualFund).setOnClickListener(this);
        view.findViewById(R.id.llShareBond).setOnClickListener(this);
        view.findViewById(R.id.llFixedDeposit).setOnClickListener(this);
        view.findViewById(R.id.llOtherAssets).setOnClickListener(this);

        View view1 = view.findViewById(R.id.viewLine1);
        View view2 = view.findViewById(R.id.viewLine2);
        View view3 = view.findViewById(R.id.viewLine3);
        View view4 = view.findViewById(R.id.viewLine4);
        view1.getBackground().setColorFilter(ContextCompat.getColor(requireActivity(), R.color.layout3_mf), PorterDuff.Mode.SRC_OVER);
        view2.getBackground().setColorFilter(ContextCompat.getColor(requireActivity(), R.color.layout3_sharebond), PorterDuff.Mode.SRC_OVER);
        view3.getBackground().setColorFilter(ContextCompat.getColor(requireActivity(), R.color.layout3_fd), PorterDuff.Mode.SRC_OVER);
        view4.getBackground().setColorFilter(ContextCompat.getColor(requireActivity(), R.color.layout3_other), PorterDuff.Mode.SRC_OVER);


        //  tvTitleName.setText(getString(R.string.product));
        setchartfeature();
        setGraph();
    }

    public void updateData() {
        if (!isAdded() || getView() == null) {
            return;
        }
        try {
            if (!android.text.TextUtils.isEmpty(AppApplication.VALUE_ASSETS_WISE)) {
                JSONObject jsonObject = new JSONObject(AppApplication.VALUE_ASSETS_WISE);
                if (jsonObject.optInt("status") == 0) {
                    mJSONGraphObject = jsonObject.optJSONObject("result");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        setGraph();
    }

    @Override
    public void onClick(View v) {
        Bundle bundle = new Bundle();
        if (v.getId() == R.id.llMutualFund) {
                mMainActivity.changeColor(3);
                mMainActivity.mTabCount = 2;
                bundle = new Bundle();
                mMainActivity.displayViewOther(19, bundle);
}
else if (v.getId() == R.id.llShareBond) {
                mMainActivity.changeColor(3);
                mMainActivity.mTabCount = 2;
                bundle = new Bundle();
                bundle.putString("tabName", "shareBond");
                mMainActivity.displayViewOther(19, bundle);
}
else if (v.getId() == R.id.llFixedDeposit) {
                mMainActivity.changeColor(3);
                mMainActivity.mTabCount = 2;
                bundle = new Bundle();
                bundle.putString("tabName", "fixedDeposit");
                mMainActivity.displayViewOther(19, bundle);
}
else if (v.getId() == R.id.llOtherAssets) {
                mMainActivity.changeColor(3);
                mMainActivity.mTabCount = 2;
                bundle = new Bundle();
                bundle.putString("tabName", "Others");
                mMainActivity.displayViewOther(19, bundle);
}
    }

    private void setchartfeature() {
        mAssetChart.setUsePercentValues(true);
        mAssetChart.getDescription().setEnabled(false);
        mAssetChart.setExtraOffsets(5, 10, 5, 5);
        mAssetChart.setDragDecelerationFrictionCoef(0.95f);
        mAssetChart.setDrawHoleEnabled(true);
        mAssetChart.setHoleColor(Color.WHITE);
        mAssetChart.setTransparentCircleColor(Color.WHITE);
        mAssetChart.setTransparentCircleAlpha(110);
        mAssetChart.setRotationEnabled(true);
        mAssetChart.setHighlightPerTapEnabled(true);
        mAssetChart.getLegend().setEnabled(false);
        mAssetChart.setEntryLabelColor(Color.TRANSPARENT);
        mAssetChart.setEntryLabelTextSize(10f);
        mAssetChart.setDrawHoleEnabled(false);
        mAssetChart.setRotationAngle(0);
    }


    private void setGraph() {

        if (mJSONGraphObject!=null && mJSONGraphObject.optInt("status") == 0) {
            mTvNothing.setVisibility(View.GONE);
            mAssetChart.setVisibility(View.VISIBLE);
            ArrayList<PieEntry> entries = new ArrayList<PieEntry>();
            ArrayList<Integer> colorList = new ArrayList<>();

            double mf = mJSONGraphObject.optDouble("mf");
            double sb = mJSONGraphObject.optDouble("sb");
            double fd = mJSONGraphObject.optDouble("fd");
            double oa = mJSONGraphObject.optDouble("oa");
            Utils.setRuppesSymbol(tvMf, mf, requireActivity());
            Utils.setRuppesSymbol(tvShareBond, sb, requireActivity());
            Utils.setRuppesSymbol(tvFixedDeposit, fd, requireActivity());
            Utils.setRuppesSymbol(tvOtherAssets, oa, requireActivity());

            int colorCodeForMf = ContextCompat.getColor(requireActivity(), R.color.layout3_mf);
            int colorCodeForShareBond = ContextCompat.getColor(requireActivity(), R.color.layout3_sharebond);
            int colorCodeForFd = ContextCompat.getColor(requireActivity(), R.color.layout3_fd);
            int colorCodeForOther = ContextCompat.getColor(requireActivity(), R.color.layout3_other);

            entries.add(new PieEntry((float) mf, getString(R.string.dashboard_mutual_funds)));
            colorList.add(colorCodeForMf);
            entries.add(new PieEntry((float) sb, getString(R.string.share_amp_bond)));
            colorList.add(colorCodeForShareBond);
            entries.add(new PieEntry((float) fd, getString(R.string.dashboard_fd)));
            colorList.add(colorCodeForFd);
            entries.add(new PieEntry((float) oa, getString(R.string.dashboard_oa)));
            colorList.add(colorCodeForOther);

            // graph start from here
            PieDataSet dataSet = new PieDataSet(entries, "");
            dataSet.setDrawIcons(false);
            dataSet.setSliceSpace(0.1f);
            dataSet.setSelectionShift(7f);
            dataSet.setIconsOffset(new MPPointF(0, 40));
            dataSet.setYValuePosition(PieDataSet.ValuePosition.INSIDE_SLICE);
            dataSet.setColors(colorList);

            dataSet.setValueLinePart1OffsetPercentage(80.f);
            dataSet.setValueLinePart1Length(0.2f);
            dataSet.setValueLinePart2Length(0.4f);
            PieData data = new PieData(dataSet);
            data.setValueFormatter(new PercentFormatter());
            data.setValueTextSize(8f);
            data.setValueTextColor(Color.TRANSPARENT);

            //  data.setValueTypeface(mTfLight);
            mAssetChart.setData(data);
            mAssetChart.setRotationEnabled(false);
            mAssetChart.animateY(1400, EaseInOutQuad);
            // undo all highlights
            mAssetChart.highlightValues(null);
            mAssetChart.invalidate();
        } else {
            mTvNothing.setVisibility(View.VISIBLE);
            mAssetChart.setVisibility(View.GONE);
        }

    }


}
