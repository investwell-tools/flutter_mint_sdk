package investwell.client.fragments.aum;


import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Frag_Aum_Adapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.UtilityKotlin;

;


public class FragAumReportByUser extends BaseFragment implements View.OnClickListener {
    public static String values;
    private Frag_Aum_Adapter mAdapter;
    private TextView mTvLoading;
    private ShimmerFrameLayout mShimmerViewContainer;
    private RecyclerView recyclerView;
    private boolean loading = false;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentPageNo = 0;
    private int mFetchListsize = 10;
    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;
    private String mFundId = "", mSchemeId = "",ARNID="",CATEGORY="";
    private TextView mTvTotal, mTvEquity, tvName;
    private LinearLayout mMainLayout;
    private AppApplication mAppplication;
    private AppSession mSession;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private BrokerActivity mBrokerActivity;

    @Override
    public void onResume() {
        super.onResume();
      /*  if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mMainActivity.setMainVisibility(this, null);
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();

        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.aum_report),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_aum_report_user, container, false);
        setUpToolBar();

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);


        mTvLoading = view.findViewById(R.id.tvNothing);
        mMainLayout = view.findViewById(R.id.linerMain);
        mTvLoading.setVisibility(View.GONE);

        mTvTotal = view.findViewById(R.id.tvTotal);
        mTvEquity = view.findViewById(R.id.tvEquity);
        tvName = view.findViewById(R.id.tvName);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llAumReportUser).setBackgroundResource(R.mipmap.card_blank);

        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("fundid")) {
            mFundId = bundle.getString("fundid");
            mSchemeId = bundle.getString("schemeId");
            ARNID =bundle.getString("arnid");
            CATEGORY =bundle.getString("category");
            String name = bundle.getString("name");
            tvName.setText(name);
        }



        recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new Frag_Aum_Adapter(getActivity(), new ArrayList<JSONObject>(), new Frag_Aum_Adapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                  /*  JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(15, bundle1);*/
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 10;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getAumByUser(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        getAumByUser(1);
        return view;
    }

    private void getAumByUserFilter() {
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                getActivity().getSupportFragmentManager().popBackStack();
}
    }


    private void getAumByUser(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;

        String url = "";
        try {
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObjec = new JSONObject();
            JSONObject jsonObjecArn = new JSONObject();
            JSONObject jsonObjecCategory = new JSONObject();


            if ((ARNID !=null && !ARNID.isEmpty()) ){
                jsonObjecArn.put("arnid",ARNID);
                jsonArray.put(jsonObjecArn);
            }

            if ((CATEGORY !=null && !CATEGORY.isEmpty()) ){
                jsonObjecCategory.put("category",CATEGORY);
                jsonArray.put(jsonObjecCategory);
            }


            jsonObjec.put("fundid", mFundId);
            jsonArray.put(jsonObjec);

            JSONObject jsonObjec2 = new JSONObject();
            jsonObjec2.put("schid", mSchemeId);
            jsonArray.put(jsonObjec2);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "aumReport");


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_AUM_REPORT
                    + "filters=" + jsonArray.toString() + "&groupBy=100&orderBy=AUM&orderByDesc=true"
                    + "&pageSize=" + mFetchListsize + "&currentPage="
                    + pageNo +"";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");


        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }


        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    mShimmerViewContainer.setVisibility(View.VISIBLE);
                    mShimmerViewContainer.stopShimmer();
                    if (pageNo > 1) {
                        singleShedow.setVisibility(View.VISIBLE);
                        fullScreenShedow.setVisibility(View.GONE);
                    } else {
                        singleShedow.setVisibility(View.GONE);
                        fullScreenShedow.setVisibility(View.VISIBLE);
                    }
                } else {
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.GONE);
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                loading = false;
                List<JSONObject> list = new ArrayList<>();
                if (pageNo > 1) {
                    list.addAll(mAdapter.mDataList);
                }
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                        JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            list.add(jsonObject1);
                        }


                        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                        format.setMinimumFractionDigits(0);
                        format.setMaximumFractionDigits(0);

                        JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");

                        double AUM = jsonObjectSummary.optDouble("AUM");
                        String strAUM2 = format.format(AUM);
                        mTvTotal.setText(strAUM2);

                        double Equity = jsonObjectSummary.optDouble("Equity");
                        if (Equity > 0) {
                            mTvEquity.setText(getResources().getString(R.string.equity));
                        }

                        double liqAltra = jsonObjectSummary.optDouble("Liquid and Ultra Short");
                        if (liqAltra > 0) {
                            mTvEquity.setText(getResources().getString(R.string.liquid));
                        }

                        double Other = jsonObjectSummary.optDouble("Other");
                        if (Other > 0) {
                            mTvEquity.setText(getResources().getString(R.string.other));
                        }

                        double Arbitrage = jsonObjectSummary.optDouble("Arbitrage");
                        if (Arbitrage > 0) {
                            mTvEquity.setText(getResources().getString(R.string.arbitrage));
                        }

                    }
                } catch (Exception e) {

                } finally {
                    if (!list.isEmpty()) {
                        mAdapter.updateList(list, "data_by_user");
                        mTvLoading.setVisibility(View.GONE);
                        mMainLayout.setVisibility(View.VISIBLE);
                    } else {
                        mAdapter.updateList(new ArrayList<JSONObject>(), "data_by_user");
                        mTvLoading.setVisibility(View.VISIBLE);
                        mMainLayout.setVisibility(View.GONE);
                    }
                }
            }
        });
    }

}
