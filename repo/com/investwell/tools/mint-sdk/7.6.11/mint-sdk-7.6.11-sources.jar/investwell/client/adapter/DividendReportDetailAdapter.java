package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.dividend.FragDividendReport;
import investwell.client.fragments.dividend.FragDividendReportDetails;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

/**
 * Created by Dev on 16/08/2021.
 */

public class DividendReportDetailAdapter extends RecyclerView.Adapter<DividendReportDetailAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private DividendReportDetailAdapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragDividendReportDetails mFragDividendReportDetails;
    private AppSession mSession;

    public DividendReportDetailAdapter(Context context, FragDividendReportDetails fragDividendReport, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mFragDividendReportDetails = fragDividendReport;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_dividend_report_detail_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvdate, text1, text2, text3, tvfolio;
        CardView card_view;
        ImageView ivDivDetail;
        View ivThreeUpper;

        public ViewHolder(View view) {
            super(view);
            tvdate = view.findViewById(R.id.tvdate);
            text1 = view.findViewById(R.id.text1);
            text2 = view.findViewById(R.id.text2);
            text3 = view.findViewById(R.id.text3);
            card_view = view.findViewById(R.id.card_view);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                final JSONObject jsonObject = mDataList.get(position);

                tvdate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("navDate")));
                text1.setText(String.format("%.2f", jsonObject.optDouble("reinvest")) );
                text2.setText(String.format("%.2f", jsonObject.optDouble("payout")));
                text3.setText(String.format("%.2f", jsonObject.optDouble("tdsAmount")));

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });

        }
    }
    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


}
