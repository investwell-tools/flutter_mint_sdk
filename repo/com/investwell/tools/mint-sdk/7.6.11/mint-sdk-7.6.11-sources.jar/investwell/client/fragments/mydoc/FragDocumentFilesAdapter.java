package investwell.client.fragments.mydoc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FragDocumentFilesAdapter extends RecyclerView.Adapter<FragDocumentFilesAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragDocumentFilesList fragDocumentFilesList;

    public FragDocumentFilesAdapter(Context context, FragDocumentFilesList frag, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        fragDocumentFilesList = frag;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_client_view_doc, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDate;
        ImageView ivDelete, ivDownload;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvDate = view.findViewById(R.id.tvDate);
            ivDelete = view.findViewById(R.id.iv_delete);
            ivDownload = view.findViewById(R.id.iv_download);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);
                tvName.setText(jsonObject.optString("fileName"));
                tvDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("createdDate")));

                ivDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        fragDocumentFilesList.deleteFile(position);
                    }
                });

                ivDownload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        fragDocumentFilesList.downloadFile(position);
                    }
                });


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
