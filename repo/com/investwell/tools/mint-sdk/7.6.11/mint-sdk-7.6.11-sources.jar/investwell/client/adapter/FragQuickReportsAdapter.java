package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;

/**
 * Created by binesh on 8/5/18.
 */

public class FragQuickReportsAdapter extends RecyclerView.Adapter<FragQuickReportsAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;

    private Context mContext;
    private OnItemClickListener listener;
    private AppSession mSession;
    private NumberFormat format;

    public FragQuickReportsAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.quick_reports_adapter_home3, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        //return mDataList.size();
        return 4;
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


    public interface OnItemClickListener {
        void onItemClick(int position, String type);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvQuickReport;
        ImageView ivImage, ic_quick_report_view, ic_quick_report_download;
        private LinearLayout llReportViewAndDownload;

        public ViewHolder(View view) {
            super(view);
            ivImage = view.findViewById(R.id.ivImage);
            tvQuickReport = view.findViewById(R.id.tvQuickReport);
            llReportViewAndDownload = view.findViewById(R.id.llReportViewAndDownload);
            ic_quick_report_view = view.findViewById(R.id.ic_quick_report_view);
            ic_quick_report_download = view.findViewById(R.id.ic_quick_report_download);


        }


        public void setItem(final int position, final OnItemClickListener listener) {

            if (position == 0) {
                llReportViewAndDownload.setVisibility(View.GONE);
                ivImage.setImageResource(R.mipmap.home3_portfolio_valuation);
                tvQuickReport.setText("Portfolio\nValuation");

            } else if (position == 1) {
                llReportViewAndDownload.setVisibility(View.GONE);
                ivImage.setImageResource(R.mipmap.home3_portfolio_summary);
                tvQuickReport.setText("Portfolio\nSummary");

            } else if (position == 2) {
                llReportViewAndDownload.setVisibility(View.GONE);
                ivImage.setImageResource(R.mipmap.home3_capital_realized);
                tvQuickReport.setText("Capital Gain\nRealized");

            } else if (position == 3) {
                llReportViewAndDownload.setVisibility(View.GONE);
                ivImage.setImageResource(R.mipmap.home3_capital_unrealised);
                tvQuickReport.setText("Unrealized\nCapital Gain");

            }

            ic_quick_report_view.setOnClickListener(v -> {
                if (position == 2) {
                    listener.onItemClick(position, "viewCapitalGain");
                } else if (position == 3) {
                    listener.onItemClick(position, "viewUnrealized");
                }
            });

            ic_quick_report_download.setOnClickListener(v -> {
                if (position == 2) {
                    listener.onItemClick(position, "downloadCapitalGain");
                } else if (position == 3) {
                    listener.onItemClick(position, "downloadUnrealized");
                }
            });



            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position, "");
                }
            });
        }

    }


}
