package investwell.client.fragments.transection.additional.common;

import static investwell.utils.Extensions.showToast;
import static investwell.utils.ExtensionsKt.formatRupees;
import static investwell.utils.ExtensionsKt.getCanNumber;
import static investwell.utils.ExtensionsKt.getMfuId;
import static investwell.utils.ExtensionsKt.getUccCode;
import static investwell.utils.UtilityKotlin.checkFeaturePermissionsOnOff;
import static investwell.utils.UtilityKotlin.constructCartUrl;
import static investwell.utils.UtilityKotlin.jsonArrayToArrayList;
import static investwell.utils.UtilityKotlin.setRefreshKeyInExistingApi;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.activity.MfuCartWebView;
import investwell.client.fragments.transection.BottomScreenPaymentMode;
import investwell.client.fragments.transection.FullScreenBsePopUpDialog;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.BaseFragment;
import investwell.utils.CurrencyTextToWord;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.allorderstatus.BseOrderStatusActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.customView.CustomDialog;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class FragSwitchNseBseMfu extends BaseFragment implements View.OnClickListener{
    private TextView purchase_cost, market_value, mTvcardview_top_name_color, mtvShortTermUnit,
            mTvShortTermAmount, mtvLongTermUnit, mTvLongTermAmount,
            mTvAmount, mTvErrorMessage,tvShortTerm, tvLongTerm,tvWordAmount,tvLabelMinAmount;
    private RequestQueue requestQueue;
    private EditText mEtAmount;
    private final DecimalFormat myFormatter = new DecimalFormat("##,##,###.00");

    private ClientActivity mActivity;
    private AppSession mSession;
    private JSONObject mOldJsonObject, tranJsonObject;
    private ArrayList<JSONObject> mSchemeList, mGroupSchemeList;
    private long mMinAmount = 0, mMaxAmount = 0;
    private String mcardview_top_name_color = "";
    private Spinner mGroupSchemeSpinner, spTargetDividendFrequency;
    private RadioGroup mRadioGroup, mRgTargetSchemeType, mRgSourceSchemeType;
    private String mSwitchType = "amount", mTargetGroupSchemeId = "", mSchemeType = "", mTransectionType = "", mTargetSchemeId = "", mTargetSchemeName = "";
    private LinearLayout mLinerHalfPart, llTargetDividendFreq;
    private LinearLayout mLinerRedeem;
    private TextView mTvLavelSchemeType;
    private LinearLayout llSourceScheme, llSourceSchemeDivFreq;

    private AppApplication mAppplication;
    private ApiDataBase db;

    private List<JSONObject> mJsonARNList;
    private Spinner mSpArn, spSourceDividendFrequency;
    private LinearLayout mLlArn;
    private String mBseId = "";
    private String mFundName = "";

    private String mSourceSchemeGroupId = "";
    private String sourceSchemeType = "G";
    private RadioButton rbGrowth;
    private ArrayList<String> schidList;
    private ArrayList<String> sourceDividendFreqList;

    private  FullScreenBsePopUpDialog popup;
    private String mSchemeId = "";
    private MaterialButton mTvCart, mTvTransactNow;
    private JSONObject profileObject;
    private BottomScreenPaymentMode bottomPaymentMode;
    private String exchange = "";
    private boolean isNse2 = false;

    private ArrayList<JSONObject> mTargetDivSchemeObjList = new ArrayList<>();
    private boolean isSchemeTypeCleared = false;
    private String uccNumber = "";
    private String nseUccCode = "";

    private LinearLayout llBottomButtons;

    private UtilityKotlin.MinAmountResult minAmountResult = null;


    private void insertApiData(String url, String req, String res, String dateTime,String endPoint) {
        final ApiDataModel api = new ApiDataModel(
                url,
                req,
                res,
                AppConstants.SWITCH,
                dateTime,
                endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
/*        if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.Switch),
                    true, false, false, false, false, false, false);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_additional_switch, container, false);
        db = ApiDataBase.getInstance(mActivity.getApplicationContext());

        setUpToolBar();
        mActivity.setMainVisibility(this, null);

        mSpArn = view.findViewById(R.id.spArn);
        mLlArn = view.findViewById(R.id.llArn);
        mLlArn.setVisibility(View.GONE);

        TextView user_name = view.findViewById(R.id.user_name);
        mTvcardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);
        tvShortTerm = view.findViewById(R.id.tvShortTerm);
        tvLongTerm = view.findViewById(R.id.tvLongTerm);

        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        mEtAmount = view.findViewById(R.id.amount);
        tvWordAmount = view.findViewById(R.id.tvWordAmount);
        tvLabelMinAmount = view.findViewById(R.id.tvLabelMinAmount);
        mtvShortTermUnit = view.findViewById(R.id.tvUnit);
        mTvShortTermAmount = view.findViewById(R.id.tvAmount);
        mtvLongTermUnit = view.findViewById(R.id.tvUnit2);
        mTvLongTermAmount = view.findViewById(R.id.tvAmount2);

        mGroupSchemeSpinner = view.findViewById(R.id.scheme);
        mRadioGroup = view.findViewById(R.id.radioGroup);
        mTvAmount = view.findViewById(R.id.tvAmountLavel);
        mTvErrorMessage = view.findViewById(R.id.tvErrorMessage);
        mLinerHalfPart = view.findViewById(R.id.linerHalfDesign);
        mLinerRedeem = view.findViewById(R.id.linerRedeem);

        mRgTargetSchemeType = view.findViewById(R.id.radioGroup2);
        mTvLavelSchemeType = view.findViewById(R.id.tvLavelSchemeType);
        mRgTargetSchemeType.setVisibility(View.GONE);
        mTvLavelSchemeType.setVisibility(View.GONE);

        mSchemeList = new ArrayList<>();
        mGroupSchemeList = new ArrayList<>();

        llSourceScheme = view.findViewById(R.id.llSourceScheme);
        mRgSourceSchemeType = view.findViewById(R.id.rgSourceSchemeType);
        rbGrowth = view.findViewById(R.id.rbGrowth);
        llSourceSchemeDivFreq = view.findViewById(R.id.llSourceSchemeDivFreq);
        spSourceDividendFrequency = view.findViewById(R.id.spSourceDividendFrequency);
        mTvCart = view.findViewById(R.id.tvCart);
        llBottomButtons = view.findViewById(R.id.llBottomButtons);
        mTvTransactNow = view.findViewById(R.id.tvTransactNow);
        llTargetDividendFreq = view.findViewById(R.id.llTargetDividendFreq);
        spTargetDividendFrequency = view.findViewById(R.id.spTargetDividendFrequency);

        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mOldJsonObject = new JSONObject(bundle.getString("oldObject"));
                mSourceSchemeGroupId = mOldJsonObject.optString("schemeGroupId");
                tranJsonObject = new JSONObject(bundle.getString("tranJsonObject"));
                mFundName = mOldJsonObject.optString("fundName");

                if (bundle.containsKey("nse2")){
                    isNse2 = bundle.getBoolean("nse2");
                    exchange = bundle.getString("exchange");
                }else {
                    isNse2 = false;
                }
                if (bundle.containsKey("sIinProfileObject")){
                    profileObject = new JSONObject(bundle.getString("sIinProfileObject"));

                    if (isNse2) {
                        mBseId = profileObject.optString("nseInvestid");
                        nseUccCode = getUccCode(isNse2,profileObject,mOldJsonObject);
                    } else {
                        mBseId = profileObject.optString("bseid");
                        uccNumber =getUccCode(isNse2,profileObject,mOldJsonObject);
                    }

                }
                user_name.setText(mOldJsonObject.optString("applicant_name"));
                mTvcardview_top_name_color.setText(mOldJsonObject.optString("schemeName"));



                mTransectionType = bundle.getString("transactionType");
                if (mOldJsonObject.has("purchaseValue")) {
                    purchase_cost.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optString("purchaseValue"))));

                } else{
                    purchase_cost.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optJSONObject("summary").optString("purchaseValue"))));

                }  if (mOldJsonObject.has("currentValue")) {
                    market_value.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optString("currentValue"))));

                } else{
                    market_value.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optJSONObject("summary").optString("currentValue"))));

                }
                exchange = Utils.getSelectedExchange(mSession);
                if (mSession.getLoginType().equals("broker")) {
                    getArnList();
                }

                getBalance(mOldJsonObject.optString("folioid"));
                mSchemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
                if (Utils.getSelectedExchange(mSession).equals("1")) {
                    setVisibilityOfSourceSchemeType(mSchemeId);
                }
                getSchemesGroups(mSchemeId);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }
        }

       /* mEtAmount.addTextChangedListener(new TextWatcher() {
            int beforeTextChangedLength;

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                beforeTextChangedLength = charSequence.length();
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (mSwitchType.equals("amount")) {
                    String typingAmount = editable.toString();
                    if (!typingAmount.equals("")) {
                        double converAmount = Float.parseFloat(typingAmount);
                        if (mMinAmount > converAmount) {
                            mEtAmount.setError("Minimum Amount will be " + getString(R.string.rs) + mMinAmount);
                            mEtAmount.requestFocus();
                        } else if (converAmount > mMaxAmount) {
                            mEtAmount.setError("Amount will be less than " + getString(R.string.rs) + mMaxAmount);
                            mEtAmount.requestFocus();
                        }
                    }

                }
            }
        });*/

        mRgTargetSchemeType.setOnCheckedChangeListener((group, checkedId) -> {
            if(!isSchemeTypeCleared) {
                if (checkedId == R.id.radioSchemeType1) {
                        mSchemeType = "G";
                        getTargetSchemeDetails();
}
else if (checkedId == R.id.radioSchemeType2) {
                        mSchemeType = "DP";
                        getTargetSchemeDetails();
}
else if (checkedId == R.id.radioSchemeType3) {
                        mSchemeType = "DR";
                        getTargetSchemeDetails();
}
            }
            else{
                isSchemeTypeCleared = false;
            }
        });

        llTargetDividendFreq.setVisibility(View.GONE);
        mSwitchType = "amount";


        mRgSourceSchemeType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbGrowth) {
                    sourceSchemeType = "G";
                    llSourceSchemeDivFreq.setVisibility(View.GONE);
}
else if (checkedId == R.id.rbDividendPayout) {
                    sourceSchemeType = "DP";
                    llSourceSchemeDivFreq.setVisibility(View.VISIBLE);
}
else if (checkedId == R.id.rbDividendReinvest) {
                    sourceSchemeType = "DR";
                    llSourceSchemeDivFreq.setVisibility(View.VISIBLE);
}
            getDividendFrequency(sourceSchemeType);
        });

        RadioButton radio1 = mRadioGroup.findViewById(R.id.radio1);
        RadioButton radio2 = mRadioGroup.findViewById(R.id.radio2);

        if(exchange.equals(AppConstants.MFU_APP))
            mTvTransactNow.setText(getString(R.string.TransactNow));
        else
            mTvTransactNow.setText(getString(R.string.place_order));
        handleAddToCartVisibility();

        if ((exchange.equals("2") || exchange.equals("4")) && (mOldJsonObject.optString("dematAccount").equals("Y"))) {
            radio1.setVisibility(View.GONE);
            radio2.setChecked(true);
            mLinerRedeem.setVisibility(View.VISIBLE);
            mEtAmount.setHint(getString(R.string.enter_unit));
            mTvAmount.setText(getString(R.string.unit));
            tvWordAmount.setVisibility(View.GONE);
            mSwitchType = "unit";
        }else{
            radio1.setVisibility(View.VISIBLE);
        }

        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio1) {
                        mLinerRedeem.setVisibility(View.VISIBLE);
                        mEtAmount.setHint("Enter Amount");
                        mTvAmount.setText(getString(R.string.amount));
                        tvWordAmount.setVisibility(View.VISIBLE);
                        mSwitchType = "amount";
}
else if (checkedId == R.id.radio2) {
                        mLinerRedeem.setVisibility(View.VISIBLE);
                        mEtAmount.setHint("Enter Unit");
                        mTvAmount.setText(getString(R.string.unit));
                        tvWordAmount.setVisibility(View.GONE);
                        mSwitchType = "unit";
}
else if (checkedId == R.id.radio3) {
                        mLinerRedeem.setVisibility(View.GONE);
                        mSwitchType = "all";
                        Utils.hideKeyboard(requireActivity());
}
                setMinAmount();
            }
        });


        view.findViewById(R.id.edit).setOnClickListener(this);
        mTvTransactNow.setOnClickListener(this);
        mTvCart.setOnClickListener(this);

        mLinerHalfPart.setVisibility(View.GONE);

        mEtAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String word ="";
                if (!TextUtils.isEmpty(charSequence)){
                    try {
                        if (charSequence.length() !=0){
                            word = CurrencyTextToWord.convertToIndianCurrency(requireContext(),charSequence.toString().trim());
                        }else {
                            word =UtilityKotlin.firstLetterCapitalOfSentence("");
                        }
                    }catch (Exception e){
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                }else {
                    word = UtilityKotlin.firstLetterCapitalOfSentence("");
                }
                tvWordAmount.setText(word);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        return view;
    }

    private void handleAddToCartVisibility() {
        if (exchange.equalsIgnoreCase(AppConstants.NSE_APP)) {
            mTvCart.setVisibility(View.GONE);
        } else if (exchange.equalsIgnoreCase(AppConstants.BSE_APP)) {
            boolean isAddToCartBseEnabled = checkFeaturePermissionsOnOff(mSession, "feature1043", Permissions.ADD);
            if(mSession.getShowBseAuthPopup() && isAddToCartBseEnabled)
                mTvCart.setVisibility(View.VISIBLE);

        }else if (exchange.equalsIgnoreCase(AppConstants.NEW_NSE_APP)) {
            boolean isAddToCartNseInvestEnabled = checkFeaturePermissionsOnOff(mSession, "feature1053", Permissions.ADD);
            if(isNse2 && isAddToCartNseInvestEnabled)
                mTvCart.setVisibility(View.VISIBLE);
        }  else if (exchange.equalsIgnoreCase(AppConstants.MFU_APP)) {
            boolean isAddToCartMfuEnabled = checkFeaturePermissionsOnOff(mSession, "feature1048", Permissions.ADD);
            if (isAddToCartMfuEnabled)
                mTvCart.setVisibility(View.VISIBLE);
            else
                mTvCart.setVisibility(View.GONE);
        }
    }

    private void setVisibilityOfSourceSchemeType(String schemeId) {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_INVESTMENT_TYPE +
                "subType=" + "SWO" +
                "&schid=" + schemeId +
                "&investorUid=" + Utils.getSelectedUid(mSession) +
                "&selectedUser=" + Utils.getSelectedUserObject(mSession);

        url = setRefreshKeyInExistingApi(url, mSession);

        ApiClient client = new ApiClient(requireContext(), mSession);
        client.makeGetRequest(url,
                isLoading-> null, response->{
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if(jsonObject.optInt("status") == 0){
                            JSONObject resultObject = jsonObject.optJSONObject("result");
                            if(resultObject != null) {
                                JSONObject data = resultObject.optJSONObject("data");
                                if(data != null)
                                {
                                    JSONArray allowedInvestmentTypes = data.optJSONArray("allowedInvestmentTypes");
                                    if(allowedInvestmentTypes != null) {

                                        if (allowedInvestmentTypes.toString().contains("D") && allowedInvestmentTypes.toString().contains("G")) { //G,D recieved then show all three
                                            llSourceScheme.setVisibility(View.VISIBLE);
                                            sourceSchemeType = "G";
                                            rbGrowth.setVisibility(View.VISIBLE);
                                            rbGrowth.setSelected(true);
                                        }
                                        else if(allowedInvestmentTypes.toString().contains("D") ) { // if only d recieved then show only dividend payout/reinvest
                                            llSourceScheme.setVisibility(View.VISIBLE);
                                            rbGrowth.setVisibility(View.GONE);
                                        }
                                        else if(allowedInvestmentTypes.toString().contains("G") ) { //if only g recieved then hide source schemefull layout
                                            llSourceScheme.setVisibility(View.GONE);
                                        }
                                        getDividendFrequency(sourceSchemeType);
                                    }
                                }
                            }
                        }
                    }catch (Exception e){
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }
                    return null;
                }, volleyError -> {
//                    if (mBar != null)
//                        mBar.dismiss();
                    if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                        VolleyError error = new VolleyError(new String(volleyError.networkResponse.data));
                        try {
                            JSONObject jsonObject2 = new JSONObject(error.getMessage());
                            Toast.makeText(requireContext(), jsonObject2.optString("error"), Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    } else if (volleyError instanceof NoConnectionError) {
                        Toast.makeText(requireContext(), requireContext().getResources().getString(R.string.no_internet), Toast.LENGTH_LONG).show();
                    } else {
                        String error = volleyError.getLocalizedMessage();
                    }

                    return null;
                },status->{
                    if (status == 401) {
                        mAppplication.showCommonDailog(requireContext(), requireContext().getString(R.string.txt_session_expired), requireContext().getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }
                    return null;
                });
    }

    private void getDividendFrequency(String sourceSchemeType) {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TARGET_SCHEME +
                "schemeGroupId=" + mSourceSchemeGroupId +
                "&investmentType=" + sourceSchemeType +
                "&subType=" + "SWO" +
                "&investorUid=" + Utils.getSelectedUid(mSession) +
                "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        url = setRefreshKeyInExistingApi(url, mSession);
        try {
            url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        new ApiClient(requireContext(), mSession).makeGetRequest(
                url,
                isLoading->{
                    if (isLoading){
                        ProgressBarCommon.showDialog(requireContext());
                    }else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                },
                response -> {
                    ProgressBarCommon.dismissDialog();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("status") == 0) {
                            JSONObject result = jsonObject.optJSONObject("result");
                            if (result != null) {
                                JSONArray dataJsonArray = result.optJSONArray("data");
                                schidList = new ArrayList<>();
                                sourceDividendFreqList = new ArrayList<>();
                                if (dataJsonArray != null) {
                                    for(int i = 0; i < dataJsonArray.length(); i++){
                                        JSONObject schemeObj = dataJsonArray.getJSONObject(i);
                                        String schid = schemeObj.optString("schid");
                                        String divFreq = schemeObj.optString("dividendFrequency");
                                        schidList.add(schid);
                                        sourceDividendFreqList.add(divFreq);
                                    }
                                    setSourceDividendFrequency(sourceDividendFreqList);
                                }
                            }
                        } else {
                            Toast.makeText(requireContext(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }
                    return null;
                },
                error -> {
                    ProgressBarCommon.dismissDialog();
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        VolleyError volleyError = new VolleyError(new String(error.networkResponse.data));
                        try {
                            JSONObject jsonObject = volleyError.getMessage() != null ? new JSONObject(volleyError.getMessage()) : null;
                            Toast.makeText(
                                    requireActivity(),
                                    jsonObject != null ? jsonObject.optString("error") : null,
                                    Toast.LENGTH_LONG
                            ).show();
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    } else if (error instanceof NoConnectionError) {
                        Toast.makeText(
                                requireActivity(),
                                getResources().getString(R.string.no_internet),
                                Toast.LENGTH_LONG
                        ).show();
                    } else {
                        String errorMessage = error.getLocalizedMessage();
                        if (errorMessage != null) {
                            Toast.makeText(requireActivity(), errorMessage, Toast.LENGTH_SHORT).show();
                        }
                    }
                    return null;
                },
                statusCode -> {
                    ProgressBarCommon.dismissDialog();
                    if (statusCode == 401) {
                        mAppplication.showCommonDailog(
                                requireContext(),
                                getResources().getString(R.string.txt_session_expired),
                                getResources().getString(R.string.txt_please_login_again_for_continue),
                                "sessionExpired"
                        );
                    }
                    return null;
                }
        );
    }

    private void setSourceDividendFrequency(ArrayList<String> sourceSchemeDivFreq) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), R.layout.spinner_bg, sourceSchemeDivFreq);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown);
        spSourceDividendFrequency.setAdapter(adapter);
        spSourceDividendFrequency.setSelection(0);
        spSourceDividendFrequency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mSchemeId = schidList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.edit) {
                if (mSchemeList.size() > 0) {
                    showSchemesDailog();
                } else {
                    getSchemes(mOldJsonObject.optString("fundid"));
                }
}
else if (v.getId() == R.id.tvTransactNow) {
                if (isValidInput()) {

                    switch (exchange) {
                        case AppConstants.NSE_APP:
                            placeSwitchNSE(false);
                            break;
                        case AppConstants.BSE_APP:
                        case AppConstants.NEW_NSE_APP:
                            placeSwitchBse(true, "", false, "",isNse2);
                            break;
                        case AppConstants.MFU_APP:
                            placeSwitchMfu(false);
                            break;

                    }
                }
}
else if (v.getId() == R.id.tvCart) {
                if (mTvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {
                    if (isValidInput()) {
                        if(exchange.equalsIgnoreCase(AppConstants.MFU_APP))
                           insertTxnInMfuCart();
                        else
                            insertTxnInNseOrBseCart();
                    }
                }
                else{
                    Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                    intent.putExtra("url", constructCartUrl(mSession));
                    intent.putExtra("isPopup", true);
                    intent.putExtra("comeFrom", "client");
                    startActivity(intent);
                    new Handler(Looper.getMainLooper()).postDelayed(this::addToCartBtnClicked, 1500);

                }
}
    }

    private void insertTxnInMfuCart() {
        ProgressBarCommon.showDialog(requireContext());

        try {
            JSONObject objectMain = new JSONObject();

            objectMain.put("txnType", "SWO");  // static
            objectMain.put("schemeType", mSchemeType);
            switch (mSwitchType) {
                case "amount":
                    objectMain.put("switchType", "amount");
                    break;
                case "unit":
                    objectMain.put("switchType", "units");
                    break;
                case "all":
                    objectMain.put("switchType", "allUnits");
                    break;
            }
            if(!mSwitchType.equalsIgnoreCase("all"))
                objectMain.put("redeemValue", mEtAmount.getText().toString().trim());
            objectMain.put("type", "sell");  // static
            objectMain.put("subType", "SWO");  // static
            objectMain.put("mfuid",getMfuId(profileObject,mOldJsonObject));
            objectMain.put("can", getCanNumber(profileObject,mOldJsonObject));
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));


            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    objectMain.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        objectMain.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }

            JSONObject itemObject = getItemObjectMfu();
            objectMain.put("item", itemObject);

            String url =  "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.INSERT_MFU_CART_ITEM;
            new ApiClient(requireContext(), mSession).makeJsonPostRequest(
                    url,
                    objectMain,
                    isLoading -> {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireContext());
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                        return null;
                    },
                    response -> {
                        try {
                            if (response.optInt("status") == 0) {
                                addToCartBtnClicked();
                                Toast.makeText(requireContext(),getString(R.string.added_successfully),Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(requireContext(),response.optString("message"),Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception ignored) { }
                        return null;
                    },
                    error -> {
                        UtilityKotlin.parseVolleyError(error, mSession, requireContext(), "");
                        return null;
                    },
                    statusCode -> {
                        if (statusCode == 401) {
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(
                                    requireContext(),
                                    getString(R.string.txt_session_expired),
                                    getString(R.string.txt_please_login_again_for_continue),
                                    "sessionExpired"
                            );
                        }
                        return null;
                    }
            );
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private JSONObject getItemObjectMfu() {
        JSONObject itemObject = new JSONObject();
        try {
            itemObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            itemObject.put("schid", mSchemeId);
            itemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            itemObject.put("folioid", mOldJsonObject.optString("folioid"));
            itemObject.put("investmentType", mSchemeType);
            itemObject.put("targetSchemeName", mTargetSchemeName);
            itemObject.put("targetSchemeid", mTargetSchemeId);
            itemObject.put("divFrequency", String.valueOf(spTargetDividendFrequency.getSelectedItemPosition()));
            switch (mSwitchType) {
                case "amount":
                    itemObject.put("redeemType", "amount");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "unit":
                    itemObject.put("redeemType", "units");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "all":
                    itemObject.put("redeemType", "allUnits");
                    itemObject.put("redeemValue", "");
                    break;
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return itemObject;
    }

    private void insertTxnInNseOrBseCart() {
        ProgressBarCommon.showDialog(mActivity);

        JSONObject objectMain = new JSONObject();
        try {
            objectMain.put("type", "sell");
            if(isNse2 )
                objectMain.put("exchange", "4");
            else
                objectMain.put("exchange", "2");
            objectMain.put("subType", "SWO");
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));

            JSONObject itemObject = getNseOrBseItemObject();
            objectMain.put("item", itemObject);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.INSERT_NSE_BSE_CART_ITEM;

        new ApiClient(mActivity, mSession).makeJsonPostRequest(
                url,
                objectMain,
                it -> {
                    if (it) {
                        ProgressBarCommon.showDialog(mActivity);
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                },
                response -> {
                    try {
                        if (response.optInt("status") == 0) {
                            addToCartBtnClicked();
                            Toast.makeText(mActivity,getString(R.string.added_successfully), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mActivity,response.optString("message"),Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception ignored) {
                    }
                    return null;
                },
                error -> {
                    UtilityKotlin.parseVolleyError(error, mSession, mActivity, "");
                    return null;
                },
                code -> {
                    if (code == 401) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(
                                mActivity,
                                getString(R.string.txt_session_expired),
                                getString(R.string.txt_please_login_again_for_continue),
                                "sessionExpired"
                        );
                    }
                    return null;
                }
        );
    }
    private JSONObject getNseOrBseItemObject() {
        JSONObject itemObject = new JSONObject();

        try {
            // Folio
            itemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            itemObject.put("folioid", mOldJsonObject.optString("folioid"));
            itemObject.put("txnType", "ADDITIONAL");
            if(isNse2) {
                itemObject.put("nseInvestid", mBseId);
                itemObject.put("nseUccCode", nseUccCode);
            }
            else{
                itemObject.put("uccNumber", uccNumber);
                itemObject.put("bseid", mBseId);
            }
            // ARN handling
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    itemObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        itemObject.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        itemObject.put("arnid", folioObject.optString("arnid"));
                    }
                }
            }else {
                itemObject.put("arnid", "");
            }

            itemObject.put("investmentType", mSchemeType);

            itemObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            itemObject.put("schid", mSchemeId);

            itemObject.put("toSchemeName", mTargetSchemeName);
            itemObject.put("toSchemeid", mTargetSchemeId);
            itemObject.put("divFrequency", String.valueOf(spTargetDividendFrequency.getSelectedItemPosition()));
            switch (mSwitchType) {
                case "amount":
                    itemObject.put("redeemType", "amount");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "unit":
                    itemObject.put("redeemType", "units");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "all":
                    itemObject.put("redeemType", "allUnits");
                    itemObject.put("redeemValue", "");
                    break;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return itemObject;
    }

    private void addToCartBtnClicked() {

        String newText;
        if (mTvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {
            newText = getString(R.string.go_to_cart);
            mTvTransactNow.setVisibility(View.GONE);
        } else {
            newText = getString(R.string.add_to_cart);
            mTvTransactNow.setVisibility(View.VISIBLE);
        }

        mTvCart.setText(newText);

    }

    private void showLoading(boolean isLoading){
        if (isLoading){
            if (!ProgressBarCommon.isDialogVisible()){
                ProgressBarCommon.showDialog(requireActivity());
            }
        }else {
            ProgressBarCommon.dismissDialog();
        }
    }


    private boolean isValidInput(){
        if(llSourceScheme.getVisibility() == View.VISIBLE && mRgSourceSchemeType.getCheckedRadioButtonId() == -1) {
            Toast.makeText(mActivity, R.string.txt_please_select_source_scheme_type, Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (mGroupSchemeSpinner.getSelectedItemPosition() == 0) {
            Toast.makeText(mActivity, R.string.txt_please_select_target_scheme, Toast.LENGTH_SHORT).show();
            return false;
        }
        else if(mTvErrorMessage.getVisibility() == View.VISIBLE) {
            showToast(requireContext(),getString(R.string.please_select_another_target_scheme));
            return false;
        }
        else if(mRgTargetSchemeType.getCheckedRadioButtonId() == -1 ){
            showToast(requireContext(), getString(R.string.new_purchase_text_select_scheme_type));
            return false;
        }
        else if (mSwitchType.equals("amount") && mEtAmount.getText().toString().isEmpty()) {
            Toast.makeText(mActivity, getString(R.string.error_empty_amount), Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (!Utils.getSelectedExchange(mSession).equals(AppConstants.MFU_APP) && mSwitchType.equals("amount") && minAmountResult != null && minAmountResult.getVisibility() == UtilityKotlin.MinAmountVisibility.SHOW && Double.parseDouble(mEtAmount.getText().toString().trim()) < minAmountResult.getMinAmount()) {
            Toast.makeText(mActivity, getString(R.string.minimum_amount_should_be) + " " + formatRupees(this,minAmountResult.getMinAmount()), Toast.LENGTH_SHORT).show();
            return false;
        }
        else if (mSwitchType.equals("unit") && mEtAmount.getText().toString().isEmpty()) {
            Toast.makeText(mActivity, R.string.txt_please_enter_unit, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
    private void placeSwitchMfu(boolean isIgnoreDuplicate) {
        if (!isAdded())
            return;
        InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isAcceptingText()) {
            imm.hideSoftInputFromWindow(mActivity.getCurrentFocus().getWindowToken(), 0);
        }

        showLoading(true);
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.PLACE_ORDER_MFU;
        JSONObject objectMain = new JSONObject();

        try {

            JSONObject paymentObject = new JSONObject();
            paymentObject.put("paymentMode", "transfer");
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("uid", Utils.getSelectedUid(mSession));
            objectMain.put("schemeType", mSchemeType);
            objectMain.put("mfuid", getMfuId(profileObject,mOldJsonObject));
            objectMain.put("can", getCanNumber(profileObject,mOldJsonObject));
            objectMain.put("source", "folio");
            objectMain.put("subType", "SWO");  // static
            objectMain.put("type", "sell");  // static
            objectMain.put("paymentMode", "transfer"); //// static
            objectMain.put("paymentAdded", "true"); // static

            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    objectMain.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        objectMain.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }

            JSONObject switchObject = new JSONObject();
            switchObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            switchObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            switchObject.put("folioid", mOldJsonObject.optString("folioid"));
            String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
            switchObject.put("schid", schemeId);
            switchObject.put("targetSchemeName", mTargetSchemeName);
            switchObject.put("targetSchemeid", mTargetSchemeId);
            switchObject.put("investmentType", mSchemeType);
            switchObject.put("divFrequency", String.valueOf(spTargetDividendFrequency.getSelectedItemPosition()));
            switch (mSwitchType) {
                case "amount":
                    switchObject.put("redeemType", "amount");
                    switchObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "unit":
                    switchObject.put("redeemType", "units");
                    switchObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "all":
                    switchObject.put("redeemType", "allUnits");
                    switchObject.put("redeemValue", "");
                    break;
            }

            objectMain.put("item", switchObject);
            objectMain.put("paymentDetails", paymentObject);

            if (isIgnoreDuplicate)
                objectMain.put("ignoreDuplicate", "N");

        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(url,objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.PLACE_ORDER_MFU);


                try {
                    AppApplication appApplication = (AppApplication) mActivity.getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        mLinerHalfPart.setVisibility(View.GONE);
                        isSchemeTypeCleared = true;
                        mSchemeType = "";
                        mRgTargetSchemeType.clearCheck();
                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        Bundle bundle = new Bundle();
                        bundle.putString("resultObject", resultObject.toString());
                        mActivity.displayViewOther(38, bundle);

                    } else {
                        String message = jsonObject.optString("message");
                        if (message.contains("order already exists")) {
                            orderExistsDailog("mfu");
                        } else {
                            appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                        }
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
                finally {
                    showLoading(false);
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        showLoading(false);
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void placeSwitchNSE(boolean isIgnoreDuplicate) {
        if (!isAdded())
            return;
        Utils.hideKeyBoardFromAnyWhere(requireActivity());


        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.PLACE_NSE_ORDER;
        JSONObject objectMain = new JSONObject();

        try {

            JSONObject paymentObject = new JSONObject();
            paymentObject.put("paymentMode", "transfer");

            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("uid", Utils.getSelectedUid(mSession));
            objectMain.put("schemeType", mSchemeType);
            objectMain.put("iinNo", mOldJsonObject.optString("iinNo"));
            objectMain.put("subType", "SWO");  // static
            objectMain.put("type", "sell");  // static
            objectMain.put("paymentMode", "transfer"); //// static
            objectMain.put("paymentAdded", "true"); // static



            JSONObject switchObject = new JSONObject();
            switchObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            switchObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            switchObject.put("folioid", mOldJsonObject.optString("folioid"));
            switchObject.put("IIN", mOldJsonObject.optString("iinNo"));
            switchObject.put("schid", mSchemeId);
            switchObject.put("targetSchemeName", mTargetSchemeName);
            switchObject.put("targetSchemeid", mTargetSchemeId);
            switchObject.put("investmentType", mSchemeType);
            switchObject.put("sourceInvestmentType", sourceSchemeType);
            if (mSwitchType.equals("amount")) {
                switchObject.put("redeemType", "amount");
                switchObject.put("redeemValue", mEtAmount.getText().toString().trim());
            } else if (mSwitchType.equals("unit")) {
                switchObject.put("redeemType", "units");
                switchObject.put("redeemValue", mEtAmount.getText().toString().trim());
            } else if (mSwitchType.equals("all")) {
                switchObject.put("redeemType", "allUnits");
                switchObject.put("redeemValue", "");
            }
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    switchObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        switchObject.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        switchObject.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }

            objectMain.put("item", switchObject);
            objectMain.put("paymentDetails", paymentObject);

            if (isIgnoreDuplicate)
                objectMain.put("ignoreDuplicate", "N");

        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(url,objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.PLACE_NSE_ORDER);

                if (mBar != null)
                    mBar.dismiss();
                try {
                    AppApplication appApplication = (AppApplication) mActivity.getApplication();
                    if (jsonObject.optInt("status") == 0) {

                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        Bundle bundle = new Bundle();
                        bundle.putString("resultObject", resultObject.toString());
                        mActivity.displayViewOther(38, bundle);

                    }else if (jsonObject.optInt("status") == 3) {
                        orderExistsDailog("nse");
                    } else {
                        String message = jsonObject.optString("message");
                        appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void orderExistsDailog(String exchangeType) {
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    switch (exchangeType){
                        case "nse":
                            placeSwitchNSE(true);
                            break;
                        case "bse":
                            placeSwitchBse(
                                    true,
                                    "",
                                    false,
                                    "",isNse2

                            );
                            break;
                        case "mfu":
                            placeSwitchMfu(true);
                            break;
                    }
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(getActivity(), getString(R.string.alert_dialog_order_exist_header_txt),
                getString(R.string.alert_dialog_order_exist_message_txt),
                getString(R.string.alert_dialog__order_exist_button1),
                getString(R.string.alert_dialog__order_exist_button2),
                true, true);
    }


    private void placeSwitchBse(
            boolean isIgnoreDuplicate,
            String otp,
            boolean isValidated,
            String provisonalOrderId,
            boolean isNseSwitch
    ) {
        Utils.hideKeyboard(mActivity);

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        String url ="";
        if (isNseSwitch){
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.PLACE_SWITCH_ORDER_NSE2;
        }else {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.PLACE_Switch_ORDER;
        }
        JSONObject objectMain = new JSONObject();

        try {

            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));

            if (!isNseSwitch && isValidated){
                objectMain.put("provisionalOrderid",provisonalOrderId);
                objectMain.put("otp", otp);
            }else{
                // common for normal bse transaction flow and Nse2 transaction common payload
                // isNseSwitch==true and BSE non- validated transaction flow
                objectMain.put("folioNo", mOldJsonObject.optString("folioNo"));

                if (mSession.getLoginType().equals("broker")) {
                    if (mJsonARNList.size() == 1) {
                        JSONObject folioObject = mJsonARNList.get(0);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    } else {
                        int position = mSpArn.getSelectedItemPosition();
                        if (position == 0)
                            objectMain.put("arnid", "");
                        else {
                            JSONObject folioObject = mJsonARNList.get(position - 1);
                            objectMain.put("arnid", folioObject.optString("arnid"));
                        }
                    }
                } else {
                     objectMain.put("arnid", "");
                }

                if (mSwitchType.equals("amount")) {
                    objectMain.put("amount", mEtAmount.getText().toString().trim());
                } else {
                    if (!isNseSwitch) objectMain.put("amount", "0");
                }

                if (mSwitchType.equals("unit")) {
                    objectMain.put("units", mEtAmount.getText().toString().trim());
                } else {
                    if (!isNseSwitch) objectMain.put("units", "0");
                }

                if (mSwitchType.equals("all")) {
                    objectMain.put("allUnits", "Y");
                } else {
                    objectMain.put("allUnits", "N");
                }

                if (isNseSwitch){
                    objectMain.put("nseInvestid", mBseId);
                    objectMain.put("nseUccCode", nseUccCode);
                    //fromSchid
                    //toSchid
                    String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
                    objectMain.put("fromSchemeId", schemeId);
                    objectMain.put("toSchemeId", mTargetSchemeId);
                }else {
                    // BSE -non trusted transaction
                    objectMain.put("uccNumber", uccNumber);
                    String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
                    objectMain.put("fromSchemeId", schemeId);
                    objectMain.put("toSchemeId", mTargetSchemeId);
                    objectMain.put("folioid", mOldJsonObject.optString("folioid"));
                }

                if (isIgnoreDuplicate)
                    objectMain.put("ignoreDuplicate", "N");
            }

        } catch (Exception e) {

        }
        String finalurl =url;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(finalurl,objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.PLACE_Switch_ORDER);

                if (mBar != null)
                    mBar.dismiss();
                try {
                    AppApplication appApplication = (AppApplication) mActivity.getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject mPlaceOderResponseObj = jsonObject.optJSONObject("result");

                        if (!isNseSwitch){
                            if (!mSession.getShowBseAuthPopup()){
                                mPlaceOderResponseObj.put("txnType", "switch");
                                mPlaceOderResponseObj.put("switchType", mSwitchType); //amount, unit,all
                                mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));

                                Bundle bundle = new Bundle();
                                bundle.putString("bseid", mBseId);
                                bundle.putString("type", "bseSwitch");
                                bundle.putString("payNowOptionType", "");
                                bundle.putString("amount", mEtAmount.getText().toString().trim());
                                mPlaceOderResponseObj.put("ClientCode", uccNumber);
                                bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                bundle.putString("fundName", mFundName);
                                Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                intent.putExtras(bundle);
                                startActivity(intent);
                            }else {
                                // new flow
                                String status = mPlaceOderResponseObj.optString("status");
                                if (mSession.getShowBseAuthPopup() && isValidated){
                                    if (popup.isVisible()){popup.dismiss();}
                                    mPlaceOderResponseObj.put("txnType", "switch");
                                    mPlaceOderResponseObj.put("switchType", mSwitchType); //amount, unit,all
                                    mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));

                                    Bundle bundle = new Bundle();
                                    bundle.putString("bseid", mBseId);
                                    bundle.putString("type", "bseSwitch");
                                    bundle.putString("payNowOptionType", "");
                                    bundle.putString("amount", mEtAmount.getText().toString().trim());
                                    mPlaceOderResponseObj.put("ClientCode", uccNumber);
                                    bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                    bundle.putBoolean("isOtpValidated", isValidated);
                                    bundle.putString("fundName", mFundName);
                                    Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                    intent.putExtras(bundle);
                                    startActivity(intent);

                                }else {
                                    showOTPAuth(
                                            true,
                                            mPlaceOderResponseObj.optString("provisionalOrderid")
                                    );
                                }

                            }
                        }else {
                            // NSE 2
                            mPlaceOderResponseObj.put("txnType", "switch");
                            mPlaceOderResponseObj.put("switchType", mSwitchType); //amount, unit,all
                            mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));

                            Bundle bundle = new Bundle();
                            bundle.putString("nseInvestid", mBseId);
                            bundle.putString("type", "nse2Switch");
                            bundle.putString("payNowOptionType", "");
                            bundle.putString("amount", mEtAmount.getText().toString().trim());
                            mPlaceOderResponseObj.put("ClientCode", uccNumber);
                            bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                            bundle.putString("fundName", mFundName);
                            Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);

                        }

                    } else if (jsonObject.optInt("status") == 3){
                        String mTranxnExchange = "bse";
                        if (isNseSwitch){
                            mTranxnExchange="Nse";
                        }else {
                            mTranxnExchange="bse";
                        }
                        orderExistsDailog(mTranxnExchange);
                    } else {
                        String message = jsonObject.optString("message");
                        if (message.contains("order already exists")) {
                            String mTranxnExchange = "bse";
                            if (isNseSwitch){
                                mTranxnExchange="Nse";
                            }else {
                                mTranxnExchange="bse";
                            }
                            orderExistsDailog(mTranxnExchange);
                        } else {
                            appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                        }
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }



    private void showOTPAuth(
            boolean mIsIgnoreDuplicate,
            String mProvisionalOrderid
    ){
        popup = new FullScreenBsePopUpDialog();
        Bundle bundle = new Bundle();
        bundle.putString("profileData",profileObject.toString());
        bundle.putString("purchaseType","Switch");
        bundle.putString("funname",mFundName);
        bundle.putBoolean("ispurchase",false);
        bundle.putString("mProvisionalOrderid", mProvisionalOrderid);
        popup.setArguments(bundle);
        popup.onValidateButtonClick(new Function1<Bundle, Unit>() {
            @Override
            public Unit invoke(Bundle bundle) {
                // place order by otp
                try {
                    // place order by otp
                    String mOtp = bundle.getString("otp");
                    placeSwitchBse(
                            mIsIgnoreDuplicate,
                            mOtp,
                            true,
                            mProvisionalOrderid,
                            false
                    );

                } catch (Exception e) {}

                return null;
            }
        });
        popup.show(requireActivity().getSupportFragmentManager(),"FullScreenPopup");
    }


    private void getArnList() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        try {
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "investOnline");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ARN_LIST_NSE + "exchange="+exchange +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

          /*  https://spvithlani.investwell.app/webapi/client/getArns?
            // exchange=2&investorUid=67c025d3f470b86011712f7f974d669d
            // &selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/
            url = setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mBar.dismiss();

                        mJsonARNList = new ArrayList<>();
                        ArrayList<String> arnList = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    arnList.add(jsonObject1.optString("arnNo"));
                                    mJsonARNList.add(jsonObject1);
                                }
                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(getActivity(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {

                        } finally {
                            if (mJsonARNList.size() > 1) {
                                mLlArn.setVisibility(View.VISIBLE);
                                setArnList(arnList);
                            }else{
                                mLlArn.setVisibility(View.GONE);
                            }


                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }




    private void setArnList(List<String> list) {
        try {
            list.add(0, getString(R.string.select_arn_2));
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpArn.setAdapter(dataAdapter);


        } catch (Exception e) {

        }
    }



    private void getBalance(String folioId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_BALANCE + "folioid=" + folioId + "&considerObjOfFolio=true"
                    + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            //    https://spvithlani.investwell.app/webapi/client/investOnline/getBalanceUnits?
            //    folioid=ad7bb34a7e0f8dfc8e5b006193b14dec&considerObjOfFolio=true
            //    &investorUid=6158fa1dba4bf04015e91d2e2caf5bcc&selectedUser={"uid":
            //    "6158fa1dba4bf04015e91d2e2caf5bcc","levelNo":"98"}
            url = setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }


        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl,"GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_BALANCE);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");

                                JSONArray keyList = jsonObject1.optJSONArray("keys");
                                String keyName1 = keyList.optString(0);
                                String keyName2 = keyList.optString(1);
                                JSONObject objLongLockTerm = jsonObject1.optJSONObject(keyName1);
                                JSONObject objShortUnlockedTerm = jsonObject1.optJSONObject(keyName2);

                                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                                format.setMinimumFractionDigits(0);
                                format.setMaximumFractionDigits(2);

                                if (keyName1.equalsIgnoreCase("longTerm")){
                                    tvLongTerm.setText(getString(R.string.long_term));
                                    tvShortTerm.setText(getString(R.string.short_term));

                                    DecimalFormat df = new DecimalFormat("0.0000");
                                    String unitLongTerm = df.format(objLongLockTerm.optDouble("units"));
                                    String unitShortTerm = df.format(objShortUnlockedTerm.optDouble("units"));

                                    if (unitLongTerm.equals("0.0000")) {
                                        mtvLongTermUnit.setText("0");
                                    } else {
                                        mtvLongTermUnit.setText(unitLongTerm);
                                    }

                                    if (unitShortTerm.equals("0.0000")) {
                                        mtvShortTermUnit.setText("0");
                                    } else {
                                        mtvShortTermUnit.setText(unitShortTerm);
                                    }



                                    double longTermAmount = objLongLockTerm.optDouble("amount");
                                    String strCurrentAmount = format.format(longTermAmount);
                                    mTvLongTermAmount.setText(strCurrentAmount);

                                    double currentValue = objShortUnlockedTerm.optDouble("amount");
                                    String shortTermAmount = format.format(currentValue);
                                    mTvShortTermAmount.setText(shortTermAmount);

                                }else{
                                    tvShortTerm.setText(getString(R.string.Locked));
                                    tvLongTerm.setText(getString(R.string.Unlocked));

                                    DecimalFormat df = new DecimalFormat("0.0000");
                                    String locked = df.format(objLongLockTerm.optDouble("units"));
                                    String unlocked = df.format(objShortUnlockedTerm.optDouble("units"));


                                    if (locked.equals("0.0000")) {
                                        mtvShortTermUnit.setText("0");
                                    } else {
                                        mtvShortTermUnit.setText(locked);
                                    }


                                    if (unlocked.equals("0.0000")) {
                                        mtvLongTermUnit.setText("0");
                                    } else {
                                        mtvLongTermUnit.setText(unlocked);
                                    }

                                    double lock = objLongLockTerm.optDouble("amount");
                                    String strLockAmount = format.format(lock);
                                    mTvShortTermAmount.setText(strLockAmount);

                                    double unlockedValue = objShortUnlockedTerm.optDouble("amount");
                                    String unlockedAmount = format.format(unlockedValue);
                                    mTvLongTermAmount.setText(unlockedAmount);
                                }


                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getValidInvestmentType(String schemeGroupId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_INVESTMENT_TYPE + "schemeGroupId=" + schemeGroupId + "&subType=SWO"+ "&investorUid=" + Utils.getSelectedUid(mSession)+"&selectedUser="+Utils.getSelectedUserObject(mSession);
            if (exchange.equals("3")) {
                url = url + "&hasMfuCode=true";
            } else if (exchange.equals("2")) {
                url = url + "&hasBseCode=true"  ;
            }else if (exchange.equals("4")) {
                url = url + "&hasNseInvestCode=true"  ;
            }
        } catch (Exception e) {
            System.out.println();
        }
        mLinerHalfPart.setVisibility(View.GONE);
        url = setRefreshKeyInExistingApi(url, mSession);
        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl,"GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_INVESTMENT_TYPE);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONObject objData = jsonObject1.optJSONObject("data");
                                JSONArray jsonArray = objData.optJSONArray("allowedInvestmentTypes");

                                RadioButton radioButton = mRgTargetSchemeType.findViewById(R.id.radioSchemeType1);
                                RadioButton radioButton2 = mRgTargetSchemeType.findViewById(R.id.radioSchemeType2);
                                RadioButton radioButton3 = mRgTargetSchemeType.findViewById(R.id.radioSchemeType3);
                                radioButton.setVisibility(View.GONE);
                                radioButton2.setVisibility(View.GONE);
                                radioButton3.setVisibility(View.GONE);

                                if (jsonArray.length() > 0) {
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        String schemeType = jsonArray.getString(i);
                                        if (schemeType.contains("D")) {
                                            radioButton.setVisibility(View.VISIBLE);
                                            radioButton2.setVisibility(View.VISIBLE);
                                            radioButton3.setVisibility(View.VISIBLE);
                                        }
                                        if (schemeType.contains("G")) {
                                            radioButton.setVisibility(View.VISIBLE);
                                        }

                                        if (schemeType.contains("DP")) {
                                            radioButton2.setVisibility(View.VISIBLE);
                                        }

                                        if (schemeType.contains("DR")) {
                                            radioButton3.setVisibility(View.VISIBLE);
                                        }


                                    }
                                    mTvErrorMessage.setVisibility(View.GONE);
                                    mRgTargetSchemeType.setVisibility(View.VISIBLE);
                                    mTvLavelSchemeType.setVisibility(View.VISIBLE);

                                } else {
                                    mTvErrorMessage.setVisibility(View.VISIBLE);
                                    mTvErrorMessage.setText(getString(R.string.no_scheme_type_available));
                                    mLinerHalfPart.setVisibility(View.GONE);
                                    mRgTargetSchemeType.setVisibility(View.GONE);
                                    mTvLavelSchemeType.setVisibility(View.GONE);
                                }

                            } else if (jsonObject.optInt("status") == -1) {
                                mTvErrorMessage.setVisibility(View.VISIBLE);
                                mTvErrorMessage.setText(getString(R.string.not_available));
                                mLinerHalfPart.setVisibility(View.GONE);
                                mRgTargetSchemeType.setVisibility(View.GONE);
                                mTvLavelSchemeType.setVisibility(View.GONE);
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                volleyError -> {
                    if (mBar != null)
                        mBar.dismiss();
                    if (!isAdded())
                        return;
                    UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getTargetSchemeDetails() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {
            JSONObject jsonObject4 = new JSONObject();
            jsonObject4.put("componentName", "investOnline");

            String varableForBSeMfu = "";

            if (exchange.equals("2")) {
                varableForBSeMfu = "&hasBseCode=true";
            }else if (exchange.equals("3")) {
                varableForBSeMfu = "&hasMfuCode=true";
            }else if (exchange.equals("4")) {
                varableForBSeMfu ="&hasNseInvestCode=true"  ;
            }

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_TARGET_SCHEME +
                    "schemeGroupId=" + mTargetGroupSchemeId +
                    "&investmentType=" + mSchemeType +
                    "&subType=" + mTransectionType +
                    varableForBSeMfu+
                    "&investorUid=" + Utils.getSelectedUid(mSession) +
                    "&selectedUser="+Utils.getSelectedUserObject(mSession);

            /*     https://spvithlani.investwell.app/webapi/client/investOnline/
            getSchemes?schemeGroupId=868f8c9dfbc79758d467103bc9b0865c&investmentType
            =G&subType=SWO&componentForLoader={"componentName":"investOnline"}
            &investorUid=b9e953d8a361ffcc5018eb0728ba94ea&selectedUser=
            {"uid":"b9e953d8a361ffcc5018eb0728ba94ea","levelNo":"100"}*/
            url = setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
            mBar.dismiss();
        }
        mLinerHalfPart.setVisibility(View.GONE);
        llBottomButtons.setVisibility(View.GONE);

        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    insertApiData(finalUrl,"GET REQ CONTAINS URL IN REQ", response,
                            TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_TARGET_SCHEME);

                    if (mBar != null)
                        mBar.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("status") == 0) {
                            mLinerHalfPart.setVisibility(View.VISIBLE);
                            llBottomButtons.setVisibility(View.VISIBLE);


                            JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                            JSONArray dataJsonArray = jsonObject1.optJSONArray("data");
                            JSONObject jsonObject2 = dataJsonArray.optJSONObject(0);
                            mMinAmount = jsonObject2.optLong("minAmount");
                            mMaxAmount = jsonObject2.optLong("maxAmount");
                            String schemeId = Utils.getSchemeIdFromAll(jsonObject2);
                            mTargetSchemeId = schemeId;
                            mTargetSchemeName = jsonObject2.optString("name");

                            mTargetDivSchemeObjList = jsonArrayToArrayList(dataJsonArray);
                            ArrayList<String> targetDividendFreqList = new ArrayList<>();
                            for (int i = 0; i < mTargetDivSchemeObjList.size(); i++) {
                                JSONObject schemeObj = mTargetDivSchemeObjList.get(i);
                                String dividendFreqText = schemeObj.optString("dividendFrequency");
                                if (!dividendFreqText.isEmpty() && !dividendFreqText.equalsIgnoreCase("null")) {
                                    String capitalDividendFreqText = dividendFreqText.substring(0, 1).toUpperCase() + dividendFreqText.substring(1);
                                    targetDividendFreqList.add(capitalDividendFreqText);
                                }
                            }
                            if (!mSchemeType.equalsIgnoreCase("G")) {
                                setTargetDividendFrequency(targetDividendFreqList);
                            } else {
                                setMinAmount();
                                llTargetDividendFreq.setVisibility(View.GONE);
                            }

                            //user is allowed to addToCart again if schid is changed
                            if(mTvCart.getVisibility() == View.VISIBLE && mTvCart.getText().toString().equals(getString(R.string.go_to_cart)))
                                addToCartBtnClicked();

                        } else if (jsonObject.optInt("status") == -1) {
                            Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }
    private void setMinAmount() {

        if(Utils.getSelectedExchange(mSession).equals(AppConstants.MFU_APP) || !mSwitchType.equals("amount"))
        {
            tvLabelMinAmount.setVisibility(View.GONE);
            return;
        }
        int divFreqPos;
        if (mSchemeType.equalsIgnoreCase("G"))
            divFreqPos = 0;
        else
            divFreqPos = spTargetDividendFrequency.getSelectedItemPosition();

        minAmountResult = UtilityKotlin.getMinAmount(mTargetDivSchemeObjList, divFreqPos, "minAmount");
        if (minAmountResult.getVisibility() == UtilityKotlin.MinAmountVisibility.HIDE) {
            tvLabelMinAmount.setVisibility(View.GONE);
        } else {
            tvLabelMinAmount.setVisibility(View.VISIBLE);
            Double minAmount = minAmountResult.getMinAmount();

            if (minAmount != null) {
                tvLabelMinAmount.setText("Min : "+formatRupees(this,minAmount));
            }
        }
    }

    private void setGroupSchemes() {
        ArrayList<String> list = new ArrayList<>();
        list.add(getString(R.string.select_target_scheme));
        for (int i = 0; i < mGroupSchemeList.size(); i++) {
            JSONObject jsonObject = mGroupSchemeList.get(i);
            String data = jsonObject.optString("name");
            list.add(data);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        mGroupSchemeSpinner.setAdapter(dataAdapter);
        mGroupSchemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                int selectedPostion = mGroupSchemeSpinner.getSelectedItemPosition();
                if (selectedPostion != 0) {
                    JSONObject jsonObject = mGroupSchemeList.get(selectedPostion - 1);
                    mTargetGroupSchemeId = jsonObject.optString("schemeGroupId");
                    isSchemeTypeCleared = true;
                    mRgTargetSchemeType.clearCheck();
                    mSchemeType = "";
                    getValidInvestmentType(mTargetGroupSchemeId);
                } else {
                    mTargetGroupSchemeId = "";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    private void getSchemesGroups(String schemeId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {


            String varableForBSeMfu = "";
            if (exchange.equals("2")) {
                varableForBSeMfu = "&hasBseCode=true";
            }else if (exchange.equals("3")) {
                varableForBSeMfu = "&hasMfuCode=true";
            }else if (exchange.equals("4")) {
                varableForBSeMfu ="&hasNseInvestCode=true"  ;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.GET_SCHEME_GROUPS + "schid=" + schemeId + "&orderBy=name&orderByDesc=false"+varableForBSeMfu+"";
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        String finalUrl = url+"&selectedUser="+Utils.getSelectedUserObject(mSession);
        finalUrl = setRefreshKeyInExistingApi(finalUrl, mSession);
        String finalUrl1 = finalUrl;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, finalUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl1,"GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_SCHEME_GROUPS);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.getJSONArray("schemes");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    mGroupSchemeList.add(jsonArray.optJSONObject(i));
                                }
                                setGroupSchemes();
                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getSchemes(String fundId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {


            String varableForBSeMfu = "";
            switch (exchange) {
                case "1":
                    varableForBSeMfu = "&hasNseCode=true";
                    break;
                case "2":
                    varableForBSeMfu = "&hasBseCode=true";
                    break;
                case "3":
                    varableForBSeMfu = "&hasMfuCode=true";
                    break;
                case "4":
                    varableForBSeMfu = "&hasNseInvestCode=true";
                    break;
            }


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.GET_FUND_SCHEAMES + "fundid=" + fundId;

            url =url+varableForBSeMfu;

            /*if (exchange.equals("3")){
                url = url +varableForBSeMfu;
            }*/
        } catch (Exception e) {

        }


        String finalUrl = url+"&selectedUser="+Utils.getSelectedUserObject(mSession);
        finalUrl = setRefreshKeyInExistingApi(finalUrl, mSession);
        String finalUrl1 = finalUrl;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, finalUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl1,"GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_FUND_SCHEAMES);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.getJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    mSchemeList.add(jsonArray.optJSONObject(i));
                                }
                                showSchemesDailog();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void showSchemesDailog() {
        final boolean[] mIsFirstTime = {true};
        final Dialog dialog = new Dialog(mActivity);
        dialog.setContentView(R.layout.change_scheme);
        final Spinner mSchemeSpinner = dialog.findViewById(R.id.scheme);
        Button mSubmitBtn = dialog.findViewById(R.id.submit_btn);

        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < mSchemeList.size(); i++) {
            JSONObject jsonObject = mSchemeList.get(i);
            String data = jsonObject.optString("name");
            list.add(data);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        mSchemeSpinner.setAdapter(dataAdapter);

        mSchemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                int selectedPostion = mSchemeSpinner.getSelectedItemPosition();
                JSONObject jsonObject = mSchemeList.get(selectedPostion);
                mcardview_top_name_color = jsonObject.optString("name");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mcardview_top_name_color.equals(""))
                    mTvcardview_top_name_color.setText(mcardview_top_name_color);
                dialog.dismiss();
            }
        });


        dialog.findViewById(R.id.close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
    }

    private void setTargetDividendFrequency(List<String> list) {
        try {
            llTargetDividendFreq.setVisibility(View.VISIBLE);

            ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(
                    requireContext(),
                    R.layout.spinner_bg,
                    list
            );
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);

            spTargetDividendFrequency.setAdapter(dataAdapter);

            spTargetDividendFrequency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    JSONObject selectedSchemeObj = mTargetDivSchemeObjList.get(position);
                    mTargetSchemeName = selectedSchemeObj.optString("name");
                    mTargetSchemeId = selectedSchemeObj.optString("schid");
                    //user is allowed to addToCart again if schid is changed
                    if(mTvCart.getVisibility() == View.VISIBLE && mTvCart.getText().toString().equals(getString(R.string.go_to_cart)))
                        addToCartBtnClicked();

                    setMinAmount();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // No action
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}