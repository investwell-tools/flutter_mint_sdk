package investwell.client.fragments.my_sip;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.UtilityKotlin;

import investwell.utils.BaseFragment;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.DividendReportDetailAdapter;
import investwell.client.adapter.FragMySipAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.SortData;

public class FragMySipDetail extends Fragment implements View.OnClickListener, FragMySipAdapter.OnTxnClick {
    private AppSession mSession;
    public static String values;
    private ClientActivity mActivity;
    private RequestQueue requestQueue;
    private AppApplication mAppplication;
    private FragMySipAdapter mAdapter;
    private TextView mTvLoading;
    private ShimmerFrameLayout mShimmerViewContainer;
    private RecyclerView recyclerView;

    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;

    private boolean loading = false;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentPageNo = 0;
    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;
    private String mData;

    @Override
    public void onResume() {
        super.onResume();
     /*   if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);
            mBrokerActivity.setMainVisibility(this, null);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
            mMainActivity.setMainVisibility(this, null);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.txt_transaction_history),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_dividend_report_details, container, false);
        setUpToolBar();
        Bundle bundle = getArguments();
        if (bundle != null)
            mData = bundle.getString("data");

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);

        mTvLoading = view.findViewById(R.id.tvLoading);
        mTvLoading.setVisibility(View.GONE);

        recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setNestedScrollingEnabled(true);

        recyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new FragMySipAdapter(new ArrayList<JSONObject>(), getContext(),this);
        recyclerView.setAdapter(mAdapter);
        getMySip(mData);
        return view;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
    private void getMySip(String data) {

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();

        singleShedow.setVisibility(View.GONE);
        fullScreenShedow.setVisibility(View.VISIBLE);
        List<JSONObject> list = new ArrayList<>();
        try{
            loading = false;

            if(!data.equals("")){
                JSONObject jsonObj = new JSONObject(data);
                JSONArray jsonArray = jsonObj.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                    list.add(jsonObject1);
                }
            }

        } catch (Exception e) {

        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);

            if (list.size() > 0) {
                Collections.sort(list, new SortData("scheme"));
                mAdapter.updateList(list, "",null);
                mTvLoading.setVisibility(View.GONE);
            } else {
                mAdapter.updateList(new ArrayList<JSONObject>(), "",null);
                mTvLoading.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public void onTxnItemClick(@NonNull JSONObject data) {

    }
}


