package investwell.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.widget.AppCompatSeekBar;

import com.iw.mint.sdk.R;

import java.util.ArrayList;

public class CustomProgressBar extends AppCompatSeekBar {

    private ArrayList<ProgressItem> mProgressItemsList;
    private Bitmap flagBitmap;
    private Double flagProgress = 0.0;

    public CustomProgressBar(Context context) {
        super(context);
        init(context);
    }

    public CustomProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public CustomProgressBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }

    public void initData(ArrayList<ProgressItem> progressItemsList) {
        this.mProgressItemsList = progressItemsList;
    }

    private void init(Context context) {
        mProgressItemsList = new ArrayList<>();

        // Convert vector drawable to bitmap
        Drawable drawable = AppCompatResources.getDrawable(context, R.drawable.goal_flag);
        if (drawable != null) {
            Bitmap bitmap = Bitmap.createBitmap(
                    drawable.getIntrinsicWidth(),
                    drawable.getIntrinsicHeight(),
                    Bitmap.Config.ARGB_8888
            );
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            drawable.draw(canvas);
            flagBitmap = bitmap;
        }
    }

    public void setFlagProgress(Double progress) {
        this.flagProgress = progress;
        invalidate(); // redraw
    }

    @Override
    protected synchronized void onMeasure(int widthMeasureSpec,
                                          int heightMeasureSpec) {
        // TODO Auto-generated method stub
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    protected void onDraw(Canvas canvas) {
        if (!mProgressItemsList.isEmpty()) {
            int progressBarWidth = getWidth();
            int progressBarHeight = getHeight();
            int thumboffset = getThumbOffset();
            int lastProgressX = 0;
            int progressItemWidth, progressItemRight;
            for (int i = 0; i < mProgressItemsList.size(); i++) {
                ProgressItem progressItem = mProgressItemsList.get(i);
                Paint progressPaint = new Paint();
                progressPaint.setColor(getResources().getColor(
                        progressItem.color));

                progressItemWidth = (int) (progressItem.progressItemPercentage
                        * progressBarWidth / 100);

                progressItemRight = lastProgressX + progressItemWidth;

                // for last item give right to progress item to the width
                if (i == mProgressItemsList.size() - 1
                        && progressItemRight != progressBarWidth) {
                    progressItemRight = progressBarWidth;
                }
                Rect progressRect = new Rect();
                progressRect.set(lastProgressX, thumboffset / 2,
                        progressItemRight, progressBarHeight - thumboffset / 2);
                canvas.drawRect(progressRect, progressPaint);
                lastProgressX = progressItemRight;
            }
            super.onDraw(canvas);

            if (flagBitmap != null && flagProgress > 0) {

                float ratio = (float) (flagProgress / getMax());
                float rawX = ratio * getWidth() - (flagBitmap.getWidth() / 2f);

                float minX = 0;
                float maxX = getWidth() - flagBitmap.getWidth();

                float x = Math.max(minX, Math.min(rawX, maxX));

                canvas.drawBitmap(flagBitmap, x, -12, null);
            }
        }
    }
}