package investwell.broker.nseOnborading;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;
import investwell.utils.Extensions;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class BrokerNsePendingOnboardAdapter extends RecyclerView.Adapter<BrokerNsePendingOnboardAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private AppSession mSession;
    private OnItemClickListener listener;
    private String mType = "";
    private String mExchange = "1";

    public BrokerNsePendingOnboardAdapter(Context context, AppSession session, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mSession = session;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.broker_nse_iin_list_adapter, viewGroup, false);
        return new BrokerNsePendingOnboardAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final BrokerNsePendingOnboardAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject mJsonData);

        void onProfileItemClick(int position);

    }

    public void updateList(List<JSONObject> list,  Boolean isSearch, String type,String exchange) {
        if (isSearch) {
            mDataList.clear();
        }
        mDataList.addAll(list);
        mType = type;
        mExchange = exchange;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPan, tvArn, tcTaxStatus, tvHolding, tvCreateDate, tvCompleteProfile, tvIin, tvPendingReason;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvPan = view.findViewById(R.id.tvPan);
            tvArn = view.findViewById(R.id.tvArn);
            tcTaxStatus = view.findViewById(R.id.tcTaxStatus);
            tvHolding = view.findViewById(R.id.tvHolding);
            tvCreateDate = view.findViewById(R.id.tvCreateDate);
            tvCompleteProfile = view.findViewById(R.id.tvCompleteProfile);
            tvIin = view.findViewById(R.id.tvInn);
            tvPendingReason = view.findViewById(R.id.tvPendingReason);
        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final BrokerNsePendingOnboardAdapter.OnItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);

                if (!TextUtils.isEmpty(jsonObject.optString("name")) && !jsonObject.optString("name").equalsIgnoreCase("null")) {
                    tvName.setText(jsonObject.optString("name"));
                } else {
                    tvName.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("iinid")) && !jsonObject.optString("iinid").equalsIgnoreCase("null")) {
                    tvIin.setText(jsonObject.optString("iinid"));
                } else {
                    tvIin.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("pan")) && !jsonObject.optString("pan").equalsIgnoreCase("null")) {
                    tvPan.setText(jsonObject.optString("pan"));
                } else {
                    tvPan.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("arn")) && !jsonObject.optString("arn").equalsIgnoreCase("null")) {
                    tvArn.setText(jsonObject.optString("arn"));
                } else {
                    tvArn.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("taxStatusCode")) && !jsonObject.optString("taxStatusCode").equalsIgnoreCase("null")) {
                    tcTaxStatus.setText(Extensions.getTaxStatus(jsonObject.optString("taxStatusCode")));
                } else {
                    tcTaxStatus.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("holdingCode")) && !jsonObject.optString("holdingCode").equalsIgnoreCase("null")
                        || (!TextUtils.isEmpty(jsonObject.optString("holdingNatureDescription")) && !jsonObject.optString("holdingNatureDescription").equalsIgnoreCase("null"))) {
                    tvHolding.setText(Extensions.getHoldingCode(jsonObject.optString("holdingCode")));
                } else {
                    tvHolding.setText(mContext.getString(R.string.not_available));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("createdAt")) && !jsonObject.optString("createdAt").equalsIgnoreCase("null")) {
                    tvCreateDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("createdAt")));
                } else {
                    tvCreateDate.setText(mContext.getString(R.string.not_available));
                }

                tvPendingReason.setVisibility(View.GONE);
                if (mType.equals("NO")) {
                    String value = jsonObject.optString("iinDeactivationReason");
                    if (!value.equals("null") && !value.equals("")) {
                        tvPendingReason.setVisibility(View.VISIBLE);
                        tvPendingReason.setText(jsonObject.optString("iinDeactivationReason"));
                    }
                }

                boolean isAddEnableProfile = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature44", Permissions.ADD);
                boolean isAddEnableProfileNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature53", Permissions.ADD);
                if(!isAddEnableProfile)
                    tvCompleteProfile.setVisibility(View.GONE);
                if (mExchange.equalsIgnoreCase("4")){
                    tvCompleteProfile.setVisibility(View.VISIBLE);
                }

                tvCompleteProfile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onProfileItemClick(position);

                    }
                });

                itemView.setOnClickListener(v -> listener.onItemClick(position, jsonObject));

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }

        }

    }

}
