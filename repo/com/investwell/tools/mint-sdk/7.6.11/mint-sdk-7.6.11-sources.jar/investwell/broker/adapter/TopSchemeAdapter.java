package investwell.broker.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import investwell.broker.fragment.FragTopScheme;

public class TopSchemeAdapter extends RecyclerView.Adapter<TopSchemeAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context context;

    public TopSchemeAdapter(ArrayList<JSONObject> mDataList, Context context) {
        this.mDataList = mDataList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_row_top_scheme, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final JSONObject object = mDataList.get(position);
        final JSONObject jsonObject = new JSONObject();
        String default_value = new DecimalFormat("#.##").format(object.optDouble(FragTopScheme.mTopTime.trim()));
        holder.tvTitle.setText(object.optString("schemeGroupName"));
        holder.tvDefault.setText(default_value + "%");
        if (Float.parseFloat(default_value) > 0) {
            holder.tvDefault.setTextColor(Color.parseColor("#329D00"));
        } else if (Float.parseFloat(default_value) < 0) {
            holder.tvDefault.setTextColor(Color.parseColor("#C91717"));
        } else {
            holder.tvDefault.setTextColor(Color.parseColor("#000000"));
        }

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView mCart, mLogo;
        TextView tvDefault, tvTitle;
        LinearLayout llTopSchemeCart;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mCart = itemView.findViewById(R.id.topscheme_cartadd);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvDefault = itemView.findViewById(R.id.tv_default);
        }
    }
}
