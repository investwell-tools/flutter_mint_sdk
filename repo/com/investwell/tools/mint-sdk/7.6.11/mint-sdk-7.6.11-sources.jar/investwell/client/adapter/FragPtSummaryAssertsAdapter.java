package investwell.client.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.utils.AppSession;
import investwell.utils.Config;

/**
 * Created by binesh on 8/5/18.
 */

public class FragPtSummaryAssertsAdapter extends RecyclerView.Adapter<FragPtSummaryAssertsAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;
    private String mType = "";
    private AppSession mSession;

    public FragPtSummaryAssertsAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_pt_summary_asserts_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position,String mFileName);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView mTvName, mTvCurrent, mTvRealizedGain, mTvUnrealizedGain,
                mTvXirr, tvLevelPurchase,tvLevelWidrawble,tvWithdrawal,tvApplicantName,tvStartDate;
        private ImageView ivDownload;
        private LinearLayout llXirrView;

        public ViewHolder(View view) {
            super(view);
            mTvName = view.findViewById(R.id.tvName);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvRealizedGain = view.findViewById(R.id.tvRealized);
            mTvUnrealizedGain = view.findViewById(R.id.tvUnrealized);
            mTvXirr = view.findViewById(R.id.tvXIRR);
            llXirrView = view.findViewById(R.id.llXirrView);
            tvLevelPurchase = view.findViewById(R.id.tvLevelPurchase);
            ivDownload = view.findViewById(R.id.iv_download);
            tvLevelWidrawble = view.findViewById(R.id.tvLevelWidrawble);
            tvWithdrawal = view.findViewById(R.id.tvWithdrawal);
            tvApplicantName = view.findViewById(R.id.tvApplicantName);
            tvStartDate = view.findViewById(R.id.tvStartDate);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObjectSummary = mDataList.get(position);
                final JSONArray txns =jsonObjectSummary.optJSONArray("txns");
                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

                double totalGain = jsonObjectSummary.optDouble("gain");
                String strTotalGain = format.format(totalGain);
                if (totalGain >= 0) {
                    mTvUnrealizedGain.setTextColor(ContextCompat.getColor(mContext, R.color.marketGreen));
                } else {
                    mTvUnrealizedGain.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                }
                mTvUnrealizedGain.setText(strTotalGain);



                double gaine3 = jsonObjectSummary.optDouble("purchaseValue");
                String strGain3 = format.format(gaine3);
                mTvRealizedGain.setText(strGain3);

                if (mType.equals("fd")) {
                    tvLevelPurchase.setText(mContext.getString(R.string.investment_amount));
                    mTvName.setText(jsonObjectSummary.optString("scheme"));
                    //
                }else{
                    // enable widrawal
                    tvWithdrawal.setText(jsonObjectSummary.optString("sellValue"));
                    tvLevelPurchase.setText(mContext.getString(R.string.investment));
                    mTvName.setText(jsonObjectSummary.optString("assetName"));
                    tvApplicantName.setText(Utils.setFirstLetterCapital(jsonObjectSummary.optString("applicantName")));
                }
                tvStartDate.setText(Utils.formatedDate(jsonObjectSummary.optString("startDate")));

                if (mSession.getHideXirr().equals("0") && jsonObjectSummary.has("XIRR")) {
                    llXirrView.setVisibility(View.VISIBLE);
                    UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-", "%", 2, false, mTvXirr);
                }
                else {
                    llXirrView.setVisibility(View.INVISIBLE);
                }

                // disable download icon when account and company provider is null
                String companyProvider="",account="";
                companyProvider = txns.optJSONObject(0).optString("companyProvider");
                account = txns.optJSONObject(0).optString("accountNumber");
                if (account.equals("null")){
                    account="";
                }
                if (companyProvider.equals("null")){
                    companyProvider="";
                }
                if (companyProvider.isEmpty() || account.isEmpty())
                    ivDownload.setVisibility(View.GONE);
                else
                    ivDownload.setVisibility(View.VISIBLE);

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }



            ivDownload.setOnClickListener(view -> {download(position);});
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position,"");
                }
            });


        }

    }

    private void download(int position) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, mContext)){
            return;
        }

        String url="",destination="",companyProvider="",account="",slug="";
        RequestQueue requestQueue;
        try{
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length()  == 0)
                destination = Config.GET_PMS_SOA_BROKER;
            else{
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                destination = Config.GET_PMS_SOA_CLIENT;
                slug ="&selectedUser="+Utils.getSelectedUserObject(mSession);
            }

            JSONArray jsonObject =mDataList.get(position).optJSONArray("txns");

            companyProvider = jsonObject.optJSONObject(0).optString("companyProvider");
            account = jsonObject.optJSONObject(0).optString("accountNumber");
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    destination +"companyProvider="+companyProvider+"&accountNumber="+account+slug;


            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        }catch (Exception e){
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET,url, response -> {
            String mFileName="";
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.optInt("status") == 0) {
                    JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                    mFileName = jsonObjectMain.optString("fileName");
                }else {
                    String msg = jsonObject.optString("error message");
                    showPopup(msg);
                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }finally {
                if (!mFileName.isEmpty()){
                    listener.onItemClick(position,mFileName);
                }
            }

        },volleyError -> {
            UtilityKotlin.parseVolleyError(volleyError, mSession, mContext, "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, mContext);
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, mContext);
                return super.parseNetworkResponse(response);
            }
        };

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) mContext.getApplicationContext();
                    appApplication.showCommonDailog(mContext, mContext.getString(R.string.txt_session_expired), mContext.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mContext);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);

    }

    private void showPopup(String msg) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
        builder.setMessage(msg);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alert = builder.create();
        alert.setTitle(mContext.getString(R.string.pms_soa));
        alert.show();

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mType = type;
        notifyDataSetChanged();
    }

}
