package investwell.client.fragments.home;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.ExtensionsKt.getDate;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;

import investwell.charts.mikephil.charting.components.Legend;
import investwell.client.adapter.MyJourneySofarAdapter;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.ExtensionsKt;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import investwell.charts.mikephil.charting.charts.LineChart;
import investwell.charts.mikephil.charting.components.AxisBase;
import investwell.charts.mikephil.charting.components.XAxis;
import investwell.charts.mikephil.charting.components.YAxis;
import investwell.charts.mikephil.charting.data.Entry;
import investwell.charts.mikephil.charting.data.LineData;
import investwell.charts.mikephil.charting.data.LineDataSet;
import investwell.charts.mikephil.charting.formatter.ValueFormatter;
import investwell.charts.mikephil.charting.interfaces.datasets.ILineDataSet;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.piechart.data.MyMarkerView;
import investwell.utils.AppSession;
import investwell.utils.Config;
import kotlin.Unit;

public class FragMyJouneySoFar extends BaseFragment {
    private View view;
    private AppSession mSession;

    public static String values;
    private ClientActivity mActivity;
    private RequestQueue requestQueue;
    private AppApplication mAppplication;
    private LineChart chart;
    private Spinner mSpDate;
    private boolean mIsFirstTimeSpinnerCalled = true;
    private LinearLayout mLinerLineChart, mLPairChart, llUsers, llCustomPeriod;
    String mSelectedValue = "";
    private TextView tvNothing;
    private MyJourneySofarAdapter myJourneySofarAdapter;
    MyMarkerView mMarkerView;
    private List<JSONObject> mMemberList, mMemberTypesList;
    private Spinner mMemberSpinner;
    private int mSelectedPosition = 0;
    private boolean isFirstTimeCalled = true;
    private TextInputEditText etCustomStartDate, etCustomEndDate;
    private MaterialButton mbCustomPeriodApply;
    private String fromDateApi, toDateApi;
    private SimpleDateFormat apiDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) ;
    private SimpleDateFormat displayDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()) ;
    private boolean snapshotApiSuccess = false;
    private boolean graphApiSuccess = false;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        //  mActivity.getClientBalSummery();
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onResume() {
        super.onResume();
/*        if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.title_journey), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.frag_my_journey_sofar, container, false);
        setUpToolBar();
        mActivity.setMainVisibility(this, null);

        chart = view.findViewById(R.id.chart);
        mSpDate = view.findViewById(R.id.spDate);
        mLPairChart = view.findViewById(R.id.linerPieChart);
        tvNothing = view.findViewById(R.id.tvNothing);
        mMemberSpinner = view.findViewById(R.id.spSelectMember);
        llUsers = view.findViewById(R.id.linerUsers);
        llCustomPeriod = view.findViewById(R.id.llCustomPeriod);
        etCustomStartDate = view.findViewById(R.id.etStartDate);
        etCustomEndDate = view.findViewById(R.id.etEndDate);
        mbCustomPeriodApply = view.findViewById(R.id.mbCustomPeriodApply);


        RecyclerView recycleView = view.findViewById(R.id.rvData);
        recycleView.setHasFixedSize(true);
        recycleView.setNestedScrollingEnabled(true);

        recycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        myJourneySofarAdapter = new MyJourneySofarAdapter(getActivity(), new ArrayList<JSONObject>(), position -> {

        });
        recycleView.setAdapter(myJourneySofarAdapter);

        setDateSpinner();
        setLineGraph("");

        if (!Utils.getSelectedLevelNo(mSession).equals("100")) {
            llUsers.setVisibility(View.VISIBLE);
            getAllMembers();
        } else
            llUsers.setVisibility(View.GONE);

        etCustomStartDate.setOnClickListener(v -> showDatePickerDialog(
                requireContext(),
                requireActivity(),
                null,
                getDate(etCustomEndDate.getText().toString(),displayDateFormat,displayDateFormat,-1,0,0),
                etCustomStartDate.getText().toString(),
                displayDateFormat,
                (displayDateString) -> {
                    String displayDateToApiFormat = getDate(displayDateString,displayDateFormat,apiDateFormat,0,0,0);
                    mbCustomPeriodApply.setEnabled(!fromDateApi.equals(displayDateToApiFormat));
                    etCustomStartDate.setText(displayDateString);
                    return Unit.INSTANCE;
                }
        ));
        etCustomEndDate.setOnClickListener(v -> showDatePickerDialog(
                requireContext(),
                requireActivity(),
                getDate(etCustomStartDate.getText().toString(),displayDateFormat,displayDateFormat,1,0,0),
                getDate(null,displayDateFormat,displayDateFormat,-1,0,0),
                etCustomEndDate.getText().toString(),
                displayDateFormat,
                (displayDateString) -> {
                    String displayDateToApiFormat = getDate(displayDateString,displayDateFormat,apiDateFormat,0,0,0);
                    mbCustomPeriodApply.setEnabled(!toDateApi.equals(displayDateToApiFormat));
                    etCustomEndDate.setText(displayDateString);

                    return Unit.INSTANCE;
                }
        ));
        mbCustomPeriodApply.setOnClickListener(v -> {
            fromDateApi = getDate(etCustomStartDate.getText().toString(),displayDateFormat,apiDateFormat,0,0,0);
            toDateApi = getDate(etCustomEndDate.getText().toString(),displayDateFormat,apiDateFormat,0,0,0);
            getOverallGainApi();
            getClientLineGraph();
        });
        return view;
    }

    private void setDateSpinner() {
        try {
            List<String> listMem = new ArrayList<>();
            listMem.add(getString(R.string.current_month));
            listMem.add(getString(R.string.last_month));
            listMem.add(getString(R.string.text_current_fy));
            listMem.add(getString(R.string.last_fy));
            listMem.add(getString(R.string.last_one_year));
            listMem.add(getString(R.string.text_Since_inc));
            listMem.add(getString(R.string.custom));

            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMem);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpDate.setAdapter(adapter);
            mSpDate.setSelection(5);
            mSelectedValue = "sinceInception";
            mSpDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    llCustomPeriod.setVisibility(View.GONE);
                    if (position == 0) {
                        mSelectedValue = "currentMonth";
                    } else if (position == 1) {
                        mSelectedValue = "lastOneMonth";
                    } else if (position == 2) {
                        mSelectedValue = "currentFY";
                    } else if (position == 3) {
                        mSelectedValue = "lastFY";
                    } else if (position == 4) {
                        mSelectedValue = "lastOneYear";
                    } else if (position == 5) {
                        mSelectedValue = "sinceInception";
                    }
                    else {
                        mSelectedValue = "custom";
                        fromDateApi = ExtensionsKt.getDate(null, apiDateFormat, apiDateFormat, 0, 0, -1);
                        toDateApi = ExtensionsKt.getDate(null, apiDateFormat, apiDateFormat, -1, 0, 0);
                        llCustomPeriod.setVisibility(View.VISIBLE);
                        String fromDisplayDate = getDate(fromDateApi, apiDateFormat, displayDateFormat, 0, 0, 0);
                        String toDisplayDate = getDate(toDateApi, apiDateFormat, displayDateFormat, 0, 0, 0);
                        etCustomStartDate.setText(fromDisplayDate);
                        etCustomEndDate.setText(toDisplayDate);
                    }

                    if (chart != null) {
                        chart.highlightValue(null);
                    }

                    getOverallGainApi();
                    getClientLineGraph();

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }


    public void getClientLineGraph() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        try {
            String url ="";



            String uId = "";
            String levelNo = "";
            JSONObject selectedObj = new JSONObject();
            if (mSelectedPosition != 0) {
                JSONObject jsonObject = mMemberList.get(mSelectedPosition - 1);
                selectedObj.put("levelNo", jsonObject.optString("levelNo"));
                uId = jsonObject.optString("uid");
                selectedObj.put("uid", uId);
            } else {
                uId = Utils.getSelectedUid(mSession);
                selectedObj = Utils.getSelectedUserObject(mSession);
            }

            JSONArray filterArray = new JSONArray();

            try {

                // products
                JSONObject productsObj = new JSONObject();
                JSONObject productTypes = new JSONObject();

                productTypes.put("MF", true);
                productTypes.put("EQ", true);

                productsObj.put("products", productTypes);
                filterArray.put(productsObj);

                // Add fromDate & toDate only for custom period
                if ("custom".equalsIgnoreCase(mSelectedValue)) {

                    JSONObject toDateObj = new JSONObject();
                    toDateObj.put("toDate", toDateApi);

                    JSONObject fromDateObj = new JSONObject();
                    fromDateObj.put("fromDate", fromDateApi);

                    filterArray.put(toDateObj);
                    filterArray.put(fromDateObj);
                }

                // graphPeriod
                JSONObject graphPeriodObj = new JSONObject();
                graphPeriodObj.put("graphPeriod", mSelectedValue);

                filterArray.put(graphPeriodObj);

                // dataSource
                JSONObject dataSourceObj = new JSONObject();
                dataSourceObj.put("dataSource", "0");
                filterArray.put(dataSourceObj);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            url =  "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_INVESTMENT_JOURNEY_GRAPH +
                    "filters="+filterArray+
                    "&selectedUser="+selectedObj+
                    "&investorUid=" + uId;

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

            KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
                @Override
                public void onLoading(boolean isLoading) {
                    if (isLoading) {
                        ProgressBarCommon.showDialog(requireActivity());
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                }

                @Override
                public void onSuccess(@NonNull String response, int statusCode) {
                    isFirstTimeCalled = false;
                    graphApiSuccess = true;
                    if(snapshotApiSuccess)
                        mbCustomPeriodApply.setEnabled(false);
                    setLineGraph(response);
                }
            });

        } catch (Exception e) {
        }


    }

    private String buildChartAccessibilitySummary() {
        if (AppApplication.dataList == null || AppApplication.dataList.isEmpty()) {
            return "Line chart with no data.";
        }

        try {
            SimpleDateFormat input = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            SimpleDateFormat output = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH);

            JSONObject first = AppApplication.dataList.get(0);
            JSONObject last = AppApplication.dataList.get(AppApplication.dataList.size() - 1);

            Date startDate = input.parse(first.optString("date"));
            Date endDate = input.parse(last.optString("date"));


            if (chart.getData() == null || chart.getData().getDataSetCount() == 0) {
                return "Line chart with no data.";
            }
            LineDataSet dataSet = (LineDataSet) chart.getData().getDataSetByIndex(0);

            float minY = dataSet.getYMin();
            float maxY = dataSet.getYMax();

            String minYFormatted = Utils.formatToLacCroreString(minY);
            String maxYFormatted = Utils.formatToLacCroreString(maxY);

            float firstValue = dataSet.getEntryForIndex(0).getY();
            float lastValue = dataSet.getEntryForIndex(dataSet.getEntryCount() - 1).getY();

            String trend;
            if (lastValue > firstValue) {
                trend = "increasing";
            } else if (lastValue < firstValue) {
                trend = "decreasing";
            } else {
                trend = "stable";
            }

            return "Performance line chart showing portfolio value from "
                    + output.format(startDate)
                    + " to "
                    + output.format(endDate)
                    + ". Y axis represents portfolio value in rupees, ranging from "
                    + minYFormatted
                    + " to "
                    + maxYFormatted
                    + ". Overall trend is "
                    + trend + ".";

        } catch (Exception e) {
            return "Performance line chart showing portfolio values.";
        }
    }

    public void setLineGraph(String response) {
        chart.getDescription().setEnabled(false);
        chart.setDrawGridBackground(true);
        chart.getAxisLeft().setDrawGridLines(true);
        chart.getXAxis().setDrawGridLines(true);
        chart.setPinchZoom(true);
        chart.setDoubleTapToZoomEnabled(true);
        chart.setScaleEnabled(true);
        chart.getLegend().setWordWrapEnabled(true);
        if (!isAdded())
            return;
        chart.setGridBackgroundColor(ContextCompat.getColor(requireActivity(), R.color.transparent));

        Legend legend = chart.getLegend();
        legend.setTextColor(ContextCompat.getColor(requireContext(), R.color.black_white));

        if (getActivity() != null) {
            mMarkerView = new MyMarkerView(getContext(), R.layout.custom_marker_view, mActivity.mSelectedValue);
            mMarkerView.setChartView(chart);
            chart.setMarker(mMarkerView);
        }

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setAvoidFirstLastClipping(true);
        xAxis.setTextColor(ContextCompat.getColor(requireContext(), R.color.default_text_color));
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getAxisLabel(float value, AxisBase axis) {
                String xAxisName = "";

                try {
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
                    @SuppressLint("SimpleDateFormat") SimpleDateFormat outPutDateFormat = new SimpleDateFormat("dd MMM yyyy");

                    float[] entryValue = axis.mEntries;
                    int totalCount = axis.mEntryCount;
                    if (entryValue[0] == value) {
                        JSONObject jsonObject = AppApplication.dataList.get(0);
                        Date date = inputDateFormat.parse(jsonObject.optString("date"));
                        xAxisName = outPutDateFormat.format(date);

                    } else if (totalCount <= 6) {
                        if (entryValue[(totalCount - 1)] == value) {
                            JSONObject jsonObject = AppApplication.dataList.get(AppApplication.dataList.size() - 1);
                            Date date = inputDateFormat.parse(jsonObject.optString("date"));
                            xAxisName = outPutDateFormat.format(date);
                        }
                    } else if (totalCount > 6) {
                        if (entryValue[(totalCount - 2)] == value) {
                            JSONObject jsonObject = AppApplication.dataList.get(AppApplication.dataList.size() - 1);
                            Date date = inputDateFormat.parse(jsonObject.optString("date"));
                            if (date != null) {
                                xAxisName = outPutDateFormat.format(date);
                            }
                        }
                    } else {
                        if (entryValue[(totalCount - 1)] == value) {
                            JSONObject jsonObject = AppApplication.dataList.get(AppApplication.dataList.size() - 1);
                            Date date = inputDateFormat.parse(jsonObject.optString("date"));
                            xAxisName = outPutDateFormat.format(date);
                        }
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

                return xAxisName;
            }
        });

        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setLabelCount(8, false);
//        leftAxis.setAxisMinimum(0f); // this replaces setStartAtZero(true)
        leftAxis.setTextColor(ContextCompat.getColor(requireContext(), R.color.default_text_color));
        leftAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                String yLeftAxisName;
                yLeftAxisName = Utils.formatToLacCroreString(value);

                /*NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                yLeftAxisName = format.format(value);*/

                return yLeftAxisName;
            }
        });


        YAxis rightAxis = chart.getAxisRight();
        rightAxis.setDrawLabels(false);
        rightAxis.setEnabled(false);

        // set data
        chart.setData((generateDataLine(response)));

        chart.getAxisLeft().resetAxisMinimum();
        chart.getAxisLeft().resetAxisMaximum();

        chart.notifyDataSetChanged();
        chart.invalidate();

        // Accessibility summary
        String accessibilityText = buildChartAccessibilitySummary();
        chart.setContentDescription(accessibilityText);

        chart.animateX(1000);

    }


    private LineData generateDataLine(String response) {
        ArrayList<ILineDataSet> sets = new ArrayList<>();
        if (getActivity() != null) {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.optInt("status") == 0) {
                    tvNothing.setVisibility(View.GONE);
                    chart.setVisibility(View.VISIBLE);

                    JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                    JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                    if (jsonArray.length() > 0) {
                        ArrayList<Entry> values1 = new ArrayList<>();
                        ArrayList<Entry> values2 = new ArrayList<>();
                        ArrayList<JSONObject> dataList = new ArrayList<>();
                        if (jsonArray.length() > 0) {
                            ArrayList<Float> list = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                dataList.add(jsonObject1);
                                String value1 = jsonObject1.optString("netInvestment");
                                values1.add(new Entry(i, Float.parseFloat(value1)));
                                String value2 = "0";
                                if (!jsonObject1.optString("AUM").equalsIgnoreCase("null")) {
                                    value2 = jsonObject1.optString("AUM");
                                    values2.add(new Entry(i, Float.parseFloat(value2)));
                                }
                                float floatValue1 = Float.parseFloat(value1);
                                float floatValue2 = Float.parseFloat(value2);
                                list.add(floatValue1);
                                list.add(floatValue2);
                              /*  if (i == 0) {
                                    float floatValue1 = Float.parseFloat(value1);
                                    float floatValue2 = Float.parseFloat(value2);
                                    JSONObject lastObject = jsonArray.getJSONObject(jsonArray.length() - 1);
                                    float floatValue3 = Float.parseFloat(lastObject.optString("netInvestment"));
                                    float floatValue4 = Float.parseFloat(lastObject.optString("AUM"));


                                    list.add(floatValue1);
                                    list.add(floatValue2);
                                    list.add(floatValue3);
                                    list.add(floatValue4);

                                    float minValue = Collections.min(list);
                                    YAxis leftAxis = chart.getAxisLeft();
                                    minValue = (minValue - (minValue * 10 / 100));
                                    leftAxis.setAxisMinimum(minValue);
                                }*/

                            }
                            float minValue = Collections.min(list);
                            float maxValue = Collections.max(list);

                            YAxis leftAxis = chart.getAxisLeft();

                            if (minValue < 0) {
                                minValue = minValue + (minValue * 0.1f);
                            } else {
                                minValue = minValue - (minValue * 0.1f);
                            }

                            maxValue = maxValue + (maxValue * 0.1f);

                            leftAxis.setAxisMinimum(minValue);
                            leftAxis.setAxisMaximum(maxValue);

                            AppApplication.GInvestmentList.clear();
                            AppApplication.GCurrentValueList.clear();
                            AppApplication.dataList.clear();
                            AppApplication.GInvestmentList.addAll(values1);
                            AppApplication.GCurrentValueList.addAll(values2);
                            AppApplication.dataList.addAll(dataList);

                            LineDataSet d1 = new LineDataSet(values1, getString(R.string.Net_Investment));
                            d1.setLineWidth(2.5f);
                            d1.setColor(ContextCompat.getColor(getActivity(), R.color.purple_text_color));
                            d1.setHighLightColor(ContextCompat.getColor(getActivity(), R.color.purple_text_color));
                            d1.setDrawValues(false);
                            d1.setDrawCircles(false);
                            /*d1.setCircleRadius(1.5f);
                            d1.setCircleColor(ContextCompat.getColor(getActivity(), R.color.transparent));*/
                            sets.add(d1);

                            LineDataSet d2 = new LineDataSet(values2, getString(R.string.current_value));
                            d2.setDrawCircles(false);
                            d2.setLineWidth(2.5f);
                            //  d2.setCircleRadius(1.5f);
                            //  d2.setCircleColor(ContextCompat.getColor(getActivity(), R.color.graph_marker_color));

                            d2.setColor(ContextCompat.getColor(getActivity(), R.color.green_text_color));
                            d2.setHighLightColor(ContextCompat.getColor(getActivity(), R.color.green_text_color));
                            d2.setDrawValues(false);
                            sets.add(d2);

                            if (dataList.size() > 0) {
                                JSONObject object = dataList.get(dataList.size() - 1);
                                String value1 = object.optString("netInvestment");
                                String value2 = "0";
                                if (!object.optString("AUM").equalsIgnoreCase("null")) {
                                    value2 = object.optString("AUM");
                                }
                                float floatValue1 = Float.parseFloat(value1);
                                float floatValue2 = Float.parseFloat(value2);

                               /* Highlight h = new Highlight(floatValue1,  floatValue2, 2);
                                chart.setMarker(mMarkerView);
                                chart.highlightValue(h);*/

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        chart.highlightValue(floatValue1, floatValue2, 1, true);
                                     /* Entry entry = new Entry();
                                      entry.setX(floatValue1);
                                      entry.setY(floatValue2);*/
                                        // chart.getMarker().refreshContent(entry,chart.getHighlightByTouchPoint(floatValue1,floatValue2));

                                    }
                                }, 1200);

                            }
                        } else {
                            chart.setVisibility(View.INVISIBLE);
                            tvNothing.setVisibility(View.VISIBLE);


                        }
                    } else {
                        chart.setVisibility(View.INVISIBLE);
                        tvNothing.setVisibility(View.VISIBLE);
                    }
                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();

            }
        }
        return new LineData(sets);
    }

    private void setOverallGainValue(String response) {
        try {
            List<JSONObject> list = new ArrayList<>();
            JSONObject newJsonObject ;
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                if(jsonObjectMain != null) {
                    if (!mSelectedValue.equals("sinceInception") && jsonObjectMain.has("openingBalance")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "OB");
                        newJsonObject.put("levelName", getString(R.string.opening_balance));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("openingBalance")));
                        newJsonObject.put("formula", "");
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("purchaseValue")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "A");
                        newJsonObject.put("levelName", getString(R.string.investment));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("purchaseValue")));
                        newJsonObject.put("formula", "");
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("switchIn")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "B");
                        newJsonObject.put("levelName", getString(R.string.text_Switch));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("switchIn")));
                        newJsonObject.put("formula", "");
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("switchOut")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "C");
                        newJsonObject.put("levelName", getString(R.string.text_sout));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("switchOut")));
                        newJsonObject.put("formula", "");
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("redemptionAmount")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "D");
                        newJsonObject.put("levelName", getString(R.string.redemptions));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("redemptionAmount")));
                        newJsonObject.put("formula", "");
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("dividend")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "E");
                        newJsonObject.put("levelName", getString(R.string.txt_Dividend_sofar));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("dividend")));
                        newJsonObject.put("formula", "");
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("currentValue")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "F");
                        newJsonObject.put("levelName", getString(R.string.text_current_value));
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("currentValue")));
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("netGain")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "G");
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("netGain")));

                        if (mSelectedValue.equals("sinceInception")) {
                            newJsonObject.put("levelName", getString(R.string.net_gain));
                            newJsonObject.put("formula", " (F-A-B+C+D+E)");
                        }
                        else {
                            newJsonObject.put("levelName", getString(R.string.period_gain));
                            newJsonObject.put("formula", " (F-OB-A-B+C+D+E)");
                        }
                        list.add(newJsonObject);
                    }

                    if (jsonObjectMain.has("periodNetInvestment")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "H");
                        String netInvestmentFormulas;
                        if (mSelectedValue.equals("sinceInception")) {
                            newJsonObject.put("levelName", getString(R.string.Net_Investment));
                        }
                        else {
                            newJsonObject.put("levelName", getString(R.string.net_investment_selected_period));
                        }
                        netInvestmentFormulas = "";
                        newJsonObject.put("value", getValues(jsonObjectMain.optDouble("periodNetInvestment")));
                        newJsonObject.put("formula", netInvestmentFormulas);
                        list.add(newJsonObject);
                    }


                    if (mSession.getHideXirr().equals("0") && jsonObjectMain.has("XIRR")) {
                        newJsonObject = new JSONObject();
                        newJsonObject.put("symbol", "I");
                        newJsonObject.put("levelName", getString(R.string.xirr));
                        String xirrValue = UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectMain, "XIRR", "-","",2,false);
                        newJsonObject.put("value", xirrValue);
                        newJsonObject.put("formula", " (%)");
                        list.add(newJsonObject);
                    }

                    myJourneySofarAdapter.updateList(list);
                }
            }
        } catch (Exception e) {

        }
    }

    private String getValues(double value) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        String strValue = "";
        if (Double.isNaN(value)) {
            value = 0.0;
        }
        strValue = format.format(value);
        return strValue;
    }

    private void getOverallGainApi() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            String uId = "";
            String levelNo = "";
            JSONObject selectedObj = new JSONObject();

            if (mSelectedPosition != 0) {
                JSONObject jsonObject = mMemberList.get(mSelectedPosition - 1);
                selectedObj.put("levelNo", jsonObject.optString("levelNo"));
                uId = jsonObject.optString("uid");
                selectedObj.put("uid", uId);
            } else {
                uId = Utils.getSelectedUid(mSession);
               selectedObj = Utils.getSelectedUserObject(mSession);
            }
            JSONArray filterArray = new JSONArray();

            try {

                // products
                JSONObject productsObj = new JSONObject();
                JSONObject productTypes = new JSONObject();

                productTypes.put("MF", true);
                productTypes.put("EQ", true);

                productsObj.put("products", productTypes);
                filterArray.put(productsObj);

                // Add fromDate & toDate only for custom period
                if ("custom".equalsIgnoreCase(mSelectedValue)) {

                    JSONObject toDateObj = new JSONObject();
                    toDateObj.put("toDate", toDateApi);

                    JSONObject fromDateObj = new JSONObject();
                    fromDateObj.put("fromDate", fromDateApi);

                    filterArray.put(toDateObj);
                    filterArray.put(fromDateObj);
                }

                // graphPeriod
                JSONObject graphPeriodObj = new JSONObject();
                graphPeriodObj.put("graphPeriod", mSelectedValue);
                filterArray.put(graphPeriodObj);

                // dataSource
                JSONObject dataSourceObj = new JSONObject();
                dataSourceObj.put("dataSource", "0");
                filterArray.put(dataSourceObj);

            } catch (JSONException e) {
                e.printStackTrace();
            }

            url =  "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_INVESTMENT_JOURNEY_SNAPSHOT +
                    "filters="+filterArray+
                    "&selectedUser="+selectedObj+
                    "&investorUid=" + uId;


            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                snapshotApiSuccess = true;
                if(graphApiSuccess)
                    mbCustomPeriodApply.setEnabled(false);
                setOverallGainValue(response);
            }
        });

    }


    private void setSpinnerMembers(String rawData) {
        try {
            mMemberList = new ArrayList<>();
            List<String> listMem = new ArrayList<>();
            listMem.add("All");

            JSONObject jsonObject = new JSONObject(rawData);

            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    mMemberList.add(jsonObject1);
                    listMem.add(jsonObject1.optString("name"));
                }
            } else {
                String service_msg = jsonObject.optString("message");
                Toast.makeText(getActivity(), service_msg, Toast.LENGTH_SHORT).show();
            }

            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMem);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mMemberSpinner.setAdapter(adapter);
            mMemberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedPosition = position;
                    if (!isFirstTimeCalled) {
                        getClientLineGraph();
                        getOverallGainApi();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

    }

    private void getAllMembers() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = "";
        try {
            if (Utils.getSelectedLevelNo(mSession).equals("1")){
                return;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MEMBERS + "levelNo=" + "100" + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                setSpinnerMembers(response);
            }
        });

    }

}
