package investwell.client.fragments.mydoc;

import static android.os.Build.VERSION.SDK_INT;

import static investwell.utils.KtorHelper.requestCallDownload;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.InputStreamVolleyRequest;
import investwell.utils.UtilityKotlin;
import investwell.utils.customView.CustomButton;
import investwell.utils.volleyCustom.VolleyMultipartRequest;

public class FragDocumentFilesList extends BaseFragment implements ToolbarFragment.ToolbarCallback {
    private AppSession mSession;
    private ClientActivity mActivity;
    private AppApplication mAppplication;
    private ShimmerFrameLayout mShimmerViewContainer;
    private ToolbarFragment fragToolBar;
    private FragDocumentFilesAdapter mFilesAdapter;
    private static final int MY_REQUEST_CODE_PERMISSION = 1000;
    private static final int MY_RESULT_CODE_FILECHOOSER = 2000;
    private BottomSheetDialog bottomSheetDialog;
    private TextView mTvNothing;
    private String mDocumentType = "PAN";
    private String mUid = "";
    private int mclickedPosition = 0;
    private RelativeLayout relFileName;
    private TextView tvFileName;
    private ImageView mIvStatus;
    private Uri mUri = null;
    String mFileName = "";
    String extension = ""; // use for handle crash



    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
 /*       if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.my_documents),
                    true, false, false, true, false, false, false);
            fragToolBar.setCallback(this);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_document, container, false);

        mActivity.setMainVisibility(this, null);
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("uid")) {
            mUid = bundle.getString("uid");
        }
        setUpToolBar();

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mTvNothing = view.findViewById(R.id.tvNothing);

        RecyclerView recycleView = view.findViewById(R.id.recycleView);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recycleView.setLayoutManager(mLayoutManager);

        mFilesAdapter = new FragDocumentFilesAdapter(mActivity, this, new ArrayList<JSONObject>(), new FragDocumentFilesAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                /*JSONObject jsonObject = mFilesAdapter.mDataList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("uid", jsonObject.optString("uid"));
                mActivity.displayViewOther(80, bundle);*/


            }
        });
        recycleView.setAdapter(mFilesAdapter);

        getFiles();
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                showBottomSheet();
}
    }


    private void getFiles() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "myDocTable");
            url = ("https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOCUMENT_LISTING + "uid=" + mUid
                    + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession));

            /*https://spvithlani.investwell.app/webapi/client/utilities/getDocumentsListing?
            uid=6158fa1dba4bf04015e91d2e2caf5bcc&componentForLoader={"componentName":"documentList"}
            &investorUid=6158fa1dba4bf04015e91d2e2caf5bcc&selectedUser={"uid":"6158fa1dba4bf04015e9
            1d2e2caf5bcc","levelNo":"98"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    mShimmerViewContainer.setVisibility(View.GONE);
                    mShimmerViewContainer.stopShimmer();


                    List<JSONObject> documentList = new ArrayList<>();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("Status") == 0) {

                            JSONObject ob = jsonObject.getJSONObject("result");
                            JSONArray jsonArray = ob.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                                documentList.add(jsonObject1);
                            }

                           /* if (dtoList.size() != 0) {

                                adapter = new MyDocumentAdapter(dtoList, new MyDocumentAdapter.ItemClick() {
                                    @Override
                                    public void onItem(int position) {
                                        showBottomSheet(position);
                                        // call to upload data
                                    }

                                    @Override
                                    public void dto(@Nullable Integer position, @Nullable String u) {
                                        Log.d(TAG, "dto: " + position + u);
                                        // view items
                                        Bundle bundle = new Bundle();
                                        bundle.putString("uid", u);
                                        bundle.putInt("position", position);
                                        mActivity.displayViewOther(80, bundle);
//                                openDocument(position,u);
                                    }
                                });
                                recyclerView.setAdapter(adapter);
                            }*/

                        } else if (jsonObject.optInt("status") == -1) {
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                        }

                    } catch (JSONException e) {
                        if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    } finally {
                        if (documentList.size() != 0) {
                            mFilesAdapter.updateList(documentList, "");
                            mTvNothing.setVisibility(View.GONE);
                        } else {
                            mFilesAdapter.updateList(new ArrayList<>(), "");
                            mTvNothing.setVisibility(View.VISIBLE);
                        }
                    }

                }, volleyError -> {

            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mTvNothing.setVisibility(View.VISIBLE);

            if (!isAdded())
                return;
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 1;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(stringRequest);
    }

    private void showBottomSheet() {
        bottomSheetDialog = new BottomSheetDialog(getActivity());
        bottomSheetDialog.setContentView(R.layout.item_doc_chooser);
        MaterialButton btUpload = bottomSheetDialog.findViewById(R.id.btUpload);
        RelativeLayout relUpload = bottomSheetDialog.findViewById(R.id.relUpload);
        relFileName = bottomSheetDialog.findViewById(R.id.relFileName);
        tvFileName = bottomSheetDialog.findViewById(R.id.tvFileName);
        mIvStatus = bottomSheetDialog.findViewById(R.id.ivFlleTick);

        Spinner spn = bottomSheetDialog.findViewById(R.id.spn);
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, getCategoryList());
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        // ArrayAdapter<String> badapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, getCategoryList());
        spn.setAdapter(dataAdapter);
        spn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spn.getSelectedItem().toString().equals("PAN Card")) {
                    mDocumentType = "PAN";
                } else if (spn.getSelectedItem().toString().equals("Aadhar Card")) {
                    mDocumentType = "aadhar";
                } else if (spn.getSelectedItem().toString().equals("Transaction Slip")) {
                    mDocumentType = "transaction";
                } else if (spn.getSelectedItem().toString().equals("KYC")) {
                    mDocumentType = "KYC";
                } else if (spn.getSelectedItem().toString().equals("Photo")) {
                    mDocumentType = "photo";
                } else if (spn.getSelectedItem().toString().equals("Driving License")) {
                    mDocumentType = "DL";
                } else {
                    mDocumentType = "others";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        relUpload.setOnClickListener(view -> {
            if (SDK_INT <= Build.VERSION_CODES.Q) {
                if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    setPermission(12);
                    return;
                }
            }

            openFileChooser();

        });

        btUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mFileName.equals("") && mUri ==null) {
                    Toast.makeText(getActivity(), getString(R.string.please_select_file), Toast.LENGTH_SHORT).show();
                }else if (tvFileName.getText().toString().contains("File Size")) {
                    Toast.makeText(getActivity(), getString(R.string.please_select_file_less_than_2_mb), Toast.LENGTH_SHORT).show();
                } else {
                    uploadDocument(mFileName, mUri);
                }


            }
        });

        bottomSheetDialog.show();
    }

    private void openFileChooser() {
        Intent chooseFileIntent = new Intent(Intent.ACTION_GET_CONTENT);
        chooseFileIntent.setType("*/*");
        String[] mimetype = {"image/*", "application/pdf", "application/msword", "text/plain", "application/excel"};
        chooseFileIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimetype);
        chooseFileIntent.addCategory(Intent.CATEGORY_OPENABLE);
        chooseFileIntent = Intent.createChooser(chooseFileIntent, "Choose a file");
//        startActivityForResult(chooseFileIntent, MY_RESULT_CODE_FILECHOOSER);
        resultLauncher.launch(chooseFileIntent);

    }

    private void uploadDocument(String fileName, Uri uri) {
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));


        if (uri != null) {
            InputStream iStream = null;
            try {
                iStream = getActivity().getContentResolver().openInputStream(uri);
                final byte[] inputData = getBytes(iStream);


                String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.UPLOAD_PROFILE_PHOTO;

                VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST,
                        url, response -> {
                    UtilityKotlin.setRefreshKey(mSession);
                    try {
                        mBar.dismiss();
                        String json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                        JSONObject object = new JSONObject(json);
                        if (object.optInt("status") == 0) {
                            bottomSheetDialog.dismiss();
                            getFiles();


                        } else if (object.optInt("status") == -1) {
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(getActivity(), getString(R.string.failed), object.optString("message"), "message");
                        }

                    } catch (UnsupportedEncodingException | JSONException e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }

                }, error -> {
                    mBar.dismiss();
                }) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("fileHandle", String.valueOf(1));

                        params.put("uid", mUid);
                        params.put("fileKey", mDocumentType);
                        params.put("fileName", fileName);
                        params.put("fileType", "DOCUMENT");
                        params.put("isExternal","1");
                        params.put("selectedUser",Utils.getSelectedUserObject(mSession).toString());
                        return params;
                    }


                    @Override
                    protected Map<String, DataPart> getByteData() throws AuthFailureError {
                        Map<String, DataPart> params = new HashMap<>();
                        params.put("file", new DataPart(fileName, inputData));
                        return params;
                    }

                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
                    }

                    @Override
                    public Response<NetworkResponse> parseNetworkResponse(NetworkResponse response) {
                        UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                        return super.parseNetworkResponse(response);
                    }
                };

                volleyMultipartRequest.setRetryPolicy(new RetryPolicy() {
                    @Override
                    public int getCurrentTimeout() {
                        return 50000;
                    }

                    @Override
                    public int getCurrentRetryCount() {
                        return 2;
                    }

                    @Override
                    public void retry(VolleyError error) throws VolleyError {
                        int statusCode = error.networkResponse.statusCode;
                        if (statusCode == 401) {
                            new AppApplication().showCommonDailog(
                                    getActivity(),
                                    getString(R.string.txt_session_expired),
                                    getString(R.string.txt_please_login_again_for_continue),
                                    "sessionExpired"
                            );
                        }
                    }
                });
                Volley.newRequestQueue(getActivity()).add(volleyMultipartRequest);

            } catch (IOException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
                mBar.dismiss();
            }
        }
    }
    public void downloadFile(int position) {
        mclickedPosition = position;
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission(11);
                return;
            }
        }

        String url = "";

        JSONObject fileObject = mFilesAdapter.mDataList.get(position);
        String fileNameInResponse = fileObject.optString("fileName");
        if (fileNameInResponse.contains(".")){
             extension = fileNameInResponse.substring(fileNameInResponse.lastIndexOf("."));
        }


        url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_DOCUMENT
                + "uid=" + mUid + "&fileHandle=1"
                + "&fileName=" + fileObject.optString("fileName") + "&isExternal=1"+"&attachment=1"+"&selectedUser="+Utils.getSelectedUserObject(mSession);

        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "doc", extension,new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        String ext = extension.replace(".", "");
                        if (ext.equals("xls")) {
                            ext = "vnd.ms-excel";
                        }
                        mActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_document_download_successfully), ext, mFileSave, uri);
                    }
                });



    }

    public void deleteFile(int position) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        String uId = "";
        String levelNo = "";
        JSONObject jsonObject = new JSONObject();

        try {
            if (mSession.getHasLoging() && mSession.getLoginType() == "broker") {
                if (mSession.getClientObject().isEmpty()) {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                } else {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                }
            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }

            jsonObject.put("uid", uId);
            jsonObject.put("levelNo", levelNo);

        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();

        }

        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DELETE_DOCUMENT;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, response -> {
            try {
                UtilityKotlin.setRefreshKey(mSession);
                if (!getActivity().isFinishing() && mBar != null && mBar.isShowing())
                    mBar.dismiss();

                JSONObject jsonObject1 = new JSONObject(response);
                if (jsonObject1.optInt("Status") == 0) {
                    mFilesAdapter.mDataList.remove(position);
                    mFilesAdapter.notifyDataSetChanged();
                }

            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }, volleyError -> {
            if (!isAdded())
                return;
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                JSONObject fileObject = mFilesAdapter.mDataList.get(position);

                params.put("uid", mUid);
                params.put("fileHandle", "1");
                params.put("fileName", fileObject.optString("fileName"));
                params.put("investorUid", jsonObject.optString("uid"));
                params.put("selectedUser", String.valueOf(jsonObject));

                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }
        };

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 2;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(stringRequest);


    }


    private JSONObject getSelectedUser() {
        String uId = "";
        JSONObject jsonObject1 = new JSONObject();
        try {
            String levelNo = "";
            if (mSession.getHasLoging() && mSession.getLoginType() == "broker") {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            jsonObject1.put("uid", uId);
            jsonObject1.put("levelNo", levelNo);
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        return jsonObject1;
    }


    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }


    private String[] getCategoryList() {
        String[] ct = new String[]{
                "PAN Card", "Aadhar Card", "Transaction Slip", "KYC", "Photo", "Driving License", "General"
        };
        return ct;
    }


    ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @SuppressLint("Range")
        @Override
        public void onActivityResult(ActivityResult result) {
            if (result.getResultCode() == Activity.RESULT_OK) {
                mUri = result.getData().getData();
                String uriString = mUri.toString();
                File myFile = new File(uriString);

                if (uriString.startsWith("content://")) {
                    Cursor cursor = null;
                    try {
                        cursor = getActivity().getContentResolver().query(mUri, null, null, null, null);
                        if (cursor != null && cursor.moveToFirst()) {
                            mFileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                            // uploadDocument(displayName, uri);

                        }
                    } finally {
                        cursor.close();
                    }
                } else if (uriString.startsWith("file://")) {
                    mFileName = myFile.getName();
                }

                try {
                    InputStream iStream = getActivity().getContentResolver().openInputStream(mUri);
                    final byte[] inputData = getBytes(iStream);

                    long lengthbmp = inputData.length;
                    int fileSize = (int) (lengthbmp / 1024);

                    if (fileSize < 2048) {
                        mIvStatus.setImageResource(R.drawable.green_checked);
                        relFileName.setVisibility(View.VISIBLE);
                        tvFileName.setText(mFileName);
                        tvFileName.setTextColor(ContextCompat.getColor(getActivity(),R.color.black));
                    } else {
                        mIvStatus.setImageResource(R.drawable.red_cross);
                        relFileName.setVisibility(View.VISIBLE);
                        tvFileName.setText(getString(R.string.file_size_limit_2mb));
                        tvFileName.setTextColor(ContextCompat.getColor(getActivity(),R.color.red));
                    }
                } catch (Exception e) {

                }
            }
        }
    });

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),permissions -> {
        if (permissions.containsValue(true)){

        }else {
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
    });


    private void requestMultiPermissions( String[] permissionList){
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }


    private void setPermission(int requestCode) {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions){
            requestMultiPermissions(permissionList);
        }else {
            if (requestCode == 11) {
                downloadFile(mclickedPosition);
            } else if (requestCode == 12) {
                openFileChooser();
            }
        }
    }

}
