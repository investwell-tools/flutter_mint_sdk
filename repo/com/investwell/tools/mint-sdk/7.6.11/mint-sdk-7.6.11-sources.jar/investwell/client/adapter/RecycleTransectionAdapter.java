package investwell.client.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by binesh on 8/5/18.
 */

public class RecycleTransectionAdapter extends RecyclerView.Adapter<RecycleTransectionAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private RecycleTransectionAdapter.OnItemClickListener listener;
    private int mWidth = 0, mHeight = 0;

    public RecycleTransectionAdapter(Context context, ArrayList<JSONObject> list, int height, int width, RecycleTransectionAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mWidth = width;
        mHeight = height;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycle_trensection_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {

        return 6;
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivImage;
        TextView tvTransection;
        RelativeLayout linMain;


        public ViewHolder(View view) {
            super(view);
            ivImage = view.findViewById(R.id.ivImage);
            tvTransection = view.findViewById(R.id.tvTransection);
            linMain = view.findViewById(R.id.linMain);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onItemClick(position);
                    }
                });
                linMain.setLayoutParams(new LinearLayout.LayoutParams(mWidth / 6, mHeight));

                if (position == 0) {
                    ivImage.setImageResource(R.mipmap.purchase_float);
                    tvTransection.setText(mContext.getString(R.string.purchase));

                } else if (position == 1) {
                    ivImage.setImageResource(R.mipmap.sip_float);
                    tvTransection.setText(mContext.getString(R.string.SIP));

                } else if (position == 2) {
                    ivImage.setImageResource(R.mipmap.switch_float);
                    tvTransection.setText(mContext.getString(R.string.Switch));

                } else if (position == 3) {
                    ivImage.setImageResource(R.mipmap.swp_float);
                    tvTransection.setText(mContext.getString(R.string.SWP));

                } else if (position == 4) {
                    ivImage.setImageResource(R.mipmap.stp_float);
                    tvTransection.setText(mContext.getString(R.string.SIP));

                } else if (position == 5) {
                    ivImage.setImageResource(R.mipmap.sell_float);
                    tvTransection.setText(mContext.getString(R.string.redeem));
                }

            } catch (Exception e) {

            }


        }

    }


}
