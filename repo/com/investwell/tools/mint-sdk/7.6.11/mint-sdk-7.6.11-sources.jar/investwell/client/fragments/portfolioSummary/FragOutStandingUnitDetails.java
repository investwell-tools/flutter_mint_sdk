package investwell.client.fragments.portfolioSummary;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPortfolioSchemeDetailAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.SortData;

public class FragOutStandingUnitDetails extends BaseFragment {
    private AppSession mSession;
    private ClientActivity mActivity;
    private JSONObject mJsonObject, tranJsonObject;
    private RequestQueue requestQueue;
    private TextView mTvErrorMessage;
    private FragPortfolioSchemeDetailAdapter mFragPortfolioSchemeDetailsADapter;
    public String mFolioId = "", mAppId = "";
    private AppApplication mAppplication;
    private ToolbarFragment mFragToolBar;

    @Override
    public void onResume() {
        super.onResume();
/*        if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.text_outstanding_unit), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag_outstanding_unit_details, container, false);
        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setUpToolBar();
            }
        });

        mTvErrorMessage = view.findViewById(R.id.tvErrorMessage);

        RecyclerView rvTRansections = view.findViewById(R.id.rvTRansections);
        rvTRansections.setNestedScrollingEnabled(false);
        rvTRansections.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mFragPortfolioSchemeDetailsADapter = new FragPortfolioSchemeDetailAdapter(getActivity(), new ArrayList<JSONObject>());
        rvTRansections.setAdapter(mFragPortfolioSchemeDetailsADapter);

        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mJsonObject = new JSONObject(bundle.getString("data"));
                mFolioId = mJsonObject.optString("folioid");
                mAppId = mJsonObject.optString("appid");
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }
        getTransection(true);
        return view;
    }


    private void getTransection(boolean isShowLoader) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        if (isShowLoader)
            mAppplication.showProgressBar(mActivity);

        String url = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(new Date());

            JSONArray jsonArray = new JSONArray();

            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);

            JSONObject dateObject2 = new JSONObject();
            dateObject2.put("appid", mAppId);
            jsonArray.put(dateObject2);

            JSONObject dateObject3 = new JSONObject();
            dateObject3.put("folioid", mFolioId);
            jsonArray.put(dateObject3);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioTable");


            //  https://demo.investwell.app/webapi/client/dashboard/getDetailedPortFolioReturns?filters=
            // [{"endDate":"2019-08-28"},{"appid":"c2f8d9991f70107520d8bb771539d900"},
            // {"folioid":"0d16acfc71e45169713e8dc49906c779"}]&componentForLoader=
            // {"componentName":"folioTable"}&pageSize=20¤tPage=1&investorUid=
            // 5553ce3575b8e1a64181794eb86c5b27&selectedUser={"uid":"5553ce3575b8e1a64181794eb86c5b27
            // ","levelNo":"98"}


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.GET_FOLIO_SCHEME_DETAILS + "filters=" + jsonArray.toString()
                    + "&pageSize=100&currentPage=1" +
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession) + "" + "&clubTxns=true" +
                    "&orderBy=purchaseDate" + "&orderByDesc=true";


            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        mAppplication.hideProgressDaolog();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject tranJsonObject = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = tranJsonObject.getJSONArray("rows");
                                ArrayList<JSONObject> list = new ArrayList<>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }
                                Collections.sort(list, new SortData("purchaseDate"));


                                mFragPortfolioSchemeDetailsADapter.updateList(list);


                            } else if (jsonObject.optInt("status") == -1) {
                                AppApplication appApplication = (AppApplication) getActivity().getApplication();
                                appApplication.showCommonDailog(getActivity(), getString(R.string.failed), jsonObject.optString("message"), "message");

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        mAppplication.hideProgressDaolog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
