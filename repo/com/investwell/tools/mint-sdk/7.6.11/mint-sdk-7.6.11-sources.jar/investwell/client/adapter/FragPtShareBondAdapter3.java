package investwell.client.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FragPtShareBondAdapter3 extends RecyclerView.Adapter<FragPtShareBondAdapter3.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private AppSession mSession;
    private Context mContext;
    private String mGroupByType = "1002";
    private OnItemClickListener listener;

    public FragPtShareBondAdapter3(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_share_bond_adapter3, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onSchemeClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvType,tvPurchaseCost,tvPrice, tvPurchaseDate,tvqunatity;
        private LinearLayout llQuantity, llMarket;


        public ViewHolder(View view) {
            super(view);
            tvType = view.findViewById(R.id.tvType);
            tvPurchaseCost = view.findViewById(R.id.tvPurchaseCost);
            tvPrice = view.findViewById(R.id.tvPrice);
            tvPurchaseDate = view.findViewById(R.id.tvPurchaseDate);
            tvqunatity = view.findViewById(R.id.tvqunatity);
            llQuantity = view.findViewById(R.id.llQuantity);
            llMarket = view.findViewById(R.id.llMarket);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObjectSummary = mDataList.get(position);

                tvType.setText(Utils.SchemeNameFormat(jsonObjectSummary.optString("txnType")));
                double currentValue = jsonObjectSummary.optDouble("amount");
                String strCurrentAmount = format.format(currentValue);
                tvPurchaseCost.setText(strCurrentAmount);



                tvPurchaseDate.setText(Utils.formatedDate(jsonObjectSummary.optString("navDate")));

                if ((!TextUtils.isEmpty(jsonObjectSummary.optString("units")) && !jsonObjectSummary.optString("units").equalsIgnoreCase("null"))) {
                    llQuantity.setVisibility(View.VISIBLE);
                    tvqunatity.setText(jsonObjectSummary.optString("units"));
                }else{
                    llQuantity.setVisibility(View.GONE);
                }

                if ((!TextUtils.isEmpty(jsonObjectSummary.optString("units")) && !jsonObjectSummary.optString("units").equalsIgnoreCase("null")) && !jsonObjectSummary.optString("units").equalsIgnoreCase("0")) {
                    llMarket.setVisibility(View.VISIBLE);
                    double nav = jsonObjectSummary.optDouble("nav");
                    String srtNav = String.format("%.2f", nav) ;
                    tvPrice.setText(srtNav);
                }else{
                    llMarket.setVisibility(View.GONE);
                }


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });


        }

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mGroupByType = type;
        notifyDataSetChanged();
    }

}
