package investwell.utils.customView;

import android.content.Context;
import android.graphics.Typeface;
import androidx.appcompat.widget.AppCompatTextView;
import android.util.AttributeSet;


public class CustomTextViewBold extends AppCompatTextView {
    public CustomTextViewBold(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs);
    }

    public CustomTextViewBold(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public CustomTextViewBold(Context context) {
        super(context);
        init(null);

    }


    public void setFont(String fontName) {
        if (fontName != null)
            this.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "fonts/" + fontName));
        else
            this.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "fonts/" + "Roboto-Bold.ttf"));
    }

    private void init(AttributeSet attrs) {

    }


    @Override
    public boolean isInEditMode() {
        return super.isInEditMode();
    }

}