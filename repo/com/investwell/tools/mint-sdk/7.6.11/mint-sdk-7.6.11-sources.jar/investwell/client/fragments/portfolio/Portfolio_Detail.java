package investwell.client.fragments.portfolio;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Portfolio_Detail_Adapter;
import investwell.utils.AppSession;
import investwell.utils.Config;


public class Portfolio_Detail extends BaseFragment {
    TextView applicant_name, purchase_cost, market_value, gain, cagr, mTvToolBarTitle;
    RequestQueue requestQueue;
    StringRequest stringRequest;
    RecyclerView sub_client_recycle;
    private String mCID = "";
    ImageView gain_arrow, cagr_arrow;
    Portfolio_Detail_Adapter portfolio_detail_adapter;
    private ClientActivity mActivity;
    private AppSession mSession;
    public String mFolioId = "", mAppId = "";
    private ProgressDialog mBar;
    private AppApplication mAppplication;

    @Override
    public void onResume() {
        super.onResume();
   /*     if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        if ((mBar != null) && mBar.isShowing())
            mBar.dismiss();
        mBar = null;
    }

    @Override
    public void onStart() {
        super.onStart();

      /*  if (mSession.getLoginType().equals("client") || AppApplication.USER_TYPE_FROM_BROKER.equals("client")) {
            mActivity.mCvTabBarBottom.setVisibility(View.VISIBLE);
            mActivity.setMainVisibility(this, null);
        }*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_portfolio__detail, container, false);

        RelativeLayout relToolBar = view.findViewById(R.id.relToolBar);
        applicant_name = view.findViewById(R.id.applicant_name);
        mTvToolBarTitle = view.findViewById(R.id.toolbar_title);
        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        gain = view.findViewById(R.id.gain);
        cagr = view.findViewById(R.id.cagr);
        gain_arrow = view.findViewById(R.id.gain_arrow);
        cagr_arrow = view.findViewById(R.id.cagr_arrow);
        sub_client_recycle = view.findViewById(R.id.sub_client_recycle);
        sub_client_recycle.setHasFixedSize(true);
        sub_client_recycle.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        portfolio_detail_adapter = new Portfolio_Detail_Adapter(getActivity(), new ArrayList<JSONObject>(), mCID);
        sub_client_recycle.setAdapter(portfolio_detail_adapter);

        Bundle mBundle = getArguments();
        if (mBundle != null && mBundle.containsKey("isShowToolBar")) {
            relToolBar.setVisibility(View.VISIBLE);
        } else {
            relToolBar.setVisibility(View.GONE);
        }

        if (mBundle != null && mBundle.containsKey("folioid")) {
            if (mBundle.containsKey("applicant_name"))
                applicant_name.setText(mBundle.getString("applicant_name"));

            mFolioId = mBundle.getString("folioid");
            mAppId = mBundle.getString("appid");
            getPortfolioDetails(mFolioId, mAppId);
        } else {
            if (mSession.getLoginType().equals("client")) {
                view.findViewById(R.id.ivLeft).setVisibility(View.GONE);
                getPortfolio();
            }/* else if (AppApplication.USER_TYPE_FROM_BROKER.equals("client")) {
                view.findViewById(R.id.ivLeft).setVisibility(View.GONE);
                getPortfolio();
            }*/
            else{
                getPortfolio();
            }
        }

        view.findViewById(R.id.ivLeft).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });
        return view;
    }

    private void getPortfolio() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.GET_PORTFOLIO + "filters=&group=appid&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession)+ "";
            url = URLDecoder.decode(url, "UTF-8");
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        if (mBar != null)
                            mBar.dismiss();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                            JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                            JSONObject jsonObject1 = jsonArray.getJSONObject(0);
                            applicant_name.setText(jsonObject1.optString("applicantName"));

                            mFolioId = jsonObject1.optString("folioid");
                            mAppId = jsonObject1.optString("appid");

                            getPortfolioDetails(mFolioId, mAppId);
                        } catch (Exception e) {

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getPortfolioDetails(String folioid, String investorUid) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(new Date());


            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject1 = new JSONObject();
            jsonObject1.put("endDate", endDate);
            jsonArray.put(jsonObject1);

            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("appid", investorUid);
            jsonArray.put(jsonObject2);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                     Config.GET_PORTFOLIO +
                    "filters=" + jsonArray.toString() + "&group=&investorUid="
                    + investorUid + "&selectedUser=&levelNo="+"&selectedUser="+Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");


        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        if (mBar != null && mBar.isShowing())
                            mBar.dismiss();
                        setPortfolio_Data(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null && mBar.isShowing())
                            mBar.dismiss();
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void setPortfolio_Data(String data) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");


                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                market_value.setText(strCurrentAmount);

                double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                String strPurchaseValue = format.format(purchaseValue);
                purchase_cost.setText(strPurchaseValue);

                double gaine = jsonObjectSummary.optDouble("gain");
                String strGain = format.format(gaine);
                gain.setText(strGain);

                cagr.setText(new DecimalFormat("#0.00").format(Double.parseDouble
                        (jsonObjectSummary.optString("CAGR"))) + "%");


                if (gain.getText().toString().contains("-")) {
                    gain_arrow.setBackgroundResource(R.drawable.menu_down);
                } else {
                    gain_arrow.setBackgroundResource(R.drawable.menu_up);
                }
                if (cagr.getText().toString().contains("-")) {
                    cagr_arrow.setBackgroundResource(R.drawable.menu_down);
                } else {
                    cagr_arrow.setBackgroundResource(R.drawable.menu_up);
                }

                List<JSONObject> list = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }
                setData(list);
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }


    }


    private void setData(List<JSONObject> list) {
        try {
            Collections.sort(list, new Comparator<JSONObject>() {

                public int compare(JSONObject a, JSONObject b) {
                    String valA = new String();
                    String valB = new String();

                    try {
                        valA = (String) a.get("fundName");
                        valB = (String) b.get("fundName");
                    } catch (JSONException e) {
                    }

                    return valA.compareTo(valB);
                }
            });
            portfolio_detail_adapter.updateList(list, applicant_name.getText().toString());

        } catch (
                Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }


    }


}