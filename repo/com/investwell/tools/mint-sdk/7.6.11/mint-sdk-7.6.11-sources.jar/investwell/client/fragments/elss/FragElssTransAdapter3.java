package investwell.client.fragments.elss;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

/**
 * Created by Dev on 16/08/2021.
 */

public class FragElssTransAdapter3 extends RecyclerView.Adapter<FragElssTransAdapter3.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private FragElssTransAdapter3.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragELSS1User mFragELSS;
    private AppSession mSession;
    private String mType = "";

    public FragElssTransAdapter3(Context context, String type, ArrayList<JSONObject> list, FragElssTransAdapter3.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mType = type;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_elss_trans_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvAmount, tvDate, tvNav;
        CardView card_view;
        View ivThreeUpper;

        public ViewHolder(View view) {
            super(view);
            tvDate = view.findViewById(R.id.tvDate);
            tvNav = view.findViewById(R.id.tvNav);
            tvAmount = view.findViewById(R.id.tvAmount);

            card_view = view.findViewById(R.id.card_view);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObject = mDataList.get(position);

                double purchaseValue = jsonObject.optDouble("amount");
                String strPurchaseValue = format.format(purchaseValue);
                tvAmount.setText(strPurchaseValue);

                tvNav.setText(Utils.SchemeNameFormat(jsonObject.optString("txnType")));
                tvDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("navDate")));


            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });

        }
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


}
