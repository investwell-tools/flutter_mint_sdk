package investwell.common.onboarding.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.Utils;

public class InvestProfileAdapter extends RecyclerView.Adapter<InvestProfileAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;


    public InvestProfileAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @NotNull
    @Override
    public InvestProfileAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_invest_profile, viewGroup, false);
        return new InvestProfileAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position,String status);
        void onProfileItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_profile_name, tv_holding_status, tv_pan,tvJointHolderName,tvJointHolderName2;
        ImageView mIvActiveStatus,mIvProfileOpener;

        public ViewHolder(View view) {
            super(view);
            tv_profile_name = view.findViewById(R.id.tv_profile_name);
            tv_pan = view.findViewById(R.id.tv_pan);
            tvJointHolderName=view.findViewById(R.id.tv_joint_holder_name);
            tvJointHolderName2=view.findViewById(R.id.tv_joint_holder_name_2);
            tv_holding_status = view.findViewById(R.id.tv_holding_status);
            mIvActiveStatus = view.findViewById(R.id.ivStatus);
        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final InvestProfileAdapter.OnItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);
                if(!TextUtils.isEmpty(jsonObject.optString("JH1Name"))&& !jsonObject.optString("JH1Name").equalsIgnoreCase("null")){
                    tvJointHolderName.setText(jsonObject.optString("JH1Name"));
                    tvJointHolderName.setVisibility(View.VISIBLE);
                }else {
                    tvJointHolderName.setVisibility(View.GONE);
                }
                tv_profile_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                tv_holding_status.setText(Utils.setFirstLetterCapital( jsonObject.optString("holdingNatureDescription")));
                tv_pan.setText("PAN: " + jsonObject.optString("firstHolderPAN"));
                if (jsonObject.optString("activationStatus").equalsIgnoreCase("Yes")) {
                    mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_green);
                } else {
                    mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_red);

                }
                itemView.setOnClickListener(v -> listener.onItemClick(position,jsonObject.optString("activationStatus")));
                mIvProfileOpener.setOnClickListener(v -> listener.onProfileItemClick(position));
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
