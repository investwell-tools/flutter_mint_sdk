package investwell.client.fragments.home.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.imageview.ShapeableImageView;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.activity.AppApplication;
import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.activity.DomainActivity;
import investwell.activity.LoginActivity;
import investwell.activity.NewKycOnboardingWebView;
import investwell.activity.WebActivity;
import investwell.activity.WebViewActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.home.FragHomeClient5;
import investwell.common.calculator.CalculatorsActivity;
import investwell.common.nfo.NfoActivity;
import investwell.common.onboarding.marketupdate.MarketUpdateActivity;
import investwell.common.topscheme.TopSchemeActivity;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.customView.CustomTextViewRegular;

public class SectionSignupAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context mContext;
    public ArrayList<JSONObject> sectionArrayList;
    private AppSession mSession;
    private Intent intent;


    public SectionSignupAdapter(Context context, ArrayList<JSONObject> sectionArrayList) {
        this.sectionArrayList = sectionArrayList;
        mContext = context;
        mSession = AppSession.getInstance(mContext);
    }



    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view;
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_loginbox5, viewGroup, false);
        return new CardViewHolder(view);
    }

    public void updateSectionsTypeList(List<JSONObject> list) {

        sectionArrayList.clear();
        sectionArrayList.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        ((CardViewHolder) viewHolder).setCardViews(sectionArrayList.get(position));

    }

    @Override
    public int getItemCount() {
        return sectionArrayList.size();
    }

    /*****************************CARD VIEWS*******************/
    class CardViewHolder extends RecyclerView.ViewHolder {
        ImageView ivIcon;
        TextView tvHeader;
        CustomTextViewRegular tvDescription;
        CustomTextViewRegular tvFullDescription;
        LinearLayout llInvestmentRoute;

        CardViewHolder(@NonNull View itemView) {
            super(itemView);
            ivIcon = itemView.findViewById(R.id.ivIcon);
            tvHeader = itemView.findViewById(R.id.tvHeader);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            tvFullDescription = itemView.findViewById(R.id.tvFullDescription);
            llInvestmentRoute = itemView.findViewById(R.id.llInvestmentRoute);
        }

        /*****************Set Card Views Data************************************/
        void setCardViews(final JSONObject jsonObject) {

            tvHeader.setText(jsonObject.optString("ChildTitle"));
            if (!jsonObject.optString("ChildBrief").isEmpty()) {
                tvDescription.setVisibility(View.VISIBLE);
                tvDescription.setText(jsonObject.optString("ChildBrief"));
            } else {
                tvDescription.setVisibility(View.GONE);
            }

            if (!jsonObject.optString("ChildDescription").isEmpty()) {
                tvFullDescription.setVisibility(View.VISIBLE);
                tvFullDescription.setText(jsonObject.optString("ChildDescription"));
            } else {
                tvFullDescription.setVisibility(View.GONE);
            }

            setIcon(jsonObject, ivIcon);
            llInvestmentRoute.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickAction(jsonObject);
                }
            });
        }


    }


    private void setIcon(JSONObject jsonObject, ImageView ivIcon) {
        if (jsonObject.optString("ChildType").equals("Module")) {
            ivIcon.setImageResource(R.mipmap.default_generic_icon);
        } else {
            Picasso.get().load(jsonObject.optString("ImageFile")).error(R.mipmap.default_generic_icon).into(ivIcon);
        }
    }

    private void clickAction(JSONObject jsonObject) {
        if (jsonObject.optString("ChildType").equals("Custom")) {
            if (jsonObject.optString("CustomType").equals("URL")) {
                intent = new Intent(mContext, NewKycOnboardingWebView.class);
                intent.putExtra("title", jsonObject.optString("ChildTitle"));
                intent.putExtra("url", jsonObject.optString("TargetURL"));
                mContext.startActivity(intent);
            } else {
                // to Do
            }
        }
    }






}







