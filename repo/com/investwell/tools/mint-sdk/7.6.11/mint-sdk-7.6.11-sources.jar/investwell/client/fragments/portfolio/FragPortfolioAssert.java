package investwell.client.fragments.portfolio;

import static investwell.utils.UtilityKotlin.getOneDayEarlier;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPortfolioAssertAdapter;
import investwell.utils.AppSession;
import investwell.utils.Config;


public class FragPortfolioAssert extends BaseFragment implements View.OnClickListener {
    RequestQueue requestQueue;
    RecyclerView sub_client;
    TextView mTvName, mTvSold,mTvCurrent,tvInvestment, mTvInterest, mTvGain, mTvREturn, mTvCgar;
    FragPortfolioAssertAdapter portfolio_client_adapter;

    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private CardView mCardView;
    private TextView mTvNothing;
    private AppApplication mAppplication;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.stopShimmer();
     /*   if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmer();
        super.onPause();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_portfolio_assert, container, false);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        mTvNothing = view.findViewById(R.id.tvNothing);


        mTvName = view.findViewById(R.id.tvName);
        mTvSold = view.findViewById(R.id.tvSoldValue);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvREturn = view.findViewById(R.id.tvReturn);
        mTvInterest = view.findViewById(R.id.tvInterest);
        mTvGain = view.findViewById(R.id.tvGain);
        mTvCgar = view.findViewById(R.id.tvCagr);
        tvInvestment = view.findViewById(R.id.tvInvestment);

        sub_client = view.findViewById(R.id.sub_client);

        sub_client.setHasFixedSize(true);
        sub_client.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        portfolio_client_adapter = new FragPortfolioAssertAdapter(getActivity(), new ArrayList<JSONObject>());
        sub_client.setAdapter(portfolio_client_adapter);

        setUserVisibleHint(true);
        if (AppApplication.DASHBOARD_PORTFOLIO_ASSERT.isEmpty()) {
            getPortfolioFD();
        } else {
            SetData();
        }

        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}

    }

    private void SetData() {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        try {
            ArrayList<JSONObject> list = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(AppApplication.DASHBOARD_PORTFOLIO_ASSERT);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                if (jsonArray.length()>0){
                    JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                    mCardView.setVisibility(View.VISIBLE);
                    mTvNothing.setVisibility(View.GONE);

                    String userName = "";
                    if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                        String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                        if (levelNo.equals("98")){
                            mTvName.setText(getString(R.string.family_head));
                        }else{
                            mTvName.setText(UtilityKotlin.getClientHopObject(mSession).optString("name"));
                        }
                    } else {
                    String levelNo = mSession.getLevelNo();
                    if (levelNo.equals("98")) {
                        mTvName.setText(getString(R.string.family_head));
                    } else {
                        mTvName.setText(mSession.getPersonName());
                    }
                }
                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    format.setMinimumFractionDigits(0);
                    format.setMaximumFractionDigits(0);

                    double currentValue = jsonObjectSummary.optDouble("purchaseValue");
                    String strCurrentAmount = format.format(currentValue);
                    tvInvestment.setText(strCurrentAmount);

                    double soldValue = jsonObjectSummary.optDouble("sellValue");
                    String strsoldValue= format.format(soldValue);
                    mTvSold.setText(strsoldValue);


                    double purchaseValue = jsonObjectSummary.optDouble("currentValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    mTvCurrent.setText(strPurchaseValue);

                    double gaine = jsonObjectSummary.optDouble("gain");
                    String strGain = format.format(gaine);
                    mTvGain.setText(strGain);

                    UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-", "%", 2, false, mTvCgar);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        list.add(jsonObject1);
                    }
                    portfolio_client_adapter.updateList(list);
                }else{
                    mTvNothing.setVisibility(View.VISIBLE);
                }


            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getPortfolioFD() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            Date date = getOneDayEarlier();
            if (date != null) {
                dateObject.put("endDate", formatter.format(date));
            }
            jsonArray.put(dateObject);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioOtherAssetTable");

          

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +Config.GET_PORTFOLIO_ASSERT + "filters="+jsonArray.toString()+"&groupBy=fixedSubAssetid"
                    +"&pageSize=100&currentPage=1"+
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession) + "";
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        AppApplication.DASHBOARD_PORTFOLIO_ASSERT = response;
                        SetData();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                     
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
