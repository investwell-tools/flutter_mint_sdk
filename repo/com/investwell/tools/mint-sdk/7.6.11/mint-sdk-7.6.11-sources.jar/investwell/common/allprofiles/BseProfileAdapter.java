package investwell.common.allprofiles;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import investwell.utils.Utils;

public class BseProfileAdapter extends RecyclerView.Adapter<BseProfileAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnItemClickListener listener;
    private String mLoggedUserType = "";
    private String mType = "";
    private boolean mIsInvestmentProfile = false;

    public BseProfileAdapter(Context context, boolean isInvestmentProfile ,String type, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        mType = type;
        mIsInvestmentProfile = isInvestmentProfile;
        this.listener = listener;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_invest_profile, viewGroup, false);
        return new BseProfileAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final BseProfileAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject mJsonData, String name);

        void onProfileItemClick(int position);

        void onMandateItemClick(int position);

        void onNomineeItemClick(int position,JSONObject mJObject);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvManageProfile, tvAddMandate,tvActionName, tv_profile_name, tv_holding_status, tvUcc, tvJointHolderName, tvJointHolderName2;
        ImageView mIvActiveStatus, ivForward,ivAction;
        LinearLayout llNomineeApproval, llButtons, llDesableView;
        View mViewLine;
        CardView cvMain;

        public ViewHolder(View view) {
            super(view);
            tv_profile_name = view.findViewById(R.id.tv_profile_name);
            tvUcc = view.findViewById(R.id.tvUcc);
            tvActionName = view.findViewById(R.id.tvActionName);
            ivAction = view.findViewById(R.id.ivAction);
            tvJointHolderName = view.findViewById(R.id.tv_joint_holder_name);
            tvJointHolderName2 = view.findViewById(R.id.tv_joint_holder_name_2);
            tv_holding_status = view.findViewById(R.id.tv_holding_status);
            mIvActiveStatus = view.findViewById(R.id.ivStatus);
            llNomineeApproval = view.findViewById(R.id.llNomineeApproval);
            tvManageProfile = view.findViewById(R.id.tvManageProfile);
            tvAddMandate = view.findViewById(R.id.tvAddMandate);
            llButtons = view.findViewById(R.id.llButtons);
            mViewLine = view.findViewById(R.id.viewLine);
            cvMain = view.findViewById(R.id.cvMain);
            llDesableView = view.findViewById(R.id.llDesableView);
            ivForward = view.findViewById(R.id.ivForward);

        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final BseProfileAdapter.OnItemClickListener listener) {
            
            try {
                final JSONObject jsonObject = mDataList.get(position);
                mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_green);

                if (mIsInvestmentProfile) {
                    llButtons.setVisibility(View.GONE);
                    mViewLine.setVisibility(View.GONE);
                    ivForward.setVisibility(View.VISIBLE);
                    llNomineeApproval.setVisibility(View.GONE);
                } else {
                    llButtons.setVisibility(View.VISIBLE);
                    mViewLine.setVisibility(View.VISIBLE);
                    ivForward.setVisibility(View.GONE);

                    if (!jsonObject.optString("taxStatus").equalsIgnoreCase("null") && jsonObject.optString("taxStatus").equalsIgnoreCase("INDIVIDUAL")
                            && jsonObject.optString("nominationAuthDate").equalsIgnoreCase("null")){
                        llNomineeApproval.setVisibility(View.VISIBLE);
                    }else {
                        llNomineeApproval.setVisibility(View.GONE);
                    }
                }

                jsonObject.put("LoginUserType", mLoggedUserType);
                if ((!TextUtils.isEmpty(jsonObject.optString("JH1Name")) && !jsonObject.optString("JH1Name").equalsIgnoreCase("null"))
                || (!TextUtils.isEmpty(jsonObject.optString("jh1FirstName")) && !jsonObject.optString("jh1FirstName").equalsIgnoreCase("null"))) {

                    String jh1Name = jsonObject.optString("JH1Name");
                    if (jh1Name == null || jh1Name.isEmpty() || "null".equalsIgnoreCase(jh1Name)) {
                        jh1Name = Stream.of(
                                        jsonObject.optString("jh1FirstName"),
                                        jsonObject.optString("jh1MiddleName"),
                                        jsonObject.optString("jh1LastName"))
                                .filter(s -> s != null && !s.isEmpty() && !"null".equalsIgnoreCase(s))
                                .collect(Collectors.joining(" "));
                    }
                    tvJointHolderName.setText(jh1Name);

                    tvJointHolderName.setVisibility(View.VISIBLE);
                } else {
                    tvJointHolderName.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(jsonObject.optString("JH2Name")) && !jsonObject.optString("JH2Name").equalsIgnoreCase("null")) {

                    String jh2Name = jsonObject.optString("JH2Name");
                    if (jh2Name == null || jh2Name.isEmpty() || "null".equalsIgnoreCase(jh2Name)) {
                        jh2Name = Stream.of(
                                        jsonObject.optString("jh2FirstName"),
                                        jsonObject.optString("jh2MiddleName"),
                                        jsonObject.optString("jh2LastName"))
                                .filter(s -> s != null && !s.isEmpty() && !"null".equalsIgnoreCase(s))
                                .collect(Collectors.joining(" "));
                    }
                    tvJointHolderName2.setText(jh2Name);
                    tvJointHolderName2.setVisibility(View.VISIBLE);
                } else {
                    tvJointHolderName2.setVisibility(View.GONE);
                }
                if ((!TextUtils.isEmpty(jsonObject.optString("holding")) && !jsonObject.optString("holding").equalsIgnoreCase("null")) || (!TextUtils.isEmpty(jsonObject.optString("holdingNatureDescription")) && !jsonObject.optString("holdingNatureDescription").equalsIgnoreCase("null"))) {
                    tv_holding_status.setVisibility(View.VISIBLE);
                } else {
                    tv_holding_status.setVisibility(View.GONE);
                }

                if (mLoggedUserType.equalsIgnoreCase("broker")) {
                    tv_profile_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                    if ((!TextUtils.isEmpty(jsonObject.optString("holdingNatureDescription")) && !jsonObject.optString("holdingNatureDescription").equalsIgnoreCase("null"))
                    ) {
                        tv_holding_status.setText(" | "+Utils.setFirstLetterCapital(jsonObject.optString("holdingNatureDescription")));
                    } else {
                        tv_holding_status.setText(Utils.setFirstLetterCapital(jsonObject.optString("holdingNatureDescription")));
                    }
                    if (((!TextUtils.isEmpty(jsonObject.optString("ucc")) && !jsonObject.optString("ucc").equalsIgnoreCase("null"))
                    || ((!TextUtils.isEmpty(jsonObject.optString("nseUccCode")) && !jsonObject.optString("nseUccCode").equalsIgnoreCase("null"))))
                    ) {
                        String ucc = jsonObject.optString("ucc");
                        if (ucc == null || ucc.isEmpty() || "null".equalsIgnoreCase(ucc)) {
                            ucc = jsonObject.optString("nseUccCode");
                        }
                        tvUcc.setText(ucc);
                        tvUcc.setVisibility(View.VISIBLE);
                    } else {
                        tvUcc.setVisibility(View.GONE);
                    }
                } else {

                    String investorName = Utils.setFirstLetterCapital(
                            !jsonObject.optString("investorName").isEmpty()
                                    ? jsonObject.optString("investorName")
                                    : jsonObject.optString("name")
                    );
                    tv_profile_name.setText(investorName);

                    if ((!TextUtils.isEmpty(jsonObject.optString("holding")) && !jsonObject.optString("holding").equalsIgnoreCase("null"))
                    ) {
                        tv_holding_status.setText(" | "+Utils.setFirstLetterCapital(jsonObject.optString("holding")));
                    } else {
                        tv_holding_status.setText(Utils.setFirstLetterCapital(jsonObject.optString("holding")));

                    }

                    if (
                            ((!TextUtils.isEmpty(jsonObject.optString("uccNumber")) && !jsonObject.optString("uccNumber").equalsIgnoreCase("null")))
                            || ((!TextUtils.isEmpty(jsonObject.optString("nseUccCode")) && !jsonObject.optString("nseUccCode").equalsIgnoreCase("null")))
                    ) {
                        String uccNumber = !jsonObject.optString("uccNumber").isEmpty()
                                ? jsonObject.optString("uccNumber")
                                : jsonObject.optString("nseUccCode");
                        tvUcc.setText(uccNumber);
                        tvUcc.setVisibility(View.VISIBLE);
                    } else {
                        tvUcc.setVisibility(View.GONE);
                    }
                }

                if (jsonObject.has("nseUccCode")){
                    if (!jsonObject.optString("status").equalsIgnoreCase("active")){
                        mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_red);
                        if (mType.equalsIgnoreCase("showProfile")){
                            Drawable drawable = ContextCompat.getDrawable(mContext, R.drawable.refresh_icon);
                            ivAction.setImageDrawable(drawable);
                            ivAction.setVisibility(View.VISIBLE);
                            llNomineeApproval.setVisibility(View.VISIBLE);
                        }
                    }
                    tvAddMandate.setVisibility(View.GONE);
                    llNomineeApproval.setVisibility(View.GONE);
                    tvActionName.setVisibility(View.GONE);
                }

                itemView.setOnClickListener(v -> {
                    listener.onItemClick(position, jsonObject, tv_profile_name.getText().toString());
                });

                llNomineeApproval.setOnClickListener(v -> listener.onNomineeItemClick(position, jsonObject));
                tvManageProfile.setOnClickListener(v -> listener.onProfileItemClick(position));
                tvAddMandate.setOnClickListener(v -> listener.onMandateItemClick(position));
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }

        }

    }

    public void updateList(List<JSONObject> list, String mLoginType, Boolean isSearch) {
        if (isSearch) {
            mDataList.clear();
        }
        mLoggedUserType = mLoginType;
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
