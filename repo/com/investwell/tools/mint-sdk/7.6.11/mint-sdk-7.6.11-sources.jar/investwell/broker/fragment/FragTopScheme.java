package investwell.broker.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.broker.adapter.TopSchemeAdapter;
import investwell.broker.adapter.YearRecyclieviewAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragTopScheme extends BaseFragment {
    public static String TopInvest = "5 Years", mTopTime = "1Year";
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private AppApplication mAppplication;
    private ToolbarFragment fragToolBar;
    private RecyclerView mRvYears;
    private ShimmerFrameLayout mShimmerViewContainer;
    private ImageButton close_filters;
    private RecyclerView recyclerView;
    private String mCat, mTopS_AMC = "All", mTopS_Cat = "E", mTopS_Sort = "5Y", mTopS_TopNo = "50", mTopS_Rating = "0";
    private YearRecyclieviewAdapter adapter;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private boolean loading;
    private TopSchemeAdapter mAdapter;
    private int mCurrentPageNo = 1;
    private LinearLayout fullScreenShedow, mLinerNoDataFound;
    private RelativeLayout singleShedow;
    private String[] yearsValue;
    LinearLayoutManager mLayoutManager;
    private List<JSONObject> list;

    public FragTopScheme() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mAppplication = (AppApplication) mBrokerActivity.getApplication();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_frag_top_scheme, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        }
        initialize(view);
        mRvYears.setHasFixedSize(true);
        mRvYears.setLayoutManager(new LinearLayoutManager(mBrokerActivity, LinearLayoutManager.HORIZONTAL, false));
        adapter = new YearRecyclieviewAdapter(mBrokerActivity, yearsValue, new YearRecyclieviewAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

                switch (position) {
                    case 0:
                        mTopS_Sort = "15D";
                        mTopTime = "15Day";
                        break;
                    case 1:
                        mTopS_Sort = "30D";
                        mTopTime = "30Day";
                        break;
                    case 2:
                        mTopS_Sort = "3M";
                        mTopTime = "3Month";
                        break;
                    case 3:
                        mTopS_Sort = "6M";
                        mTopTime = "6Month";
                        break;
                    case 4:
                        mTopS_Sort = "1Y";
                        mTopTime = "1Year";
                        break;
                    case 5:
                        mTopS_Sort = "2Y";
                        mTopTime = "2Year";
                        break;
                    case 6:
                        mTopS_Sort = "3Y";
                        mTopTime = "3Year";
                        break;
                    case 7:
                        mTopS_Sort = "5Y";
                        mTopTime = "5Year";
                        break;
                    case 8:
                        mTopS_Sort = "10Y";
                        mTopTime = "10Year";
                        break;

                    case 9:
                        mTopS_Sort = "SI";
                        mTopTime = "sinceInceptionReturn";
                        break;

                }

                getTopScheme(mCurrentPageNo);
            }
        });
        mRvYears.setAdapter(adapter);
        new Handler().postDelayed(
                new Runnable() {
                    @Override
                    public void run() {
                        mRvYears.scrollToPosition(8);
                    }
                }, 100);
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();
                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 100;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getTopScheme(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        return view;
    }

    private void initialize(View view) {
        recyclerView = view.findViewById(R.id.recycleView);
        mRvYears = view.findViewById(R.id.years);
        singleShedow = view.findViewById(R.id.singleShedow);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        yearsValue = getResources().getStringArray(R.array.top_scheme_years_array);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mAdapter = new TopSchemeAdapter(new ArrayList<JSONObject>(), getContext());
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(mAdapter);
        setUpToolBar();
        getTopScheme(mCurrentPageNo);
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.txt_top_scheme),
                    true, false, false, false, false, false, false);
        }
    }

    private void getTopScheme(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        } else {
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";

        try {
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "topSchemesTable");

            url = "https://profitcentre.investwell.app/webapi/broker/utilities/getTopSchemes?filters=[]&orderBy=1Year&orderByDesc=true&pageSize=20&currentPage=1&selectedUser={}";


        } catch (Exception e) {
            System.out.println();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        loading = false;
                        list = new ArrayList<>();
                        if (pageNo > 1) {
                            list.addAll(mAdapter.mDataList);
                        }
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            recyclerView.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mLinerNoDataFound.setVisibility(View.GONE);
                                mAdapter.updateList(list);
                            } else {
                                mLinerNoDataFound.setVisibility(View.VISIBLE);
                                mAdapter.updateList(new ArrayList<JSONObject>());
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}



