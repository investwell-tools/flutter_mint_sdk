package investwell.textview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Build;
import android.util.AttributeSet;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import com.iw.mint.sdk.R;


public class AppTextViewValue extends AppCompatTextView {

    public AppTextViewValue(Context context) {
        super(context);
        init(null, context);
    }

    public AppTextViewValue(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(attrs, context);
    }

    public AppTextViewValue(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, context);
    }

    private void init(@Nullable AttributeSet attrs, Context context) {
        if (attrs == null) return;

        // Load attributes
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.CustomTextView);

        // Set font family
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int fontResId = typedArray.getResourceId(R.styleable.CustomTextView_customFontFamilyRes, -1);
            Typeface typeface = AppTextView.getCachedFont(context, fontResId != -1 ? fontResId : R.font.lato_bold);
            if (typeface != null) {
                setTypeface(typeface, getTypeface() != null ? getTypeface().getStyle() : Typeface.BOLD);
            }
        } else {
           /* String fontFamily = typedArray.getString(R.styleable.CustomTextView_customFontFamily);
            if (fontFamily != null) {
                Typeface typeface = Typeface.createFromAsset(getContext().getAssets(), "fonts/" + fontFamily);
                setTypeface(typeface);
            }else{
                this.setTypeface(Typeface.createFromAsset(getContext().getAssets(),   "Roboto-Bold.ttf"));
            }  */
        }


        // Set font color
        int textColor = typedArray.getColor(R.styleable.CustomTextView_customFontColorType, getCurrentTextColor());
        if (textColor == 0) {
            setTextColor(ContextCompat.getColor(context, R.color.white_black));
        } else if (textColor == 1) {
            setTextColor(ContextCompat.getColor(context, R.color.black_white));
        } else if (textColor == 2) {
            setTextColor(ContextCompat.getColor(context, R.color.primaryToGreenPrimary));
        } else if (textColor == 3) {
            setTextColor(ContextCompat.getColor(context, R.color.key_text_color));
        } else if (textColor == 4) {
            setTextColor(ContextCompat.getColor(context, R.color.value_text_color));
        } else if (textColor == 5) {
            setTextColor(ContextCompat.getColor(context, R.color.red_text_color));
        } else if (textColor == 6) {
            setTextColor(ContextCompat.getColor(context, R.color.default_text_color));
        } else if (textColor == 7) {
            setTextColor(ContextCompat.getColor(context, R.color.both_white));
        } else if (textColor == 8) {
            setTextColor(ContextCompat.getColor(context, R.color.both_black));
        } else if (textColor == 9) {
            setTextColor(ContextCompat.getColor(context, R.color.green_text_color));
        }
        else if(textColor == 10){
            setTextColor(ContextCompat.getColor(context, R.color.textView_button_color));
        }
        else if(textColor == 11){
            setTextColor(ContextCompat.getColor(context, R.color.lightBlack_lightGrey));
        }
        else if(textColor == 12){
            setTextColor(ContextCompat.getColor(context, R.color.purple_text_color));
        }
        else if(textColor == 13){
            setTextColor(ContextCompat.getColor(context, R.color.blue_text_color));
        }
        else if(textColor == 14){
            setTextColor(ContextCompat.getColor(context, R.color.orange_text_color));
        }
        else if(textColor == 15){
            setTextColor(ContextCompat.getColor(context, R.color.colorToolbarText));
        }
        else if(textColor == 16){
            setTextColor(ContextCompat.getColor(context, R.color.key_text_color_diamond_card));
        }
        else if(textColor == 17){
            setTextColor(ContextCompat.getColor(context, R.color.primaryToPurplePrimary));
        }
        else if(textColor == 18){
            setTextColor(ContextCompat.getColor(context, R.color.primaryToBluePrimary));
        }
        else {
            setTextColor(ContextCompat.getColor(context, R.color.black));
        }

        int textSize = typedArray.getInt(R.styleable.CustomTextView_customTextSizeType, (int) getTextSize());
        if (textSize == 0) {
            setTextSize(11);
        } else if (textSize == 1) {
            setTextSize(12);
        }else if (textSize == 2) {
            setTextSize(13);
        } else if (textSize == 3) {
            setTextSize(14);
        } else if (textSize == 4) {
            setTextSize(15);
        }else if (textSize == 5) {
            setTextSize(17);
        }else if (textSize == 6) {
            setTextSize(20);
        }else if (textSize == 7) {
            setTextSize(25);
        }else if (textSize == 8) {
            setTextSize(30);
        }else if (textSize == 9) {
            setTextSize(35);
        }else if (textSize == 10) {
            setTextSize(40);
        }else if (textSize == 11) {
            setTextSize(45);
        }else if (textSize == 12) {
            setTextSize(50);
        }else{
            setTextSize(14);
        }

        typedArray.recycle();
    }
}

