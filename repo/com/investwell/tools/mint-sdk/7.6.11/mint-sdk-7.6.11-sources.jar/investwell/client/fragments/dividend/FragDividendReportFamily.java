package investwell.client.fragments.dividend;

import static android.os.Build.VERSION.SDK_INT;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.KtorHelper.requestCallDownload;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.DividendReportFamilyAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.InputStreamVolleyRequest;
import investwell.utils.UtilityKotlin;


public class FragDividendReportFamily extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    RequestQueue requestQueue;
    DividendReportFamilyAdapter mDividendReportAdapter;
    private boolean loading = false;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentPageNo = 0;
    private int mFetchListsize = 15;
    private String groupByClient = "100";
    private String fromDate, toDate, fromToDate, changeNP;

    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow, nameSection;
    private TextView mTvNothing, mTvInvestorName, mTvDivReinvTotal, mTvDivPayTotal, mTvDivTdsTotal, mTvFromToDate;
    private ImageView mIvPrevDate, mIvNextDate;
    private ShimmerFrameLayout mShimmerViewContainer;
    RecyclerView mRvDividendReportDetail;
    CardView mclient_total;

    private List<JSONObject> mListFirstData;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;


    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    private void setUpToolBar(boolean isShowDownload) {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.dividend_report),
                    true, false, false, isShowDownload, false, false, false);
        }
        fragToolBar.setCallback(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }


    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_dividend_report, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mMainActivity.setMainVisibility(this, null);

        mclient_total = view.findViewById(R.id.client_total);
        mIvPrevDate = view.findViewById(R.id.ivPrevDate);
        mIvNextDate = view.findViewById(R.id.ivNextDate);
        mTvFromToDate = view.findViewById(R.id.tvFromToDate);

        mclient_total = view.findViewById(R.id.client_total);
        nameSection = view.findViewById(R.id.nameSection);
        mTvInvestorName = view.findViewById(R.id.investorName);
        mTvDivReinvTotal = view.findViewById(R.id.div_reinv_total);
        mTvDivPayTotal = view.findViewById(R.id.div_pay_total);
        mTvDivTdsTotal = view.findViewById(R.id.div_tds_total);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mTvNothing = view.findViewById(R.id.tvLoading);
        mTvNothing.setVisibility(View.GONE);

        // check feature permission feature1027 if exist then show download
        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
        boolean isShowDownload = false;
        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
            JSONObject mJsoObject = null;
            try {
                mJsoObject = new JSONObject(allowedFeatured);
                JSONArray jsonArray = mJsoObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.optJSONObject(i).has("feature1027")) {
                        isShowDownload = true;
                        break;
                    }
                }
                setUpToolBar(isShowDownload);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }


        mListFirstData = new ArrayList<>();

        mRvDividendReportDetail = view.findViewById(R.id.recycleView);
        mRvDividendReportDetail.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRvDividendReportDetail.setLayoutManager(mLayoutManager);
        mDividendReportAdapter = new DividendReportFamilyAdapter(getActivity(), this, new ArrayList<JSONObject>(), new DividendReportFamilyAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });

        mRvDividendReportDetail.setAdapter(mDividendReportAdapter);
        mRvDividendReportDetail.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 15;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getDividendReport(mCurrentPageNo, groupByClient);
                            }
                        }
                    }
                }
            }
        });

        fromToDate = this.getArguments().getString("fromToDate");
        changeNP = this.getArguments().getString("changeNP");
        if (fromToDate == null && changeNP == null) {
            fromToDate = getCurrentFinYear();
            fromDate = createFromDate(fromToDate);
            toDate = createToDate(fromToDate);
            mTvFromToDate.setText(fromToDate);
        } else {
            fromToDate = getCustomFinYear(fromToDate, changeNP);
            fromDate = createFromDate(fromToDate);
            toDate = createToDate(fromToDate);
            mTvFromToDate.setText(fromToDate);
        }

        getDividendReport(1, groupByClient);

        mIvPrevDate.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public void onClick(View v) {
                changeFY("prev", fromToDate);
            }
        });
        mIvNextDate.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("RestrictedApi")
            @Override
            public void onClick(View v) {
                changeFY("next", fromToDate);
            }
        });

    }

    private String createFromDate(String fromToDate) {
        String frDate = fromToDate.split("-")[0] + "-04-01";
        return frDate;
    }

    private String createToDate(String fromToDate) {
        String tDate = fromToDate.split("-")[1] + "-03-31";
        return tDate;
    }

    private String getCurrentFinYear(){
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
        int TodayDay = Calendar.getInstance().get(Calendar.DATE);
        String finYear = "";
        if (month < 3 ) {
            finYear = (year - 1) + "-" + year;
        }else if (month == 3 && TodayDay <=31) {
            finYear = (year - 1) + "-" + year;
        } else {
            finYear = year + "-" + (year + 1);
        }
        return finYear;
    }

    private String getCustomFinYear(String fromToDate, String changeNP) {
        String finYear = "";
        if (changeNP.equals("next")) {
            finYear = (Integer.parseInt(fromToDate.split("-")[0]) + 1) + "-" + (Integer.parseInt(fromToDate.split("-")[1]) + 1);
        }
        if (changeNP.equals("prev")) {
            finYear = (Integer.parseInt(fromToDate.split("-")[0]) - 1) + "-" + (Integer.parseInt(fromToDate.split("-")[1]) - 1);
        }
        return finYear;
    }

    private void changeFY(String chNP, String fromToDate) {
        getDataFromServer(chNP);
    }

    private void getDataFromServer(String chNP) {
        changeNP = chNP;
        if (fromToDate == null && changeNP == null) {
            fromToDate = getCurrentFinYear();
            fromDate = createFromDate(fromToDate);
            toDate = createToDate(fromToDate);
            mTvFromToDate.setText(fromToDate);
        } else {
            fromToDate = getCustomFinYear(fromToDate, changeNP);
            fromDate = createFromDate(fromToDate);
            toDate = createToDate(fromToDate);
            mTvFromToDate.setText(fromToDate);
        }
        getDividendReport(1, groupByClient);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                downloadFile2();
}
    }

    private void SetData(String data, final boolean isSaveTrue, int pageNo) {
        String uId = "";
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            JSONObject jsonObject1 = new JSONObject();
            if (UtilityKotlin.getClientHopObject(mSession).length() != 0) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
            }
        }
        List<JSONObject> list = new ArrayList<>();
        if (pageNo > 1) {
            list.addAll(mDividendReportAdapter.mDataList);
        }
        try {
            JSONObject jsonObject = null;
            jsonObject = new JSONObject(data);

            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                if (jsonObjectMain.length() > 0) {
                    JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                    JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                    mclient_total.setVisibility(View.VISIBLE);
                    nameSection.setVisibility(View.GONE);
                    mTvDivReinvTotal.setText(String.format("%.2f", jsonObjectSummary.optDouble("reinvest")));
                    mTvDivReinvTotal.setTextSize(15);
                    mTvDivPayTotal.setText(String.format("%.2f", jsonObjectSummary.optDouble("payout")));
                    mTvDivPayTotal.setTextSize(15);
                    mTvDivTdsTotal.setText(String.format("%.2f", jsonObjectSummary.optDouble("tdsAmount")));
                    mTvDivTdsTotal.setTextSize(15);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        jsonObject1.put("fromDate", fromDate);
                        jsonObject1.put("toDate", toDate);
                        list.add(jsonObject1);
                    }

                    if (isSaveTrue) {
                        mListFirstData.addAll(list);
                    }
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mRvDividendReportDetail.setVisibility(View.VISIBLE);

            if (list.size() > 0) {
                mTvNothing.setVisibility(View.GONE);
                mclient_total.setVisibility(View.VISIBLE);
                mDividendReportAdapter.updateList(list);

            } else {
                mTvNothing.setVisibility(View.VISIBLE);
                mclient_total.setVisibility(View.GONE);
                mDividendReportAdapter.updateList(list);
            }

        }

    }

    private void getDividendReport(final int pageNo, final String groupBy) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
            mRvDividendReportDetail.setVisibility(View.VISIBLE);
        } else {
            mRvDividendReportDetail.setVisibility(View.GONE);
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";
        try {
            JSONArray filterArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("fromDate", fromDate);
            jsonObject.put("toDate", toDate);
            filterArray.put(jsonObject);
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                JSONObject jsonObject1 = new JSONObject();
                if (UtilityKotlin.getClientHopObject(mSession).length() != 0) {
                    if (Utils.getSelectedLevelNo(mSession).equals("1")){
                        return;
                    }
                    jsonObject1.put("uid", Utils.getSelectedUid(mSession));
                    jsonObject1.put("levelNo", Utils.getSelectedLevelNo(mSession));
                    JSONObject jsonObject2 = new JSONObject();
                    jsonObject2.put("selectedUser", jsonObject1);
                    filterArray.put(jsonObject2);

                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                            + Config.GET_DIVIDEND_REPORT_CLIENT + "groupBy=" + groupBy + "&filters=" + filterArray.toString()
                            + "&orderByDesc=true" + "&pageSize=" + mFetchListsize + "&currentPage="
                            + pageNo + "&investorUid=" + Utils.getSelectedUid(mSession) ;
                } else {
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                            + Config.GET_DIVIDEND_REPORT_CLIENT + "groupBy=" + groupBy + "&filters=" + filterArray.toString()
                            + "&orderByDesc=true" + "&pageSize=" + mFetchListsize + "&currentPage="
                            + pageNo ;
                }
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_DIVIDEND_REPORT_CLIENT + "groupBy=" + groupBy + "&filters=" + filterArray.toString()
                        + "&orderByDesc=true" + "&pageSize=" + mFetchListsize + "&currentPage=" + pageNo;
            }
        } catch (Exception e) {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mRvDividendReportDetail.setVisibility(View.VISIBLE);
        }
        String finalurl = url+"&selectedUser="+Utils.getSelectedUserObject(mSession);
        finalurl = UtilityKotlin.setRefreshKeyInExistingApi(finalurl, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, finalurl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        loading = false;
                        SetData(response, false, pageNo);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRvDividendReportDetail.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        if (mBrokerActivity != null)
            requestQueue = Volley.newRequestQueue(mBrokerActivity);
        else
            requestQueue = Volley.newRequestQueue(mMainActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void downloadFile2() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }
        String url = "";
        try {
            // filter date
            JSONArray jsonArrayFilter = new JSONArray();
            jsonArrayFilter.put(new JSONObject().put("fromDate", fromDate));
            jsonArrayFilter.put(new JSONObject().put("toDate", toDate));

            JSONObject jsonObjectUID = new JSONObject();
            jsonObjectUID.put("uid", Utils.getSelectedUid(mSession));
            jsonObjectUID.put("levelNo", Utils.getSelectedLevelNo(mSession));
            jsonArrayFilter.put(new JSONObject().put("selectedUser", jsonObjectUID));

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_DIVIDEND_REPORT_PDF + "filters=" + jsonArrayFilter.toString() + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "dividendReport", "",new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(requireActivity(), getString(R.string.txt_successfully), getString(R.string.txt_dividend_report_download_successfully), "pdf", mFileSave,uri);
                        else{
                            mMainActivity.showCommonDownload(requireActivity(), getString(R.string.txt_successfully), getString(R.string.txt_dividend_report_download_successfully), "pdf", mFileSave,uri);

                        }
                    }
                });
        // https://finnovators.investwell.app/webapi/client/reports/getDividendReportPdf?filters=[{"fromDate":"2014-04-01"},{"toDate":"2015-03-31"},{"selectedUser":{"uid":"b21b2f3960a466bf417faf4ce1d94600","levelNo":"98"}}]&selectedUser={"uid":"b21b2f3960a466bf417faf4ce1d94600","levelNo":"98"}

    }


    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }

    private void requestMultiPermissions( String[] permissionList){
        List<String> permissionsToRequest = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)){

        }else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2();
        }
    });
}
