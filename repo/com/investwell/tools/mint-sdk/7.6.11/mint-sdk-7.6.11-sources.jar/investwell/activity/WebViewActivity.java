package investwell.activity;

import static investwell.utils.Extensions.resolveIsInternal;
import static investwell.utils.Extensions.setCustomUserAgent;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.iw.mint.sdk.R;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import investwell.di.core.BaseUrls;
import investwell.utils.AppSession;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class WebViewActivity extends BaseActivity {


    private WebView browser;
    String facebookUrl, twitterUrl;

    ProgressDialog dialog;
    ProgressBar loadingProgressBar;
    final Context context = this;

    private boolean isLoderAdded = false;
    private boolean isMultiwindowDisabled = false;
    public static Button login;
    int a = 0;
    public static boolean loginviewweb;
    SwipeRefreshLayout swipeRefreshLayout;
    private RelativeLayout rlToolbar;


    private static final String TAG = WebViewActivity.class.getSimpleName();
    private String mCM;
    private ValueCallback<Uri> mUM;
    private ValueCallback<Uri[]> mUMA;
    private final static int FCR = 1;
    private AppSession mSession;
    private String mTitle = "";
    private String mUrl = "";


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (Build.VERSION.SDK_INT >= 21) {
            Uri[] results = null;
            //Check if response is positive
            if (resultCode == Activity.RESULT_OK) {
                if (requestCode == FCR) {
                    if (null == mUMA) {
                        return;
                    }
                    if (intent == null || intent.getData() == null) {
                        //Capture Photo if no image available
                        if (mCM != null) {
                            results = new Uri[]{Uri.parse(mCM)};
                        }
                    } else {
                        String dataString = intent.getDataString();
                        if (dataString != null) {
                            results = new Uri[]{Uri.parse(dataString)};
                        }
                    }
                }
            }
            mUMA.onReceiveValue(results);
            mUMA = null;
        } else {
            if (requestCode == FCR) {
                if (null == mUM) return;
                Uri result = intent == null || resultCode != RESULT_OK ? null : intent.getData();
                mUM.onReceiveValue(result);
                mUM = null;
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mSession != null) {
            UtilityKotlin.checkReAuth(mSession, WebViewActivity.this);
        }

    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_web_view);
        Extensions.checkDevice(this);


        mSession = AppSession.getInstance(this);
        browser = (WebView) findViewById(R.id.webView);
        rlToolbar = findViewById(R.id.rlToolbar);
        TextView tvTitle = findViewById(R.id.tvTitle);


        tvTitle.setTextColor(ContextCompat.getColor(this,R.color.colorToolbarText));
        rlToolbar.setBackground(ContextCompat.getDrawable(this, R.color.colorToolbar));



        assert browser != null;
        WebSettings webSettings = browser.getSettings();
        if (isConnectingToInternet(getApplicationContext())) {
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                mTitle = extras.getString("title");
                isLoderAdded = extras.getBoolean("isLoderAdded");
                mUrl = extras.getString("url");
                boolean isInternal =resolveIsInternal(getIntent(), mUrl, () -> BaseUrls.baseUrl().replace("/webapi",""));
                setCustomUserAgent(browser,null,isInternal);

                isMultiwindowDisabled = extras.getBoolean("isMultiwindowDisabled");
                tvTitle.setText(mTitle);
                if (mTitle.equalsIgnoreCase("Facebook") || mTitle.equalsIgnoreCase("Twitter") || mTitle.equalsIgnoreCase("Instagram") || mTitle.equalsIgnoreCase("Linkedin") || mTitle.equalsIgnoreCase("Whatsapp")) {
                    webSettings.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.5845.110 Safari/537.36");
                } //browser.loadUrl(extras.getString("url"));
                browser.loadUrl(mUrl);
            }
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.txt_no_internet_connection), Toast.LENGTH_LONG).show();
        }


        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(browser, true);
        webSettings.setAllowFileAccess(true);
        if (!isMultiwindowDisabled) {
            webSettings.setSupportMultipleWindows(true);
        }
//        webSettings.setMixedContentMode(0);
        browser.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        browser.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {

                WebViewActivity.this.setProgress(progress * 5000);
            }
        });

        browser.setWebChromeClient(new WebChromeClient() {

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                AlertDialog.Builder builder = new AlertDialog.Builder(
                        WebViewActivity.this);
                builder.setMessage(message)
                        .setNeutralButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int arg1) {
                                dialog.dismiss();
                            }
                        }).show();
                result.cancel();
                return true;
            }
        });


        browser.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {

                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            }
        });

        browser.setWebViewClient(new WebViewClient());
        CookieManager.getInstance().setAcceptCookie(true);


        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.refresh);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                swipeRefreshLayout.setRefreshing(true);
                (new Handler()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        swipeRefreshLayout.setRefreshing(false);
                        browser.reload();
                    }
                }, 4000);
            }
        });

        findViewById(R.id.ivBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }


    public class WebViewClient extends android.webkit.WebViewClient {

        private void dismissDialog() {
            if (isLoderAdded) {
                if (ProgressBarCommon.isDialogVisible()) {
                    ProgressBarCommon.dismissDialog();
                }
            }

        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            if (isLoderAdded) {
                ProgressBarCommon.showDialog(WebViewActivity.this);
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            super.onReceivedError(view, request, error);
            dismissDialog();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (url == null || url.startsWith("http://") || url.startsWith("https://"))
                return false;
            if (url.endsWith(".pdf")) {
                browser.loadUrl("https://drive.google.com/viewerng/viewer?embedded=true&url=" + url);
            } else if (url.startsWith("whatsapp:")) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                return true;
            } else if (url.startsWith("https://chat.whatsapp.com/") || url.startsWith("https://wa.me/")) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.setPackage("com.whatsapp");
                try {
                    startActivity(intent); // Open in WhatsApp if installed
                } catch (ActivityNotFoundException e) {
                    view.loadUrl(url); // Fallback: open in WebView
                }
                return true;
            } else if (url.startsWith("intent")) {

                try {
                    Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);

                    String fallbackUrl = intent.getStringExtra("browser_fallback_url");
                    if (fallbackUrl != null) {
                        browser.loadUrl(fallbackUrl);
                        return true;
                    }
                } catch (URISyntaxException e) {
                    return true;//do nothing in other cases
                }
            }

            return true;//do nothing in other cases

        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!isFinishing() && isLoderAdded) {
                ProgressBarCommon.dismissDialog();
            }

        }
    }

    // Create an image file
    private File createImageFile() throws IOException {
        @SuppressLint("SimpleDateFormat") String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", new Locale("en", "in")).format(new Date());
        String imageFileName = "img_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(imageFileName, ".jpg", storageDir);
    }

    @Override
    public boolean onKeyDown(int keyCode, @NonNull KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                    if (browser.canGoBack()) {
                        browser.goBack();
                    } else {
                        finish();
                    }
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }


    private boolean isConnectingToInternet(Context applicationContext) {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        if (ni == null) {
            // There are no active networks.
            //  Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_LONG).show();
            WebViewActivity.this.finish();
            return false;
        } else return true;

    }


    private static final int TIME_INTERVAL = 2000; // # milliseconds, desired time passed between two back presses.
    private long mBackPressed;

    @Override
    public void onBackPressedHandled() {


        if (browser.canGoBack()) {
            browser.goBack();
        } else {
            super.onBackPressedHandled();
            finish();

        }
    }


}
