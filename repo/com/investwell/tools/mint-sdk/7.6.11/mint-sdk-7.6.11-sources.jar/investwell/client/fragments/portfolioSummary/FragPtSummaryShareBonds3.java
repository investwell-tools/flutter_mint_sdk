package investwell.client.fragments.portfolioSummary;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPtShareBondAdapter3;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;

import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mEndDate;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mMemberList;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mSelectedPosition;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mStartingDate;


public class FragPtSummaryShareBonds3 extends BaseFragment implements View.OnClickListener {
    private TextView mTvName, mTvCurrent, mTvTotalGain, mTvAbsolute,tvPurchageValue, tvGainLevel,
            mTvOneDayChange, tvDividend, tvCagr, tvQuantity, tvAvgPurchaseRate, tvMarketRate;
    RequestQueue requestQueue;
    private FragPtShareBondAdapter3 mAdapter;
    private RecyclerView mRecycleView;
    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mCardView;
    private String mGroupById = "1002";
    private LinearLayout mLinerNoData;
    private ToolbarFragment mFragToolBar;

    private AppApplication mAppplication;
    private boolean mIsActiveAssert = true;
    private JSONObject mPreviousObject;
    private String applicantUid= "";
    private CardView llMutualFund;


    @Override
    public void onResume() {
        super.onResume();
   /*     if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.share_amp_bond), true, false, false, false, false, false, false);
        }
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        JSONObject appConfigObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }
        } catch (Exception e) {

        }
        View view;
        if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
            view = inflater.inflate(R.layout.frag_share_bond3_layout6, container, false);
        } else {
            view = inflater.inflate(R.layout.frag_share_bond3, container, false);
        }


        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        setUpToolBar();
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("data")) {
            try {
                mPreviousObject = new JSONObject(bundle.getString("data"));
                if (mPreviousObject.has("applicantUid")){
                    applicantUid=mPreviousObject.optString("applicantUid");
                }
            } catch (Exception e) {

            }
        }

        llMutualFund = view.findViewById(R.id.llMutualFund);
        mTvName = view.findViewById(R.id.tvName);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
        mTvTotalGain = view.findViewById(R.id.tvTotalGain);
        tvCagr = view.findViewById(R.id.tvCagr);
        tvDividend = view.findViewById(R.id.tvDividend);
        mTvAbsolute = view.findViewById(R.id.tvAbsolute);
        mLinerNoData = view.findViewById(R.id.linerNoData);
        tvGainLevel = view.findViewById(R.id.tvGainLevel);
        tvPurchageValue = view.findViewById(R.id.tvPurchageValue);
        tvQuantity = view.findViewById(R.id.tvQuantity);
        tvAvgPurchaseRate = view.findViewById(R.id.tvAvgPurchaseRate);
        tvMarketRate = view.findViewById(R.id.tvMarketRate);

        mRecycleView = view.findViewById(R.id.recycleView);
        mRecycleView.setHasFixedSize(true);
        mRecycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mAdapter = new FragPtShareBondAdapter3(getActivity(), new ArrayList<JSONObject>(), new FragPtShareBondAdapter3.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                  /*  JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(15, bundle1);*/
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }

            @Override
            public void onSchemeClick(int position) {
             /*   JSONObject jsonObject = mAdapter.mDataList.get(position);
                Bundle bundle1 = new Bundle();
                bundle1.putString("schemeId", jsonObject.optString("schid"));
                Intent i = new Intent(mActivity, FactSheetActivity.class);
                i.putExtras(bundle1);
                startActivity(i);*/
            }
        });
        mRecycleView.setAdapter(mAdapter);

        getPtShareBondDetails();

        return view;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}

    }

    private void SetData(String data) {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        mCardView.setVisibility(View.VISIBLE);
        mLinerNoData.setVisibility(View.GONE);
        ArrayList<JSONObject> list = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("rows");
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");

                mTvName.setText(mPreviousObject.optString("schemeName"));

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);

                double purchaseValue = 0;
                if (jsonObjectSummary.has("purchaseValue")){
                    purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                }else{
                    purchaseValue = jsonObjectSummary.optDouble("remainingBalUnitsPurchaseValue");
                }

                String strpurchaseValue = format.format(purchaseValue);
                tvPurchageValue.setText(strpurchaseValue);

                if (mAppplication.isDaysChange) {
                    double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                    if (!Double.isNaN(oneDayChange)) {
                        String strOneDayChange = format.format(oneDayChange);
                        double changePercent = jsonObjectSummary.optDouble("changePercent");
                        String changePercentStr = String.format("%.2f", changePercent) + "%";
                        if (oneDayChange == 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.black));
                        } else if (oneDayChange > 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                        } else {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                        }
                    }else{
                        mTvOneDayChange.setVisibility(View.GONE);
                    }
                } else {
                    mTvOneDayChange.setVisibility(View.GONE);
                }

                double gain = jsonObjectSummary.optDouble("gain");
                Utils.checkNegativeAndPositiveValue(mTvTotalGain,gain,requireActivity());

                double CAGR = jsonObjectSummary.optDouble("CAGR");
                Utils.checkNegativeAndPositiveWithSign(tvCagr,CAGR,requireActivity());

     /*           double gain = jsonObjectSummary.optDouble("gain");
                String strTotalGain = format.format(gain);
                mTvTotalGain.setText(strTotalGain);*/

                double dividend = jsonObjectSummary.optDouble("dividend");
                String strDividend = format.format(dividend);
                tvDividend.setText(strDividend);

                double cgrValue = jsonObjectSummary.optDouble("absoluteReturn");
                String data2 = String.format("%.2f", cgrValue) + "%";
                mTvAbsolute.setText(data2);

          /*      double CAGR = jsonObjectSummary.optDouble("CAGR");
                String strCAGR = String.format("%.2f", CAGR) + "%";
                if (CAGR >= 0) {
                    tvCagr.setText("  (+" + strCAGR + ")");
                }else{
                    tvCagr.setText("  (" + strCAGR + ")");
                }
*/

                double longValue = jsonObjectSummary.optDouble("balanceUnits");
                if (longValue > 0) {
                    String data1 = String.format("%.4f", longValue);
                    tvQuantity.setText(data1);
                } else {
                    tvQuantity.setText("0");
                }

                double avgCost = jsonObjectSummary.optDouble("avgCost");
                String stravgCost = String.format("%.4f", avgCost) ;
                tvAvgPurchaseRate.setText(stravgCost);

                double currentPrice = jsonObjectSummary.optDouble("currentPrice");
                String strCurrentPrice = String.format("%.2f", currentPrice) ;
                tvMarketRate.setText(strCurrentPrice);


/*

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }
*/


            } else {
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        } finally {
          /*  if (list.size() > 0) {
                mLinerNoData.setVisibility(View.GONE);
                mAdapter.updateList(list, mGroupById);
            } else {
                mAdapter.updateList(list, mGroupById);
                mLinerNoData.setVisibility(View.VISIBLE);
                mCardView.setVisibility(View.GONE);
            }*/
        }

    }

    public void getPtShareBondDetails() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        mCardView.setVisibility(View.GONE);
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();

        String uId = "";
        String url = "";
        String levelNo = "";
        try {
            JSONObject jsonObject1 = new JSONObject();


            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
            String endDate = formatter.format(new Date());
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);

            JSONObject appIdObject = new JSONObject();
            appIdObject.put("appid", mPreviousObject.optString("appid"));
            jsonArray.put(appIdObject);

            JSONObject schemeIdObject = new JSONObject();
            String schemeId = Utils.getSchemeIdFromAll(mPreviousObject);
            schemeIdObject.put("schid", schemeId);
            jsonArray.put(schemeIdObject);


            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioShareBondTable");

            if (mSelectedPosition != 0) {
                JSONObject jsonObject4 = new JSONObject();
                JSONObject jsonObject4_1 = new JSONObject();
                JSONObject jsonObject = mMemberList.get(mSelectedPosition - 1);
                jsonObject4_1.put("levelNo", jsonObject.optString("levelNo"));
                uId = jsonObject.optString("uid");
                jsonObject4_1.put("uid", uId);
                jsonObject4.put("selectedUser", jsonObject4_1);
            } else {
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");

                } else {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                }
                jsonObject1.put("uid", uId);
                jsonObject1.put("levelNo", levelNo);
            }
            jsonArray.put(jsonObject1);



            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_PT_SUMMARY_SHAREBOND_DETAILS + "filters=" + jsonArray.toString()
                    + "&pageSize=100&currentPage=1" +
                    "&investorUid=" + uId + "&selectedUser=" + jsonObject1.toString() + "&clubTxns=true";

         //   https://finnovators.investwell.app/webapi/client/dashboard/getDetailedPortFolioReturnsForShareAndBond?
            //   filters=[{"endDate":"2021-01-24"},
            //   {"selectedUser":{"uid":"ebdb5b74f9c1d8b17dcb7dd88f65c467","levelNo":98}},
            //   {"casArnOption":"0"},{"appid":"0463f938ad93181d2a9bb9f5426df422"},
            //   {"schid":"18b62d18bcf410d8e2d65848dd9a4a56"}]&componentForLoader=
            //   {"componentName":"folioShareBondTable"}&pageSize=100&currentPage=1
            //   &clubTxns=true
        } catch (Exception e) {

        }
        String mUrl = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, mUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        SetData(response);
                        if (!isAdded()){
                            return;
                        }
                        getPtShareBondHistory();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession,getMCurrentActivity());
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    public void getPtShareBondHistory() {
        if (!isAdded())
            return;
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String uId = "";
        String url = "";
        String levelNo = "";
        try {
            JSONObject jsonObject1 = new JSONObject();

            JSONArray jsonArray = new JSONArray();
            JSONObject schemeIdObject = new JSONObject();
            String schemeId = Utils.getSchemeIdFromAll(mPreviousObject);
            schemeIdObject.put("schid", schemeId);
            jsonArray.put(schemeIdObject);

            JSONObject applicantObject = new JSONObject();
            applicantObject.put("applicantUid", applicantUid);
            jsonArray.put(applicantObject);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "transactionsTable");

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            jsonObject1.put("uid", uId);
            jsonObject1.put("levelNo", levelNo);


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_SHARE_BOND_TRAN_HIST + "filters=" + jsonArray.toString()
                    + "&pageSize=500&currentPage=1" +
                    "&investorUid=" + uId + "&selectedUser=" + jsonObject1.toString() + "&clubTxns=true";

            //  https://investmentlocker.investwell.app/webapi/client/shares/getShareBondTxns?
            //  filters=[{"fromDate":"2019-01-01"},{"toDate":"2023-10-25"},{"schid":"89395f85d1e52b13912d9dbd7d0b1a7c"}]
            //  &currentPage=1&pageSize=20&componentForLoader={"componentName":"transactionsTable"}
            //  &clubTxns=true&investorUid=319cc526e84d2af379cfdd2218a91870&selectedUser=
            //  {"uid":"319cc526e84d2af379cfdd2218a91870","levelNo":"98"}&refreshKey="2023-10-25T08:45:18.399Z"
        } catch (Exception e) {

        }
        String mUrl =UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, mUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        ArrayList<JSONObject> list = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                                    list.add(jsonObject1);
                                }
                            }
                        }catch (Exception e){

                        }finally {
                            if (list.size() > 0) {
                                mAdapter.updateList(list, mGroupById);
                                llMutualFund.setVisibility(View.VISIBLE);
                                mLinerNoData.setVisibility(View.GONE);
                            } else {
                                mAdapter.updateList(list, mGroupById);
                                mLinerNoData.setVisibility(View.VISIBLE);
                                llMutualFund.setVisibility(View.GONE);
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }



}
