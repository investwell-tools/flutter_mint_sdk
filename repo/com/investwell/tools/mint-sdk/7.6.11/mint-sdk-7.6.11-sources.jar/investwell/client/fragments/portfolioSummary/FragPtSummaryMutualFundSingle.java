package investwell.client.fragments.portfolioSummary;

import static android.os.Build.VERSION.SDK_INT;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;
import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UtilityKotlin.getOneDayEarlier;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.client.adapter.FragPtSortingAdapter;
import investwell.client.adapter.FragPtSummaryListInSideListAdapter;
import investwell.di.viewmodel.ApiClient;
import investwell.textview.AppTextViewTitle;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.KtorHelper;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;


import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.UtilityKotlin;
import investwell.utils.WhatsAppShare;
import investwell.utils.customView.CustomDialog;


public class FragPtSummaryMutualFundSingle extends BaseFragment implements View.OnClickListener, FragPtSummaryListInSideListAdapter.OnAllCardsCollapsedListener, CustomDialog.DialogBtnCallBack {
    private TextView mTvCurrent, mTvTotalGain, mTvXirr, mTvOneDayChange;
    private TextView mTvStartDateP, mTvEndDateP, tvValuationDate;

    RequestQueue requestQueue;
    private FragPtSummaryListInSideListAdapter mAdapter;
    FragPtSortingAdapter mSortingAdapter;

    private ClientActivity mActivity;
    private AppSession mSession;
    private LinearLayout mCardView;
    private final String mGroupById = "1005";
    private String mAppUid = "";
    public static String mStartingDate = "", mEndDate = "", mValuationDate;

    private String mAppLevelNo = "";
    private LinearLayout mLinerNoData;
    private AppApplication mAppplication;
    private JSONObject mClientObject;

    private String mSortingType = "";

    private String mClientName = "";
    private ApiDataBase db;
    private TextView tvPurchageValue, tvCagrLavel, tvPurchaseLevel, tvCagr;
    private ImageView ivGainLoss, ivGainInfo;

    private ArrayList<JSONObject> mFirstSchemeList;
    private ArrayList<JSONObject> mFilterArrayList;
    RecyclerView mRecycleView;
    private View view;

    private View viewLineTotalGain;
    private ConstraintLayout relOverallGainLayout;
    private String OverAllGainData = "";
    private TextView tvOverallGainInPercentage, tvOverallGain;
    private ProgressBar pbLoaderOnArn;
    private LinearLayout llExpandCollapseAll, llFilterNoData, llFilter;
    private ImageView ivExpandCollapseAllArrow;
    private TextView tvExpandCollapseAllText;
    private boolean areAllExpanded;
    private View viewFilterIndicator, viewFilterIndicatorNoData;
    private ImageView ivFilter, ivFilterNoData;
    private ShimmerFrameLayout mShimmerViewContainer;
    private NestedScrollView nestedScrollView;

    private AppTextViewTitle  mTvName;

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog alertDialog;
    private LinearLayout mLinFilterPart, mLinerCustomDurationP;
    private ImageView ivCloseFilter;
    private RadioGroup radioGroupPortfolio;
    private String mSelectedTime = "";






    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(url, req, res, AppConstants.PORTFOLIO_DETAIL, dateTime, endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (view == null) {
            view = inflater.inflate(R.layout.frag_pt_summary_mutuatfund_single, container, false);
            db = ApiDataBase.getInstance(mActivity.getApplicationContext());

            LinearLayout llToolbar = view.findViewById(R.id.llToolbar);
            TextView tvToolbarTitle = view.findViewById(R.id.tvToolbarTitle);
            ImageView ivShare = view.findViewById(R.id.ivShare);
            ImageView ivPdfDownload = view.findViewById(R.id.ivPdfDownload);
            boolean isShowDownloadAndShareButton = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature1011",Permissions.VIEW) || UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature1012",Permissions.VIEW);
            if(isShowDownloadAndShareButton){
                ivShare.setVisibility(View.VISIBLE);
                ivPdfDownload.setVisibility(View.VISIBLE);
            }
            else{
                ivShare.setVisibility(View.GONE);
                ivPdfDownload.setVisibility(View.GONE);
            }
            mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
            nestedScrollView = view.findViewById(R.id.nestedScrollView);
            tvToolbarTitle.setText(getString(R.string.portfolio));
            ivShare.setOnClickListener(this);
            ivPdfDownload.setOnClickListener(this);
            view.findViewById(R.id.ivBack).setOnClickListener(this);

            viewLineTotalGain = view.findViewById(R.id.viewLineTotalGain);
            relOverallGainLayout = view.findViewById(R.id.relOverallGainLayout);
            tvOverallGainInPercentage = view.findViewById(R.id.tvOverallGainInPercentage);
            pbLoaderOnArn = view.findViewById(R.id.pbLoaderOnArn);
            tvOverallGain = view.findViewById(R.id.tvOverallGain);
            tvCagr = view.findViewById(R.id.tvCagr);


          /*  try{
                JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
                String lightColorShade = appConfigObject.optString("lightColorShade");
                if (lightColorShade.length()>0) {
                    //50% — 80, 40% — 66, 30% — 4D, 20% — 33, 10% — 1A
                    String lightColorShade2 = "#4d" + lightColorShade.replace("#", ""); //10 opacity
                    int[] colors = {Color.parseColor(lightColorShade), Color.parseColor(lightColorShade2)};
                    GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, colors);
                    gd.setCornerRadius(30f);
                    llTopCard.setBackground(gd);
                }
            }catch (Exception e){
                System.out.println();

            }*/

            mFirstSchemeList = new ArrayList<>();
            mFilterArrayList = new ArrayList<>();
            if (mSession.getPtFilterType().equals("")) {
                mSortingType = "category";
            } else {
                mSortingType = mSession.getPtFilterType();
            }

            mCardView = view.findViewById(R.id.top_layout);
            tvPurchageValue = view.findViewById(R.id.tvPurchageValue);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvTotalGain = view.findViewById(R.id.tvTotalGain);
            mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
            mLinerNoData = view.findViewById(R.id.linerNoData);

            ivGainLoss = view.findViewById(R.id.ivGainLoss);
            tvCagrLavel = view.findViewById(R.id.tvCagrLavel);
            ivGainInfo = view.findViewById(R.id.ivGainInfo);
            ivGainInfo.setOnClickListener(v -> showGainInfoDialog());
            view.findViewById(R.id.iv_overall_gain_info).setOnClickListener(v ->
                    mActivity.showGainInfoDialog(getString(R.string.dialog_overall_gain_info_dashboard)));

            tvPurchaseLevel = view.findViewById(R.id.tvPurchaseLevel);
            mTvName = view.findViewById(R.id.tvName);
            viewFilterIndicator = view.findViewById(R.id.viewFilterIndicator);
            viewFilterIndicatorNoData = view.findViewById(R.id.viewFilterIndicatorNoData);
            ivFilter = view.findViewById(R.id.ivFilter);
            ivFilterNoData = view.findViewById(R.id.ivFilterNoData);

            LinearLayout relSort = view.findViewById(R.id.relSort);
            llFilter = view.findViewById(R.id.llFilter);
            llFilterNoData = view.findViewById(R.id.llFilterNoData);

            relSort.setOnClickListener(this);
            llFilter.setOnClickListener(this);
            llFilterNoData.setOnClickListener(this);
            mRecycleView = view.findViewById(R.id.recycleView);
            mRecycleView.setHasFixedSize(true);

            llExpandCollapseAll = view.findViewById(R.id.ll_expand_collapse_all);
            ivExpandCollapseAllArrow = view.findViewById(R.id.iv_expand_collapse_all_arrow);
            tvExpandCollapseAllText = view.findViewById(R.id.tv_expand_collapse_all_text);


            Bundle bundle = getArguments();
            if (bundle != null && bundle.containsKey("data")) {
                try {
                    if(Utils.getSelectedLevelNo(mSession).equals("98"))
                        llFilter.setVisibility(View.GONE);
                      else
                        llFilter.setVisibility(View.VISIBLE);

                    mClientObject = new JSONObject(bundle.getString("data"));
                    mAppUid = mClientObject.optString("uid");
                    mAppLevelNo = mClientObject.optString("levelNo");
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }

            if (bundle != null && bundle.containsKey("isHideToolBar")) {
                if (bundle.getBoolean("isHideToolBar")) {
                    llToolbar.setVisibility(View.GONE);


                    if (mSession.getHasShowXirr()) {
                        relOverallGainLayout.setVisibility(View.GONE);
                        viewLineTotalGain.setVisibility(View.GONE);
                    } else {
                        try {
                            JSONObject appConfigObject = new JSONObject();
                            if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
                                appConfigObject = new JSONObject(mSession.getAppInfo());
                            }
                            if ((!TextUtils.isEmpty(appConfigObject.optString("showInvestmentSummary")) && !appConfigObject.optString("showInvestmentSummary").equalsIgnoreCase("null")) && appConfigObject.optString("showInvestmentSummary").equalsIgnoreCase("1")) {
                                relOverallGainLayout.setVisibility(View.VISIBLE);
                                viewLineTotalGain.setVisibility(View.VISIBLE);
                                if (OverAllGainData.equals("")) {
                                    getOverallGainApi();
                                } else {
                                    setOverAllGain();
                                }

                            } else {
                                relOverallGainLayout.setVisibility(View.GONE);
                                viewLineTotalGain.setVisibility(View.GONE);
                            }

                        } catch (Exception e) {

                        }
                    }


                } else {
                    llToolbar.setVisibility(View.VISIBLE);
                    relOverallGainLayout.setVisibility(View.GONE);
                    viewLineTotalGain.setVisibility(View.GONE);

                }
            }


            mRecycleView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
            mAdapter = new FragPtSummaryListInSideListAdapter(getActivity(), new ArrayList<>());
            mSortingAdapter = new FragPtSortingAdapter(getActivity(), new ArrayList<>(), new FragPtSortingAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int position) {

                }

                @Override
                public void onSchemeClick(int position) {

                }
            });
            mRecycleView.setAdapter(mAdapter);
            //  mRecycleView.setAdapter(mSortingAdapter);


              SetData();

            //expand collapse of asset card in categpory
            mAdapter.setOnAllCardsCollapsedListener(this);
            areAllExpanded = mSession.getPortfolioAssetCardExpandCollapseStatus();
            mAdapter.setAreAllExpanded(areAllExpanded);
            updateUIOfExpandCollapse(areAllExpanded);

            llExpandCollapseAll.setOnClickListener(v -> {
                areAllExpanded = !areAllExpanded;
                updateUIOfExpandCollapse(areAllExpanded);
                mAdapter.setAreAllExpanded(areAllExpanded);
                mSession.setPortfolioAssetCardExpandCollapseStatus(areAllExpanded);
            });
        }

        return view;
    }

    private void showGainInfoDialog() {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireContext(), R.style.CustomAlertDialog);

        builder.setTitle(getString(R.string.overall_gain));
        builder.setMessage(getString(R.string.dialog_gain_info_portfolio));
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        androidx.appcompat.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    public void updateUIOfExpandCollapse(boolean areAllExpanded) {
        if (areAllExpanded) {
            llExpandCollapseAll.announceForAccessibility(getString(R.string.all_mutual_funds_expanded));
            ivExpandCollapseAllArrow.setImageResource(R.mipmap.home3_up_arrow);
            tvExpandCollapseAllText.setText(getString(R.string.collapse_all));
        } else {
            llExpandCollapseAll.announceForAccessibility(getString(R.string.all_mutual_funds_collapsed));
            ivExpandCollapseAllArrow.setImageResource(R.mipmap.home3_down_arrow);
            tvExpandCollapseAllText.setText(getString(R.string.expand_all));
        }
    }

    @Override
    public void onAllFlxFormCardsCollapsed() {
        areAllExpanded = false;
        mSession.setPortfolioAssetCardExpandCollapseStatus(areAllExpanded);
        ivExpandCollapseAllArrow.setImageResource(R.mipmap.home3_down_arrow);
        tvExpandCollapseAllText.setText(getString(R.string.expand_all));
    }

    @Override
    public void onAllFlxFormCardsExpanded() {
        areAllExpanded = true;
        mSession.setPortfolioAssetCardExpandCollapseStatus(areAllExpanded);
        ivExpandCollapseAllArrow.setImageResource(R.mipmap.home3_up_arrow);
        tvExpandCollapseAllText.setText(R.string.collapse_all);
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvSTartp) {
                datePicker(true, false);
        }
else if (v.getId() == R.id.tvEndp || v.getId() == R.id.tvEnd) {
                datePicker(false, false);
}
else if (v.getId() == R.id.apply_btnP) {
                if (!mSelectedTime.equals("CU")) {
//                    isClickedApply = true;
                    if (alertDialog.isShowing()) {
                        alertDialog.dismiss();
                    }
                    downloadFileSummary();
                } else {
                    if (!mStartingDate.isEmpty() && !mEndDate.isEmpty()) {
                        if (alertDialog.isShowing()) {
                            alertDialog.dismiss();
                        }
                        downloadFileSummary();
                    } else {
                        Toast.makeText(mAppplication, getString(R.string.please_choose_time_period), Toast.LENGTH_SHORT).show();
                    }
                }
}
else if (v.getId() == R.id.tvSTart) {
                System.out.println();
                datePicker(true, false);
}
else if (v.getId() == R.id.ivClose_performance) {
                alertDialog.dismiss();
}
else if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}
else if (v.getId() == R.id.ivPdfDownload) {
                showPopMenuItemDownload(v);
}
else if (v.getId() == R.id.ivShare) {
                showPopMenuItemShare(v);
}
else if (v.getId() == R.id.relSort) {
                showFilterPopup();
}
else if (v.getId() == R.id.ivBack) {
                getActivity().getSupportFragmentManager().popBackStack();
}
else if (v.getId() == R.id.llFilter) {
}
else if (v.getId() == R.id.llFilterNoData) {
                showFilterBottomSheet();
}

    }
    private void showFilterBottomSheet() {
        Fragment fragment = getChildFragmentManager().findFragmentByTag("BottomSheetPortfolioFilter");
        if (fragment instanceof BottomSheetPortfolioFilter bottomSheet) {
            bottomSheet.showBottomSheet();
        } else {
            boolean isCagr = !mSession.getHasShowXirr();
            BottomSheetPortfolioFilter newFragment = BottomSheetPortfolioFilter.newInstance(isCagr, false);
            newFragment.setClicked(true);
            newFragment.show(getChildFragmentManager(), "BottomSheetPortfolioFilter");
        }
    }


    @SuppressLint("AccessibilityFocus")
    private void SetData() {
        mCardView.setVisibility(View.VISIBLE);
        mLinerNoData.setVisibility(View.GONE);
        mFirstSchemeList = new ArrayList<>();
        mFilterArrayList = new ArrayList<>();

        try {
            JSONObject jsonObjectSummary = mClientObject.optJSONObject("summary");

            NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
            format.setMinimumFractionDigits(0);
            format.setMaximumFractionDigits(0);

            if (mClientObject.has("name")) {
                mClientName = mClientObject.optString("name");
            } else {
                mClientName = mClientObject.optString("applicantName");
            }
            mTvName.setText(mClientName);

            double currentValue = jsonObjectSummary.optDouble("currentValue");
            String strCurrentAmount = format.format(currentValue);
            mTvCurrent.setText(strCurrentAmount);

            if (mAppplication.isDaysChange) {
                double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                String strOneDayChange = format.format(oneDayChange);
                double changePercent = jsonObjectSummary.optDouble("changePercent");
                String changePercentStr = String.format("%.2f", changePercent) + "%";
                if (oneDayChange == 0) {
                    mTvOneDayChange.setVisibility(View.VISIBLE);
                    mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                    mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.default_text_color));
                } else if (oneDayChange > 0) {
                    mTvOneDayChange.setVisibility(View.VISIBLE);
                    mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                    mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.green_text_color));
                } else {
                    //  ivGainLoss.setImageResource(R.mipmap.home3_triangle_loss);
                    mTvOneDayChange.setVisibility(View.VISIBLE);
                    mTvOneDayChange.setText(strOneDayChange + " (" + changePercentStr + ")");
                    mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.red_text_color));
                }
            } else {
                mTvOneDayChange.setVisibility(View.GONE);
            }

            /*showXIRR  == its represent to show xirr view
              hideXirr = hide xirr value*/

            if (mSession.getHasShowXirr()) {
                tvCagrLavel.setText(getString(R.string.overall_gain));
                ivGainInfo.setVisibility(View.VISIBLE);
                if (mSession.getHideXirr().equals("0")) {
                    tvPurchaseLevel.setText(getString(R.string.XIRR));

                    UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-", "%", 2, true, tvPurchageValue);
                } else {
                    tvPurchaseLevel.setVisibility(View.GONE);
                    tvPurchageValue.setVisibility(View.GONE);
                }

                /*double totalGain = jsonObjectSummary.optDouble("gain");
                String gainValue = format.format(totalGain);
                mTvTotalGain.setText(gainValue);*/
                double gain = jsonObjectSummary.optDouble("gain");
                Utils.checkNegativeAndPositiveValue(mTvTotalGain, gain, requireActivity());

                RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
                params.addRule(RelativeLayout.ALIGN_PARENT_END);
                params.setMargins(0, 0, 55, 0);
                mTvTotalGain.setLayoutParams(params);
            } else {
                tvPurchaseLevel.setText(getString(R.string.PurchaseCost));
                tvCagrLavel.setText(getString(R.string.gain_cagr));
                ivGainInfo.setVisibility(View.GONE);

                double gain = jsonObjectSummary.optDouble("gain");
                Utils.checkNegativeAndPositiveValue(mTvTotalGain, gain, requireActivity());

                double cgrValue = jsonObjectSummary.optDouble("CAGR");
                Utils.checkNegativeAndPositiveWithSign(tvCagr, cgrValue, mActivity);
             /*   double cgrValue = jsonObjectSummary.optDouble("CAGR");
                String data2 = String.format("%.2f", cgrValue) + "%";

                double totalGain = jsonObjectSummary.optDouble("gain");
                String gainValue = format.format(totalGain);
                String finalValue = gainValue + " (" + data2 + ")";
                mTvTotalGain.setText(finalValue);

                if (totalGain > 0) {
                    mTvTotalGain.setTextColor(ContextCompat.getColor(requireActivity(), R.color.green_text_color));
                } else {
                    mTvTotalGain.setTextColor(ContextCompat.getColor(requireActivity(), R.color.red_text_color));
                }*/

                double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                String strPurchaseValue = format.format(purchaseValue);
                tvPurchageValue.setText(strPurchaseValue);
            }

            JSONArray jsonArray = mClientObject.optJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                mFirstSchemeList.add(jsonObject1);

                JSONArray jsonArray1 = jsonObject1.optJSONArray("data");
                for (int j = 0; j < jsonArray1.length(); j++) {
                    JSONObject schemeObject = jsonArray1.optJSONObject(j);
                    mFilterArrayList.add(schemeObject);
                }
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();

        } finally {
            if (mFirstSchemeList.size() > 0) {
                llFilterNoData.setVisibility(View.GONE);
                mCardView.setVisibility(View.VISIBLE);
                if (mSortingType.length() > 0) {//category
                    sortingScheme();
                } else {
                    mLinerNoData.setVisibility(View.GONE);
                    mAdapter.updateList(mFirstSchemeList, mClientName);
                }
                if (llFilter.isShown()) {
                    llFilter.performAccessibilityAction(
                            AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS,
                            null
                    );
                }

            } else {
                mCardView.setVisibility(View.GONE);
                mAdapter.updateList(mFirstSchemeList, mClientName);
                if(!Utils.getSelectedLevelNo(mSession).equals("98"))
                   llFilterNoData.setVisibility(View.VISIBLE);
                mLinerNoData.setVisibility(View.VISIBLE);
            }
        }
    }

    private void setOverAllGain() {
        try {
            JSONObject jsonObject = new JSONObject(OverAllGainData);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double oneDayChange = jsonObjectMain.optDouble("netGain");
                //  Utils.setRuppesSymbol(tvOverallGain, oneDayChange, mActivity);
                Utils.checkNegativeAndPositiveValue(tvOverallGain, oneDayChange, mActivity);

                UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectMain, "XIRR", "", "%", 2, true, tvOverallGainInPercentage,true);

            }

        } catch (Exception e) {

        }
    }


    private void getOverallGainApi() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            JSONArray jsonArrayTop = new JSONArray();
            JSONArray jsonArrayInside = new JSONArray();
            JSONObject jsonObjectTop = new JSONObject();
            JSONObject jsonObjectMf = new JSONObject();
            jsonObjectMf.put("name", "MF");
            jsonObjectMf.put("isRequired", true);
            jsonArrayInside.put(jsonObjectMf);
            jsonObjectTop.put("products", jsonArrayInside);
            jsonArrayTop.put(jsonObjectTop);

            JSONObject selectedUSer = new JSONObject();
            selectedUSer.put("uid", mAppUid);
            selectedUSer.put("levelNo", mAppLevelNo);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_DASHBOARD_XIRR
                    + "preferences=" + jsonArrayTop + "&investorUid=" + mAppUid
                    + "&selectedUser=" + selectedUSer +
                    "&levelNo=" + mAppLevelNo;

            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        KtorHelper.requestCall(
                requireContext(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {

                    @Override
                    public void onLoading(boolean isLoading){
                        if(isLoading){
                            pbLoaderOnArn.setVisibility(View.VISIBLE);

                            tvOverallGainInPercentage.setVisibility(View.GONE);
                            tvOverallGain.setVisibility(View.GONE);
                        }
                        else{
                            pbLoaderOnArn.setVisibility(View.GONE);

                            tvOverallGainInPercentage.setVisibility(View.VISIBLE);
                            tvOverallGain.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {
                        OverAllGainData = response;
                        setOverAllGain();
                    }
                }
        );


    }


    public void getPtSummaryMutualFund() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        nestedScrollView.setVisibility(View.GONE);
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.startShimmer();

        String url = "";
        try {
            @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
            JSONArray jsonArray = new JSONArray();

            JSONObject selectedUser = new JSONObject();
            selectedUser.put("uid", mAppUid);
            selectedUser.put("levelNo", mAppLevelNo);

            JSONObject selectedObject = new JSONObject();
            selectedObject.put("selectedUser", selectedUser);

            jsonArray.put(selectedObject);

            JSONObject dataSourceObj = new JSONObject();
            dataSourceObj.put("dataSource",  mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSourceObj);

            if (mSession.getHasShowXirr()) {
                JSONObject activeFolioObject = new JSONObject();
                activeFolioObject.put("activeFoliosOnly", mActivity.ptMFSelectedFilter.getSecond());
                jsonArray.put(activeFolioObject);

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.XIRR_PORTFOLIO_RETURN_NEW_API +
                        "&filters=" + jsonArray +
                        "&investorUid=" + mAppUid +
                        "&selectedUser=" + selectedObject;
            }
            else {
                JSONObject dateObject = new JSONObject();
                Date date = getOneDayEarlier();
                if (date != null) {
                    dateObject.put("endDate", formatter.format(date));
                }
                jsonArray.put(dateObject);
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CAGR_PORTFOLIO_RETURN_NEW_API +
                        "filters=" + jsonArray +
                        "&investorUid=" + mAppUid +
                        "&selectedUser=" + selectedObject;

            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        String finalUrl = url;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_PT_SUMMARY_MUTUALFUND);
                nestedScrollView.setVisibility(View.VISIBLE);
                mShimmerViewContainer.setVisibility(View.GONE);
                mShimmerViewContainer.stopShimmer();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                        JSONObject jsonObject1 = jsonArray.optJSONObject(0);
                        mClientObject = jsonObject1;
                        SetData();
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    // updateViewPagerView(true, new JSONObject());
                }
                //  SetDataWithLiveResponse(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                nestedScrollView.setVisibility(View.VISIBLE);
                mShimmerViewContainer.setVisibility(View.GONE);
                mShimmerViewContainer.stopShimmer();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showFilterPopup() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = (LayoutInflater) requireActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_portfolio_filter, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();

        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);

        RadioGroup radioGroup = dialogView.findViewById(R.id.radioGroup);
        ImageView ivClose = dialogView.findViewById(R.id.ivClose);

        RadioButton radio1 = dialogView.findViewById(R.id.radio1);
        RadioButton radio2 = dialogView.findViewById(R.id.radio2);
        RadioButton radio3 = dialogView.findViewById(R.id.radio3);
        RadioButton radio4 = dialogView.findViewById(R.id.radio4);
        RadioButton radio5 = dialogView.findViewById(R.id.radio5);
        RadioButton radio6 = dialogView.findViewById(R.id.radio6);
        RadioButton radio7 = dialogView.findViewById(R.id.radio7);

        if (mAppplication.isDaysChange) {
            radio7.setVisibility(View.VISIBLE);
        } else {
            radio7.setVisibility(View.GONE);
        }

        if (mSession.getHasShowXirr()) {
            radio4.setVisibility(View.GONE);
        } else {
            radio4.setVisibility(View.VISIBLE);
        }

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.dialog_background_inset));
            relSubMenu.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.dialog_header_background));
            GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
            drawable.setColor(ContextCompat.getColor(requireActivity(), R.color.filterToolbar));
        } else {
            relSubMenu.setBackgroundColor(ContextCompat.getColor(requireActivity(), R.color.filterToolbar));
        }

        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        switch (mSortingType) {
            case "category":
                radio1.setChecked(true);
                break;

            case "name":
                radio2.setChecked(true);
                break;

            case "currentValue":
                radio3.setChecked(true);
                break;

            case "investedValue":
                radio4.setChecked(true);
                break;

            case "gain":
                radio5.setChecked(true);
                break;

            case "return":
                radio6.setChecked(true);
                break;

            case "oneDayChange":
                radio7.setChecked(true);
                break;
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio1) {
                        mSortingType = "category";
}
else if (checkedId == R.id.radio2) {
                        mSortingType = "name";
}
else if (checkedId == R.id.radio3) {
                        mSortingType = "currentValue";
}
else if (checkedId == R.id.radio4) {
                        mSortingType = "investedValue";
}
else if (checkedId == R.id.radio5) {
                        mSortingType = "gain";
}
else if (checkedId == R.id.radio6) {
                        mSortingType = "return";
}
else if (checkedId == R.id.radio7) {
                        mSortingType = "oneDayChange";
}

                mSession.setPtFilterType(mSortingType);
                sortingScheme();
                alertDialog.dismiss();
            }
        });
        //alertDialog.setCancelable(false);
        alertDialog.show();
    }

    private void sortingScheme() {
        switch (mSortingType) {

            case "category":
                /*mRecycleView.setAdapter(mAdapter);
                mSortingAdapter.updateList(mFirstSchemeList);*/
                mRecycleView.setAdapter(mAdapter);
                mAdapter.updateList(mFirstSchemeList, mClientName);
                mAdapter.setAreAllExpanded(areAllExpanded);
                llExpandCollapseAll.setEnabled(true);
                ivExpandCollapseAllArrow.setImageAlpha(255);
                tvExpandCollapseAllText.setAlpha(1f);
                break;

            case "name":
                Collections.sort(mFilterArrayList, new SortData(mSortingType));
                mRecycleView.setAdapter(mSortingAdapter);
                mSortingAdapter.updateList(mFilterArrayList);
                Log.d("updatedCalled", "line 949: ");

                llExpandCollapseAll.setEnabled(false);
                ivExpandCollapseAllArrow.setImageAlpha(100);
                tvExpandCollapseAllText.setAlpha(0.5f);
                break;

            case "currentValue":
                reFilterForNegativeValue("currentValue");
                llExpandCollapseAll.setEnabled(false);
                ivExpandCollapseAllArrow.setImageAlpha(100);
                tvExpandCollapseAllText.setAlpha(0.5f);
                break;

            case "investedValue":
                reFilterForNegativeValue("purchaseValue");
                llExpandCollapseAll.setEnabled(false);
                ivExpandCollapseAllArrow.setImageAlpha(100);
                tvExpandCollapseAllText.setAlpha(0.5f);
                break;

            case "gain":
                reFilterForNegativeValue("gain");
                llExpandCollapseAll.setEnabled(false);
                ivExpandCollapseAllArrow.setImageAlpha(100);
                tvExpandCollapseAllText.setAlpha(0.5f);
                break;

            case "return":
                if (mSession.getHasShowXirr()) {
                    reFilterForNegativeValue("XIRR");
                } else {
                    reFilterForNegativeValue("CAGR");
                }
                llExpandCollapseAll.setEnabled(false);
                ivExpandCollapseAllArrow.setImageAlpha(100);
                tvExpandCollapseAllText.setAlpha(0.5f);
                break;

            case "oneDayChange":
                reFilterForNegativeValue("oneDayChange");
                llExpandCollapseAll.setEnabled(false);
                ivExpandCollapseAllArrow.setImageAlpha(100);
                tvExpandCollapseAllText.setAlpha(0.5f);
                break;
        }
    }

    private void reFilterForNegativeValue(String keyName) {
        ArrayList<JSONObject> list = new ArrayList<>();
        list.addAll(mFilterArrayList);

        Collections.sort(list, new SortData(mSortingType));
        List<JSONObject> listNegativeValue = new ArrayList<>();
        List<JSONObject> listPositiveValue = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            JSONObject jsonObject = list.get(i);
            String value = "";
            if (mSession.getHasShowXirr()) {
                Log.i("Binesh kumar", "reFilterForNegativeValue: "+jsonObject.optString(keyName));
                value = jsonObject.optString(keyName);
            } else {
                value = jsonObject.optJSONObject("summary").optString(keyName);
            }

            if (value.contains("-")) {
                listNegativeValue.add(jsonObject);
            } else {
                listPositiveValue.add(jsonObject);
            }
        }

        mFilterArrayList = new ArrayList<>();
        Collections.reverse(listPositiveValue);
        mFilterArrayList.addAll(listPositiveValue);

        // Collections.reverse(listNegativeValue);
        mFilterArrayList.addAll(listNegativeValue);
        mRecycleView.setAdapter(mSortingAdapter);
        mSortingAdapter.updateList(mFilterArrayList);
        Log.d("updatedCalled", "line 1020: ");
    }


    private void showPopMenuItemDownload(View view) {
        Context popupContext = new ContextThemeWrapper(mActivity, R.style.AppPopupMenuStyle2);

        PopupMenu popup = new PopupMenu(popupContext, view);
        popup.getMenuInflater().inflate(R.menu.menu_portfolio_download, popup.getMenu());
        MenuItem itemValuationD = popup.getMenu().findItem(R.id.itemPtValuationD);
        MenuItem itemSummaryD = popup.getMenu().findItem(R.id.itemPtSummaryD);// summary

        boolean isShowValuationD = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature1011", Permissions.VIEW);
        boolean isShowSummaryD = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature1012", Permissions.VIEW);
        itemValuationD.setVisible(isShowValuationD);
        itemSummaryD.setVisible(isShowSummaryD);

        popup.setOnMenuItemClickListener(item -> {
            if (item.getItemId() == R.id.itemPtValuationD) {
                    dialogFilterPortfolioValuation();
}
else if (item.getItemId() == R.id.itemPtSummaryD) {
                    dialogFilterPortfolioSummary();
}
            return true;
        });
        popup.show();//showing popup menu
    }

    private void dialogFilterPortfolioValuation() {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.portfolio_valuation_filter, null);
        dialogBuilder.setView(dialogView);
        AlertDialog alertDialog2 = dialogBuilder.create();
        // filter

        tvValuationDate = dialogView.findViewById(R.id.tvValuationDate);
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, -1);
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);

        NumberFormat formatter = new DecimalFormat("00");
        String day = formatter.format((mDay));
        String month = formatter.format((mMonth + 1));
        String date_time = mYear + "-" + month + "-" + day;
        String date_for_text = day + "-" + month + "-" + mYear;
        tvValuationDate.setText(date_for_text);
        mValuationDate = date_time;

        dialogView.findViewById(R.id.apply_btnP).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog2.dismiss();
                downloadFileValuation();
            }
        });

        dialogView.findViewById(R.id.ivClose_performance).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog2.dismiss();
            }
        });

        tvValuationDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker(false, true);
            }
        });
        alertDialog2.setCancelable(true);
        alertDialog2.show();
    }
    private void dialogFilterPortfolioSummary() {
        dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.portfolio_performance_filter, null);
        dialogBuilder.setView(dialogView);
        alertDialog = dialogBuilder.create();
        // filter
        mLinerCustomDurationP = dialogView.findViewById(R.id.linerCustomDurationp);
        ivCloseFilter = dialogView.findViewById(R.id.ivClose_performance);

        mTvStartDateP = dialogView.findViewById(R.id.tvSTartp);
        mTvEndDateP = dialogView.findViewById(R.id.tvEndp);
        radioGroupPortfolio = dialogView.findViewById(R.id.rdGroupP);
        radioGroupPortfolio.check(R.id.radio0);
        mSelectedTime = "SI";
        dialogView.findViewById(R.id.apply_btnP).setOnClickListener(this);
        radioGroupPortfolio.setOnCheckedChangeListener((radioGroup, checkId) -> {
            mLinerCustomDurationP.setVisibility(View.GONE);
            String year2 = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            Date todayDate = Calendar.getInstance().getTime();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));

            /*CF,PF,CU,SI*/
            if (checkId == R.id.radio0) {
                    mSelectedTime = "SI";
}
else if (checkId == R.id.radio1) {
                    mSelectedTime = "CF";
                    mStartingDate = getCurrentFinYear();
                    mEndDate = formatter.format(todayDate);
}
else if (checkId == R.id.radio2) {
                    mSelectedTime = "PF";
                    // mStartingDate = Integer.parseInt(year2) - 1 +"-01-04";
                    mStartingDate = getLast1Year();
                    mEndDate = formatter.format(todayDate);
}
else if (checkId == R.id.radio3) {
                    mSelectedTime = "CU";
                    mLinerCustomDurationP.setVisibility(View.VISIBLE);
                    /*mStartingDate = year2 + "-01-01";

                    mEndDate = formatter.format(todayDate);

                    mTvStartDateP.setText(mStartingDate);
                    mTvEndDateP.setText(mEndDate);*/
}else if (checkId == R.id.radio4){
                mSelectedTime = "LF";
                mStartingDate = UtilityKotlin.getLastFinYearStart();
                mEndDate = UtilityKotlin.getLastFinYearEnd();

            }
        });
        mTvEndDateP.setOnClickListener(this);
        mTvStartDateP.setOnClickListener(this);
        ivCloseFilter.setOnClickListener(this);
        alertDialog.setCancelable(true);
        alertDialog.show();
    }
    private String getLast1Year() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.YEAR, -1);
        String date = formatter.format(calendar.getTimeInMillis());
        return date;
    }
    private String getCurrentFinYear() {
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month = Calendar.getInstance().get(Calendar.MONTH) + 1;
        int TodayDay = Calendar.getInstance().get(Calendar.DATE);

        String finYearStardDate = "";
        if (month < 3) {
            finYearStardDate = (year - 1) + "-04-01";
        } else if (month == 3 && TodayDay <= 31) {
            finYearStardDate = (year - 1) + "-04-01";
        } else {
            finYearStardDate = year + "-04-01";
        }
        return finYearStardDate;
    }



    private void datePicker(final boolean isStartDate, final boolean isDateForValuation) {

        SimpleDateFormat apiFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat displayFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        Calendar calendar = Calendar.getInstance();

        // Max date = yesterday for valuation
        String maxDateString = null;
        if (isDateForValuation) {
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            maxDateString = displayFormat.format(calendar.getTime());
        }
        String defaultDateString;
        if(isStartDate) {
            defaultDateString = mTvStartDateP.getText().toString();
        }else if(isDateForValuation) {
            defaultDateString = tvValuationDate.getText().toString();
        } else {
            defaultDateString = mTvEndDateP.getText().toString();
        }
        String minDate = null;
        if (!isStartDate && !isDateForValuation && !mTvStartDateP.getText().toString().isEmpty())
            minDate = mTvStartDateP.getText().toString();

        String maxDate = null;
        if (isStartDate && !mTvEndDateP.getText().toString().isEmpty())
            maxDate = mTvEndDateP.getText().toString();
        else if (isDateForValuation) {
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            maxDate = displayFormat.format(calendar.getTime());
        }

        showDatePickerDialog(
                mActivity,
                mActivity,
                minDate,
                maxDate,
                defaultDateString,
                displayFormat,
                selectedDisplayDate -> {  // callback

                    try {
                        // Convert back to yyyy-MM-dd
                        Date parsed = displayFormat.parse(selectedDisplayDate);
                        String apiDate = apiFormat.format(parsed);

                        if (isDateForValuation) {
                            tvValuationDate.setText(selectedDisplayDate);
                            mValuationDate = apiDate;
                        } else {
                            if (isStartDate) {
                                if (mTvStartDateP != null)
                                    mTvStartDateP.setText(selectedDisplayDate);
                                mStartingDate = apiDate;
                            } else {
                                if (mTvEndDateP != null)
                                    mTvEndDateP.setText(selectedDisplayDate);
                                mEndDate = apiDate;
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return  null;
                }
        );
    }


    private void showPopMenuItemShare(View view) {
        Context popupContext = new ContextThemeWrapper(requireActivity(), R.style.AppPopupMenuStyle2);

        PopupMenu popup = new PopupMenu(popupContext, view);
        popup.getMenuInflater().inflate(R.menu.menu_pdf, popup.getMenu());

        try {
            Field field = popup.getClass().getDeclaredField("mPopup");
            field.setAccessible(true);
            Object mPopup = field.get(popup);
            mPopup.getClass().getDeclaredMethod("setForceShowIcon", boolean.class)
                    .invoke(mPopup, true);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            public boolean onMenuItemClick(MenuItem item) {
                if (item.getItemId() == R.id.itemPtSummaryE) {
}
else if (item.getItemId() == R.id.itemPtValuationE) {
                        sendPortfolioSummaryOnEmail();
}
else if (item.getItemId() == R.id.itemPtValuationW) {
                        sendReportOnWhatsapp("portfolioValuation");
}
else if (item.getItemId() == R.id.itemPtSummaryW) {
                        sendReportOnWhatsapp("portfolioSummary");
}
                return true;
            }
        });
        popup.show();//showing popup menu
    }

    private void downloadFileSummary() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        String url = "";

        try {
            JSONObject jsonObject1 = new JSONObject();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            JSONObject dataClient = new JSONObject();

            dataClient.put("uid", mAppUid);
            dataClient.put("levelNo", "100");
            JSONObject dataSelectedUser = new JSONObject();
            dataSelectedUser.put("selectedUser", dataClient);
            jsonArray.put(dataSelectedUser);

            String endDate = formatter.format(getOneDayEarlier());
            if (mSelectedTime.equalsIgnoreCase("SI")) {
                dateObject.put("endDate", endDate);
            } else {
                dateObject.put("startDate", mStartingDate);
                dateObject.put("endDate", mEndDate);
            }
            jsonArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSource);

          /*     if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");

            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
           */

            jsonObject1.put("uid", mAppUid);
            jsonObject1.put("levelNo", "100");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_COMPLETE_PORTFOLIO_SUMMARY_PDF + "filters=" + jsonArray + "&selectedUser=" + jsonObject1;
            /*https://profitcentre.investwell.app/webapi/client/dashboard/downloadCompletePortfolioSummary?filters=[{"endDate":"2020-04-12"},{},{"activeFoliosOnly":"false"}]&selectedUser={"uid":"cc194cc3026338f87fc640c8b93e7130","levelNo":"98"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "portfolio_performance_", "", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_portfolio_report_download_successfully), "pdf", mFileSave, uri);
                    }
                });

    }

    private void downloadFileValuation() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }
        String url = "";

        try {
            JSONObject jsonObject1 = new JSONObject();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
            String endDate = formatter.format(getOneDayEarlier());


            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            JSONObject dataClient = new JSONObject();

            if (mAppUid.isEmpty()) {
                dataClient.put("uid", Utils.getSelectedUid(mSession));
            } else {
                dataClient.put("uid", mAppUid);
            }

            dataClient.put("levelNo", "100");
            JSONObject dataSelectedUser = new JSONObject();
            dataSelectedUser.put("selectedUser", dataClient);

            dateObject.put("endDate", mValuationDate);
            JSONObject dateObject2 = new JSONObject();
            dateObject2.put("isSummary", true);

            jsonArray.put(dataSelectedUser);
            jsonArray.put(dateObject);
            jsonArray.put(dateObject2);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            jsonArray.put(dataSource);

            String levelNo = "";
            String uId = mAppUid;


          /*
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");

            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
          */
            jsonObject1.put("uid", mAppUid);
            // jsonObject1.put("levelNo", mAppLevelNo); // comment on 19 july , keep fixed 98 levelNo
            jsonObject1.put("levelNo", "100"); //

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_PORTFOLIO_REPORT + "filters=" + jsonArray + "&group=appid" + "&investorUid=" + uId + "&selectedUser=" + jsonObject1 + "&clubTxns=true";
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
            /* https://demo.investwell.app/webapi/client/reports/downloadPortfolioReport?filters=[{"endDate":"2020-04-29","isSummary":true}]&investorUid=106ca28e2c51d6c6a787e74837d300aa&group=appid&selectedUser={"uid":"106ca28e2c51d6c6a787e74837d300aa","levelNo":"98"}&clubTxns=true*/

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "portfolio_valuation","", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_portfolio_report_download_successfully), "pdf", mFileSave, uri);
                    }
                });

    }

    private void sendPortfolioSummaryOnEmail() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        String url = "";
        JSONArray filterArray = new JSONArray();
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "SendReportOptions");

            JSONObject dateObject = new JSONObject();
            String endDate = formatter.format(new Date());
            dateObject.put("endDate", endDate);
            filterArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            filterArray.put(dataSource);


            JSONObject jsonObject1 = new JSONObject();
            jsonObject1.put("uid", mAppUid);
            jsonObject1.put("levelNo", "100");
            JSONObject selectedUserObj = new JSONObject();
            selectedUserObj.put("selectedUser", Utils.getSelectedUserObject(mSession));
            filterArray.put(selectedUserObj);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL +
                    "purpose=Portfolio Summary" +
                    "&purposeVal=PS" +
                    "&filters=" + filterArray +
                    "&ccWithRm=false" +
                    "&brokerUid=" + mSession.getBrokerUID() +
                    "&investorUid=" + mAppUid +
                    "&selectedUser=" + jsonObject1 ;

          /*  if (mSession.getLoginType().equals("broker")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "purpose=Portfolio Summary&purposeVal=PS&" + "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "" + "&endDate=" + endDate ;
            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "purpose=Portfolio Summary&purposeVal=PS&" + "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() + "&endDate=" + endDate + "componentForLoader=" + componentObject.toString() + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }*/

            url = URLDecoder.decode(url, "UTF-8");

            /*https://spvithlani.investwell.app/webapi/client/reports/sendReportEmailToUsers?
            purpose=Portfolio Summary&purposeVal=PS&ccWithRm=false&brokerUid=
            2357bdb419d9924c630e60bf99535a20&endDate=2020-04-19&componentForLoader=
            {"componentName":"SendReportOptions"}*/

            /*https://spvithlani.investwell.app/webapi/client/reports/sendReportEmailToUsers?
            purpose=Portfolio Summary&purposeVal=PS&ccWithRm=false&selectedUser=
            {"uid":"da4701a5ba3d6178dbee5e2271afbdce","levelNo":"100"}&brokerUid=2357bdb419d9924c630
            e60bf99535a20&endDate=2020-04-19&componentForLoader={"componentName":"SendReportOptions"}
            &investorUid=da4701a5ba3d6178dbee5e2271afbdce*/
        } catch (Exception e) {
            if (mBar != null) mBar.dismiss();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                if (mBar != null) mBar.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (mBar != null) mBar.dismiss();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void sendPortfolioReportOnEmail() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        String url = "";
        JSONArray filterArray = new JSONArray();

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "SendReportOptions");

            JSONObject jsonObject1 = new JSONObject();
            jsonObject1.put("uid", mAppUid);
            jsonObject1.put("levelNo", "100");

            JSONObject dateObject = new JSONObject();
            String endDate = formatter.format(new Date());
            dateObject.put("endDate", endDate);
            filterArray.put(dateObject);

            JSONObject dataSource = new JSONObject();
            dataSource.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());
            filterArray.put(dataSource);
            JSONObject selectedUserObj = new JSONObject();
            selectedUserObj.put("selectedUser", Utils.getSelectedUserObject(mSession));
            filterArray.put(selectedUserObj);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL +
                    "purpose=Portfolio Valuation&purposeVal=PR&" +
                    "filters=" + filterArray +
                    "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() +
                    "&investorUid=" + mAppUid +
                    "&selectedUser=" + jsonObject1;


         /*   if (mSession.getLoginType().equals("broker")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "purpose=Portfolio Valuation&purposeVal=PR&" + "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "" + "&endDate=" + endDate ;
            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "purpose=Portfolio Summary&purposeVal=PS&" + "ccWithRm=false&brokerUid=" + mSession.getBrokerUID() + "&endDate=" + endDate + "componentForLoader=" + componentObject.toString() + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }*/

            url = URLDecoder.decode(url, "UTF-8");

            //  https://spvithlani.investwell.app/webapi/client/reports/sendReportEmailToUsers?
            //  purpose=Portfolio Return&purposeVal=PR&ccWithRm=false&selectedUser=
            //  {"uid":"6158fa1dba4bf04015e91d2e2caf5bcc","levelNo":"98"}&brokerUid=
            //  2357bdb419d9924c630e60bf99535a20&endDate=2020-05-21&componentForLoader=
            //  {"componentName":"SendReportOptions"}&investorUid=6158fa1dba4bf04015e91d2e2caf5bcc


        } catch (Exception e) {
            if (mBar != null) mBar.dismiss();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (mBar != null) mBar.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (mBar != null) mBar.dismiss();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void sendReportOnWhatsapp(String reportType) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }

        JSONArray filtersArray = new JSONArray();
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
            String mEndDate = formatter.format(new Date());

            JSONObject filterObject = new JSONObject();

            filterObject.put("endDate", mEndDate);
            filterObject.put("dataSource", mActivity.ptMFSelectedFilter.getFirst());

            JSONArray selectedUserArray = new JSONArray();

            JSONObject userObject = new JSONObject();
            userObject.put("uid", mAppUid);
            userObject.put("levelNo", 100);

            selectedUserArray.put(userObject);

            filterObject.put("selectedUser", selectedUserArray);

            filtersArray.put(filterObject);

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        String url;
        if(mSession.getCustomURL().isEmpty())
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_WHATSAPP;
        else
            url = "https://" + mSession.getCustomURL() + "/webapi/" + Config.SEND_REPORT_ON_WHATSAPP;

        url = url + "filters=" + filtersArray +
                "&clubTxns=" + "true" +
                "&reportType=" + reportType +
                "&investorUid=" + Utils.getSelectedUid(mSession) +
                "&selectedUser=" + Utils.getSelectedUserObject(mSession);

        ApiClient client = new ApiClient(requireContext(), mSession);
        client.makeGetRequest(
                url,
                isLoading -> {
                    if (isLoading) {
                        ProgressBarCommon.showDialog(requireContext());
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                }, response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("status") == 0) {
                            JSONObject result = jsonObject.optJSONObject("result");
                            String whatsappUrl = result != null ? result.optString("url") : "";
                            if (!whatsappUrl.isEmpty()) {
                                if (WhatsAppShare.isAnyWhatsappInstalled(requireActivity())) {
                                    WhatsAppShare.shareOnWhatsApp(requireActivity(), whatsappUrl);
                                } else
                                    showWhatsAppOptionsDialog();
                            }
                        } else
                            Toast.makeText(requireContext(), jsonObject.optString("message"), Toast.LENGTH_LONG).show();
                    } catch (Exception e) {

                    }
                    return null;
                }, volleyError -> {
                    if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                        VolleyError error = new VolleyError(new String(volleyError.networkResponse.data));
                        try {
                            JSONObject jsonObject2 = new JSONObject(error.getMessage());
                            Toast.makeText(requireContext(), jsonObject2.optString("error"), Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    } else if (volleyError instanceof NoConnectionError) {
                        Toast.makeText(requireContext(), requireContext().getResources().getString(R.string.no_internet), Toast.LENGTH_LONG).show();
                    } else {
                        String error = volleyError.getLocalizedMessage();
                    }

                    return null;
                }, status -> {
                    if (status == 401) {
                        mAppplication.showCommonDailog(requireContext(), requireContext().getString(R.string.txt_session_expired), requireContext().getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }
                    return null;
                });
    }

    public void updateFilterIndicator(Boolean isFilterApplied){
        if(isFilterApplied) {
            ivFilter.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_filled_icon));
            viewFilterIndicator.setVisibility(View.VISIBLE);
            ivFilterNoData.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_filled_icon));
            viewFilterIndicatorNoData.setVisibility(View.VISIBLE);

            llFilter.setContentDescription(getString(R.string.filter_button_filter_applied));
            llFilterNoData.setContentDescription(getString(R.string.filter_button_filter_applied));
        }
        else {
            ivFilter.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_unfilled_icon));
            viewFilterIndicator.setVisibility(View.GONE);
            ivFilterNoData.setImageDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.pt_filter_unfilled_icon));
            viewFilterIndicatorNoData.setVisibility(View.GONE);

            llFilter.setContentDescription(getString(R.string.filter_button_no_filter_applied));
            llFilterNoData.setContentDescription(getString(R.string.filter_button_no_filter_applied));
        }
    }

    private void showWhatsAppOptionsDialog() {
        CustomDialog customDialog = new CustomDialog(this);
        customDialog.showDialog(
                requireContext(),
                getString(R.string.alert),
                getString(R.string.whatsapp_not_installed),
                getString(R.string.install),
                getString(R.string.cancel),
                true,
                true
        );
    }

    @Override
    public void onDialogBtnClick(View view) {
        if (view.getId() == R.id.btDone) {
                redirectToPlayStore(requireContext());
}
else if (view.getId() == R.id.btCalcel) {
}
    }

    public void redirectToPlayStore(Context context) {
        String packageName = "com.whatsapp";
        PackageManager packageManager = context.getPackageManager();

        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + packageName));
        if (playStoreIntent.resolveActivity(packageManager) != null) {
            context.startActivity(playStoreIntent);
        } else {
            // Play Store is not installed, open in browser
            Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + packageName));
            context.startActivity(webIntent);
        }
    }

    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }

    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private final ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {
            logD("DB", "PERMISSION GRANTED");
        } else {
            isGranted = false;
            Toast.makeText(mActivity, getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFileValuation();
        }
    });


    public class SortData implements Comparator {
        String mType = "";

        SortData(String type) {
            mType = type;
        }

        @SuppressLint("DefaultLocale")
        @Override
        public int compare(Object o1, Object o2) {
            String a = "0";
            String b = "0";
            switch (mType) {

                case "name":
                    a = ((JSONObject) o1).optString("fundName");
                    b = ((JSONObject) o2).optString("fundName");
                    break;

                case "currentValue":
                    if (mSession.getHasShowXirr()) {
                        String valueWithENotationA = ((JSONObject) o1).optString("currentValue");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                            Log.i("SortingIssue", "compare: "+a);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optString("currentValue");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                            Log.i("SortingIssue", "compare: "+b);

                        }
                    } else {
                        String valueWithENotationA = ((JSONObject) o1).optJSONObject("summary").optString("currentValue");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optJSONObject("summary").optString("currentValue");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    }


                    break;

                case "investedValue":
                    if (mSession.getHasShowXirr()) {
                        String valueWithENotationA = ((JSONObject) o1).optString("purchaseValue");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optString("purchaseValue");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    } else {
                        String valueWithENotationA = ((JSONObject) o1).optJSONObject("summary").optString("purchaseValue");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optJSONObject("summary").optString("purchaseValue");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    }

                    break;

                case "gain":
                    if (mSession.getHasShowXirr()) {
                        String valueWithENotationA = ((JSONObject) o1).optString("gain");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optString("gain");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    } else {
                        String valueWithENotationA = ((JSONObject) o1).optJSONObject("summary").optString("gain");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optJSONObject("summary").optString("gain");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    }


                    break;

                case "return":
                    if (mSession.getHasShowXirr()) {
                        String valueWithENotationA = ((JSONObject) o1).optString("XIRR");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optString("XIRR");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    } else {
                        String valueWithENotationA = ((JSONObject) o1).optJSONObject("summary").optString("CAGR");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optJSONObject("summary").optString("CAGR");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    }

                    break;

                case "oneDayChange":
                    if (mSession.getHasShowXirr()) {
                        String valueWithENotationA = ((JSONObject) o1).optString("oneDayChange");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optString("oneDayChange");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    } else {
                        String valueWithENotationA = ((JSONObject) o1).optJSONObject("summary").optString("oneDayChange");
                        if (!valueWithENotationA.equals("null") && !valueWithENotationA.isEmpty()){
                            double valueA = Double.parseDouble(valueWithENotationA);
                            a = String.format("%.4f", valueA);
                        }

                        String valueWithENotationB = ((JSONObject) o2).optJSONObject("summary").optString("oneDayChange");
                        if (!valueWithENotationB.equals("null") && !valueWithENotationB.isEmpty()){
                            double valueB = Double.parseDouble(valueWithENotationB);
                            b = String.format("%.4f", valueB);
                        }
                    }

                    break;
            }


            int ia = 0, ib = 0;
            int nza = 0, nzb = 0;
            char ca, cb;
            int result;

            while (true) {
                // only count the number of zeroes leading the last number compared
                nza = nzb = 0;

                ca = charAt(a, ia);
                cb = charAt(b, ib);

                // skip over leading spaces or zeros
                while (Character.isSpaceChar(ca) || ca == '0') {
                    if (ca == '0') {
                        nza++;
                    } else {
                        // only count consecutive zeroes
                        nza = 0;
                    }

                    ca = charAt(a, ++ia);
                }

                while (Character.isSpaceChar(cb) || cb == '0') {
                    if (cb == '0') {
                        nzb++;
                    } else {
                        // only count consecutive zeroes
                        nzb = 0;
                    }

                    cb = charAt(b, ++ib);
                }

                // process run of digits
                if (Character.isDigit(ca) && Character.isDigit(cb)) {
                    if ((result = compareRight(a.substring(ia), b.substring(ib))) != 0) {
                        return result;
                    }
                }

                if (ca == 0 && cb == 0) {
                    // The strings compare the same. Perhaps the caller
                    // will want to call strcmp to break the tie.
                    return nza - nzb;
                }

                if (ca < cb) {
                    return -1;
                } else if (ca > cb) {
                    return +1;
                }

                ++ia;
                ++ib;
            }
        }

        private char charAt(String s, int i) {
            if (i >= s.length()) {
                return 0;
            } else {
                return s.charAt(i);
            }
        }

        int compareRight(String a, String b) {
            int bias = 0;
            int ia = 0;
            int ib = 0;

            // The longest run of digits wins. That aside, the greatest
            // value wins, but we can't know that it will until we've scanned
            // both numbers to know that they have the same magnitude, so we
            // remember it in BIAS.
            for (; ; ia++, ib++) {
                char ca = charAt(a, ia);
                char cb = charAt(b, ib);

                if (!Character.isDigit(ca) && !Character.isDigit(cb)) {
                    return bias;
                } else if (!Character.isDigit(ca)) {
                    return -1;
                } else if (!Character.isDigit(cb)) {
                    return +1;
                } else if (ca < cb) {
                    if (bias == 0) {
                        bias = -1;
                    }
                } else if (ca > cb) {
                    if (bias == 0)
                        bias = +1;
                } else if (ca == 0 && cb == 0) {
                    return bias;
                }
            }
        }
    }

}
