package investwell.activity;

import static investwell.utils.UtilityKotlin.openNewKycOnboardingInWebView;
import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.CrmBuilder;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.messaging.FirebaseMessaging;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

import investwell.admin.activity.AdminActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.common.debugmode.DebugActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.common.lock.AppLockOptionActivity;
import investwell.utils.ApiRequestType;
import investwell.utils.AppConstants;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.Extensions;
import investwell.utils.Internet;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.TimeDateUtils;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class LoginActivity extends BaseActivity implements View.OnClickListener {

    private TextInputEditText mAtUsername, mEtPassword;
    private TextInputEditText edtPhone;
    private AppSession mSession;
    private String mDomainName = "", mLogoPath = "",mCompName;
    private RelativeLayout mRelMain, rlMobileLogin;
    private LinearLayout mllDeveloperMode, llusernameLogin, llSignText;
    private ImageView ivlogo, ivLoginTypeChange;
    public static String sCallingFrom = "login";
    private String mGToken = "";
    private GoogleSignInClient mSignInClient;
    //Signing Options
    private GoogleSignInOptions gso;
    private final int RC_SIGN_IN = 100;
    private String resultData = "";
    private String mUserName = "";
    private TextView tvChangeDomain, tvForgotPassword, tvLoginLabelMsg, tvLoginTypeChange, tvPrivacy, tvSlogan,tvContactUs;
    private int mClickCount = 0;
    private ApiDataBase db;
    private boolean isPhoneLogin = false;

    private boolean isPhoneOTPToggle = false;
    private LinearLayout llOtpUsernameButton, llGoogleLogin,llGotAnQues;
    private TextView tvOR;
    public String mComingFrom = "";
    private CheckBox mCheckBox;
    private Intent mIntent;

    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(url, req, res, AppConstants.LOGIN_SCREEN, dateTime, endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_login);
        Extensions.checkDevice(this);
        sCallingFrom = "login";
        mSession = AppSession.getInstance(this);
        mSession.setHasLoging(false);
        mIntent = getIntent();
        Extensions.updateLocale(this,mSession.getAppLanguage());


        Utils.setTheme(this,mSession);

        db = ApiDataBase.getInstance(getApplicationContext());
        mAtUsername = findViewById(R.id.atUser);
        mEtPassword = findViewById(R.id.etPassword);
        edtPhone = findViewById(R.id.edt_phone);
        mCheckBox = findViewById(R.id.cbPrivacyPolicy);
        tvContactUs = findViewById(R.id.tv_contact_us);
        llGotAnQues = findViewById(R.id.ll_contactUS);

        llusernameLogin = findViewById(R.id.llusernameLogin);
        rlMobileLogin = findViewById(R.id.rlMobileLogin);
        tvForgotPassword = findViewById(R.id.tvForgot);
        tvLoginLabelMsg = findViewById(R.id.tvCreateAccLabelMsg);
        tvLoginTypeChange = findViewById(R.id.tvLoginTypeChange);
        ivLoginTypeChange = findViewById(R.id.ivLoginTypeChange);
        tvPrivacy = findViewById(R.id.tvPrivacy);
        llSignText = findViewById(R.id.llSignText);

        Button btLogin = findViewById(R.id.btLogin);
        tvSlogan = findViewById(R.id.tvSlogan);
        llGoogleLogin = findViewById(R.id.btGoogle);
        llOtpUsernameButton = findViewById(R.id.llOtpUsernameButton);
        tvSlogan.setText(mSession.getSloganOnLogo());

        userLoginVisible();
        tvForgotPassword.setVisibility(View.VISIBLE);


        tvOR = findViewById(R.id.tvOR);
        ivlogo = findViewById(R.id.ivlogo);
        mRelMain = findViewById(R.id.relMain);
        mllDeveloperMode = findViewById(R.id.llDeveloperMode);

        btLogin.setEnabled(false);
        btLogin.setAlpha(0.5f);  // Light color

        llGoogleLogin.setEnabled(false);
        llGoogleLogin.setAlpha(0.8f);  // Light color

        btLogin.setOnClickListener(this);
        mCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            btLogin.setEnabled(isChecked);  // Enable only when checked
            llGoogleLogin.setEnabled(isChecked);  // Enable only when checked
            btLogin.setAlpha(isChecked ? 1f : 0.5f);
            llGoogleLogin.setAlpha(isChecked ? 1f : 0.5f);
        });

        llGoogleLogin.setOnClickListener(this);
        tvForgotPassword.setOnClickListener(this);
        findViewById(R.id.ivBack).setOnClickListener(this);
        findViewById(R.id.ivlogo).setOnClickListener(this);
        findViewById(R.id.llOtpUsernameButton).setOnClickListener(this);
        tvChangeDomain = findViewById(R.id.tvChangeDomain);
        tvChangeDomain.setOnClickListener(this);

        getDataFromBundle();
        logoAndTextAlignment();

        setTintColorIfDark(this,ivlogo);

        if (mSession.getOnBoarding() == 1) {
            findViewById(R.id.ll_signup_section).setVisibility(View.VISIBLE);
        } else {
            if (mSession.getAppConfig().contains("LoginBox5")){
                findViewById(R.id.ll_signup_section).setVisibility(View.VISIBLE);
            }else{
                findViewById(R.id.ll_signup_section).setVisibility(View.GONE);
            }
        }
        TextView mSignUp = findViewById(R.id.tv_sign_up);
        mSignUp.setOnClickListener(view -> {
            if (mSession.getAppConfig().contains("LoginBox5")){
                if (Utils.getConfigData(mSession).has("SectionList") && Objects.requireNonNull(Utils.getConfigData(mSession)
                        .optJSONArray("SectionList")).length() > 0){
                    JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("SectionList");
                    for (int i = 0; i < sectionJSONArray.length(); i++) {
                        try {
                            JSONObject  jsonObject = sectionJSONArray.getJSONObject(i);
                            if (jsonObject.optString("SectionName").equalsIgnoreCase("LoginBox5")) {
                                    JSONArray jsonArrayLogin5 = jsonObject.optJSONArray("SectionChildList");
                                    if (jsonArrayLogin5 != null && jsonArrayLogin5.length() == 1) {
                                        JSONObject jsonObjectSingleObj = jsonArrayLogin5.optJSONObject(0);

                                        Intent intent = new Intent(LoginActivity.this, NewKycOnboardingWebView.class);
                                        intent.putExtra("url", jsonObjectSingleObj.optString("TargetURL"));
                                        intent.putExtra("title", jsonObjectSingleObj.optString("ChildTitle"));
                                        intent.putExtra("comeFrom", "SectionAdapter");
                                        startActivity(intent);

                                    }else if (jsonArrayLogin5 != null && jsonArrayLogin5.length() > 1) {
                                        Intent intent = new Intent(this, SignupActivityLayout5.class);
                                        intent.putExtra("data", jsonObject.toString());
                                        startActivity(intent);
                                    }

                            }
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }


                    }

                }

            }else {
                openNewKycOnboardingInWebView(this, mSession, "0", "signUp", "");
            }
        });
        validateContactUs();
    }

    private void validateContactUs(){
            if (mSession.getAllowedCrm()){
                llGotAnQues.setVisibility(View.VISIBLE);
                tvContactUs.setOnClickListener(this);
            }else{
                llGotAnQues.setVisibility(View.GONE);
            }
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btLogin) {
                if (isPhoneLogin) {
                    String mPhone = edtPhone.getText().toString().trim();
                    if (mPhone.length() < 10) {
                        Toast.makeText(this, R.string.please_enter_registered_mobile_number, Toast.LENGTH_SHORT).show();
                    } else if (mSession.getFcmToken().isEmpty()) {
                        getNewFcmToken();
                    } else {
                        otpLogin(true);
                    }
                } else {
                    LoginValidations();
                }
}else if (v.getId() == R.id.tv_contact_us){
            Intent contactIntent = new Intent(getApplicationContext(), ContactUsActivity.class);
            startActivity(contactIntent);
        }
else if (v.getId() == R.id.btGoogle) {
                getGmailUserDetails();
}
else if (v.getId() == R.id.llOtpUsernameButton) {
                if (!isPhoneOTPToggle) {
                    mobileLoginVisible();
                    isPhoneOTPToggle = true;
                } else {
                    userLoginVisible();
                    isPhoneOTPToggle = false;
                }
}
else if (v.getId() == R.id.tvForgot) {
//                UtilityKotlin.forgotPwdApi(this);
                Intent forgotIntent = new Intent(getApplicationContext(), ForgotPasswordActivity.class);
                forgotIntent.putExtra("domain_name", mDomainName);
                startActivity(forgotIntent);
}
else if (v.getId() == R.id.ivBack) {
                finish();
}
else if (v.getId() == R.id.tvChangeDomain) {
                Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                // intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
                // finish();
}
else if (v.getId() == R.id.ivlogo) {
                if (mSession.getEnableDebug()) {
                    UtilityKotlin.showDebugModeLoading(this);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startActivity(new Intent(LoginActivity.this, DebugActivity.class));
                        }
                    }, 3000);

                } else {
                    mClickCount = mClickCount + 1;
                    if (mClickCount == 25) {
                        UtilityKotlin.launchDebugMode(this);
                        mClickCount = 0;
                    }
                }
}
    }


    private void logoAndTextAlignment() {
        try {
            JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
            setClickableTerms(appConfigObject);
            String isGoogleSignin = appConfigObject.optString("isGoogleSignin");
            String isOTPLogin = appConfigObject.optString("allowMobileOtpLogin");
            mSession.setShowBseAuthPopup("1".equals(appConfigObject.optString("showBseAuthPopup").trim()));
            if (isOTPLogin.equalsIgnoreCase("1")) {
                llOtpUsernameButton.setVisibility(View.VISIBLE);
                mobileLoginVisible();
                isPhoneOTPToggle = true;
            } else {
                llOtpUsernameButton.setVisibility(View.GONE);
                userLoginVisible();
            }

            if (isGoogleSignin.equalsIgnoreCase("1")) {
                llGoogleLogin.setVisibility(View.VISIBLE);
            } else {
                llGoogleLogin.setVisibility(View.GONE);
            }

            if (isOTPLogin.equalsIgnoreCase("1") || isGoogleSignin.equalsIgnoreCase("1")) {
                tvOR.setVisibility(View.VISIBLE);
            } else {
                tvOR.setVisibility(View.GONE);
            }

            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
                if (sectionJSONArray != null) {
                    String logoAlignment = UtilityKotlin.getFeatureSettingByName(sectionJSONArray, "LogoAlignment");
                    if (!"Left".equalsIgnoreCase(logoAlignment)) {
                        RelativeLayout.LayoutParams imageParams = new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT // set default wrap and max 100DP
                        );
                        int maxHeight = (int) (100 * getResources().getDisplayMetrics().density); // 100dp to px
                        int topMargin = (int) (10 * getResources().getDisplayMetrics().density);

                        imageParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
                        imageParams.topMargin = topMargin;
                        ivlogo.setLayoutParams(imageParams);
                        ivlogo.setAdjustViewBounds(true);
                        ivlogo.setMaxHeight(maxHeight);

                        RelativeLayout.LayoutParams textParams = new RelativeLayout.LayoutParams(
                                RelativeLayout.LayoutParams.WRAP_CONTENT,
                                RelativeLayout.LayoutParams.WRAP_CONTENT
                        );
                        textParams.addRule(RelativeLayout.BELOW, R.id.ivlogo);
                        textParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
                        textParams.topMargin = (int) (5 * getResources().getDisplayMetrics().density); // 5dp to px
                        tvSlogan.setLayoutParams(textParams);


                        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );
                        params.gravity = Gravity.CENTER;
                        llSignText.setLayoutParams(params);
                        tvLoginLabelMsg.setLayoutParams(params);


                    }
                }

            }


        } catch (Exception e) {

        }


    }


    private void setClickableTerms(JSONObject appConfigObject) {
        String fullText = getString(R.string.i_confirm);
        SpannableString spannable = new SpannableString(fullText);
        String terms = getString(R.string.terms_of_use);
        String privacy = getString(R.string.privacy_policy);

        int termsStart = fullText.indexOf(terms);
        int termsEnd = termsStart + terms.length();

        int privacyStart = fullText.indexOf(privacy);
        int privacyEnd = privacyStart + privacy.length();

        // ClickableSpan for Terms of Use
        ClickableSpan termsClickable = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                String url = "";
                try {
                    if (appConfigObject != null && appConfigObject.has("termsAndConditionsLink")) {
                        url = appConfigObject.optString("termsAndConditionsLink");
                    } else {
                        url = " https://apppanel.mintservices.in/policies.aspx?activeTab=Terms&mintSubDomain="+mSession.getUserBrokerDomain();
                    }

                    Intent intent = new Intent(LoginActivity.this, WebViewActivity.class);
                    intent.putExtra("url",url);
                    intent.putExtra("title",getString(R.string.terms_of_use));
                    intent.putExtra("comeFrom","login");
                    startActivity(intent);

                } catch (ActivityNotFoundException e) {
                    System.out.println();
                }
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false);
                ds.setColor(ContextCompat.getColor(LoginActivity.this, R.color.blue_text_color));
            }
        };

        // ClickableSpan for Privacy Policy
        ClickableSpan privacyClickable = new ClickableSpan() {
            @Override
            public void onClick(View widget) {

                try {
                    String url = "";
                    if (appConfigObject != null && appConfigObject.has("privacyPolicyURL")) {
                        url = appConfigObject.optString("privacyPolicyURL");
                    } else {
                        url = " https://apppanel.mintservices.in/policies.aspx?activeTab=Privacy&mintSubDomain=" + mSession.getUserBrokerDomain();
                    }

                    Intent intent = new Intent(LoginActivity.this, WebViewActivity.class);
                    intent.putExtra("url",url);
                    intent.putExtra("title",getString(R.string.privacy_policy));
                    intent.putExtra("comeFrom","login");
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    System.out.println();
                }
            }

            @Override
            public void updateDrawState(TextPaint ds) {
                ds.setUnderlineText(false);
                ds.setColor(ContextCompat.getColor(LoginActivity.this, R.color.blue_text_color));
            }
        };

        // Apply clickable spans
        spannable.setSpan(termsClickable, termsStart, termsEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(privacyClickable, privacyStart, privacyEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        tvPrivacy.setMovementMethod(LinkMovementMethod.getInstance());
        tvPrivacy.setHighlightColor(Color.TRANSPARENT);
        tvPrivacy.setText(spannable, TextView.BufferType.SPANNABLE);
    }

    private void mobileLoginVisible() {
        isPhoneLogin = true;
        tvLoginLabelMsg.setText(R.string.enter_mobile_number);
        tvLoginTypeChange.setText(getString(R.string.username));
        ivLoginTypeChange.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.icon_circle_avtar));
        rlMobileLogin.setVisibility(View.VISIBLE);
        tvForgotPassword.setVisibility(View.GONE);
        llusernameLogin.setVisibility(View.GONE);
    }

    private void userLoginVisible() {
        isPhoneLogin = false;
        tvLoginLabelMsg.setText(R.string.username_tosingin);
        tvLoginTypeChange.setText(R.string.otp);
        ivLoginTypeChange.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.otp_new));
        rlMobileLogin.setVisibility(View.GONE);
        llusernameLogin.setVisibility(View.VISIBLE);
        tvForgotPassword.setVisibility(View.VISIBLE);
    }


    private void otpLogin(boolean isLoder) {

        String url = "https://" + mDomainName + mSession.getHostingPath() + Config.OTP_LOGIN;
        JSONObject params = new JSONObject();
        try {
            params.put("mobile", edtPhone.getText().toString());
        } catch (Exception ignored) {

        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, params, AppHeaderType.LOGIN, new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    if (isLoder) {
                        ProgressBarCommon.showDialog(LoginActivity.this);
                    }
                } else {
                    if (isLoder) {
                        ProgressBarCommon.dismissDialog();
                    }
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                UtilityKotlin.setRefreshKey(mSession);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        String token = "";
                        if (jsonObjectMain.has("token")) {
                            token = jsonObjectMain.optString("token");
                        }

                        Intent mIntent = new Intent(LoginActivity.this, MobileVerificationActivity.class);
                        mIntent.putExtra("token", token);
                        mIntent.putExtra("domain_name", mDomainName);
                        mIntent.putExtra("mobile", edtPhone.getText().toString());
                        mIntent.putExtra("type", "login");
                        startActivity(mIntent);
                    } else {
                        String errorMessge = jsonObject.optString("message");
                        if (!errorMessge.equalsIgnoreCase("invalid request")) {
                            AppApplication appApplication = (AppApplication) getApplication();
                            appApplication.showCommonDailog(LoginActivity.this, "Message", errorMessge, "message");
                        } else {
                            Toast.makeText(LoginActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception ignored) {

                }
            }
        });

    }


    private void getDataFromBundle() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("domain_name")) {
            mDomainName = intent.getStringExtra("domain_name");
        } else {
            mDomainName = mSession.getUserBrokerDomain();
        }

        if (intent != null && intent.hasExtra("result")) {
            resultData = intent.getStringExtra("result");
            try {
                JSONObject jsonObject = new JSONObject(resultData);
                mUserName = !TextUtils.isEmpty(jsonObject.optString("username")) ? jsonObject.optString("username") : "";
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }
        } else {
            resultData = "";
        }
        if (intent != null && intent.hasExtra("logoPath")) {
            mLogoPath = intent.getStringExtra("logoPath");
        } else {
            mLogoPath = mSession.getAppLogo();
        }
        if (intent != null && intent.hasExtra("compName")) {
            mCompName = intent.getStringExtra("compName");
        } else {
            mCompName = mDomainName;
        }
        if (intent != null && intent.hasExtra("logoPath")) {
            mLogoPath = intent.getStringExtra("logoPath");
        } else {
            mLogoPath = mSession.getAppLogo();
        }

        try {
            if (intent != null && intent.hasExtra("comingFrom")) {
                mComingFrom = intent.getStringExtra("comingFrom");
            }
            if (mComingFrom != null && mComingFrom.equalsIgnoreCase("SignUpWebViewForOtpLogin")) {
                String mobileNo = intent.getStringExtra("mobileNo");
                isPhoneLogin = true;
                edtPhone.setText(mobileNo);
                if (mSession.getFcmToken().isEmpty()) {
                    getNewFcmToken();
                } else {
                    otpLogin(true);
                }
            }
        } catch (Exception e) {

        }


        ivlogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getString(R.string.subdomain).equals("sdk")) {
            tvChangeDomain.setVisibility(View.VISIBLE);
            if (!mLogoPath.equals("")) {
                Picasso.get().invalidate(mLogoPath);
                Picasso.get().load(mLogoPath).error(R.drawable.app_logo_secondry_mint).into(ivlogo);
            } else {
                ivlogo.setImageResource(R.drawable.app_logo_secondry_mint);
            }
        } else {
            tvChangeDomain.setVisibility(View.GONE);
            ivlogo.setImageResource(R.mipmap.app_logo_secondry);
        }


        mAtUsername.setText(mUserName);

    }


    public static boolean passwordsMatch(String password1, String password2) {
        if (password1 != null && password2 != null) {
            return password1.equals(password2);
        }
        return false; // If any password is null, they don't match
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }


    @SuppressLint("WrongConstant")
    private void setDeveloperModeAnimation() {
        ObjectAnimator anim = ObjectAnimator.ofInt(mllDeveloperMode, "backgroundColor", Color.WHITE, Color.RED, Color.WHITE);
        anim.setDuration(3000);
        anim.setEvaluator(new ArgbEvaluator());
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        anim.start();

    }


    public void getGmailUserDetails() {
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(getString(R.string.client_server_key)).requestEmail().build();

        mSignInClient = GoogleSignIn.getClient(this, gso);
        // logout
        if (GoogleSignIn.getLastSignedInAccount(LoginActivity.this) != null) {
            if (mSignInClient != null) {
                mSignInClient.signOut();
            }
        }
        Intent signInIntent = mSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
       /* GoogleSignInResult result2 = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
        int code = result2.getStatus().getStatusCode();
        System.out.println(""+code);*/

        if (requestCode == RC_SIGN_IN && resultCode == RESULT_OK) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data); // for gmail login
            if (result.isSuccess()) {
                GoogleSignInAccount acct = result.getSignInAccount();
                mGToken = acct.getIdToken();
                GoogleLoginMethod();
            } else {
                Toast.makeText(this, getString(R.string.txt_login_failed), Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, getString(R.string.txt_login_failed), Toast.LENGTH_LONG).show();
        }
    }

    private void LoginValidations() {
       /* if (mAtUsername.getText().toString().equalsIgnoreCase("mobileapp") && mEtPassword.getText().toString().equalsIgnoreCase("demo1234")) {
            mSession.setHostingPath(".investwell.app/webapi/");
            mSession.setUserBrokerDomain("demo");
            mDomainName = mSession.getUserBrokerDomain();
        }*/

        if (mAtUsername.getText().toString().trim().equals("")) {
            Toast.makeText(this, R.string.txt_please_enter_username, Toast.LENGTH_SHORT).show();
        } else if (mEtPassword.getText().toString().length() < 3) {
            Toast.makeText(this, R.string.txt_please_enter_at_least_6_characters_password, Toast.LENGTH_SHORT).show();
        } else {
            Utils.hideKeyBoardFromAnyWhere(LoginActivity.this);
            if (mSession.getFcmToken().isEmpty()) {
                getNewFcmToken();
            } else {
                LoginMethod(true);
            }
        }
    }

    private void getNewFcmToken() {
        if (Internet.getInstance().internetConnectivity(this)) {
            ProgressBarCommon.showDialog(this);

            FirebaseMessaging.getInstance().getToken().addOnFailureListener(e -> {
                Log.d("fcmToken", "addOnFailureListener called " + e.getLocalizedMessage());
                loginType();
                // Toast.makeText(this, e.getLocalizedMessage()+" & "+e.getMessage(), Toast.LENGTH_SHORT).show();
            }).addOnCanceledListener(() -> {
                Log.d("fcmToken", "addOnCanceledListener called ");
                loginType();
                // Toast.makeText(this, "Fcm cancelled", Toast.LENGTH_SHORT).show();
            }).addOnCompleteListener(task -> {
                Log.d("fcmToken", "addOnCompleteListener called ");
                if (task.isSuccessful()) {
                    String deviceToken = task.getResult();
                    if (!getString(R.string.subdomain).equals("mint")) {
                        String topicName = "mintandroid" + mSession.getUserBrokerDomain();
                        FirebaseMessaging.getInstance().subscribeToTopic(topicName);
                    }
                    Log.d("fcmToken", "new token received: " + deviceToken);
                    mSession.setFcmToken(deviceToken);
                }
                loginType();
            });


        } else {
            Toast.makeText(this, getResources().getString(R.string.no_internet), Toast.LENGTH_LONG).show();
        }
    }

    private void loginType() {
        if (isPhoneLogin) {
            otpLogin(false);
        } else {
            LoginMethod(false);
        }
    }


    private void LoginMethod(boolean isShowLoader) {
        String url = "https://" + mDomainName + mSession.getHostingPath() + Config.AUTHENTICATION;
        JSONObject params = new JSONObject();
        try {
            params.put("email", mAtUsername.getText().toString().trim());
            params.put("password", UtilityKotlin.encryptedPassword(mEtPassword.getText().toString()));
            params.put("brokerDomain", mDomainName);
            params.put("isEncryption", "true");
            params.put("rememberMe", "true");
        } catch (Exception e) {

        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, params, AppHeaderType.LOGIN, new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    if (isShowLoader) {
                        ProgressBarCommon.showDialog(LoginActivity.this);
                    }
                } else {
                    if (isShowLoader) {
                        ProgressBarCommon.dismissDialog();
                    }
                }

            }

            @Override
            public void onSuccess(String response, int statusCode) {
                UtilityKotlin.setRefreshKey(mSession);
                ProgressBarCommon.dismissDialog();
                mSession.setShowCrossDialog(true);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        mSession.setUserId(mAtUsername.getText().toString().trim());
                        mSession.setLoginBy("user_password");
                        mSession.setUserpw("");
                        mSession.setLoginTypeEvent("normal");
                        if (!mLogoPath.isEmpty()) {
                            mSession.setAppLogo(mLogoPath);
                        }

                        if (jsonObjectMain.has("token")) {
                            Intent intent = new Intent(LoginActivity.this, MobileVerificationActivity.class);
                            intent.putExtra("token", jsonObjectMain.optString("token"));
                            intent.putExtra("mobile", jsonObjectMain.optString("mobile"));
                            intent.putExtra("type", "twoFactor");
                            intent.putExtra("isTwoFa", true);
                            startActivity(intent);
                        } else {

                            if (getString(R.string.subdomain).equals("sdk")) {
                                AppApplication appApplication = (AppApplication) getApplication();
                                appApplication.GtmSetUp(jsonObjectMain.optString("levelNo"), jsonObjectMain.optString("name"));
                            }

                            mSession.setUsername(jsonObjectMain.optString("username"));
                            mSession.setName(jsonObjectMain.optString("name"));
                            mSession.setPersonName(jsonObjectMain.optString("name"));
                            mSession.setBrokerFullName(jsonObjectMain.optString("name"));
                            mSession.setPAN(jsonObjectMain.optString("pan"));
                            mSession.setUid(jsonObjectMain.optString("uid"));
                            mSession.setLead(jsonObjectMain.optString("isLead"));
                            mSession.setUserBrokerDomain(jsonObjectMain.optString("brokerDomain"));
                            mSession.setLoginType(jsonObjectMain.optString("userType"));
                            mSession.setLevelId(jsonObjectMain.optString("levelid"));
                            mSession.setBid(jsonObjectMain.optString("bid"));
                            mSession.setBrokerUID(jsonObjectMain.optString("brokerUid"));
                            mSession.setLowerReportingLevels(jsonObjectMain.optString("lowerReportingLevels"));
                            mSession.setLevelNo(jsonObjectMain.optString("levelNo"));
                            mSession.setReportingLevelName(jsonObjectMain.optString("reportingLevelName"));
                            mSession.setAllLoginData(response);
                            mSession.setAppId(jsonObjectMain.optString("appid"));
                            mSession.setHideXirr(jsonObjectMain.optString("hideXirr"));
                            mSession.setPAN(jsonObjectMain.optString("pan"));
                            mSession.setAppId(jsonObjectMain.optString("appid"));
                            mSession.setIsLargeIfa(jsonObjectMain.optInt("isLargeIfa"));
                            mSession.setEmail(jsonObjectMain.optString("email"));
                            mSession.setClientPhotoName(jsonObjectMain.optString("profileImage"));
                            mSession.setPhone(jsonObjectMain.optString("phone").equalsIgnoreCase("null") ? "" : jsonObjectMain.optString("phone"));
                            AppApplication appApplication = (AppApplication) getApplication();
                            appApplication.removedTempData();


                            mSession.setHasSoaDownloadEnable(jsonObjectMain.optString("allowSOADownload").equals("1"));
                            AppApplication.sExchangeType = "";

                            mSession.setHasTransectionEnable(jsonObjectMain.optString("txnEnable").equals("1"));

                            mSession.setHasEdge360(jsonObjectMain.optString("useEdge360").equals("1"));
//                        mSession.setShowBseAuthPopup(jsonObjectMain.optString("showBseAuthPopup").equals("1"));

                            mSession.setHasBDCardWithStar(jsonObjectMain.optString("hideMetrics").equals("1"));

                            mSession.setHasBseOpted(jsonObjectMain.optString("bseOpted").equals("1"));

                            mSession.setHasNseOpted(jsonObjectMain.optString("nseOpted").equals("1"));

                            mSession.setHasNse2Opted(jsonObjectMain.optString("nseInvestOpted").equals("1"));

                            mSession.setHasMfuOpted(jsonObjectMain.optString("mfuOpted").equals("1"));

                            if (mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted()) && !mSession.getHasMfuOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasBseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else mSession.setHasMultiExchange((mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasNseOpted());
                            // nseInvest can't be default exchange
                            if (!mSession.getHasMultiExchange()) {
                                boolean hasBse = mSession.getHasBseOpted();
                                boolean hasNse = mSession.getHasNseOpted();
                                boolean hasMfu = mSession.getHasMfuOpted();
                                boolean hasNse2 = mSession.getHasNse2Opted();
                                String exchange = "";
                                if (hasNse) {
                                    exchange = "1";
                                } else if (hasBse) {
                                    exchange = "2";
                                } else if (hasMfu) {
                                    exchange = "3";
                                } else if (hasNse2) {
                                    exchange = "4";
                                }
                                mSession.setExchangeNseBseMfu(exchange);
                            }


                            mSession.setHasLoging(true);
                            Config.sOncePopupPerLoginSession = false;
                            if (mSession.getHasAppLockEnable()) {
                                if (mSession.getLoginType().equals("broker")) {
                                    Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                                    CrmBuilder.copyStringExtras(
                                            mIntent,
                                            intent,
                                            "coming_from",
                                            "data"
                                    );
                                    if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                        intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                    }
                                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    mSession.setHasFirstTimeAppIntroLaunched(true);
                                    startActivity(intent);
                                    finish();
                                } else if (mSession.getLoginType().equals("admin")) {
                                    Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    mSession.setHasFirstTimeAppIntroLaunched(true);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                                    if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                        intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                    }

                                    AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    startActivity(intent);
                                    finish();
                                }

                            } else {
                                Intent intent = new Intent(getApplicationContext(), AppLockOptionActivity.class);
                                CrmBuilder.copyStringExtras(
                                        mIntent,
                                        intent,
                                        "coming_from",
                                        "data"
                                );
                                if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                    intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                }
                                intent.putExtra("type", "set_screen_lock");
                                intent.putExtra("callFrom", "login");
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP | android.content.Intent.FLAG_ACTIVITY_NEW_TASK | android.content.Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                mSession.setHasFirstTimeAppIntroLaunched(true);
                                startActivity(intent);
                                finish();
                            }
                            callAllowedFeatures();
                        }

                    } else {
                        String errorMessge = jsonObject.optString("message");
                        if (!errorMessge.equalsIgnoreCase("invalid request"))
                            Toast.makeText(LoginActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    String data = e.getLocalizedMessage();
                    System.out.println(data);
                }
            }

            @Override
            public void onError(String errorMessage, int statusCode) {
                mRelMain.setVisibility(View.VISIBLE);
            }
        });
    }

    private void callAllowedFeatures() {
        String url = "";
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.BROKER_ALLOWED_FEATURES;
        } else {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_ALLOWED_FEATURES + Utils.getSelectedUserObject(mSession);
        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject resultData = jsonObject.optJSONObject("result");
                    if (jsonObject.optInt("status") == 0) {

                        if (resultData != null) {
                            mSession.setAllowedFeatures("" + resultData);

                        }
                    } else {
                        String errorMessge = jsonObject.optString("message");
                        if (!errorMessge.equalsIgnoreCase("invalid request"))
                            Toast.makeText(LoginActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException ignored) {

                }
            }
        });
    }


    private void GoogleLoginMethod() {
        String url = "https://" + mDomainName + mSession.getHostingPath() + Config.GOOGLE_AUTHENTICATION;
        JSONObject objectMain = new JSONObject();
        try {
            objectMain.put("domain", mDomainName);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("id_token", mGToken);
            objectMain.put("tokens", jsonObject);
            objectMain.put("rememberMe", "true");
        } catch (Exception ignored) {

        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, objectMain, AppHeaderType.LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(LoginActivity.this);
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                UtilityKotlin.setRefreshKey(mSession);
                ProgressBarCommon.dismissDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        insertApiData(url, objectMain.toString(), jsonObject.toString(), TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GOOGLE_AUTHENTICATION);
                        mSession.setShowCrossDialog(true);

                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        mSession.setLoginBy("google");
                        mSession.setGoogleToken(mGToken);
                        mSession.setLoginTypeEvent("google");
                        if (!mLogoPath.isEmpty()) {
                            mSession.setAppLogo(mLogoPath);
                        }

                        if (jsonObjectMain.has("token")) {
                            Intent intent = new Intent(LoginActivity.this, MobileVerificationActivity.class);
                            intent.putExtra("token", jsonObjectMain.optString("token"));
                            intent.putExtra("mobile", jsonObjectMain.optString("mobile"));
                            intent.putExtra("type", "twoFactor");
                            intent.putExtra("isTwoFa", true);
                            startActivity(intent);
                        } else {
                            if (getString(R.string.subdomain).equals("sdk")) {
                                AppApplication appApplication = (AppApplication) getApplication();
                                appApplication.GtmSetUp(jsonObjectMain.optString("levelNo"), jsonObjectMain.optString("name"));
                            }

                            mSession.setUsername(jsonObjectMain.optString("username"));
                            mSession.setName(jsonObjectMain.optString("name"));
                            mSession.setPersonName(jsonObjectMain.optString("name"));
                            mSession.setBrokerFullName(jsonObjectMain.optString("name"));
                            mSession.setUid(jsonObjectMain.optString("uid"));
                            mSession.setLead(jsonObjectMain.optString("isLead"));
                            mSession.setUserBrokerDomain(jsonObjectMain.optString("brokerDomain"));
                            mSession.setLoginType(jsonObjectMain.optString("userType"));
                            mSession.setLevelId(jsonObjectMain.optString("levelid"));
                            mSession.setBid(jsonObjectMain.optString("bid"));
                            mSession.setBrokerUID(jsonObjectMain.optString("brokerUid"));
                            mSession.setLowerReportingLevels(jsonObjectMain.optString("lowerReportingLevels"));
                            mSession.setLevelNo(jsonObjectMain.optString("levelNo"));
                            mSession.setReportingLevelName(jsonObjectMain.optString("reportingLevelName"));
                            mSession.setEmail(jsonObjectMain.optString("email"));
                            mSession.setClientPhotoName(jsonObjectMain.optString("profileImage"));
                            mSession.setIsLargeIfa(jsonObjectMain.optInt("isLargeIfa"));
                            AppApplication appApplication = (AppApplication) getApplication();
                            appApplication.removedTempData();
                            mSession.setHideXirr(jsonObjectMain.optString("hideXirr"));
                            mSession.setPAN(jsonObjectMain.optString("pan"));
                            mSession.setAppId(jsonObjectMain.optString("appid"));
                            mSession.setPhone(jsonObjectMain.optString("phone").equalsIgnoreCase("null") ? "" : jsonObjectMain.optString("phone"));


                            mSession.setHasSoaDownloadEnable(jsonObjectMain.optString("allowSOADownload").equals("1"));
                            AppApplication.sExchangeType = "";
//                            mSession.setShowBseAuthPopup(jsonObjectMain.optString("showBseAuthPopup").equals("1"));

                            mSession.setHasTransectionEnable(jsonObjectMain.optString("txnEnable").equals("1"));

                            mSession.setHasEdge360(jsonObjectMain.optString("useEdge360").equals("1"));

                            mSession.setHasBDCardWithStar(jsonObjectMain.optString("hideMetrics").equals("1"));

                            mSession.setHasBseOpted(jsonObjectMain.optString("bseOpted").equals("1"));

                            mSession.setHasNseOpted(jsonObjectMain.optString("nseOpted").equals("1"));
                            mSession.setHasNse2Opted(jsonObjectMain.optString("nseInvestOpted").equals("1"));

                            mSession.setHasMfuOpted(jsonObjectMain.optString("mfuOpted").equals("1"));

                            if (mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted()) && !mSession.getHasMfuOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasBseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else mSession.setHasMultiExchange((mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasNseOpted());

                            // nseInvest can't be default exchange
                            if (!mSession.getHasMultiExchange()) {
                                boolean hasBse = mSession.getHasBseOpted();
                                boolean hasNse = mSession.getHasNseOpted();
                                boolean hasMfu = mSession.getHasMfuOpted();
                                boolean hasNse2 = mSession.getHasNse2Opted();
                                String exchange = "";
                                if (hasNse) {
                                    exchange = "1";
                                } else if (hasBse) {
                                    exchange = "2";
                                } else if (hasMfu) {
                                    exchange = "3";
                                } else if (hasNse2) {
                                    exchange = "4";
                                }
                                mSession.setExchangeNseBseMfu(exchange);
                            }
                            mSession.setHasLoging(true);
                            Config.sOncePopupPerLoginSession = false;


                            if (mSession.getHasAppLockEnable()) {
                                if (mSession.getLoginType().equals("broker")) {
                                    Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                                    if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                        intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                    }
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    mSession.setHasFirstTimeAppIntroLaunched(true);
                                    startActivity(intent);
                                    finish();
                                } else if (mSession.getLoginType().equals("admin")) {
                                    Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                                    if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                        intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                    }
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    mSession.setHasFirstTimeAppIntroLaunched(true);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                                    if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                        intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                    }
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                    mSession.setHasFirstTimeAppIntroLaunched(true);
                                    startActivity(intent);
                                    finish();
                                }

                            } else {
                                Intent intent = new Intent(getApplicationContext(), AppLockOptionActivity.class);
                                if (mIntent.hasExtra("transactionDeeplinkUrl")) {
                                    intent.putExtra("transactionDeeplinkUrl", mIntent.getStringExtra("transactionDeeplinkUrl"));
                                }
                                intent.putExtra("type", "set_screen_lock");
                                intent.putExtra("callFrom", "login");
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                mSession.setHasFirstTimeAppIntroLaunched(true);
                                startActivity(intent);
                                finish();
                            }
                            callAllowedFeatures();
                        }


                    } else {
                        if (jsonObject.optString("message").equalsIgnoreCase("Invalid Token")) {
                            getGmailUserDetails();
                        } else {
                            String errorMessge = jsonObject.optString("message");
                            if (!errorMessge.equalsIgnoreCase("invalid request"))
                                Toast.makeText(LoginActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {

                }
            }

            @Override
            public void onError(String errorMessage, int statusCode) {
                mRelMain.setVisibility(View.VISIBLE);
            }
        });
    }

    private void setRedirection(){

    }
    public void ForgotPassword(final String email) {
        String url = "https://" + mDomainName + mSession.getHostingPath() + Config.FORGOT_PASSWORD;
        try {
            JSONObject params = new JSONObject();
            params.put("username", email);
        } catch (Exception ignored) {

        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(LoginActivity.this);
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    insertApiData(url, "", jsonObject.toString(), TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.FORGOT_PASSWORD);
                    if (jsonObject.optInt("status") == 0) {
                        getAlert();
                    } else {
                        Toast.makeText(LoginActivity.this, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception ignored) {

                }
            }
        });


    }

    private void getAlert() {
        AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
        ViewGroup viewGroup = findViewById(android.R.id.content);

        View dialogView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.dialog_forgot_pwd_succes, viewGroup, false);
        builder.setView(dialogView);
        AlertDialog alertDialog = builder.create();
        alertDialog.setCanceledOnTouchOutside(false);
        alertDialog.show();

        MaterialButton ok = alertDialog.findViewById(R.id.textViewOk);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

    }

    private void dailogForgetPassword() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle(getResources().getString(R.string.Forget_Password));
        alert.setMessage(getResources().getString(R.string.Please_enter_username));
        final EditText email = new EditText(this);
        LinearLayout lay = new LinearLayout(this);
        lay.setOrientation(LinearLayout.VERTICAL);
        email.setInputType(InputType.TYPE_CLASS_TEXT);
        lay.addView(email);
        alert.setView(lay);

        alert.setPositiveButton(getResources().getString(R.string.Ok), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub

                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        if (imm.isAcceptingText()) {
                            imm.hideSoftInputFromWindow(email.getWindowToken(), 0);
                        }
                        if (email.getText().toString().equals("")) {
                            Toast.makeText(getApplicationContext(), getResources().getString(R.string.Please_enter_valid_username), Toast.LENGTH_SHORT).show();
                        } else {
                            //  ForgotPassword(email.getText().toString().trim());
                            ForgotPassword(email.getText().toString());

                        }

                    }
                }

        );

        alert.setNegativeButton(getResources().getString(R.string.Cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm.isAcceptingText()) {
                    imm.hideSoftInputFromWindow(email.getWindowToken(), 0);
                }
            }
        });

        alert.show();
    }


}
