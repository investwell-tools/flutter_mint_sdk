package investwell.client.fragments.portfolio;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPortfolioSchemeDetailAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.SortData;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

;

public class PortfolioSchemeDetail extends BaseFragment implements View.OnClickListener {
    TextView user_name, cardview_top_name_color, purchase_cost, market_value, folio_number, gain, balance_unit, holding, abs_return, cagr;
    DecimalFormat myFormatter = new DecimalFormat("##,##,###.00");
    private AppSession mSession;
    private String mCID = "";
    private ClientActivity mActivity;
    private CardView mCardVidew;
    private JSONObject mJsonObject, tranJsonObject;
    private RequestQueue requestQueue;
    private GridViewAdapter mGridAdapter;
    private TextView mTvErrorMessage;
    private FragPortfolioSchemeDetailAdapter mFragPortfolioSchemeDetailsADapter;
    public String mFolioId = "", mAppId = "";
    private AppApplication mAppplication;
    private ToolbarFragment mFragToolBar;
private GridView gridView;
    @Override
    public void onResume() {
        super.onResume();
     /*   if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.portfolio), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag_portfolio_scheme_detail, container, false);
        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setUpToolBar();
            }
        });


        user_name = view.findViewById(R.id.user_name);
        cardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);
        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        folio_number = view.findViewById(R.id.folio_number);
        gain = view.findViewById(R.id.gain);
        balance_unit = view.findViewById(R.id.balance_unit);
        holding = view.findViewById(R.id.holding);
        abs_return = view.findViewById(R.id.abs_return);
        cagr = view.findViewById(R.id.cagr);

        gridView= view.findViewById(R.id.gridView);
        mGridAdapter = new GridViewAdapter(getActivity(), new ArrayList<String>());
        gridView.setAdapter(mGridAdapter);
        mCardVidew = view.findViewById(R.id.cardView);
        mTvErrorMessage = view.findViewById(R.id.tvErrorMessage);

        RecyclerView rvTRansections = view.findViewById(R.id.rvTRansections);
        rvTRansections.setNestedScrollingEnabled(false);
        rvTRansections.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mFragPortfolioSchemeDetailsADapter = new FragPortfolioSchemeDetailAdapter(getActivity(), new ArrayList<JSONObject>());
        rvTRansections.setAdapter(mFragPortfolioSchemeDetailsADapter);


        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mJsonObject = new JSONObject(bundle.getString("data"));
                user_name.setText(mJsonObject.optString("applicant_name"));
                cardview_top_name_color.setText(mJsonObject.optString("schemeName"));
                purchase_cost.setText(myFormatter.format(Double.parseDouble(mJsonObject.optString("purchaseValue"))));
                market_value.setText(myFormatter.format(Double.parseDouble(mJsonObject.optString("currentValue"))));
                mFolioId = mJsonObject.optString("folioid");
                mAppId = mJsonObject.optString("appid");
                folio_number.setText(mJsonObject.optString("folioNo"));

                gain.setText(getString(R.string.Rs) + myFormatter.format(Double.parseDouble(mJsonObject.optString("gain"))));

                try {
                    double avgHoldingDays = mJsonObject.optDouble("avgHoldingDays");
                    long rounded = Math.round(avgHoldingDays);
                    int days = (rounded <= Integer.MAX_VALUE) ? (int) rounded : Integer.MAX_VALUE;
                    holding.setText("" + days);
                }
                catch (Exception e){
                    holding.setText("");
                }

                double longValue = mJsonObject.optDouble("balanceUnits");
                if (longValue > 0) {
                    String data1 = String.format("%.4f", longValue);
                    balance_unit.setText(data1);
                } else {
                    balance_unit.setText("0");
                }

                double absoluteReturnValue = mJsonObject.optDouble("absoluteReturn");
                String data2 = String.format("%.2f", absoluteReturnValue) + "%";
                abs_return.setText(data2);

                double cgrValue = mJsonObject.optDouble("CAGR");
                String data3 = String.format("%.2f", cgrValue) + "%";
                cagr.setText(data3);

            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }

        if (mSession.getExchangeNseBseMfu().equals("1")) {
            String iinNo = mJsonObject.optString("iinNo");
            if (iinNo.equals("") || iinNo == null || iinNo.equals("null")) {
                mCardVidew.setVisibility(View.GONE);
                mTvErrorMessage.setVisibility(View.GONE);
                getTransection(true);
            } else {
                mCardVidew.setVisibility(View.GONE);
                mTvErrorMessage.setVisibility(View.GONE);
                String schemeId = Utils.getSchemeIdFromAll(mJsonObject);
                getAllTransectionTypes(schemeId);
            }
        } else if (mSession.getExchangeNseBseMfu().equals("2")) {
            String ucc = mJsonObject.optString("uccNumber");
            if (ucc.equals("") || ucc == null || ucc.equals("null")) {
                mCardVidew.setVisibility(View.GONE);
                mTvErrorMessage.setVisibility(View.GONE);
                getTransection(true);
            } else {
                mCardVidew.setVisibility(View.GONE);
                mTvErrorMessage.setVisibility(View.GONE);
                String schemeId = Utils.getSchemeIdFromAll(mJsonObject);
                getAllTransectionTypes(schemeId);
            }
        } else if (mSession.getExchangeNseBseMfu().equals("3")) {

        }


      /*  mCardVidew.setVisibility(View.GONE);
        mTvErrorMessage.setVisibility(View.GONE);*/

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String transectionType = mGridAdapter.mList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("oldObject", mJsonObject.toString());
                bundle.putString("tranJsonObject", tranJsonObject.toString());
                bundle.putString("transactionType", transectionType);

                if (transectionType.equalsIgnoreCase("NRP")) {
                    if (mSession.getExchangeNseBseMfu().equals("1")) {
                        mActivity.displayViewOther(27, bundle);
                    } else if (mSession.getExchangeNseBseMfu().equals("2")) {
                        mActivity.displayViewOther(8, bundle);
                    } else if (mSession.getExchangeNseBseMfu().equals("3")) {

                    }

                } else if (transectionType.equalsIgnoreCase("SIP")) {
                    if (mSession.getExchangeNseBseMfu().equals("1")) {
                        mActivity.displayViewOther(28, bundle);
                    } else if (mSession.getExchangeNseBseMfu().equals("2")) {
                        mActivity.displayViewOther(9, bundle);
                    } else if (mSession.getExchangeNseBseMfu().equals("3")) {

                    }

                } else if (transectionType.equalsIgnoreCase("SWO")) {
                    mActivity.displayViewOther(10, bundle);
                } else if (transectionType.equalsIgnoreCase("SWP")) {
                    if (mSession.getExchangeNseBseMfu().equals("1")) {
                        mActivity.displayViewOther(86, bundle);
                    } else{
                        mActivity.displayViewOther(11, bundle);
                    }


                } else if (transectionType.equalsIgnoreCase("STP")) {
                    if (mSession.getExchangeNseBseMfu().equals("1")) {
                        mActivity.displayViewOther(87, bundle);
                    } else{
                        mActivity.displayViewOther(12, bundle);
                    }

                } else if (transectionType.equalsIgnoreCase("NRS")) {
                    mActivity.displayViewOther(13, bundle);
                }
            }
        });

        if (gain.getText().toString().contains("-")) {
            gain.setTextColor(Color.parseColor("#d01f1f"));
        } else {
            gain.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
        }


        if (abs_return.getText().toString().contains("-")) {
            abs_return.setTextColor(Color.parseColor("#d01f1f"));
        } else {
            abs_return.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
        }

        if (cagr.getText().toString().contains("-")) {
            cagr.setTextColor(Color.parseColor("#d01f1f"));
        } else {
            cagr.setTextColor(ContextCompat.getColor(getActivity(), R.color.white));
        }
        setUpTransactionButtonUi();
        return view;
    }

    private void setUpTransactionButtonUi() {
        if (mSession.getHasTransectionEnable()) {
            gridView.setVisibility(View.GONE);
        } else {
            gridView.setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }


    private void getTransection(boolean isShowLoader) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (isShowLoader)
            mAppplication.showProgressBar(mActivity);

        String url = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(new Date());

            JSONArray jsonArray = new JSONArray();

            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);

            JSONObject dateObject2 = new JSONObject();
            dateObject2.put("appid", mAppId);
            jsonArray.put(dateObject2);

            JSONObject dateObject3 = new JSONObject();
            dateObject3.put("folioid", mFolioId);
            jsonArray.put(dateObject3);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioTable");


            //  https://demo.investwell.app/webapi/client/dashboard/getDetailedPortFolioReturns?filters=
            // [{"endDate":"2019-08-28"},{"appid":"c2f8d9991f70107520d8bb771539d900"},
            // {"folioid":"0d16acfc71e45169713e8dc49906c779"}]&componentForLoader=
            // {"componentName":"folioTable"}&pageSize=20¤tPage=1&investorUid=
            // 5553ce3575b8e1a64181794eb86c5b27&selectedUser={"uid":"5553ce3575b8e1a64181794eb86c5b27
            // ","levelNo":"98"}


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FOLIO_SCHEME_DETAILS + "filters=" + jsonArray.toString()
                    + "&pageSize=100&currentPage=1" +
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession)+ "" + "&clubTxns=true" +
                    "&orderBy=purchaseDate" + "&orderByDesc=true";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        mAppplication.hideProgressDaolog();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject tranJsonObject = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = tranJsonObject.getJSONArray("rows");
                                ArrayList<JSONObject> list = new ArrayList<>();
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }
                                Collections.sort(list, new SortData("purchaseDate"));


                                mFragPortfolioSchemeDetailsADapter.updateList(list);


                            } else if (jsonObject.optInt("status") == -1) {
                                AppApplication appApplication = (AppApplication) getActivity().getApplication();
                                appApplication.showCommonDailog(getActivity(), getString(R.string.failed), jsonObject.optString("message"), "message");

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        mAppplication.hideProgressDaolog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getAllTransectionTypes(String schemeCode) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mAppplication.showProgressBar(mActivity);
        String url = "";

        try {
            String varableForBSeMfu = "";
            if (mSession.getExchangeNseBseMfu().equals("1")) {
                varableForBSeMfu = "&hasNseCode=true";
            }else if (mSession.getExchangeNseBseMfu().equals("2")) {
                varableForBSeMfu = "&hasBseCode=true";
            } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                varableForBSeMfu = "&hasMfuCode=true";
            }else if (mSession.getExchangeNseBseMfu().equals("4")) {
                varableForBSeMfu = "&hasNseInvestCode=true"  ;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TRANSECTION_TYPE +
                    "schid=" + schemeCode + varableForBSeMfu+"&investorUid=" + Utils.getSelectedUid(mSession) +
                    "&selectedUser="+Utils.getSelectedUserObject(mSession) + "&bid=" + mSession.getBid() +
                    "&levelid=" + mSession.getLevelId();
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
//                        if (mBar != null)
//                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                tranJsonObject = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = tranJsonObject.getJSONArray("allowedInvestmentTypes");
                                if (jsonArray.length() > 0) {
                                    mCardVidew.setVisibility(View.GONE);
                                    ArrayList<String> list = new ArrayList<>();
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        String transectionType = jsonArray.getString(i);

                                       /* if (mSession.getHasNSE()) { // if all transaction will be complete then i will remove this , right now only three transactions are working
                                            if (transectionType.equalsIgnoreCase("NRP")) {
                                                list.add(transectionType);
                                            } else if (transectionType.equalsIgnoreCase("SWO")) {
                                                list.add(transectionType);
                                            } else if (transectionType.equalsIgnoreCase("NRS")) {
                                                list.add(transectionType);
                                            }
                                        }else{
                                            list.add(transectionType);
                                        }*/

                                        list.add(transectionType);
                                    }
                                    mGridAdapter.updateView(list);
                                } else {
                                    mCardVidew.setVisibility(View.GONE);
                                    //  AppApplication appApplication = (AppApplication) getActivity().getApplication();
                                    //   appApplication.showCommonDailog(getActivity(), "Failed", "Transaction not allowed, please contact your advisor", "message");

                                }

                            } else if (jsonObject.optInt("status") == -1) {
                                AppApplication appApplication = (AppApplication) getActivity().getApplication();
                                appApplication.showCommonDailog(getActivity(), getString(R.string.failed), jsonObject.optString("message"), "message");

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        } finally {
                            getTransection(false);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public class GridViewAdapter extends BaseAdapter {
        private Context mContaxt;
        private ArrayList<String> mList;

        public GridViewAdapter(Context context, ArrayList<String> list) {
            mContaxt = context;
            mList = list;
        }

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(mContaxt, R.layout.gridview_item, null);
            }

            ImageView ivIcon = convertView.findViewById(R.id.ivIcon);
            TextView tvText = convertView.findViewById(R.id.tvText);
            String transectionType = mList.get(position);


            if (transectionType.equalsIgnoreCase("NRP")) {
                ivIcon.setImageResource(R.mipmap.purchase2);
                tvText.setText(getString(R.string.purchase));
            } else if (transectionType.equalsIgnoreCase("SWO")) {
                ivIcon.setImageResource(R.mipmap.switch2);
                tvText.setText(getString(R.string.Switch));
            } else if (transectionType.equalsIgnoreCase("NRS")) {
                ivIcon.setImageResource(R.mipmap.redeem2);
                tvText.setText(getString(R.string.redeem));
            } else if (transectionType.equalsIgnoreCase("SWP")) {
                ivIcon.setImageResource(R.mipmap.swp2);
                tvText.setText(getString(R.string.SWP));
            } else if (transectionType.equalsIgnoreCase("STP")) {
                ivIcon.setImageResource(R.mipmap.stp2);
                tvText.setText(getString(R.string.txt_STP));
            } else if (transectionType.equalsIgnoreCase("SIP")) {
                ivIcon.setImageResource(R.mipmap.sip2);
                tvText.setText(getString(R.string.SIP));
            } else {
                ivIcon.setImageResource(R.mipmap.sip2);
                tvText.setText(transectionType);
            }


            return convertView;
        }

        public void updateView(ArrayList<String> list) {
            mList.clear();
            mList.addAll(list);
            notifyDataSetChanged();
        }
    }

}
