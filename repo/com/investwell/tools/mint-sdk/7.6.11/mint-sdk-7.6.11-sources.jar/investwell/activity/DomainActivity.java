package investwell.activity;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;

import com.google.android.material.textfield.TextInputEditText;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.intro.IntroActivity;
import investwell.common.intro.SingleIntroActivity;
import investwell.utils.ApiRequestType;
import investwell.utils.AppConstants;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class DomainActivity extends BaseActivity implements View.OnClickListener {
    private TextInputEditText mAtBroker;
    private AppSession mSession;
    private ImageView mIvlogo;
    private String whereToNavigate = "";
    private ApiDataBase db;
    TextView tvSlogan, tvText1;
    private LinearLayout llLogoText;

//    private static final int RC_LANGUAGE_SELECTION = 1001;


    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        Extensions.checkDevice(this);
        mSession = AppSession.getInstance(this);
        Extensions.updateLocale(this,mSession.getAppLanguage());
        db = ApiDataBase.getInstance(getApplicationContext());
        Log.d("ActivityCalled", "onCreate Called SplashActivity");

        Utils.setTheme(this,mSession);
        getDataFromBundle();
        if (getString(R.string.subdomain).equals("mint")) {
            setContentView(R.layout.activity_domain);
            mAtBroker = findViewById(R.id.tietUser);
            MaterialButton btLogin = findViewById(R.id.tvLogin);
            llLogoText = findViewById(R.id.llLogoText);
            tvText1 = findViewById(R.id.tvText1);

            mIvlogo = findViewById(R.id.ivlogo);
            btLogin.setOnClickListener(this);
            String imagePath = mSession.getAppLogo();
            tvSlogan = findViewById(R.id.tvSlogan);
            if (mSession.getSloganOnLogo().length() > 0) {
                tvSlogan.setText(mSession.getSloganOnLogo());
                tvSlogan.setVisibility(View.VISIBLE);
            } else {
                tvSlogan.setVisibility(View.GONE);
            }

            setTintColorIfDark(this,mIvlogo);
            mIvlogo.setContentDescription(mSession.getCompanyName() + ". logo");
            if (getString(R.string.subdomain).equals("mint")) {
                if (!imagePath.equals("")) {
                    Picasso.get().invalidate(imagePath);
                    Picasso.get().load(imagePath).error(R.drawable.app_logo_secondry_mint).into(mIvlogo);
                } else {
                    mIvlogo.setImageResource(R.drawable.app_logo_secondry_mint);
                }
            } else {
                mIvlogo.setImageResource(R.mipmap.app_logo_secondry);
            }


            mAtBroker.requestFocus();
            mAtBroker.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    String domainName = mAtBroker.getText().toString().toLowerCase().trim();
                    if (domainName.startsWith("#") && domainName.endsWith("#")) {
                        domainName = domainName.replaceAll("#", "");
                    } else if (domainName.startsWith("*") && domainName.endsWith("*")) {
                        domainName = domainName.replaceAll("\\*", "");
                    } else if (domainName.startsWith("&") && domainName.endsWith("&")) {
                        domainName = domainName.replaceAll("&", "");
                    }else if (domainName.startsWith("@") && domainName.endsWith("@")) {
                        domainName = domainName.replaceAll("@", "");
                    }
                    final String imagePath1 = Config.IMAGE_PATH + domainName + "_Logo.png";
                    Picasso.get().invalidate(imagePath1);
                    Picasso.get().load(imagePath1).into(mIvlogo, new Callback() {
                        @Override
                        public void onSuccess() {
                            // mSession.setAppLogo(imagePath);
                        }

                        @Override
                        public void onError(Exception e) {
                            Picasso.get().invalidate(imagePath1);
                            if (getString(R.string.subdomain).equals("mint")) {
                                if (!imagePath.equals("")) {
                                    Picasso.get().invalidate(imagePath);
                                    Picasso.get().load(imagePath).error(R.drawable.app_logo_secondry_mint).into(mIvlogo);
                                } else {
                                    mIvlogo.setImageResource(R.drawable.app_logo_secondry_mint);
                                }
                            } else {
                                mIvlogo.setImageResource(R.mipmap.app_logo_secondry);
                            }
                        }

                    });


                }
            });
        } else {
            forStaticApp();
        }

        logoAndTextAlignment();
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvLogin) {
                LoginValidations();
}
    }

    private void logoAndTextAlignment() {
        try {
            JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
                if (sectionJSONArray != null) {
                    String logoAlignment = UtilityKotlin.getFeatureSettingByName(sectionJSONArray, "LogoAlignment");
                    if (!"Left".equalsIgnoreCase(logoAlignment)) {

                        llLogoText.setGravity(Gravity.CENTER);

                        int maxHeight = (int) (100 * getResources().getDisplayMetrics().density); // 100dp to px
                        int topMargin = (int) (10 * getResources().getDisplayMetrics().density);

                        LinearLayout.LayoutParams imageViewParams = (LinearLayout.LayoutParams) mIvlogo.getLayoutParams();
                        imageViewParams.gravity = Gravity.CENTER;
                        imageViewParams.topMargin = topMargin;
                        mIvlogo.setLayoutParams(imageViewParams);
                        mIvlogo.setAdjustViewBounds(true);
                        mIvlogo.setMaxHeight(maxHeight);

                        LinearLayout.LayoutParams tvSloganParams = (LinearLayout.LayoutParams) tvSlogan.getLayoutParams();
                        tvSloganParams.gravity = Gravity.CENTER;
                        tvSlogan.setLayoutParams(tvSloganParams);

                        LinearLayout.LayoutParams tvText1Params = (LinearLayout.LayoutParams) tvText1.getLayoutParams();
                        tvText1Params.gravity = Gravity.CENTER;
                        tvText1.setLayoutParams(tvText1Params);



                    }
                }

            }


        } catch (Exception e) {

        }
    }


    private void getDataFromBundle() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("login_come_from")) {
            whereToNavigate = intent.getStringExtra("login_come_from");
        }
    }

    private void forStaticApp() {
        String domainName = getString(R.string.subdomain);
        mSession.setHostingPath(".investwell.app/webapi/");
        getPublicInfoForCustomApp(domainName);
    }


    private void LoginValidations() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isAcceptingText()) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        String domainName = mAtBroker.getText().toString().toLowerCase().trim();
        if (domainName.trim().equals("")) {
            Toast.makeText(this, R.string.txt_please_enter_broker_domain, Toast.LENGTH_SHORT).show();
        } else {
            if (domainName.startsWith("#") && domainName.endsWith("#")) {
                mSession.setHostingPath(".investwell.io/webapi/");
                domainName = domainName.replaceAll("#", "");
            } else if (domainName.startsWith("*") && domainName.endsWith("*")) {
                mSession.setHostingPath(".iwmint.com/webapi/");
                domainName = domainName.replaceAll("\\*", "");
            } else if (domainName.startsWith("&") && domainName.endsWith("&")) {
                mSession.setHostingPath(".getinvestwell.com/webapi/");
                domainName = domainName.replaceAll("&", "");
            }else if (domainName.startsWith("$") && domainName.endsWith("$")){
                mSession.setHostingPath(".letsinvestwell.com/webapi/");
                domainName = domainName.replaceAll("\\$", "");
            }else if (domainName.startsWith("@") && domainName.endsWith("@")) {
                mSession.setHostingPath(".your-portfolio.co.in/webapi/");
                domainName = domainName.replaceAll("@", "");
            } else {
                mSession.setHostingPath(".investwell.app/webapi/");
            }
            getPublicInfo(domainName);
        }

    }

    private void activitySelection(String imagePathFinal, JSONObject jsonObject1) {
        String playstoreLink = mSession.getPlayStoreLink();
        if (getString(R.string.subdomain).equals("mint") && !playstoreLink.equalsIgnoreCase("null") && !playstoreLink.isEmpty() && !playstoreLink.contains("com.iw.mint.sdk")) {
            Intent intent = new Intent(getApplicationContext(), PlaystoreAppActivity.class);
            intent.putExtra("domain_name", mSession.getUserBrokerDomain());
            intent.putExtra("logoPath", imagePathFinal);
            startActivity(intent);
            DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
        } else {
            if (!TextUtils.isEmpty(whereToNavigate) && whereToNavigate.equalsIgnoreCase("Register")) {
                UtilityKotlin.openNewKycOnboardingInWebView(this, mSession, "0", "signUp","");
            } else {
                if ((!TextUtils.isEmpty(jsonObject1.optString("layout")) && jsonObject1.optString("layout").equalsIgnoreCase("2"))) {
                    Intent intent = new Intent(getApplicationContext(), SingleIntroActivity.class);
                    intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                    intent.putExtra("logoPath", imagePathFinal);
                    startActivity(intent);
                    DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                } else if ((!TextUtils.isEmpty(jsonObject1.optString("layout")) && jsonObject1.optString("layout").equalsIgnoreCase("3"))) {
                    Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
                    intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                    intent.putExtra("logoPath", imagePathFinal);
                    startActivity(intent);
                    DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                } else {
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                    intent.putExtra("logoPath", imagePathFinal);
                    startActivity(intent);
                    DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                }

            }

        }
    }

    private void setNewAppConfig(String languageCode, String imagePath, JSONObject jsonObjParam) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Subdomain", mSession.getUserBrokerDomain());
            jsonObject.put("Language", UtilityKotlin.getLanguageCodeToValueMap().get(languageCode));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        ProgressBarCommon.showDialog(this);
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, Config.APP_CONFIG, jsonObject, response -> {

            if (response.optBoolean("Status")) {
                mSession.setAppConfig(response.toString());
                mSession.setAppLanguage(languageCode);
                Extensions.updateLocale(this, languageCode);
                activitySelection(imagePath,jsonObjParam);
            }
            ProgressBarCommon.dismissDialog();
        },volleyError -> {
            ProgressBarCommon.dismissDialog();
            mSession.setAppConfig("");
            UtilityKotlin.parseVolleyError(volleyError, mSession, this, "splash");

        });
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                Log.d("getConfigData", "getConfigData: getCurrentRetryCount called =");
                return 4;
            }

            @Override
            public void retry(VolleyError error) {
                System.out.println();
                Log.d("getConfigData", "getConfigData: retry called");
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);
    }



    private void getPublicInfo(final String domainName) {
        logD("getPublicInfo", "getPublicInfo: called on DomainActivity");
        String url = "https://" + domainName + mSession.getHostingPath() + Config.GET_BROKER_PUBLIC_INFO + "brokerDomain=" + domainName + "&userBusinessCode=" + AppConstants.SUB_BROKER_BUSINESS_CODE;
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.OPEN_API, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(DomainActivity.this);
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String imagePath = "";

                    if (jsonObject.optInt("status") == 0) {
                        String entDomainName = mAtBroker.getText().toString().toLowerCase().trim();
                        if (entDomainName.startsWith("#") && entDomainName.endsWith("#")) {
                            mSession.setTestDomainType("prePord1");
                            entDomainName = domainName.replaceAll("#", "");
                            imagePath = Config.IMAGE_PATH + entDomainName + "_Logo.png";

                        } else if (entDomainName.startsWith("*") && entDomainName.endsWith("*")) {
                            entDomainName = domainName.replaceAll("\\*", "");
                            imagePath = Config.IMAGE_PATH + entDomainName + "_Logo.png";
                            mSession.setTestDomainType("iwmint");
                        } else if (entDomainName.startsWith("&") && entDomainName.endsWith("&")) {
                            entDomainName = domainName.replaceAll("&", "");
                            imagePath = Config.IMAGE_PATH + entDomainName + "_Logo.png";
                            mSession.setTestDomainType("prePord2");
                        }else if (entDomainName.startsWith("$") && entDomainName.endsWith("$")){
                            entDomainName=domainName.replaceAll("\\$","");
                            imagePath  = Config.IMAGE_PATH+entDomainName+"_Logo.png";
                            mSession.setTestDomainType("preProd4");
                        } else if (entDomainName.startsWith("@") && entDomainName.endsWith("@")){
                            entDomainName=domainName.replaceAll("@","");
                            imagePath  = Config.IMAGE_PATH+entDomainName+"_Logo.png";
                            mSession.setTestDomainType("preProd5");
                        }else {
                            mSession.setTestDomainType("");
                            imagePath = Config.IMAGE_PATH + entDomainName + "_Logo.png";
                        }

                        mSession.setAppLogo(imagePath);

                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        //jsonObject1.put("layout", "5");
                        mSession.setShowBseAuthPopup("1".equals(jsonObject1.optString("showBseAuthPopup").trim()));

                        mSession.setAppLogoName(jsonObject1.optString("logo"));
                        mSession.setFutureProjectionCalculator(jsonObject1.optInt("futureProjectionCalculator"));
                        mSession.setSIPCalculator(jsonObject1.optInt("SIPCalculator"));
                        mSession.setPlayStoreLink(jsonObject1.optString("androidAppLink"));
                        mSession.setAppStoreLink(jsonObject1.optString("iosAppLink"));
                        mSession.setCompanyName(jsonObject1.optString("compName"));
                        mSession.setAllowedCrm(jsonObject1.optInt("allowCrm",0)==1);
                        mSession.setOnBoarding(jsonObject1.optInt("allowOnboarding"));
                        mSession.setAllowedMobileOTPLogin(jsonObject1.optInt("allowMobileOtpLogin"));
                        mSession.setUserEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setWebsite(jsonObject1.optString("website").equalsIgnoreCase("null") ? "" : jsonObject1.optString("website"));
                        mSession.setMobileNumber(jsonObject1.optString("mobileNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("mobileNo1"));
                        mSession.setTelNumber(jsonObject1.optString("telNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("telNo1"));
                        mSession.setVoltPartnerCode(jsonObject1.optString("voltPartnerCode").equalsIgnoreCase("null") ? "" : jsonObject1.optString("voltPartnerCode"));

                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        mSession.setHasShowXirr(jsonObject1.optString("showXIRR").equals("1"));
                        String domain = jsonObject1.optString("domain");
                        if (!domain.equalsIgnoreCase("null") && !domain.isEmpty()) {
                            mSession.setUserBrokerDomain(domain);
                        }
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
                            jsonObject1.put("layout", 6);
                        }

                        mSession.setAppInfo("" + jsonObject1);
                        mSession.setIsRiskProfileMandatory(jsonObject1.optInt("isRiskProfileManadatory"));

                        String address = "";
                        address = UtilityKotlin.checkAndGetCompanyAddress(jsonObject1);
                        mSession.setAddress(address);
                        mSession.setCustomURL(jsonObject1.getString("customURL").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customURL"));



                        String slogan = jsonObject1.optString("slogan");
                        if (!slogan.equalsIgnoreCase("null") && !slogan.isEmpty()) {
                            mSession.setSloganOnLogo(slogan);
                        }
                        tvSlogan.setText(mSession.getSloganOnLogo());
                        Picasso.get().invalidate(imagePath);
                        final String imagePathFinal = imagePath;
                        String layout = jsonObject1.optString("layout");
                        Picasso.get().load(imagePath).memoryPolicy(MemoryPolicy.NO_CACHE).networkPolicy(NetworkPolicy.NO_CACHE).into(mIvlogo, new Callback() {
                            @Override
                            public void onSuccess() {
                                if ((!TextUtils.isEmpty(layout) && layout.equals("5"))) {
                                    getConfigData(domainName, imagePathFinal, jsonObject1);
                                } else {
                                    if(!mSession.getAppLanguage().equals("en"))
                                        setNewAppConfig("en",imagePathFinal,jsonObject1);
                                    else
                                       activitySelection(imagePathFinal, jsonObject1);
                                }
                            }


                            @Override
                            public void onError(Exception e) {
                                Picasso.get().invalidate(imagePathFinal);
                                if (getString(R.string.subdomain).equals("mint")) {
                                    if (!imagePathFinal.equals("")) {
                                        Picasso.get().invalidate(imagePathFinal);
                                        Picasso.get().load(imagePathFinal).error(R.drawable.app_logo_secondry_mint).into(mIvlogo);
                                    } else {
                                        mIvlogo.setImageResource(R.drawable.app_logo_secondry_mint);
                                    }
                                } else {
                                    mIvlogo.setImageResource(R.mipmap.app_logo_secondry);
                                }
                                if ((!TextUtils.isEmpty(layout) && layout.equals("5"))) {
                                    getConfigData(domainName, imagePathFinal, jsonObject1);
                                } else {
                                    if(!mSession.getAppLanguage().equals("en"))
                                        setNewAppConfig("en",imagePathFinal, jsonObject1);
                                    else
                                       activitySelection(imagePathFinal, jsonObject1);
                                }
                            }
                        });

                    } else {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.showCommonDailog(DomainActivity.this, getString(R.string.alert_dialog_error_txt), getString(R.string.alert_dialog_invalid_domain), "error");
                    }
                } catch (Exception e) {

                }
            }
        });

    }


    private void setCustomLinksData(String data) {
        List<String> keywords = List.of(getString(R.string.txt_policies_agreements), getString(R.string.txt_grievance_redressal), getString(R.string.txt_legal_regulatory));
        JSONArray jsonArray = null;
        ArrayList<JSONObject> jsonObjects = new ArrayList<>();
        try {
            if (data.length() != 0) {
                jsonArray = new JSONArray(data);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String title = jsonObject.optString("title");
                    if (keywords.contains(title)) {
                        // matching keywords
                        jsonObjects.add(jsonObject);
                    }
                }
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        } finally {
            mSession.setCustomLinksForContactUs("" + jsonObjects);
        }
    }


    private void getPublicInfoForCustomApp(final String domainName) {
        logD("getPublicInfo", "getPublicInfo: called on DomainActivity");
        String url = "https://" + domainName + mSession.getHostingPath() + Config.GET_BROKER_PUBLIC_INFO + "brokerDomain=" + domainName + "&userBusinessCode=" + AppConstants.SUB_BROKER_BUSINESS_CODE;
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.OPEN_API, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                String imagePath = "";
                JSONObject jsonObject1 = new JSONObject();

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    if (jsonObject.optInt("status") == 0) {
                        mSession.setTestDomainType("");
                        imagePath = Config.IMAGE_PATH + domainName + "_Logo.png";
                        mSession.setAppLogo(imagePath);

                        jsonObject1 = jsonObject.optJSONObject("result");
                        //jsonObject1.put("layout", "5");
                        mSession.setShowBseAuthPopup("1".equals(jsonObject1.optString("showBseAuthPopup").trim()));


                        mSession.setAppLogoName(jsonObject1.optString("logo"));
                        mSession.setFutureProjectionCalculator(jsonObject1.optInt("futureProjectionCalculator"));
                        mSession.setSIPCalculator(jsonObject1.optInt("SIPCalculator"));
                        mSession.setPlayStoreLink(jsonObject1.optString("androidAppLink"));
                        mSession.setAppStoreLink(jsonObject1.optString("iosAppLink"));
                        mSession.setCompanyName(jsonObject1.optString("compName"));
                        mSession.setOnBoarding(jsonObject1.optInt("allowOnboarding"));
                        mSession.setAllowedMobileOTPLogin(jsonObject1.optInt("allowMobileOtpLogin"));
                        mSession.setUserEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setWebsite(jsonObject1.optString("website").equalsIgnoreCase("null") ? "" : jsonObject1.optString("website"));
                        mSession.setMobileNumber(jsonObject1.optString("mobileNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("mobileNo1"));
                        mSession.setTelNumber(jsonObject1.optString("telNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("telNo1"));
                        mSession.setVoltPartnerCode(jsonObject1.optString("voltPartnerCode").equalsIgnoreCase("null") ? "" : jsonObject1.optString("voltPartnerCode"));
                        mSession.setIsRiskProfileMandatory(jsonObject1.optInt("isRiskProfileManadatory"));
                        mSession.setAllowedCrm(jsonObject1.optInt("allowCrm",0)==1);
                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        mSession.setHasShowXirr(jsonObject1.optString("showXIRR").equals("1"));
                        String domain = jsonObject1.optString("domain");
                        if (!domain.equalsIgnoreCase("null") && !domain.isEmpty()) {
                            mSession.setUserBrokerDomain(domain);
                        }
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
                            jsonObject1.put("layout", 6);
                        }
                        mSession.setAppInfo("" + jsonObject1);
                        mSession.setForceUpdate(jsonObject1.optInt("majorUpdate")==1);
                        String address = "";
                        address = UtilityKotlin.checkAndGetCompanyAddress(jsonObject1);
                        mSession.setAddress(address);
                        mSession.setCustomURL(jsonObject1.getString("customURL").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customURL"));
                        setCustomLinksData(jsonObject1.getString("customLinks").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customLinks"));
                        String slogan = jsonObject1.optString("slogan");
                        if (!slogan.equalsIgnoreCase("null") && !slogan.isEmpty()) {
                            mSession.setSloganOnLogo(slogan);
                        }



                        if (!TextUtils.isEmpty(whereToNavigate) && whereToNavigate.equalsIgnoreCase("Register")) {
                            UtilityKotlin.openNewKycOnboardingInWebView(DomainActivity.this, mSession, "0", "signUp","");
                            finish();
                        } else {
                            if (!mSession.getHasFirstTimeAppIntroLaunched() && (!TextUtils.isEmpty(jsonObject1.optString("layout")) &&
                                    jsonObject1.optString("layout").equalsIgnoreCase("2"))) {
                                Intent intent = new Intent(getApplicationContext(), SingleIntroActivity.class);
                                intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                                intent.putExtra("logoPath", imagePath);
                                startActivity(intent);
                                DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                                finish();
                            } else if (!mSession.getHasFirstTimeAppIntroLaunched() && (!TextUtils.isEmpty(jsonObject1.optString("layout")) && (jsonObject1.optString("layout").equalsIgnoreCase("3") || jsonObject1.optString("layout").equalsIgnoreCase("6")))) {
                                Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
                                intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                                intent.putExtra("logoPath", imagePath);
                                startActivity(intent);
                                DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                                finish();
                            } else {
                                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                                intent.putExtra("logoPath", imagePath);
                                startActivity(intent);
                                DomainActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
                                finish();
                            }

                        }
                    } else {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.showCommonDailog(DomainActivity.this, getString(R.string.alert_dialog_error_txt), getString(R.string.alert_dialog_invalid_domain), "error");
                    }
                } catch (Exception e) {

                }
            }
        });

    }


    private void getConfigData(String domain, String imagePath, JSONObject publicInfoObject) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Subdomain", domain);
            jsonObject.put("Language", UtilityKotlin.getLanguageCodeToValueMap().get(mSession.getAppLanguage()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        KtorHelper.requestCall(this, mSession, Config.APP_CONFIG, ApiRequestType.POST, jsonObject, AppHeaderType.NONE, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading){
                    ProgressBarCommon.showDialog(DomainActivity.this);
                }else{
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject1 = new JSONObject(response);
                    if (jsonObject1.optBoolean("Status")) {
                        mSession.setAppConfig(response);
//                        if (jsonObject1.optString("multiLang").equalsIgnoreCase("1")) {
//                            Intent intent = new Intent(DomainActivity.this, LanguageSelectorActivity.class);
//                            intent.putExtra("imagePath", imagePath);
//                            intent.putExtra("publicInfoObject", publicInfoObject.toString());
//                            startActivityForResult(intent, RC_LANGUAGE_SELECTION);
//                        }
//                        else {
//                            activitySelection(imagePath, publicInfoObject);
//                        }
                        if(!mSession.getAppLanguage().equals("en"))
                            setNewAppConfig("en",imagePath,publicInfoObject);
                        else
                            activitySelection(imagePath, publicInfoObject);
                    } else {
                        mSession.setAppConfig("");
                        if(!mSession.getAppLanguage().equals("en"))
                            setNewAppConfig("en",imagePath,publicInfoObject);
                        else
                            activitySelection(imagePath, publicInfoObject);
                    }
                }catch (Exception ignored){

                }
            }
        });

    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == RC_LANGUAGE_SELECTION) {
//            // Continue normal app flow
//            String imagePath = "";
//            JSONObject publicInfoObject = new JSONObject();
//            if(data != null) {
//                imagePath = data.getStringExtra("imagePath");
//
//                String publicInfoStr = data.getStringExtra("publicInfoObject");
//                if (publicInfoStr != null) {
//                    try {
//                        publicInfoObject = new JSONObject(publicInfoStr);
//                    } catch (Exception ignored) {}
//                }
//                activitySelection(imagePath,publicInfoObject);
//            }
//        }
//    }

}
