package investwell.client.fragments.others;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;
import static android.content.Context.KEYGUARD_SERVICE;
import static androidx.work.LoggerExtKt.logd;
import static investwell.common.lock.AppLockOptionActivity.CUSTOM_PIN_LOCK_CODE;
import static investwell.common.lock.AppLockOptionActivity.DEFAULT_LOCK_CODE;
import static investwell.utils.UtilityKotlin.applyAccessibilityList;
import static investwell.utils.Utils.applySelectedTheme;
import static investwell.utils.UtilityKotlin.loadImageWithAuthentication;

import android.app.Activity;
import android.app.KeyguardManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.ContactUsActivity;
import investwell.activity.TextSizeActivity;
import investwell.common.adapter.LanguageSupportAdapter;
import investwell.common.adapter.ThemeSupportAdapter;
import investwell.textview.AppTextView;
import investwell.utils.BaseFragment;
import investwell.utils.Extensions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.WebViewActivity;
import investwell.admin.activity.AdminActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.common.lock.PinLockActivity;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.RoundedImageView;
import investwell.utils.crop.CropImage;
import investwell.utils.customView.CustomDialog;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.databinding.ActivityLanguageSelectorBinding;


public class FragProfileSettings extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AdminActivity mAdminActivity;
    private AppApplication mApplication;
    private TextView mTvLockScreen, mTvUsername, mTvVersion, tvFontSelected;
    private int count = 0;
    public ImageView mProfileImage;
    private ToolbarFragment fragToolBar;
    private boolean isNotAdmin = false;
    private TextView tvCloseAccDesc, tvLogoutDesc;
    private RadioGroup rgThemeOptions;
    private RadioButton rbSystemDefault, rbLightTheme, rbDarkTheme;
    private Button btnSaveTheme;

    private RelativeLayout llanguage;
    private ProgressBar pbProfileImage;

    private AppTextView tvThemeSelected;
    private AppTextView tvLanguageSelected;


    @Override
    public void onResume() {
        super.onResume();

   /*     if (mBrokerActivity != null) {
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        } else if (mAdminActivity != null)
            FirebaseAnalytics.getInstance(mAdminActivity).setCurrentScreen(mAdminActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mBrokerActivity.setMainVisibility(this, null);
            mSession = AppSession.getInstance(mBrokerActivity);
            isNotAdmin = true;
        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mMainActivity.setMainVisibility(this, null);
            mSession = AppSession.getInstance(mMainActivity);
            isNotAdmin = true;
        } else if (context instanceof AdminActivity) {
            this.mAdminActivity = (AdminActivity) context;
            mSession = AppSession.getInstance(mAdminActivity);
            mApplication = (AppApplication) mAdminActivity.getApplication();
            isNotAdmin = false;
            mSession = AppSession.getInstance(mAdminActivity);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.settings), isNotAdmin, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_, container, false);

        setUpToolBar();
        mTvUsername = view.findViewById(R.id.card_user_name);
        TextView tvName = view.findViewById(R.id.et_name);
        mTvVersion = view.findViewById(R.id.tvVersion);
        llanguage =  view.findViewById(R.id.rllanguage);
        tvCloseAccDesc = view.findViewById(R.id.tv_close_acc_desc);
        tvLogoutDesc = view.findViewById(R.id.tv_logout_acc_desc);
        tvLogoutDesc.setText(R.string.logout_from_app);
        tvThemeSelected = view.findViewById(R.id.tvThemeSelected);
        tvLanguageSelected = view.findViewById(R.id.tvLanguageSelected);
        /*tvCloseAccDesc.setText("Clear your profile on this device");*/



        mProfileImage = view.findViewById(R.id.profile_icon);
        pbProfileImage = view.findViewById(R.id.pbProfileImage);
        mProfileImage.setOnClickListener(this);
        tvFontSelected = view.findViewById(R.id.tvFontSelected);


        if ((mSession.getLoginType().equalsIgnoreCase("broker"))) {
            mTvUsername.setText(mSession.getBrokerFullName());
        } else if (!mSession.getPersonName().isEmpty()) {
            mTvUsername.setText(mSession.getPersonName());
        } else {
            mTvUsername.setText(getResources().getString(R.string.incomplete_profile_dear_investor_txt));
        }

        boolean isBroker = mSession.getLoginType().equalsIgnoreCase("broker") && mSession.getClientObject().isEmpty();
        if (!isBroker && !mSession.getClientPhotoName().isEmpty() && !mSession.getClientPhotoName().equals("null")) {
            loadImageWithAuthentication(requireContext(), mSession, mProfileImage, pbProfileImage, false);
        } else {
            mProfileImage.setVisibility(View.GONE);
            String name = mTvUsername.getText().toString();
            if (!name.equals("")) {
                String usertext = "";
                String[] n = name.split(" ", 2);
                for (int i = 0; i < n.length; i++) {
                    usertext = usertext + n[i].charAt(0);
                }
                tvName.setVisibility(View.VISIBLE);
                tvName.setText(usertext);
            }
        }
        if (mSession.getHasLoging() && mSession.getOnBoarding() == 1
                && mSession.getLoginType().equals("client")) {
            view.findViewById(R.id.refer_to_friends).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.refer_to_friends).setVisibility(View.GONE);
        }

        boolean shouldReferToFriendShow = mSession.getHasLoging() && mSession.getAllowedCrm() && mSession.getLoginType().equals("client");
        if (shouldReferToFriendShow) {
            view.findViewById(R.id.rlReferFriend).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.rlReferFriend).setVisibility(View.GONE);
        }


        view.findViewById(R.id.screen_lock_layout).setOnClickListener(this);
        view.findViewById(R.id.refer_to_friends).setOnClickListener(this);
        llanguage.setOnClickListener(this);
        view.findViewById(R.id.help_layout).setOnClickListener(this);
        view.findViewById(R.id.change_password_layout).setOnClickListener(this);
        view.findViewById(R.id.share_layout).setOnClickListener(this);
        view.findViewById(R.id.rate_layout).setOnClickListener(this);
        view.findViewById(R.id.rlReferFriend).setOnClickListener(this);
        view.findViewById(R.id.about_layout).setOnClickListener(this);
        view.findViewById(R.id.privacy_layout).setOnClickListener(this);
        view.findViewById(R.id.logout_layout).setOnClickListener(this);
        view.findViewById(R.id.rl_close_acc_layout).setOnClickListener(this);
        view.findViewById(R.id.rlDeleteAccount).setOnClickListener(this);
        view.findViewById(R.id.relChangeFontSize).setOnClickListener(this);
        view.findViewById(R.id.relChangeTheme).setOnClickListener(this);

        if(getString(R.string.dark_theme_enabled).equals("false"))
            view.findViewById(R.id.relChangeTheme).setVisibility(View.GONE);
        else
            view.findViewById(R.id.relChangeTheme).setVisibility(View.VISIBLE);




        mTvLockScreen = view.findViewById(R.id.tvLockType);

        setting_updateView();
        versionName();

        float savedSize = mSession.getFontScale();
        if (savedSize >1) {
            int percentageAmount = Math.round((savedSize - 1.0f) * 100);
            tvFontSelected.setText(String.format("%02d%% increased", percentageAmount));

        }
        setLanguageOptionVisibility();


        tvThemeSelected.setText(UtilityKotlin.getThemeNameByCode(mSession.getTheme()));
        tvLanguageSelected.setText(UtilityKotlin.getLanguageCodeToValueMap().get(mSession.getAppLanguage()));

        applyAccessibilityList(view.findViewById(R.id.llAllItems));
        setWidgetsVisibility(view);
        return view;
    }

    private void setWidgetsVisibility(View view) {
        if (BuildConfig.IS_ENV_SDK){
            view.findViewById(R.id.logout_layout).setVisibility(View.GONE);
            view.findViewById(R.id.rlDeleteAccount).setVisibility(View.GONE);
            view.findViewById(R.id.rllanguage).setVisibility(View.GONE);
            view.findViewById(R.id.relChangeFontSize).setVisibility(View.GONE);
            view.findViewById(R.id.refer_to_friends).setVisibility(View.GONE);
        }
    }



    @Override
    public void onClick(View view) {
        String pckg = "";

        if (view.getId() == R.id.share_layout) {
                if (!mSession.getCallFromPackage().isEmpty()){
                    pckg =mSession.getCallFromPackage();
                }else if (mMainActivity != null) {
                    pckg = mMainActivity.getApplicationContext().getPackageName();
                } else if (mAdminActivity != null) {
                    pckg = mAdminActivity.getApplicationContext().getPackageName();
                } else {
                    pckg = mBrokerActivity.getApplicationContext().getPackageName();
                }
                Intent intnt = new Intent(Intent.ACTION_SEND);
                intnt.setType("text/plain");
                String primaryShareMsg = "";
                //String text = primaryShareMsg + mSession.getPlayStoreLink();
                String text = primaryShareMsg + " https://play.google.com/store/apps/details?id="
                        + pckg +
                        "&hl=en";

                if (intnt != null) {
                    intnt.putExtra(Intent.EXTRA_TEXT, text);
                    startActivity(intnt);
                }
}
else if (view.getId() == R.id.rate_layout) {
                if (mMainActivity != null) {
                    pckg = mMainActivity.getApplicationContext().getPackageName();
                } else if (mAdminActivity != null) {
                    pckg = mAdminActivity.getApplicationContext().getPackageName();
                } else {
                    pckg = mBrokerActivity.getApplicationContext().getPackageName();
                }
                String playstoreLink = "https://play.google.com/store/apps/details?id=" + pckg;
                // Uri uriUrl = Uri.parse(mSession.getPlayStoreLink());
                Intent intentt = new Intent(Intent.ACTION_VIEW, Uri.parse(playstoreLink));
                startActivity(intentt);
}
else if (view.getId() == R.id.screen_lock_layout) {
                if (mSession.getHasAppLockEnable()) {
                    if (mSession.getAppLockType().equalsIgnoreCase("default")) {
                        KeyguardManager km = (KeyguardManager) getActivity().getSystemService(KEYGUARD_SERVICE);
                        if (km.isKeyguardSecure()) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                Intent i = km.createConfirmDeviceCredentialIntent(getString(R.string.txt_use_your_screen_lock_pattern_to_login), "");
                                startActivityForResult(i, DEFAULT_LOCK_CODE);
                            }
                        } else {
                            mSession.setHasAppLockEnable(false);
                            mApplication.showCommonDailog(getActivity(), getString(R.string.Error), getString(R.string.text_no_screen_lock), "message");
                        }
                    } else if (mSession.getAppLockType().equalsIgnoreCase("pin")) {
                        Intent intent = new Intent(getActivity(), PinLockActivity.class);
                        intent.putExtra("type", "verifyFromSetting");
                        startActivityForResult(intent, CUSTOM_PIN_LOCK_CODE);
                    }

                } else {
                    if (mBrokerActivity != null) {
                        mBrokerActivity.displayViewOther(64, null);
                    } else if (mAdminActivity != null) {
                        mAdminActivity.displayViewOther(2, null);
                    } else {
                        mMainActivity.displayViewOther(64, null);
                    }
                }
}
else if (view.getId() == R.id.help_layout) {
                //  mActivity.displayViewOther(57, null);
}
else if (view.getId() == R.id.about_layout) {
                Intent intent = new Intent(getActivity(), WebViewActivity.class);
                intent.putExtra("title", getString(R.string.about_us_name));
                intent.putExtra("url", ""/*getString(R.string.app_link_about_us)*/);
                startActivity(intent);
}
else if (view.getId() == R.id.privacy_layout) {
                Intent intent_privcy = new Intent(getActivity(), WebViewActivity.class);
                intent_privcy.putExtra("title", getString(R.string.settings_privacy_policy_txt));
                intent_privcy.putExtra("url", ""/*getString(R.string.app_link_privacy_policy)*/);
                startActivity(intent_privcy);
}
else if (view.getId() == R.id.change_password_layout) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mMainActivity != null) {
                            Bundle bundle = new Bundle();
                            bundle.putString("type", "changePassword");
                            mMainActivity.displayViewOther(38, bundle);
                        } else {
                            Bundle bundle = new Bundle();
                            bundle.putString("type", "changePassword");
                            mBrokerActivity.displayViewOther(38, bundle);
                        }
                    }
                }, 200);
}
else if (view.getId() == R.id.logout_layout) {
                showLogOutAlert();
}
else if (view.getId() == R.id.rlDeleteAccount) {
                showAccountDeleteAlert();
}
else if (view.getId() == R.id.refer_to_friends) {
                generateShortUrl();
}
else if (view.getId() == R.id.rllanguage) {
                changeLanguage();
}
/*else if (view.getId() == R.id.faq_layout) {
                if (mBrokerActivity != null) {
                    Intent intent1 = new Intent(getActivity(), WebViewActivity.class);
                    intent1.putExtra("title", "FAQ");
                    intent1.putExtra("url", getString(R.string.faq_link));
                    startActivity(intent1);
                }
}*/
else if (view.getId() == R.id.rl_close_acc_layout) {
                showCloseAccountAlert();
}
else if (view.getId() == R.id.relChangeFontSize) {
                Intent intent1 = new Intent(getActivity(), TextSizeActivity.class);
                startActivity(intent1);
}
else if (view.getId() == R.id.relChangeTheme) {
                changeTheme();
}
else if (view.getId() == R.id.profile_icon) {
            /*    if (mSession.getLoginType().equalsIgnoreCase("Broker") || mSession.getLoginType().equalsIgnoreCase("SubBroker") || mSession.getLoginType().equalsIgnoreCase("RM")) {
                } else {
                    CropImage.activity(null).setGuidelines(CropImageView.Guidelines.ON).start(getActivity(), 300);
                }*/
}
    }
    private void changeTheme() {
        ThemeSupportAdapter themeSupportAdapter;
        List<String> themeList;

        BottomSheetDialog bottomSheetDialog;
        Activity mActivity;

        if (mBrokerActivity != null) {
            mActivity = mBrokerActivity;
        } else {
            mActivity = mMainActivity;
        }
        bottomSheetDialog = new BottomSheetDialog(mActivity);
        ActivityLanguageSelectorBinding mBinding = ActivityLanguageSelectorBinding.inflate(getLayoutInflater());
        bottomSheetDialog.setContentView(mBinding.getRoot());
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.show();


        themeSupportAdapter = new ThemeSupportAdapter(mActivity, mSession, theme -> {

            applySelectedTheme(theme,mSession);
            tvThemeSelected.setText(UtilityKotlin.getThemeNameByCode(mSession.getTheme()));
            bottomSheetDialog.hide();

        });
        LinearLayoutManager mLayoutmanager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false);

        mBinding.rvLanguageSupport.setLayoutManager(mLayoutmanager);
        mBinding.rvLanguageSupport.setItemAnimator(new DefaultItemAnimator());
        mBinding.rvLanguageSupport.setNestedScrollingEnabled(false);
        mBinding.rvLanguageSupport.setAdapter(themeSupportAdapter);
        mBinding.txtChoose.setText(R.string.txt_choose_theme);


        themeList = Utils.getThemeList();
        themeSupportAdapter.update(themeList);

    }

    private void setLanguageOptionVisibility(){
        JSONObject appConfigObject;
        try {
            appConfigObject = new JSONObject(mSession.getAppInfo());
            boolean isMultiLangEnabled = "1".equals(appConfigObject.optString("multiLang"));
            // If isMultiLangEnabled is 0 → language is not visible
            if (isMultiLangEnabled)
                llanguage.setVisibility(View.VISIBLE);
            else
                llanguage.setVisibility(View.GONE);


        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
    private void changeLanguage() {
        LanguageSupportAdapter languageSupportAdapter;
        List<String> langlist;

        BottomSheetDialog bottomSheetDialog;
        Activity mActivity;

        if (mBrokerActivity != null) {
            mActivity = mBrokerActivity;
        } else {
            mActivity = mMainActivity;
        }
        bottomSheetDialog = new BottomSheetDialog(mActivity);
        ActivityLanguageSelectorBinding mBinding = ActivityLanguageSelectorBinding.inflate(getLayoutInflater());
        bottomSheetDialog.setContentView(mBinding.getRoot());
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.show();


        languageSupportAdapter = new LanguageSupportAdapter(mActivity, mSession, langCode -> {
            if(!mSession.getAppLanguage().equals(langCode)) {
                setNewAppConfig(langCode);
            }
            else
                bottomSheetDialog.dismiss();
        });
        LinearLayoutManager mLayoutmanager = new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mActivity, LinearLayoutManager.VERTICAL);

        mBinding.rvLanguageSupport.setLayoutManager(mLayoutmanager);
        mBinding.rvLanguageSupport.addItemDecoration(dividerItemDecoration);
        mBinding.rvLanguageSupport.setItemAnimator(new DefaultItemAnimator());
        mBinding.rvLanguageSupport.setNestedScrollingEnabled(false);
        mBinding.rvLanguageSupport.setAdapter(languageSupportAdapter);
        mBinding.txtChoose.setText(R.string.txt_choose_language);

        langlist = new ArrayList<>(UtilityKotlin.getLanguageCodeToValueMap().values());

        languageSupportAdapter.update(langlist);

    }

    private void setNewAppConfig(String languageCode) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Subdomain", mSession.getUserBrokerDomain());
            jsonObject.put("Language", UtilityKotlin.getLanguageCodeToValueMap().get(languageCode));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        ProgressBarCommon.showDialog(requireContext());
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, Config.APP_CONFIG, jsonObject, response -> {

            if (response.optBoolean("Status")) {
                mSession.setAppConfig(response.toString());
                mSession.setAppLanguage(languageCode);
                Extensions.updateLocale(getMCurrentActivity(), languageCode);
                tvLanguageSelected.setText(UtilityKotlin.getThemeNameByCode(mSession.getAppLanguage()));
                Intent intent;
                if (mBrokerActivity != null) {
                    intent = new Intent(requireContext(), BrokerActivity.class);
                } else {
                    intent = new Intent(requireContext(), ClientActivity.class);
                }
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                requireActivity().finish();

            }
            ProgressBarCommon.dismissDialog();
        },volleyError -> {
            ProgressBarCommon.dismissDialog();
            mSession.setAppConfig("");
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "splash");

        });
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                Log.d("getConfigData", "getConfigData: getCurrentRetryCount called =");
                return 4;
            }

            @Override
            public void retry(VolleyError error) {
                System.out.println();
                Log.d("getConfigData", "getConfigData: retry called");
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getMCurrentActivity());
        requestQueue.add(jsonObjectRequest);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK && requestCode == DEFAULT_LOCK_CODE)) {
            mSession.setHasAppLockEnable(true);

            if (mBrokerActivity != null) {
                mBrokerActivity.displayViewOther(64, null);
            } else if (mAdminActivity != null)
                mAdminActivity.displayViewOther(2, null);
            else {
                mMainActivity.displayViewOther(64, null);
            }
        } else if ((resultCode == RESULT_CANCELED && requestCode == DEFAULT_LOCK_CODE)) {

        } else if ((resultCode == RESULT_CANCELED && requestCode == CUSTOM_PIN_LOCK_CODE)) {

        } else if (requestCode == CUSTOM_PIN_LOCK_CODE) {
            if (mBrokerActivity != null) {
                mBrokerActivity.displayViewOther(64, null);
            } else if (mAdminActivity != null)
                mAdminActivity.displayViewOther(2, null);
            else {
                mMainActivity.displayViewOther(64, null);
            }
        } else if (requestCode == 300) {
            CropImage.ActivityResult imageResult = CropImage.getActivityResult(data);
            try {
                Uri selectedImage = imageResult.getUri();
                if (selectedImage != null) {
                    Bitmap gallery_bit = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), selectedImage);
                    mProfileImage.setImageBitmap(RoundedImageView.getCroppedBitmap(gallery_bit, 150));
                    convertToDataUri(gallery_bit);
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }


        }
    }

    private void versionName() {
        try {
            PackageInfo pInfo = getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0);
            final String version = pInfo.versionName;
            mTvVersion.setText("" + version);
            AccessibilityManager accessibilityManager = (AccessibilityManager) requireContext().getSystemService(Context.ACCESSIBILITY_SERVICE);

            if (accessibilityManager != null) {
                AccessibilityManager.AccessibilityStateChangeListener accessibilityListener = enabled -> {
                    if (!enabled) {
                        mTvVersion.setOnClickListener(v -> {
                            count = count + 1;
                            if (count > 3) {
                                //  mTvVersion.setText("Version: " + version + " & Build: V3");
                                count = 0;
                            }
                        });
                    }
                };
                accessibilityManager.addAccessibilityStateChangeListener(accessibilityListener);
            }
        } catch (PackageManager.NameNotFoundException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

    }

    private void showAccountDeleteAlert() {
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    deleteMyAccount();
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(
                requireContext(),
                getResources().getString(R.string.Confirm),
                getResources().getString(R.string.Are_you_sure_delete_account),
                getString(R.string.delete_my_account),
                getString(R.string.no),
                true,
                true
        );
    }

    private void showLogOutAlert() {
//        AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
//        alert.setTitle(getResources().getString(R.string.Confirm));
//        alert.setMessage(getResources().getString(R.string.Are_you_sure_logout));
//        alert.setPositiveButton(getString(R.string.yes),
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        LogoutMethod();
//                    }
//                });
//
//        alert.setNegativeButton(getString(R.string.no), null);
//        alert.show();
//
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    LogoutMethod();
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(
                requireContext(),
                getResources().getString(R.string.Confirm),
                getResources().getString(R.string.Are_you_sure_logout),
                getString(R.string.yes),
                getString(R.string.no),
                true,
                true
        );
    }

    private void showCloseAccountAlert() {
//        AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
//        alert.setTitle(getResources().getString(R.string.Confirm));
//        alert.setMessage(getResources().getString(R.string.Are_you_sure_clear_account));
//        alert.setPositiveButton(getString(R.string.yes),
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        if (getActivity() != null) {
//                            String deviceID = mSession.getDeviceUniqueID();
//                            mSession.clear();
//                            mSession.setDeviceUniqueID(deviceID);
//                            getActivity().finish();
//                        }
//                    }
//                });
//
//        alert.setNegativeButton(getString(R.string.no), null);
//        alert.show();


        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    if (getActivity() != null) {
                        String deviceID = mSession.getDeviceUniqueID();
                        mSession.clear();
                        mSession.setDeviceUniqueID(deviceID);
                        getActivity().finish();
                    }
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(
                requireContext(),
                getResources().getString(R.string.Confirm),
                getResources().getString(R.string.Are_you_sure_clear_account),
                getString(R.string.yes),
                getString(R.string.no),
                true,
                true
        );
    }


    private void deleteMyAccount() {
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";


        JSONObject objectMain = new JSONObject();

        try {
            if (mSession.getLoginType().equals("client")) {
                if (Utils.getSelectedLevelNo(mSession).equals("1")) {
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLEINT_DELETE_MY_ACCOUNT;
                objectMain.put("&selectedUser=", Utils.getSelectedUserObject(mSession));
            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.BROKER_DELETE_MY_ACCOUNT;
            }
            objectMain.put("uid", mSession.getUid());

        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                UtilityKotlin.setRefreshKey(mSession);
                if (mBar != null)
                    mBar.dismiss();
                try {
                    if (jsonObject.optInt("status") == 0) {
                        if (getActivity() != null) {
                            String deviceID = mSession.getDeviceUniqueID();
                            mSession.clear();
                            mSession.setDeviceUniqueID(deviceID);
                            getActivity().finish();
                        }
                    } else {
                        String message = jsonObject.optString("message");
                        mApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");

                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }


    private void LogoutMethod() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.LOGOUT;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mBar.hide();
                        mApplication.goToLogin("logout");
                        //mApplication.clearAllSession();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null) mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderLoginLogout(mSession);
            }


        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void setting_updateView() {
        if (mSession.getAppLockType().equalsIgnoreCase("default")) {
            mTvLockScreen.setText(getResources().getString(R.string.profile_phone_active));
            mTvLockScreen.setTextColor(ContextCompat.getColor(getActivity(), R.color.blue));
        } else if (mSession.getAppLockType().equalsIgnoreCase("pin")) {
            mTvLockScreen.setText(getResources().getString(R.string.profile_pin_active));
            mTvLockScreen.setTextColor(ContextCompat.getColor(getActivity(), R.color.blue));
        } else if (mSession.getAppLockType().equalsIgnoreCase("nothing")) {
            mTvLockScreen.setText(getResources().getString(R.string.profile_none));
            mTvLockScreen.setTextColor(ContextCompat.getColor(getActivity(), R.color.blue));
        }
    }


    public void convertToDataUri(Bitmap signatureBitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        signatureBitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        byte[] byteArray = baos.toByteArray();
        String b64String = Base64.encodeToString(byteArray, Base64.NO_WRAP);
        String dataUri = "data:image/png;base64," + b64String;
        //saveInformation(dataUri);

    }


    private void generateShortUrl() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        ProgressBarCommon.showDialog(getActivity());
        String referUrl = "";
        if (mSession.getCustomURL() != null && !mSession.getCustomURL().isEmpty()) {
            referUrl = "https://" + mSession.getCustomURL() + "/" + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        } else {
            referUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath().replace("/webapi", "") + Config.DEEP_LINKING + "referredByUid=" + Utils.getSelectedUid(mSession) + "%26referredByLevelNo=" + Utils.getSelectedLevelNo(mSession);
        }
//        String referUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath().replace("/api", "") + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "%26referredByLevelNo=" + mSession.getLevelNo();
        String url = Config.DEEP_LINKING_SHORT_URL + referUrl + "&signature=11d3c107e3" + "&format=json&action=shorturl";
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    ProgressBarCommon.dismissDialog();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
//                        insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),
//                                Config.DEEP_LINKING_SHORT_URL);

                        if (jsonObject.optInt("statusCode") == 200) {
                            String shorturl = jsonObject.optString("shorturl");
                            refer(shorturl);
                        }
                    } catch (Exception e) {
                        if (BuildConfig.DEBUG) e.printStackTrace();
                    }
                },
                volleyError -> {
                    if (!isAdded())
                        return;
                    ProgressBarCommon.dismissDialog();
                    UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void refer(String shorturl) {
        String message = getString(R.string.to_invest_quickly_please_onboard_now);
        String finalMessage =""+message+"\n"+shorturl;
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name));
        sharingIntent.putExtra(Intent.EXTRA_TEXT, finalMessage);
        startActivity(Intent.createChooser(sharingIntent, getString(R.string.txt_share_using)));
    }


}

