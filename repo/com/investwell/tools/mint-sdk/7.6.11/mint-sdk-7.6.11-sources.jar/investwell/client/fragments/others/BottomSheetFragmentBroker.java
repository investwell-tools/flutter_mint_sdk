package investwell.client.fragments.others;

import static investwell.di.core.LogExtKt.logD;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import investwell.broker.mfuOnboarding.BrokerMfuPendingOnboardListActivity;
import investwell.broker.mfuOnboarding.MfuOnboardingActivity;
import investwell.mintSdk.MintAppConfiguration;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.iw.mint.sdk.R;

import java.util.ArrayList;
import java.util.List;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.broker.bseOnboarding.BrokerBse_ProfileBrokerActivity;
import investwell.broker.nseOnborading.BrokerNsePendingOnboardListActivity;
import investwell.client.adapter.DashboardMenuAdapter;
import investwell.common.alltransactions.CommonExchangeActivity;
import investwell.utils.AppSession;
import investwell.utils.GridSpacingItemDecoration;
import investwell.utils.model.FinancialTools;


public class BottomSheetFragmentBroker extends BottomSheetDialogFragment implements View.OnClickListener, DashboardMenuAdapter.DashboardMenuListener {
    private DashboardMenuAdapter dashboardMenuAdapter;
    private List<FinancialTools> financialToolsList;
    private RecyclerView rvFinancialTools;
    private View view;
    private ImageView mIvProfileImage;
    private TextView tvName;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private AppApplication mApplication;

    public BottomSheetFragmentBroker() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mBrokerActivity = (BrokerActivity) context;
        mSession = AppSession.getInstance(mBrokerActivity);
        mApplication = (AppApplication) mBrokerActivity.getApplication();
        mSession = AppSession.getInstance(mBrokerActivity);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_bottom_sheet_dialog, container, false);
        setInitializer();
        setDashboardMenuAdapter();
        return view;
    }

    private void setInitializer() {

        mBrokerActivity.setMainVisibility(this, null);

        financialToolsList = new ArrayList<>();
        rvFinancialTools = view.findViewById(R.id.rv_menus);
        tvName = view.findViewById(R.id.tv_user_name);
        mIvProfileImage = view.findViewById(R.id.iv_profile_image);

        tvName.setText(!TextUtils.isEmpty(mSession.getName()) ? mSession.getName() : "");
        view.findViewById(R.id.iv_shut_down).setOnClickListener(this);
        view.findViewById(R.id.iv_setting).setOnClickListener(this);

        mIvProfileImage.setImageResource(R.mipmap.profileplaceholder);
        if (MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()){
            view.findViewById(R.id.iv_shut_down).setVisibility(View.VISIBLE);
        }else {
            view.findViewById(R.id.iv_shut_down).setVisibility(View.GONE);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.iv_shut_down) {
                mBrokerActivity.showLogOutAlert();
}
else if (v.getId() == R.id.iv_setting) {
                mBrokerActivity.displayViewOther(62, null);
}
    }


    /*******************************************
     * Method used to set dynamic financial items
     *******************************************/

    private void setDashboardMenuAdapter() {
        dashboardMenuAdapter = new DashboardMenuAdapter(mBrokerActivity, financialToolsList, this);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mBrokerActivity, 3);

        rvFinancialTools.setLayoutManager(gridLayoutManager);
        rvFinancialTools.addItemDecoration(new GridSpacingItemDecoration(3, dpToPx(0), true));
//        rvFinancialTools.setItemAnimator(new DefaultItemAnimator());
        rvFinancialTools.setNestedScrollingEnabled(false);
        rvFinancialTools.setAdapter(dashboardMenuAdapter);
        prepareDashboardMenu();
    }

    /****************************************
     * Converting dp to pixel
     ****************************************/
    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    /*******************************************
     * Method contains data for investment route items
     *******************************************/
    private void prepareDashboardMenu() {
        //   if (mSession.getExchangeNseBseMfu().equals(""))

        String exchange = "";
        if (mSession.getHasMultiExchange()) {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            }else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            }else if (mSession.getHasNse2Opted()) {
                exchange = "4";
            }
        } else {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            } else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            } else if (mSession.getHasNse2Opted()) {
                exchange = "4";
            }
        }

        FinancialTools a;

        //folio
        boolean isViewEnableFolio = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature3", Permissions.VIEW);
        if(isViewEnableFolio) {
            a = new FinancialTools(R.mipmap.folio_lookup, getString(R.string.folio_lookup), "0");
            financialToolsList.add(a);
        }

        //transaction
        boolean isViewEnableTransaction = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature57", Permissions.VIEW);
        if(isViewEnableTransaction) {
            a = new FinancialTools(R.mipmap.transfer_holdings, getString(R.string.transactions), "1");
            financialToolsList.add(a);
        }

        //insurance
        boolean isViewEnableInsurance = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature7", Permissions.VIEW);
        if(isViewEnableInsurance) {
            a = new FinancialTools(R.mipmap.insurance, getString(R.string.insurance), "2");
            financialToolsList.add(a);
        }

        //sip summary
        boolean isViewEnableSipSummary = UtilityKotlin.checkFeaturePermissionsOnOff(mSession,"feature27", Permissions.VIEW);
        if(isViewEnableSipSummary) {
            a = new FinancialTools(R.mipmap.sip_mining, getString(R.string.txt_sip_mining), "3");
            financialToolsList.add(a);
        }

        boolean isViewEnableNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature46", Permissions.VIEW);
        boolean isViewEnableBSe = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature37", Permissions.VIEW);
        boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature42", Permissions.VIEW);
        boolean isViewEnableNseInvest = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature133", Permissions.VIEW);
        if (isViewEnableNse || isViewEnableBSe || isViewEnableMfu || isViewEnableNseInvest) {
            a = new FinancialTools(R.mipmap.myorder, getString(R.string.txt_Myorder), "4");
            financialToolsList.add(a);
        }

        // 120
      /*  if (!mSession.getAllowedCrm() ){
            a = new FinancialTools(R.mipmap.meeting_notes_icon, getString(R.string.meeting_notes), "5");
            financialToolsList.add(a);
        }*/
        boolean isViewEnableMeetingNotes = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature120", Permissions.VIEW);
        if (isViewEnableMeetingNotes){
            a = new FinancialTools(R.mipmap.meeting_notes_icon, getString(R.string.meeting_notes), "5");
            financialToolsList.add(a);
        }


        if (!getString(R.string.subdomain).equalsIgnoreCase("mint") && mSession.getLevelNo().equals("1")) {
            a = new FinancialTools(R.mipmap.ic_notitifcation_menu, getString(R.string.create_notification), "6");
            financialToolsList.add(a);
        }
        // for casImport permission
        boolean isViewEnableCasImport = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature56", Permissions.VIEW);
        if (exchange.equals("1") || exchange.equals("2") || exchange.equals("3") || exchange.equals("4") ) {
            boolean isViewEnableCreateProfNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature44", Permissions.VIEW);
            boolean isViewEnableCreateProfBse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature35", Permissions.VIEW);
            boolean isViewEnableCreateProfNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature89", Permissions.VIEW);
            boolean isViewEnableCreateProfMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature40", Permissions.VIEW);


            if (isViewEnableCreateProfNse || isViewEnableCreateProfBse || isViewEnableCreateProfMfu || isViewEnableCreateProfNSE2) {
                a = new FinancialTools(R.mipmap.investment_profile, getString(R.string.txt_create_profile), "7");
                financialToolsList.add(a);
            }
            // for nse bse
            if (isViewEnableCasImport){
                a = new FinancialTools(R.drawable.cas_new_icon, getString(R.string.txt_cas_import), "8");
                financialToolsList.add(a);
            }

        }else {
            // for mfu
            if (isViewEnableCasImport){
                a = new FinancialTools(R.drawable.cas_new_icon, getString(R.string.txt_cas_import), "8");
                financialToolsList.add(a);
            }
        }
        // check is exchange opted enable kyc module
        boolean isEnabledKycModule= mSession.getHasBseOpted() || mSession.getHasMfuOpted() || mSession.getHasNseOpted() || mSession.getHasNse2Opted();
        if (isEnabledKycModule){
            a = new FinancialTools(R.drawable.pan, getString(R.string.txt_video_kyc_status), "9");
            financialToolsList.add(a);
        }

        dashboardMenuAdapter.notifyDataSetChanged();
    }


    private void refer(String url) {
        //   String referUrl = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath().replace("/api", "") + Config.DEEP_LINKING + "referredByUid=" + mSession.getUid() + "&referredByLevelNo=" + mSession.getLevelNo();
        String message = getString(R.string.to_invest_quickly_please_onboard_now);
        String finalMessage = message + "\n\n" + url;

        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, getActivity().getString(R.string.app_name));
        sharingIntent.putExtra(Intent.EXTRA_TEXT, finalMessage);
        getActivity().startActivity(Intent.createChooser(sharingIntent, getActivity().getString(R.string.txt_share_using)));
    }


    @Override
    public void onToolsClick(String menuId) {

    }

    @Override
    public void onToolsPosClick(int pos) {
        int clickPosId = Integer.parseInt(dashboardMenuAdapter.financialToolList.get(pos).getMenuId());

        Bundle bundle = new Bundle();
        bundle.putString("call_from", "broker_menu");
        mSession.setClientObject("");
        logD("client_object_clear", "data clear: BottomSheetFragmentBroker");

        String exchange = "";
        if (mSession.getHasMultiExchange()) {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            }else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            }else if (mSession.getHasNse2Opted()) {
                exchange = "4";
            }
        } else {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            } else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            }else if (mSession.getHasNse2Opted()) {
                exchange = "4";
            }
        }

        if (clickPosId == 0) {
            mBrokerActivity.displayViewOther(14, bundle);
        } else if (clickPosId == 1) {
            mBrokerActivity.displayViewOther(6, bundle);
        } else if (clickPosId == 2) {
            mBrokerActivity.displayViewOther(21, bundle);
        } else if (clickPosId == 3) {
            mBrokerActivity.displayViewOther(29, bundle);
        } else if (clickPosId == 4) {
            boolean isViewEnableNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature46", Permissions.VIEW);
            boolean isViewEnableBSe = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature37", Permissions.VIEW);
            boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature42", Permissions.VIEW);
            boolean isViewEnableNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature133", Permissions.VIEW);
            int trueCount = (isViewEnableNse ? 1 : 0) + (isViewEnableBSe ? 1 : 0) + (isViewEnableMfu ? 1 : 0) + (isViewEnableNSE2 ? 1 : 0);

            if (mSession.getHasMultiExchange()) {
                if (trueCount == 1) {
                    if (isViewEnableNse) {
                        AppApplication.sExchangeType = "1";
                    } else if (isViewEnableBSe) {
                        AppApplication.sExchangeType = "2";
                    } else if (isViewEnableMfu) {
                        AppApplication.sExchangeType="3";
                    } else {
                        AppApplication.sExchangeType = "4";
                    }
                    mBrokerActivity.displayViewOther(33, bundle);
                } else {
                    bundle.putString("comefrom", "myorderBroker");
                    mBrokerActivity.displayViewOther(66, bundle);
                }
            } else {
                mBrokerActivity.displayViewOther(33, bundle);
            }
        } else if (clickPosId == 5) {
            mBrokerActivity.displayViewOther(70, bundle);
        } else if (clickPosId == 6) {
            if (!getString(R.string.subdomain).equalsIgnoreCase("mint") && mSession.getLevelNo().equals("1")) {
                mBrokerActivity.displayViewOther(73, bundle);
            }
        } else if (clickPosId == 7) {
            boolean isViewEnableNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature44", Permissions.VIEW);
            boolean isViewEnableCreateProfNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature89", Permissions.VIEW);
            boolean isViewEnableBse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature35", Permissions.VIEW);
            boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature40", Permissions.VIEW);
            int trueCount = (isViewEnableNse ? 1 : 0) + (isViewEnableBse ? 1 : 0) + (isViewEnableMfu ? 1 : 0) + (isViewEnableCreateProfNSE2 ? 1 : 0);

            // Handle multi-exchange scenario

            if (mSession.getHasMultiExchange()) {
                Intent intent;
                if (trueCount == 1) {
                    if (isViewEnableNse || isViewEnableCreateProfNSE2) {
                        intent = new Intent(getActivity(), BrokerNsePendingOnboardListActivity.class);
                        intent.putExtra("exchange",exchange);
                    } else if(isViewEnableBse) {
                        intent = new Intent(getActivity(), BrokerBse_ProfileBrokerActivity.class);
                    }
                    else
                        intent = new Intent(getActivity(), BrokerMfuPendingOnboardListActivity.class);
                } else {
                    intent = new Intent(getActivity(), CommonExchangeActivity.class);
                    bundle.putString("type", "broker_onboard");
                }
                intent.putExtras(bundle);
                startActivity(intent);
            } else {
                Intent intent;
                if (exchange.equals("1") || exchange.equals("4")){
                    intent = new Intent(getActivity(), BrokerNsePendingOnboardListActivity.class);
                    intent.putExtra("exchange",exchange);
                } else if (exchange.equals("2"))
                    intent = new Intent(getActivity(), BrokerBse_ProfileBrokerActivity.class);
                else
                    intent = new Intent(getActivity(), BrokerMfuPendingOnboardListActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }

        } else if (clickPosId == 8) {
            mBrokerActivity.displayViewOther(76, bundle);
        } else if (clickPosId==9) {
            bundle.putString("exchange",mSession.getExchangeNseBseMfu());
            mBrokerActivity.displayViewOther(82,bundle);
        }

    }

    private void onboardingMethod(String exchange, Bundle bundle){
        if (exchange.equals("1") || exchange.equals("2")) {
            if (mSession.getHasMultiExchange()) {
                Intent intent = new Intent(getActivity(), CommonExchangeActivity.class);
                bundle.putString("type", "broker_onboard");
                intent.putExtras(bundle);
                startActivity(intent);
            } else {
                if (exchange.equals("1")) {
                    Intent intent = new Intent(getActivity(), BrokerNsePendingOnboardListActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                } else {
                    Intent intent = new Intent(getActivity(), BrokerBse_ProfileBrokerActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        }
    }
}
