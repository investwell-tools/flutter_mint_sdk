package investwell.client.fragments.portfolioSummary;

import static investwell.utils.Extensions.prepareAllowedList;
import static investwell.utils.ExtensionsKt.checkExchangeId;
import static investwell.utils.UtilityKotlin.getPicassoTransform;
import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.allprofiles.BseProfileActivity;
import investwell.common.allprofiles.MfuProfileActivity;
import investwell.common.allprofiles.NseProfileActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.common.factsheet.FactSheetActivity;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

;

public class FragPtSummarySchemeDetails extends BaseFragment {
    TextView mTvUserName, cardview_top_name_color, purchase_cost, market_value, mTvUnReleasized, mTvRealizedGain, balance_unit, holding, mTvOneDayChange, mTvXirr, mTvUccINN, tvCurrentValueLavel, tvPurchasePriceLevel, tvUnrealizedLavel, tvRealizedLavel, tvBalanceLavel, tvCurrentNav, tvCurrentNavDate, absretXirrTV, absretXirrValue, mtvBalanceUnitsValue;
    private AppSession mSession;
    private String mCID = "";
    private ClientActivity mActivity;
    private JSONObject mJsonObject, tranJsonObject, mUccIinResponseObject;
    private RequestQueue requestQueue;
    private GridViewButtonAdapter mGridButtonAdapter;
    private GridViewAdapter mGridAdapter;
    private GridView mGridViewButton, mGridViewTrasactionButtons;
    public String mFolioId = "", mAppId = "";
    private AppApplication mAppplication;
    private ToolbarFragment mFragToolBar;
    private CardView mCvTransaction;
    private ImageView mIvScheme;
    private LinearLayout  llXirr, ll_no_profile, absretXirrLY, balanceCagrLY;
    private ConstraintLayout llButtomLine;
    private Button btnContactUs, btnCreateProfile;
    private ApiDataBase db;
    private Bundle mBundle;
    private String mErrorMessage = "";

    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(url, req, res, AppConstants.PORTFOLIO_SCHEME_DETAIL, dateTime, endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onResume() {
        super.onResume();
    /*    if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.portfolio), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag_ptsummary_scheme_details, container, false);
        db = ApiDataBase.getInstance(mActivity.getApplicationContext());
        mUccIinResponseObject = new JSONObject();

        mActivity.runOnUiThread(() -> setUpToolBar());
        mJsonObject = new JSONObject();
        mIvScheme = view.findViewById(R.id.iv_scheme);
        mTvUserName = view.findViewById(R.id.user_name);
        cardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);
        mCvTransaction = view.findViewById(R.id.cardView_transactions);
        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        mTvUnReleasized = view.findViewById(R.id.tvUnRelealized);
        mTvRealizedGain = view.findViewById(R.id.tvReleazied);
        balance_unit = view.findViewById(R.id.balance_unit);
        holding = view.findViewById(R.id.holding);
        ll_no_profile = view.findViewById(R.id.ll_no_profile);
        mTvUccINN = view.findViewById(R.id.tvUccINN);
        tvCurrentNav = view.findViewById(R.id.tvCurrentNav);
        tvCurrentNavDate = view.findViewById(R.id.tvCurrentNavDate);
        llXirr = view.findViewById(R.id.llXirr);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.rlPtSummarySchemeDetails).setBackgroundResource(R.mipmap.card_blank);

        mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
        mTvXirr = view.findViewById(R.id.tvXIRR);

        mGridViewTrasactionButtons = view.findViewById(R.id.gridView);
        mGridAdapter = new GridViewAdapter(getActivity(), new ArrayList<String>());
        mGridViewTrasactionButtons.setAdapter(mGridAdapter);

        mGridViewButton = view.findViewById(R.id.gridViewButton);
        mGridButtonAdapter = new GridViewButtonAdapter(getActivity(), new ArrayList<String>());
        mGridViewButton.setAdapter(mGridButtonAdapter);

        llButtomLine = view.findViewById(R.id.llButtomLine);
        tvCurrentValueLavel = view.findViewById(R.id.tvCurrentValueLavel);
        tvPurchasePriceLevel = view.findViewById(R.id.tvPurchasePriceLevel);
        tvUnrealizedLavel = view.findViewById(R.id.tvUnrealizedLavel);
        tvRealizedLavel = view.findViewById(R.id.tvRealizedLavel);
        tvBalanceLavel = view.findViewById(R.id.tvBalanceLavel);

        balanceCagrLY = view.findViewById(R.id.balanceCagrLY);

        absretXirrLY = view.findViewById(R.id.absretXirrLY);
        absretXirrTV = view.findViewById(R.id.absretXirrTV);
        absretXirrValue = view.findViewById(R.id.absretXirrValue);

        mtvBalanceUnitsValue = view.findViewById(R.id.tv_balance_units_value);

        mBundle = getArguments();
        if (mBundle != null) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                mJsonObject = new JSONObject(mBundle.getString("data"));
                mJsonObject.put("applicant_name", mBundle.getString("applicant_name"));
                mTvUserName.setText(mBundle.getString("applicant_name") + "(" + mJsonObject.optString("folioNo") + ")");
                cardview_top_name_color.setText(mJsonObject.optString("schemeName"));
                if (!TextUtils.isEmpty(mJsonObject.optString("fundName")) && !mJsonObject.optString("fundName").equalsIgnoreCase("null")) {
                    String fundName = "";
                    fundName = mJsonObject.optString("fundName");

                    String fundUrl = UtilityKotlin.getFundImageUrl(fundName);

                    Picasso.get().load(fundUrl).error(R.mipmap.tranparent).transform(getPicassoTransform()).into(mIvScheme);
                }
                mIvScheme.setContentDescription( mJsonObject.optString("fundName") + ". logo");
                mFolioId = mJsonObject.optString("folioid");
                mAppId = mJsonObject.optString("appid");

                Double strHoldingValue = mJsonObject.optDouble("avgHoldingDays");
                long inHolding = Math.round(strHoldingValue);
                holding.setText("" + inHolding);

                Double balanceUnits;
                if(mSession.getHasShowXirr())
                    balanceUnits = mJsonObject.optDouble("currentUnits");
                else
                    balanceUnits = mJsonObject.optJSONObject("summary").optDouble("balanceUnits");

                if (balanceUnits > 0) {
                    String data1 = String.format("%.4f", balanceUnits);
                    mtvBalanceUnitsValue.setText(data1);
                }
                else
                    mtvBalanceUnitsValue.setText("0");



                double currentNav = mJsonObject.optDouble("currentNav");
                String strCurrentNav = String.format("%.2f", currentNav);
                String currentNavdate = UtilityKotlin.dateFormat2(mJsonObject.optString("currentNavDate"));
                tvCurrentNav.setText(strCurrentNav + " ");
                tvCurrentNavDate.setText("(" + currentNavdate + ")");

                UtilityKotlin.safeDisplayXirrPercentValue(mJsonObject, "XIRR", "-", "%", 2, true, mTvXirr);
                String strCurrentAmount = "";
                double currentValue;
                if (mJsonObject.has("currentValue")) {
                    currentValue = mJsonObject.optDouble("currentValue");
                    strCurrentAmount = format.format(currentValue);
                } else {
                    currentValue = mJsonObject.optJSONObject("summary").optDouble("currentValue");
                    strCurrentAmount = format.format(currentValue);
                }
                market_value.setText(strCurrentAmount);
                if (currentValue == 0) {
                    setButtons(true);
                } else {
                    setButtons(false);
                   /* ViewGroup.LayoutParams params = mGridViewButton.getLayoutParams();
                    int height = 0;
                    if (mSession.getLoginType().equalsIgnoreCase("client")) {
                        height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 130, getResources().getDisplayMetrics());
                    } else {
                        height = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 130, getResources().getDisplayMetrics());
                    }

                    params.height = height;
                    mGridViewButton.setLayoutParams(params);
*/

                }

                double purchaseValue = mJsonObject.optDouble("remainingBalUnitsPurchaseValue");
                String strPurchaseValue = format.format(purchaseValue);
                purchase_cost.setText(strPurchaseValue);

                long realizedGain = mJsonObject.optLong("realizedGain");
                String strRealizedGain = format.format(realizedGain);
                if (realizedGain == 0) {
                    mTvRealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.black));
                } else if (realizedGain > 0) {
                    mTvRealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                } else {
                    mTvRealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                }
                mTvRealizedGain.setText(strRealizedGain);

                long unrealizedGain = mJsonObject.optLong("unrealizedGain");
                String strUnrealizedGain = format.format(unrealizedGain);
                if (unrealizedGain == 0) {
                    mTvUnReleasized.setTextColor(ContextCompat.getColor(mActivity, R.color.black));
                } else if (unrealizedGain > 0) {
                    mTvUnReleasized.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                } else {
                    mTvUnReleasized.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                }
                mTvUnReleasized.setText(strUnrealizedGain);
                if (mAppplication.isDaysChange) {
                    long oneDayChange = 0;
                    String strOneDayChange = "";
                    if (mJsonObject.has("oneDayChange")) {
                        oneDayChange = mJsonObject.optLong("oneDayChange");
                        strOneDayChange = format.format(oneDayChange);
                    } else {
                        oneDayChange = mJsonObject.optJSONObject("summary").optLong("oneDayChange");
                        strOneDayChange = format.format(oneDayChange);
                    }

                  /*  long oneDayChange = mJsonObject.optLong("oneDayChange");
                    String strOneDayChange = format.format(oneDayChange);*/
                    if (mAppplication.isDaysChange) {
                        if (oneDayChange == 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText("  (+" + strOneDayChange + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.black));
                        } else if (oneDayChange > 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText("  (+" + strOneDayChange + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                        } else {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText("  (" + strOneDayChange + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                        }
                    }
                } else {
                    mTvOneDayChange.setVisibility(View.GONE);
                }

                if (mSession.getHasShowXirr()) {
                    llButtomLine.setVisibility(View.VISIBLE);
                    if (mSession.getHideXirr().equals("0"))
                        llXirr.setVisibility(View.VISIBLE);
                    else
                        llXirr.setVisibility(View.GONE);

                    absretXirrLY.setVisibility(View.VISIBLE);
                    balanceCagrLY.setVisibility(View.GONE);

                    view.findViewById(R.id.ll_nav).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.ll_holding).setVisibility(View.VISIBLE);
                    tvCurrentValueLavel.setText(getString(R.string.MarketValue));
                    tvPurchasePriceLevel.setText(getString(R.string.PurchaseCost));
                    tvUnrealizedLavel.setText(getString(R.string.unrealized_gain));
                    tvRealizedLavel.setText(getString(R.string.realized_gain));
                    tvBalanceLavel.setText(getString(R.string.BalanceUnit));

                    double absoluteReturn;
                    if (mJsonObject.has("absoluteReturn")) {
                        absoluteReturn = mJsonObject.optDouble("absoluteReturn");
                    } else {
                        absoluteReturn = mJsonObject.optJSONObject("summary").optDouble("absoluteReturn");
                    }
                    String strAbsoluteReturn = String.format("%.2f", absoluteReturn) + "%";
                    if (absoluteReturn == 0) {
                        absretXirrValue.setTextColor(ContextCompat.getColor(mActivity, R.color.black));
                    } else if (absoluteReturn > 0) {
                        absretXirrValue.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                    } else {
                        absretXirrValue.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                    }
                    absretXirrValue.setText(strAbsoluteReturn);

                } else {
                    llButtomLine.setVisibility(View.VISIBLE);
                    llXirr.setVisibility(View.GONE);

                    absretXirrLY.setVisibility(View.GONE);
                    balanceCagrLY.setVisibility(View.VISIBLE);

                    view.findViewById(R.id.ll_nav).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.ll_holding).setVisibility(View.GONE);
                    tvCurrentValueLavel.setText(getString(R.string.CurrentValue));
                    tvPurchasePriceLevel.setText(getString(R.string.Gain));
                  //  tvUnrealizedLavel.setText(getString(R.string.holding_days));
                    tvUnrealizedLavel.setText(getString(R.string.avg_purchase_nav));
                    tvRealizedLavel.setText(getString(R.string.AbsReturn));
                    tvBalanceLavel.setText(getString(R.string.CAGR));

                    double totalGain;
                    if (mJsonObject.has("gain")) {
                        totalGain = mJsonObject.optDouble("gain");
                    } else {
                        totalGain = mJsonObject.optJSONObject("summary").optDouble("gain");
                    }
                    Utils.checkNegativeAndPositiveValue(purchase_cost, totalGain, mActivity);


                    try {
                        double avgCost = mJsonObject.optJSONObject("summary").optDouble("avgCost");
                        String strAvgCost = String.format("%.2f", avgCost);
                        mTvUnReleasized.setText(strAvgCost);



                     /*   double avgHoldingDays;
                        if (mJsonObject.has("avgHoldingDays")) {
                            avgHoldingDays = mJsonObject.optDouble("avgHoldingDays");
                        } else {
                            avgHoldingDays = mJsonObject.optJSONObject("summary").optDouble("avgHoldingDays");
                        }

                        long rounded = Math.round(avgHoldingDays);
                        int days = (rounded <= Integer.MAX_VALUE) ? (int) rounded : Integer.MAX_VALUE;
                        mTvUnReleasized.setText("" + days);*/
                    }
                    catch (Exception e){
                        mTvUnReleasized.setText("");
                    }

                    double absoluteReturn;
                    if (mJsonObject.has("absoluteReturn")) {
                        absoluteReturn = mJsonObject.optDouble("absoluteReturn");
                    } else {
                        absoluteReturn = mJsonObject.optJSONObject("summary").optDouble("absoluteReturn");
                    }

                    String strAbsoluteReturn = String.format("%.2f", absoluteReturn) + "%";
                    if (absoluteReturn == 0) {
                        mTvRealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.black));
                    } else if (absoluteReturn > 0) {
                        mTvRealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                    } else {
                        mTvRealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                    }
                    mTvRealizedGain.setText(strAbsoluteReturn);

                    double cgrValue2;
                    if (mJsonObject.has("CAGR")) {
                        cgrValue2 = mJsonObject.optDouble("CAGR");
                    } else {
                        cgrValue2 = mJsonObject.optJSONObject("summary").optDouble("CAGR");
                    }

                    String srtCAGR2 = String.format("%.2f", cgrValue2) + "%";
                    balance_unit.setText(srtCAGR2);

                }

            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        } else {
            mJsonObject = new JSONObject();
        }

        mGridViewTrasactionButtons.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (mErrorMessage.length() > 0) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.failed), mErrorMessage, "message");
                    return;
                }
                String transectionType = mGridAdapter.mList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("oldObject", mJsonObject.toString());
                bundle.putString("tranJsonObject", tranJsonObject.toString());
                bundle.putString("transactionType", transectionType);
                bundle.putString("isAnimation", "true");
                JSONObject newEmptyobject = new JSONObject();
                bundle.putString("sIinProfileObject", newEmptyobject.toString());

                String exchange = "";
                if (mSession.getHasMultiExchange()) {
                    exchange = AppApplication.sExchangeType;
                    if (exchange == "") exchange = mSession.getExchangeNseBseMfu();
                } else {
                    if (mSession.getHasNseOpted()) {
                        exchange = "1";
                    } else if (mSession.getHasBseOpted()) {
                        exchange = "2";
                    } else if (mSession.getHasMfuOpted()) {
                        exchange = "3";
                    }else if (mSession.getHasNse2Opted()) {
                        exchange = "4";
                    }  else {
                        // exchange = mSession.getExchangeNseBseMfu();
                    }
                }

                if (mSession.getHasMultiExchange()) {
                    bundle.putString("type", "additionalPurchase");
                    mActivity.displayViewOther(76, bundle);
                } else {
                    try {
                        // add pan list
                        JSONObject panlist = new JSONObject();
                        JSONObject nameList = new JSONObject();

                        JSONArray jsonArray = mUccIinResponseObject.getJSONArray("data");
                        if (jsonArray.length() > 0) {
                            JSONObject object = jsonArray.optJSONObject(0);

                            if (!mUccIinResponseObject.optBoolean("recommended") && mSession.getExchangeNseBseMfu().equals("3")) {

                                String mfuid = object.optString("mfuid");
                                String source = object.optString("source");
                                mJsonObject.put("mfuid", mfuid);
                                mJsonObject.put("source", source);
                                bundle.putString("oldObject", mJsonObject.toString());
                                bundle.putString("sIinProfileObject", object.toString());
                            } else {
                                bundle.putString("sIinProfileObject", object.toString());
                            }
                            panlist = UtilityKotlin.buildPanList(object);
                            nameList = UtilityKotlin.buildNameList(object);
                        }

                        if (mUccIinResponseObject == null) {
                            JSONObject object = new JSONObject();
                            bundle.putString("sIinProfileObject", object.toString());
                            mActivity.displayViewOther(34, bundle);
                        } else if (mUccIinResponseObject.optBoolean("recommended")) {
                            bundle.putString("sIinProfileObject", mUccIinResponseObject.toString());
                            mActivity.displayViewOther(34, bundle);
                        } else {

                            if (mActivity!= null){
                                bundle.putString("panList",panlist.toString());
                                bundle.putString("nameList",nameList.toString());
                                bundle.putString("exchangeId",checkExchangeId(mUccIinResponseObject));
                                bundle.putString("exchange",exchange);
                                bundle.putString("appid",mAppId);
                                bundle.putString("mTransactionType",transectionType);
                                bundle.putString("mUccIinResponseObject",mUccIinResponseObject.toString());
                                bundle.putString("comeFrom","additional");
                                mActivity.displayViewOther(88,bundle);
                            }

                        }

                    } catch (Exception e) {
                        if (mUccIinResponseObject == null) {
                            JSONObject object = new JSONObject();
                            bundle.putString("sIinProfileObject", object.toString());
                            mActivity.displayViewOther(34, bundle);
                        }
                    }
                }
            }
        });

        if (mTvRealizedGain.getText().toString().contains("-")) {
            mTvRealizedGain.setTextColor(Color.parseColor("#d01f1f"));
        }


        boolean isTxnEnabled = false;
        isTxnEnabled = mSession.getHasNseOpted()
                || mSession.getHasBseOpted()
                || mSession.getHasMfuOpted()
                || mSession.getHasNse2Opted();

        if (mSession.getHasTransectionEnable() && isTxnEnabled) {
            String schemeId = Utils.getSchemeIdFromAll(mJsonObject);
            getAllTransectionTypes(schemeId);

            mCvTransaction.setVisibility(View.VISIBLE);
        } else {
            mCvTransaction.setVisibility(View.GONE);
        }
        setUpNoProfileButtons(view);
        return view;
    }

    private void setUpNoProfileButtons(View view) {
        btnContactUs = view.findViewById(R.id.btn_contact);
        btnCreateProfile = view.findViewById(R.id.btn_create_profile);
        btnCreateProfile.setVisibility(View.VISIBLE);

        btnContactUs.setOnClickListener(v -> {
            mActivity.displayViewOther(39, null);
        });
        btnCreateProfile.setOnClickListener(v -> {
            Intent intent;
            Bundle bundle;
            switch (mSession.getExchangeNseBseMfu()) {
                case "1":
                    intent = new Intent(getActivity(), NseProfileActivity.class);
                    bundle = new Bundle();
                    bundle.putString("type", "showProfile");
                    bundle.putString("transactionRoute", "clientHome");
                    intent.putExtras(bundle);
                    startActivity(intent);
                    break;
                case "2":
                    intent = new Intent(getActivity(), BseProfileActivity.class);
                    bundle = new Bundle();
                    bundle.putString("type", "showProfile");
                    bundle.putString("transactionRoute", "clientHome");
                    intent.putExtras(bundle);
                    startActivity(intent);
                    break;
                case "3":
                    intent = new Intent(getActivity(), MfuProfileActivity.class);
                    bundle = new Bundle();
                    bundle.putString("type", "showProfile");
                    bundle.putString("transactionRoute", "clientHome");
                    intent.putExtras(bundle);
                    startActivity(intent);
                    break;
            }
        });
    }

    private void setButtons(boolean isHideOutStanding) {
        ArrayList<String> buttonList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
           /* if (mSession.getLoginType().equalsIgnoreCase("client")) {
                if (i == 0) {
                    buttonList.add(getString(R.string.text_folio_details));
                } else if (i == 1 && !isHideOutStanding) {
                    buttonList.add(getString(R.string.text_outstanding_unit));
                }
            } else {
                if (i == 0) {
                    buttonList.add(getString(R.string.text_statement_of_account));
                } else if (i == 1) {
                    buttonList.add(getString(R.string.text_folio_details));
                } else if (i == 2 && !isHideOutStanding) {
                    buttonList.add(getString(R.string.text_outstanding_unit));
                }
            }*/

            if (i == 0) {
                buttonList.add(getString(R.string.text_statement_of_account));
            } else if (i == 1) {
                buttonList.add(getString(R.string.text_folio_details));
            } else if (i == 2) {
                buttonList.add(getString(R.string.factsheet_name));
            } else if (i == 3 && !isHideOutStanding) {
                buttonList.add(getString(R.string.text_outstanding_unit));
            }
        }
        mGridButtonAdapter.updateView(buttonList);

    }

    private void getUccIinMfu(final ProgressDialog bar) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {
            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("componentName", "investOnline");

            String exchange = "";
            if (mSession.getHasMultiExchange()) {
                exchange = AppApplication.sExchangeType;
                if (exchange == "") exchange = mSession.getExchangeNseBseMfu();
            } else {
                if (mSession.getHasNseOpted()) {
                    exchange = "1";
                } else if (mSession.getHasBseOpted()) {
                    exchange = "2";
                } else if (mSession.getHasMfuOpted()) {
                    exchange = "3";
                } else if (mSession.getHasNse2Opted()) {
                    exchange = "4";
                } else {
                    exchange = mSession.getExchangeNseBseMfu();
                }
            }

            if (exchange.equals("1")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_IIN_BY_FOLIO + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("2")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_UCC_LIST + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("3")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CAN_LIST + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("4")) {//GET_SELECTED_UCC_NSE2
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_SELECTED_UCC_NSE2 + "folioid=" + mFolioId + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }else {
                if (bar.isShowing()){
                    bar.dismiss();
                }
                return;
            }

            //https://staging4.investwell.io/webapi/client/investOnline/getCANList?
            // folioid=7cb831cb3a4968b2eb8e350655e57da4&componentForLoader={"componentName":"investOnline"}

            //https://profitcentre.investwell.app/webapi/client/investOnline/getIINByFolios?
            // folioid=a4f17e1832a0448fee277d2afe118e97&componentForLoader=
            // {"componentName":"investOnline"}&investorUid=e243f4494c775264c9ab636395a83863
            // &selectedUser={"uid":"e243f4494c775264c9ab636395a83863","levelNo":"100"}

            /*https://spvithlani.investwell.app/webapi/client/investOnline/getUccList?folioid=
            fe38aa55eded146cb9baddf8751c2004&investorUid=67c025d3f470b86011712f7f974d669d&
            selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/

            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (bar != null)
                    bar.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_CAN_LIST);

                    if (jsonObject.optInt("status") == 0) {

                        mUccIinResponseObject = jsonObject.optJSONObject("result");

                        // Message will be show when recomended false as well as no any ucc/iin
                        if (!mUccIinResponseObject.optBoolean("recommended")) {
                            JSONArray jsonArray = mUccIinResponseObject.getJSONArray("data");
                            if (jsonArray.length() > 0) {
                                mGridViewTrasactionButtons.setVisibility(View.VISIBLE);
                            } else {
                                mGridViewTrasactionButtons.setVisibility(View.GONE);
                                if (mSession.getLoginType().equals("broker")){
                                    ll_no_profile.setVisibility(View.VISIBLE);
                                    String exchange = Utils.getSelectedExchange(mSession);
                                    if (exchange.equals("1")) {
                                        mTvUccINN.setText(getString(R.string.no_iin_available));
                                    } else if (exchange.equals("2") || exchange.equals("4")) {
                                        mTvUccINN.setText(getString(R.string.no_ucc_available));
                                    } else if (exchange.equals("3")) {
                                        mTvUccINN.setText(getString(R.string.no_can_available));
                                    }
                                }else{
                                    ll_no_profile.setVisibility(View.GONE);
                                }


                            }
                        }else{
                            mGridViewTrasactionButtons.setVisibility(View.VISIBLE);
                        }

                    } else if (jsonObject.optInt("status") == -1) {
                        mErrorMessage = jsonObject.optString("message");
                        mGridViewTrasactionButtons.setVisibility(View.VISIBLE);
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    mGridViewTrasactionButtons.setVisibility(View.VISIBLE);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getAllTransectionTypes(String schemeCode) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        try {

            String varableForBSeMfu = "";
            String mExchange = "";
            if (mSession.getExchangeNseBseMfu().equals("1")) {
                varableForBSeMfu = "&hasNseCode=true";
            }else if (mSession.getExchangeNseBseMfu().equals("2")) {
                varableForBSeMfu = "&hasBseCode=true";
            } else if (mSession.getExchangeNseBseMfu().equals("3")) {
                varableForBSeMfu = "&hasMfuCode=true";
            } else if (mSession.getExchangeNseBseMfu().equals("4")){
                varableForBSeMfu = "&hasNseInvestCode=true" ;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TRANSECTION_TYPE + "schid=" + schemeCode + varableForBSeMfu + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "&bid=" + mSession.getBid() + "&exchange=" + mSession.getExchangeNseBseMfu() + "&levelid=" + mSession.getLevelId();
            url = URLDecoder.decode(url, "UTF-8");


            /*https://spvithlani.investwell.app/webapi/client/investOnline/getSchemeNSEInfo?
            schid=9e539c7cf67bc5232e1e40581ba682ee
            &hasBseCode=true
            &bid=
            a14223ec0adf09805f758441c455d58a
            &levelid=7ecb1293761347d78cf6b8f857435249
            &investorUid=67c025d3f470b86011712f7f974d669d&selectedUser=
            {"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/

        } catch (Exception e) {

        }

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_TRANSECTION_TYPE);
                        tranJsonObject = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = tranJsonObject.getJSONArray("allowedInvestmentTypes");
                        if (jsonArray.length() > 0) {
                            ArrayList<String> list = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                String transectionType = jsonArray.getString(i);

                                list.add(transectionType);
                            }
                          //  mGridViewTrasactionButtons.setVisibility(View.VISIBLE);
                            ll_no_profile.setVisibility(View.GONE);
                            mGridAdapter.updateView(list);

                            if (!mSession.getHasMultiExchange())
                                getUccIinMfu(mBar); // miltiple profile
                            else{
                                mGridViewTrasactionButtons.setVisibility(View.VISIBLE);
                                mBar.dismiss();
                            }

                            btnCreateProfile.setVisibility(View.VISIBLE);
                        } else {
                            mBar.dismiss();
                            mCvTransaction.setVisibility(View.GONE);
                            mGridViewTrasactionButtons.setVisibility(View.GONE);
                            ll_no_profile.setVisibility(View.VISIBLE);
                            btnCreateProfile.setVisibility(View.GONE);
                            mTvUccINN.setText(getString(R.string.TransactionNotAllowed));
                        }

                    } else if (jsonObject.optInt("status") == -1) {
                        mBar.dismiss();

                        mGridViewTrasactionButtons.setVisibility(View.GONE);
                        ll_no_profile.setVisibility(View.VISIBLE);
                        btnCreateProfile.setVisibility(View.GONE);
                        mTvUccINN.setText(getString(R.string.TransactionNotAllowed));

                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    if (getActivity() instanceof ClientActivity) {
                        if (!getActivity().isFinishing()) mBar.dismiss();
                    }


                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (getActivity() instanceof ClientActivity) {
                    if (!getActivity().isFinishing()) mBar.dismiss();
                }

                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public class GridViewAdapter extends BaseAdapter {
        private Context mContaxt;
        private ArrayList<String> mList;

        public GridViewAdapter(Context context, ArrayList<String> list) {
            mContaxt = context;
            mList = list;
        }

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(mContaxt, R.layout.gridview_item, null);
            }

            ImageView ivIcon = convertView.findViewById(R.id.ivIcon);
            TextView tvText = convertView.findViewById(R.id.tvText);
            String transectionType = mList.get(position);


            if (transectionType.equalsIgnoreCase("NRP")) {
                ivIcon.setImageResource(R.mipmap.purchase2);
                tvText.setText(getString(R.string.purchase));
            } else if (transectionType.equalsIgnoreCase("SWO")) {
                ivIcon.setImageResource(R.mipmap.switch2);
                tvText.setText(getString(R.string.Switch));
            } else if (transectionType.equalsIgnoreCase("NRS")) {
                ivIcon.setImageResource(R.mipmap.redeem2);
                tvText.setText(getString(R.string.redeem));
            } else if (transectionType.equalsIgnoreCase("SWP")) {
                ivIcon.setImageResource(R.mipmap.swp2);
                tvText.setText(getString(R.string.SWP));
            } else if (transectionType.equalsIgnoreCase("STP")) {
                ivIcon.setImageResource(R.mipmap.stp2);
                tvText.setText(getString(R.string.txt_STP));
            } else if (transectionType.equalsIgnoreCase("SIP")) {
                ivIcon.setImageResource(R.mipmap.sip2);
                tvText.setText(getString(R.string.SIP));
            } else {
                ivIcon.setImageResource(R.mipmap.sip2);
                tvText.setText(transectionType);
            }


            return convertView;
        }

        public void updateView(ArrayList<String> list) {
            mList.clear();
            ArrayList<String> allowedTransaction =
                    prepareAllowedList(list);
            mList.addAll(allowedTransaction);
            notifyDataSetChanged();
        }
    }

    public class GridViewButtonAdapter extends BaseAdapter {
        private Context mContaxt;
        private ArrayList<String> mList;
        private HashMap<Integer, Boolean> mHashMap;

        public GridViewButtonAdapter(Context context, ArrayList<String> list) {
            mContaxt = context;
            mList = list;
            mHashMap = new HashMap<>();
        }

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(mContaxt, R.layout.gridview_button_adapter, null);
            }

            String buttonName = mList.get(position);
            TextView tvText = convertView.findViewById(R.id.botton);
            LinearLayout linerButton = convertView.findViewById(R.id.linerButton);
            tvText.setText(buttonName);

            if (mHashMap.get(position)) {
                linerButton.setBackgroundResource(R.drawable.btn_bg_secondary_selected);
            } else {
                linerButton.setBackgroundResource(R.drawable.btn_bg_secondary_unseleted);
            }
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i = 0; i < mList.size(); i++) {
                        mHashMap.put(i, false);
                    }

                    mHashMap.put(position, true);
                    notifyDataSetChanged();

            /*        if (mSession.getLoginType().equalsIgnoreCase("client")) {
                        if (position == 0) {
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("folioid", mJsonObject.optString("folioid"));
                            bundle1.putString("schid", mJsonObject.optString("schid"));
                            bundle1.putString("isAnimation", "true");
                            mActivity.displayViewOther(15, bundle1);
                        } else if (position == 1) {
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("data", mJsonObject.toString());
                            bundle1.putString("isAnimation", "true");
                            bundle1.putString("applicant_name", mJsonObject.optString("applicantName"));
                            mActivity.displayViewOther(33, bundle1);
                        }
                    } else {

                    }*/

                    if (position == 0) {
                        Bundle bundle1 = new Bundle();
                        bundle1.putString("folioid", mJsonObject.optString("folioid"));
                        String schemeId = Utils.getSchemeIdFromAll(mJsonObject);
                        bundle1.putString("schid", schemeId);
                        bundle1.putString("isAnimation", "true");
                        mActivity.displayViewOther(16, bundle1);
                    } else if (position == 1) {
                        Bundle bundle1 = new Bundle();
                        bundle1.putString("folioid", mJsonObject.optString("folioid"));
                        String schemeId = Utils.getSchemeIdFromAll(mJsonObject);
                        bundle1.putString("schid", schemeId);
                        bundle1.putString("isAnimation", "true");
                        mActivity.displayViewOther(15, bundle1);
                    } else if (position == 2) {
                        Bundle bundle1 = new Bundle();
                        String schemeId = Utils.getSchemeIdFromAll(mJsonObject);
                        bundle1.putString("schemeId", schemeId);
                        bundle1.putString("SchemeName", mJsonObject.optString("schemeName"));
                        bundle1.putString("schemeObj", mJsonObject.toString());
                        Intent i = new Intent(mActivity, FactSheetActivity.class).putExtra("route", "noInv");
                        i.putExtras(bundle1);
                        updateView(new ArrayList<>(mList));
                        startActivity(i);
                    } else if (position == 3) {
                        Bundle bundle1 = new Bundle();
                        bundle1.putString("data", mJsonObject.toString());
                        bundle1.putString("isAnimation", "true");
                        bundle1.putString("applicant_name", mJsonObject.optString("applicantName"));
                        mActivity.displayViewOther(33, bundle1);
                    }


                }
            });

            return convertView;
        }

        public void updateView(ArrayList<String> list) {
            mList.clear();
            mList.addAll(list);
            for (int i = 0; i < list.size(); i++) {
                mHashMap.put(i, false);
            }
            notifyDataSetChanged();
        }
    }


}
