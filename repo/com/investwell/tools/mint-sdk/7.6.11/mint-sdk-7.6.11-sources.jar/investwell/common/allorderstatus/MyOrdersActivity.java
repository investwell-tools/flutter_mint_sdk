package investwell.common.allorderstatus;

import static investwell.utils.ExtensionsKt.formatDateToYYYYMMDD;
import static investwell.utils.ExtensionsKt.getCurrentDateInFormat;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.BaseActivity;
import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.adapter.FragMyOrderAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;

public class MyOrdersActivity extends BaseActivity implements View.OnClickListener {
    private RecyclerView mRecyclerView;
    private ShimmerFrameLayout mShimmerViewContainer;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private boolean loading = false;
    private int mCurrentPageNo = 0;
    private LinearLayout fullScreenShedow, linerUsers;
    private FloatingActionButton mFilterIcon;
    private boolean isClickedApply = false;
    private RelativeLayout mRelFilterMain;
    private RelativeLayout singleShedow;
    private AppSession mSession;
    private int mMonthCount = 0;
    private String mStartingDate = "", mEndDate = "";
    private LinearLayout mLinFilterPart, mLinerCustomDuration, mLinerNoDataFound;
    private Animation slideUpAnimation, slideDownAnimation;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private FragMyOrderAdapter mAdapter;
    private TextView mTvStartDate, mTvEndDate, filterTitle, tv_tool_bar_transaction;
    private boolean mIsFirstTime = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_my_orders);

        initializer();
        initialUi();
        setAdapters();
        getMyOrder(1);
        setListeners();
    }

    @SuppressLint("SetTextI18n")
    private void initializer() {
        mSession = AppSession.getInstance(this);
        mRecyclerView = findViewById(R.id.recycleView);
        tv_tool_bar_transaction = findViewById(R.id.tv_tool_bar_transaction);
        findViewById(R.id.iv_back_transactions).setOnClickListener(this);
        mShimmerViewContainer = findViewById(R.id.shimmer_view_container);
        fullScreenShedow = findViewById(R.id.fullScreenShedow);
        singleShedow = findViewById(R.id.singleShedow);
        mFilterIcon = findViewById(R.id.filters);
        mRelFilterMain = findViewById(R.id.rl_filters);
        mLinFilterPart = findViewById(R.id.rl_filter);
        mLinerCustomDuration = findViewById(R.id.linerCustomDuration);
        mTvStartDate = findViewById(R.id.tvSTart);
        mTvEndDate = findViewById(R.id.tvEnd);
        mLinerNoDataFound = findViewById(R.id.linerNoData);
        filterTitle = findViewById(R.id.filterTitle);
        linerUsers = findViewById(R.id.linerUsers);
        slideUpAnimation = AnimationUtils.loadAnimation(MyOrdersActivity.this, R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(MyOrdersActivity.this, R.anim.slide_down);
        tv_tool_bar_transaction.setText("My Orders");
    }

    private void setAdapters() {
        mRecyclerView.setNestedScrollingEnabled(true);
        mAdapter = new FragMyOrderAdapter(new ArrayList<JSONObject>(), MyOrdersActivity.this);
        mLayoutManager = new LinearLayoutManager(MyOrdersActivity.this, LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }

    private void initialUi() {
        linerUsers.setVisibility(View.GONE);
        filterTitle.setText(getString(R.string.txt_order_duration));
        dateCalculation("custom");

    }

    private void setListeners() {
        mFilterIcon.setOnClickListener(this);
        findViewById(R.id.ivClose).setOnClickListener(this);
        findViewById(R.id.apply_btn).setOnClickListener(this);
        mFilterIcon.setOnClickListener(this);
        mTvStartDate.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 10;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getMyOrder(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        RadioGroup radioGroup = findViewById(R.id.rdGroup);
        radioGroup.check(R.id.radio5);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                mLinerCustomDuration.setVisibility(View.GONE);
                int position = radioGroup.indexOfChild(findViewById(i));
                switch (position) {
                    case 0:
                        dateCalculation("currentMonth");
                        break;

                    case 1:
                        dateCalculation("prevMonth");
                        break;

                    case 2:
                        dateCalculation("currentFy");
                        break;

                    case 3:
                        dateCalculation("previousFy");
                        break;

                    case 4:
                        dateCalculation("custom");
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                }

            }


        });
        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);
              /*  if (!call_from.equals("broker_menu")) {
                    mActivity.mCvTabBarBottom.setVisibility(View.VISIBLE);
                } else {
                    mActivity.mCvTabBarBottom.setVisibility(View.GONE);
                }*/

                mFilterIcon.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.filters) {
                mFilterIcon.setVisibility(View.GONE);
                mRelFilterMain.setVisibility(View.VISIBLE);
                mLinFilterPart.startAnimation(slideUpAnimation);
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                mLinFilterPart.startAnimation(slideDownAnimation);
                isClickedApply = true;
                getMyOrder(1);
}
else if (v.getId() == R.id.tvSTart) {
//                datePicker(true);
                showDatePickerDialog(
                        this,
                        this,
                        null,
                        mTvEndDate.getText().toString(),
                        mTvStartDate.getText().toString(),
                        inputFormat,
                        selectedDateFormatted -> {
                            try {
                                Date parsed = outputFormat.parse(selectedDateFormatted);
                                String apiDate = formatDateToYYYYMMDD(selectedDateFormatted);

                                mTvStartDate.setText(selectedDateFormatted);
                                mStartingDate = apiDate;

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            return null;
                        });
}
else if (v.getId() == R.id.tvEnd) {
//                datePicker(false);
                showDatePickerDialog(
                        this,
                        this,
                        mTvStartDate.getText().toString(),
                        getCurrentDateInFormat(inputFormat),
                        mTvEndDate.getText().toString(),
                        inputFormat,
                        selectedDateFormatted -> {

                            try {
                                Date parsed = outputFormat.parse(selectedDateFormatted);
                                String apiDate = formatDateToYYYYMMDD(selectedDateFormatted);

                                mTvEndDate.setText(selectedDateFormatted);
                                mEndDate = apiDate;
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            return null;
                        });
}
else if (v.getId() == R.id.ivLeft) {
                onBackPressed();
}
else if (v.getId() == R.id.iv_back_transactions) {
                onBackPressed();
}
    }
    SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
    SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private void getMyOrder(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)){
            return;
        }
        mCurrentPageNo = pageNo;
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        } else {
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";
        try {


            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "myOrderTable");
            JSONArray jsonArray = new JSONArray();
            JSONObject fromObject = new JSONObject();
            fromObject.put("fromDate", mStartingDate);
            jsonArray.put(fromObject);

            JSONObject toDateObject = new JSONObject();
            toDateObject.put("toDate", mEndDate);
            jsonArray.put(toDateObject);

            String exchange = "";
            if (mSession.getHasMultiExchange()) {
                exchange = AppApplication.sExchangeType;
                if (exchange == "")
                    exchange = mSession.getExchangeNseBseMfu();
            } else {
                if (mSession.getHasNseOpted()) {
                    exchange = "1";
                } else if (mSession.getHasBseOpted()) {
                    exchange = "2";
                } else if (mSession.getHasMfuOpted()) {
                    exchange = "3";
                }else if (mSession.getHasBseOpted()) {
                    exchange = "4";
                } else {
                    exchange = mSession.getExchangeNseBseMfu();
                }
            }

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MY_ORDER_CLIENT + "currentPage=" + pageNo + "&pageSize=10" + "&orderBy=updatedAt" + "&orderByDesc=true" + "&exchange=" + exchange + "&hasBse=true" + "&filters=" + jsonArray + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            System.out.println();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                loading = false;
                List<JSONObject> list = new ArrayList<>();
                if (pageNo > 1) {
                    list.addAll(mAdapter.mDataList);
                }
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            list.add(jsonObject1);
                        }

                    }
                } catch (Exception e) {

                } finally {
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.GONE);
                    mRecyclerView.setVisibility(View.VISIBLE);

                    if (list.size() > 0) {
                        mAdapter.updateList(list, "");
                        mLinerNoDataFound.setVisibility(View.GONE);
//                                mTvLoading.setVisibility(View.GONE);
                    } else {
                        mAdapter.updateList(new ArrayList<JSONObject>(), "");
                        mLinerNoDataFound.setVisibility(View.VISIBLE);
//                                mTvLoading.setVisibility(View.VISIBLE);
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                mShimmerViewContainer.stopShimmer();
                mShimmerViewContainer.setVisibility(View.GONE);
                mRecyclerView.setVisibility(View.VISIBLE);
                UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(MyOrdersActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(MyOrdersActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


//    private void dateCalculation(boolean isPreviousMonthClicked) {
//        Calendar mCalender = Calendar.getInstance();
//
//        if (mIsFirstTime) {
//            mIsFirstTime = false;
//            mCalender.add(Calendar.MONTH, 0);
//        } else if (mMonthCount == 0) {
//            mCalender.add(Calendar.MONTH, 0);
//        } else {
//            if (isPreviousMonthClicked) mCalender.add(Calendar.MONTH, mMonthCount);
//            else mCalender.add(Calendar.MONTH, mMonthCount);
//        }
//        mCalender.set(Calendar.DAY_OF_MONTH, 1);
//        Date firstDateOfPreviousMonth = mCalender.getTime();
//        mCalender.set(Calendar.DATE, mCalender.getActualMaximum(Calendar.DATE)); // changed calendar to mCalender
//
//        Date lastDateOfPreviousMonth = mCalender.getTime();
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
//        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy");
//        mStartingDate = formatter.format(firstDateOfPreviousMonth);
//        mEndDate = formatter.format(lastDateOfPreviousMonth);
//
//        String dateForString = formatterForText.format(lastDateOfPreviousMonth);
//
//        mTvStartDate.setText(dateForString);
//        mTvEndDate.setText(dateForString);
//
//    }

    private void dateCalculation(String durationType) {
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        if (durationType.equals("currentMonth")) {
            Date todayDate = calendar1.getTime();
            mEndDate = formatter.format(todayDate);

            calendar2.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfCurrentMonth = calendar2.getTime();
            mStartingDate = formatter.format(firstDateOfCurrentMonth);

        } else if (durationType.equals("prevMonth")) {
            calendar1.add(Calendar.MONTH, -1);
            calendar1.set(Calendar.DAY_OF_MONTH, calendar2.getActualMinimum(Calendar.DAY_OF_MONTH));
            Date firstDateOfPreviousMonth = calendar1.getTime();
            mStartingDate = formatter.format(firstDateOfPreviousMonth);

            calendar2.add(Calendar.MONTH, -1);
            calendar2.set(Calendar.DATE, calendar2.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date lastDateOfPreviousMonth = calendar2.getTime();
            mEndDate = formatter.format(lastDateOfPreviousMonth);

        } else if (durationType.equals("currentFy")) {
            Date todayDate = Calendar.getInstance().getTime();
            mStartingDate = getCurrentFinYear(false);
            mEndDate = formatter.format(todayDate);

        } else if (durationType.equals("previousFy")) {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.YEAR, -1);
            mStartingDate = getCurrentFinYear(true);

            int year = calendar.get(Calendar.YEAR);
            mEndDate = (year + 1) + "-03-31";
            System.out.println();

        } else {
            refreshDate();
        }

    }
    private void refreshDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy", new Locale("en","in"));
        String strShowStartDate = "";
        String strShowEndDate = "";

        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            if (mSession.getClientObject().isEmpty()) {
                Calendar mCalender = Calendar.getInstance();
                Date todayDate = mCalender.getTime();
                strShowStartDate = formatterForText.format(todayDate);
                mEndDate = formatter.format(todayDate);

                mCalender.add(Calendar.DAY_OF_YEAR, -15);
                Date previousDays = mCalender.getTime();
                strShowEndDate = formatterForText.format(previousDays);
                mStartingDate = formatter.format(previousDays);
            } else {
                Calendar mCalender = Calendar.getInstance();
                Date todayDate = mCalender.getTime();
                strShowStartDate = formatterForText.format(todayDate);
                mEndDate = formatter.format(todayDate);

                mCalender.add(Calendar.DAY_OF_YEAR, -30);
                Date previousDays = mCalender.getTime();
                strShowEndDate = formatterForText.format(previousDays);
                mStartingDate = formatter.format(previousDays);
            }
        } else {
            Calendar mCalender = Calendar.getInstance();
            Date todayDate = mCalender.getTime();
            mEndDate = formatter.format(todayDate);
            strShowStartDate = formatterForText.format(todayDate);

            mCalender.add(Calendar.DAY_OF_YEAR, -30);
            Date previousDays = mCalender.getTime();
            strShowEndDate = formatterForText.format(previousDays);
            mStartingDate = formatter.format(previousDays);
        }

//        mTvStartDate.setText(strShowStartDate);
//        mTvEndDate.setText(strShowEndDate);
        mTvStartDate.setText(strShowEndDate);
        mTvEndDate.setText(strShowStartDate);
    }
    private String getCurrentFinYear(boolean isPrev) {
        int month = 0;
        int year = 0;
        Calendar calendar = Calendar.getInstance();
        if (isPrev) {
            year = calendar.get(Calendar.YEAR) - 1;
        } else {
            year = calendar.get(Calendar.YEAR);
        }
        month = calendar.get(Calendar.MONTH) + 1;
        String finYearStardDate = "";
        if (month < 3) {
            finYearStardDate = (year - 1) + "-04-01";
        } else if (month == 3) {
            finYearStardDate = (year - 1) + "-04-01";
        } else {
            finYearStardDate = year + "-04-01";
        }
        return finYearStardDate;
    }



    private void datePicker(final boolean isStartDate) {
        Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(MyOrdersActivity.this, (view, year, monthOfYear, dayOfMonth) -> {
            if (view.isShown()) {
                NumberFormat formatter = new DecimalFormat("00");
                String day = formatter.format((dayOfMonth));
                String month = formatter.format((monthOfYear + 1));
                String date_time = year + "-" + month + "-" + day;
                String date_for_text = day + "-" + month + "-" + year;

                if (isStartDate) {
                    mTvStartDate.setText(date_for_text);
                    mStartingDate = date_time;
                } else {
                    mTvEndDate.setText(date_for_text);
                    mEndDate = date_time;
                }
            }

        }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }
}