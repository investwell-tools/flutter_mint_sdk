package investwell.client.activity;

import static investwell.activity.AppApplication.sAppUpdateCalled;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.Extensions.getNSE2ExchangeOnboardingStep;
import static investwell.utils.UtilityKotlin.openCompleteKycOnboardingForm;
import static investwell.utils.UtilityKotlin.openNewKycOnboardingInWebView;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.android.volley.AuthFailureError;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.iw.mint.sdk.BuildConfig;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;

import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.activity.BaseActivity;
import investwell.broker.fragment.FragHome3WithoutLogin;
import investwell.broker.fragment.FragHome6WithoutLogin;
import investwell.broker.fragment.FragHomeBrokerV4;
import investwell.broker.fragment.FragHomeBrokerV5;
import investwell.broker.mfuOnboarding.MfuOnboardingActivity;
import investwell.client.fragments.amcscheme.AmcScheme;
import investwell.client.fragments.amcscheme.FragAmcFinder;
import investwell.client.fragments.folio.sharefolio.FragShareFolioLookupDetails;
import investwell.client.fragments.home.FragHomeClient5;
import investwell.client.fragments.home.FragHomeClient6;
import investwell.client.fragments.my_sip.FragScheduleSipDetails;
import investwell.client.fragments.my_sip.FragSipMainContainer;
import investwell.client.fragments.portfolioSummary.FragPtSummaryFD;
import investwell.client.fragments.portfolioSummary.FragPtSummaryFDLayout6;
import investwell.client.fragments.portfolioSummary.FragPtSummaryMutualFundSingleLayout6;
import investwell.client.fragments.portfolioSummary.FragPtSummarySchemeDetailsLayout6;
import investwell.client.fragments.transferholding.TransferHoldingInfo;
import investwell.client.orderBse.FragOrderDash;
import investwell.client.fragments.home.FragClientProfile;
import investwell.client.fragments.home.FragMyJouneySoFar;
import investwell.client.fragments.others.FragBrokerOrderHome;
import investwell.client.fragments.portfolioSummary.FragAllInvestHome3;
import investwell.client.fragments.portfolioSummary.FragInvestInExistingPortfolio;
import investwell.client.orderBse.FragOrdersBse;
import investwell.common.casimport.FragCasImportMain;
import investwell.common.casimport.FragCasOTPAuthenticate;
import investwell.common.nav.FragLatestNav;
import investwell.common.permissions.NotificationPermissionHandler;
import investwell.common.permissions.NotificationPermissionManager;
import investwell.common.permissions.PermissionHandlerViewModel;
import investwell.di.ForceUpdate;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.iw.mint.sdk.R;
import com.voltmoney.voltsdk.VoltSDKContainer;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.text.Format;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import investwell.activity.AppApplication;
import investwell.activity.SplashActivity;
import investwell.broker.fragment.FragHomeBroker;
import investwell.broker.fragment.FragHomeBrokerV2;
import investwell.broker.nseOnborading.BrokerNseOnBoardingActivity;
import investwell.client.fragments.aum.FragAumReport;
import investwell.client.fragments.aum.FragAumReportByScheme;
import investwell.client.fragments.aum.FragAumReportByUser;
import investwell.client.fragments.capitalgain.FragCapitalGainHome;
import investwell.client.fragments.dividend.FragDividendReport;
import investwell.client.fragments.dividend.FragDividendReportDetails;
import investwell.client.fragments.dividend.FragDividendReportFamily;
import investwell.client.fragments.elss.FragELSS1User;
import investwell.client.fragments.elss.FragELSS2Scheme;
import investwell.client.fragments.elss.FragELSS3Trans;
import investwell.client.fragments.folio.FragFolioLookup;
import investwell.client.fragments.folio.FragFolioLookupDetails;
import investwell.client.fragments.folio.Frag_SOA;
import investwell.client.fragments.goal.FragAddNewGoals;
import investwell.client.fragments.goal.FragGoalForm;
import investwell.client.fragments.goal.FragGoalList;
import investwell.client.fragments.goal.FragUpdateGoal;
import investwell.client.fragments.help.ContactFragment;
import investwell.client.fragments.help.ContactFragmentV2;
import investwell.client.fragments.help.FaqFragment;
import investwell.client.fragments.help.HelpHostFragment;
import investwell.client.fragments.help.MoreFragment;
import investwell.client.fragments.home.FragHomeClient;
import investwell.client.fragments.home.FragHomeClient2;
import investwell.client.fragments.home.FragHomeClient3;
import investwell.client.fragments.home.FragHomeClient4;
import investwell.client.fragments.home.FragNotification;
import investwell.client.fragments.insurance.FragInsuranceHome;
import investwell.client.fragments.my_sip.FragMySipDetail;
import investwell.client.fragments.mydoc.FragDocumentFilesList;
import investwell.client.fragments.mydoc.FragDocumentFolders;
import investwell.client.fragments.others.BottomSheetFragmentClient;
import investwell.client.fragments.others.FragCapitalGainUnrealized;
import investwell.client.fragments.others.FragMyOrders;
import investwell.client.fragments.others.FragProfileSettings;
import investwell.client.fragments.others.Help_Frag;
import investwell.client.fragments.portfolio.FragPortfolioHome;
import investwell.client.fragments.portfolio.FragPortfolioShareDetails;
import investwell.client.fragments.portfolio.PortfolioSchemeDetail;
import investwell.client.fragments.portfolio.Portfolio_Detail;
import investwell.client.fragments.portfolioSummary.FragIinByFolio;
import investwell.client.fragments.portfolioSummary.FragOutStandingUnitDetails;
import investwell.client.fragments.portfolioSummary.FragPtSummaryHome;
import investwell.client.fragments.portfolioSummary.FragPtSummaryMutualFundSingle;
import investwell.client.fragments.portfolioSummary.FragPtSummarySchemeDetails;
import investwell.client.fragments.portfolioSummary.FragPtSummaryShareBonds2;
import investwell.client.fragments.portfolioSummary.FragPtSummaryShareBonds3;
import investwell.client.fragments.transection.additional.common.FragRedeemNseBseMfu;
import investwell.client.fragments.transection.additional.common.FragStpBseMfu;
import investwell.client.fragments.transection.additional.common.FragStpNse;
import investwell.client.fragments.transection.additional.common.FragSwitchNseBseMfu;
import investwell.client.fragments.transection.additional.common.FragSwpNse;
import investwell.client.fragments.transection.additional.common.FragSwpNseBse;
import investwell.client.fragments.transection.additional.purchase.FragAdditionalPurchaseBse;
import investwell.client.fragments.transection.additional.purchase.FragAdditionalPurchaseMfu;
import investwell.client.fragments.transection.additional.purchase.FragAdditionalPurchaseNse;
import investwell.client.fragments.transection.additional.sip.FragAdditionalSipBse;
import investwell.client.fragments.transection.additional.sip.FragAdditionalSipMfu;
import investwell.client.fragments.transection.additional.sip.FragAdditionalSipNse;
import investwell.client.fragments.transection.status.FragOrderStatusNseBse;
import investwell.common.allprofiles.BseProfileActivity;
import investwell.common.allprofiles.MfuProfileActivity;
import investwell.common.allprofiles.NseProfileActivity;
import investwell.common.calculator.fragment.FragEducationCalculator;
import investwell.common.calculator.fragment.FragEmiCalculator;
import investwell.common.calculator.fragment.FragLumsumCal;
import investwell.common.calculator.fragment.FragMarriegeCalculator;
import investwell.common.calculator.fragment.FragRetirmentCalculator;
import investwell.common.calculator.fragment.FragSipCalculator;
import investwell.common.calculator.fragment.FragSipDelayCost;
import investwell.common.calculator.fragment.FragSipStepup;
import investwell.common.calculator.fragment.FragTaxInvestmentCal;
import investwell.common.checkkyc.FragCommonCheckKycPan;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.common.intro.IntroActivity;
import investwell.common.intro.SingleIntroActivity;
import investwell.common.lock.FragChangeAppSecurity;
import investwell.common.onboarding.ExchangeForAdditionalPurchase;
import investwell.common.onboarding.OnBoardingActivity;
import investwell.common.onboarding.SelectOnBoardingUserActivity;
import investwell.common.transactions.fragments.FragAddTxnFD;
import investwell.common.transactions.fragments.FragAddTxnShareAndBond;
import investwell.common.transactions.fragments.FragTransactionHome;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.RoundedImageView;
import investwell.utils.TimeDateUtils;
import investwell.utils.crop.CropImage;
import investwell.utils.customView.CustomDialog;
import investwell.utils.customView.ImagePickerActivity;
import investwell.utils.volleyCustom.VolleyMultipartRequest;
import investwell.utils.volleyCustom.VolleySingleton;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.text.Charsets;

public class ClientActivity extends BaseActivity implements View.OnClickListener, NotificationPermissionHandler  {
    public List<JSONObject> mSelectedCartsList;
    private AppSession mSession;
    private boolean mIsDailogIsShowing = false;
    private LinearLayout llTabBarHome1, llTabBarHome3;
    private RelativeLayout mTab1, mTab2, mTab3, mTab4, mTab5;
    private TextView mTvMenu1, mTvMenu2, mTvMenu3, mTvMenu4, mTvMenu5;
    private ImageView mIvMenu1, mIvMenu2, mIvMenu3, mIvMenu4, mIvMenu5;
    private RelativeLayout mHome3Tab1, mHome3Tab2, mHome3Tab3, mHome3Tab4, mHome3Tab5;
    private TextView mTvHome3Menu1, mTvHome3Menu2, mTvHome3Menu3, mTvHome3Menu4, mTvHome3Menu5;
    private ImageView mIvHome3Menu1, mIvHome3Menu2, mIvHome3Menu3, mIvHome3Menu4, mIvHome3Menu5;
    private View mIvHome3Line1, mIvHome3Line2, mIvHome3Line3, mIvHome3Line4, mIvHome3Line5;
    public static int mTabCount = 1;
    public CardView mCvTabBarBottom;
    private AppApplication mApplication;
    private Bundle mBundle;
    public JSONObject mProsPectStatusObject;
    private final int RC_APP_UPDATE = 0;
    private final int REQUEST_APP_UPDATE = 17362;
    public AppApplication mAppplication;
    public String mSelectedValue = "currentFY";
    private BottomSheetFragmentClient bottomSheetFragment;
    private JSONObject appConfigObject;
    private Bundle mBundleSaveInstance;
    private String mCallCommingFrom = "";
    private final int imageCode = 1001;

    private ReviewInfo reviewInfo;
    private ReviewManager reviewManager;

    private VoltSDKContainer voltSDKInstance;

    private long backPressedTime = 0;
    private Toast backToast;
    //first value is dataSource and second is activeFoliosOnly
    public Pair<String, Boolean> ptMFSelectedFilter = new Pair<>("0", true);

    private PermissionHandlerViewModel permissionViewModel;
    private NotificationPermissionManager permissionManager;

  /*  @Override
    protected void onStart() {
        System.out.println("binesh: onStart");
//        UtilityKotlin.checkReAuth(mSession, ClientActivity.this);
        super.onStart();
    }

    @Override
    public void onAttachFragment(android.app.Fragment fragment) {
        System.out.println("binesh: onAttachActivty");
        super.onAttachFragment(fragment);
    }*/

    @Override
    protected void onDestroy() {
        super.onDestroy();

        AppApplication.sExchangeType = "";
        ProgressBarCommon.dismissDialog();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public void onBackPressedHandled() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
        int fragmentCount = getSupportFragmentManager().getBackStackEntryCount();

        if ((mSession.getHasLoging() && mSession.getLoginType().equalsIgnoreCase("broker"))) {
            if (fragment instanceof FragHomeClient ||fragment instanceof FragHomeClient2 || fragment instanceof FragHomeClient3 || fragment instanceof FragHomeClient4|| fragment instanceof FragHomeClient5|| fragment instanceof FragHomeClient6) {
                mSession.setClientObject("");
                Log.d("client_object_clear", "data clear: ClientActivity");
                finish();
            } else {
                super.onBackPressedHandled();
            }
        } else {
            handleBackPressedCase(fragmentCount);
        }
    }

    private void handleBackPressedCase(int fragmentCount)
    {
        if (fragmentCount == 0) {
            if (backPressedTime + 2000 > System.currentTimeMillis()) {
                backToast.cancel();
                super.onBackPressedHandled();
            } else {
                backToast = Toast.makeText(this, getString(R.string.press_back_again_to_exit), Toast.LENGTH_SHORT);
                backToast.show();
            }
            backPressedTime = System.currentTimeMillis();
        }
        else {
            getSupportFragmentManager().popBackStack();
        }
    }



    public <T> void setMainVisibility(Fragment fragment, T object) {
        try {
            if (fragment instanceof FragHomeBroker
                    || fragment instanceof FragHome6WithoutLogin
                    || fragment instanceof FragHome3WithoutLogin
                    || fragment instanceof FragHomeBrokerV2
                    || fragment instanceof FragHomeBrokerV4
                    || fragment instanceof FragHomeBrokerV5
                    || fragment instanceof FragHomeClient
                    || fragment instanceof FragHomeClient2
                    || fragment instanceof FragHomeClient3
                    || fragment instanceof FragHomeClient4
                    || fragment instanceof FragHomeClient5
                    || fragment instanceof FragHomeClient6
                    || fragment instanceof FragPtSummaryHome
                    || fragment instanceof FragPortfolioHome
                    || fragment instanceof FragTransactionHome
                    || fragment instanceof BottomSheetFragmentClient
                    || fragment instanceof FragAllInvestHome3) {

                if (mSession.getHasLoging()) {
                    mCvTabBarBottom.setVisibility(View.VISIBLE);
                } else {
                    mCvTabBarBottom.setVisibility(View.GONE);
                }

                if (fragment instanceof FragHomeClient2 || fragment instanceof FragHomeClient4 || fragment instanceof FragHomeClient || fragment instanceof FragHomeClient3|| fragment instanceof FragHomeClient6) {
                    changeColor(1);
                    mTabCount = 1;
                } else if (fragment instanceof FragPortfolioHome || fragment instanceof FragPtSummaryHome) {
                    if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                        // changeColor(3);
                        // mTabCount = 3;
                    } else {
                        changeColor(2);
                        mTabCount = 2;
                    }

                } else if (fragment instanceof FragAllInvestHome3) {
                    changeColor(2);
                    mTabCount = 2;

                } else if (fragment instanceof FragTransactionHome) {
                    if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                        // changeColor(4);
                        //  mTabCount = 4;
                    } else {
                        changeColor(3);
                        mTabCount = 3;
                    }
                } else if (fragment instanceof BottomSheetFragmentClient) {
                    changeColor(4);
                    if (mTabCount == 1) {
                        changeColor(1);
                    } else if (mTabCount == 2) {
                        changeColor(2);
                    } else if (mTabCount == 3) {
                        changeColor(3);
                    }
                } else {
                    changeColor(1);
                    mTabCount = 1;
                }
            } else {
                mCvTabBarBottom.setVisibility(View.GONE);
                if (bottomSheetFragment.isVisible()) {
                    bottomSheetFragment.dismiss();
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (myReceiver != null) {
            unregisterReceiver(myReceiver);
            myReceiver = null;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            registerReceiver(myReceiver, new IntentFilter("FBR-IMAGE"), RECEIVER_EXPORTED);
        }else{
            //  registerReceiver(myReceiver, new IntentFilter("FBR-IMAGE"));
        }
        permissionViewModel.updatePermissionStatus(this);
    }

    /**********************************************************
     BroadCastReceiver for get notification Check
     ***********************************************************/

    public BroadcastReceiver myReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateNotificationCount();

           /* String action = intent.getStringExtra("action");
            if (action.isEmpty()) {

                tv_notification_badge.setVisibility(View.INVISIBLE);
                tvNotficationBadge3B.setVisibility(View.INVISIBLE);
            } else {
                tv_notification_badge.setVisibility(View.VISIBLE);
                tvNotficationBadge3B.setVisibility(View.VISIBLE);
                notificationCount();
            }*/
        }
    };

    private void updateNotificationCount() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
        if (fragment instanceof FragHomeClient) {
            ((FragHomeClient) fragment).notificationCount();
        }
        else  if (fragment instanceof FragHomeClient2) {
            ((FragHomeClient2) fragment).notificationCount();
        }
        else  if (fragment instanceof FragHomeClient3) {
            ((FragHomeClient3) fragment).notificationCount();
        }
        else  if (fragment instanceof FragHomeClient5) {
            ((FragHomeClient5) fragment).notificationCount();
        }
        else  if (fragment instanceof FragHomeClient6) {
            ((FragHomeClient6) fragment).notificationCount();
        }
    }

    private ApiDataBase db;

    private void insertApiData(String url, String req, String res, String dateTime, String
            endPoint) {
        final ApiDataModel api = new ApiDataModel(url, req, res, AppConstants.HOME_WITH, dateTime, endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!Utils.isTablet(this))
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);
        permissionViewModel  = new ViewModelProvider(this).get(PermissionHandlerViewModel.class);
        permissionManager = new NotificationPermissionManager(
                this,
                granted -> {
                    permissionViewModel.updatePermissionStatus(ClientActivity.this);
                    return null;
                }
        );
        permissionManager.register();

        Extensions.checkDevice(this);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        db = ApiDataBase.getInstance(getApplicationContext());
        mApplication = (AppApplication) getApplication();
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("coming_from")) {
            mCallCommingFrom = intent.getStringExtra("coming_from");
        }
        reviewManager = ReviewManagerFactory.create(this);

        AppApplication.OVER_SUMMARY_SUMMARY = "";
        AppApplication.VALUE_ASSETS_WISE = "";

        if(!(intent.hasExtra("comeFromMfuCartWebView") || intent.hasExtra("comeFromNseCartWebView") || intent.hasExtra("comeFromBseCartWebView"))){
            AppApplication.sExchangeType = "";
        }
        if (intent != null) {
            mBundle = intent.getExtras();
        }
        mAppplication = (AppApplication) getApplication();
        mSession = AppSession.getInstance(this);
        Extensions.updateLocale(this,mSession.getAppLanguage());

        llTabBarHome1 = findViewById(R.id.llTabBarHome1);
        llTabBarHome3 = findViewById(R.id.llTabBarHome3);
        mCvTabBarBottom = findViewById(R.id.ly_header);

        mTab1 = findViewById(R.id.relMenu1);
        mTab2 = findViewById(R.id.relMenu2);
        mTab3 = findViewById(R.id.relMenu3);
        mTab4 = findViewById(R.id.relMenu4);
        mTab5 = findViewById(R.id.relMenu5);

        mTvMenu1 = findViewById(R.id.tvMenu1);
        mTvMenu2 = findViewById(R.id.tvMenu2);
        mTvMenu3 = findViewById(R.id.tvMenu3);
        mTvMenu4 = findViewById(R.id.tvMenu4);
        mTvMenu5 = findViewById(R.id.tvMenu5);

        mIvMenu1 = findViewById(R.id.ivMenu1);
        mIvMenu2 = findViewById(R.id.ivMenu2);
        mIvMenu3 = findViewById(R.id.ivMenu3);
        mIvMenu4 = findViewById(R.id.ivMenu4);
        mIvMenu5 = findViewById(R.id.ivMenu5);

        mTab1.setOnClickListener(this);
        mTab2.setOnClickListener(this);
        mTab3.setOnClickListener(this);
        mTab4.setOnClickListener(this);
        mTab5.setOnClickListener(this);

        mHome3Tab1 = findViewById(R.id.relHome3Menu1);
        mHome3Tab2 = findViewById(R.id.relHome3Menu2);
        mHome3Tab3 = findViewById(R.id.relHome3Menu3);
        mHome3Tab4 = findViewById(R.id.relHome3Menu4);
        mHome3Tab5 = findViewById(R.id.relHome3Menu5);

        mTvHome3Menu1 = findViewById(R.id.tvHome3Menu1);
        mTvHome3Menu2 = findViewById(R.id.tvHome3Menu2);
        mTvHome3Menu3 = findViewById(R.id.tvHome3Menu3);
        mTvHome3Menu4 = findViewById(R.id.tvHome3Menu4);
        mTvHome3Menu5 = findViewById(R.id.tvHome3Menu5);

        mIvHome3Menu1 = findViewById(R.id.ivHome3Menu1);
        mIvHome3Menu2 = findViewById(R.id.ivHome3Menu2);
        mIvHome3Menu3 = findViewById(R.id.ivHome3Menu3);
        mIvHome3Menu4 = findViewById(R.id.ivHome3Menu4);
        mIvHome3Menu5 = findViewById(R.id.ivHome3Menu5);

        mIvHome3Line1 = findViewById(R.id.lineMenu1);
        mIvHome3Line2 = findViewById(R.id.lineMenu2);
        mIvHome3Line3 = findViewById(R.id.lineMenu3);
        mIvHome3Line4 = findViewById(R.id.lineMenu4);
        mIvHome3Line5 = findViewById(R.id.lineMenu5);

        mHome3Tab1.setOnClickListener(this);
        mHome3Tab2.setOnClickListener(this);
        mHome3Tab3.setOnClickListener(this);
        mHome3Tab4.setOnClickListener(this);
        mHome3Tab5.setOnClickListener(this);

        if (!mSession.getHasTransectionEnable()) {
            mHome3Tab2.setVisibility(View.GONE);
        } else {
            mHome3Tab2.setVisibility(View.VISIBLE);
        }

        if (mSession.getHasLoging()) {
            callClientInfoApi(false, false);
        }


        if (bottomSheetFragment == null) {
            bottomSheetFragment = new BottomSheetFragmentClient();
        }

        mSelectedCartsList = new ArrayList<>();
        mBundleSaveInstance = savedInstanceState;


        updateNotificationCount();
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
                // appConfigObject.put("layout", "3");

                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                    llTabBarHome3.setVisibility(View.VISIBLE);
                    llTabBarHome1.setVisibility(View.GONE);
                    changeColor(1);
                    mTabCount = 1;

                    String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
                    if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
                        JSONObject mJsoObject = null;
                        try {
                            mJsoObject = new JSONObject(allowedFeatured);

                            JSONArray jsonArray = mJsoObject.optJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                if (jsonArray.optJSONObject(i).has("feature1017") && mSession.getExchangeNseBseMfu().equalsIgnoreCase("1")) {
                                    mHome3Tab2.setVisibility(View.VISIBLE);
                                    break;
                                } else if (jsonArray.optJSONObject(i).has("feature1021") && mSession.getExchangeNseBseMfu().equalsIgnoreCase("2")) {
                                    mHome3Tab2.setVisibility(View.VISIBLE);
                                    break;
                                } else if (jsonArray.optJSONObject(i).has("feature1024") && mSession.getExchangeNseBseMfu().equalsIgnoreCase("3")) {
                                    mHome3Tab2.setVisibility(View.VISIBLE);
                                    break;
                                } else if (jsonArray.optJSONObject(i).has("feature1042") && mSession.getExchangeNseBseMfu().equalsIgnoreCase("4")) {
                                    mHome3Tab2.setVisibility(View.VISIBLE);
                                    break;
                                }else{
                                    mHome3Tab2.setVisibility(View.GONE);
                                }

                            }
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }
                    }

                } else {
                    llTabBarHome3.setVisibility(View.GONE);
                    llTabBarHome1.setVisibility(View.VISIBLE);
                }

            } else {
                appConfigObject = new JSONObject();
            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        if (mSession.getAppInfo().isEmpty()) {
            getPublicInfo();
        }else{
            reDirectMethod();
        }
        if (!BuildConfig.DEBUG) new ForceUpdate(mSession).forceUpdateIfRequired(this);
        if (sAppUpdateCalled) {
            sAppUpdateCalled = false;

            if(getString(R.string.subdomain).equals("mint")) requestNotificationPermission(false);
            //if (!BuildConfig.DEBUG) new ForceUpdate(mSession).forceUpdateIfRequired(this);
        }

        Intent intent1 = getIntent();
        int step = 0;

        if (intent1 != null && intent1.hasExtra("step")) {
            step = intent1.getIntExtra("step", 0);
        }

        if (step == 35) {
            displayViewOther(35, null);
        }
        if (intent.hasExtra("contact")) {
            displayViewOther(39, null);
        }

        if (intent.hasExtra("type") && intent.getStringExtra("type").equalsIgnoreCase("newKycOnboard")) {

            if(intent.hasExtra("status") && intent.getStringExtra("status").equalsIgnoreCase("failed")) {
                CustomDialog customDialog = new CustomDialog(view -> {
                    if (view.getId() == R.id.btDone) {
}
else if (view.getId() == R.id.btCalcel) {
}
                });

                customDialog.showDialog(this, getString(R.string.alert),
                        getString(R.string.new_kyc_failure_msg),
                        getString(R.string.alert_dialog_btn_txt),
                        "",
                        true, false);
            }

        }

        checkVOltCokiee();
        hideBottomMenu();

        if(intent.hasExtra("comeFromMfuCartWebView")) {
            Bundle bundle = new Bundle();
            bundle.putBoolean("comeFromMfuCartWebView", true);
            displayViewOther(98, bundle);
        }
        if(intent.hasExtra("comeFromBseCartWebView")){
            Bundle bundle = new Bundle();
            bundle.putBoolean("comeFromBseCartWebView", true);
            displayViewOther(35, bundle);
        }
        if(intent.hasExtra("comeFromNseCartWebView")){
            Bundle bundle = new Bundle();
            bundle.putBoolean("comeFromNseCartWebView", true);
            displayViewOther(35, bundle);
        }
        if (intent.hasExtra("transactionDeeplinkUrl")) {
            String transactionDeeplinkUrl = intent.getStringExtra("transactionDeeplinkUrl");
            if (transactionDeeplinkUrl != null) {
                getSchemeDetailsForDeeplink(transactionDeeplinkUrl);
            }
        }

        if(llTabBarHome1.getVisibility() == View.VISIBLE)
            updateAccessibilityOfTab(0);
        else
            updateAccessibilityOfTab(4);
    }

    private void applyTabAccessibility(
            View tabView,
            String label,
            int index,
            boolean isSelected) {

        tabView.setFocusable(true);
        tabView.setClickable(true);
        tabView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);

        tabView.setContentDescription(
                label + ". tab " + (index + 1) + " of " + 4
                        + (isSelected ? ". selected" : ". not selected")
        );
    }
    private void updateAccessibilityOfTab(int index) {

        applyTabAccessibility(
                mTab1,
                mTvMenu1.getText().toString(),
                0,
                index == 0
        );

        applyTabAccessibility(
                mTab2,
                mTvMenu2.getText().toString(),
                1,
                index == 1
        );

        applyTabAccessibility(
                mTab3,
                mTvMenu3.getText().toString(),
                2,
                index == 2
        );

        applyTabAccessibility(
                mTab4,
                mTvMenu4.getText().toString(),
                3,
                index == 3
        );

        applyTabAccessibility(
                mHome3Tab1,
                mTvHome3Menu1.getText().toString(),
                4,
                index == 4
        );

        applyTabAccessibility(
                mHome3Tab2,
                mTvHome3Menu2.getText().toString(),
                5,
                index == 5
        );

        applyTabAccessibility(
                mHome3Tab3,
                mTvHome3Menu3.getText().toString(),
                6,
                index == 6
        );

        applyTabAccessibility(
                mHome3Tab4,
                mTvHome3Menu4.getText().toString(),
                7,
                index == 7
        );

        applyTabAccessibility(
                mHome3Tab5,
                mTvHome3Menu5.getText().toString(),
                8,
                index == 8
        );

    }

    public void getSchemeDetailsForDeeplink(String transactionDeeplinkUrl) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }

        String isInFromDeeplink = UtilityKotlin.getIsInFromDeeplink(transactionDeeplinkUrl);
        String exchangeFromDeeplink = UtilityKotlin.getExchangeFromDeeplink(transactionDeeplinkUrl);
        String schemeRoute = UtilityKotlin.getSchemeRouteForDeeplink(transactionDeeplinkUrl);

        JSONArray filterArray = new JSONArray();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("isinNo", isInFromDeeplink);
            filterArray.put(jsonObject);
        } catch (Exception e) {

        }

        String apiName = "";
        if (schemeRoute.equals("allSchemes")) {
            apiName = Config.GET_TOP_SCHEME_LIST_NSE;
        } else if (schemeRoute.equals("nfoSchemes")) {
            apiName = Config.GET_NFO_SCHEME_LIST_API+"?";
        }

        String hasExchangeCode = "";
        if (mSession.getHasMultiExchange()) {
            AppApplication.sExchangeType = "1";
        }
        if (exchangeFromDeeplink.equals("2")) {
            hasExchangeCode = "hasBseCode=true";
        } else if (exchangeFromDeeplink.equals("3")) {
            hasExchangeCode = "hasMfuCode=true";
        } else if (exchangeFromDeeplink.equals("4")) {
            hasExchangeCode = "hasNseInvestCode=true";
        }


        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + apiName + "filters=" + filterArray + "&orderBy=schemeGroupName" + "&orderByDesc=false&" + hasExchangeCode + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        KtorCallBack mCallback = new KtorCallBack() {
            @Override
            public void onSuccess(String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject resultData = jsonObject.optJSONObject("result");
                        if (resultData != null) {
                            JSONArray dataArray = resultData.optJSONArray("data");
                            if (dataArray!=null && dataArray.length()>0){
                                JSONObject jsonObject1 = dataArray.optJSONObject(0);


                                Bundle bundle = new Bundle();
                                bundle.putString("schemeId", Utils.getSchemeIdFromAll(jsonObject1));
                                bundle.putString("SchemeName", jsonObject1.optString("schemeName"));
                                bundle.putString("schemeObj", jsonObject1.toString());

                                switch (exchangeFromDeeplink) {
                                    case "2": {
                                        Intent intent = new Intent(ClientActivity.this, BseProfileActivity.class);
                                        bundle.putString("type", "investmentProfile");
                                        bundle.putString("transactionRoute", "nfo");
                                        bundle.putString("transactionDeeplinkUrl", transactionDeeplinkUrl);
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                        break;
                                    }

                                    case "3": {
                                        Intent intent = new Intent(ClientActivity.this, MfuProfileActivity.class);
                                        bundle.putString("type", "investmentProfile");
                                        bundle.putString("transactionRoute", "nfo");
                                        bundle.putString("transactionDeeplinkUrl", transactionDeeplinkUrl);
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                        break;
                                    }

                                    case "4": {
                                        Intent intent = new Intent(ClientActivity.this, BseProfileActivity.class);
                                        bundle.putString("type", "investmentProfile");
                                        bundle.putString("transactionRoute", "nfo");
                                        bundle.putString("transactionDeeplinkUrl", transactionDeeplinkUrl);
                                        bundle.putBoolean("nse2", true);
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                        break;
                                    }

                                    default:
                                        // Optional: handle unknown value
                                        break;
                                }
                            }

                        }
                    } else {
                        showCommonDailog(ClientActivity.this, getString(R.string.alert), jsonObject.optString("message"));
                    }

                } catch (JSONException e) {
                }
            }

            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                if (isLoading) {
                    ProgressBarCommon.showDialog(ClientActivity.this);
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }
        };

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, mCallback);
    }



    private void hideBottomMenu() {
        if (!mSession.getHasLoging()){
            mCvTabBarBottom.setVisibility(View.GONE);
        }
    }
    private void checkVOltCokiee() {
        if (mCallCommingFrom.equalsIgnoreCase("broker")) {
            if (!mSession.getLocalTimeInMillis().equals("null") && !mSession.getLocalTimeInMillis().equals("") && !mSession.getVoltAuthToken().equals("") && !mSession.getVoltAuthToken().equals("null")) {
                WebStorage.getInstance().deleteAllData();
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
            }
        }
    }


    @Override
    public void onClick(View v) {
        Bundle bundle = new Bundle();
        if (v.getId() == R.id.relMenu1) {
                changeColor(1);
                mTabCount = 1;

                if (mSession.getLoginType().equals("broker")) {
                    removeAllStack();
                    bundle.putString("isAddBackToStack", "no");
                    displayViewOther(3, bundle);
                } else {
                    removeAllStack();
                }
                updateAccessibilityOfTab(0);
}
else if (v.getId() == R.id.relMenu2) {
                changeColor(2);
                mTabCount = 2;
              /*  bundle.putString("screen_name", "Portfolio");
                displayViewOther(4, bundle);*/
                updateAccessibilityOfTab(1);
                displayViewOther(19, bundle);
}
else if (v.getId() == R.id.relMenu3) {
                changeColor(3);
                mTabCount = 3;
                updateAccessibilityOfTab(2);
                displayViewOther(6, bundle);
}
else if (v.getId() == R.id.relMenu4) {
                changeColor(4);
                if (mTabCount == 1) {
                    changeColor(1);
                } else if (mTabCount == 2) {
                    changeColor(2);
                } else if (mTabCount == 3) {
                    changeColor(3);
                } else if (mTabCount == 5) {
                    changeColor(5);
                }
                updateAccessibilityOfTab(3);

                if (!bottomSheetFragment.isVisible() && !bottomSheetFragment.isAdded())
                    bottomSheetFragment.show(getSupportFragmentManager(), bottomSheetFragment.getTag());
}
else if (v.getId() == R.id.relMenu5) {
                changeColor(5);
                mTabCount = 5;
                displayViewOther(62, null);


            /*homeLayout3*/
}
else if (v.getId() == R.id.relHome3Menu1) {
                System.out.println();
                changeColor(1);
                mTabCount = 1;
                updateAccessibilityOfTab(4);
                if (mSession.getLoginType().equals("broker")) {
                    removeAllStack();
                    bundle.putString("isAddBackToStack", "no");
                    displayViewOther(3, bundle);
                } else {
                    removeAllStack();
                }
}
else if (v.getId() == R.id.relHome3Menu2) {
                changeColor(2);
                mTabCount = 2;
                updateAccessibilityOfTab(5);
                displayViewOther(29, bundle);
                // newTransactionCondition();
}
else if (v.getId() == R.id.relHome3Menu3) {
                changeColor(3);
                mTabCount = 3;
                updateAccessibilityOfTab(6);
                displayViewOther(19, bundle);
                // displayViewOther(79, new Bundle());
}
else if (v.getId() == R.id.relHome3Menu4) {
                changeColor(4);
                mTabCount = 4;
                updateAccessibilityOfTab(7);
                displayViewOther(6, bundle);
}
else if (v.getId() == R.id.relHome3Menu5) {
                changeColor(5);
                updateAccessibilityOfTab(8);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mTabCount == 1) {
                            changeColor(1);
                        } else if (mTabCount == 2) {
                            changeColor(2);
                        } else if (mTabCount == 3) {
                            changeColor(3);
                        } else if (mTabCount == 4) {
                            changeColor(4);
                        }
                    }
                }, 1000);


                if (!bottomSheetFragment.isVisible() && !bottomSheetFragment.isAdded())
                    bottomSheetFragment.show(getSupportFragmentManager(), bottomSheetFragment.getTag());
}
else {
}
    }

    private void newTransactionCondition() {
        Intent intent = null;
        Bundle bundle;

        String exchange = Utils.getSelectedExchange(mSession);
        switch (exchange) {
            case "0":
                Toast.makeText(this, R.string.profile_creation_not_allowed_please_contact_administrator, Toast.LENGTH_SHORT).show();
                break;
            case "1":
                if (mSession.getLead().equalsIgnoreCase("1")) {
                    callClientInfoApi(true, false);
                } else {
                    bundle = new Bundle();
                    intent = new Intent(ClientActivity.this, NseProfileActivity.class);
                    bundle.putString("type", "investmentProfile");
                    bundle.putString("transactionRoute", "clientHome");
                    intent.putExtras(bundle);
                    startActivity(intent);
                }

                break;
            case "2":
                if (mSession.getLead().equalsIgnoreCase("1")) {
                    callClientInfoApi(true, false);
                } else {
                    bundle = new Bundle();
                    intent = new Intent(ClientActivity.this, BseProfileActivity.class);
                    bundle.putString("type", "investmentProfile");
                    bundle.putString("transactionRoute", "clientHome");
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
                break;
            case "3":
                if (mSession.getLead().equalsIgnoreCase("1")) {
                    callClientInfoApi(true, false);
                } else {
                    bundle = new Bundle();
                    intent = new Intent(ClientActivity.this, MfuProfileActivity.class);
                    bundle.putString("type", "investmentProfile");
                    bundle.putString("mfutransactionRoute", "clientHome");
                    intent.putExtras(bundle);
                    startActivity(intent);

                }

                break;
        }
    }

    public void displayViewOther(int position, Bundle bundle) {
        Fragment fragment = null;
        if (position ==81){
            mCvTabBarBottom.setVisibility(View.VISIBLE);
        }else{
            mCvTabBarBottom.setVisibility(View.GONE);
        }
        switch (position) {
            case 1:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                    fragment = new FragHomeBrokerV4();
                    fragment.setArguments(bundle);
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                    fragment = new FragHomeBrokerV2();
                    fragment.setArguments(bundle);
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                    if (!mSession.getHasLoging()) {
                        fragment = new FragHome3WithoutLogin();
                        fragment.setArguments(bundle);
                    } else {
                        fragment = new FragHomeBroker();
                        fragment.setArguments(bundle);
                    }
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    if (!mSession.getHasLoging()) {
                        fragment = new FragHome6WithoutLogin();
                        fragment.setArguments(bundle);
                    } else {
                        fragment = new FragHomeBroker();
                    }
                    fragment.setArguments(bundle);
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                    fragment = new FragHomeBrokerV5();
                    fragment.setArguments(bundle);
                } else {
                    fragment = new FragHomeBroker();
                    fragment.setArguments(bundle);
                }
                break;

            case 2:
              /*  mCvTabBarBottom.setVisibility(View.GONE);
                fragment = new FragClientSearch();
                fragment.setArguments(bundle);*/
                break;

            case 3:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                    fragment = new FragHomeClient4();
                    fragment.setArguments(bundle);
                }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                    fragment = new FragHomeClient2();
                    fragment.setArguments(bundle);
                } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                    changeColor(1);
                    mTabCount = 1;
                    fragment = new FragHomeClient3();
                    fragment.setArguments(bundle);
                } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    fragment = new FragHomeClient6();
                    fragment.setArguments(bundle);
                }else if (!mSession.getAppConfig().isEmpty() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                    changeColor(1);
                    mTabCount = 1;
                    fragment = new FragHomeClient5();
                    fragment.setArguments(bundle);
                } else {
                    fragment = new FragHomeClient();
                    fragment.setArguments(bundle);
                }

                break;

          /*  case 4:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                fragment = new Portfolio();
                fragment.setArguments(bundle);
                break;*/

            case 4:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                fragment = new FragPortfolioHome();
                fragment.setArguments(bundle);
                break;

            case 5:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                fragment = new Portfolio_Detail();
                fragment.setArguments(bundle);
                break;

            case 6:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                fragment = new FragTransactionHome();
                fragment.setArguments(bundle);
                break;

            case 7:
                fragment = new PortfolioSchemeDetail();
                fragment.setArguments(bundle);
                break;

            case 8:
                fragment = new FragAdditionalPurchaseBse();
                fragment.setArguments(bundle);
                break;


            case 9:
                fragment = new FragAdditionalSipBse();
                fragment.setArguments(bundle);
                break;

            case 10:
                fragment = new FragSwitchNseBseMfu();
                fragment.setArguments(bundle);
                break;

            case 11:
                fragment = new FragSwpNseBse();
                fragment.setArguments(bundle);
                break;

            case 12:
                fragment = new FragStpBseMfu();
                fragment.setArguments(bundle);
                break;

            case 13:
                fragment = new FragRedeemNseBseMfu();
                fragment.setArguments(bundle);
                break;

            case 14:
                fragment = new FragFolioLookup();
                fragment.setArguments(bundle);
                break;

            case 15:
                fragment = new FragFolioLookupDetails();
                fragment.setArguments(bundle);
                break;

            case 16:
                fragment = new Frag_SOA();
                fragment.setArguments(bundle);
                break;

            case 17:
                fragment = new FragCapitalGainHome();
                fragment.setArguments(bundle);
                break;

            case 18:
                fragment = new FragPortfolioShareDetails();
                fragment.setArguments(bundle);
                break;

            case 19:
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                fragment = new FragPtSummaryHome();
                fragment.setArguments(bundle);
                break;

            case 20:
                fragment = new FragCapitalGainUnrealized();
                fragment.setArguments(bundle);
                break;

            case 21:
                fragment = new FragInsuranceHome();
                fragment.setArguments(bundle);
                break;


            case 24:
                fragment = new FragAumReport();
                fragment.setArguments(bundle);
                break;

            case 25:
                fragment = new FragAumReportByScheme();
                fragment.setArguments(bundle);
                break;

            case 26:
                fragment = new FragAumReportByUser();
                fragment.setArguments(bundle);
                break;


            case 27:
                fragment = new FragAdditionalPurchaseNse();
                fragment.setArguments(bundle);
                break;

            case 28:
                fragment = new FragAdditionalSipNse();
                fragment.setArguments(bundle);
                break;

            case 29:
                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    mCvTabBarBottom.setVisibility(View.GONE);
                }else{
                    mCvTabBarBottom.setVisibility(View.VISIBLE);
                }
                fragment = new FragAllInvestHome3();
                fragment.setArguments(bundle);
                break;

            case 30:
                fragment = new FragInvestInExistingPortfolio();
                fragment.setArguments(bundle);
                break;

            case 31:
                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    fragment = new FragPtSummarySchemeDetailsLayout6();
                }else{
                    fragment = new FragPtSummarySchemeDetails();

                }
                fragment.setArguments(bundle);
                break;

            case 32:
                //fragment = new FragPtSummaryMutualFund2();
                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    fragment = new FragPtSummaryMutualFundSingleLayout6();
                }else{
                    fragment = new FragPtSummaryMutualFundSingle();

                }
                fragment.setArguments(bundle);
                break;

            case 33:
                fragment = new FragOutStandingUnitDetails();
                fragment.setArguments(bundle);
                break;

            case 34:
                fragment = new FragIinByFolio();
                fragment.setArguments(bundle);
                break;

            case 35:
               /* fragment = new FragMyOrders();
                fragment.setArguments(bundle);*/
                String selectedExchange = Utils.getSelectedExchange(mSession);
                if (selectedExchange.equals("1")) {
                    fragment = new FragOrderDash();
                    fragment.setArguments(bundle);
                } else if (selectedExchange.equals("2")) {
                    fragment = new FragOrderDash();
                    fragment.setArguments(bundle);
                } else if (selectedExchange.equals("3")) {
                    fragment = new FragMyOrders();
                } else if (selectedExchange.equals("4")) {
                    fragment = new FragOrdersBse();
                } else {
                    fragment = new FragBrokerOrderHome();
                    fragment.setArguments(bundle);
                }
                break;

            case 36:
//                fragment = new FragMySipHome();
                fragment = new FragSipMainContainer();
                fragment.setArguments(bundle);
                break;

            case 37:

                break;

            case 38:
                fragment = new FragOrderStatusNseBse();
                fragment.setArguments(bundle);
                break;

            case 39:
                JSONObject mAppJSONObject = new JSONObject();
                String mContactThemeType = "v2";
                if (!TextUtils.isEmpty(mSession.getAppInfo())) {
                    try {
                        mAppJSONObject = new JSONObject(mSession.getAppInfo());
                    } catch (Exception ignored) {

                    }
                }
                if (mAppJSONObject.has("contacttheme")) {
                    String contactThemeType = mAppJSONObject.optString("contacttheme");
                    if (contactThemeType == "null" || contactThemeType.isEmpty()) {
                        mContactThemeType = "v2";
                    } else if (contactThemeType.equals("1")) {
                        mContactThemeType = "v1";
                    } else if (contactThemeType.equals("2")) {
                        mContactThemeType = "v2";
                    } else {
                        mContactThemeType = "v2";
                    }
                }
                if (mContactThemeType.equals("v2")){
                    fragment = new ContactFragmentV2();
                    fragment.setArguments(bundle);
                }else{
                    fragment = new HelpHostFragment();
                    fragment.setArguments(bundle);
                }

                break;
            case 40:
                fragment = new ContactFragment();
                fragment.setArguments(bundle);
                break;
            case 41:
                fragment = new FaqFragment();
                fragment.setArguments(bundle);
                break;
            case 42:
                fragment = new MoreFragment();
                fragment.setArguments(bundle);
                break;

            case 43:
                fragment = new FragAdditionalPurchaseMfu();
                fragment.setArguments(bundle);
                break;

            case 44:
                fragment = new FragAdditionalSipMfu();
                fragment.setArguments(bundle);
                break;

            case 45:

                break;

            case 46:
                fragment = new FragNotification();
                fragment.setArguments(bundle);
                break;

            case 47:
                fragment = new FragPtSummaryShareBonds2();
                fragment.setArguments(bundle);
                break;

            case 48:
                fragment = new FragPtSummaryShareBonds3();
                fragment.setArguments(bundle);
                break;

            case 49:
                fragment = new FragGoalList();
//                fragment = new FragGoalPlanning();
                fragment.setArguments(bundle);
                break;


            case 62:
                fragment = new FragProfileSettings();
                fragment.setArguments(bundle);
                break;

            case 63:
                fragment = new Help_Frag();
                fragment.setArguments(bundle);
                break;

            case 64:
                fragment = new FragChangeAppSecurity();
                fragment.setArguments(bundle);
                break;

            case 65:
                fragment = new FragClientProfile();
                fragment.setArguments(bundle);
                break;
            /*case 65:
                fragment = new NfoSchemesFragment();
                fragment.setArguments(bundle);
                break;
            case 66:
                fragment = new ChooseNfoNseProfileFragment();
                fragment.setArguments(bundle);
                break;
            case 67:
                fragment = new ChooseNfoBseProfileFragment();
                fragment.setArguments(bundle);
                break;
            case 68:
                fragment = new NfoBseTransactionFragment();
                fragment.setArguments(bundle);
                break;
                */


            case 70:
                fragment = new FragDividendReportFamily();
                fragment.setArguments(bundle);
                break;
            case 71:
                fragment = new FragDividendReport();
                fragment.setArguments(bundle);
                break;
            case 72:
                fragment = new FragDividendReportDetails();
                fragment.setArguments(bundle);
                break;

            case 73:
                fragment = new FragELSS1User();
                fragment.setArguments(bundle);
                break;

            case 74:
                fragment = new FragELSS2Scheme();
                fragment.setArguments(bundle);
                break;

            case 75:
                fragment = new FragELSS3Trans();
                fragment.setArguments(bundle);
                break;

            case 76:
                fragment = new ExchangeForAdditionalPurchase();
                fragment.setArguments(bundle);
                break;

            case 77:

                break;

            case 78:
                fragment = new FragMySipDetail();
                fragment.setArguments(bundle);
                break;

            case 79:
                fragment = new FragDocumentFolders();
                fragment.setArguments(bundle);
                break;

            case 80:
                fragment = new FragDocumentFilesList();
                fragment.setArguments(bundle);
                break;

            case 81:
                setVoltAuth();
                break;

            case 82:
                fragment = new FragMyJouneySoFar();
                fragment.setArguments(bundle);
                break;

            case 83:
                fragment = new FragAddNewGoals();
                fragment.setArguments(bundle);
                break;

            case 84:
                fragment = new FragGoalForm();
                fragment.setArguments(bundle);
                break;

            case 85:
                fragment = new FragUpdateGoal();
                fragment.setArguments(bundle);
                break;

            case 86:
                fragment = new FragSwpNse();
                fragment.setArguments(bundle);
                break;

            case 87:
                fragment = new FragStpNse();
                fragment.setArguments(bundle);
                break;
            case 88:
                fragment = new FragCommonCheckKycPan();
                fragment.setArguments(bundle);
                break;


            case 89:
                fragment = new TransferHoldingInfo();
                fragment.setArguments(bundle);
                break;

            case 90:
                fragment = new FragAmcFinder();
                fragment.setArguments(bundle);
                break;

            case 91:
                fragment = new AmcScheme();
                fragment.setArguments(bundle);
                break;

            case 92:
                fragment = new FragCasImportMain();
                fragment.setArguments(bundle);
                break;

            case 93:
                fragment = new FragCasOTPAuthenticate();
                fragment.setArguments(bundle);
                break;

            case 94:
                fragment = new FragAddTxnShareAndBond();
                fragment.setArguments(bundle);
                break;

            case 95:
                fragment = new FragAddTxnFD();
                fragment.setArguments(bundle);
                break;

            case 96:
                fragment = new FragScheduleSipDetails();
                fragment.setArguments(bundle);
                break;

            case 97:
                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
                    fragment = new FragPtSummaryFDLayout6();
                }else{
                    fragment = new FragPtSummaryFD();
                }

                fragment.setArguments(bundle);
                break;


            case 98:
                fragment = new FragMyOrders();
                fragment.setArguments(bundle);
                break;

            case 99:
                fragment = new FragLatestNav();
                fragment.setArguments(bundle);
                break;

            case 100:
                fragment = new FragShareFolioLookupDetails();
                fragment.setArguments(bundle);
                break;
        }

        if (fragment != null) {

            if (bundle != null && bundle.containsKey("isAnimation")) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction().addToBackStack(null);
                transaction.setCustomAnimations(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left, R.anim.anim_slide_in_righ, R.anim.anim_slide_out_right);
                transaction.replace(R.id.content_frame, fragment);
                transaction.commit();
            } else {
                if (bundle != null && bundle.containsKey("isAddBackToStack")) {
                    String layout = appConfigObject.optString("layout");
                    System.out.println(layout);
                    if (position == 3) {
                        if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                            FragmentManager fragManager = getSupportFragmentManager();
                            Fragment frag = fragManager.findFragmentByTag("home");
                            if (frag == null) {
                                frag = new FragHomeClient4();
                            }
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, frag, "home").commit();
                        }else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2"))) {
                            FragmentManager fragManager = getSupportFragmentManager();
                            Fragment frag = fragManager.findFragmentByTag("home");
                            if (frag == null) {
                                frag = new FragHomeClient2();
                            }
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, frag, "home").commit();
                        } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                            FragmentManager fragManager = getSupportFragmentManager();
                            Fragment frag = fragManager.findFragmentByTag("home");
                            if (frag == null) {
                                frag = new FragHomeClient3();
                            }
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, frag, "home").commit();
                        }else if (!mSession.getAppConfig().isEmpty() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                            FragmentManager fragManager = getSupportFragmentManager();
                            Fragment frag = fragManager.findFragmentByTag("home");
                            if (frag == null) {
                                frag = new FragHomeClient5();
                            }
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, frag, "home").commit();
                        }else if (layout.equalsIgnoreCase("6")) {
                            FragmentManager fragManager = getSupportFragmentManager();
                            Fragment frag = fragManager.findFragmentByTag("home");
                            if (frag == null) {
                                frag = new FragHomeClient6();
                            }
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, frag, "home").commit();
                        } else {
                            FragmentManager fragManager = getSupportFragmentManager();
                            Fragment frag = fragManager.findFragmentByTag("home");
                            if (frag == null) {
                                frag = new FragHomeClient();
                            }
                            FragmentManager fragmentManager = getSupportFragmentManager();
                            fragmentManager.beginTransaction().replace(R.id.content_frame, frag, "home").commit();
                        }

                    } else {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
                    }
                } else {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    int count = getSupportFragmentManager().getBackStackEntryCount();
                    fragmentManager.beginTransaction().addToBackStack(null).replace(R.id.content_frame, fragment, "" + count).commit();
                }
            }
        }
    }



    private void callLoanAgainst() {
        int primaryColor = ContextCompat.getColor(this, R.color.primaryToGreenPrimary);
        String primaryHexColor = Integer.toHexString(primaryColor).substring(2);
        int secondryColor = ContextCompat.getColor(this, R.color.backgroundColor);
        String secondryHexColor = Integer.toHexString(secondryColor).substring(2);
        long tsLong = System.currentTimeMillis();
        mSession.setLocalTimeInMillis(String.valueOf(tsLong));

        int textColor = ContextCompat.getColor(this, R.color.colorToolbarText);
        String textHexColor = Integer.toHexString(textColor).substring(2);
        voltSDKInstance = new VoltSDKContainer(
                ClientActivity.this,
                "SDK_INVESTWELL",
                mSession.getVoltAuthToken(),
                "production",
                primaryHexColor,
                textHexColor,
                "",
                "",
                mSession.getVoltPartnerCode(),
                "Yes",
                secondryHexColor,
                onVoltSDKExit -> {
                    logD("DefaultExit");
                    return Unit.INSTANCE;
                }
        );

    }

    private void setVoltAuth() {
        final ProgressDialog mBar = ProgressDialog.show(ClientActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        String url = Config.VOLT_AUTH;
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("app_key", Config.VOLT_APP_KEY_PRODUCTION);
            jsonObject.put("app_secret", Config.VOLT_APP_SECRET_PRODUCTION);
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, jsonObject, response -> {
            if (!ClientActivity.this.isFinishing() && mBar.isShowing()) mBar.dismiss();
            try {
                JSONObject mJSONOBJECT = new JSONObject(response.toString());
                String statusCode = mJSONOBJECT.optString("statusCode");
                String message = mJSONOBJECT.optString("message");
                if (statusCode.equalsIgnoreCase("400")){
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                }else {
                    mSession.setVoltAuthToken(mJSONOBJECT.optString("auth_token"));
                    callLoanAgainst();
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }, error -> {
            if (!ClientActivity.this.isFinishing() && mBar.isShowing()) mBar.dismiss();
            if (error.networkResponse != null && error.networkResponse.data != null) {
                String message = "";
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 400) {
                    message = getString(R.string.incorrect_username_or_password);
                } else if (statusCode == 500) {
                    message = getString(R.string.something_went_wrong_please_try_again);
                }
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, getString(R.string.txt_something_is_getting_wrong), Toast.LENGTH_SHORT).show();
            }

        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
//                return super.getHeaders();
                HashMap<String, String> headers = new HashMap<>();
                headers.put("X-AppPlatform", "SDK_INVESTWELL");
                headers.put("accept", "application/json");
                headers.put("Content-Type", "application/json");
                headers.put("requestReferenceId", timeIntervalSince1970());
                return headers;
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);

    }


    private String timeIntervalSince1970() {
        long timeInMilisecond = Calendar.getInstance(TimeZone.getTimeZone("UTC")).getTimeInMillis() * 1000;
        return String.valueOf(timeInMilisecond);
    }

    public void displayViewCalculator(int position, Bundle bundle) {
        Fragment fragment = null;
        switch (position) {

            case 1:
                fragment = new FragSipCalculator();
                fragment.setArguments(bundle);
                break;

            case 3:
                fragment = new FragSipStepup();
                fragment.setArguments(bundle);
                break;

            case 4:
                fragment = new FragEmiCalculator();
                fragment.setArguments(bundle);
                break;

            case 5:
                fragment = new FragSipDelayCost();
                fragment.setArguments(bundle);
                break;

            case 6:
                fragment = new FragRetirmentCalculator();
                fragment.setArguments(bundle);
                break;

            case 7:
                fragment = new FragEducationCalculator();
                fragment.setArguments(bundle);
                break;

            case 8:
                fragment = new FragMarriegeCalculator();
                fragment.setArguments(bundle);
                break;

            case 9:
                fragment = new FragTaxInvestmentCal();
                fragment.setArguments(bundle);
                break;

            case 10:
                fragment = new FragLumsumCal();
                fragment.setArguments(bundle);
                break;


        }
        FragmentManager fragmentManager = getSupportFragmentManager();
        if (position == 0) {
            fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
        } else {
            fragmentManager.beginTransaction().addToBackStack(null).replace(R.id.content_frame, fragment).commit();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent result) {
        super.onActivityResult(requestCode, resultCode, result);
        if (requestCode == REQUEST_APP_UPDATE) {
            if (resultCode == RESULT_OK) {
                startActivity(new Intent(getBaseContext(), SplashActivity.class));
            }
        } else if (resultCode == 100) {
            if (mSession.getAppType().equals("N")) {
                String isSingUploaded = result.getStringExtra("signUploaded");
                String ucc_code = result.getStringExtra("ucc_code");
                Bundle bundle = new Bundle();
                bundle.putString("ucc_code", ucc_code);
                if (isSingUploaded.equals("yes")) {
                    displayViewOther(10, bundle);
                }
            } else {
                String isSingUploaded = result.getStringExtra("signUploaded");
                if (isSingUploaded.equals("yes")) {
                    displayViewOther(11, new Bundle());
                }
            }
        } else if (resultCode == 500) {//ClientG Client
            if ((mSession.getHasLoging() && mSession.getLoginType().equals("ClientG")) || mSession.getHasLoging() && mSession.getLoginType().equals("Client")) {
                removeAllStack();
                mBundle.putString("isAddBackToStack", "no");
                displayViewOther(3, mBundle);
                // displayViewOther(15, null);
            } else if ((mSession.getHasLoging() && mSession.getLoginType().equals("SubBroker")) || mSession.getHasLoging() && mSession.getLoginType().equals("RM") || mSession.getHasLoging() && mSession.getLoginType().equals("Broker")) {
                removeAllStack();
                //displayViewOther(3, null);
                displayViewOther(26, null);

            } else {
                removeAllStack();
                // displayViewOther(3, null);
                displayViewOther(15, null);
            }
        }
        if (requestCode == 300) {
            CropImage.ActivityResult imageResult = CropImage.getActivityResult(result);
            try {
                Uri selectedImage = imageResult.getUri();
                if (selectedImage != null) {
                    Bitmap gallery_bit = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                    mSession.setImageRawData(selectedImage.getPath());
                    // if (gallery_bit != null)
                    //  mProfileImage.setImageBitmap(RoundedImageView.getCroppedBitmap(gallery_bit, 150));
                    //saveProfileAccount();
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }

        } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
            Toast.makeText(this, getString(R.string.txt_cropping_failed), Toast.LENGTH_LONG).show();
        }

        if (requestCode == RC_APP_UPDATE) {
            if (resultCode != RESULT_OK) {
                System.out.println("onActivityResult: app download failed");
            }
        }

        if (requestCode == imageCode) {
            if (resultCode == RESULT_OK) {
                Uri uri = result.getParcelableExtra("path");
                try {
                    // You can update this bitmap to your server
                    Bitmap galleryBit = MediaStore.Images.Media.getBitmap(ClientActivity.this.getContentResolver(), uri);
                    //  ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    //  galleryBit.compress(Bitmap.CompressFormat.JPEG, 30, baos);
                    if (bottomSheetFragment.mIvProfileImage !=null){
                        bottomSheetFragment.mIvProfileImage.setImageBitmap(RoundedImageView.getCroppedBitmap(galleryBit, 150));
                    }
                    uploadProfileBitmap(galleryBit);

                } catch (IOException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }

    }

    private void saveProfileAccount() {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.UPLOAD_PROFILE_PHOTO;
        VolleyMultipartRequest multipartRequest = new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                String resultResponse = new String(response.data);
                try {
                    JSONObject result = new JSONObject(resultResponse);
                    String status = result.getString("status");
                    String message = result.getString("message");
                    Log.d("Messsage", message);
                    System.out.println(message);
                 /*   if (status.equals(Constant.REQUEST_SUCCESS)) {
                        // tell everybody you have succed upload image and post strings
                        Log.d("Messsage", message);
                    } else {
                        Log.d("Unexpected", message);
                    }*/
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }, error -> {
            NetworkResponse networkResponse = error.networkResponse;
            String errorMessage = getString(R.string.txt_unknown_error);
            if (networkResponse == null) {
                if (error.getClass().equals(TimeoutError.class)) {
                    errorMessage = getString(R.string.txt_request_timeout);
                } else if (error.getClass().equals(NoConnectionError.class)) {
                    errorMessage = getString(R.string.txt_failed_to_connect_server);
                }
            } else {
                String result = new String(networkResponse.data);
                try {
                    JSONObject response = new JSONObject(result);
                    String status = response.getString("status");
                    String message = response.getString("message");

                    Log.d("Error Status", status);
                    Log.d("Error Message", message);

                    if (networkResponse.statusCode == 404) {
                        errorMessage = getString(R.string.txt_resource_not_found);
                    } else if (networkResponse.statusCode == 401) {
                        errorMessage = message + getString(R.string.txt_please_login_again);
                    } else if (networkResponse.statusCode == 400) {
                        errorMessage = message + getString(R.string.txt_check_your_inputs);
                    } else if (networkResponse.statusCode == 500) {
                        errorMessage = message + getString(R.string.txt_something_is_getting_wrong);
                    }
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
            Log.d("Error", errorMessage);
            UtilityKotlin.parseVolleyError(error, mSession, getApplicationContext(), "");

        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("fileHandle", "1");
                params.put("uid", mSession.getUid());
                params.put("fileKey", "profile");
                params.put("fileName", "download.png");
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                // params.put("file", new DataPart("file_avatar.jpg", AppHelper.getFileDataFromDrawable(getBaseContext(), mProfileImage.getDrawable()), "image/jpeg"));

                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<NetworkResponse> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }

        };

        VolleySingleton.getInstance(getBaseContext()).addToRequestQueue(multipartRequest);
    }


    public void removeAllStack() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.getBackStackEntryCount();
        for (int i = 0; i < fragmentManager.getBackStackEntryCount(); i++)
            fragmentManager.popBackStack();
    }

    /**
     * @implNote reviewAndRating() will call while review condition is meet
     * @see
     */

    public void reviewAndRating() {
        BottomSheetDialog bottomSheet = new BottomSheetDialog(this, R.style.Bottom_Sheet_Style);
        bottomSheet.setContentView(R.layout.layout_new_review);
        // init view
        ImageView mRLogo = bottomSheet.findViewById(R.id.ivLogo);
        ImageView mRClose = bottomSheet.findViewById(R.id.iv_close);
        ImageView ivDislike = bottomSheet.findViewById(R.id.ivDislike);
        ImageView ivLike = bottomSheet.findViewById(R.id.ivLike);
        LinearLayout ll_review_suggestion = bottomSheet.findViewById(R.id.ll_review_suggestion);
        LinearLayout ll_review_main = bottomSheet.findViewById(R.id.ll_review_main);
        // hide logo in-case of mint app
        if (getString(R.string.subdomain).equals("mint")) {
            mRLogo.setVisibility(View.GONE);
        } else {
            int squareLogo = UtilityKotlin.checkExistResources("app_logo_square", "mipmap", this);
            int circleLogo = UtilityKotlin.checkExistResources("app_logo_round", "mipmap", this);
            if (squareLogo != 0) {
                mRLogo.setImageResource(squareLogo);
            } else if (circleLogo != 0) {
                mRLogo.setImageResource(circleLogo);
            } else {
                mRLogo.setImageResource(R.mipmap.app_logo);
            }
        }
        Window window = getWindow();
        window.setBackgroundDrawableResource(android.R.color.transparent);
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.alpha = 1.0f;
        lp.dimAmount = 0.0f;
        window.setAttributes(lp);

        mRClose.setOnClickListener(view -> {
            bottomSheet.dismiss();
            resetReviewParameters();
        });

        ivDislike.setOnClickListener(view -> {
            ll_review_main.setVisibility(View.GONE);
            ll_review_suggestion.setVisibility(View.VISIBLE);
            mSession.setThumbsDownClicked(true);
            // Start 20-day new cycle
            mSession.setCountOfAppOpen(0);
            mSession.setActionCount(0);
        });
        ivLike.setOnClickListener(view -> {
//            mSession.setRatingSubmitted(true);
            bottomSheet.dismiss();
            reviewRequest();
        });
//        mSession.setHasFirstTimeReviewShown(true);

        bottomSheet.setCancelable(false);
        bottomSheet.show();
    }

    private void reviewRequest() {
        Task<ReviewInfo> request = reviewManager.requestReviewFlow();
        request.addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                reviewInfo = task.getResult();
                Task<Void> flow =
                        reviewManager.launchReviewFlow(this, reviewInfo);
                flow.addOnCompleteListener(task2 -> {
                    // Google does not confirm actual submission.
                    // Once flow completes, consider review done.
                    mSession.setRatingSubmitted(true);
                    onReviewSubmitted();
                });
            } else {
                onReviewSubmissionFailed();
            }
        });
        request.addOnFailureListener(e -> onReviewSubmissionFailed());

    }
    /***
     *  Display the in-app review dialog
     *  get submitted and failed
     */
    private void onReviewSubmitted() {
        // Never show again
        resetReviewParameters();
    }

    private void onReviewSubmissionFailed() {
//        resetReviewParameters();
    }

    public void userDidAction(String currentScreenName) {
        mSession.setActionCount(mSession.getActionCount() + 1);
        whenToShowAppReview(currentScreenName);
    }

    /**
     * app open days should be be 8
     * number of days the app has been opened at least once
     * app is opened multiple times in a same day, the count will only be 1
     * <p>
     * Actions/ Screen Visits
     * If the user does any of the below,
     * Visits Portfolio Report Screen
     * Does a transaction from anywhere // + response success
     * an action is considered. The action count should be 10
     * Rating should be shown in their respective homescreens / elegible
     * homescreens(Client,Sub broker,broker etc)
     * <p>
     * Rating Case
     * Rating Submitted
     * If the user submits a rating in , then the rating should not be shown to the user again.
     * Thumbs down Clicked
     * For such users, show the rating screen again after 20 app open days and continue the rating screen cycle.
     * Reset
     * For all other cases, reset the eligibility parameters and continue the rating screen cycle
     * <p>
     * close tab reset
     * don't show logo while mint app.
     *
     * @param screen contains screen name where in-app review will call
     */

    private void whenToShowAppReview(String screen) {
        if (screen == null || screen.isEmpty()) return;

        //  Never show again if already submitted
        if (mSession.getRatingSubmitted()) {
            return;
        }
        int noOfAppOpen = mSession.getCountOfAppOpen();
        int actionCount = mSession.getActionCount();
        boolean thumbsDownClicked = mSession.getThumbsDownClicked();
        // Count app open only once per day
        String today = Utils.getTodayDateString();
        String lastShownDate = mSession.getShownDateOfReview();
        if (lastShownDate == null || !lastShownDate.equals(today)) {
            noOfAppOpen++;
            mSession.setCountOfAppOpen(noOfAppOpen);
            mSession.setShownDateOfReview(today);
        }
        //  Thumbs down case → show after 20 open days
        if (thumbsDownClicked) {
            if (noOfAppOpen >= 20) {
                isReleventScreen(screen);
            }
            return;
        }
        //  Normal case → 8 app open days + 10 actions
        if (noOfAppOpen >= 8 && actionCount >= 10) {
            isReleventScreen(screen);
        }

    }

    private void isReleventScreen(String screen) {
        // show only respective screens
        if (!screen.equalsIgnoreCase("")) {
            reviewAndRating();
//            resetReviewParameters();
        }
    }

    private void resetReviewParameters() {
        mSession.setCountOfAppOpen(0);
        mSession.setActionCount(0);
        mSession.setThumbsDownClicked(false);
        mSession.setAskMeLater(false);
        mSession.setShownDateOfReview(null);
    }

    private boolean isSameDay(Date d1, Date d2) {
        SimpleDateFormat sdf =
                new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
        return sdf.format(d1).equals(sdf.format(d2));
    }

    @Override
    public void requestNotificationPermission() {
        requestNotificationPermission(false);
    }

    public void requestNotificationPermission(boolean fromBanner) {
        permissionManager.requestPermission(fromBanner);
    }
    public boolean shouldShowNotification() {
        return permissionManager.shouldShowNotificationBanner();
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showCommonDailog(Context context, String title, String message) {
        mIsDailogIsShowing = true;
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.comom_dialog, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();


        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView tvMessage = dialogView.findViewById(R.id.tvMessage);
        MaterialButton tvOk = dialogView.findViewById(R.id.btDone);
        RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);

        tvTitle.setText(title);
        tvMessage.setText(message);
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        }
        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_background_inset));
            relSubMenu.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_header_background));
            GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
            drawable.setColor(ContextCompat.getColor(getApplicationContext(), R.color.filterToolbar));
        } else {
            relSubMenu.setBackgroundColor(ContextCompat.getColor(this, R.color.filterToolbar));
        }

        tvOk.setOnClickListener(v -> {
            alertDialog.dismiss();
            mIsDailogIsShowing = false;
        });
        alertDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                mIsDailogIsShowing = false;
            }
        });

        alertDialog.setCancelable(false);
        alertDialog.show();
    }

    public static String getRealPathFromUri(Context context, Uri contentUri) {
        Cursor cursor = null;
        try {
            String[] proj = {MediaStore.Images.Media.DATA};
            cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showCommonDownload(Context context, String title, String message,
                                   final String type, final File file, Uri uri) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.common_dailog3, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();

        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView tvMessage = dialogView.findViewById(R.id.heading);
        MaterialButton tvShare = dialogView.findViewById(R.id.tvShare);
        MaterialButton tvOpen = dialogView.findViewById(R.id.tvOpen);
        RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);
        tvTitle.setText(title);
        tvMessage.setText(message);

        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_background_inset));
            relSubMenu.setBackground(ContextCompat.getDrawable(this, R.drawable.dialog_header_background));
            GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
            drawable.setColor(ContextCompat.getColor(getApplicationContext(), R.color.filterToolbar));
        } else {
            relSubMenu.setBackgroundColor(ContextCompat.getColor(this, R.color.filterToolbar));
        }

        tvShare.setOnClickListener(v -> {
            alertDialog.dismiss();
            // Uri imageUri = Uri.parse(file.getAbsolutePath());
            Uri imageUri = null;
            if (uri != null && !uri.toString().equals("")) {
                imageUri = uri;
            } else {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                    imageUri = Uri.fromFile(file);
                } else {
                    imageUri = FileProvider.getUriForFile(getApplicationContext(), BuildConfig.LIBRARY_PACKAGE_NAME + ".fileprovider", file);
                }
            }

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/pdf");
            intent.putExtra(Intent.EXTRA_STREAM, imageUri);
            startActivity(Intent.createChooser(intent, "Share with"));
        });

        tvOpen.setOnClickListener(v -> {
            if (type.equals("pdf") || type.equals("xls") || type.equals("vnd.ms-excel") || type.equals("jpg") || type.equals("jpeg") || type.equals("png")) {
                Intent intentUrl = new Intent(Intent.ACTION_VIEW);
                if (uri != null && !uri.toString().equals("")) {
                    if (type.equals("jpg") || type.equals("jpeg") || type.equals("png")) {
                        intentUrl.setDataAndType(uri, "image/" + type);
                    } else {
                        intentUrl.setDataAndType(uri, "application/" + type);
                    }
                } else {
                    Uri contentUri = FileProvider.getUriForFile(getBaseContext(), BuildConfig.LIBRARY_PACKAGE_NAME + ".fileprovider", file);
                    if (type.equals("jpg") || type.equals("jpeg") || type.equals("png")) {
                        intentUrl.setDataAndType(contentUri, "image/" + type);
                    } else {
                        intentUrl.setDataAndType(contentUri, "application/" + type);
                    }
                }
                intentUrl.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intentUrl.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                try {
                    startActivity(intentUrl);
                } catch (ActivityNotFoundException e) {
                    if (type.equals("pdf"))
                        Toast.makeText(ClientActivity.this, getString(R.string.txt_no_pdf_viewer_installed), Toast.LENGTH_LONG).show();
                    else if (type.equals("vnd.ms-excel") || type.equals("xls"))
                        Toast.makeText(ClientActivity.this, getString(R.string.txt_no_xls_viewer_installed), Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(ClientActivity.this, getString(R.string.txt_no_image_viewer_installed), Toast.LENGTH_SHORT).show();
                }
            }
            alertDialog.dismiss();
        });

        //alertDialog.setCancelable(false);
        alertDialog.show();
    }


    public void convertIntoCurrencyFormat(String currency, EditText editText) {
        try {
            Format format = NumberFormat.getNumberInstance(new Locale("en", "IN"));
            String str = format.format(Double.parseDouble(currency));
            editText.setText(str);
            editText.setSelection(editText.getText().toString().length());
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    private void reDirectMethod(){
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
                // appConfigObject.put("layout", "3");
                if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                    llTabBarHome3.setVisibility(View.VISIBLE);
                    llTabBarHome1.setVisibility(View.GONE);
                    changeColor(1);
                    mTabCount = 1;
                } else {
                    llTabBarHome3.setVisibility(View.GONE);
                    llTabBarHome1.setVisibility(View.VISIBLE);
                }
            } else {
                appConfigObject = new JSONObject();
            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        Log.d("Ekta", "isFirstTimeLaunch: " + mSession.isFirstTimeLaunch());
        if (!mSession.isFirstTimeLaunch() && ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2")))) {
            Intent intent = new Intent(getApplicationContext(), SingleIntroActivity.class);
            startActivity(intent);
            finish();
        } else if (!mSession.isFirstTimeLaunch() && ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3")))) {
            Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
            startActivity(intent);
            finish();
        }else if (!mSession.isFirstTimeLaunch() && ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6")))) {
            Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
            startActivity(intent);
            finish();
        } else if (mBundleSaveInstance == null) {
            Bundle bundle = new Bundle();
            if (!mSession.getHasLoging()) {
                mCvTabBarBottom.setVisibility(View.GONE);
                bundle.putString("isAddBackToStack", "no");
                displayViewOther(1, bundle);
            } else {
                mCvTabBarBottom.setVisibility(View.VISIBLE);
                bundle.putString("isAddBackToStack", "no");
                displayViewOther(3, bundle);
            }

        }
        if (mCallCommingFrom.equalsIgnoreCase("notification")) {
            displayViewOther(46, null);
        }
    }


    private void getPublicInfo() {
        Log.d("getPublicInfo", "getPublicInfo: called on ClientActivty");
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_BROKER_PUBLIC_INFO + "brokerDomain=" + mSession.getUserBrokerDomain() + "&userBusinessCode=" + AppConstants.SUB_BROKER_BUSINESS_CODE;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_BROKER_PUBLIC_INFO);

                if (jsonObject.optInt("status") == 0) {
                    JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                    //jsonObject1.put("layout", "5");

                    if (jsonObject1 != null) {
                        mSession.setAppLogoName(jsonObject1.optString("logo"));
                        mSession.setShowBseAuthPopup("1".equals(jsonObject1.optString("showBseAuthPopup").trim()));

                        mSession.setPlayStoreLink(jsonObject1.optString("androidAppLink"));
                        mSession.setAppStoreLink(jsonObject1.optString("iosAppLink"));
                        mSession.setOnBoarding(jsonObject1.optInt("allowOnboarding"));
                        mSession.setAllowedMobileOTPLogin(jsonObject1.optInt("allowMobileOtpLogin"));
                        mSession.setFutureProjectionCalculator(jsonObject1.optInt("futureProjectionCalculator"));
                        mSession.setSIPCalculator(jsonObject1.optInt("SIPCalculator"));
                        mSession.setForceUpdate(jsonObject1.optInt("majorUpdate")==1);
                        mSession.setAllowedCrm(jsonObject1.optInt("allowCrm",0)==1);
                        mSession.setNfo(jsonObject1.optInt("NFO"));
                        mSession.setNfo(jsonObject1.optInt("NFO"));
                        mSession.setNfo(jsonObject1.optInt("NFO"));
                        mSession.setCompanyName(jsonObject1.optString("compName"));
                        mSession.setUserEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setVoltPartnerCode(jsonObject1.optString("voltPartnerCode").equalsIgnoreCase("null") ? "" : jsonObject1.optString("voltPartnerCode"));
/*
                                mSession.setEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
*/
                        mSession.setWebsite(jsonObject1.optString("website").equalsIgnoreCase("null") ? "" : jsonObject1.optString("website"));
                        mSession.setMobileNumber(jsonObject1.optString("mobileNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("mobileNo1"));
                        mSession.setTelNumber(jsonObject1.optString("telNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("telNo1"));
                        mSession.setIsRiskProfileMandatory(jsonObject1.optInt("isRiskProfileManadatory"));

                        String domain = jsonObject1.optString("domain");
                        if (!domain.equalsIgnoreCase("null") && !domain.isEmpty()){
                            mSession.setUserBrokerDomain(domain);
                        }

                        String address = "";
                        address = UtilityKotlin.checkAndGetCompanyAddress(appConfigObject);

                        mSession.setAddress(address);
                        mSession.setCustomURL(jsonObject1.getString("customURL").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customURL"));
                        setCustomLinksData(jsonObject1.getString("customLinks").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customLinks"));
                        String slogan = jsonObject1.optString("slogan");
                        if (!slogan.equalsIgnoreCase("null") && !slogan.isEmpty()){
                            mSession.setSloganOnLogo(slogan);
                        }
                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        if (jsonObject1.optString("showXIRR").equals("1")) {
                            mSession.setHasShowXirr(true);
                        } else {
                            mSession.setHasShowXirr(false);
                        }
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
                            jsonObject1.put("layout", 6);
                        }

                        mSession.setAppInfo("" + jsonObject1);
                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        reDirectMethod();

                    }

                }
            } catch (Exception e) {

            }
        }, volleyError -> {

        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderBeforeLogin(mSession);
            }
        };

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void setCustomLinksData(String data) {
        List<String> keywords = List.of("Policies & Agreements", "Grievance Redressal", "Legal & Regulatory");
        JSONArray jsonArray = null;
        ArrayList<JSONObject> jsonObjects = new ArrayList<>();
        try {
            if (data.length() !=0){
                jsonArray = new JSONArray(data);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String title = jsonObject.optString("title");
                    if (keywords.contains(title)) {
                        // matching keywords
                        jsonObjects.add(jsonObject);
                    }
                }
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }finally {
            mSession.setCustomLinksForContactUs(""+jsonObjects);
        }
    }



    public void showLogOutAlert() {
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    LogoutMethod();
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(
                this,
                getResources().getString(R.string.Confirm),
                getResources().getString(R.string.Are_you_sure_logout),
                getString(R.string.yes),
                getString(R.string.no),
                true,
                true
        );
    }


    private void LogoutMethod() {
        ProgressBarCommon.showDialog(this);
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.LOGOUT + "?selectedUser=" + Utils.getSelectedUserObject(mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                ProgressBarCommon.dismissDialog();
                //  mApplication.goToLogin("logout");
                mApplication.clearAllSession();
            }
        }, volleyError -> {
            ProgressBarCommon.dismissDialog();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");
        }) {

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderLoginLogout(mSession);
            }


        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    public String setUsername(String name) {
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(name);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        return capMatcher.appendTail(capBuffer).toString();
    }

    public void changeColor(int index) {
        Boolean isHome3 = false;
        Boolean isActiveInactiveBothDiffColor = false;
        if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
            mTvHome3Menu1.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvHome3Menu2.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvHome3Menu3.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvHome3Menu4.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvHome3Menu5.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            isHome3 = true;

            if (index == 1)
                mTvHome3Menu1.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 2)
                mTvHome3Menu2.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 3)
                mTvHome3Menu3.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 4)
                mTvHome3Menu4.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 5)
                mTvHome3Menu5.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
        } else {
            isHome3 = false;
            mTvMenu1.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvMenu2.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvMenu3.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvMenu4.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mTvMenu5.setTextColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));

            if (index == 1)
                mTvMenu1.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 2)
                mTvMenu2.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 3)
                mTvMenu3.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 4)
                mTvMenu4.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
            else if (index == 5)
                mTvMenu5.setTextColor(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor));
        }

        if (!mSession.getAppConfig().isEmpty() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
            if (Utils.getConfigData(mSession).has("FeatureList") && Objects.requireNonNull(Utils.getConfigData(mSession).optJSONArray("FeatureList")).length()>0){
                JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
                for (int i = 0; i <sectionJSONArray.length() ; i++) {
                    JSONObject jsonObject = sectionJSONArray.optJSONObject(i);
                    if (jsonObject.optString("FeatureName").equalsIgnoreCase("layout") && jsonObject.optString("AdditionalSetting").equalsIgnoreCase("2")){
                        isActiveInactiveBothDiffColor = true;
                    }
                }
            }
        }


        changeImageColor(index, isHome3, isActiveInactiveBothDiffColor);
    }

    // for Image color
    private void changeImageColor(int index, boolean isHome3, boolean isActiveInactiveBothDiffColor) {
        if (isHome3) {
            highlight(mIvHome3Menu1, R.mipmap.home3_menu1, false);
            highlight(mIvHome3Menu2, R.mipmap.home3_menu2, false);
            highlight(mIvHome3Menu3, R.mipmap.home3_menu3, false);
            highlight(mIvHome3Menu4, R.mipmap.home3_menu4, false);
            highlight(mIvHome3Menu5, R.mipmap.home3_menu5, false);

            mIvHome3Line1.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mIvHome3Line2.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mIvHome3Line3.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mIvHome3Line4.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));
            mIvHome3Line5.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarDefaultColor));

            if (index == 1) {
                mIvHome3Line1.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
                highlight(mIvHome3Menu1, R.mipmap.home3_menu1, true);
            } else if (index == 2) {
                mIvHome3Line2.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
                highlight(mIvHome3Menu2, R.mipmap.home3_menu2, true);
            } else if (index == 3) {
                mIvHome3Line3.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
                highlight(mIvHome3Menu3, R.mipmap.home3_menu3, true);
            } else if (index == 4) {
                mIvHome3Line4.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
                highlight(mIvHome3Menu4, R.mipmap.home3_menu4, true);
            } else if (index == 5) {
                mIvHome3Line5.setBackgroundColor(ContextCompat.getColor(this, R.color.bottomNavBarSelectedColor));
                highlight(mIvHome3Menu5, R.mipmap.home3_menu5, true);
            }
        }else if(isActiveInactiveBothDiffColor){
            setSameIcon(mIvMenu1, R.mipmap.home, false);
            setSameIcon(mIvMenu2, R.mipmap.portfolio, false);
            setSameIcon(mIvMenu3, R.mipmap.transaction, false);
            setSameIcon(mIvMenu4, R.mipmap.more, false);
            setSameIcon(mIvMenu5, R.mipmap.menu5, false);

            if (index == 1) setSameIcon(mIvMenu1, R.mipmap.home_active, true);
            else if (index == 2) setSameIcon(mIvMenu2, R.mipmap.portfolio_active, true);
            else if (index == 3) setSameIcon(mIvMenu3, R.mipmap.transaction_active, true);
            else if (index == 4) setSameIcon(mIvMenu4, R.mipmap.more_active, true);
            else if (index == 5) setSameIcon(mIvMenu5, R.mipmap.menu5, true);

        }else {
            highlight(mIvMenu1, R.mipmap.home, false);
            highlight(mIvMenu2, R.mipmap.portfolio, false);
            highlight(mIvMenu3, R.mipmap.transaction, false);
            highlight(mIvMenu4, R.mipmap.more, false);
            highlight(mIvMenu5, R.mipmap.menu5, false);

            if (index == 1) highlight(mIvMenu1, R.mipmap.home_active, true);
            else if (index == 2) highlight(mIvMenu2, R.mipmap.portfolio_active, true);
            else if (index == 3) highlight(mIvMenu3, R.mipmap.transaction_active, true);
            else if (index == 4) highlight(mIvMenu4, R.mipmap.more_active, true);
            else if (index == 5) highlight(mIvMenu5, R.mipmap.menu5, true);
        }

    }

    private void setSameIcon(ImageView iv, int drawableid, boolean enable){
        Drawable drawable = ContextCompat.getDrawable(ClientActivity.this, drawableid);
        iv.setImageDrawable(drawable);

    }

    void highlight(ImageView iv, int drawableid, boolean enable) {
        if (enable) {
            Drawable drawable = ContextCompat.getDrawable(ClientActivity.this, drawableid);
            if (!mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")) {
                drawable.setColorFilter(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarSelectedColor), PorterDuff.Mode.SRC_ATOP);
            }
            iv.setImageDrawable(drawable);

        } else {
            Drawable drawable = ContextCompat.getDrawable(ClientActivity.this, drawableid);
            if (!mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")) {
                drawable.setColorFilter(ContextCompat.getColor(ClientActivity.this, R.color.bottomNavBarDefaultColor), PorterDuff.Mode.SRC_ATOP);
            }
            iv.setImageDrawable(drawable);
        }
    }


    public void getClientBalSummery() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        ProgressBarCommon.showDialog(this);
        String url = "";

        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.BAL_SUMMERY + "currentPage=1&pageSize=100" +  "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "&levelNo=" + Utils.getSelectedLevelNo(mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception ignored) {

        }
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.BAL_SUMMERY);
            try {
                JSONObject jsonObject = null;
                jsonObject = new JSONObject(response);
                AppApplication.CLIENT_DASHBOARD_BAL_SUMMARY = response;
                if (jsonObject.optInt("status") == 0) {
                    JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                    if (jsonObjectMain.has("oneDayChange")) {
                        mAppplication.isDaysChange = true;
                    }
                }
            } catch (Exception e) {
            } finally {
                ProgressBarCommon.dismissDialog();
                Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
                if (fragment instanceof FragHomeClient4) {
                    ((FragHomeClient4) fragment).setLineGraph();
                    ((FragHomeClient4) fragment).setSummary();
                    ((FragHomeClient4) fragment).updateViewPagerView();
                }else if (fragment instanceof FragHomeClient2) {
                    ((FragHomeClient2) fragment).setLineGraph();
                    ((FragHomeClient2) fragment).setSummary();
                    ((FragHomeClient2) fragment).updateViewPagerView();
                } else if (fragment instanceof FragHomeClient) {
                    ((FragHomeClient) fragment).setSummary();
                    ((FragHomeClient) fragment).updateViewPagerView();
                } else if (fragment instanceof FragHomeClient3) {
                    ((FragHomeClient3) fragment).setSummary();
                    ((FragHomeClient3) fragment).updateViewPagerView();
                } else if (fragment instanceof FragHomeClient5) {
                    ((FragHomeClient5) fragment).updateApiData();
                }else if (fragment instanceof FragHomeClient6) {
                    ((FragHomeClient6) fragment).updateApiData();
                }
            }

        }, volleyError -> {
            ProgressBarCommon.dismissDialog();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, ClientActivity.this);
                return super.parseNetworkResponse(response);
            }


        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                try {
                    int statusCode = error.networkResponse.statusCode;
                    if (statusCode == 401) {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }
                } catch (Exception e) {

                }

            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public void showGainInfoDialog(String value) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this, R.style.CustomAlertDialog);

        builder.setMessage(value);
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        androidx.appcompat.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    /****************************************************
     * Method shows a common dialog throughout the app
     * @param title  specify the title
     * @param message specify the message
     *********************************************************/
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public void showCommonDialog(Context context, String title, String message) {
        if (getWindow() != null) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ClientActivity.this);
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View dialogView = inflater.inflate(R.layout.comom_dialog, null);
            dialogBuilder.setView(dialogView);
            final AlertDialog alertDialog = dialogBuilder.create();

            if (alertDialog != null && alertDialog.isShowing()) return;
            LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
            TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
            TextView tvMessage = dialogView.findViewById(R.id.tvMessage);

            tvTitle.setText(title);
            tvMessage.setText(message);

            Button tvOk = dialogView.findViewById(R.id.btDone);
            RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                Objects.requireNonNull(alertDialog.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }

            if (Build.VERSION.SDK_INT >= 21) {
                linerMain.setBackground(ContextCompat.getDrawable(ClientActivity.this, R.drawable.dialog_background_inset));
                relSubMenu.setBackground(ContextCompat.getDrawable(ClientActivity.this, R.drawable.dialog_header_background));
                GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
                drawable.setColor(ContextCompat.getColor(ClientActivity.this, R.color.gray));
            } else {
                relSubMenu.setBackgroundColor(ContextCompat.getColor(ClientActivity.this, R.color.gray));
            }


            tvOk.setOnClickListener(v -> alertDialog.dismiss());
            alertDialog.setOnDismissListener(dialogInterface -> {
            });

            alertDialog.setCancelable(false);
            alertDialog.show();

        }
    }


    public void callClientInfoApi(boolean isShowLoader, boolean isFromPleaseComplete ) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        if (isShowLoader) {
            ProgressBarCommon.showDialog(this);
        }

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CLIENT_INFO_API + "?investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        String finalUrl = url;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            if (isShowLoader) {
                ProgressBarCommon.dismissDialog();
            }

            JSONObject jsonObject = null;
            insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_CLIENT_INFO_API);

            try {
                jsonObject = new JSONObject(response);
                if (jsonObject.optInt("status") == 0) {
                    JSONObject resultData = jsonObject.optJSONObject("result");
                    if (resultData != null) {
                        AppApplication.sClientInfo = resultData;
                        mSession.setClientPhotoName(resultData.optString("profileImage"));
                        mSession.setAppId(resultData.optString("appid"));
                        mSession.setPAN(resultData.optString("pan"));
                        if (isShowLoader) {
                            mSession.setEmail(resultData.optString("email"));
                            try {
                                if (!TextUtils.isEmpty(resultData.optJSONObject("contactDetails").toString()) && !resultData.optJSONObject("contactDetails").toString().equalsIgnoreCase("null")) {
                                    mSession.setContactDetails(resultData.optJSONObject("contactDetails").toString());
                                }
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG) e.printStackTrace();
                            }

                            if(isFromPleaseComplete)
                                callGetOnboardingDetails();
                            else {
                                if (mSession.getExchangeNseBseMfu().equals("1")) {
                                    callAppIInApi(resultData.optString("appid"), resultData);
                                } else if (mSession.getExchangeNseBseMfu().equals("2")) {
                                    callBseAppUccApi(resultData.optString("appid"), resultData);
                                } else {
                                    callMfuCanApi(resultData.optString("appid"), resultData);
                                }
                            }
                            try {
                                if (!TextUtils.isEmpty(resultData.optJSONObject("contactDetails").toString()) && !resultData.optJSONObject("contactDetails").toString().equalsIgnoreCase("null")) {
                                    mSession.setContactDetails(resultData.optJSONObject("contactDetails").toString());
                                }
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG)
                                    e.printStackTrace();
                            }
                        } else {
                            Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
                            if (fragment instanceof FragClientProfile) {
                                ((FragClientProfile) fragment).updateClientData();
                            }

                        }
                    }

                } else {
                    Toast.makeText(ClientActivity.this, jsonObject.optString("message"), Toast.LENGTH_LONG).show();
                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }

        }, volleyError -> {
            if (isShowLoader) {
                ProgressBarCommon.dismissDialog();
            }
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }
    public void callGetOnboardingDetails(){
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_ONBOARDING_DETAILS + "?appid=" + mSession.getAppId()+"&selectedUser=" + Utils.getSelectedUserObject(mSession);
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        KtorCallBack mCallback = new KtorCallBack() {
            @Override
            public void onSuccess(String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if(jsonObject.optInt("status") == 0){
                        JSONObject resultData = jsonObject.optJSONObject("result");
                        if (resultData != null) {
                            String stepNo = resultData.optString("stepNo");
                            if(stepNo.equals("8")){
                                int exchange = resultData.optInt("exchange");
                                if (exchange ==4){
                                    String mID = resultData.optString("id");
                                    String mAppid = resultData.optString("appid");
                                    String mSource = resultData.optString("source");
                                    String mOpenableUrl = getNSE2ExchangeOnboardingStep(
                                            mSession,
                                            stepNo,
                                            "4",
                                            "client",
                                            mID,
                                            mAppid,
                                            Utils.getSelectedLevelNo(mSession),
                                            Utils.getSelectedUid(mSession),
                                            mSource
                                    );
                                    Intent intent = new Intent(ClientActivity.this, AppIntoMintWebPortalActivity.class);
                                    intent.putExtra("url",mOpenableUrl);
                                    intent.putExtra("title",getString(R.string.kyc_onboarding));
                                    intent.putExtra("comeFrom","onboard");
                                    startActivity(intent);

                                }else {
                                    openCompleteKycOnboardingForm(
                                            ClientActivity.this,
                                            mSession,
                                            String.valueOf(exchange),
                                            resultData.optString("id")
                                    );
                                }
                            }
                            else{
                                openNewKycOnboardingInWebView(
                                        ClientActivity.this,
                                        mSession,
                                        stepNo,
                                        "pleaseComplete",
                                        resultData.optString("id"));
                            }
                        }
                    }else {
                        showCommonDailog(ClientActivity.this,getString(R.string.alert),jsonObject.optString("message"));
                    }

                } catch (JSONException e) {
                }
            }

            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                if (isLoading){
                    ProgressBarCommon.showDialog(ClientActivity.this);
                }else {
                    ProgressBarCommon.dismissDialog();
                }
            }
        };

        KtorHelper.requestCall(this,mSession,url, ApiRequestType.GET,new JSONObject(), AppHeaderType.AFTER_LOGIN,mCallback);
    }

    //NSE API FOR IIN LIST
    public void callAppIInApi(String mAppId, final JSONObject mClientInfo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(ClientActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(mBar.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_IIN_BY_APP_ID_API + "?appid=" + mAppId + "&type=0" + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            mBar.dismiss();
            JSONObject jsonObject = null;
            insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_IIN_BY_APP_ID_API);

            try {
                jsonObject = new JSONObject(response);
                JSONArray resultData = jsonObject.optJSONArray("result");
                if (jsonObject.optInt("status") == 0) {
                    if (resultData != null && resultData.length() > 1) {
                        Intent intent = new Intent(ClientActivity.this, SelectOnBoardingUserActivity.class);
                        intent.putExtra("result", String.valueOf(jsonObject));
                        intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                        startActivity(intent);
                    } else {
                        if (mSession.getExchangeNseBseMfu().equals("1")) {
                            Intent intent = new Intent(this, BrokerNseOnBoardingActivity.class);
                            if (resultData != null && resultData.length() > 0) {
                                intent.putExtra("result", String.valueOf(resultData.opt(0)));
                            } else {
                                intent.putExtra("result", String.valueOf(mClientInfo));
                            }
                            intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                            intent.putExtra("route", "normal");
                            startActivity(intent);
                            // finish();
                        } else {
                            Intent intent = new Intent(ClientActivity.this, OnBoardingActivity.class);
                            if (resultData != null && resultData.length() > 0) {
                                intent.putExtra("result", String.valueOf(resultData.opt(0)));
                            } else {
                                intent.putExtra("result", String.valueOf(mClientInfo));
                            }
                            intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                            intent.putExtra("route", "normal");
                            startActivity(intent);
                        }

                    }

                } else {
                    Toast.makeText(ClientActivity.this, jsonObject.optString("message"), Toast.LENGTH_LONG).show();

                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }

        }, volleyError -> {
            if (!ClientActivity.this.isFinishing() && mBar != null && mBar.isShowing())
                mBar.dismiss();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    //BSE API FOR UCC LIST
    public void callBseAppUccApi(String mAppId, final JSONObject mClientInfo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(ClientActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(mBar.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.BSE_GET_UCC_BY_APP_ID_API + "?type=0" + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            mBar.dismiss();
            JSONObject jsonObject = null;
            insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.BSE_GET_UCC_BY_APP_ID_API);

            try {
                jsonObject = new JSONObject(response);
                JSONArray jsonArray = jsonObject.optJSONArray("result");
                if (jsonObject.optInt("status") == 0) {
                    if (jsonArray != null && jsonArray.length() > 1) {
                        Intent intent = new Intent(ClientActivity.this, SelectOnBoardingUserActivity.class);
                        intent.putExtra("result", String.valueOf(jsonObject));
                        intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(ClientActivity.this, OnBoardingActivity.class);
                        if (jsonArray != null && jsonArray.length() > 0) {
                            intent.putExtra("result", String.valueOf(jsonArray.opt(0)));
                        } else {
                            mClientInfo.remove("stepNo");
                            intent.putExtra("result", String.valueOf(mClientInfo));
                            intent.putExtra("bseID", false);
                        }
                        intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                        startActivity(intent);
                    }

                } else {
                    Toast.makeText(ClientActivity.this, jsonObject.optString("message"), Toast.LENGTH_LONG).show();

                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }

        }, volleyError -> {
            if (!ClientActivity.this.isFinishing() && mBar.isShowing()) mBar.dismiss();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    //MFU  API FOR CAN LIST
    public void callMfuCanApi(String mAppId, final JSONObject mClientInfo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, this)) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(ClientActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Objects.requireNonNull(mBar.getWindow()).setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.MFU_GET_CAN_BY_APP_ID_API + "?type=0" + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            mBar.dismiss();
            JSONObject jsonObject = null;
            try {
                jsonObject = new JSONObject(response);
                JSONArray resultData = jsonObject.optJSONArray("result");
                if (jsonObject.optInt("status") == 0) {
                    if (resultData != null && resultData.length() > 1) {
                        Intent intent = new Intent(ClientActivity.this, SelectOnBoardingUserActivity.class);
                        intent.putExtra("result", String.valueOf(jsonObject));
                        intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(ClientActivity.this, MfuOnboardingActivity.class);
                        if (resultData != null && resultData.length() > 0) {
                            intent.putExtra("result", String.valueOf(resultData.opt(0)));
                        } else {
                            mClientInfo.remove("stepNo");
                            intent.putExtra("result", String.valueOf(mClientInfo));
                        }
                        intent.putExtra("domain_name", mSession.getUserBrokerDomain());
                        startActivity(intent);
                    }

                } else {
                    Toast.makeText(ClientActivity.this, jsonObject.optString("message"), Toast.LENGTH_LONG).show();

                }
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }

        }, volleyError -> {
            if (!ClientActivity.this.isFinishing() && mBar.isShowing()) mBar.dismiss();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(ClientActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    // set profile image code
    public final void onImageUploadClickClick() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (this.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 22);
                return;
            }

        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (this.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
                        || this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 22);
                    return;
                }
            }
        }

        showImagePickerOptions();
    }


    public final void showImagePickerOptions() {
        ImagePickerActivity.showImagePickerOptions(ClientActivity.this, new ImagePickerActivity.PickerOptionListener() {
            public void onTakeCameraSelected() {
                launchCameraIntent();
            }

            public void onChooseGallerySelected() {
                launchGalleryIntent();
            }
        });
    }


    private void showSettingsDialogForImage() {


        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    openSettings();
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(
                this,
                getResources().getString(R.string.dialog_permission_title),
                getResources().getString(R.string.dialog_permission_message),
                getString(R.string.go_to_settings),
                getString(R.string.cancel),
                true,
                true
        );
    }

    private void openSettings() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", ClientActivity.this.getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, 101);
    }

    public final void launchCameraIntent() {
        Intent intent = new Intent(ClientActivity.this, ImagePickerActivity.class);
        intent.putExtra("image_picker_option", 0);
        intent.putExtra("lock_aspect_ratio", true);
        intent.putExtra("aspect_ratio_x", 1);
        intent.putExtra("aspect_ratio_Y", 1);
        intent.putExtra("set_bitmap_max_width_height", true);
        intent.putExtra("max_width", 1000);
        intent.putExtra("max_height", 1000);
        this.startActivityForResult(intent, imageCode);
    }

    public final void launchGalleryIntent() {
        Intent intent = new Intent(ClientActivity.this, ImagePickerActivity.class);
        intent.putExtra("image_picker_option", 1);
        intent.putExtra("lock_aspect_ratio", true);
        intent.putExtra("aspect_ratio_x", 1);
        intent.putExtra("aspect_ratio_Y", 1);
        this.startActivityForResult(intent, imageCode);
    }

    private final byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 50, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    public void uploadProfileBitmap(@NotNull final Bitmap bitmap) {
        final ProgressDialog mBar = ProgressDialog.show(ClientActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.UPLOAD_PROFILE_PHOTO;
        VolleyMultipartRequest volleyMultipartRequest = (new VolleyMultipartRequest(Request.Method.POST, url, new Response.Listener() {

            public void onResponse(Object var1) {
                this.onResponse((NetworkResponse) var1);
            }

            public void onResponse(@org.jetbrains.annotations.Nullable NetworkResponse it) {
                UtilityKotlin.setRefreshKey(mSession);
                try {
                    if (it != null) {
                        byte[] byteDate = it.data;
                        if (byteDate != null) {
                            String byteString = new String(byteDate, Charsets.UTF_8);
                            JSONObject jsonObject = new JSONObject(byteString);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                saveFileName(mBar, jsonObject1.optString("filename"));
                            } else {
                                mBar.dismiss();
                            }
                        }
                    }

                } catch (Exception e) {

                }

            }
        }, new Response.ErrorListener() {
            public void onErrorResponse(VolleyError volleyError) {
                if (!ClientActivity.this.isFinishing() && mBar != null && mBar.isShowing())
                    mBar.dismiss();
                UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");

            }
        }) {
            @NotNull
            protected Map getParams() throws AuthFailureError {
                HashMap<String, java.io.Serializable> params = new HashMap<String, java.io.Serializable>();
                params.put("fileHandle", "1");
                params.put("fileKey", "profile");
                params.put("fileType", "DOCUMENT");
                params.put("isExternal", "1");
                String uId = "";
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                } else {
                    uId = mSession.getUid();
                }
                params.put("uid", uId);
                Calendar calendar = Calendar.getInstance();
                params.put("fileName", calendar.getTimeInMillis() + ".png");
                // params.put("selectedUser", "" + Utils.getSelectedUserObject(mSession));

                return params;
            }

            @NotNull
            protected Map getByteData() {
                HashMap<String, DataPart> params = new HashMap<String, DataPart>();
                long imgName = System.currentTimeMillis();
                params.put("file", new DataPart(imgName + ".png", ClientActivity.this.getFileDataFromDrawable(bitmap)));
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<NetworkResponse> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }
        });
        volleyMultipartRequest.setRetryPolicy(new RetryPolicy() {
            public int getCurrentTimeout() {
                return 500000;
            }

            public int getCurrentRetryCount() {
                return 500000;
            }

            public void retry(@NotNull VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        Volley.newRequestQueue(this).add(volleyMultipartRequest);
    }

    private void saveFileName(ProgressDialog progressDialog, String fileName) {
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.UPLOAD_CLIENT_PROFILE_IMAGE;
        JSONObject objectMain = new JSONObject();

        try {
            String appId = "";
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                appId = UtilityKotlin.getClientHopObject(mSession).optString("appid");
            } else {
                appId = mSession.getAppId();
            }

            objectMain.put("profileImage", fileName);
            objectMain.put("appid", appId);
            String uId = "";
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
            } else {
                uId = mSession.getUid();
            }
            objectMain.put("uid", uId);
            objectMain.put("investorUid", uId);
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(url, objectMain.toString(), jsonObject.toString(), TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.UPLOAD_CLIENT_PROFILE_IMAGE);


                if (progressDialog != null) progressDialog.dismiss();
                try {
                    if (jsonObject.optInt("status") == 0) {
                        mSession.setClientPhotoName(fileName);
                        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);
                        if (fragment instanceof FragClientProfile) {
                            ((FragClientProfile) fragment).showProfileImage(true);
                        }

                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (progressDialog != null) progressDialog.dismiss();

                UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "ignore");

            }
        }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(ClientActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean isGranted = true;
        switch (requestCode) {
            case 22: {
                for (int i = 0; i < permissions.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    } else {
                        isGranted = false;
                        showSettingsDialogForImage();
                        break;
                    }
                }
                if (isGranted) {
                    showImagePickerOptions();
                }

            }

            break;
        }

        if (isGranted) {


        }
    }

    public void goToTransactionTab(Bundle bundle)
    {
        changeColor(3);
        mTabCount = 3;
        mApplication.isFromPtToAddTxn = true;
        displayViewOther(6, bundle);
    }

    public void bsePopUp(){

    }
}
