package investwell.client.fragments.folio;

import static android.os.Build.VERSION.SDK_INT;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.ExtensionsKt.getDate;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;
import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.larvalabs.svgandroid.SVG;
import com.larvalabs.svgandroid.SVGParser;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;


import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.SoaAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

;


public class Frag_SOA extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    TextView mTvUserName, mTvSchemeName, mTvNav, mTvMarketValue, mTvFolioe, mTvBalanceUnit, mTvDate;
    private RequestQueue requestQueue;
    private SoaAdapter mSoaAdapter;
    private String mFolioId = "", mSchemeId = "";
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mLinerMainActivity;
    private TextView mTvNothing;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private String mRta = "";
    private String mFileName = "";
    private RadioGroup radioGroup;

    private RelativeLayout mRelFilterMain;
    private LinearLayout mLinFilterPart, mLinerCustomDuration;
    private Animation slideUpAnimation, slideDownAnimation;
    private TextView mTvStartDate, mTvEndDate;
    private String mStartingDate = "", mEndDate = "", mSelectedTime = "";

    private String mCookiesAWSALBTG = "", mCookiesAWSALBTG3 = "", mCookiesAWSALBTG4 = "", mCookiesAWSALB = "";
    private String mResponseHeaderCookies = "", mFundsNetCookies = "", mFundsNetGuid = "", mFundsNetToken = "";
    SimpleDateFormat displayDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
    SimpleDateFormat apiDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private AlertDialog mFundsNetCaptchaDialog;

    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);
            mBrokerActivity.setMainVisibility(this, null);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
            mMainActivity.setMainVisibility(this, null);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {

            boolean isShowDownloadOption = false;
            if (mSession.getLoginType().equalsIgnoreCase("client")) {
                isShowDownloadOption = false;
            } else {
                if (mSession.getHasSoaDownloadEnable()) {
                    isShowDownloadOption = true;
                } else {
                    isShowDownloadOption = false;
                }
            }
            fragToolBar.setUpToolBar(getResources().getString(R.string.statement_of_account),
                    true, false, false, isShowDownloadOption, false, false, false);
            fragToolBar.setCallback(this);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_soa, container, false);
        setUpToolBar();
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }


        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mLinerMainActivity = view.findViewById(R.id.linerMain);
        mTvNothing = view.findViewById(R.id.tvErrorMessage);

        mTvUserName = view.findViewById(R.id.tvUserName);
        mTvSchemeName = view.findViewById(R.id.tvSchemeName);
        mTvNav = view.findViewById(R.id.tvNav);
        mTvMarketValue = view.findViewById(R.id.tvMarketValue);
        mTvFolioe = view.findViewById(R.id.tvFolio);
        mTvBalanceUnit = view.findViewById(R.id.tvBalanceUnit);
        mTvDate = view.findViewById(R.id.tvDate);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.rlSoa).setBackgroundResource(R.mipmap.card_blank);

        RecyclerView recycleView = view.findViewById(R.id.recycleView);
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("folioid")) {
            mFolioId = bundle.getString("folioid");
            mSchemeId = bundle.getString("schid");
        }

        recycleView.setHasFixedSize(true);
        recycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mSoaAdapter = new SoaAdapter(getActivity(), new ArrayList<JSONObject>(), new SoaAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    /*JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(15, bundle1);*/
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        recycleView.setAdapter(mSoaAdapter);

        //search
        mTvStartDate = view.findViewById(R.id.tvSTart);
        mTvEndDate = view.findViewById(R.id.tvEnd);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mLinerCustomDuration = view.findViewById(R.id.linerCustomDuration);
        slideUpAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up2);
        slideDownAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_down2);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);
        view.findViewById(R.id.tvSTart).setOnClickListener(this);
        view.findViewById(R.id.tvEnd).setOnClickListener(this);
        slideUpAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        radioGroup = view.findViewById(R.id.rdGroup);
        radioGroup.check(R.id.radio0);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int checkId) {
                mLinerCustomDuration.setVisibility(View.GONE);
                /*CF,PF,CU,SI*/
                if (checkId == R.id.radio0) {
                        mSelectedTime = "SI";
}
else if (checkId == R.id.radio1) {
                        mSelectedTime = "CF";
}
else if (checkId == R.id.radio2) {
                        mSelectedTime = "PF";
}
else if (checkId == R.id.radio3) {
                    mSelectedTime = "CU";
                    mLinerCustomDuration.setVisibility(View.VISIBLE);
                    String year2 = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
                    mStartingDate = year2 + "-01-01";
                    mEndDate = Utils.getTodayDateString2();

                    mTvStartDate.setText(getDate(mStartingDate,apiDateFormat,displayDateFormat,0,0,0));
                    mTvEndDate.setText(Utils.getTodayDateString());

                }


            }


        });

        getSOA(mFolioId);
        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideUpAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                mLinFilterPart.startAnimation(slideUpAnimation);
                if (mRta.equalsIgnoreCase("C")) {
                    if (mSession.getHasEdge360()) {
                        getCampsEdge360Captcha(mFolioId);
                    } else {
                       getFundsNetLoginCaptcha(mFolioId);
                    }
                } else if (mRta.equalsIgnoreCase("K")) {
                    getFileName();
                } else if (mRta.equalsIgnoreCase("F")) {
                    getFileName();
                }
}
else if (v.getId() == R.id.tvSTart) {
            showDatePickerDialog(
                    requireContext(),
                    this,
                    null,
                    mTvEndDate.getText().toString(),
                    mTvStartDate.getText().toString(),
                    displayDateFormat,
                    selectedDateFormatted -> {

                        try {
                            Date parsed = displayDateFormat.parse(selectedDateFormatted);
                            String apiDate = apiDateFormat.format(parsed);

                            mTvStartDate.setText(selectedDateFormatted);
                            mStartingDate = apiDate;

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        return null;
                    }
            );
}
else if (v.getId() == R.id.tvEnd) {
            showDatePickerDialog(
                    requireContext(),
                    this,
                    mTvStartDate.getText().toString(),
                    Utils.getTodayDateString(),
                    mTvEndDate.getText().toString(),
                    displayDateFormat,
                    selectedDateFormatted -> {

                        try {
                            Date parsed = displayDateFormat.parse(selectedDateFormatted);
                            String apiDate = apiDateFormat.format(parsed);

                            mTvEndDate.setText(selectedDateFormatted);
                            mEndDate = apiDate;
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        return null;
                    }
            );
}
    }
    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                mRelFilterMain.setVisibility(View.VISIBLE);
                mLinFilterPart.startAnimation(slideDownAnimation);
}


    }

    private void getSOA(String folioID) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = "";
        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_SOA_BROKER + "folioId=" + folioID + "&clubTxns=true";
            }else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_SOA + "folioId=" + folioID + "&clubTxns=true&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    mShimmerViewContainer.setVisibility(View.VISIBLE);
                    mShimmerViewContainer.startShimmer();
                    mLinerMainActivity.setVisibility(View.GONE);
                } else {
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.GONE);
                    mLinerMainActivity.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                ArrayList<JSONObject> list = new ArrayList<>();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {

                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        mRta = jsonObject1.optString("rta");
                        mSelectedTime = "SI";
                        JSONArray jsonArray = jsonObject1.getJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject data = jsonArray.optJSONObject(i);
                            list.add(data);
                        }
                        mSoaAdapter.updateList(list);

                        JSONObject jsonObjectInner = jsonObject1.getJSONObject("summary");
                        mTvSchemeName.setText(jsonObject1.optString("schemeName"));
                        mTvUserName.setText(jsonObject1.optString("applicantName"));
                        mTvFolioe.setText(jsonObject1.optString("folioNo"));
                        mTvNav.setText(jsonObjectInner.optString("nav") + " (" + Utils.formatedDateddMMMyyyy2(jsonObjectInner.optString("date")) + ")");

                        double longValue = jsonObjectInner.optDouble("units");
                        if (longValue > 0) {
                            String data1 = String.format("%.4f", longValue);
                            mTvBalanceUnit.setText(data1);
                        } else {
                            mTvBalanceUnit.setText("0");
                        }

                        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                        format.setMinimumFractionDigits(0);
                        format.setMaximumFractionDigits(0);

                        double currentValue = jsonObjectInner.optDouble("amount");
                        if (Double.isNaN(currentValue)) {
                            String strCurrentAmount = format.format(0);
                            mTvMarketValue.setText(strCurrentAmount);
                        } else {
                            String strCurrentAmount = format.format(currentValue);
                            mTvMarketValue.setText(strCurrentAmount);
                        }


                                // mTvDate.setText(getResources().getString(R.string.nav_as_on) + Utils.formatedDate2(jsonObjectInner.optString("date")));
                            } else if (jsonObject.optInt("status") == -1) {
                                AppApplication appApplication = (AppApplication) getActivity().getApplication();
                                appApplication.showCommonDailog(getActivity(), getString(R.string.failed), jsonObject.optString("message"), "message");
                            }

                } catch (Exception ignored) {

                } finally {
                    if (!list.isEmpty()) {
                        mTvNothing.setVisibility(View.GONE);
                    } else {
                        mTvNothing.setVisibility(View.VISIBLE);
                    }
                }
            }
        });
    }

    /**--------------------------EDGE 360 FLOW METHODS-------------------------------------**/
    private void getCampsEdge360Captcha(String folioID) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = "";

        try {

            String timePreviod = "";
            if (mSelectedTime.equalsIgnoreCase("CU")) {
                timePreviod = "&timePeriod=" + mSelectedTime + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate;
            } else {
                timePreviod = "&timePeriod=" + mSelectedTime;
            }

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CAMS_EDGE360_CAPTCHA
                        + "folioid=" + folioID + timePreviod + "&pageSize=100&currentPage=1" + "";

            }else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CAMS_EDGE360_CAPTCHA_CLIENT
                        + "folioid=" + folioID + timePreviod + "&pageSize=100&currentPage=1" +
                        "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, "", "", "", "", "", new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity());
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonCookies = jsonObject.optJSONObject("soaCookies");
                        if (jsonCookies != null) {
                            mCookiesAWSALBTG = jsonCookies.optString("AWSALBTG");
                            mCookiesAWSALB = jsonCookies.optString("AWSALB");
                            mCookiesAWSALBTG3 = jsonCookies.optString("AWSALBTGCORS");
                            mCookiesAWSALBTG4 = jsonCookies.optString("AWSALBCORS");
                        }

                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        showCamsEdge360Dailog(jsonObject1);
                    } else if (jsonObject.optInt("status") == -1) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public void showCamsEdge360Dailog(final JSONObject jsonObject) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_cams_captcha, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();

        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        Button btDone = dialogView.findViewById(R.id.btDone);
        final Button btCancel = dialogView.findViewById(R.id.btCancel);
        ImageView ivCaptcha = dialogView.findViewById(R.id.ivCaptcha);
        final TextInputEditText etCaptcha = dialogView.findViewById(R.id.etCaptcha);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.dialog_background_inset));
        }


        String svgStr = jsonObject.optString("captchaSVG");
        SVG svg = SVGParser.getSVGFromString(svgStr);
        ivCaptcha.setImageDrawable(svg.createPictureDrawable());


        btDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String captcha = etCaptcha.getText().toString();
                if (captcha.isEmpty()) {
                    Toast.makeText(getActivity(), getString(R.string.text_enter_captcha), Toast.LENGTH_SHORT).show();
                } else if (captcha.length() < 2) {
                    Toast.makeText(getActivity(), getString(R.string.text_enter_correct_captcha), Toast.LENGTH_SHORT).show();
                } else {
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm.isAcceptingText()) {
                        imm.hideSoftInputFromWindow(etCaptcha.getWindowToken(), 0);
                    }
                    validateEdge360Captcha(captcha, jsonObject.optString("sessionToken"), alertDialog);
                }


            }
        });

        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();

            }
        });

        alertDialog.setCancelable(false);
        alertDialog.show();
    }
    private void validateEdge360Captcha(String captchaText, String fundsNetToken, final AlertDialog alertDialog) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        String url = "";

        try {
            JSONObject jsonObject1 = new JSONObject();
            jsonObject1.put("uid", Utils.getSelectedUid(mSession));
            jsonObject1.put("levelNo", Utils.getSelectedLevelNo(mSession));

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.GET_FILE_NAME_VERYFY_CAPTCHA + "captcha=" + captchaText +
                        "&sessionToken=" + fundsNetToken + "&investorUid=" + Utils.getSelectedUid(mSession) + "";

            }else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.GET_FILE_NAME_VERYFY_CAPTCHA_CLIENT + "captcha=" + captchaText +
                        "&sessionToken=" + fundsNetToken + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "";

            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        } catch (Exception e) {

        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, mCookiesAWSALBTG, mCookiesAWSALB, mCookiesAWSALBTG3, mCookiesAWSALBTG4, "soa2", new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_we_are_verifying_captcha));
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        alertDialog.dismiss();
                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        mFileName = jsonObject1.optString("fileName");
                        if (!mFileName.isEmpty())
                            downloadFile();
                    } else if (jsonObject.optInt("status") == -1) {
                        ProgressBarCommon.dismissDialog();
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }

                } catch (Exception ignored) {

                }
            }

            @Override
            public void onError(String errorMessage, int statusCode) {
                KtorCallBack.super.onError(errorMessage, statusCode);
                ProgressBarCommon.dismissDialog();
                if (!errorMessage.contains("Invalid Captcha")){
                    alertDialog.dismiss();
                }

            }
        });

    }

    /**--------------------------FUNDS NET FLOW METHODS-------------------------------------**/
    private void getFundsNetLoginCaptcha(String folioID) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        String url = "";
        String timePeriod;
        if (mSelectedTime.equalsIgnoreCase("CU")) {
            if (mStartingDate.isEmpty() || mEndDate.isEmpty()) {
                Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
                return;
            }
            timePeriod = "&timePeriod=" + mSelectedTime + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate;
        } else {
            timePeriod = "&timePeriod=" + mSelectedTime;
        }

        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FUNDSNET_LOGIN_CAPTCHA
                        + "folioid=" + folioID + timePeriod;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")) {
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FUNDSNET_LOGIN_CAPTCHA_CLIENT
                        + "folioid=" + folioID + timePeriod + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, "", "", "", "", "", new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.loading_first_captcha));
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        if(resultObject != null) {
                            if (resultObject.has("fileName"))
                            {
                                mFileName = resultObject.optString("fileName");
                                if (!mFileName.isEmpty()) {
                                    downloadFile();
                                } else {
                                    Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
                                }
                            }
                            else {
                                JSONObject dataObject = resultObject != null ? resultObject.optJSONObject("data") : null;
                                String captchaLink = dataObject != null ? dataObject.optString("captchaLink") : "";
                                mResponseHeaderCookies = jsonObject.optString("fundsNetCookieFromResponseHeaders");
                                mFundsNetCookies = dataObject != null ? dataObject.optString("fundsNetCookies") : "";
                                mFundsNetGuid = dataObject != null ? dataObject.optString("hdnGUIDVal") : "";
                                showFundsNetCaptchaDialog(captchaLink, true);
                            }
                        }
                    } else {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
    private void getFundsNetToken(String loginCaptchaText) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        String url = "";
        String timePeriod;
        if (mSelectedTime.equalsIgnoreCase("CU")) {
            timePeriod = "&timePeriod=" + mSelectedTime + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate;
        } else {
            timePeriod = "&timePeriod=" + mSelectedTime;
        }

        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FUNDSNET_TOKEN_BROKER
                        + "folioid=" + mFolioId + timePeriod
                        + "&fundsNetCookies=" + mFundsNetCookies
                        + "&loginCaptcha=" + loginCaptchaText
                        + "&hdnGUIDVal=" + mFundsNetGuid;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")) {
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FUNDSNET_TOKEN_CLIENT
                        + "folioid=" + mFolioId + timePeriod
                        + "&fundsNetCookies=" + mFundsNetCookies
                        + "&loginCaptcha=" + loginCaptchaText
                        + "&hdnGUIDVal=" + mFundsNetGuid
                        + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, mResponseHeaderCookies, "", "", "", "fundsnet_cookie", new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.verifying_details_next_captcha_will_appear_shortly));

                    if (mFundsNetCaptchaDialog != null && mFundsNetCaptchaDialog.isShowing()) {
                        mFundsNetCaptchaDialog.hide();
                    }
                } else {
                    ProgressBarCommon.dismissDialog();

                    if (mFundsNetCaptchaDialog != null) {
                        mFundsNetCaptchaDialog.show();
                    }
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        String captchaLink = resultObject != null ? resultObject.optString("captchaLink") : "";
                        mFundsNetToken = resultObject != null ? resultObject.optString("fundsNetToken") : "";
                        mResponseHeaderCookies = jsonObject.optString("fundsNetCookieFromResponseHeaders");
                        showFundsNetCaptchaDialog(captchaLink, false);
                    } else {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }
    private void showFundsNetCaptchaDialog(final String captchaUrl, final boolean isLoginCaptcha) {
        if (captchaUrl == null || captchaUrl.isEmpty()) {
            Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_cams_captcha, null);
        dialogBuilder.setView(dialogView);
        mFundsNetCaptchaDialog = dialogBuilder.create();

        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        Button btDone = dialogView.findViewById(R.id.btDone);
        final Button btCancel = dialogView.findViewById(R.id.btCancel);
        ImageView ivCaptcha = dialogView.findViewById(R.id.ivCaptcha);
        ProgressBar pbCaptchaLoading = dialogView.findViewById(R.id.pbCaptchaLoading);
        final TextInputEditText etCaptcha = dialogView.findViewById(R.id.etCaptcha);
        mFundsNetCaptchaDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        linerMain.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.dialog_background_inset));

        tvTitle.setText(isLoginCaptcha ? "Captcha 1/2" : "Captcha 2/2");

        pbCaptchaLoading.setVisibility(View.VISIBLE);
        ivCaptcha.setVisibility(View.GONE);
        Picasso.get().load(captchaUrl).into(ivCaptcha, new Callback() {
            @Override
            public void onSuccess() {

                pbCaptchaLoading.setVisibility(View.GONE);
                ivCaptcha.setVisibility(View.VISIBLE);
            }

            @Override
            public void onError(Exception exception) {
                pbCaptchaLoading.setVisibility(View.GONE);
                ivCaptcha.setVisibility(View.VISIBLE);
                mFundsNetCaptchaDialog.dismiss();
                Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
            }
        });

        btDone.setOnClickListener(v -> {
            String captcha = etCaptcha.getText() != null ? etCaptcha.getText().toString().trim() : "";
            if (captcha.isEmpty()) {
                Toast.makeText(getActivity(), getString(R.string.text_enter_captcha), Toast.LENGTH_SHORT).show();
                return;
            }
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && imm.isAcceptingText()) {
                imm.hideSoftInputFromWindow(etCaptcha.getWindowToken(), 0);
            }
            if (isLoginCaptcha) {
                getFundsNetToken(captcha);
            } else {
                downloadFundsNetSoa(captcha);
            }
        });

        btCancel.setOnClickListener(v -> mFundsNetCaptchaDialog.dismiss());

        mFundsNetCaptchaDialog.setCancelable(false);
        mFundsNetCaptchaDialog.show();
    }
    private void downloadFundsNetSoa(String captchaText) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        if (mFundsNetToken.isEmpty() || mResponseHeaderCookies.isEmpty()) {
            Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "";
        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_FUNDSNET_SOA
                        + "captchaText=" + captchaText
                        + "&fundsNetToken=" + mFundsNetToken;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")) {
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_FUNDSNET_SOA_CLIENT
                        + "captchaText=" + captchaText
                        + "&fundsNetToken=" + mFundsNetToken
                        + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, mResponseHeaderCookies, "", "", "", "fundsnet_cookie", new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.requesting_soa));
                    if (mFundsNetCaptchaDialog != null && mFundsNetCaptchaDialog.isShowing()) {
                        mFundsNetCaptchaDialog.hide();
                    }
                } else {
                    ProgressBarCommon.dismissDialog();

                    if ( mFundsNetCaptchaDialog != null) {
                        mFundsNetCaptchaDialog.show();
                    }

                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        if (mFundsNetCaptchaDialog != null) {
                            mFundsNetCaptchaDialog.dismiss();
                            mFundsNetCaptchaDialog = null;
                        }
                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        mFileName = resultObject != null ? resultObject.optString("fileName") : "";
                        if (!mFileName.isEmpty()) {
                            downloadFile();
                        } else {
                            Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    /**--------------------------CAMS SECRET FLOW METHODS(replaced by fundsnet flow now)-------------------------------------**/
    private void getCampsCaptcha(String folioID) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        String url = "";

        //  &fromDate=2019-10-01&toDate=2020-07-13
        String timePreviod = "";
        if (mSelectedTime.equalsIgnoreCase("CU")) {
            timePreviod = "&timePeriod=" + mSelectedTime + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate;
        } else {
            timePreviod = "&timePeriod=" + mSelectedTime;
        }

        try {
            JSONObject jsonObject1 = new JSONObject();
            jsonObject1.put("componentName", "RequestSOA");
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CAMS_CAPTCHA
                        + "folioid=" + folioID + timePreviod + "&pageSize=100" + "&currentPage=1";
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_CAMS_CAPTCHA_CLIENT
                        + "folioid=" + folioID + timePreviod + "&pageSize=100" + "&currentPage=1" + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, "", "", "", "", "", new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity());
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonCookies = jsonObject.optJSONObject("soaCookies");
                        if (jsonCookies != null) {
                            mCookiesAWSALBTG = jsonCookies.optString("AWSALBTG");
                            mCookiesAWSALB = jsonCookies.optString("AWSALB");
                        }

                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        showCamsDailog(jsonObject1);
                    } else if (jsonObject.optInt("status") == -1) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }
    public void showCamsDailog(final JSONObject jsonObject) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_cams_captcha, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();

        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        Button btDone = dialogView.findViewById(R.id.btDone);
        final Button btCancel = dialogView.findViewById(R.id.btCancel);
        ImageView ivCaptcha = dialogView.findViewById(R.id.ivCaptcha);
        final TextInputEditText etCaptcha = dialogView.findViewById(R.id.etCaptcha);
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(getActivity(), R.drawable.dialog_background_inset));
        }


        Picasso.get().load(jsonObject.optString("captchaLink")).into(ivCaptcha, new Callback() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onError(Exception exception) {
                alertDialog.dismiss();
                Toast.makeText(getActivity(), getString(R.string.text_try_again), Toast.LENGTH_SHORT).show();
            }
        });

        btDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String captcha = etCaptcha.getText().toString();
                if (captcha.isEmpty()) {
                    Toast.makeText(getActivity(), getString(R.string.text_enter_captcha), Toast.LENGTH_SHORT).show();
                } else if (captcha.length() < 3) {
                    Toast.makeText(getActivity(), getString(R.string.text_enter_correct_captcha), Toast.LENGTH_SHORT).show();
                } else {
                    InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm.isAcceptingText()) {
                        imm.hideSoftInputFromWindow(etCaptcha.getWindowToken(), 0);
                    }
                    validateCampsCaptcha(captcha, jsonObject.optString("fundsNetToken"), alertDialog);
                }


            }
        });

        btCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();

            }
        });

        alertDialog.setCancelable(false);
        alertDialog.show();
    }
    private void validateCampsCaptcha(String captchaText, String fundsNetToken, final AlertDialog alertDialog) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        String url = "";
        try {
            JSONObject jsonObject1 = new JSONObject();
            jsonObject1.put("componentName", "RequestSOA");
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FILE_NAME_VERIFY_CAPTCHA
                        + "captchaText=" + captchaText + "&fundsNetToken=" + fundsNetToken;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FILE_NAME_VERIFY_CAPTCHA_CLIENT
                        + "captchaText=" + captchaText + "&fundsNetToken=" + fundsNetToken + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

            /*https://profitcentre.investwell.app/webapi/broker/SOA/downloadCamsSOA?captchaText=TVERR
            &fundsNetToken=fundsNet:/wEFJDIxOGVjZDVhLTU0ZjAtNDk0MS1hYWNmLTVhMjA5YWE4ZDIyNg==
            &componentForLoader={"componentName":"RequestSOA"}&pageSize=100&currentPage=1&selectedUser={}*/

        } catch (Exception e) {

        }

        KtorHelper.requestCallSOA(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, mCookiesAWSALBTG, mCookiesAWSALB, "", "", "soa1", new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_we_are_verifying_captcha));
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        alertDialog.dismiss();
                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        mFileName = jsonObject1.optString("fileName");
                        if (!mFileName.isEmpty())
                            downloadFile();
                    } else if (jsonObject.optInt("status") == -1) {
                        ProgressBarCommon.dismissDialog();
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }

                } catch (Exception ignored) {

                }
            }

            @Override
            public void onError(String errorMessage, int statusCode) {
                KtorCallBack.super.onError(errorMessage, statusCode);
                ProgressBarCommon.dismissDialog();
                if (!errorMessage.contains("Invalid Captcha")){
                    alertDialog.dismiss();
                }

            }
        });

    }

    private void getFileName() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        String url = "";
        try {
            String timePreviod = "";
            if (mSelectedTime.equalsIgnoreCase("CU")) {
                timePreviod = "&timePeriod=" + mSelectedTime + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate;
            } else {
                timePreviod = "&timePeriod=" + mSelectedTime;
            }

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && UtilityKotlin.getClientHopObject(mSession).length() == 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FILE_NAME
                        + "folioid=" + mFolioId + timePreviod;
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FILE_NAME_CLIENT
                        + "folioid=" + mFolioId + timePreviod + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        } catch (Exception e) {

        }

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                } else {
                    ProgressBarCommon.dismissDialog();

                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        mFileName = jsonObject1.optString("fileName");
                        if (!mFileName.isEmpty())
                            downloadFile();
                    } else if (jsonObject.optInt("status") == -1) {
                        ProgressBarCommon.dismissDialog();
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(getActivity(), "Failed", jsonObject.optString("message"), "message");
                    }

                } catch (Exception e) {

                }

            }
        });

    }
    private void downloadFile() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                ProgressBarCommon.dismissDialog();
                return;
            }
        }

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                Config.DOWNLOAD_SOA + "fileHandle=2" + "&fileName=" + mFileName + "&downloadType=PDF";
        if (!mSession.getLoginType().equals("broker")) {
            if (Utils.getSelectedLevelNo(mSession).equals("1")){
                return;
            }
            url = url + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        }
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "statement_of_account", "", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.downloading_soa));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_soa_download_successfully), "pdf", mFileSave, uri);
                        else {
                            mMainActivity.showCommonDownload(mMainActivity, getString(R.string.txt_successfully), getString(R.string.txt_soa_download_successfully), "pdf", mFileSave, uri);
                        }
                    }
                });

    }

    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }
    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }
    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {

        } else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            if (!mFileName.isEmpty()) {
                ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                downloadFile();
            }

        }
    });
}
