package investwell.common.onboarding;

import static investwell.utils.ExtensionsKt.checkExchangeId;
import static investwell.utils.ExtensionsKt.checkFirstHolderPan;
import static investwell.utils.ExtensionsKt.checkFirstPan;
import static investwell.utils.ExtensionsKt.checkSecondHolderName;
import static investwell.utils.ExtensionsKt.checkSecondHolderPan;
import static investwell.utils.ExtensionsKt.checkThirdHolderName;
import static investwell.utils.ExtensionsKt.checkfirstHolderName;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.activity.MfuCartWebView;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class ExchangeForAdditionalPurchase extends BaseFragment implements View.OnClickListener {
    private ImageView mIvNse, mIvBse, mIvMfu, mIvNse2;
    private AppSession mSession;
    private Bundle mBundle;
    private JSONObject mOldJsonObject, tranJsonObject, mObjNewScheme, mUccIinResponseObject;
    public String mFolioId = "", mAppId = "", mTransactionType = "";
    AppApplication appApplication;
    private ApiDataBase db;
    private ClientActivity mActivity;
    private BrokerActivity mBrokerActivity;
    private ToolbarFragment mFragToolBar;
    private String mType ="";

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            appApplication = (AppApplication) mActivity.getApplication();
        }else if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            appApplication = (AppApplication) mBrokerActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.Select_exchange), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.frag_common_exchange, container, false);

        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mActivity.setMainVisibility(this, null);
        }

        mUccIinResponseObject = new JSONObject();

        mBundle = getArguments();
        if (mBundle != null && mBundle.containsKey("comefrom")) {
            mType = mBundle.getString("comefrom");
        }

        if (mBrokerActivity!=null){
            db = ApiDataBase.getInstance(mBrokerActivity.getApplicationContext());
        }else {
            db = ApiDataBase.getInstance(mActivity.getApplicationContext());
            if (mBundle != null) {
                try {
                    if (!mType.equalsIgnoreCase("myorderClient") && mBundle.containsKey("oldObject")) {
                        mOldJsonObject = new JSONObject(mBundle.getString("oldObject"));
                        tranJsonObject = new JSONObject(mBundle.getString("tranJsonObject"));
                        mTransactionType = mBundle.getString("transactionType");
                        mFolioId = mOldJsonObject.optString("folioid");
                        mAppId = mOldJsonObject.optString("appid");
                    }

                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }

        mIvNse = view.findViewById(R.id.ivNse);
        mIvNse2 = view.findViewById(R.id.ivNse2);
        mIvBse = view.findViewById(R.id.ivBse);
        mIvMfu = view.findViewById(R.id.ivMfu);
        mIvNse.setOnClickListener(this);
        mIvNse2.setOnClickListener(this);
        mIvBse.setOnClickListener(this);
        mIvMfu.setOnClickListener(this);

        boolean hasBse = mSession.getHasBseOpted();
        boolean hasNse = mSession.getHasNseOpted();
        boolean hasMfu = mSession.getHasMfuOpted();
        boolean hasNse2 = mSession.getHasNse2Opted();

        View[] exchangeViews = { mIvBse, mIvNse, mIvMfu, mIvNse2 };
        boolean[] exchangeFlags = { hasBse, hasNse, hasMfu, hasNse2 };

        int enabledCount = 0;
        for (int i = 0; i < exchangeViews.length; i++) {
            if (exchangeFlags[i]) {
                exchangeViews[i].setVisibility(View.VISIBLE);
                enabledCount++;
            } else {
                exchangeViews[i].setVisibility(View.GONE);
            }
        }

        mSession.setHasMultiExchange(enabledCount > 1);


        if (mType.equalsIgnoreCase("myorderBroker")){
            //boolean isViewEnableNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature46", Permissions.VIEW);
            boolean isViewEnableBSe = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature37", Permissions.VIEW);
            boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature42", Permissions.VIEW);
            boolean isViewEnableNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature133", Permissions.VIEW);

//            if (isViewEnableNse){
//                mIvNse.setVisibility(View.VISIBLE);
//            }else{
//                mIvNse.setVisibility(View.GONE);
//            }

            if (isViewEnableBSe){
                mIvBse.setVisibility(View.VISIBLE);
            }else{
                mIvBse.setVisibility(View.GONE);
            }

            if (isViewEnableMfu){
                mIvMfu.setVisibility(View.VISIBLE);
            }else{
                mIvMfu.setVisibility(View.GONE);
            }
            if (isViewEnableNSE2){
                mIvNse2.setVisibility(View.VISIBLE);
            }else {
                mIvNse2.setVisibility(View.GONE);
            }

        }
        else if (mType.equalsIgnoreCase("myorderClient")){
            //boolean isViewEnableNse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1020", Permissions.VIEW);
            boolean isViewEnableBSe = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1023", Permissions.VIEW);
            boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1026", Permissions.VIEW);
            boolean isViewEnableNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1052", Permissions.VIEW);

//            if (isViewEnableNse){
//                mIvNse.setVisibility(View.VISIBLE);
//            }else{
//                mIvNse.setVisibility(View.GONE);
//            }

            if (isViewEnableBSe){
                mIvBse.setVisibility(View.VISIBLE);
            }else{
                mIvBse.setVisibility(View.GONE);
            }

            if (isViewEnableMfu){
                mIvMfu.setVisibility(View.VISIBLE);
            }else{
                mIvMfu.setVisibility(View.GONE);
            }

            if (isViewEnableNSE2){
                mIvNse2.setVisibility(View.VISIBLE);
            }else{
                mIvNse2.setVisibility(View.GONE);
            }
        }
        else if (mType.equalsIgnoreCase("cart")){
            boolean isViewEnableMfu = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1048", Permissions.VIEW);
            boolean isViewEnableNSE2 = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1053", Permissions.VIEW);
            boolean isViewEnableBse = UtilityKotlin.checkFeaturePermissionsOnOff(mSession, "feature1043", Permissions.VIEW);

            mIvBse.setVisibility(View.GONE);
            mIvNse.setVisibility(View.GONE);
            if (isViewEnableMfu){
                mIvMfu.setVisibility(View.VISIBLE);
            }else{
                mIvMfu.setVisibility(View.GONE);
            }

            if (isViewEnableNSE2){
                mIvNse2.setVisibility(View.VISIBLE);
            }else{
                mIvNse2.setVisibility(View.GONE);
            }

            if (isViewEnableBse){
                mIvBse.setVisibility(View.VISIBLE);
            }else{
                mIvBse.setVisibility(View.GONE);
            }
        }


        if (mBrokerActivity !=null){
            mBrokerActivity.runOnUiThread(() -> setUpToolBar());
        }else {
            mActivity.runOnUiThread(() -> setUpToolBar());
        }

        return view;
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.ivNse) {
                AppApplication.sExchangeType = "1";
                if (mActivity !=null){

                }else {

                }
                redirectMethod();
}
else if (view.getId() == R.id.ivBse) {
                AppApplication.sExchangeType = "2";
                if (mActivity !=null){

                }else {

                }
                redirectMethod();
}
else if (view.getId() == R.id.ivMfu) {
                AppApplication.sExchangeType = "3";
                if (mActivity !=null){

                }else {

                }

                redirectMethod();
}
else if (view.getId() == R.id.ivNse2) {
                AppApplication.sExchangeType = "4";
                redirectMethod();
}

    }


    private void redirectMethod() {
        if (mType.equalsIgnoreCase("myorderBroker")){
            mBrokerActivity.displayViewOther(33, mBundle);

        }else if (mType.equalsIgnoreCase("myorderClient")){
            mActivity.displayViewOther(35, mBundle);
        }
        else if (mType.equalsIgnoreCase("cart")){
            Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
            intent.putExtra("url", UtilityKotlin.constructCartUrl(mSession));
            intent.putExtra("isPopup", true);
            intent.putExtra("comeFrom", "clientHome");
            startActivity(intent);
        }
        else {
            String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
//            mActivity.displayViewOther(88,mBundle);
            getAllmTransactionTypes(schemeId);
        }


    }

    private void getUccIinMfu(final ProgressDialog bar) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        String exchange = "";
        if (mSession.getHasMultiExchange()) {
            exchange = AppApplication.sExchangeType;
            if (exchange == "")
                exchange = mSession.getExchangeNseBseMfu();
        } else {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            } else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            }else if (mSession.getHasBseOpted()) {
                exchange = "4";
            } else {
                exchange = mSession.getExchangeNseBseMfu();
            }
        }

        try {

            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("componentName", "investOnline");

            if (exchange.equals("1")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_IIN_BY_FOLIO
                        + "folioid=" + mFolioId
                        + "&investorUid=" + Utils.getSelectedUid(mSession)
                        +"&selectedUser="+Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("2")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_UCC_LIST
                        + "folioid=" + mFolioId
                        + "&investorUid=" + Utils.getSelectedUid(mSession)
                        + "&selectedUser="+Utils.getSelectedUserObject(mSession);
            } else if (exchange.equals("3")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_CAN_LIST
                        + "folioid=" + mFolioId
                        + "&investorUid=" + Utils.getSelectedUid(mSession)
                        +"&selectedUser="+Utils.getSelectedUserObject(mSession);
            }else if (exchange.equals("4")) {
                //GET_SELECTED_UCC_NSE2
                /*
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_SELECTED_NSE2_ACTIVE_PROFILE
                        + "status=active&folioid=" + mFolioId
                        + "&investorUid=" + Utils.getSelectedUid(mSession)
                        +"&selectedUser="+Utils.getSelectedUserObject(mSession);*/

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_SELECTED_UCC_NSE2
                        + "folioid=" + mFolioId
                        + "&investorUid=" + Utils.getSelectedUid(mSession)
                        +"&selectedUser="+Utils.getSelectedUserObject(mSession);
            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        bar.dismiss();
                        String exchange = "";
                        if (mSession.getHasMultiExchange()) {
                            exchange = AppApplication.sExchangeType;
                            if (exchange == "")
                                exchange = mSession.getExchangeNseBseMfu();
                        } else {
                            if (mSession.getHasNseOpted()) {
                                exchange = "1";
                            } else if (mSession.getHasBseOpted()) {
                                exchange = "2";
                            } else if (mSession.getHasMfuOpted()) {
                                exchange = "3";
                            }else if (mSession.getHasBseOpted()) {
                                exchange = "4";
                            } else {
                                exchange = mSession.getExchangeNseBseMfu();
                            }
                        }
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            int status = jsonObject.optInt("status");

                            if (status == 0) {
                                mUccIinResponseObject = jsonObject.optJSONObject("result");
                                boolean recommended = mUccIinResponseObject.optBoolean("recommended", false);

                                JSONArray dataArray = mUccIinResponseObject.optJSONArray("data");
                                int dataLen = dataArray != null ? dataArray.length() : 0;

                                // Message will be show when recomended false as well as no any ucc/iin
                                if (!recommended && dataLen == 0) {
                                    String msg = null;
                                    if ("1".equals(exchange)) {
                                        msg = getString(R.string.no_iin_available);
                                    } else if ("2".equals(exchange) || "4".equals(exchange)) {
                                        msg = getString(R.string.no_ucc_available);
                                    } else if ("3".equals(exchange) ) {
                                        msg = getString(R.string.no_can_available);
                                    }else if ("4".equals(exchange) ) {
                                        msg = getString(R.string.no_ucc_available);
                                    }
                                    if (msg != null) appApplication.showCommonDailog(mActivity,  getString(R.string.failed), msg, "message");
                                    return;
                                }
                                // redirection
                                try {

                                    //recommended
                                    if (recommended){
                                        mBundle.putString("sIinProfileObject", mUccIinResponseObject.toString());
                                        mActivity.displayViewOther(34, mBundle);
                                    }else {
                                        JSONObject panlist = new JSONObject();
                                        JSONObject nameList = new JSONObject();
                                        JSONArray jsonArray = mUccIinResponseObject.optJSONArray("data");
                                        if (jsonArray.length() > 0) {
                                            JSONObject object = jsonArray.optJSONObject(0);


                                            if (!mUccIinResponseObject.optBoolean("recommended")
                                                    && exchange.equals("3")) {

                                                String mfuid = object.optString("mfuid");
                                                String source = object.optString("source");
                                                mOldJsonObject.put("mfuid", mfuid);
                                                mOldJsonObject.put("source", source);
                                                mBundle.putString("oldObject", mOldJsonObject.toString());
                                                mBundle.putString("sIinProfileObject", object.toString());
                                            } else {
                                                mBundle.putString("sIinProfileObject", object.toString());
                                            }

                                            panlist = UtilityKotlin.buildPanList(object);//JSONObject()
                                            nameList = UtilityKotlin.buildNameList(object);//JSONObject()
                                            String appId = object.optString("appid", "");
                                            mAppId = appId.isEmpty() ? null : appId;


                                        }else {
                                            mBundle.putString("sIinProfileObject", mUccIinResponseObject.toString());
                                            mActivity.displayViewOther(34, mBundle);
                                        }
                                        if (mType.equalsIgnoreCase("additionalPurchase")){
                                            existingInvestmentRoute(mTransactionType,mOldJsonObject,mUccIinResponseObject);
                                        }else {
                                            if (mActivity!= null){
                                                mBundle.putString("panList",panlist.toString());
                                                mBundle.putString("nameList",nameList.toString());
                                                mBundle.putString("exchangeId",checkExchangeId(mUccIinResponseObject));
                                                mBundle.putString("exchange",exchange);
                                                mBundle.putString("appid",mAppId);
                                                mBundle.putString("mTransactionType",mTransactionType);
                                                mBundle.putString("mUccIinResponseObject",mUccIinResponseObject.toString());
                                                mBundle.putString("comeFrom","additional");
                                                mActivity.displayViewOther(88,mBundle);
                                            }
                                        }
                                    }


                                } catch (Exception e) {
                                    if (mUccIinResponseObject == null) {
                                        JSONObject object = new JSONObject();
                                        mBundle.putString("sIinProfileObject", object.toString());
                                        mActivity.displayViewOther(34, mBundle);
                                    }
                                }
                            } else if (jsonObject.optInt("status") == -1) {
                                appApplication.showCommonDailog(mActivity, getString(R.string.failed), jsonObject.optString("message"), "message");
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG) e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                        UtilityKotlin.parseVolleyError(volleyError, mSession, requireActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) mActivity.getApplication();
                    appApplication.showCommonDailog(mActivity, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(mActivity);
        requestQueue.add(stringRequest);
    }


    private void existingInvestmentRoute(String transectionType , JSONObject jsonObject,JSONObject sIinProfileObject){
        Bundle bundle = new Bundle();
        try {
            jsonObject.put("applicant_name", jsonObject.optString("applicantName"));
            bundle.putString("oldObject", jsonObject.toString());
            bundle.putString("tranJsonObject", tranJsonObject.toString());
            bundle.putString("transactionType", transectionType);
            bundle.putString("isAnimation", "true");
            bundle.putString("sIinProfileObject", sIinProfileObject.toString());
        } catch (Exception exception) {

        }

        try {
            JSONArray jsonArray = mUccIinResponseObject.getJSONArray("data");
            if (jsonArray.length() > 0) {
                JSONObject object = jsonArray.optJSONObject(0);

                if (!mUccIinResponseObject.optBoolean("recommended") && mSession.getExchangeNseBseMfu().equals("3")) {

                    String mfuid = object.optString("mfuid");
                    String source = object.optString("source");
                    jsonObject.put("mfuid", mfuid);
                    jsonObject.put("source", source);
                    bundle.putString("oldObject", jsonObject.toString());
                    bundle.putString("sIinProfileObject", object.toString());
                } else {
                    bundle.putString("sIinProfileObject", object.toString());
                }

            }

            String exchange = "";
            if (mSession.getHasMultiExchange()) {
                exchange = AppApplication.sExchangeType;
                if (exchange == "") exchange = mSession.getExchangeNseBseMfu();
            } else {
                if (mSession.getHasNseOpted()) {
                    exchange = "1";
                } else if (mSession.getHasBseOpted()) {
                    exchange = "2";
                } else if (mSession.getHasMfuOpted()) {
                    exchange = "3";
                }  else if (mSession.getHasNse2Opted()) {
                    exchange = "4";
                } else {
                    // exchange = mSession.getExchangeNseBseMfu();
                }
            }
            if (mUccIinResponseObject == null) {
                JSONObject object = new JSONObject();
                bundle.putString("sIinProfileObject", object.toString());
                mActivity.displayViewOther(34, bundle);
            } else if (mUccIinResponseObject.optBoolean("recommended")) {
                bundle.putString("sIinProfileObject", mUccIinResponseObject.toString());
                mActivity.displayViewOther(34, bundle);
            } else {
                if (transectionType.equalsIgnoreCase("NRP")) {

                    if (exchange.equals("1")) {
                        mActivity.displayViewOther(27, bundle);
                    } else if (exchange.equals("2")) {
                        mActivity.displayViewOther(8, bundle);
                    } else if (exchange.equals("3")) {
                        mActivity.displayViewOther(43, bundle);
                    }else if (exchange.equals("4")) {
                        bundle.putBoolean("nse2",true);
                        mActivity.displayViewOther(8, bundle);
                    } else {
                        Toast.makeText(getActivity(), "Profile Creation not allowed. Please contact Administrator", Toast.LENGTH_LONG).show();
                    }

                } else if (transectionType.equalsIgnoreCase("SIP")) {
                    if (exchange.equals("1")) {
                        mActivity.displayViewOther(28, bundle);
                    } else if (exchange.equals("2")) {
                        mActivity.displayViewOther(9, bundle);
                    } else if (exchange.equals("3")) {
                        mActivity.displayViewOther(44, bundle);
                    } else if (exchange.equals("4")) {
                        bundle.putBoolean("nse2",true);
                        mActivity.displayViewOther(9, bundle);
                    } else {
                        Toast.makeText(getActivity(), "Profile Creation not allowed. Please contact Administrator", Toast.LENGTH_LONG).show();
                    }

                } else if (transectionType.equalsIgnoreCase("SWO")) {
                    mActivity.displayViewOther(10, bundle);
                } else if (transectionType.equalsIgnoreCase("SWP")) {
                    if (mSession.getExchangeNseBseMfu().equals("1")) {
                        mActivity.displayViewOther(86, bundle);
                    } else{
                        mActivity.displayViewOther(11, bundle);
                    }
                } else if (transectionType.equalsIgnoreCase("STP")) {
                    if (mSession.getExchangeNseBseMfu().equals("1")) {
                        mActivity.displayViewOther(87, bundle);
                    } else{
                        mActivity.displayViewOther(12, bundle);
                    }
                } else if (transectionType.equalsIgnoreCase("NRS")) {
                    mActivity.displayViewOther(13, bundle);
                }
            }

        } catch (Exception e) {
            if (mUccIinResponseObject == null) {
                JSONObject object = new JSONObject();
                Bundle bundle2 = new Bundle();
                bundle2.putString("data", jsonObject.toString());
                bundle2.putString("applicant_name", jsonObject.optString("applicantName"));
                bundle2.putString("sIinProfileObject", object.toString());
                mActivity.displayViewOther(34, bundle2);
            }
        }
    }

    private void getAllmTransactionTypes(String schemeCode) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        try {

            String varableForBSeMfu = "";
            if (appApplication.sExchangeType.equals("2")) {
                varableForBSeMfu = "&hasBseCode=true";
            } else if (appApplication.sExchangeType.equals("3")) {
                varableForBSeMfu = "&hasMfuCode=true";
            } else if (appApplication.sExchangeType.equals("4")) {
                varableForBSeMfu="&hasNseInvestCode=true";
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_TRANSECTION_TYPE + "schid=" + schemeCode + varableForBSeMfu +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession) + "&bid=" + mSession.getBid() + "&exchange=" + appApplication.sExchangeType +
                    "&levelid=" + mSession.getLevelId();
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");


        } catch (Exception e) {

        }

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {


                                tranJsonObject = jsonObject.optJSONObject("result");
                                mBundle.putString("tranJsonObject", tranJsonObject.toString());
                                JSONArray jsonArray = tranJsonObject.getJSONArray("allowedInvestmentTypes");
                                if (jsonArray.length() > 0) {
                                    ArrayList<String> list = new ArrayList<>();
                                    for (int i = 0; i < jsonArray.length(); i++) {
                                        String mTransactionType = jsonArray.getString(i);
                                        list.add(mTransactionType);
                                    }
                                    if (list.contains(mTransactionType)) {
                                        getUccIinMfu(mBar);
                                    } else {
                                        mBar.dismiss();
                                        if (appApplication.sExchangeType.equals("1")) {
                                            String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_nse_for) + mOldJsonObject.optString("schemeName");
                                            appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");

                                        } else if (appApplication.sExchangeType.equals("2")) {
                                            String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_bse_for) + mOldJsonObject.optString("schemeName");
                                            appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");

                                        } else if (appApplication.sExchangeType.equals("3")) {
                                            String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_mfu_for) + mOldJsonObject.optString("schemeName");
                                            appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");
                                        } else if (appApplication.sExchangeType.equals("4")) {
                                            String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_nse_for) + mOldJsonObject.optString("schemeName");
                                            appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");
                                        }
                                    }

                                } else {
                                    mBar.dismiss();
                                    if (appApplication.sExchangeType.equals("1")) {
                                        String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_nse_for) + mOldJsonObject.optString("schemeName");
                                        appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");

                                    } else if (appApplication.sExchangeType.equals("2")) {
                                        String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_bse_for) + mOldJsonObject.optString("schemeName");
                                        appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");

                                    } else if (appApplication.sExchangeType.equals("3")) {
                                        String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_mfu_for) + mOldJsonObject.optString("schemeName");
                                        appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");
                                    } else if (appApplication.sExchangeType.equals("4")) {
                                        String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_nse_for) + mOldJsonObject.optString("schemeName");
                                        appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");
                                    }

                                }

                            } else if (jsonObject.optInt("status") == -1) {
                                mBar.dismiss();
                                if (appApplication.sExchangeType.equals("1")) {
                                    String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_nse_for) + mOldJsonObject.optString("schemeName");
                                    appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");

                                } else if (appApplication.sExchangeType.equals("2")) {
                                    String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_bse_for) + mOldJsonObject.optString("schemeName");
                                    appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");

                                } else if (appApplication.sExchangeType.equals("3")) {
                                    String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_mfu_for) + mOldJsonObject.optString("schemeName");
                                    appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");
                                } else if (appApplication.sExchangeType.equals("4")) {
                                    String message = Utils.SchemeNameFormat(mTransactionType) + getString(R.string.not_allowed_by_nse_for)  + mOldJsonObject.optString("schemeName");
                                    appApplication.showCommonDailog(mActivity, getString(R.string.failed), message, "message");
                                }
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        mBar.dismiss();

                        UtilityKotlin.parseVolleyError(volleyError, mSession, requireActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) mActivity.getApplication();
                    appApplication.showCommonDailog(mActivity, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }
}