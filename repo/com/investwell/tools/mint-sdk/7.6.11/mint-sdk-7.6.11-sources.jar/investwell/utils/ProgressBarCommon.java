package investwell.utils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.iw.mint.sdk.R;


public class ProgressBarCommon {
    private static AlertDialog dialog = null;

    // Guards against WindowManager.BadTokenException: if context is an Activity that has
    // already finished/been destroyed by the time an async callback calls showDialog (e.g. a
    // RecyclerView ViewHolder's network callback firing after the host Activity is gone), the
    // window token is no longer valid and dialog.show() would crash.
    private static boolean canShowDialog(Context context) {
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            return !activity.isFinishing() && !activity.isDestroyed();
        }
        return true;
    }

    public static void showDialog(Context context) {
        if (dialog != null) {
            dismissDialog();
        }
        if (!canShowDialog(context)) {
            return;
        }

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.progress_layout, null);
        dialogBuilder.setView(dialogView);
        dialog = dialogBuilder.create();
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        try {
            dialog.show();
        } catch (WindowManager.BadTokenException | IllegalStateException e) {
            dialog = null;
        }

    }

    public static void showDialog(Context context,String message) {
        if (dialog != null) {
            dismissDialog();
        }
        if (!canShowDialog(context)) {
            return;
        }

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.progress_layout, null);
        TextView tvLoaderTitle = dialogView.findViewById(R.id.tvLoaderText);
        tvLoaderTitle.setVisibility(View.VISIBLE);
        tvLoaderTitle.setText(message);
        dialogBuilder.setView(dialogView);
        dialog = dialogBuilder.create();
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        try {
            dialog.show();
        } catch (WindowManager.BadTokenException | IllegalStateException e) {
            dialog = null;
        }

    }


    public static boolean isDialogVisible() {
        if (dialog != null) {
            return dialog.isShowing();
        } else {
            return false;
        }
    }

    public static void dismissDialog2() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
            dialog = null;
        }
    }

    public static void dismissDialog() {
        try {
            if (dialog != null && dialog.isShowing()) {
                //get the Context object that was used to great the dialog
                Context context = ((ContextWrapper) dialog.getContext()).getBaseContext();
                // if the Context used here was an activity AND it hasn't been finished or destroyed
                // then dismiss it
                if (context instanceof Activity) {

                    if (!((Activity) context).isFinishing()) {
                        if (!((Activity) context).isDestroyed()) {
                            dismissWithExceptionHandling();
                        }
                    }
                } else {
                    // if the Context used wasn't an Activity, then dismiss it too
                    dismissWithExceptionHandling();
                }
            }

            if (dialog != null && dialog.isShowing()) {
                dialog.dismiss();
            }
            dialog = null;
        }catch (Exception e){

        }
    }


    public static void dismissWithExceptionHandling() {
        try {
            dialog.dismiss();
        } catch (final IllegalArgumentException e) {
            // Do nothing.
        } catch (final Exception e) {
            // Do nothing.
        } finally {
            dialog = null;
        }
    }
}
