package investwell.client.fragments.elss;

import static android.os.Build.VERSION.SDK_INT;

import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.InputStreamVolleyRequest;
import investwell.utils.UtilityKotlin;


public class FragELSS1User extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    RequestQueue requestQueue;
    FragElssAdapter mElsstAdapter;
    private LinearLayoutManager mLayoutManager;

    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;
    private TextView mTvNothing;
    private ShimmerFrameLayout mShimmerViewContainer;
    RecyclerView mRvDividendReport;

    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;

    private Calendar c = Calendar.getInstance();
    private int year;
    private int next_year;
    private ImageView Previous_Year_img, Next_Year_img;
    private TextView Previous_Year, Next_Year;


    @Override
    public void onResume() {
        super.onResume();
  /*      if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }

    private void setUpToolBar(boolean isShowDownload) {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.elss_text),
                    true, false, false, isShowDownload, false, false, false);
        }
        fragToolBar.setCallback(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_elss, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mMainActivity.setMainVisibility(this, null);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mTvNothing = view.findViewById(R.id.tvLoading);
        mTvNothing.setVisibility(View.GONE);

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llElss).setBackgroundResource(R.mipmap.card_blank);

        mRvDividendReport = view.findViewById(R.id.recycleView);
        mRvDividendReport.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRvDividendReport.setLayoutManager(mLayoutManager);
        mElsstAdapter = new FragElssAdapter(getActivity(), "type_user", new ArrayList<JSONObject>(), new FragElssAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                JSONObject jsonObject = mElsstAdapter.mDataList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("data", jsonObject.toString());
                bundle.putString("year", year+"");
                bundle.putString("finYear",  Previous_Year.getText().toString()+"-"+Next_Year.getText().toString());
                mMainActivity.displayViewOther(74, bundle);
            }
        });
        mRvDividendReport.setAdapter(mElsstAdapter);

        // check feature permission feature1011 if exist then show download
        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
        boolean isShowDownload = false;
        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
            JSONObject mJsoObject = null;
            try {
                mJsoObject = new JSONObject(allowedFeatured);
                JSONArray jsonArray = mJsoObject.optJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    if (jsonArray.optJSONObject(i).has("feature1011")) {
                        isShowDownload = true;
                        break;
                    }
                }
                setUpToolBar(isShowDownload);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }


        Previous_Year_img = view.findViewById(R.id.previous_year);
        Next_Year_img = view.findViewById(R.id.next_year);
        Next_Year = view.findViewById(R.id.next_year_txt);
        Previous_Year = view.findViewById(R.id.previous_year_txt);
        Next_Year = view.findViewById(R.id.next_year_txt);
        year = c.get(Calendar.YEAR);
        next_year = year - 1;
        if (c.get(Calendar.MONTH) > 2) {
            next_year = next_year + 1;
            year = year + 1;
        }
        Previous_Year.setText("" + next_year);
        Next_Year.setText("" + year);
        Previous_Year_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year = year - 1;
                next_year = next_year - 1;
                Previous_Year.setText("" + next_year);
                Next_Year.setText("" + year);
                getELSSReport();
            }
        });

        Next_Year_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year = year + 1;
                next_year = next_year + 1;
                Previous_Year.setText("" + next_year);
                Next_Year.setText("" + year);
                getELSSReport();
            }
        });
        getELSSReport();

        Bundle bundle = getArguments();
        if (bundle!=null && bundle.containsKey("action")){
            String actionType = bundle.getString("action");
            if (actionType.equalsIgnoreCase("download")){
                downloadFile3();
            }
        }

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
//                downloadFile2();
                downloadFile3();
}
    }
    private void getELSSReport() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        mRvDividendReport.setVisibility(View.GONE);
        singleShedow.setVisibility(View.GONE);
        fullScreenShedow.setVisibility(View.VISIBLE);
        mTvNothing.setVisibility(View.GONE);

        if (c.get(Calendar.YEAR) == Integer.parseInt(Previous_Year.getText().toString())) {
            Next_Year_img.setVisibility(View.INVISIBLE);
        } else {

            Next_Year_img.setVisibility(View.VISIBLE);
        }
        String url = "";

        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ELSS_REPORT_CLIENT + "year=" + year
                    + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);
            /**
             * https://spvithlani.investwell.app/webapi/client/reports/getElssProcurementData?year=2023&investorUid=d849fef6041d14fc1dc2aa7677689ef2&selectedUser={"uid":"d849fef6041d14fc1dc2aa7677689ef2","levelNo":"98"}
             */
          /*  if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_ELSS_REPORT_CLIENT + "year=" + year
                        + "&investorUid=" + uId + "&selectedUser=" + jsonObjectUID.toString();
            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_ELSS_REPORT_CLIENT + "year=" + year;
            }*/

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        List<JSONObject> list = new ArrayList<>();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject object = jsonArray.optJSONObject(i);
                                    list.add(object);
                                }

                            } else {

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            mRvDividendReport.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mElsstAdapter.updateList(list);
                                mTvNothing.setVisibility(View.GONE);
                            } else {
                                mTvNothing.setVisibility(View.VISIBLE);
                                mElsstAdapter.updateList(list);
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRvDividendReport.setVisibility(View.VISIBLE);

                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        if (mBrokerActivity != null)
            requestQueue = Volley.newRequestQueue(mBrokerActivity);
        else
            requestQueue = Volley.newRequestQueue(mMainActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void downloadFile3(){
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        if (c.get(Calendar.YEAR) == Integer.parseInt(Previous_Year.getText().toString())) {
            Next_Year_img.setVisibility(View.INVISIBLE);
        } else {

            Next_Year_img.setVisibility(View.VISIBLE);
        }

        String url = "";
        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ELSS_REPORT_CLIENT_PDF + "year=" + year
                    + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        }catch (Exception e){

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "ELSSStatement","", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(requireActivity(), getString(R.string.txt_successfully), getString(R.string.txt_elss_report_download_successfully), "pdf", mFileSave,uri);
                        else {
                            mMainActivity.showCommonDownload(requireActivity(), getString(R.string.txt_successfully), getString(R.string.txt_elss_report_download_successfully), "pdf", mFileSave, uri);
                        }
                    }
                });

    }



    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions){
            requestMultiPermissions(permissionList);
        }
    }


    private void requestMultiPermissions( String[] permissionList){
        List<String> permissionsToRequest = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)){

        }else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
//            downloadFile2();
            downloadFile3();
        }
    });
}
