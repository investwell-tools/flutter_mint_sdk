package investwell.client.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.client.fragments.mandate.BseMandateFormActivity;
import investwell.client.fragments.mandate.NseMandateFormActivity;
import investwell.utils.AppSession;
import investwell.utils.Utils;


/**0
0.

 -* Created by binesh on 8/5/18.
 */

public class RecycleBankAdapter extends RecyclerView.Adapter<RecycleBankAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private RecycleBankAdapter.OnItemClickListener listener;
    private int mWidth = 0, mHeight = 0;
    private RecyclerView.LayoutParams params;
    private String mType = "";
    private String mTransactionType = "";
    private NumberFormat format;
    public HashMap<Integer, Boolean> mHashSelection = new HashMap<>();
    private AppSession mSession;


    public RecycleBankAdapter(Context context, ArrayList<JSONObject> list, int width, RecycleBankAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mWidth = width;

        format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycle_view_bank_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {

        return mDataList.size();

    }

    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mType = type;
        for (int i = 0; i < list.size(); i++) {
            if (i == 0)
                mHashSelection.put(i, true);
            else
                mHashSelection.put(i, false);

        }
        notifyDataSetChanged();
    }

    public void updateForSipMandate(List<JSONObject> list, String type, String transactionType) {
        mDataList.clear();
        mDataList.addAll(list);
        mType = type;
        mTransactionType = transactionType;
        for (int i = 0; i < list.size(); i++) {
            if (i == 0)
                mHashSelection.put(i, true);
            else
                mHashSelection.put(i, false);

        }
        notifyDataSetChanged();
    }


    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvText1, tvText2, tvText3, tvText4;
        TextView tvLevel1, tvLevel2, tvLevel3, tvLevel4, tvMessage, tv_create_mendate, tvMandateStatus;
        LinearLayout liner4,ll_status;
        RelativeLayout relMain, relNoMandate;
        ImageView ivSelected;


        public ViewHolder(View view) {
            super(view);
            tvText1 = view.findViewById(R.id.tvText1);
            tvText2 = view.findViewById(R.id.tvText2);
            tvText3 = view.findViewById(R.id.tvText3);
            tvText4 = view.findViewById(R.id.tvText4);
            tvLevel1 = view.findViewById(R.id.tvLevel1);
            tvLevel2 = view.findViewById(R.id.tvLevel2);
            tvLevel3 = view.findViewById(R.id.tvLevel3);
            tvLevel4 = view.findViewById(R.id.tvLevel4);
            liner4 = view.findViewById(R.id.liner4);
            relMain = view.findViewById(R.id.relMain);
            ivSelected = view.findViewById(R.id.ivSelected);
            relNoMandate = view.findViewById(R.id.relNoMandate);
            tvMessage = view.findViewById(R.id.tvMessage);
            tv_create_mendate = view.findViewById(R.id.tv_create_mendate);
            tvMandateStatus = view.findViewById(R.id.tvMandateStatus);

            params = (RecyclerView.LayoutParams) view.getLayoutParams();
            params.width = mWidth - 150;
            ll_status = view.findViewById(R.id.ll_status);
            view.setLayoutParams(params);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                JSONObject jsonObject = mDataList.get(position);
                tv_create_mendate.setVisibility(View.GONE);
                if (mType.equalsIgnoreCase("Mandate")) {
                    if (jsonObject.length() != 0){
                        ll_status.setVisibility(View.VISIBLE);

                        liner4.setVisibility(View.VISIBLE);
                        tvLevel1.setText(mContext.getString(R.string.Bank_Name));
                        tvLevel2.setText(mContext.getString(R.string.txt_Amount));
                        tvLevel3.setText(mContext.getString(R.string.txt_Mandate_Code));
                        tvLevel4.setText(mContext.getString(R.string.txt_AccountNumber));

                        tvText1.setText(jsonObject.optString("bankName"));
                        tvText3.setText(jsonObject.optString("mandateCode"));
                        tvText4.setText(jsonObject.optString("accNo"));

                        int amount = jsonObject.optInt("amount");
                        String strPurchaseValue = format.format(amount);
                        tvText2.setText(strPurchaseValue);

                        relNoMandate.setVisibility(View.GONE);
                        relMain.setVisibility(View.VISIBLE);
                        String status = jsonObject.optString("mandateStatus");
                        if (status != null && status.length() > 0) {
                            if (status.equalsIgnoreCase("approved") || status.equalsIgnoreCase("ACCEPTED")) {
                                tvMandateStatus.setTextColor(ContextCompat.getColor(mContext, R.color.green));
                            } else {
                                tvMandateStatus.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                            }
                            tvMandateStatus.setText(mContext.getString(R.string.mandate_status) + status);

                        } else {
                            tvMandateStatus.setTextColor(ContextCompat.getColor(mContext, R.color.red));
                            tvMandateStatus.setText(mContext.getString(R.string.not_available));
                        }

                    }else{
                        ll_status.setVisibility(View.GONE);

                        relNoMandate.setVisibility(View.VISIBLE);
                        relMain.setVisibility(View.GONE);
                        tvMessage.setText(R.string.mendate_list_no_mandate_found_txt);
                        tv_create_mendate.setVisibility(View.VISIBLE);
                        relNoMandate.setOnClickListener(view -> {
                            if (Utils.getSelectedExchange(mSession).equals("1")) {
                               // OnBoardNewNseTransactionActivity onBoardNewNseTransactionActivity = (OnBoardNewNseTransactionActivity) mContext;
                                Intent intent = new Intent(mContext, NseMandateFormActivity.class);
                                intent.putExtra("result", ""+ AppApplication.sIinProfileObject);
                                intent.putExtra("fromNavigationPoint", "profile");
                                mContext.startActivity(intent);
                            } else if (Utils.getSelectedExchange(mSession).equals("2")) {
                                Intent intent = new Intent(mContext, BseMandateFormActivity.class);
                                intent.putExtra("result", ""+ AppApplication.sBseProfileObject);
                                intent.putExtra("fromNavigationPoint", "profile");
                                mContext.startActivity(intent);
                            }
                        });
                    }

                } else if (mType.equalsIgnoreCase("bankBSE")) {
                    ll_status.setVisibility(View.GONE);

                    if (jsonObject.length() != 0){
                        relNoMandate.setVisibility(View.GONE);
                        relMain.setVisibility(View.VISIBLE);

                        tvLevel1.setText(mContext.getString(R.string.Bank_Name));
                        tvLevel2.setText(mContext.getString(R.string.ifsc));
                        tvLevel3.setText(mContext.getString(R.string.txt_AccountNumber));
                        tvLevel4.setText(mContext.getString(R.string.txt_AccountType));

                        tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("bankName")));
                        tvText2.setText(jsonObject.optString("neftOrIfscCode"));
                        tvText3.setText(jsonObject.optString("accountNo"));
                        tvText4.setText(jsonObject.optString("accountType"));
                    }else{
                        relNoMandate.setVisibility(View.VISIBLE);
                        relMain.setVisibility(View.GONE);
                        tvMessage.setText(R.string.bank_list_no_found_txt);
                    }

                }else if (mType.equalsIgnoreCase("bankMFU")) {
                    if (jsonObject.length() != 0){
                        relNoMandate.setVisibility(View.GONE);
                        relMain.setVisibility(View.VISIBLE);
                        /*"accNo":"531610017039",
"proof":"77",
"accType":"SB",
"bankCode":"240",
"bankName":"HDFC BANK",
"ifscCode":"HDFC0000053",
"micrCode":"560240004",
"defaultAccountFlag":"Y"*/

                        tvLevel1.setText(mContext.getString(R.string.Bank_Name));
                        tvLevel2.setText(mContext.getString(R.string.ifsc));
                        tvLevel3.setText(mContext.getString(R.string.txt_AccountNumber));
                        tvLevel4.setText(mContext.getString(R.string.txt_AccountType));

                        tvText1.setText(Utils.setFirstLetterCapital(jsonObject.optString("bankName")));
                        tvText2.setText(jsonObject.optString("neftOrIfscCode"));
                        tvText3.setText(jsonObject.optString("accountNo"));
                        tvText4.setText(jsonObject.optString("accountType"));
                    }else{
                        relNoMandate.setVisibility(View.VISIBLE);
                        relMain.setVisibility(View.GONE);
                        tvMessage.setText(R.string.bank_list_no_found_txt);
                    }

                } else {
                    if (jsonObject.length() != 0) {
                        relNoMandate.setVisibility(View.GONE);
                        relMain.setVisibility(View.VISIBLE);

                        tvLevel1.setText(mContext.getString(R.string.Bank_Name));
                        tvLevel2.setText(mContext.getString(R.string.txt_AccountNumber));
                        tvLevel3.setText(mContext.getString(R.string.Bank_Branch));
                        liner4.setVisibility(View.GONE);

                        tvText1.setText(jsonObject.optString("bankName"));
                        tvText2.setText(jsonObject.optString("accNo"));
                        tvText3.setText(Utils.setFirstLetterCapital(jsonObject.optString("bankBranch")));

                    }else{
                        relNoMandate.setVisibility(View.VISIBLE);
                        relMain.setVisibility(View.GONE);
                        tvMessage.setText(R.string.bank_list_no_found_txt);
                    }
                }

                if (mHashSelection.get(position) == true) {
                    relMain.setBackgroundResource(R.drawable.selected_payment_mode);
                    ivSelected.setVisibility(View.VISIBLE);
                } else {
                    relMain.setBackgroundResource(R.drawable.unselcted_bank);
                    ivSelected.setVisibility(View.GONE);
                }


                relMain.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (mType.equalsIgnoreCase("Mandate") && mTransactionType.equalsIgnoreCase("sip")) {
                            return;
                        }
                        if (mHashSelection.get(position) == true) {
                            relMain.setBackgroundResource(R.drawable.unselcted_bank);
                            ivSelected.setVisibility(View.GONE);
                            for (int i = 0; i < mHashSelection.size(); i++) {
                                mHashSelection.put(i, false);
                            }
                            notifyDataSetChanged();

                        } else {
                            relMain.setBackgroundResource(R.drawable.selected_payment_mode);
                            ivSelected.setVisibility(View.VISIBLE);
                            for (int i = 0; i < mHashSelection.size(); i++) {
                                mHashSelection.put(i, false);
                            }
                            mHashSelection.put(position, true);
                            notifyDataSetChanged();

                        }
                        listener.onItemClick(position);

                    }
                });

              /*  itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onItemClick(position);
                    }
                });*/
            } catch (
                    Exception e) {

            }


        }

    }


}
