package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FragPortfolioFdADapter extends RecyclerView.Adapter<FragPortfolioFdADapter.MyViewHolder> {


    private ArrayList<JSONObject> jsonObjects;
    Context context;
    private AppSession mSession;
    private ClientActivity mActivity;


    public FragPortfolioFdADapter(Context context, ArrayList<JSONObject> jsonObjects) {

        this.context = context;
        this.jsonObjects = jsonObjects;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.frag_portfolio_fd_adapter, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        mActivity = (ClientActivity) context;

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);
/*"applicantName":"Garima",
"appid":"6ea53026e4281094d952cdc50e770738",
"fixedAssetName":"Bajaj Finance Ltd",
"scheme":"Bajaj Finance Ltd",
"allotmentDate":"2013-08-13T18:30:00.000Z",
"maturityDate":"2030-06-19T18:30:00.000Z",
"fdType":"Half Yearly Payout",
"fixedSubAssetid":"560843d710948e801280257b2d23a96c",
"rateOfInterest":7,
"day":67,
"month":200,
"purchaseValue":25000,
"currentValue":25000,
"dividend":10567.12,
"avgHoldingDays":2203,
"gain":10567.120000000003,
"absoluteReturn":42.26848000000001,
"CAGR":6.015052251177888*/

        final JSONObject jsonObject = jsonObjects.get(position);
        mSession = AppSession.getInstance(context);

        holder.mTvName.setText(jsonObject.optString("applicantName"));
        holder.mTvSchemeName.setText(jsonObject.optString("scheme"));

        double currentValue = jsonObject.optDouble("purchaseValue");
        String strCurrentAmount = format.format(currentValue);
        holder.mTvInvest.setText(strCurrentAmount);

        double purchaseValue = jsonObject.optDouble("currentValue");
        String strPurchaseValue = format.format(purchaseValue);
        holder.mTvCurrent.setText(strPurchaseValue);

        double devidenValue = jsonObject.optDouble("dividend");
        String strDEdidentValue = format.format(devidenValue);
        holder.mTvInterest.setText(strDEdidentValue);

        double gaine = jsonObject.optDouble("gain");
        String strGain = format.format(gaine);
        holder.mTvGain.setText(strGain);

        double cgrValue = jsonObject.optDouble("CAGR");
        String data2 = String.format("%.2f", cgrValue) + "%";
        holder.mTvCgar.setText(data2);

        double returnValue = jsonObject.optDouble("absoluteReturn");
        String stReturnValue = String.format("%.2f", returnValue) + "%";
        holder.mTvREturn.setText(stReturnValue);



        holder.top_linear_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("applicant_name", jsonObject.optString("applicantName"));
                bundle.putString("appid", jsonObject.optString("appid"));
                bundle.putString("folioid", jsonObject.optString("folioid"));
               // mActivity.displayViewOther(5, bundle);


            }
        });


    }

    @Override
    public int getItemCount() {

        return jsonObjects.size();
    }

    public void updateList(List<JSONObject> list) {

        jsonObjects.clear();
        jsonObjects.addAll(list);
        notifyDataSetChanged();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView mTvSchemeName, mTvName, mTvInvest, mTvCurrent, mTvInterest, mTvGain, mTvREturn, mTvCgar;
        LinearLayout top_linear_layout;

        public MyViewHolder(View view) {
            super(view);

            mTvSchemeName = view.findViewById(R.id.tvSchemeName);
            mTvName = view.findViewById(R.id.tvName);
            mTvInvest = view.findViewById(R.id.tvInvestment);
            mTvCurrent = view.findViewById(R.id.tvCurrent);
            mTvREturn = view.findViewById(R.id.tvReturn);
            mTvInterest = view.findViewById(R.id.tvInterest);
            mTvGain = view.findViewById(R.id.tvGain);
            mTvCgar = view.findViewById(R.id.tvCagr);
            top_linear_layout = view.findViewById(R.id.top_linear_layout);

        }
    }

}
