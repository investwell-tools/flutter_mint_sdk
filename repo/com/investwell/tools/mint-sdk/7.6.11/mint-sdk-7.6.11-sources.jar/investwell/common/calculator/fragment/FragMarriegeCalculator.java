package investwell.common.calculator.fragment;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.calculator.utils.AudioPlayer;
import investwell.common.calculator.utils.RoundKnobButton;
import investwell.common.calculator.utils.Singleton;
import investwell.common.calculator.utils.Utils;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;


public class FragMarriegeCalculator extends BaseFragment implements View.OnClickListener,
        View.OnTouchListener, RoundKnobButton.RoundKnobButtonListener, ToolbarFragment.ToolbarCallback {

    private final long DELAY = 1000; // milliseconds
    Singleton m_Inst = Singleton.getInstance();
    double dblChildAge = 0, dblMrgCost = 0, dblYrlySaving = 0, dblExpReturnRate = 0, dblExtInflammation = 0, dblMrgAge = 0;
    double dblTymLeft = 0, dblExistingCorpus = 0, dblExistingGrowth = 0, futureSaving = 0;
    double add_fund = 0, add_sav = 0, inflammationCost = 0, onetimeinv = 0, monthlyinv = 0, yearlyinv = 0;
    private EditText mEtPresentAge, mEtMarrigeAge, mEtWeddingCost, mEtSaving, mEtExitingCurpus, mEtExpectedRate, mEtExpectedInflation;
    private TextView mTvTitle, mTvText2, mTvText3, mTvText4, mTvResult4, mTvResult1, mTvResult2, mTvImageTitle;
    private RelativeLayout mLinerResult;
    private ImageView mIvImageRight, mIvRefresh, mIvBack;
    private int mCount1 = 0, mCount2 = 0, mCount3 = 0, mCount4 = 0, mCount5 = 0, mCount6 = 0;
    private AudioPlayer audioPlayer;
    private ScrollView mScrollView;
    private RoundKnobButton mDailerInvest1, mDailerInvest2, mDailerInvest3, mDailerInvest4, mDailerInvest5, mDailerInvest6, mDailerInvest7;
    private LinearLayout mLinerResultPart;
    private ConstraintLayout mClCalcFooter;
    private Timer timer = new Timer();
    private ClientActivity mActivity;
    private AppApplication mApplication;
    private RelativeLayout mRelToolbar;
    private Bundle bundle;
    private ToolbarFragment fragToolBar;
    private AppTextViewTitle tvHeaderTitle;
    private LinearLayout ll_calculator_header;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private TextView mTvAppName, mTvWebsite, mTvEmail, mTvAddress, mTvPhone, mTvSlogan;
    private ImageView mIvAppLogo;

    private TextView mTvChildAgeError, mTvChildMarriageAgeError, mTvMarriageCostError, mTvExpectedRorError, mTvExpectedInflationRateError;

    @Override
    public void onResume() {
        super.onResume();
   /*     if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mActivity.setMainVisibility(this, null);
            mSession = AppSession.getInstance(mActivity);
            mApplication = (AppApplication) mActivity.getApplication();

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_cal_marriege, container, false);
        bundle = getArguments();
        if (mBrokerActivity != null) {
            m_Inst.InitGUIFrame(mBrokerActivity);

        } else {
            m_Inst.InitGUIFrame(mActivity);

        }
        audioPlayer = new AudioPlayer();
        mIvAppLogo = view.findViewById(R.id.iv_app_logo);
        mRelToolbar = view.findViewById(R.id.relToolBar);
        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        ll_calculator_header = view.findViewById(R.id.ll_calculator_header);
        mTvSlogan = view.findViewById(R.id.tvSlogan);

        setUpToolBar();
        mEtPresentAge = view.findViewById(R.id.edit1);
        mEtMarrigeAge = view.findViewById(R.id.edit2);
        mEtWeddingCost = view.findViewById(R.id.edit3);
        mEtSaving = view.findViewById(R.id.edit4);
        mEtExitingCurpus = view.findViewById(R.id.edit5);
        mEtExpectedRate = view.findViewById(R.id.edit6);
        mEtExpectedInflation = view.findViewById(R.id.edit7);
        mScrollView = view.findViewById(R.id.scrollView);
        mTvImageTitle = view.findViewById(R.id.tvImageTitle);
        mClCalcFooter = view.findViewById(R.id.cl_calc_footer);
        mClCalcFooter.setVisibility(View.GONE);
        mLinerResultPart = view.findViewById(R.id.linerResultPart);

        mTvChildAgeError = view.findViewById(R.id.tvChildAgeError);
        mTvChildMarriageAgeError = view.findViewById(R.id.tvChildMarriageAgeError);
        mTvMarriageCostError = view.findViewById(R.id.tvMarriageCostError);
        mTvExpectedRorError = view.findViewById(R.id.tvExpectedRorError);
        mTvExpectedInflationRateError = view.findViewById(R.id.tvExpectedInflationRateError);


        mScrollView = view.findViewById(R.id.scrollView);

        mTvTitle = view.findViewById(R.id.textView1);
        mTvText2 = view.findViewById(R.id.textView2);
        mTvText3 = view.findViewById(R.id.textView3);
        mTvText4 = view.findViewById(R.id.textView4);

        mTvResult1 = view.findViewById(R.id.tvResult);
        mTvResult2 = view.findViewById(R.id.tvResult2);


        mLinerResult = view.findViewById(R.id.linerResult);

        mTvAddress = view.findViewById(R.id.tvAddress);
        mTvAppName = view.findViewById(R.id.tvApp_name);
        mTvPhone = view.findViewById(R.id.call);
        mTvWebsite = view.findViewById(R.id.web);
        mTvEmail = view.findViewById(R.id.email);
        setupFooter();

       /* TextViewtoolbar_title_left = view.findViewById(R.id.toolbar_title_left);
        toolbar_title_left.setText("Marriage Calculator");*/


        view.findViewById(R.id.lumpsum_btn).setOnClickListener(this);
        view.findViewById(R.id.sip_btn).setOnClickListener(this);

        mDailerInvest1 = view.findViewById(R.id.dialer1);
        mDailerInvest2 = view.findViewById(R.id.dialer2);
        mDailerInvest3 = view.findViewById(R.id.dialer3);
        mDailerInvest4 = view.findViewById(R.id.dialer4);
        mDailerInvest5 = view.findViewById(R.id.dialer5);
        mDailerInvest6 = view.findViewById(R.id.dialer6);
        mDailerInvest7 = view.findViewById(R.id.dialer7);
        if (mBrokerActivity != null) {
            mDailerInvest1.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest5.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest6.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest7.RoundKnobButton2(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        } else {
            mDailerInvest1.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest5.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest6.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest7.RoundKnobButton2(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        }
        mDailerInvest1.setOnTouchListener(this);
        mDailerInvest2.setOnTouchListener(this);
        mDailerInvest3.setOnTouchListener(this);
        mDailerInvest4.setOnTouchListener(this);
        mDailerInvest5.setOnTouchListener(this);
        mDailerInvest6.setOnTouchListener(this);
        mDailerInvest7.setOnTouchListener(this);


        if (bundle != null && bundle.containsKey("viewLayout"))
            view.findViewById(R.id.button_layout).setVisibility(View.VISIBLE);

        mDailerInvest1.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtPresentAge.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtPresentAge.getText().toString());
                        int collegeStart = Integer.parseInt(mEtMarrigeAge.getText().toString());
                        int updateValue = 0;


                        if (mCount1 != percentage) {
                            if (percentage > mCount1) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount1) {
                                updateValue = (currentValue - 1);
                            }

                            mCount1 = percentage;
                            if (currentValue < collegeStart || updateValue < collegeStart) {
                                if (updateValue < 2) {
                                    mEtPresentAge.setText("" + 1);
                                } else {
                                    mEtPresentAge.setText("" + updateValue);
                                }

                                if (mBrokerActivity != null) {
                                    audioPlayer.play(mBrokerActivity);
                                } else {
                                    audioPlayer.play(mActivity);
                                }
                                calculateAmount();

                            } else {
                                mApplication.showSnackBar(mEtPresentAge, getResources().getString(R.string.marriage_cal_error_child_age));

                            }

                        }


                    }
                });
            }
        });

        mDailerInvest2.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtMarrigeAge.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtMarrigeAge.getText().toString());
                        int presentAge = Integer.parseInt(mEtPresentAge.getText().toString());
                        int updateValue = 0;

                        if (mCount2 != percentage) {
                            if (percentage > mCount2) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount2) {
                                updateValue = (currentValue - 1);
                            }

                            mCount2 = percentage;
                            if (currentValue > presentAge || updateValue > presentAge) {

                                if (updateValue < 18)
                                    mEtMarrigeAge.setText("" + 18);
                                else if (updateValue > 35)
                                    mEtMarrigeAge.setText("" + 35);
                                else
                                    mEtMarrigeAge.setText("" + updateValue);

                                if (mBrokerActivity != null) {
                                    audioPlayer.play(mBrokerActivity);
                                } else {
                                    audioPlayer.play(mActivity);
                                }
                                calculateAmount();

                            } else {
                                mApplication.showSnackBar(mEtPresentAge, getResources().getString(R.string.marriage_cal_error_wedding_age));
                            }
                        }

                    }
                });
            }
        });

        mDailerInvest3.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
            }

            public void onRotate(final int percentage) {
                mEtWeddingCost.post(new Runnable() {
                    public void run() {
                        long currentValue = Long.parseLong(mEtWeddingCost.getText().toString().replaceAll(",", "").toString());
                        long updateValue = 0;
                        if (mCount3 != percentage) {
                            if (percentage > mCount3) {
                                updateValue = (currentValue + 10000);
                            } else if (percentage < mCount3) {
                                updateValue = (currentValue - 10000);
                            }

                            mCount3 = percentage;
                            if (updateValue < 100000)
                                mEtWeddingCost.setText("" + 100000);
                            else
                                mEtWeddingCost.setText("" + updateValue);

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }

                    }
                });
            }
        });


        mDailerInvest4.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtSaving.post(new Runnable() {
                    public void run() {
                        long currentValue = Long.parseLong(mEtSaving.getText().toString().replaceAll(",", "").toString());
                        long updateValue = 0;
                        if (mCount4 != percentage) {
                            if (percentage > mCount4) {
                                updateValue = (currentValue + 1000);
                            } else if (percentage < mCount4) {
                                updateValue = (currentValue - 1000);
                            }

                            mCount4 = percentage;
                            if (updateValue < 1000)
                                mEtSaving.setText("" + 0);
                            else
                                mEtSaving.setText("" + updateValue);

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });

        mDailerInvest5.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {

                mEtExitingCurpus.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtExitingCurpus.getText().toString().replaceAll(",", "").toString());
                        int updateValue = 0;
                        if (mCount5 != percentage) {
                            if (percentage > mCount5) {
                                updateValue = (currentValue + 10000);
                            } else if (percentage < mCount5) {
                                updateValue = (currentValue - 10000);
                            }

                            mCount5 = percentage;
                            if (updateValue < 10000) {
                                mEtExitingCurpus.setText("" + 0);
                            } else {
                                mEtExitingCurpus.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });
            }
        });


        mDailerInvest6.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtExpectedRate.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtExpectedRate.getText().toString());
                        double updateValue = 0;
                        if (mCount6 != percentage) {
                            if (percentage > mCount6) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount6) {
                                updateValue = (currentValue - 1);
                            }

                            mCount6 = percentage;
                            if (updateValue < 1) {
                                mEtExpectedRate.setText("" + 1.00);
                            } else if (updateValue > 100) {
                                mEtExpectedRate.setText("" + 100.00);
                            } else {
                                mEtExpectedRate.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }

                    }
                });
            }
        });

        mDailerInvest7.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtExpectedInflation.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtExpectedInflation.getText().toString());
                        double updateValue = 0;
                        if (mCount6 != percentage) {
                            if (percentage > mCount6) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount6) {
                                updateValue = (currentValue - 1);
                            }

                            mCount6 = percentage;
                            if (updateValue < 1) {
                                mEtExpectedInflation.setText("" + 1.00);
                            } else if (updateValue > 30) {
                                mEtExpectedInflation.setText("" + 20.00);
                            } else {
                                mEtExpectedInflation.setText("" + updateValue);
                            }

                            if (mBrokerActivity != null) {
                                audioPlayer.play(mBrokerActivity);
                            } else {
                                audioPlayer.play(mActivity);
                            }
                            calculateAmount();
                        }


                    }
                });

            }
        });
        mEtPresentAge.addTextChangedListener(new GenericTextWatcher(mEtPresentAge));
        mEtMarrigeAge.addTextChangedListener(new GenericTextWatcher(mEtMarrigeAge));
        mEtWeddingCost.addTextChangedListener(new GenericTextWatcher(mEtWeddingCost));
        mEtSaving.addTextChangedListener(new GenericTextWatcher(mEtSaving));
        mEtExitingCurpus.addTextChangedListener(new GenericTextWatcher(mEtExitingCurpus));
        mEtExpectedRate.addTextChangedListener(new GenericTextWatcher(mEtExpectedRate));
        mEtExpectedInflation.addTextChangedListener(new GenericTextWatcher(mEtExpectedInflation));
        calculateAmount();
        return view;
    }

    private void setupFooter() {
        setTintColorIfDark(requireActivity(), mIvAppLogo);
        mIvAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getResources().getString(R.string.subdomain).equals("mint")) {
            if (mSession.getHasLoging()) {
                if (!TextUtils.isEmpty(mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")) {
                    Picasso.get().load(mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                    mIvAppLogo.setVisibility(View.VISIBLE);
                } else {
                    mIvAppLogo.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")) {
                    mTvAddress.setText(mSession.getAddress());
                    mTvAddress.setVisibility(View.VISIBLE);
                } else {
                    mTvAddress.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")) {
                    mTvWebsite.setText(mSession.getWebsite());
                    mTvWebsite.setVisibility(View.VISIBLE);
                } else {
                    mTvWebsite.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")) {
                    mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                    mTvPhone.setVisibility(View.VISIBLE);
                } else {
                    mTvPhone.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")) {
                    mTvEmail.setText(mSession.getUserEmail());
                    mTvEmail.setVisibility(View.VISIBLE);
                } else {
                    mTvEmail.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")) {
                    mTvAppName.setText(mSession.getCompanyName());
                    mTvAppName.setVisibility(View.VISIBLE);
                } else {
                    mTvAppName.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                    mTvSlogan.setText(mSession.getSloganOnLogo());
                    mTvSlogan.setVisibility(View.VISIBLE);
                }else{
                    mTvSlogan.setVisibility(View.GONE);
                }
            } else {
                if (!TextUtils.isEmpty(mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")) {
                    Picasso.get().load(mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                }
                mTvAddress.setText(getResources().getString(R.string.locatetext));
                mTvWebsite.setText(getResources().getString(R.string.website));
                mTvPhone.setText(getResources().getString(R.string.image_phone));
                mTvEmail.setText(getResources().getString(R.string.support_email_address));
                mTvAppName.setText(getString(R.string.app_name));
                mTvSlogan.setText(mSession.getSloganOnLogo());

            }
        } else {

            mIvAppLogo.setVisibility(View.VISIBLE);
            int squareLogo = UtilityKotlin.checkExistResources("app_logo_square", "mipmap", requireContext());
            int circleLogo = UtilityKotlin.checkExistResources("app_logo_round", "mipmap", requireContext());
            if (squareLogo != 0) {
                mIvAppLogo.setImageResource(squareLogo);
            } else if (circleLogo != 0) {
                mIvAppLogo.setImageResource(circleLogo);
            } else {
                mIvAppLogo.setImageResource(R.mipmap.app_logo);
            }
            if (!TextUtils.isEmpty(mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")) {
                mTvAddress.setText(mSession.getAddress());
                mTvAddress.setVisibility(View.VISIBLE);
            } else {
                mTvAddress.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")) {
                mTvWebsite.setText(mSession.getWebsite());
                mTvWebsite.setVisibility(View.VISIBLE);
            } else {
                mTvWebsite.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")) {
                mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                mTvPhone.setVisibility(View.VISIBLE);
            } else {
                mTvPhone.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")) {
                mTvEmail.setText(mSession.getUserEmail());
                mTvEmail.setVisibility(View.VISIBLE);
            } else {
                mTvEmail.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")) {
                mTvAppName.setText(mSession.getCompanyName());
                mTvAppName.setVisibility(View.VISIBLE);
            } else {
                mTvAppName.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                mTvSlogan.setText(mSession.getSloganOnLogo());
                mTvSlogan.setVisibility(View.VISIBLE);
            }else{
                mTvSlogan.setVisibility(View.GONE);
            }

        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.toolBar_title_marriage_cal),
                    true, true, false, false, true, false, false);

            fragToolBar.setCallback(this);
        }
        tvHeaderTitle.setText(getResources().getString(R.string.toolBar_title_marriage_cal));
    }

    @Override
    public void onStateChange(boolean newstate) {

    }

    @Override
    public void onRotate(int percentage) {

    }

    @Override
    public void onClick(View view) {
        int duration = Integer.parseInt(mEtMarrigeAge.getText().toString()) - Integer.parseInt(mEtPresentAge.getText().toString());
        Bundle bundle = new Bundle();
       /* if (view.getId() == R.id.ivRight) {
            saveFrameLayout();
        } *//*else if (view.getId() == R.id.ivRight2) {
            refreshView();
        } *//*else if (view.getId() == R.id.ivLeft) {
            mActivity.getSupportFragmentManager().popBackStack();
        }*/
        if (view.getId() == R.id.lumpsum_btn) {
            bundle.putString("type", "coming_from_goal");
            bundle.putString("investment_type", "Lumpsum");
            bundle.putString("ic_invest_route_goal", "Marriage Planning");
            bundle.putString("Amount", mTvResult1.getText().toString());
            bundle.putInt("duration", duration);
            if (mBrokerActivity != null) {
                mBrokerActivity.displayViewOther(64, bundle);
            } else {
                mActivity.displayViewOther(64, bundle);
            }
            System.out.println(bundle.toString());

        } else if (view.getId() == R.id.sip_btn) {
            bundle.putString("type", "coming_from_goal");
            bundle.putString("investment_type", "SIP");
            bundle.putString("ic_invest_route_goal", "Marriage Planning");
            bundle.putString("Amount", mTvResult2.getText().toString());
            bundle.putInt("duration", duration);
            if (mBrokerActivity != null) {
                mBrokerActivity.displayViewOther(64, bundle);
            } else {
                mActivity.displayViewOther(64, bundle);
            }
        }

    }

    private void refreshView() {
        mDailerInvest1.setRotorPercentage(0);
        mDailerInvest2.setRotorPercentage(0);
        mDailerInvest3.setRotorPercentage(0);
        mDailerInvest4.setRotorPercentage(0);
        mDailerInvest5.setRotorPercentage(0);
        mDailerInvest6.setRotorPercentage(0);
        mDailerInvest7.setRotorPercentage(0);

        mEtPresentAge.setText("2");
        mEtMarrigeAge.setText("25");
        mEtWeddingCost.setText("5");
        mEtSaving.setText("0");
        mEtExitingCurpus.setText("0");
        mEtWeddingCost.setText("500000");
        mEtExpectedRate.setText("12.00");
        mEtExpectedInflation.setText("6.00");
        calculateAmount();
    }


    private void delayCall() {
        timer.cancel();
        timer = new Timer();
        timer.schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        if (mBrokerActivity != null) {
                            mBrokerActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });

                        } else {
                            mActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });
                        }
                    }
                },
                DELAY
        );
    }

    private void calculateAmount() {
        mTvChildAgeError.setVisibility(View.GONE);
        mTvChildMarriageAgeError.setVisibility(View.GONE);
        mTvMarriageCostError.setVisibility(View.GONE);
        mTvExpectedRorError.setVisibility(View.GONE);
        mTvExpectedInflationRateError.setVisibility(View.GONE);


        if (mBrokerActivity != null) {
            if (mEtPresentAge.getText().toString().equals("")) {
//                mBrokerActivity.showCommonDialog(mBrokerActivity, "Not Valid", getResources().getString(R.string.education_calculator_error_empty_child_age));
                mTvChildAgeError.setVisibility(View.VISIBLE);
                mTvChildAgeError.announceForAccessibility(getResources().getString(R.string.education_calculator_error_empty_child_age));
                mTvChildAgeError.setText(getResources().getString(R.string.education_calculator_error_empty_child_age));
            } else if (mEtMarrigeAge.getText().toString().equals("")) {
                mTvChildMarriageAgeError.setVisibility(View.VISIBLE);
                mTvChildMarriageAgeError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_empty_start_wed_age));
                mTvChildMarriageAgeError.setText(getResources().getString(R.string.marriage_cal_error_empty_start_wed_age));
            } else if (Integer.parseInt(mEtPresentAge.getText().toString()) > Integer.parseInt(mEtMarrigeAge.getText().toString())) {
                mTvChildAgeError.setVisibility(View.VISIBLE);
                mTvChildAgeError.announceForAccessibility(getResources().getString(R.string.marriage_cal_invalid_child_age));
                mTvChildAgeError.setText(getResources().getString(R.string.marriage_cal_invalid_child_age));
            } else if (mEtWeddingCost.getText().toString().replaceAll(",", "").equals("") || mEtWeddingCost.getText().toString().replaceAll(",", "").equals("0")) {
                mTvMarriageCostError.setVisibility(View.VISIBLE);
                mTvMarriageCostError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_wed_amnt));
                mTvMarriageCostError.setText(getResources().getString(R.string.marriage_cal_error_wed_amnt));

            } else if ((Long.parseLong(mEtWeddingCost.getText().toString().replaceAll(",", ""))) < 100000) {
                mTvMarriageCostError.setVisibility(View.VISIBLE);
                mTvMarriageCostError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_minnimum_age));
                mTvMarriageCostError.setText(getResources().getString(R.string.marriage_cal_error_minnimum_age));
            } else if ((Long.parseLong(mEtWeddingCost.getText().toString().replaceAll(",", ""))) > 100000000) {
                mTvMarriageCostError.setVisibility(View.VISIBLE);
                mTvMarriageCostError.announceForAccessibility(getResources().getString(R.string.marriage_cal_maxx_amnt));
                mTvMarriageCostError.setText(getResources().getString(R.string.marriage_cal_maxx_amnt));
            } else if (mEtExpectedRate.getText().toString().equals("") || mEtExpectedRate.getText().toString().equals(".") || mEtExpectedRate.getText().toString().equals("0.00")) {
                mTvExpectedRorError.setVisibility(View.VISIBLE);
                mTvExpectedRorError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_expected_return));
                mTvExpectedRorError.setText(getResources().getString(R.string.marriage_cal_error_expected_return));
            } else if (Double.parseDouble(mEtExpectedRate.getText().toString()) > 100) {
                mTvExpectedRorError.setVisibility(View.VISIBLE);
                mTvExpectedRorError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_less_expected_ror));
                mTvExpectedRorError.setText(getResources().getString(R.string.marriage_cal_error_less_expected_ror));
            } else if (mEtExpectedInflation.getText().toString().equals("") || mEtExpectedInflation.getText().toString().equals(".")) {
               // mBrokerActivity.showCommonDialog(mBrokerActivity, "Not Valid", getResources().getString(R.string.marriage_cal_some_errror));
                mTvExpectedInflationRateError.setVisibility(View.VISIBLE);
                mTvExpectedInflationRateError.announceForAccessibility(getResources().getString(R.string.marriage_cal_expected_inflation_rate));
                mTvExpectedInflationRateError.setText(getResources().getString(R.string.marriage_cal_expected_inflation_rate));
            } else if (Double.parseDouble(mEtExpectedInflation.getText().toString()) > 30) {
                mTvExpectedInflationRateError.setVisibility(View.VISIBLE);
                mTvExpectedInflationRateError.announceForAccessibility(getResources().getString(R.string.marriage_cal_some_errror));
                mTvExpectedInflationRateError.setText(getResources().getString(R.string.marriage_cal_some_errror));
            } else {
                String rawValue = mEtWeddingCost.getText().toString().replaceAll(",", "").toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue, mEtWeddingCost);

                String rawValue2 = mEtSaving.getText().toString().replaceAll(",", "").toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue2, mEtSaving);

                String rawValue3 = mEtExitingCurpus.getText().toString().replaceAll(",", "").toString().replaceAll(",", "").toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue3, mEtExitingCurpus);

                try {
                    dblTymLeft = 0;
                    dblExistingCorpus = 0;
                    dblExistingGrowth = 0;
                    futureSaving = 0;
                    add_sav = 0;
                    inflammationCost = 0;
                    onetimeinv = 0;
                    monthlyinv = 0;
                    yearlyinv = 0;


                    dblChildAge = Double.parseDouble(mEtPresentAge.getText().toString());
                    dblMrgAge = Double.parseDouble(mEtMarrigeAge.getText().toString());
                    dblMrgCost = Double.parseDouble(mEtWeddingCost.getText().toString().replaceAll(",", "").toString());
                    dblYrlySaving = Double.parseDouble(mEtSaving.getText().toString().replaceAll(",", "").toString());
                    dblExpReturnRate = Double.parseDouble(mEtExpectedRate.getText().toString());
                    dblExtInflammation = Double.parseDouble(mEtExpectedInflation.getText().toString());
                    dblExistingCorpus = Double.parseDouble(mEtExitingCurpus.getText().toString().replaceAll(",", "").toString());
//hcuipwenc
                    //calculation for inflation adjusted cost
                    dblTymLeft = dblMrgAge - dblChildAge;

                    inflammationCost = dblMrgCost * (Math.pow((1 + dblExtInflammation / 100), dblTymLeft));

                    //Calculation for existing corpus gain after retirement
                    dblExistingGrowth = dblExistingCorpus * (Math.pow((1 + dblExpReturnRate / 100), dblTymLeft));

                    //double leftAmount=inflammationCost-dblExistingGrowth;

                    //calculation for Future value of my savings

                    double p = Math.pow((1 + dblExpReturnRate / 100), dblTymLeft);

                    futureSaving = (dblYrlySaving * (p - 1)) / (dblExpReturnRate / 100);


                    //calculation for Additional funds required to meet expenses

                    add_fund = inflammationCost - (futureSaving + dblExistingGrowth);

                    //calculation for Additional savings required for year

                    add_sav = (add_fund * (dblExpReturnRate / 100)) / (p - 1);


                    onetimeinv = add_fund / (Math.pow((1 + dblExpReturnRate / 100), dblTymLeft));

                    yearlyinv = (add_fund * dblExpReturnRate / 100) / ((Math.pow((1 + dblExpReturnRate / 100), dblTymLeft)) - 1);


                    // Calculation for Monthly Investment
                    double pm = 12 * dblTymLeft;
                    double intr = dblExpReturnRate / 1200;


                    double powr = Math.pow((1 + intr), pm);
                    monthlyinv = ((add_fund * ((intr * powr) / (powr - 1))) / powr);
                    if (dblExpReturnRate == 0) {
                        monthlyinv = (add_fund / (dblTymLeft * 12));
                    }
                    if (dblTymLeft == 0) {
                        monthlyinv = add_fund;
                    }

                    mLinerResult.setVisibility(View.VISIBLE);

                    String strAmount = "";
                    String[] resultAmount;
                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));

                    long value1 = Math.round(dblExistingGrowth);
                    strAmount = format.format(value1);
                    resultAmount = strAmount.split("\\.", 0);
                    String existingGroth = resultAmount[0];

                    long value2 = Math.round(add_fund);
                    strAmount = format.format(value2);
                    resultAmount = strAmount.split("\\.", 0);
                    String leftAmount = resultAmount[0];

                    long value3 = Math.round(dblExistingCorpus);
                    strAmount = format.format(value3);
                    resultAmount = strAmount.split("\\.", 0);
                    String curpus_vlaue = resultAmount[0];

                    long value4 = Math.round(futureSaving);
                    strAmount = format.format(value4);
                    resultAmount = strAmount.split("\\.", 0);
                    String future_Saving = resultAmount[0];

                    long value5 = Math.round(inflammationCost);
                    strAmount = format.format(value5);
                    resultAmount = strAmount.split("\\.", 0);
                    String totalAmountAtMarrige = resultAmount[0];
                    mTvText2.setText(totalAmountAtMarrige);

                    if (add_fund > 0) {
                        mLinerResultPart.setVisibility(View.VISIBLE);
                        mTvText4.setVisibility(View.GONE);
                        mTvText3.setTextColor(ContextCompat.getColor(mBrokerActivity, R.color.black_white));
                        mTvText3.setText(getResources().getString(R.string.marriage_cal_goal_txt));
                    } else {
                        mTvText3.setText(getResources().getString(R.string.marriage_cal_congrats));
                        mTvText4.setText(getResources().getString(R.string.marriage_cal_desc));
                        mTvText3.setTextColor(ContextCompat.getColor(mActivity, R.color.green_text_color));
                        mLinerResultPart.setVisibility(View.GONE);
                        mTvText4.setVisibility(View.VISIBLE);
                    }


                    long value6 = Math.round(onetimeinv);
                    double totalAmount = Math.round(value6);
                    strAmount = format.format(totalAmount);
                    resultAmount = strAmount.split("\\.", 0);
                    mTvResult1.setText(resultAmount[0]);

                    long value7 = Math.round(monthlyinv);
                    double shortFall = Math.round(value7);
                    strAmount = format.format(shortFall);
                    resultAmount = strAmount.split("\\.", 0);
                    mTvResult2.setText(resultAmount[0]);

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }



                String announcement = mTvTitle.getText().toString() + ". " + mTvText2.getText().toString() + ". "
                        + mTvText3.getText().toString() + ". " + mTvText4.getText().toString() + ". "
                        + getString(R.string.mendate_list_onetime_txt) + ". " + mTvResult1 + ". "
                        + getString(R.string.goal_summary_details_month_txt) + ". " + mTvResult2 + ". ";

                mTvText2.post(() ->
                        mTvText2.announceForAccessibility(announcement)
                );


            }
        } else {
            if (mEtPresentAge.getText().toString().equals("")) {
//                mActivity.showCommonDialog(mBrokerActivity, "Not Valid", getResources().getString(R.string.education_calculator_error_empty_child_age));
                mTvChildAgeError.setVisibility(View.VISIBLE);
                mTvChildAgeError.announceForAccessibility(getResources().getString(R.string.education_calculator_error_empty_child_age));
                mTvChildAgeError.setText(getResources().getString(R.string.education_calculator_error_empty_child_age));
            } else if (mEtMarrigeAge.getText().toString().equals("")) {
                mTvChildMarriageAgeError.setVisibility(View.VISIBLE);
                mTvChildMarriageAgeError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_empty_start_wed_age));
                mTvChildMarriageAgeError.setText(getResources().getString(R.string.marriage_cal_error_empty_start_wed_age));
            } else if (Integer.parseInt(mEtPresentAge.getText().toString()) > Integer.parseInt(mEtMarrigeAge.getText().toString())) {
                mTvChildAgeError.setVisibility(View.VISIBLE);
                mTvChildAgeError.announceForAccessibility(getResources().getString(R.string.marriage_cal_invalid_child_age));
                mTvChildAgeError.setText(getResources().getString(R.string.marriage_cal_invalid_child_age));
            } else if (mEtWeddingCost.getText().toString().replaceAll(",", "").equals("") || mEtWeddingCost.getText().toString().replaceAll(",", "").equals("0")) {
                mTvMarriageCostError.setVisibility(View.VISIBLE);
                mTvMarriageCostError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_wed_amnt));
                mTvMarriageCostError.setText(getResources().getString(R.string.marriage_cal_error_wed_amnt));

            } else if ((Long.parseLong(mEtWeddingCost.getText().toString().replaceAll(",", ""))) < 100000) {
                mTvMarriageCostError.setVisibility(View.VISIBLE);
                mTvMarriageCostError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_minnimum_age));
                mTvMarriageCostError.setText(getResources().getString(R.string.marriage_cal_error_minnimum_age));
            } else if ((Long.parseLong(mEtWeddingCost.getText().toString().replaceAll(",", ""))) > 100000000) {
                mTvMarriageCostError.setVisibility(View.VISIBLE);
                mTvMarriageCostError.announceForAccessibility(getResources().getString(R.string.marriage_cal_maxx_amnt));
                mTvMarriageCostError.setText(getResources().getString(R.string.marriage_cal_maxx_amnt));
            } else if (mEtExpectedRate.getText().toString().equals("") || mEtExpectedRate.getText().toString().equals(".") || mEtExpectedRate.getText().toString().equals("0.00")) {
                mTvExpectedRorError.setVisibility(View.VISIBLE);
                mTvExpectedRorError.setText(getResources().getString(R.string.marriage_cal_error_expected_return));
            } else if (Double.parseDouble(mEtExpectedRate.getText().toString()) > 100) {
                mEtExpectedRate.setText("100.00");
                mTvExpectedRorError.setVisibility(View.VISIBLE);
                mTvExpectedRorError.announceForAccessibility(getResources().getString(R.string.marriage_cal_error_less_expected_ror));
                mTvExpectedRorError.setText(getResources().getString(R.string.marriage_cal_error_less_expected_ror));
            } else if (mEtExpectedInflation.getText().toString().equals("") || mEtExpectedInflation.getText().toString().equals("")) {
                mTvExpectedInflationRateError.setVisibility(View.VISIBLE);
                mTvExpectedInflationRateError.announceForAccessibility(getResources().getString(R.string.marriage_cal_some_errror));
                mTvExpectedInflationRateError.setText(getResources().getString(R.string.marriage_cal_some_errror));
            } else if (Double.parseDouble(mEtExpectedInflation.getText().toString()) > 30) {
                mEtExpectedInflation.setText("30.00");
                mTvExpectedInflationRateError.setVisibility(View.VISIBLE);
                mTvExpectedInflationRateError.announceForAccessibility(getResources().getString(R.string.marriage_cal_expected_inflation_rate));
                mTvExpectedInflationRateError.setText(getResources().getString(R.string.marriage_cal_expected_inflation_rate));
            } else {
                String rawValue = mEtWeddingCost.getText().toString().replaceAll(",", "").toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue, mEtWeddingCost);

                String rawValue2 = mEtSaving.getText().toString().replaceAll(",", "").toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue2, mEtSaving);

                String rawValue3 = mEtExitingCurpus.getText().toString().replaceAll(",", "").toString().replaceAll(",", "").toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue3, mEtExitingCurpus);

                try {
                    dblTymLeft = 0;
                    dblExistingCorpus = 0;
                    dblExistingGrowth = 0;
                    futureSaving = 0;
                    add_sav = 0;
                    inflammationCost = 0;
                    onetimeinv = 0;
                    monthlyinv = 0;
                    yearlyinv = 0;


                    dblChildAge = Double.parseDouble(mEtPresentAge.getText().toString());
                    dblMrgAge = Double.parseDouble(mEtMarrigeAge.getText().toString());
                    dblMrgCost = Double.parseDouble(mEtWeddingCost.getText().toString().replaceAll(",", "").toString());
                    dblYrlySaving = Double.parseDouble(mEtSaving.getText().toString().replaceAll(",", "").toString());
                    dblExpReturnRate = Double.parseDouble(mEtExpectedRate.getText().toString());
                    dblExtInflammation = Double.parseDouble(mEtExpectedInflation.getText().toString());
                    dblExistingCorpus = Double.parseDouble(mEtExitingCurpus.getText().toString().replaceAll(",", "").toString());
//hcuipwenc
                    //calculation for inflation adjusted cost
                    dblTymLeft = dblMrgAge - dblChildAge;

                    inflammationCost = dblMrgCost * (Math.pow((1 + dblExtInflammation / 100), dblTymLeft));

                    //Calculation for existing corpus gain after retirement
                    dblExistingGrowth = dblExistingCorpus * (Math.pow((1 + dblExpReturnRate / 100), dblTymLeft));

                    //double leftAmount=inflammationCost-dblExistingGrowth;

                    //calculation for Future value of my savings

                    double p = Math.pow((1 + dblExpReturnRate / 100), dblTymLeft);

                    futureSaving = (dblYrlySaving * (p - 1)) / (dblExpReturnRate / 100);


                    //calculation for Additional funds required to meet expenses

                    add_fund = inflammationCost - (futureSaving + dblExistingGrowth);

                    //calculation for Additional savings required for year

                    add_sav = (add_fund * (dblExpReturnRate / 100)) / (p - 1);


                    onetimeinv = add_fund / (Math.pow((1 + dblExpReturnRate / 100), dblTymLeft));

                    yearlyinv = (add_fund * dblExpReturnRate / 100) / ((Math.pow((1 + dblExpReturnRate / 100), dblTymLeft)) - 1);


                    // Calculation for Monthly Investment
                    double pm = 12 * dblTymLeft;
                    double intr = dblExpReturnRate / 1200;


                    double powr = Math.pow((1 + intr), pm);
                    monthlyinv = ((add_fund * ((intr * powr) / (powr - 1))) / powr);
                    if (dblExpReturnRate == 0) {
                        monthlyinv = (add_fund / (dblTymLeft * 12));
                    }
                    if (dblTymLeft == 0) {
                        monthlyinv = add_fund;
                    }

                    mLinerResult.setVisibility(View.VISIBLE);

                    String strAmount = "";
                    String[] resultAmount;
                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));

                    long value1 = Math.round(dblExistingGrowth);
                    strAmount = format.format(value1);
                    resultAmount = strAmount.split("\\.", 0);
                    String existingGroth = resultAmount[0];

                    long value2 = Math.round(add_fund);
                    strAmount = format.format(value2);
                    resultAmount = strAmount.split("\\.", 0);
                    String leftAmount = resultAmount[0];

                    long value3 = Math.round(dblExistingCorpus);
                    strAmount = format.format(value3);
                    resultAmount = strAmount.split("\\.", 0);
                    String curpus_vlaue = resultAmount[0];

                    long value4 = Math.round(futureSaving);
                    strAmount = format.format(value4);
                    resultAmount = strAmount.split("\\.", 0);
                    String future_Saving = resultAmount[0];

                    long value5 = Math.round(inflammationCost);
                    strAmount = format.format(value5);
                    resultAmount = strAmount.split("\\.", 0);
                    String totalAmountAtMarrige = resultAmount[0];
                    mTvText2.setText(totalAmountAtMarrige);

                    if (add_fund > 0) {
                        mLinerResultPart.setVisibility(View.VISIBLE);
                        mTvText4.setVisibility(View.GONE);
                        mTvText3.setTextColor(ContextCompat.getColor(mActivity, R.color.black_white));
                        mTvText3.setText(getResources().getString(R.string.marriage_cal_goal_txt));
                    } else {
                        mTvText3.setText(getResources().getString(R.string.marriage_cal_congrats));
                        mTvText4.setText(getResources().getString(R.string.marriage_cal_desc));
                        mTvText3.setTextColor(ContextCompat.getColor(mActivity, R.color.green_text_color));
                        mLinerResultPart.setVisibility(View.GONE);
                        mTvText4.setVisibility(View.VISIBLE);
                    }


                    long value6 = Math.round(onetimeinv);
                    double totalAmount = Math.round(value6);
                    strAmount = format.format(totalAmount);
                    resultAmount = strAmount.split("\\.", 0);
                    mTvResult1.setText(resultAmount[0]);

                    long value7 = Math.round(monthlyinv);
                    double shortFall = Math.round(value7);
                    strAmount = format.format(shortFall);
                    resultAmount = strAmount.split("\\.", 0);
                    mTvResult2.setText(resultAmount[0]);

                    String announcement = mTvTitle.getText().toString() + ". " + mTvText2.getText().toString() + ". "
                            + mTvText3.getText().toString() + ". " + mTvText4.getText().toString() + ". "
                            + getString(R.string.mendate_list_onetime_txt) + ". " + mTvResult1 + ". "
                            + getString(R.string.goal_summary_details_month_txt) + ". " + mTvResult2 + ". ";

                    mTvText2.post(() ->
                            mTvText2.announceForAccessibility(announcement)
                    );
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        hideKeyPad();
        String currentValue = "";
        int i = view.getId();
        if (i == R.id.dialer1) {
            currentValue = mEtPresentAge.getText().toString();

            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 2)
                    mEtPresentAge.setText("" + 1);
                else if (value > 25)
                    mEtPresentAge.setText("" + 25);
            } else {
                mEtPresentAge.setText("" + 1);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer2) {
            currentValue = mEtMarrigeAge.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 18)
                    mEtMarrigeAge.setText("" + 18);
                else if (value > 35)
                    mEtMarrigeAge.setText("" + 35);

            } else {
                mEtMarrigeAge.setText("" + 18);
            }

            desableScrollView(motionEvent);


        } else if (i == R.id.dialer3) {
            currentValue = mEtWeddingCost.getText().toString().replaceAll(",", "").toString();
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 100000)
                    mEtWeddingCost.setText("" + 100000);

            } else {
                mEtWeddingCost.setText("" + 100000);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer4) {
            currentValue = mEtSaving.getText().toString().replaceAll(",", "").toString();
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 1000)
                    mEtSaving.setText("" + 0);
            } else {
                mEtSaving.setText("" + 5000);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer5) {
            currentValue = mEtExitingCurpus.getText().toString().replaceAll(",", "").toString();
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 1)
                    mEtExitingCurpus.setText("" + 0);

            } else {
                mEtExitingCurpus.setText("" + 10000);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer6) {
            currentValue = mEtExpectedRate.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtExpectedRate.setText("" + 1.00);
                else if (value > 100)
                    mEtExpectedRate.setText("" + 100.00);

            } else {
                mEtExpectedRate.setText("" + 12.00);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer7) {
            currentValue = mEtExpectedInflation.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtExpectedInflation.setText("" + 0.00);
                else if (value > 100)
                    mEtExpectedRate.setText("" + 100.00);

            } else {
                mEtExpectedInflation.setText("" + 6.00);
            }
            desableScrollView(motionEvent);
        }
        return false;
    }

    private void desableScrollView(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            mScrollView.requestDisallowInterceptTouchEvent(true);

        else if (motionEvent.getAction() == MotionEvent.ACTION_UP)
            mScrollView.requestDisallowInterceptTouchEvent(false);

    }

    public void hideKeyPad() {
        if (mBrokerActivity != null) {
            InputMethodManager inputManager = (InputMethodManager) mBrokerActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mBrokerActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } else {
            InputMethodManager inputManager = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    public void saveFrameLayout() {
        mClCalcFooter.setVisibility(View.VISIBLE);
        ll_calculator_header.setVisibility(View.VISIBLE);
        loadUpdatedView();
    }

    private void loadUpdatedView() {
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          createImage();
                                      }
                                  },

                100);
    }

    private void createImage() {
        if (mBrokerActivity != null) {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mBrokerActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        } else {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        }
    }


    private Bitmap getBitmapFromView(View view, int height, int width) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return bitmap;
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                saveFrameLayout();
}
else if (view.getId() == R.id.iv_refresh) {
                refreshView();
}
    }

    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {
            if (mBrokerActivity != null) {
                if (mBrokerActivity.getCurrentFocus() == mEtPresentAge) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtMarrigeAge) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtWeddingCost) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtSaving) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtExitingCurpus) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtExpectedRate) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtExpectedInflation) {
                    delayCall();
                }
            } else {
                if (mActivity.getCurrentFocus() == mEtPresentAge) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtMarrigeAge) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtWeddingCost) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtSaving) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtExitingCurpus) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtExpectedRate) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtExpectedInflation) {
                    delayCall();
                }
            }

        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

    }
}

