package investwell.client.fragments.mydoc;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;

public class FragDocumentFolders extends BaseFragment {
    private AppSession mSession;
    private ClientActivity mActivity;
    private AppApplication mAppplication;
    private ShimmerFrameLayout mShimmerViewContainer;
    private ToolbarFragment fragToolBar;
    private FragDocumentFolderAdapter mDocumentAdapter;
    private static final int MY_REQUEST_CODE_PERMISSION = 1000;
    private static final int MY_RESULT_CODE_FILECHOOSER = 2000;
    private BottomSheetDialog bottomSheetDialog;
    private TextView mTvNothing;
    private String mDocumentType = "";

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        /*if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.my_documents),
                    true, false, false, false, false, false, false);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_document, container, false);

        mActivity.setMainVisibility(this, null);
        setUpToolBar();

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mTvNothing = view.findViewById(R.id.tvNothing);

        RecyclerView recycleView = view.findViewById(R.id.recycleView);
        recycleView.setLayoutManager(new GridLayoutManager(getActivity(), 3));
        mDocumentAdapter = new FragDocumentFolderAdapter(mActivity, new ArrayList<JSONObject>(), new FragDocumentFolderAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                JSONObject jsonObject = mDocumentAdapter.mDataList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("uid", jsonObject.optString("uid"));
                mActivity.displayViewOther(80, bundle);


            }
        });
        recycleView.setAdapter(mDocumentAdapter);

        callMyDocuments();
        return view;
    }



    private void callMyDocuments() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        String type = "";
        try {
            if (Utils.getSelectedLevelNo(mSession).equals("98")) {
                type = "FH";
            } else {
                type = "C";
            }


            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "myDocTable");
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOCUMENT_FOLDERS + "uid=" + Utils.getSelectedUid(mSession)
                    + "&userType=" + type + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

            /*https://spvithlani.investwell.app/webapi/client/utilities/getDirectoryListing?
            uid=6158fa1dba4bf04015e91d2e2caf5bcc&userType=FH&componentForLoader={"componentName":"myDocTable"}
            &investorUid=6158fa1dba4bf04015e91d2e2caf5bcc&selectedUser={"uid":"6158fa1dba4bf04015e91d2e2caf5bcc"
            ,"levelNo":"98"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    mShimmerViewContainer.setVisibility(View.GONE);
                    mShimmerViewContainer.stopShimmer();


                    List<JSONObject> documentList = new ArrayList<>();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.optInt("Status") == 0) {

                            JSONObject ob = jsonObject.getJSONObject("result");
                            JSONArray jsonArray = ob.getJSONArray("data");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                                documentList.add(jsonObject1);
                            }

                        } else if (jsonObject.optInt("status") == -1) {
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(getActivity(), getString(R.string.failed), jsonObject.optString("message"), "message");
                        }

                    } catch (JSONException e) {
                        if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    } finally {
                        if (documentList.size() != 0) {
                            mDocumentAdapter.updateList(documentList, "");
                            mTvNothing.setVisibility(View.GONE);
                        } else {
                            mDocumentAdapter.updateList(new ArrayList<>(), "");
                            mTvNothing.setVisibility(View.VISIBLE);
                        }
                    }

                }, volleyError -> {

            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mTvNothing.setVisibility(View.VISIBLE);

            if (!isAdded())
                return;
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 1;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(stringRequest);
    }



}
