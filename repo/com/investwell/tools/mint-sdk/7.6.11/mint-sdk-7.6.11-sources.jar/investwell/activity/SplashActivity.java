package investwell.activity;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieFrameInfo;
import com.airbnb.lottie.value.SimpleLottieValueCallback;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Callback;
import com.iw.mint.sdk.databinding.ActivityLanguageSelectorBinding;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.common.adapter.LanguageSupportAdapter;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.common.intro.IntroActivity;
import investwell.common.intro.SingleIntroActivity;
import investwell.common.lock.AppLockOptionActivity;
import investwell.utils.ApiRequestType;
import investwell.utils.AppConstants;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.Extensions;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.TimeDateUtils;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class SplashActivity extends BaseActivity {
    private final int SPLASH_DISPLAY_LENGTH = 2000;
    private AppSession mSession;
    private String mType = "",mStatus = "",ssoToken="",imagePath="",token="",call_from="";

    private JSONObject appConfigObject, adminJSONObject;
    private ApiDataBase db;
    private RelativeLayout relMainBody;
    private ImageView imageView;
    private LottieAnimationView lottieAnimationView;

    private String transactionDeeplinkUrl = "";
    private String coming_from = "";
    private JSONObject mObject = new JSONObject();
    private boolean returnedFromOtherActivity = false;
    private boolean relogin = false;
    private boolean allowedlogin = false;
    private boolean isCustomSplash = false;
    private int sdkCustomLoader = 0;
//    private static final int RC_LANGUAGE_SELECTION = 1001;





    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(url, req, res, AppConstants.SPLASH, dateTime, endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.hasExtra("type")) {
            mType = intent.getStringExtra("type");
        }
        if (intent.getExtras() != null) {
            for (String key : intent.getExtras().keySet()) {
                logD("FCM_DEBUG , Key: " + key + " Value: " + intent.getExtras().get(key));
            }
        }
        if (intent != null && intent.hasExtra("ssoData")) {
            ssoToken = intent.getStringExtra("ssoData");
        }
        if (intent != null && intent.hasExtra("domain")){
            mSession.setUserBrokerDomain(intent.getStringExtra("domain"));
        }

        if (intent != null) {
            Bundle extras = intent.getExtras();
            mObject = new JSONObject();
            if (extras != null) {
                // Case 1: FCM system notification (background case)
                if (extras.containsKey("entityHyperLink") || extras.containsKey("source")) {
                    String entityHyperLink = extras.getString("entityHyperLink", "");
                    String title = extras.getString("title", "");
                    String body = extras.getString("body", "");
                    coming_from = "notification";
                    try {
                        mObject.put("entityHyperLink", entityHyperLink);
                        mObject.put("title", title);
                        mObject.put("body", body);
                        mObject.put("source", extras.getString("source", ""));
                    } catch (Exception e) {
                    }
                }
                //  Case 2: Your custom notification (foreground / data payload)
                else if (extras.containsKey("coming_from") || extras.containsKey("data")) {
                    coming_from = extras.getString("coming_from", "");
                    String dataStr = extras.getString("data", "");
                    if (!dataStr.isEmpty()) {
                        try {
                            mObject = new JSONObject(dataStr);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            mObject = new JSONObject();
                        }
                    }
                }
                //  Case 3: Unknown / launcher open
                else {
                    coming_from = "";
                }
            } else {
                coming_from = "";
            }
        }

        if (intent != null && intent.hasExtra("domain")){
            mSession.setUserBrokerDomain(intent.getStringExtra("domain"));
            String imagePath = Config.IMAGE_PATH + mSession.getUserBrokerDomain() + "_Logo.png";

        }
        String data = "";
        if (intent != null) {
            data = intent.getDataString();
        }
        logD("MintLifeCycleLog", mType);

        if (mType.equalsIgnoreCase("admin")) {
            mSession.clear();
            // set the session
            mSession.setServerToken(adminJSONObject.optString("serverToken"));
            mSession.setServerTokenID(adminJSONObject.optString("serverTokenID"));
            mSession.setServerReAuth(adminJSONObject.optString("serverReAuth"));
            mSession.setUserBrokerDomain(adminJSONObject.optString("serverDomain"));
            // set hosting path
            mSession.setHostingPath(".investwell.app/webapi/");
            // cache the image url
            String imagePath = Config.IMAGE_PATH + mSession.getUserBrokerDomain() + "_Logo.png";
            mSession.setAppLogo(imagePath);
            Picasso.get().invalidate(imagePath);
            final String imagePathFinal = imagePath;
            Picasso.get().load(imagePath).memoryPolicy(MemoryPolicy.NO_CACHE)
                    .networkPolicy(NetworkPolicy.NO_CACHE).into(imageView, new Callback() {
                        @Override
                        public void onSuccess() {

                        }

                        @Override
                        public void onError(Exception e) {
                            Picasso.get().invalidate(imagePathFinal);
                        }
                    });


            // reLogin();
            getPublicInfo(mSession.getUserBrokerDomain(), "", false, "deeplinkApp", "");
        }
        else if (data != null && data.contains("appLogin")) {
            String url = data.toString();
            String[] parametrs = url.split("=");
            String token = parametrs[1].replace("&uid", "");
            String uid = parametrs[2];
            String domain = "";
            if (url.contains("https"))
                url = url.replace("https://", "");
            else
                url = url.replace("http://", "");

            if (url.contains(".")) {
                String[] baseUrlSplit = url.split("\\.", 2);
                domain = baseUrlSplit[0];
            }

            AppApplication appApplication = (AppApplication) getApplication();
            appApplication.clearAllSession2();
            if (url.contains("iwmint")) {
                mSession.setTestDomainType("iwmint");
                mSession.setHostingPath(".iwmint.com/webapi/");
            } else {
                mSession.setTestDomainType("");
                mSession.setHostingPath(".investwell.app/webapi/");
            }
            mSession.setHasFirstTimeAppIntroLaunched(true);
            //adminLoginMethod(domain, token, uid);
            getPublicInfo(domain, token, false, "deeplinkWeb", uid);
        }
        else if (data != null && data.length() > 0 && data.contains("referredByUid")) {
            String[] parametrs = data.split("=");
            String referredByUid = parametrs[1].replace("&referredByLevelNo", "");
            String referredByLevelNo = parametrs[2];

            AppApplication appApplication = (AppApplication) getApplication();
            appApplication.sDeeplinkingReferUid = referredByUid;
            appApplication.sDeeplinkingReferLevelNo = referredByLevelNo;



            if (mSession.getUserBrokerDomain().length() > 0) {
                getPublicInfo2("deeplinkOnboarding", mSession.getUserBrokerDomain());

            } else {
                Intent intent3 = new Intent(SplashActivity.this, SplashActivity.class);
                intent3.putExtra("login_come_from", "Register");
                startActivity(intent3);
            }

        }
        else if (data != null && data.length() > 0 && data.contains("resetpassword")) {
            String resetPass = data.toString();
            String token = UtilityKotlin.extractLastPathComponent(resetPass);

            if (getString(R.string.subdomain).equals("mint")) {
                resetPass = resetPass.replace("https://", "");
                String[] parameters = resetPass.split("/", 2);
                String baseUrl = parameters[0];
                if (baseUrl.contains(".")) {
                    String[] baseUrlSplit = baseUrl.split("\\.", 2);
                    String domain = baseUrlSplit[0];
                    String basePath = baseUrlSplit[1];
                    if (mSession.getUserBrokerDomain().length() > 0) {
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase(domain)) {
                            Intent intent3 = new Intent(SplashActivity.this, ResetPasswordActivity.class);
                            intent3.putExtra("token", token);
                            intent3.putExtra("domain_name", mSession.getUserBrokerDomain());
                            startActivity(intent3);
                            finish();
                        } else {
                            mSession.clear();
                            mSession.setHostingPath("." + basePath + "/webapi/");
                            getPublicInfo(domain, token, true, "", "");
                        }

                    } else {
                        mSession.setHostingPath("." + basePath + "/webapi/");
                        getPublicInfo(domain, token, true, "", "");
                    }
                }
            } else {
                Intent intent3 = new Intent(SplashActivity.this, ResetPasswordActivity.class);
                intent3.putExtra("token", token);
                intent3.putExtra("domain_name", mSession.getUserBrokerDomain());
                startActivity(intent3);
                finish();
            }

        }
        else if (data != null && data.length() > 0 && data.contains("token")) {

            String url = data;
            String mLoginToken = UtilityKotlin.extractTokenFromUrl(url);
            String subdomain = UtilityKotlin.extractSubdomainFromUrl(url);
            mSession.setUserBrokerDomain(subdomain);
            // ssoLogin
            if (!mLoginToken.equalsIgnoreCase("null") && !mLoginToken.equalsIgnoreCase("")){
//                mSession.clear();
                mSession.setUserBrokerDomain(subdomain);
                ssoLogin(mLoginToken);
            }else {
                activitySelection();
            }
        }
        else if (mType.equalsIgnoreCase("token")) {
            // ssoLogin
            if (!ssoToken.equalsIgnoreCase("")){
                ssoLogin(ssoToken);
            }else {
                activitySelection();
            }

        }else if (data != null && !data.isEmpty() && (data.contains("bseNewInvestment") || data.contains("nseInvestNewInvestment") || data.contains("mfuNewInvestment"))) {
            if(mSession.getHasLoging() && !data.contains(mSession.getUserBrokerDomain())){
                Toast.makeText(this, "Domain not matched with current login session, Please logout then retry it", Toast.LENGTH_SHORT).show();
                activitySelection();
            }else {
                transactionDeeplinkUrl = data;
                if (mSession.getHasLoging()) {
                    if (mSession.getLoginType().equals("broker")) {
                        Intent brokerActivity = new Intent(getApplicationContext(), BrokerActivity.class);
                        AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                        brokerActivity.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                        startActivity(brokerActivity);
                        finish();
                    } else {
                        Intent clientActivity = new Intent(getApplicationContext(), ClientActivity.class);
                        AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                        clientActivity.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                        startActivity(clientActivity);
                        finish();
                    }

                } else {
                    activitySelection();
                }
            }

        }
        else if(mType.equalsIgnoreCase("newKycOnboard")){
            if(intent != null && intent.hasExtra("status"))
                mStatus = intent.getStringExtra("status");
            reLogin();
        }
        else {
            // domain will be empty when mint app start first time, in case of custom app domain is filling at onCreate
            if (!mSession.getUserBrokerDomain().isEmpty()) {
                String mSSOLogin ="";
                if(!ssoToken.equalsIgnoreCase("")){
                    mSSOLogin ="ssologin";
                }else{
                    mSSOLogin ="";
                }
                getPublicInfo(mSession.getUserBrokerDomain(), "", false, mSSOLogin, "");
            } else {
                if (mSession.getHasLoging()) {
                    if (!mSession.getServerReAuth().trim().isEmpty()) {
                        reLogin();
                    } else if (!mSession.getUsername().isEmpty() && !mSession.getUserpw().isEmpty()) {
                        LoginMethod();
                    } else {
                        activitySelection();
                    }
                } else {
                    activitySelection();
                }
            }

        }
    }


    private void chooseLanguageSelection() {
        if (mSession.isFirstTimeLaunch()){
            startActivity(new Intent(this, LanguageSelectorActivity.class));
            finish();
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (!getString(R.string.subdomain).equals("mint")) {
            setTheme(R.style.SplashTheme);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
//        new CheckForRootOrEmulator(this).initStrictMode();
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("mint_admin")) {
            String adminJsonString = intent.getStringExtra("mint_admin");
            try {
                adminJSONObject = new JSONObject(adminJsonString);
                mType = adminJSONObject.optString("type");
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }else if (intent!=null && intent.hasExtra("relogin")){
            relogin= intent.getBooleanExtra("relogin",false);
            allowedlogin= intent.getBooleanExtra("allowedlogin",false);
        }

        imageView = findViewById(R.id.imageView);
        lottieAnimationView = findViewById(R.id.loadingAnimation);
        RelativeLayout relMainBody = findViewById(R.id.relMainBody);
        mSession = AppSession.getInstance(SplashActivity.this);

        //setting language
        String language = mSession.getAppLanguage();
        Extensions.updateLocale(this,language);

       Utils.setTheme(this,mSession);
        if (savedInstanceState != null) {
            // Activity is being recreated after process death
            // Restore state here
            System.out.println();
        } else {
            mSession.setClientObject("");
            logD("client_object_clear", "data clear: SplashActivity");
        }

        db = ApiDataBase.getInstance(getApplicationContext());
        String imagePath = mSession.getAppLogo();
        logD("ActivityCalled", "onCreate Called SplashActivity");
        //logD("MintLifeCycleLog", "API list from splash" + mSession.getStoreApi());
        if (intent !=null && intent.hasExtra("token")){
            token = getIntent().getStringExtra("token");
        }

        if (intent !=null && intent.hasExtra("domain")){
            mSession.setUserBrokerDomain(getIntent().getStringExtra("domain"));
        }
        if (intent !=null && intent.hasExtra("isCustomSplash")){
            isCustomSplash = getIntent().getBooleanExtra("isCustomSplash",false);
        }
        if (intent !=null && intent.hasExtra("customImage")){
            sdkCustomLoader = getIntent().getIntExtra("customImage",0);
        }
        if(intent !=null && intent.hasExtra("ssoToken")){
            ssoToken = getIntent().getStringExtra("ssoToken");
        }
        if(intent !=null && intent.hasExtra("call_from")){
            call_from = getIntent().getStringExtra("call_from");
        }
        if(intent !=null && intent.hasExtra("currentclasswithname")){
            mSession.setCallFromPackage(getIntent().getStringExtra("currentclasswithname"));
        }

        if (!call_from.equalsIgnoreCase("sdk")){
            finish();
            return;
        }

        setTintColorIfDark(this,imageView, R.color.both_black);
        imageView.setContentDescription(mSession.getCompanyName() + ". logo");

        if (isCustomSplash && sdkCustomLoader !=0){
            lottieAnimationView.setVisibility(View.GONE);
            imageView.setVisibility(View.VISIBLE);
            imageView.setImageResource(sdkCustomLoader);
        } else if (!allowedlogin && !relogin) {
            lottieAnimationView.setVisibility(View.VISIBLE);
            playLottieAnimation();
        }else {
            if (isCustomSplash && sdkCustomLoader !=0){
                lottieAnimationView.setVisibility(View.GONE);
                imageView.setVisibility(View.VISIBLE);
                imageView.setImageResource(sdkCustomLoader);
            }else {
                imageView.setVisibility(View.GONE);
                lottieAnimationView.setVisibility(View.VISIBLE);
                playLottieAnimation();
            }
        }


        String uniqueId = UtilityKotlin.getDeviceUniqueID(this);
        logD("MintLifeCycleLog", "Device UniqeId = " + uniqueId);

        mSession.setDeviceUniqueID(uniqueId);
        UtilityKotlin.setRefreshKey(mSession);
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());

            } else {
                appConfigObject = new JSONObject();
            }
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        if (!getString(R.string.subdomain).equals("mint")) {
            mSession.setHostingPath(".investwell.app/webapi/");
            mSession.setUserBrokerDomain(getString(R.string.subdomain));
        } else {
            String domainName = mSession.getUserBrokerDomain();
            if (!domainName.isEmpty()) {
                if (mSession.getTestDomainType().equals("prePord1")) {
                    mSession.setHostingPath(".investwell.io/webapi/");
                } else if (mSession.getTestDomainType().equals("prePord2")) {
                    mSession.setHostingPath(".getinvestwell.com/webapi/");
                } else if (mSession.getTestDomainType().equals("iwmint")) {
                    mSession.setHostingPath(".iwmint.com/webapi/");
                }else if (mSession.getTestDomainType().equals("preProd4")) {
                    mSession.setHostingPath(".letsinvestwell.com/webapi/");
                }else if (mSession.getTestDomainType().equals("preProd5")) {
                    mSession.setHostingPath(".your-portfolio.co.in/webapi/");
                } else {
                    mSession.setHostingPath(".investwell.app/webapi/");
                }
            } else {
                mSession.setHostingPath(".investwell.app/webapi/");
            }
        }
        onNewIntent(getIntent());

    }


    private void playLottieAnimation(){
        lottieAnimationView.addValueCallback(
                new KeyPath("magnifier Outlines", "**"),
                LottieProperty.COLOR_FILTER,
                new SimpleLottieValueCallback<ColorFilter>() {
                    @Override
                    public ColorFilter getValue(LottieFrameInfo<ColorFilter> frameInfo) {
                        return new PorterDuffColorFilter(
                                ContextCompat.getColor(SplashActivity.this, R.color.colorPrimary),
                                PorterDuff.Mode.SRC_ATOP
                        );
                    }
                }

        );
        lottieAnimationView.setRepeatMode(LottieDrawable.RESTART);
        lottieAnimationView.setRepeatCount(LottieDrawable.INFINITE);
        // Start the animation
        lottieAnimationView.playAnimation();


    }

    private void showInCompatiblePopUp(boolean isRootedOrEmulator) {
        if (isRootedOrEmulator) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SplashActivity.this);
            builder.setTitle(R.string.alert)
                    .setMessage("Incompatible Device")
                    .setPositiveButton(R.string.ok, (dialog, which) -> {
                        dialog.dismiss();
                        finish();
                    })
                    .setCancelable(false)
                    .show();
        }
    }



    /***
     * ::::::::::::::::::check isFirstTimeLaunched() then ask for app language:::::::::::::::::::
     */
    private void openBottomSheetLanguageSelector() {
        LanguageSupportAdapter languageSupportAdapter;
        List<String> langlist= new ArrayList<>();
        ArrayList<JSONObject> langJSONObject = new ArrayList<JSONObject>();
        if (!isFinishing()){
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
            ActivityLanguageSelectorBinding mBinding = ActivityLanguageSelectorBinding.inflate(getLayoutInflater());
            bottomSheetDialog.setContentView(mBinding.getRoot());
            bottomSheetDialog.setCancelable(false);
            bottomSheetDialog.show();


            languageSupportAdapter = new LanguageSupportAdapter(SplashActivity.this, mSession,langCode -> {
                setNewAppConfig(langCode);
                Extensions.updateLocale(this,langCode);
            });
            LinearLayoutManager mLayoutmanager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
            DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, LinearLayoutManager.VERTICAL);

            mBinding.rvLanguageSupport.setLayoutManager(mLayoutmanager);
            mBinding.rvLanguageSupport.addItemDecoration(dividerItemDecoration);
            mBinding.rvLanguageSupport.setItemAnimator(new DefaultItemAnimator());
            mBinding.rvLanguageSupport.setNestedScrollingEnabled(false);
            mBinding.rvLanguageSupport.setAdapter(languageSupportAdapter);

            // set config for language list
            JSONArray jsonArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
            langlist =  Utils.getFeatureSettingByName(jsonArray,"Vernacular");
            languageSupportAdapter.update(langlist);
            // continue data
        }
    }

    // set app Config again with updated language
    private void setNewAppConfig(String languageCode) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Subdomain", mSession.getUserBrokerDomain());
            jsonObject.put("Language", UtilityKotlin.getLanguageCodeToValueMap().get(languageCode));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, Config.APP_CONFIG, jsonObject, response -> {
//            progressBar.setVisibility(View.GONE);
            if (response.optBoolean("Status")) {
                mSession.setAppConfig(response.toString());
               // this.recreate();
                activitySelectionContinue();
            }
            },volleyError -> {
//            progressBar.setVisibility(View.GONE);
            mSession.setAppConfig("");
            UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "splash");

        });
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                Log.d("getConfigData", "getConfigData: getCurrentRetryCount called =");
                return 4;
            }

            @Override
            public void retry(VolleyError error) {
                System.out.println();
                Log.d("getConfigData", "getConfigData: retry called");
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);
        }

    private void activitySelectionContinue(){
        Log.d("MintLifeCycleLog", "activitySelection called");

        if (mSession.getHasLoging()) {
            if (mSession.getHasAppLockEnable()) {
                logD("binesh", "applock called from Splash class ");
                Intent intent = new Intent(getApplicationContext(), AppLockOptionActivity.class);
                if (!transactionDeeplinkUrl.isEmpty()) {
                    intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                }
                if (!TextUtils.isEmpty(coming_from)){
                    intent.putExtra("coming_from", coming_from);
                    intent.putExtra("data", mObject.toString());

                }
                intent.putExtra("type", "verify_lock");
                intent.putExtra("callFrom", "splash");
                startActivity(intent);
                finish();
            } else if (mType.equals("sessionExpired")) {
                logD("MintLifeCycleLog", "DomainActivity.class Called");
                Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                if (!transactionDeeplinkUrl.isEmpty()) {
                    intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                }
                if (!TextUtils.isEmpty(coming_from)){
                    intent.putExtra("coming_from", coming_from);
                    intent.putExtra("data", mObject.toString());

                }
                startActivity(intent);
                finish();
            } else if (mSession.getLoginType().equals("broker")) {
                logD("MintLifeCycleLog", "BrokerActivity.class Called");
                Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                if (!transactionDeeplinkUrl.isEmpty()) {
                    intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                }
                if (!TextUtils.isEmpty(coming_from)){
                    intent.putExtra("coming_from", coming_from);
                    intent.putExtra("data", mObject.toString());

                }
                AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                startActivity(intent);
                finish();
            } else if (mSession.getLoginType().equals("client")) {
                logD("MintLifeCycleLog", "ClientActivity.class Called");
                Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                if (!transactionDeeplinkUrl.isEmpty()) {
                    intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                }
                if (!TextUtils.isEmpty(coming_from)){
                    intent.putExtra("coming_from", coming_from);
                    intent.putExtra("data", mObject.toString());

                }
                AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                intent.putExtra("type", "newKycOnboard");
                intent.putExtra("status", mStatus);
                startActivity(intent);
                finish();

            }
        } else {
            if (mType.equals("sessionExpired")) {
                logD("MintLifeCycleLog", "DomainActivity.class Called");
                Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                if (!transactionDeeplinkUrl.isEmpty()) {
                    intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                }
                if (!TextUtils.isEmpty(coming_from)){
                    intent.putExtra("coming_from", coming_from);
                    intent.putExtra("data", mObject.toString());

                }
                startActivity(intent);
                finish();
            } else if (!mSession.getHasFirstTimeAppIntroLaunched() && !TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("2")) {
                Intent intent = new Intent(getApplicationContext(), SingleIntroActivity.class);
                startActivity(intent);
                finish();
            } else if (!mSession.getHasFirstTimeAppIntroLaunched() && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && (appConfigObject.optString("layout").equalsIgnoreCase("3") || appConfigObject.optString("layout").equalsIgnoreCase("6")))) {
                Intent intent = new Intent(getApplicationContext(), IntroActivity.class);
                startActivity(intent);
                finish();
            } else if (getString(R.string.subdomain).equals("iwmint") && (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("1"))) {
                if (!mSession.getUserBrokerDomain().isEmpty()) {
                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                    if (!transactionDeeplinkUrl.isEmpty()) {
                        intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                    }
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                    if (!transactionDeeplinkUrl.isEmpty()) {
                        intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                    }
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                    startActivity(intent);
                    finish();
                }
            } else {
                if (getString(R.string.subdomain).equals("iwmint")) {
                    Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                    if (!transactionDeeplinkUrl.isEmpty()) {
                        intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                    }
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                    startActivity(intent);
                    finish();
                } else if (!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5")) {
                    if (Utils.getConfigData(mSession).has("FeatureList") && Objects.requireNonNull(Utils.getConfigData(mSession).optJSONArray("FeatureList")).length()>0){
                        JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("FeatureList");
                        boolean isFound = false;
                        for (int i = 0; i <sectionJSONArray.length() ; i++) {
                            JSONObject jsonObject = sectionJSONArray.optJSONObject(i);
                            if (jsonObject.optString("FeatureName").equalsIgnoreCase("LoginMandatory") && jsonObject.optString("FeatureStatus").equalsIgnoreCase("1")){
                                if (!mSession.getUserBrokerDomain().isEmpty()) {
                                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                    if (!transactionDeeplinkUrl.isEmpty()) {
                                        intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                                    }
                                    startActivity(intent);
                                    finish();
                                    return;
                                } else {
                                    Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
                                    if (!transactionDeeplinkUrl.isEmpty()) {
                                        intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                                    }
                                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                                    startActivity(intent);
                                    finish();
                                    return;
                                }
                            }
                        }

                        Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                        if (!transactionDeeplinkUrl.isEmpty()) {
                            intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                        }
                        if (!TextUtils.isEmpty(coming_from)){
                            intent.putExtra("coming_from", coming_from);
                            intent.putExtra("data", mObject.toString());

                        }
                        AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                        startActivity(intent);
                        finish();
                    }else{
                        Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                        if (!transactionDeeplinkUrl.isEmpty()) {
                            intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                        }
                        if (!TextUtils.isEmpty(coming_from)){
                            intent.putExtra("coming_from", coming_from);
                            intent.putExtra("data", mObject.toString());

                        }
                        AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                        startActivity(intent);
                        finish();
                    }
                } else {
                    Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                    if (!transactionDeeplinkUrl.isEmpty()) {
                        intent.putExtra("transactionDeeplinkUrl", transactionDeeplinkUrl);
                    }
                    if (!TextUtils.isEmpty(coming_from)){
                        intent.putExtra("coming_from", coming_from);
                        intent.putExtra("data", mObject.toString());
                    }
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                    startActivity(intent);
                    finish();
                }

            }
        }
    }
    private void activitySelection() {
//        if (appConfigObject.optString("multiLang").equals("1") && mSession.getHasFirstTimeSplashLaunch()) {
//            if (!isLanguageSelectorRunning()) {
//                Intent intent = new Intent(SplashActivity.this, LanguageSelectorActivity.class);
//                startActivityForResult(intent, RC_LANGUAGE_SELECTION);
//            }
//        }
//        else {
//            activitySelectionContinue();
//        }
        activitySelectionContinue();
    }
    private boolean isLanguageSelectorRunning() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);

        if (taskInfo != null && !taskInfo.isEmpty()) {
            ComponentName topActivity = taskInfo.get(0).topActivity;
            return topActivity != null &&
                    topActivity.getClassName().equals(LanguageSelectorActivity.class.getName());
        }
        return false;
    }


    private void reLogin() {
        logD("MintLifeCycleLog", "relogin Called");
        long time = System.currentTimeMillis();
        mSession.setLastReloginTime("" + time);
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_LOGGEDIN_USER;

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mSession.setShowCrossDialog(true);
                insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.AUTHENTICATION);
                setReLoginResponse(response);
            }

        });
    }


    private void adminLoginMethod(String domain, String token, String uid) {
        String url = "https://" + domain + mSession.getHostingPath() + Config.ADMIN_AUTHENTICATION;
        JSONObject objectMain = new JSONObject();

        try {
            objectMain.put("domain", domain);
            objectMain.put("token", token);
            objectMain.put("uid", uid);
            objectMain.put("selectedUser", new JSONObject());
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, objectMain, AppHeaderType.LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                UtilityKotlin.setRefreshKey(mSession);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    insertApiData(url, "GET API CONTAINS REQUEST IN URL", "" + jsonObject, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.AUTHENTICATION);
                    logD("binesh_admin_log", "adminLoginMethod: " + jsonObject);
                    if (jsonObject.optInt("status") == 0) {
                        setReLoginResponse("" + jsonObject);

                    } else {
                        String errorMessge = jsonObject.optString("message");
                        Toast.makeText(SplashActivity.this, errorMessge, Toast.LENGTH_SHORT).show();

                    }
                } catch (Exception e) {
                    String data = e.getLocalizedMessage();
                    System.out.println(data);
                }
            }

        });


    }

    private void setReLoginResponse(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optInt("status") == 0) {

                logD("MintLifeCycleLog", "relogin Response received");
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                if (jsonObjectMain.has("token")) {
                    Intent intent = new Intent(SplashActivity.this, MobileVerificationActivity.class);
                    intent.putExtra("token", jsonObjectMain.optString("token"));
                    intent.putExtra("mobile", jsonObjectMain.optString("mobile"));
                    intent.putExtra("type", "twoFactor");
                    intent.putExtra("isTwoFa", true);
                    startActivity(intent);
                } else {

                    if (getString(R.string.subdomain).equals("mint")) {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.GtmSetUp(jsonObjectMain.optString("levelNo"), jsonObjectMain.optString("name"));
                    }

                    mSession.setUsername(jsonObjectMain.optString("username"));
                    mSession.setName(jsonObjectMain.optString("name"));
                    mSession.setPersonName(jsonObjectMain.optString("name"));
                    mSession.setBrokerFullName(jsonObjectMain.optString("name"));
                    mSession.setUid(jsonObjectMain.optString("uid"));
                    mSession.setLead(jsonObjectMain.optString("isLead"));
                    mSession.setUserBrokerDomain(jsonObjectMain.optString("brokerDomain"));
                    mSession.setLoginType(jsonObjectMain.optString("userType"));
                    mSession.setLevelId(jsonObjectMain.optString("levelid"));
                    mSession.setBid(jsonObjectMain.optString("bid"));
                    mSession.setBrokerUID(jsonObjectMain.optString("brokerUid"));
                    mSession.setLowerReportingLevels(jsonObjectMain.optString("lowerReportingLevels"));
                    mSession.setLevelNo(jsonObjectMain.optString("levelNo"));
                    mSession.setReportingLevelName(jsonObjectMain.optString("reportingLevelName"));
                    mSession.setAllLoginData("" + jsonObject);
                    mSession.setHideXirr(jsonObjectMain.optString("hideXirr"));
                    mSession.setPAN(jsonObjectMain.optString("pan"));
                    mSession.setAppId(jsonObjectMain.optString("appid"));
                    mSession.setEmail(jsonObjectMain.optString("email"));
                    mSession.setClientPhotoName(jsonObjectMain.optString("profileImage"));
                    mSession.setIsLargeIfa(jsonObjectMain.optInt("isLargeIfa"));
                    mSession.setPhone(jsonObjectMain.optString("phone").equalsIgnoreCase("null") ? "" : jsonObjectMain.optString("phone"));
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.removedTempData();


                    if (jsonObjectMain.optString("allowSOADownload").equals("1")) {
                        mSession.setHasSoaDownloadEnable(true);
                    } else {
                        mSession.setHasSoaDownloadEnable(false);
                    }
                    AppApplication.sExchangeType = "";

                    if (jsonObjectMain.optString("txnEnable").equals("1")) {
                        mSession.setHasTransectionEnable(true);
                    } else {
                        mSession.setHasTransectionEnable(false);
                    }

                    if (jsonObjectMain.optString("useEdge360").equals("1")) {
                        mSession.setHasEdge360(true);
                    } else {
                        mSession.setHasEdge360(false);
                    }

                    if (jsonObjectMain.optString("hideMetrics").equals("1")) {
                        mSession.setHasBDCardWithStar(true);
                    } else {
                        mSession.setHasBDCardWithStar(false);
                    }

                    if (jsonObjectMain.optString("bseOpted").equals("1")) {
                        mSession.setHasBseOpted(true);
                    } else {
                        mSession.setHasBseOpted(false);
                    }

                    if (jsonObjectMain.optString("nseOpted").equals("1")) {
                        mSession.setHasNseOpted(true);
                    } else {
                        mSession.setHasNseOpted(false);
                    }
                    mSession.setHasNse2Opted(jsonObjectMain.optString("nseInvestOpted").equals("1"));

                    if (jsonObjectMain.optString("mfuOpted").equals("1")) {
                        mSession.setHasMfuOpted(true);
                    } else {
                        mSession.setHasMfuOpted(false);
                    }

                    if (mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNse2Opted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasMfuOpted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted()) && !mSession.getHasMfuOpted() && !mSession.getHasNse2Opted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNseOpted() && !mSession.getHasNse2Opted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasBseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted() && !mSession.getHasMfuOpted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasBseOpted() && !mSession.getHasNse2Opted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasMfuOpted()) {
                        mSession.setHasMultiExchange(true);
                    } else if ((mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasNseOpted()) {
                        mSession.setHasMultiExchange(true);
                    } else {
                        mSession.setHasMultiExchange(false);
                    }

                    // nseInvest can't be default exchange
                    if (!mSession.getHasMultiExchange()){
                        boolean hasBse = mSession.getHasBseOpted();
                        boolean hasNse = mSession.getHasNseOpted();
                        boolean hasMfu = mSession.getHasMfuOpted();
                        boolean hasNse2 = mSession.getHasNse2Opted();
                        String exchange = "";
                        if (hasNse) {
                            exchange = "1";
                        } else if (hasBse) {
                            exchange = "2";
                        } else if (hasMfu) {
                            exchange = "3";
                        } else if (hasNse2) {
                            exchange = "4";
                        }
                        mSession.setExchangeNseBseMfu(exchange);
                    }
                    mSession.setHasLoging(true);
                    Config.sOncePopupPerLoginSession = false;
                    callAllowedFeatures();

                }

            } else {
                String errorMessge = jsonObject.optString("message");
                if (!errorMessge.equalsIgnoreCase("invalid request"))
                    Toast.makeText(SplashActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            String data = e.getLocalizedMessage();
            System.out.println(data);
        }

    }


    public void LoginMethod() {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.AUTHENTICATION;

        JSONObject params = new JSONObject();
        try {
            params.put("email", mSession.getUserId());
            params.put("password", UtilityKotlin.encryptedPassword(mSession.getUserpw()));
            params.put("brokerDomain", mSession.getUserBrokerDomain());
            params.put("isEncryption", "true");
            params.put("rememberMe", "true");
            insertApiData(url, params.toString(), "", TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.AUTHENTICATION);
        }catch (Exception e){

        }
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, params, AppHeaderType.LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mSession.setShowCrossDialog(true);
                insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.AUTHENTICATION);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        logD("MintLifeCycleLog", "relogin by user & pass Response received");
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                        if (jsonObjectMain.has("token")) {
                            Intent intent = new Intent(getApplicationContext(), MobileVerificationActivity.class);
                            intent.putExtra("token", jsonObjectMain.optString("token"));
                            intent.putExtra("mobile", jsonObjectMain.optString("mobile"));
                            intent.putExtra("type", "twoFactor");
                            intent.putExtra("isTwoFa", true);
                            startActivity(intent);
                        } else {

                            if (getString(R.string.subdomain).equals("mint")) {
                                AppApplication appApplication = (AppApplication) getApplication();
                                appApplication.GtmSetUp(jsonObjectMain.optString("levelNo"), jsonObjectMain.optString("name"));
                            }

                            mSession.setUsername(jsonObjectMain.optString("username"));
                            mSession.setName(jsonObjectMain.optString("name"));
                            mSession.setPersonName(jsonObjectMain.optString("name"));
                            mSession.setBrokerFullName(jsonObjectMain.optString("name"));
                            mSession.setUid(jsonObjectMain.optString("uid"));
                            mSession.setLead(jsonObjectMain.optString("isLead"));
                            mSession.setUserBrokerDomain(jsonObjectMain.optString("brokerDomain"));
                            mSession.setLoginType(jsonObjectMain.optString("userType"));
                            mSession.setLevelId(jsonObjectMain.optString("levelid"));
                            mSession.setBid(jsonObjectMain.optString("bid"));
                            mSession.setBrokerUID(jsonObjectMain.optString("brokerUid"));
                            mSession.setLowerReportingLevels(jsonObjectMain.optString("lowerReportingLevels"));
                            mSession.setLevelNo(jsonObjectMain.optString("levelNo"));
                            mSession.setReportingLevelName(jsonObjectMain.optString("reportingLevelName"));
                            mSession.setAllLoginData(response);
                            mSession.setHideXirr(jsonObjectMain.optString("hideXirr"));
                            mSession.setPAN(jsonObjectMain.optString("pan"));
                            mSession.setAppId(jsonObjectMain.optString("appid"));

                            mSession.setEmail(jsonObjectMain.optString("email"));
                            mSession.setClientPhotoName(jsonObjectMain.optString("profileImage"));
                            mSession.setIsLargeIfa(jsonObjectMain.optInt("isLargeIfa"));
                            mSession.setPhone(jsonObjectMain.optString("phone").equalsIgnoreCase("null") ? "" : jsonObjectMain.optString("phone"));
                            AppApplication appApplication = (AppApplication) getApplication();
                            appApplication.removedTempData();


                            if (jsonObjectMain.optString("allowSOADownload").equals("1")) {
                                mSession.setHasSoaDownloadEnable(true);
                            } else {
                                mSession.setHasSoaDownloadEnable(false);
                            }
                            AppApplication.sExchangeType = "";

                            if (jsonObjectMain.optString("txnEnable").equals("1")) {
                                mSession.setHasTransectionEnable(true);
                            } else {
                                mSession.setHasTransectionEnable(false);
                            }


                            if (jsonObjectMain.optString("useEdge360").equals("1")) {
                                mSession.setHasEdge360(true);
                            } else {
                                mSession.setHasEdge360(false);
                            }

                            if (jsonObjectMain.optString("hideMetrics").equals("1")) {
                                mSession.setHasBDCardWithStar(true);
                            } else {
                                mSession.setHasBDCardWithStar(false);
                            }
                            if (jsonObjectMain.optString("bseOpted").equals("1")) {
                                mSession.setHasBseOpted(true);
                            } else {
                                mSession.setHasBseOpted(false);
                            }

                            if (jsonObjectMain.optString("nseOpted").equals("1")) {
                                mSession.setHasNseOpted(true);
                            } else {
                                mSession.setHasNseOpted(false);
                            }
                            mSession.setHasNse2Opted(jsonObjectMain.optString("nseInvestOpted").equals("1"));

                            if (jsonObjectMain.optString("mfuOpted").equals("1")) {
                                mSession.setHasMfuOpted(true);
                            } else {
                                mSession.setHasMfuOpted(false);
                            }

                            if (mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted()) && !mSession.getHasMfuOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasBseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasNseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else {
                                mSession.setHasMultiExchange(false);
                            }
                            // nseInvest can't be default exchange
                            if (!mSession.getHasMultiExchange()){
                                boolean hasBse = mSession.getHasBseOpted();
                                boolean hasNse = mSession.getHasNseOpted();
                                boolean hasMfu = mSession.getHasMfuOpted();
                                boolean hasNse2 = mSession.getHasNse2Opted();
                                String exchange = "";
                                if (hasNse) {
                                    exchange = "1";
                                } else if (hasBse) {
                                    exchange = "2";
                                } else if (hasMfu) {
                                    exchange = "3";
                                } else if (hasNse2) {
                                    exchange = "4";
                                }
                                mSession.setExchangeNseBseMfu(exchange);
                            }

                            mSession.setHasLoging(true);
                            Config.sOncePopupPerLoginSession = false;
                            callAllowedFeatures();
                        }

                    } else {
                        String errorMessge = jsonObject.optString("message");
                        if (!errorMessge.equalsIgnoreCase("invalid request"))
                            Toast.makeText(SplashActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    String data = e.getLocalizedMessage();
                    System.out.println(data);
                }

            }

        });

    }


    private void callAllowedFeatures() {
        String url = "";
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.BROKER_ALLOWED_FEATURES;
        } else {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_ALLOWED_FEATURES + Utils.getSelectedUserObject(mSession);
        }
        UtilityKotlin.setRefreshKey(mSession);
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        String finalUrl = url;
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = new JSONObject(response);
                    JSONObject resultData = jsonObject.optJSONObject("result");
                    if (jsonObject.optInt("status") == 0) {

                        if (resultData != null) {
                            mSession.setAllowedFeatures("" + resultData);

                        }
                    }
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                } finally {
                    try {
                        if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                            appConfigObject = new JSONObject(mSession.getAppInfo());
                        } else {
                            appConfigObject = new JSONObject();
                        }
                    } catch (JSONException e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }
                    logD("MintLifeCycleLog", "activitySelection called from login by userPass");
                    activitySelection();
                }
            }

        });
    }


    private void getPublicInfo(final String domainName, String token, boolean isResetPassword, String callFrom, String uid) {
        logD("getPublicInfo", "getPublicInfo: called on SplashActivty");
        String url = "https://" + domainName + mSession.getHostingPath() + Config.GET_BROKER_PUBLIC_INFO + "brokerDomain=" + domainName + "&userBusinessCode=" + AppConstants.SUB_BROKER_BUSINESS_CODE;
        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.OPEN_API, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading){
//                    progressBar.setVisibility(View.VISIBLE);
//                    progressBar.setActivated(true);
                }else{
//                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                logD("getPublicInfo", "getPublicInfo: onResponse called =");
                JSONObject jsonObject1 = new JSONObject();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String imagePath = "";

                    if (jsonObject.optInt("status") == 0) {
                        imagePath = Config.IMAGE_PATH + domainName + "_Logo.png";

                        mSession.setAppLogo(imagePath);

                        jsonObject1 = jsonObject.optJSONObject("result");
                        //jsonObject1.put("layout", "5");
                        mSession.setShowBseAuthPopup("1".equals(jsonObject1.optString("showBseAuthPopup").trim()));

                        mSession.setAppLogoName(jsonObject1.optString("logo"));
                        mSession.setFutureProjectionCalculator(jsonObject1.optInt("futureProjectionCalculator"));
                        mSession.setSIPCalculator(jsonObject1.optInt("SIPCalculator"));
                        mSession.setPlayStoreLink(jsonObject1.optString("androidAppLink"));
                        mSession.setAppStoreLink(jsonObject1.optString("iosAppLink"));
                        mSession.setCompanyName(jsonObject1.optString("compName"));
                        mSession.setOnBoarding(jsonObject1.optInt("allowOnboarding"));
                        mSession.setForceUpdate(jsonObject1.optInt("majorUpdate")==1);
                        mSession.setAllowedMobileOTPLogin(jsonObject1.optInt("allowMobileOtpLogin"));
                        mSession.setUserEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setWebsite(jsonObject1.optString("website").equalsIgnoreCase("null") ? "" : jsonObject1.optString("website"));
                        mSession.setMobileNumber(jsonObject1.optString("mobileNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("mobileNo1"));
                        mSession.setTelNumber(jsonObject1.optString("telNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("telNo1"));
                        mSession.setVoltPartnerCode(jsonObject1.optString("voltPartnerCode").equalsIgnoreCase("null") ? "" : jsonObject1.optString("voltPartnerCode"));
                        mSession.setAllowedCrm(jsonObject1.optInt("allowCrm",0)==1);
                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        mSession.setHasShowXirr(jsonObject1.optString("showXIRR").equals("1"));
                        String domain = jsonObject1.optString("domain");
                        if (!domain.equalsIgnoreCase("null") && !domain.isEmpty()) {
                            mSession.setUserBrokerDomain(domain);
                        }
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
                            jsonObject1.put("layout", 6);
                            Log.i("RedmiCalled", "Splash2 set layout 6 called: ");

                        }
                        Log.i("RedmiCalled", "Splash2 domain:  "+mSession.getUserBrokerDomain());

                        mSession.setAppInfo("" + jsonObject1);
                        mSession.setIsRiskProfileMandatory(jsonObject1.optInt("isRiskProfileManadatory"));
                        appConfigObject = jsonObject1;

                        String address = "";
                        address = UtilityKotlin.checkAndGetCompanyAddress(jsonObject1);
                        mSession.setAddress(address);
                        mSession.setCustomURL(jsonObject1.getString("customURL").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customURL"));
                        setCustomLinksData(jsonObject1.getString("customLinks").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customLinks"));

                        String slogan = jsonObject1.optString("slogan");
                        if (!slogan.equalsIgnoreCase("null") && !slogan.isEmpty()) {
                            mSession.setSloganOnLogo(slogan);
                        }



                    } else {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.showCommonDailog(SplashActivity.this, getString(R.string.alert_dialog_error_txt), getString(R.string.alert_dialog_invalid_domain), "error");
                    }
                } catch (Exception e) {

                } finally {
                    if ((!TextUtils.isEmpty(jsonObject1.optString("layout")) && jsonObject1.optString("layout").equalsIgnoreCase("5"))) {
                        if (!mSession.getAppConfig().isEmpty()) {
                            redirectMethodForAppConfig(mSession.getUserBrokerDomain(), isResetPassword, token, callFrom, uid);
                        } else {
                            getConfigData(mSession.getUserBrokerDomain(), isResetPassword, token, callFrom, uid);
                        }
                    } else {
                        if (callFrom.equalsIgnoreCase("deeplinkWeb")) {
                            adminLoginMethod(domainName, token, uid);
                        } else if (callFrom.equalsIgnoreCase("deeplinkApp")) {
                            reLogin();
                        } else if (mType.equalsIgnoreCase("generateReAuth")) {
                            reLogin();
                        } else if (callFrom.equalsIgnoreCase("ssologin")) {
                            ssoLogin(ssoToken);
                        }else {
                            if (isResetPassword) {
                                Intent intent3 = new Intent(SplashActivity.this, ResetPasswordActivity.class);
                                intent3.putExtra("token", token);
                                intent3.putExtra("domain_name", mSession.getUserBrokerDomain());
                                startActivity(intent3);
                                finish();
                            } else {
                                if (mSession.getHasLoging()) {
                                    if (!mSession.getServerReAuth().trim().isEmpty()) {
                                        reLogin();
                                    } else if (!mSession.getUsername().isEmpty() && !mSession.getUserpw().isEmpty()) {
                                        LoginMethod();
                                    } else {
                                        activitySelection();
                                    }
                                } else {
                                    activitySelection();
                                }
                            }
                        }
                    }
                }
            }

        });

    }

    private void getPublicInfo2(final String callFrom, String domainName) {
        logD("getPublicInfo", "getPublicInfo2: called on SplashActivty");
        String url = "https://" + domainName + mSession.getHostingPath() + Config.GET_BROKER_PUBLIC_INFO + "brokerDomain=" + domainName + "&userBusinessCode=" + AppConstants.SUB_BROKER_BUSINESS_CODE;

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.OPEN_API, new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading){
//                    progressBar.setVisibility(View.VISIBLE);
//                    progressBar.setActivated(true);
                }else{
//                    progressBar.setVisibility(View.GONE);
                }
            }
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                logD("getPublicInfo", "getPublicInfo2: onResponse called =");
                if (mSession.getEnableDebug()) {
                    insertApiData(url, "GET REQUEST IN BODY OF URL", response.toString(), TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_BROKER_PUBLIC_INFO);
                }
                JSONObject jsonObject1 = new JSONObject();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String imagePath = "";

                    if (jsonObject.optInt("status") == 0) {
                        imagePath = Config.IMAGE_PATH + domainName + "_Logo.png";

                        mSession.setAppLogo(imagePath);

                        jsonObject1 = jsonObject.optJSONObject("result");
                        //jsonObject1.put("layout", "5");
                        mSession.setShowBseAuthPopup("1".equals(jsonObject1.optString("showBseAuthPopup").trim()));


                        mSession.setAppLogoName(jsonObject1.optString("logo"));
                        mSession.setFutureProjectionCalculator(jsonObject1.optInt("futureProjectionCalculator"));
                        mSession.setSIPCalculator(jsonObject1.optInt("SIPCalculator"));
                        mSession.setPlayStoreLink(jsonObject1.optString("androidAppLink"));
                        mSession.setAppStoreLink(jsonObject1.optString("iosAppLink"));
                        mSession.setForceUpdate(jsonObject1.optInt("majorUpdate")==1);
                        mSession.setCompanyName(jsonObject1.optString("compName"));
                        mSession.setOnBoarding(jsonObject1.optInt("allowOnboarding"));
                        mSession.setAllowedMobileOTPLogin(jsonObject1.optInt("allowMobileOtpLogin"));
                        mSession.setUserEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setEmail(jsonObject1.optString("email").equalsIgnoreCase("null") ? "" : jsonObject1.optString("email"));
                        mSession.setWebsite(jsonObject1.optString("website").equalsIgnoreCase("null") ? "" : jsonObject1.optString("website"));
                        mSession.setMobileNumber(jsonObject1.optString("mobileNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("mobileNo1"));
                        mSession.setTelNumber(jsonObject1.optString("telNo1").equalsIgnoreCase("null") ? "" : jsonObject1.optString("telNo1"));
                        mSession.setVoltPartnerCode(jsonObject1.optString("voltPartnerCode").equalsIgnoreCase("null") ? "" : jsonObject1.optString("voltPartnerCode"));
                        mSession.setIsRiskProfileMandatory(jsonObject1.optInt("isRiskProfileManadatory"));
                        mSession.setAllowedCrm(jsonObject1.optInt("allowCrm",0)==1);
                        mSession.setExchangeNseBseMfu(jsonObject1.optString("exchange"));
                        mSession.setHasShowXirr(jsonObject1.optString("showXIRR").equals("1"));
                        String domain = jsonObject1.optString("domain");
                        if (!domain.equalsIgnoreCase("null") && !domain.isEmpty()) {
                            mSession.setUserBrokerDomain(domain);
                        }
                        if (mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
                            jsonObject1.put("layout", 6);
                            Log.i("RedmiCalled", "Splash Activity set layout 6 called: ");

                        }
                        Log.i("RedmiCalled", "Splash domain:  "+mSession.getUserBrokerDomain());

                        mSession.setAppInfo("" + jsonObject1);
                        appConfigObject = jsonObject1;

                        String address = "";
                        address = UtilityKotlin.checkAndGetCompanyAddress(jsonObject1);
                        mSession.setAddress(address);
                        mSession.setCustomURL(jsonObject1.getString("customURL").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customURL"));
                        setCustomLinksData(jsonObject1.getString("customLinks").equalsIgnoreCase("null") ? "" : jsonObject1.optString("customLinks"));

                        String slogan = jsonObject1.optString("slogan");
                        if (!slogan.equalsIgnoreCase("null") && !slogan.isEmpty()) {
                            mSession.setSloganOnLogo(slogan);
                        }

                    } else {
                        AppApplication appApplication = (AppApplication) getApplication();
                        appApplication.showCommonDailog(SplashActivity.this, getString(R.string.alert_dialog_error_txt), getString(R.string.alert_dialog_invalid_domain), "error");
                    }
                } catch (Exception e) {

                } finally {
                    if (callFrom.equalsIgnoreCase("deeplinkOnboarding")) {
                        if (mSession.getOnBoarding() == 1) {
                            UtilityKotlin.openNewKycOnboardingInWebView(SplashActivity.this, mSession, "0", "signUp","");
                        } else {
                            //Toast.makeText(getApplicationContext(), "Feature not allowed", Toast.LENGTH_SHORT).show();
                            activitySelection();
                        }
                    }
                }
            }

        });

    }


    public void getConfigData(String domain, Boolean isResetPassword, String token, String callFrom, String uid) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Subdomain", domain);
            jsonObject.put("Language", UtilityKotlin.getLanguageCodeToValueMap().get(mSession.getAppLanguage()));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        KtorHelper.requestCall(this, mSession, Config.APP_CONFIG, ApiRequestType.POST, jsonObject, AppHeaderType.NONE, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    logD("getConfigData", "getConfigData: response = " + response);
                    JSONObject jsonObject1 = new JSONObject(response);
                    if (jsonObject1.optBoolean("Status")) {
                        mSession.setAppConfig(response);
                        redirectMethodForAppConfig(domain, isResetPassword, token, callFrom, uid);

                    } else {
                        mSession.setAppConfig("");
                        if (isResetPassword) {
                            Intent intent3 = new Intent(SplashActivity.this, ResetPasswordActivity.class);
                            intent3.putExtra("token", token);
                            intent3.putExtra("domain_name", mSession.getUserBrokerDomain());
                            startActivity(intent3);
                            finish();
                        } else {
                            if (mSession.getHasLoging()) {
                                if (!mSession.getServerReAuth().trim().isEmpty()) {
                                    reLogin();
                                } else if (!mSession.getUsername().isEmpty() && !mSession.getUserpw().isEmpty()) {
                                    LoginMethod();
                                } else {
                                    activitySelection();
                                }
                            } else {
                                activitySelection();
                            }
                        }
                        //Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_try_again), Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){

                }
            }

            @Override
            public void onError(String errorMessage, int statusCode) {
                mSession.setAppConfig("");
            }
        });

    }


    private void ssoLogin(String token){
        // cache the image url
        String imagePath = Config.IMAGE_PATH + mSession.getUserBrokerDomain() + "_Logo.png";
        mSession.setAppLogo(imagePath);
        Picasso.get().invalidate(imagePath);
        final String imagePathFinal = imagePath;
        Picasso.get().load(imagePath).memoryPolicy(MemoryPolicy.NO_CACHE)
                .networkPolicy(NetworkPolicy.NO_CACHE).into(imageView, new Callback() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onError(Exception e) {
                        Picasso.get().invalidate(imagePathFinal);
                    }
                });



        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SSO_LOGIN;
        JSONObject params = new JSONObject();
        try {
            params.put("SSOToken", token);
        }catch (Exception e){

        }

        KtorHelper.requestCall(this, mSession, url, ApiRequestType.POST, params, AppHeaderType.LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mSession.setShowCrossDialog(true);
                insertApiData(url, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.AUTHENTICATION);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        logD("MintLifeCycleLog", "relogin by user & pass Response received");
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                        if (jsonObjectMain.has("token")) {
                            Intent intent = new Intent(SplashActivity.this, MobileVerificationActivity.class);
                            intent.putExtra("token", jsonObjectMain.optString("token"));
                            intent.putExtra("mobile", jsonObjectMain.optString("mobile"));
                            intent.putExtra("type", "twoFactor");
                            intent.putExtra("isTwoFa", true);
                            startActivity(intent);
                        } else {

                            if (getString(R.string.subdomain).equals("mint")) {
                                AppApplication appApplication = (AppApplication) getApplication();
                                appApplication.GtmSetUp(jsonObjectMain.optString("levelNo"), jsonObjectMain.optString("name"));
                            }

                            mSession.setUsername(jsonObjectMain.optString("username"));
                            mSession.setName(jsonObjectMain.optString("name"));
                            mSession.setPersonName(jsonObjectMain.optString("name"));
                            mSession.setBrokerFullName(jsonObjectMain.optString("name"));
                            mSession.setUid(jsonObjectMain.optString("uid"));
                            mSession.setLead(jsonObjectMain.optString("isLead"));
                            mSession.setUserBrokerDomain(jsonObjectMain.optString("brokerDomain"));
                            mSession.setLoginType(jsonObjectMain.optString("userType"));
                            mSession.setLevelId(jsonObjectMain.optString("levelid"));
                            mSession.setBid(jsonObjectMain.optString("bid"));
                            mSession.setBrokerUID(jsonObjectMain.optString("brokerUid"));
                            mSession.setLowerReportingLevels(jsonObjectMain.optString("lowerReportingLevels"));
                            mSession.setLevelNo(jsonObjectMain.optString("levelNo"));
                            mSession.setReportingLevelName(jsonObjectMain.optString("reportingLevelName"));
                            mSession.setAllLoginData(response);
                            mSession.setHideXirr(jsonObjectMain.optString("hideXirr"));
                            mSession.setPAN(jsonObjectMain.optString("pan"));
                            mSession.setAppId(jsonObjectMain.optString("appid"));

                            mSession.setEmail(jsonObjectMain.optString("email"));
                            mSession.setClientPhotoName(jsonObjectMain.optString("profileImage"));
                            mSession.setPhone(jsonObjectMain.optString("phone").equalsIgnoreCase("null") ? "" : jsonObjectMain.optString("phone"));
                            AppApplication appApplication = (AppApplication) getApplication();
                            appApplication.removedTempData();

                            mSession.setHasNse2Opted(jsonObjectMain.optString("nseInvestOpted").equals("1"));

                            if (jsonObjectMain.optString("allowSOADownload").equals("1")) {
                                mSession.setHasSoaDownloadEnable(true);
                            } else {
                                mSession.setHasSoaDownloadEnable(false);
                            }
                            AppApplication.sExchangeType = "";

                            if (jsonObjectMain.optString("txnEnable").equals("1")) {
                                mSession.setHasTransectionEnable(true);
                            } else {
                                mSession.setHasTransectionEnable(false);
                            }

                            if (jsonObjectMain.optString("useEdge360").equals("1")) {
                                mSession.setHasEdge360(true);
                            } else {
                                mSession.setHasEdge360(false);
                            }

                            if (jsonObjectMain.optString("hideMetrics").equals("1")) {
                                mSession.setHasBDCardWithStar(true);
                            } else {
                                mSession.setHasBDCardWithStar(false);
                            }

                            if (jsonObjectMain.optString("bseOpted").equals("1")) {
                                mSession.setHasBseOpted(true);
                            } else {
                                mSession.setHasBseOpted(false);
                            }

                            if (jsonObjectMain.optString("nseOpted").equals("1")) {
                                mSession.setHasNseOpted(true);
                            } else {
                                mSession.setHasNseOpted(false);
                            }

                            if (jsonObjectMain.optString("mfuOpted").equals("1")) {
                                mSession.setHasMfuOpted(true);
                            } else {
                                mSession.setHasMfuOpted(false);
                            }

                            if (mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted()) && !mSession.getHasMfuOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasBseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasBseOpted() && !mSession.getHasNse2Opted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasMfuOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else if ((mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasNseOpted()) {
                                mSession.setHasMultiExchange(true);
                            } else {
                                mSession.setHasMultiExchange(false);
                            }
                            // nseInvest can't be default exchange
                            if (!mSession.getHasMultiExchange()){
                                boolean hasBse = mSession.getHasBseOpted();
                                boolean hasNse = mSession.getHasNseOpted();
                                boolean hasMfu = mSession.getHasMfuOpted();
                                boolean hasNse2 = mSession.getHasNse2Opted();
                                String exchange = "";
                                if (hasNse) {
                                    exchange = "1";
                                } else if (hasBse) {
                                    exchange = "2";
                                } else if (hasMfu) {
                                    exchange = "3";
                                } else if (hasNse2) {
                                    exchange = "4";
                                }
                                mSession.setExchangeNseBseMfu(exchange);
                            }


                            mSession.setHasLoging(true);
                            Config.sOncePopupPerLoginSession = false;
                            callAllowedFeatures();
                        }

                    } else {
                        String errorMessge = jsonObject.optString("message");
                        if (!errorMessge.equalsIgnoreCase("invalid request"))
                            Toast.makeText(SplashActivity.this, errorMessge, Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    String data = e.getLocalizedMessage();
                    System.out.println(data);
                }
            }

        });


    }

    private void redirectMethodForAppConfig(String domain, Boolean isResetPassword, String token, String callFrom, String uid){
        if (callFrom.equalsIgnoreCase("deeplinkWeb")) {
            adminLoginMethod(domain, token, uid);
        } else if (callFrom.equalsIgnoreCase("deeplinkApp")) {
            reLogin();
        } else if (mType.equalsIgnoreCase("generateReAuth")) {
            reLogin();
        } else if (callFrom.equalsIgnoreCase("ssologin")) {
            ssoLogin(ssoToken);
        }else {
            if (isResetPassword) {
                Intent intent3 = new Intent(SplashActivity.this, ResetPasswordActivity.class);
                intent3.putExtra("token", token);
                intent3.putExtra("domain_name", mSession.getUserBrokerDomain());
                startActivity(intent3);
                finish();
            } else {
                if (mSession.getHasLoging()) {
                    if (!mSession.getServerReAuth().trim().isEmpty()) {
                        reLogin();
                    } else if (!mSession.getUsername().isEmpty() && !mSession.getUserpw().isEmpty()) {
                        LoginMethod();
                    } else {
                        activitySelection();
                    }
                } else {
                    activitySelection();
                }
            }
        }
    }

    private void setCustomLinksData(String data) {
        List<String> keywords = List.of("Policies & Agreements", "Grievance Redressal", "Legal & Regulatory");
        JSONArray jsonArray = null;
        ArrayList<JSONObject> jsonObjects = new ArrayList<>();
        try {
            if (data.length() != 0) {
                jsonArray = new JSONArray(data);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String title = jsonObject.optString("title");
                    if (keywords.contains(title)) {
                        // matching keywords
                        jsonObjects.add(jsonObject);
                    }
                }
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        } finally {
            mSession.setCustomLinksForContactUs("" + jsonObjects);
        }
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == RC_LANGUAGE_SELECTION) {
//            // Continue normal app flow
//            mSession.setHasFirstTimeSplashLaunch(false);
//            activitySelectionContinue();
//        }
//    }



}

