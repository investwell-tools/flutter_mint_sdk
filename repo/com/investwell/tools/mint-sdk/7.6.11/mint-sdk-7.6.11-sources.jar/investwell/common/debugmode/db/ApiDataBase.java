package investwell.common.debugmode.db;

import static investwell.di.core.LogExtKt.logD;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.room.AutoMigration;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.iw.mint.sdk.BuildConfig;

import net.zetetic.database.sqlcipher.SQLiteConnection;
import net.zetetic.database.sqlcipher.SQLiteDatabase;
import net.zetetic.database.sqlcipher.SQLiteDatabaseHook;
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory;

import java.io.File;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

import investwell.common.checkkyc.dto.KYCData;
import investwell.common.checkkyc.dto.KycDataDao;
import investwell.di.Converters;
import investwell.di.dao.GoalModuleDaoTwo;
import investwell.di.data.GoalData;

@Database(
        entities = {
                ApiDataModel.class,
                GoalData.class,
                KYCData.class
        }, exportSchema = true,
        version = 3,
        autoMigrations = {
            @AutoMigration(from = 1, to = 2),
            @AutoMigration(from = 2, to = 3)
        }
)
@TypeConverters(Converters.class)
public abstract class ApiDataBase extends RoomDatabase {
    private static final String DB_NAME = "api_db";
    private static final String ENCRYPTED_DB_NAME = "api_db_encrypted"; // Encrypted database name
    private static final String TAG = "ApiDataBase";

    private static ApiDataBase apiDataBase;
    private static boolean isSqlCipherLoaded = false;
//    private static final byte[] ENCRYPTION_PASSWORD = BuildConfig.LIBRARY_PACKAGE_NAME.getBytes();
    private static byte[] ENCRYPTION_PASSWORD;
    private static final String FALLBACK_PREF_NAME = "mint_db_key_fallback_pref";
    private static final String FALLBACK_KEY_NAME = "db_key_fallback";

    private static synchronized byte[] getEncryptionPassword(Context context) {

        if (ENCRYPTION_PASSWORD != null) {
            return ENCRYPTION_PASSWORD;
        }

        try {
            SharedPreferences prefs;
            MasterKey masterKey =
                    new MasterKey.Builder(context.getApplicationContext())
                            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                            .build();
            prefs = EncryptedSharedPreferences.create(
                    context.getApplicationContext(),
                    "secure_sql_pref",
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
            final String KEY_NAME = "sqlcipher_passphrase";
            String existingKey =
                    prefs.getString(KEY_NAME, null);
            if (existingKey != null && !existingKey.isEmpty()) {
                ENCRYPTION_PASSWORD =
                        Base64.decode(
                                existingKey,
                                Base64.NO_WRAP
                        );
                return ENCRYPTION_PASSWORD;
            }
            byte[] newKey = new byte[32];
            SecureRandom secureRandom =
                    new SecureRandom();
            secureRandom.nextBytes(newKey);

            prefs.edit()
                    .putString(
                            KEY_NAME,
                            Base64.encodeToString(
                                    newKey,
                                    Base64.NO_WRAP
                            )
                    )
                    .commit();

            ENCRYPTION_PASSWORD = newKey;

            return ENCRYPTION_PASSWORD;

        } catch (Exception e) {

            e.printStackTrace();

            ENCRYPTION_PASSWORD = getOrCreateFallbackKey(context);

            return ENCRYPTION_PASSWORD;
        }
    }

    /**
     * Used only when EncryptedSharedPreferences/Keystore is unavailable on the device.
     * Persisted in plain SharedPreferences so the same key survives across app
     * restarts; without this, a fresh random key on every launch would fail to
     * decrypt the previous run's database and force a destructive recreation
     * (data loss) every single time.
     */
    private static byte[] getOrCreateFallbackKey(Context context) {
        SharedPreferences fallbackPrefs =
                context.getApplicationContext()
                        .getSharedPreferences(FALLBACK_PREF_NAME, Context.MODE_PRIVATE);

        String existingKey = fallbackPrefs.getString(FALLBACK_KEY_NAME, null);
        if (existingKey != null && !existingKey.isEmpty()) {
            return Base64.decode(existingKey, Base64.NO_WRAP);
        }

        byte[] newKey = new byte[32];
        new SecureRandom().nextBytes(newKey);

        fallbackPrefs.edit()
                .putString(FALLBACK_KEY_NAME, Base64.encodeToString(newKey, Base64.NO_WRAP))
                .commit();

        return newKey;
    }

    private static  SQLiteDatabaseHook getHookSupport(boolean isEncrypted){
        return new SQLiteDatabaseHook() {
            @Override
            public void preKey(SQLiteConnection connection) {

            }

            @Override
            public void postKey(SQLiteConnection connection) {

                try {
                    if (connection != null && !isEncrypted) {
                        logD("DB_MIGRATION :-----> DB_HOOK :----> Applying cipher_page_size = 16384");
                        connection.execute("PRAGMA cipher_page_size = 16384;", null, null);
                    }
                } catch (Exception e) {
                    logD("DB_MIGRATION :-----> DB_HOOK :----> Error setting cipher_page_size", e);
                }
            }
        };
    }

    private static ApiDataBase buildDatabase(Context appContext, SupportOpenHelperFactory factory) {
        return Room.databaseBuilder(
                        appContext,
                        ApiDataBase.class,
                        ENCRYPTED_DB_NAME
                )
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration()
                .build();
    }

    public static synchronized ApiDataBase getInstance(Context context) {

        if (apiDataBase != null) {
            return apiDataBase;
        }

        Context appContext =
                context.getApplicationContext();

        try {

            SupportOpenHelperFactory factory =
                    new SupportOpenHelperFactory(
                            getEncryptionPassword(appContext)
                    );

            apiDataBase = buildDatabase(appContext, factory);

            apiDataBase.getOpenHelper()
                    .getWritableDatabase();

        } catch (Exception e) {
            logD("DB_MIGRATION :-----> Failed to open " + ENCRYPTED_DB_NAME
                    + " with current key; treating as key-rotation cache invalidation and recreating. Cause: " + e);
            File db =
                    context.getDatabasePath(
                            ENCRYPTED_DB_NAME
                    );
            db.delete();
            SupportOpenHelperFactory factory =
                    new SupportOpenHelperFactory(
                            getEncryptionPassword(appContext)
                    );
            apiDataBase = buildDatabase(appContext, factory);
        }

        return apiDataBase;
    }

    private static final Migration MIGRATION_2_3 = new Migration(2, 3) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase database) {
            database.execSQL("CREATE TABLE IF NOT EXISTS `${TABLE_NAME}` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `amountReqFutureVal` REAL NOT NULL, `amountReqTodayVal` INTEGER, `appid` TEXT NOT NULL, `category` TEXT NOT NULL, `categoryid` TEXT NOT NULL, `checksum` TEXT, `createdAt` TEXT NOT NULL, `currentSavings` TEXT, `expectedReturn` INTEGER, `expense` TEXT NOT NULL, `expenseGrowth` TEXT NOT NULL, `goalName` TEXT, `goalid` TEXT, `imagePath` TEXT NOT NULL, `income` TEXT, `incomeGrowth` TEXT, `inflationRate` INTEGER, `lifeExpectancy` TEXT, `monthlyExpenses` TEXT, `monthlyExpensesFuture` TEXT, `name` TEXT NOT NULL, `postRetirementReturn` TEXT, `preRetirementReturn` TEXT, `priority` INTEGER, `requirementDate` TEXT NOT NULL, `retirementAge` TEXT, `savingsPerMonth` TEXT, `startAge` TEXT, `startDate` TEXT NOT NULL, `updatedAt` TEXT NOT NULL)");
        }
    };

    public abstract ApiDao apiDao();

    public abstract GoalModuleDaoTwo getGoalDao();
    public abstract KycDataDao getKyc();
}
