package investwell.charts.mikephil.charting.interfaces.dataprovider;

import investwell.charts.mikephil.charting.components.YAxis;
import investwell.charts.mikephil.charting.data.LineData;

public interface LineDataProvider extends BarLineScatterCandleBubbleDataProvider {

    LineData getLineData();

    YAxis getAxis(YAxis.AxisDependency dependency);
}
