package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.iw.mint.sdk.R;

import investwell.broker.bseOnboarding.BrokerBse_SignatureAdapter;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.Utils;

public class Portfolio_Client_Adapter extends RecyclerView.Adapter<Portfolio_Client_Adapter.MyViewHolder> {
    private ArrayList<JSONObject> jsonObjects;
    Context context;
    private AppSession mSession;
    private ClientActivity mActivity;
    private OnItemClickListener listener;


    public interface OnItemClickListener {
        void onItemClick(int pos, JSONObject jsonObject);
    }

    public Portfolio_Client_Adapter(Context context, ArrayList<JSONObject> jsonObjects, OnItemClickListener listener) {
        this.context = context;
        this.jsonObjects = jsonObjects;
        mSession = AppSession.getInstance(context);
        mActivity = (ClientActivity) context;
        this.listener = listener;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_design, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder,  int position) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        final JSONObject jsonObject = jsonObjects.get(position);

        holder.tvScheme.setText(jsonObject.optString("schemeName"));
        holder.applicant_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("investor")));
        double currentValue = jsonObject.optDouble("AUM");
        String strCurrentValue = format.format(currentValue);
        holder.market_value.setText(strCurrentValue);
        holder.folio.setText(jsonObject.optString("folioNo"));


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClick(position, jsonObject);
            }
        });


    }

    @Override
    public int getItemCount() {

        return jsonObjects.size();
    }

    public void updateList(List<JSONObject> list) {

        jsonObjects.clear();
        jsonObjects.addAll(list);
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView applicant_name, market_value, tvScheme, folio;
        ImageView next_arrow;
        ImageView gain_arrow, cagr_arrow;
        LinearLayout top_linear_layout;


        public MyViewHolder(View view) {
            super(view);

            applicant_name = view.findViewById(R.id.applicant_name);
            tvScheme = view.findViewById(R.id.tvScheme);
            market_value = view.findViewById(R.id.market_value);
            folio = view.findViewById(R.id.folio);

        }
    }
}
