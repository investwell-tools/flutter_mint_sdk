package investwell.client.fragments.aum;

import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Frag_Aum_Adapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

;


public class FragAumReportByScheme extends BaseFragment implements View.OnClickListener {
    TextView mTvTotal, mTvDEbt, mTvEquity, tvName, mTvOther, mTvArbi, mTvLiqUltra, tvHybrid;
    Frag_Aum_Adapter mAumAdapter;

    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mLinerMain;
    private TextView mTvNothing;
    private String mFundId,mFilter="",ARNID="",CATEGORY="";
    private AppApplication mAppplication;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private BrokerActivity mBrokerActivity;
    private ProgressDialog mBar = null;


    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mMainActivity.setMainVisibility(this, null);
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();

        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.aum_report),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_aum_report_scheme, container, false);
        setUpToolBar();
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mLinerMain = view.findViewById(R.id.linerMain);
        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llAumReportScheme).setBackgroundResource(R.mipmap.card_blank);
        mTvNothing = view.findViewById(R.id.tvNothing);


        mTvTotal = view.findViewById(R.id.tvTotal);
        mTvDEbt = view.findViewById(R.id.tvDept);
        mTvEquity = view.findViewById(R.id.tvEquity);
        mTvLiqUltra = view.findViewById(R.id.tvLiqUltra);
        mTvOther = view.findViewById(R.id.tvOther);
        mTvArbi = view.findViewById(R.id.tvArbi);
        //tvName = view.findViewById(R.id.tvName);
        tvHybrid = view.findViewById(R.id.tvHybrid);


        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("fundid")) {
            mFundId = bundle.getString("fundid");
            mFilter = bundle.getString("filter");
            String name = bundle.getString("name");
            ARNID =bundle.getString("arnid");
            CATEGORY =bundle.getString("category");
            //tvName.setText(name);
        }


        RecyclerView recycleView = view.findViewById(R.id.recycleView);

        recycleView.setHasFixedSize(true);
        recycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mAumAdapter = new Frag_Aum_Adapter(getActivity(), new ArrayList<JSONObject>(), new Frag_Aum_Adapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    JSONObject jsonObject = mAumAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("fundid", mFundId);
                    bundle1.putString("arnid",ARNID);
                    bundle1.putString("category",CATEGORY);
                    String schemeId = Utils.getSchemeIdFromAll(jsonObject);
                    bundle1.putString("schemeId", schemeId);
                    bundle1.putString("name", jsonObject.optString("name"));
                    bundle1.putString("isAnimation", "true");

                    if (mBrokerActivity != null)
                        mBrokerActivity.displayViewOther(26, bundle1);
                    else
                        mActivity.displayViewOther(26, bundle1);
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        recycleView.setAdapter(mAumAdapter);
        if (!mFilter.isEmpty())
            getFilterData();
        else
            getAumDetails(mFundId);



        return view;
    }

    private void getFilterData() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "",uid="";
        try {
            JSONArray filtersArray = new JSONArray();
            JSONObject filter4 = new JSONObject();
            JSONObject filter2 = new JSONObject();
            JSONObject filter3 = new JSONObject();
            JSONObject selectedUser = new JSONObject();
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "aumReport");

            filter4.put("fundid",mFundId);
            filter3.put("selectedUser",AppApplication.AUM_FILTER3);
            filtersArray.put(AppApplication.AUM_FILTER1);
            filtersArray.put(AppApplication.AUM_FILTER2);
            filtersArray.put(AppApplication.AUM_FILTER3);
            filtersArray.put(filter4);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.GET_AUM_REPORT
                    + "currentPage=1&pageSize=100&orderBy=name&orderByDesc=false&groupBy=1002"+"&filters="+filtersArray.toString() + "";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }


        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity());
                } else {
                    ProgressBarCommon.dismissDialog();

                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        SetData(response);

                    } else if (jsonObject.optInt("status") == -1) {
                        if (mBrokerActivity != null) {
                            Toast.makeText(mBrokerActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mMainActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {

                }
            }
        });
    }


    @Override
    public void onClick(View v) {


    }

    private void SetData(String data) {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        try {
            ArrayList<JSONObject> list = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                if (jsonArray.length() > 0) {
                    JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                    mLinerMain.setVisibility(View.VISIBLE);
                    mTvNothing.setVisibility(View.GONE);

                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    format.setMinimumFractionDigits(0);
                    format.setMaximumFractionDigits(0);

                    double AUM = jsonObjectSummary.optDouble("AUM");
                    String strAUM = format.format(AUM);
                    mTvTotal.setText(strAUM);

                    double Debt = jsonObjectSummary.optDouble("Debt");
                    String strDebt = format.format(Debt);
                    mTvDEbt.setText(strDebt);

                    double Equity = jsonObjectSummary.optDouble("Equity");
                    String strEquity = format.format(Equity);
                    mTvEquity.setText(strEquity);


                    double liqAltra = jsonObjectSummary.optDouble("Liquid and Ultra Short");
                    String strliqAltra = format.format(liqAltra);
                    mTvLiqUltra.setText(strliqAltra);

                    double Other = jsonObjectSummary.optDouble("Other");
                    String strOther = format.format(Other);
                    mTvOther.setText(strOther);

                    double Arbitrage = jsonObjectSummary.optDouble("Arbitrage");
                    String strArbitrage = format.format(Arbitrage);
                    mTvArbi.setText(strArbitrage);

                    double Hybrid = jsonObjectSummary.optDouble("Hybrid");
                    String strHybrid = format.format(Hybrid);
                    tvHybrid.setText(strHybrid);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        list.add(jsonObject1);
                    }
                    if (!mFilter.isEmpty())
                        mAumAdapter.updateList(list, mFilter);
                    else
                        mAumAdapter.updateList(list, "data_by_scheme");

                } else {
                    mTvNothing.setVisibility(View.VISIBLE);
                }


            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getAumDetails(String fundId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";

        try {
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObjec = new JSONObject();
            jsonObjec.put("fundid", fundId);
            jsonArray.put(jsonObjec);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +  Config.GET_AUM_REPORT
                    + "filters=" + jsonArray.toString() + "&groupBy=1002&orderBy=AUM&orderByDesc=true"
                    + "&pageSize=100" +
                    "&currentPage=1";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }


        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.VISIBLE);
                } else {
                    mShimmerViewContainer.stopShimmer();
                    mShimmerViewContainer.setVisibility(View.GONE);

                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                SetData(response);
            }
        });
    }


}
