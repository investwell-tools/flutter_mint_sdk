package investwell.utils;

import static investwell.di.core.LogExtKt.logD;
import static investwell.di.core.LogExtKt.logI;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import com.iw.mint.sdk.R;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Map;
import java.util.Set;

import investwell.di.core.BaseUrls;

/**
 * Created by SK-Accocoate on 09/26/2015.
 */
public class AppSession {

    public static int value;
    private static AppSession Instance;
    private EncryptedSharedPreferences prefs;
//    private SharedPreferences prefs;
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    private static final String IS_THUMBS_DOWN = "IsThumbDown";
    private static final String IS_THUMBS_UP = "IsThumbUp";
    private static final String SHARED_PREFS_FILE = "secure_shared_prefs";
    private static final String EXISTING_SHARED_PREFS_FILE = "shared_prefs";

    public AppSession(Context cntx) {
        try {
            MasterKey masterKey = new MasterKey.Builder(cntx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            prefs = (EncryptedSharedPreferences) EncryptedSharedPreferences.create(
                    cntx,
                    SHARED_PREFS_FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );

        } catch (Exception  e){
            logD(e);
        }

    }

    public static AppSession getInstance(Context cntx) {
        if (Instance == null) {
            synchronized (AppSession.class){
                if (Instance==null){
                    Instance = new AppSession(cntx);
                }
                BaseUrls.setUrls("https://" + Instance.getUserBrokerDomain() + Instance.getHostingPath());
            }
        }
        return Instance;
    }

    public void setAppLanguage(String language) {
        prefs.edit().putString("applanguage",language).apply();
    }
    public String getAppLanguage() {
        return prefs.getString("applanguage", "en");
    }

    public void setLastReAuthTime(String lastReAuthTime) {
        prefs.edit().putString("lastReAuthTime", lastReAuthTime).apply();
    }

    public String getLastReAuthTime() {
        return prefs.getString("lastReAuthTime", "0");
    }



    public void setLastAppInBgTime(long lastAppInBgTime) {
        prefs.edit().putLong("lastAppInBgTime", lastAppInBgTime).apply();
    }

    public long getLastAppInBgTime() {
        return prefs.getLong("lastAppInBgTime", 0);
    }


    public String getUserpw() {
        return prefs.getString("userpw", "");
    }

    public void setUserpw(String userpw) {
        prefs.edit().putString("userpw", userpw).apply();
    }

    public void setLastReloginTime(String lastReloginTime) {
        prefs.edit().putString("lastReloginTime", lastReloginTime).apply();
    }

    public String getLastReloginTime() {
        return prefs.getString("lastReloginTime", "0");
    }

    public void setTestDomainType(String testDomainType) {
        prefs.edit().putString("testDomainType", testDomainType).apply();
    }

    public String getTestDomainType() {
        return prefs.getString("testDomainType", "");
    }


    public void setLastBaseFragTime(String lastReAuthTime) {
        prefs.edit().putString("lastBaseFragTime", lastReAuthTime).apply();
    }

    public String getLastBaseFragTime() {
        return prefs.getString("lastBaseFragTime", "0");
    }


    public String getRefreshKey() {
        return prefs.getString("refreshKey", "");
    }

    public void setRefreshKey(String refreshKey) {
        prefs.edit().putString("refreshKey", refreshKey).apply();
    }

    public String getStoreApi() {
        return prefs.getString("storeApi", "");
    }

    public void setStoreApi(String storeApi) {
        prefs.edit().putString("storeApi", storeApi).apply();
    }


    public String getDeviceUniqueID() {
        return prefs.getString("dvDI", "");
    }

    public void setDeviceUniqueID(String dvDI) {
        prefs.edit().putString("dvDI", dvDI).apply();
    }

    // for Review
    public boolean getHasFirstTimeReviewShown() {
        return prefs.getBoolean("hasFirstTimeReviewShown", false);
    }

    public void setHasFirstTimeReviewShown(boolean hasFirstTimeReviewShown) {
        prefs.edit().putBoolean("hasFirstTimeReviewShown", hasFirstTimeReviewShown).apply();
    }


    public void setCurrentDate(String currentDate) {
        prefs.edit().putString("iscurrentdate", currentDate).apply();
    }

    public String getCurrentdate() {
        return prefs.getString("iscurrentdate", "");
    }

    public boolean getIsAmountHideHome3() {
        return prefs.getBoolean("isAmountHideHome3", false);
    }

    public void setIsAmountHideHome3(boolean isAmountHideHome3) {
        prefs.edit().putBoolean("isAmountHideHome3", isAmountHideHome3).apply();
    }

    public boolean getIsAssetHideHome3() {
        return prefs.getBoolean("isAssetHideHome3", false);
    }

    public void setIsAssetHideHome3(boolean isAssetHideHome3) {
        prefs.edit().putBoolean("isAssetHideHome3", isAssetHideHome3).apply();
    }

    public boolean getIsQuickReportHideHome3() {
        return prefs.getBoolean("isQuickReportHideHome3", false);
    }

    public void setIsQuickReportHideHome3(boolean isQuickReportHideHome3) {
        prefs.edit().putBoolean("isQuickReportHideHome3", isQuickReportHideHome3).apply();
    }

    // for Debug
    public boolean getEnableDebug() {
        return prefs.getBoolean("debugMode", false);
    }

    public void setEnableDebug(boolean debugMode) {
        prefs.edit().putBoolean("debugMode", debugMode).apply();
    }

    public String getFcmToken() {
        return prefs.getString("device_token", "");
    }

    public void setFcmToken(String devicetokn) {
        prefs.edit().putString("device_token", devicetokn).apply();
    }

    public String getNotification() {
        return prefs.getString("Notification", "");
    }

    public void setNotification(String Notification) {
        prefs.edit().putString("Notification", Notification).apply();
    }

    public void setNotifyIcon(String notifyIcon) {
        prefs.edit().putString("notifyIcon", notifyIcon).apply();
    }

    public String getNotifyIcon() {
        return prefs.getString("notifyIcon", "");
    }

    public void saveCurrentDate(String currentDate) {
        prefs.edit().putString("mcurrentDate", currentDate).apply();
    }


    public String getUserMob() {
        return prefs.getString("mob", "");
    }

    public void setUserMob(String mob) {
        prefs.edit().putString("mob", mob).apply();
    }

    public boolean getHasShowXirr() {
        return prefs.getBoolean("hasShowXirr", false);
    }

    public void setHasShowXirr(boolean hasShowXirr) {
        prefs.edit().putBoolean("hasShowXirr", hasShowXirr).apply();
    }

    public boolean getAskMeLater() {
        return prefs.getBoolean("askMeLater", false);
    }

    public void setAskMeLater(boolean askMeLater) {
        prefs.edit().putBoolean("askMeLater", askMeLater).apply();
    }

    public void setShownDateOfReview(String shownDateOfReview) {
        prefs.edit().putString("shownDateOfReview", shownDateOfReview).apply();
    }

    public String getShownDateOfReview() {
        return prefs.getString("shownDateOfReview", "");
    }

    public void setCountOfAppOpen(int countOfAppOpen) {
        prefs.edit().putInt("countOfAppOpen", countOfAppOpen).apply();
    }

    public void setActionCount(int countOfActionCount) {
        prefs.edit().putInt("countOfActionCount", countOfActionCount).apply();
    }

    public int getCountOfAppOpen() {
        return prefs.getInt("countOfAppOpen", 0);
    }

    public int getActionCount() {
        return prefs.getInt("countOfActionCount", 0);
    }

    public boolean getRatingSubmitted() {
        return prefs.getBoolean(IS_THUMBS_UP, false);
    }

    public void setRatingSubmitted(boolean isUp) {
        prefs.edit().putBoolean(IS_THUMBS_UP, isUp).apply();
    }

    public boolean getThumbsDownClicked() {
        return prefs.getBoolean(IS_THUMBS_DOWN, false);
    }

    public void setThumbsDownClicked(boolean isDown) {
        prefs.edit().putBoolean(IS_THUMBS_DOWN, isDown).apply();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        prefs.edit().putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime).apply();
    }

    public boolean isFirstTimeLaunch() {
        return prefs.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void setCountOfScreen(int countOfScreen) {
        prefs.edit().putInt("countOfScreen", countOfScreen).apply();
    }

    public int getCountOfScreen() {
        return prefs.getInt("countOfScreen", 0);
    }

    public void setNfo(int nfo) {
        prefs.edit().putInt("nfo", nfo).apply();
    }

    public int getNfo() {
        return prefs.getInt("nfo", 0);
    }
    // for Review

    public void setSIPCalculator(int i) {
        prefs.edit().putInt("SIPCalculator", i).apply();
    }

    public void setForceUpdate(boolean isForce){
        prefs.edit().putBoolean("isforce",isForce).apply();
    }

    public boolean getForceUpdate(){
        return prefs.getBoolean("isforce",false);
    }

    public int getSIPCalculator() {
        return prefs.getInt("SIPCalculator", 0);
    }

    public void setFutureProjectionCalculator(int i) {
        prefs.edit().putInt("futureProjectionCalculator", i).apply();
    }

    public int getFutureProjectionCalculator() {
        return prefs.getInt("futureProjectionCalculator", 0);
    }


    public void setAppLogo(String appLogo) {
        prefs.edit().putString("appLogo", appLogo).apply();
    }

    public String getAppLogo() {
        return prefs.getString("appLogo", "");
    }


    public void setAppLogoName(String appLogoName) {
        prefs.edit().putString("appLogoName", appLogoName).apply();
    }

    public String getAppLogoName() {
        return prefs.getString("appLogoName", "");
    }

    public String getCompanyName() {
        return prefs.getString("companyName", "");
    }

    public void setCompanyName(String companyName) {
        prefs.edit().putString("companyName", companyName).apply();
    }

    public String getCompanyLogo() {
        return prefs.getString("companyLogo", "");
    }


    public void setExchangeNseBseMfu(String exchangeNseBseMfu) {
        prefs.edit().putString("exchangeNseBseMfu", exchangeNseBseMfu).apply();
    }

    public String getExchangeNseBseMfu() {
        return prefs.getString("exchangeNseBseMfu", "");
    }

    public boolean getHasFirstTimeAppIntroLaunched() {
        return prefs.getBoolean("firstTimeAppIntroLaunched", false);
    }

    public void setHasFirstTimeAppIntroLaunched(boolean firstTimeAppIntroLaunched) {
        prefs.edit().putBoolean("firstTimeAppIntroLaunched", firstTimeAppIntroLaunched).apply();
    }

    public boolean getHasNotificationEnable() {
        return prefs.getBoolean("hasNotificationEnable", false);
    }

    public void setHasNotificationEnable(boolean hasNotificationEnable) {
        prefs.edit().putBoolean("hasNotificationEnable", hasNotificationEnable).apply();
    }

    public void setAppType(String appType) {
        prefs.edit().putString("appType", appType).apply();
    }

    public String getAppType() {
        return prefs.getString("appType", "");
    }

    public void setUsername(String username) {
        prefs.edit().putString("username", username).apply();
    }

    public String getUsername() {
        return prefs.getString("username", "");
    }

    public void setName(String name) {
        prefs.edit().putString("name", name).apply();
    }

    public String getName() {
        return prefs.getString("name", "");
    }

    public void setPersonName(String personName) {
        prefs.edit().putString("personName", personName).apply();
    }

    public String getPersonName() {
        return prefs.getString("personName", "");
    }

    public void setLead(String isLead) {
        prefs.edit().putString("isLead", isLead).apply();
    }

    public String getLead() {
        return prefs.getString("isLead", "");
    }

    public String getBrokerFullName() {
        return prefs.getString("brokerFullName", "");
    }

    public void setBrokerFullName(String brokerFullName) {
        prefs.edit().putString("brokerFullName", brokerFullName).apply();
    }


    public void setType(String type) {
        prefs.edit().putString("type", type).apply();
    }

    public String getType() {
        return prefs.getString("type", "familyHead");
    }

    public void setUid(String uid) {
        prefs.edit().putString("uid", uid).apply();
    }

    public String getUid() {
        return prefs.getString("uid", "");
    }

    public void setLevelId(String levelId) {
        prefs.edit().putString("levelId", levelId).apply();
    }

    public String getLevelId() {
        return prefs.getString("levelId", "");
    }

    public void setBid(String bid) {
        prefs.edit().putString("bid", bid).apply();
    }

    public String getBid() {
        return prefs.getString("bid", "");
    }

    public void setBrokerUID(String setBrokerUID) {
        prefs.edit().putString("setBrokerUID", setBrokerUID).apply();
    }

    public String getBrokerUID() {
        return prefs.getString("setBrokerUID", "");
    }

    public void setLowerReportingLevels(String lowerReportingLevels) {
        prefs.edit().putString("lowerReportingLevels", lowerReportingLevels).apply();
    }

    public String getLowerReportingLevels() {
        return prefs.getString("lowerReportingLevels", "");
    }

    public void setLevelNo(String levelNo) {
        prefs.edit().putString("levelNo", levelNo).apply();
    }

    public String getLevelNo() {
        return prefs.getString("levelNo", "");
    }

    public void setAllLoginData(String response) {
        prefs.edit().putString("response", response).apply();
    }

    public String getAllLoginData() {
        return prefs.getString("response", "");
    }

    public void setHideXirr(String hideXirr) {
        prefs.edit().putString("hideXirr", hideXirr).apply();
    }

    public String getHideXirr() {
        return prefs.getString("hideXirr", "");
    }


    public void setReportingLevelName(String reportingLevelName) {
        prefs.edit().putString("reportingLevelName", reportingLevelName).apply();
    }

    public String getReportingLevelName() {
        return prefs.getString("reportingLevelName", "");
    }

    public String getVoltAuthToken() {
        return prefs.getString("voltAuthToken", "");
    }

    public void setVoltAuthToken(String voltAuthToken) {
        prefs.edit().putString("voltAuthToken", voltAuthToken).apply();
    }

    public String getServerToken() {
        return prefs.getString("serverToken", "");
    }


    public void setServerToken(String serverToken) {
        prefs.edit().putString("serverToken", serverToken).apply();
    }

    public String getGenVoltPartnerCode() {
        String genVoltPartnerCode = prefs.getString("genVoltPartnerCode", "");
        System.out.println("auth" + genVoltPartnerCode);
        return genVoltPartnerCode;
    }

    public void setGenVoltPartnerCode(String genVoltPartnerCode) {
        prefs.edit().putString("genVoltPartnerCode", genVoltPartnerCode).apply();
    }


    public String getServerTokenID() {
        return prefs.getString("serverTokenID", "");
    }

    public void setServerTokenID(String serverTokenID) {
        prefs.edit().putString("serverTokenID", serverTokenID).apply();
    }

    public String getServerReAuth() {
        return prefs.getString("serverReAuth", "");
    }

    public void setServerReAuth(String serverReAuth) {
        prefs.edit().putString("serverReAuth", serverReAuth).apply();
    }


    public String getUserId() {
        return prefs.getString("id", "");
    }

    public void setUserId(String id) {
        prefs.edit().putString("id", id).apply();
    }

    public String getIinId() {
        return prefs.getString("iinId", "");
    }

    public void setIinId(String iinId) {
        prefs.edit().putString("iinId", iinId).apply();
    }


    public String getUserBrokerDomain() {
        return prefs.getString("userBrokerDomain", "");
    }

    public void setUserBrokerDomain(String userBrokerDomain) {
        prefs.edit().putString("userBrokerDomain", userBrokerDomain).apply();
    }

    public String getCallFromPackage() {
        String hostingPath = prefs.getString("callfrompackage", "");
        return hostingPath;
    }

    public void  setCallFromPackage(String path){
        prefs.edit().putString("callfrompackage",path).commit();
    }
    public String getHostingPath() {
        return prefs.getString("hostingPath", "");
    }

    public void setHostingPath(String hostingPath) {
        prefs.edit().putString("hostingPath", hostingPath).apply();
    }

    public boolean getHasSoaDownloadEnable() {
        return prefs.getBoolean("hasSoaDownloadEnable", false);
    }

    public void setHasSoaDownloadEnable(boolean hasSoaDownloadEnable) {
        prefs.edit().putBoolean("hasSoaDownloadEnable", hasSoaDownloadEnable).apply();
    }

    public boolean getHasTransectionEnable() {
        return prefs.getBoolean("hasTransectionEnable", true);
    }

    public void setHasTransectionEnable(boolean hasTransectionEnable) {
        prefs.edit().putBoolean("hasTransectionEnable", hasTransectionEnable).apply();
    }

    public boolean getHasEdge360() {
        return prefs.getBoolean("hasEdge360", false);
    }

    public void setHasEdge360(boolean hasEdge360) {
        prefs.edit().putBoolean("hasEdge360", hasEdge360).apply();
    }

    public void setShowBseAuthPopup(boolean showBseAuthPopup){
        prefs.edit().putBoolean("showBseAuthPopup",showBseAuthPopup).apply();
    }

    public boolean getShowBseAuthPopup(){
        return  prefs.getBoolean("showBseAuthPopup",false);
    }

    public boolean getHasBDCardWithStar() {
        return prefs.getBoolean("hasBDCardWithStar", false);
    }

    public void setHasBDCardWithStar(boolean hasBDCardWithStar) {
        prefs.edit().putBoolean("hasBDCardWithStar", hasBDCardWithStar).apply();
    }


    public void setDocumentData(String documentData) {
        prefs.edit().putString("documentData", documentData).apply();
    }

    public String getDocumentData() {
        return prefs.getString("documentData", "");
    }


    public void setImageRawData(String imageRawData) {
        prefs.edit().putString("imageRawData", imageRawData).apply();
    }

    public String getImageRawData() {
        return prefs.getString("imageRawData", "");
    }

    public boolean getHasFirstTimeDashBoard() {
        return prefs.getBoolean("firstTimeCompleteddashboard", false);
    }

    public void setHasFirstTimeDashBoard(boolean firstTimedashboard) {
        prefs.edit().putBoolean("firstTimeCompleteddashboard", firstTimedashboard).apply();
    }

    public boolean getHasOTPVerified() {
        return prefs.getBoolean("hasOTPVerified", false);
    }

    public void setHasOTPVerified(boolean hasOTPVerified) {
        prefs.edit().putBoolean("hasOTPVerified", hasOTPVerified).apply();
    }

    public String getAddToCartList() {
        return prefs.getString("addToCartList", "");
    }

    public void setAddToCartList(String addToCartList) {
        prefs.edit().putString("addToCartList", addToCartList).apply();
    }

    public String getEmail() {
        return prefs.getString("email", "");
    }

    public void setEmail(String email) {
        prefs.edit().putString("email", email).apply();
    }

    public String getPAN() {
        return prefs.getString("pan", "");
    }

    public void setPAN(String pan) {
        prefs.edit().putString("pan", pan).apply();
    }

    public String getShowDialogByCurrentDate() {
        return prefs.getString("cur_date_dialog", "");
    }

    public void setShowDialogByCurrentDate(String currentdatedialog) {
        prefs.edit().putString("cur_date_dialog", currentdatedialog).apply();
    }

    ///////////////////////////////////////////////////////////

    public void setShowDialog(boolean showdialog) {
        prefs.edit().putBoolean("showdialog", showdialog).apply();
    }

    public boolean getShowDialog() {
        return prefs.getBoolean("showdialog", true);
    }

    public void setShowCrossDialog(boolean showdialog) {
        prefs.edit().putBoolean("showCrossdialog", showdialog).apply();
    }

    public boolean getShowCrossDialog() {
        return prefs.getBoolean("showCrossdialog", true);
    }

    public String getUserType() {
        return prefs.getString("userType", "");
    }

    public void setUserType(String userType) {
        prefs.edit().putString("userType", userType).apply();
    }

    public String getLoginType() {
        return prefs.getString("loginType", "");
    }

    public void setLoginType(String loginType) {
        prefs.edit().putString("loginType", loginType).apply();
    }

    public String getClientObject() {
        return prefs.getString("clientObject", "");
    }

    public void setClientObject(String clientObject) {
        prefs.edit().putString("clientObject", clientObject).apply();
    }


    public String getLoginBy() {
        return prefs.getString("loginBy", "");
    }

    public void setLoginBy(String loginBy) {  // user_password && gmail
        prefs.edit().putString("loginBy", loginBy).apply();
    }

    public String getGoogleToken() {
        return prefs.getString("googleToken", "");
    }

    public void setGoogleToken(String googleToken) {  // user_password && gmail
        prefs.edit().putString("googleToken", googleToken).apply();
    }


    public String getImageUrl() {
        return prefs.getString("url", "");
    }

    public void setImageUrl(String url) {
        prefs.edit().putString("url", url).apply();
    }

    public void clear() {
        prefs.edit().clear().apply();

    }

    public boolean getHasLoging() {
        return prefs.getBoolean("hasLoging", false);
    }

    public void setHasLoging(boolean value) {
        prefs.edit().putBoolean("hasLoging", value).apply();
    }

    public void setPattern(String pattern) {
        prefs.edit().putString("pattern", pattern).apply();
    }

    public String getPattern() {
        return prefs.getString("pattern", "");
    }


    public void setPIN(String pin) {
        prefs.edit().putString("pin", pin).apply();
    }

    public String getPIN() {
        return prefs.getString("pin", "");
    }


    public boolean getHasSignatureScreen() {
        return prefs.getBoolean("hasSignatureScreen", false);
    }

    public void setHasSignatureScreen(boolean hasSignatureScreen) {
        prefs.edit().putBoolean("hasSignatureScreen", hasSignatureScreen).apply();
    }

    public boolean getHasAppLockEnable() {
        return prefs.getBoolean("hasAppLockEnable", false);
    }

    public void setHasAppLockEnable(boolean hasAppLockEnable) {
        prefs.edit().putBoolean("hasAppLockEnable", hasAppLockEnable).apply();
    }

    public String getAppLockType() {
        return prefs.getString("appLockType", "");
    }

    public void setAppLockType(String appLockType) {
        prefs.edit().putString("appLockType", appLockType).apply();
    }

    public void setPlayStoreLink(String playStoreLink) {
        prefs.edit().putString("playStoreLink", playStoreLink).apply();
    }

    public String getPlayStoreLink() {
        return prefs.getString("playStoreLink", "");
    }

    public void setAppStoreLink(String playStoreLink) {
        prefs.edit().putString("appStoreLink", playStoreLink).apply();
    }

    public String getAppStoreLink() {
        return prefs.getString("appStoreLink", "");
    }

    public String getUserEmail() {
        return prefs.getString("userEmail", "");
    }

    public void setUserEmail(String email) {
        prefs.edit().putString("userEmail", email).apply();
    }

    public String getAddress() {
        return prefs.getString("address", "");
    }

    public void setAddress(String address) {
        prefs.edit().putString("address", address).apply();
    }

    public String getWebsite() {
        return prefs.getString("website", "");
    }

    public void setWebsite(String email) {
        prefs.edit().putString("website", email).apply();
    }

    public String getMobileNumber() {
        return prefs.getString("mobile", "");
    }

    public void setMobileNumber(String mobile) {
        prefs.edit().putString("mobile", mobile).apply();
    }

    public String getTelNumber() {
        return prefs.getString("telephone", "");
    }

    public void setTelNumber(String telephone) {
        prefs.edit().putString("telephone", telephone).apply();
    }

    public void setContactDetails(String contactDetails) {
        prefs.edit().putString("contactDetails", contactDetails).apply();
    }

    public String getContactDetails() {
        return prefs.getString("contactDetails", "");
    }

    public String getAppInfo() {
        return prefs.getString("appInfo", "");
    }

    public void setCustomURL(String customURL){
        prefs.edit().putString("customURL",customURL).commit();
    }

    public String getCustomURL() {
        return prefs.getString("customURL", "");
    }

    public void setCustomLinksForContactUs(String mdata){
        prefs.edit().putString("customLinksForContactUs",mdata).commit();
    }
    public String getCustomLinksForContactUs(){
        return prefs.getString("customLinksForContactUs","");
    }

    public void setSloganOnLogo(String sloganOnLogo) {
        prefs.edit().putString("sloganOnLogo", sloganOnLogo).apply();
    }

    public String getSloganOnLogo() {
        return prefs.getString("sloganOnLogo", "");
    }

    public void setAppInfo(String appInfo) {
        prefs.edit().putString("appInfo", appInfo).apply();
    }

    public String getAllowedFeatures() {
        return prefs.getString("allowFeatures", "");
    }

    public void setAllowedFeatures(String allowFeatures) {
        prefs.edit().putString("allowFeatures", allowFeatures).apply();
    }

    public String getSignFileName() {
        return prefs.getString("signFile", "");
    }

    public void setSignFileName(String signFile) {
        prefs.edit().putString("signFile", signFile).apply();
    }

    public String getAppId() {
        return prefs.getString("appId", "");
    }

    public void setAppId(String appId) {
        prefs.edit().putString("appId", appId).apply();
    }

    /**************************on boarding*******************************/
    public boolean isFirstStepCompleted() {
        return prefs.getBoolean("isFirstStepDone", false);
    }

    public void setFirstStepCompleted(boolean isFirstStepDone) {
        prefs.edit().putBoolean("isFirstStepDone", isFirstStepDone).apply();
    }

    public void setAllowedCrm(boolean isAllowedCrm){
        prefs.edit().putBoolean("allowCrm",isAllowedCrm).apply();
    }
    public boolean getAllowedCrm(){return prefs.getBoolean("allowCrm",false);}
    public void setStepNo(int stepNoOfOnBoarding) {
        prefs.edit().putInt("stepNoOfOnBoarding", stepNoOfOnBoarding).apply();
    }

    public int getStepNo() {
        return prefs.getInt("stepNoOfOnBoarding", 0);
    }

    public void setOnBoarding(int onboard) {
        prefs.edit().putInt("onboard", onboard).apply();
    }

    public int getOnBoarding() {
        return prefs.getInt("onboard", 0);
    }

    /***************************Mix Pannel**********************************/
    public String getLoginTypeEvent() {
        return prefs.getString("loginTypeMixPanelEvent", "");
    }

    public void setLoginTypeEvent(String loginTypeMixPanelEvent) {
        prefs.edit().putString("loginTypeMixPanelEvent", loginTypeMixPanelEvent).apply();
    }

    public void setHasBseOpted(boolean hasBseOpted) {
        prefs.edit().putBoolean("hasBseOpted", hasBseOpted).apply();
    }

    public boolean getHasBseOpted() {
        return prefs.getBoolean("hasBseOpted", false);
    }

    public void setHasNseOpted(boolean hasNseOpted) {
        prefs.edit().putBoolean("hasNseOpted", hasNseOpted).apply();
    }

    public boolean getHasNse2Opted(){
        return prefs.getBoolean("hasNse2Opted", false);
    }

    public void setHasNse2Opted(boolean hasNseOpted2){
        prefs.edit().putBoolean("hasNse2Opted", hasNseOpted2).apply();
    }

    public boolean getHasNseOpted() {
        return prefs.getBoolean("hasNseOpted", false);
    }

    public void setHasMfuOpted(boolean hasMfuOpted) {
        prefs.edit().putBoolean("hasMfuOpted", hasMfuOpted).apply();
    }

    public boolean getHasMfuOpted() {
        return prefs.getBoolean("hasMfuOpted", false);
    }

    public void setHasMultiExchange(boolean hasMultiExchange) {
        prefs.edit().putBoolean("hasMultiExchange", hasMultiExchange).apply();
    }

    public boolean getHasMultiExchange() {
        return prefs.getBoolean("hasMultiExchange", false);
    }


    public void setPhone(String phone) {
        prefs.edit().putString("phone", phone).apply();
    }

    public String getPhone() {
        return prefs.getString("phone", "");
    }

    public void setClientPhotoName(String clientPhotoName) {
        prefs.edit().putString("clientPhotoName", clientPhotoName).apply();
    }

    public String getClientPhotoName() {
        return prefs.getString("clientPhotoName", "");
    }

    public void setVoltPartnerCode(String voltPartnerCode) {
        prefs.edit().putString("voltPartnerCode", voltPartnerCode).apply();
    }

    public String getVoltPartnerCode() {
        return prefs.getString("voltPartnerCode", "");
    }

    public void setAllowedMobileOTPLogin(int allowMobileOtpLogin) {
        prefs.edit().putInt("allowMobileOtpLogin", allowMobileOtpLogin).apply();
    }

    public int getAllowedMobileOTPLogin() {
        return prefs.getInt("allowMobileOtpLogin", 0);
    }

    public void setLocalTimeInMillis(String localTimeInMillis) {
        prefs.edit().putString("localTimeInMillis", localTimeInMillis).apply();
    }

    public String getLocalTimeInMillis() {
        return prefs.getString("localTimeInMillis", "");
    }

    public String getPtFilterType() {
        return prefs.getString("ptFilterType", "");
    }

    public void setPtFilterType(String ptFilterType) {
        prefs.edit().putString("ptFilterType", ptFilterType).apply();
    }

    public void setHomeChartBoxExpandStatus(boolean isExpanded) {
        prefs.edit().putBoolean("status", isExpanded).apply();
    }

    public boolean getHomeChartBoxExpandStatus() {
        return prefs.getBoolean("status", true);
    }

    public void setPortfolioAssetCardExpandCollapseStatus(boolean areExpanded) {
        prefs.edit().putBoolean("areAllExpanded", areExpanded).apply();
    }

    public boolean getPortfolioAssetCardExpandCollapseStatus() {
        return prefs.getBoolean("areAllExpanded", false);
    }

    public void setIsLargeIfa(int isLargeIfa) {
        prefs.edit().putInt("isLargeIfa", isLargeIfa).apply();
    }

    public int getIsLargeIfa() {
        return prefs.getInt("isLargeIfa", 0);
    }

    public String getFontOption() {
        return prefs.getString("fontOption", "");
    }

    public void setFontOption(String fontOption) {
        prefs.edit().putString("fontOption", fontOption).apply();
    }


    /**************************App Config*************************/
    public void setAppConfig(String appConfig) {
        prefs.edit().putString("appConfig", appConfig).apply();
    }

    public String getAppConfig() {
        return prefs.getString("appConfig", "");
    }

    public Float getFontScale() {
        return prefs.getFloat("fontScale", 1.0f);
    }

    public void setFontScale(Float fontScale) {
        prefs.edit().putFloat("fontScale", fontScale).apply();
    }

    public void setFontProgress(int fontProgress) {
        prefs.edit().putInt("fontProgress", fontProgress).apply();
    }


    public int getFontProgress() {
        return prefs.getInt("fontProgress", 0);
    }

    public void setIsRiskProfileMandatory(int isRiskProfileMandatory) {
        prefs.edit().putInt("isRiskProfileMandatory", isRiskProfileMandatory).apply();
    }

    public int getIsRiskProfileMandatory() {
        return prefs.getInt("isRiskProfileMandatory", 0);
    }



    //system_default = "system"
    //dark_mode = "dark"
    //light_mode = "light"
    public void setTheme(String theme){
        prefs.edit().putString("theme", theme).apply();
    }

    public String getTheme(){
        return prefs.getString("theme", "light");
    }

    public void setUserSelectedTheme(boolean isSelected){
        prefs.edit().putBoolean("theme_selected", isSelected).apply();
    }

    public boolean getUserSelectedTheme(){
        return prefs.getBoolean("theme_selected", false);
    }

    public boolean getHasFirstTimeSplashLaunch() {
        return prefs.getBoolean("firstTimeSplashLaunch", true);
    }

    public void setHasFirstTimeSplashLaunch(boolean firstTimeSplashLaunch) {
        prefs.edit().putBoolean("firstTimeSplashLaunch", firstTimeSplashLaunch).apply();
    }

    public boolean getHasRequestedNotificationPermission() {
        return prefs.getBoolean("hasRequestedNotificationPermission", false);
    }

    public void setHasRequestedNotificationPermission(boolean value) {
        prefs.edit().putBoolean("hasRequestedNotificationPermission", value).apply();
    }

    public long getNotificationBannerCloseTime() {
        return prefs.getLong("notification_banner_close_time", 0L);
    }

    public void setNotificationBannerCloseTime(long time) {
        prefs.edit().putLong("notification_banner_close_time", time).apply();
    }
}