package investwell.activity;

import static investwell.di.core.LogExtKt.logE;
import static investwell.di.core.LogExtKt.logI;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.Application;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.DefaultLifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;
import androidx.multidex.MultiDex;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import investwell.charts.mikephil.charting.data.Entry;
import investwell.textview.AppTextView;

import com.google.android.material.snackbar.Snackbar;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import investwell.mintSdk.MintAppConfiguration;
import investwell.utils.ActivityCollector;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.UtilityKotlin;
import timber.log.Timber;



public class AppApplication extends Application implements DefaultLifecycleObserver {
    private AppSession mSession;
    public static boolean sAppUpdateCalled = true;
    public static boolean sDematAccount = false;
    public static boolean ONE_DAY_CHANGE = false;
    private ProgressDialog mBar;
    public boolean mFirstTimeSkippedApplock = false, isAppForeground = false, isDaysChange = false;
    public String sDeeplinkingReferUid = "", sDeeplinkingReferLevelNo = "";
    public static String sExchangeType = "";
    public static JSONObject sIinProfileObject, sBseProfileObject;
    public static JSONObject sClientInfo;

    public static String CLIENT_DASHBOARD_BAL_SUMMARY = "", CLIENT_DASHBOARD_LINE__GRAPH = "",
            DASHBOARD_PORTFOLIO = "", DASHBOARD_PORTFOLIO_FD = "",
            DASHBOARD_PORTFOLIO_ASSERT = "", DASHBOARD_BROKER = "", COMING_FROM_PATH = "client",
            DASHBOARD_TRAN_MEMBERS = "", AUM_REPORT = "", notification = "", sWatchList = "", FILTER_BUNDLE1 = "", FILTER_BUNDLE2 = "", FILTER_BUNDLE3 = "", OVER_SUMMARY_SUMMARY = "", VALUE_ASSETS_WISE = "", TMP_ALLOWED_FEATURED = "";
    public static JSONObject AUM_FILTER1 = new JSONObject();
    public static JSONObject AUM_FILTER2 = new JSONObject();
    public static JSONObject AUM_FILTER3 = new JSONObject();
    public static ArrayList<Entry> GInvestmentList = new ArrayList<>();
    public static ArrayList<Entry> GNavList = new ArrayList<>();
    public static ArrayList<Entry> GCurrentValueList = new ArrayList<>();
    public static ArrayList<JSONObject> dataList = new ArrayList<>();
    public static ArrayList<JSONObject> sheetDataList = new ArrayList<>();
    public static ArrayList<JSONObject> sBankList = new ArrayList<>();
    public long sRefreshTimePortfolio = 0;
    public static long sRefreshTimeBrokerDashBoard = 0;
    private Handler handler;
    public boolean isNotificationLaunched = true;

    public boolean isFromPtToAddTxn = false;
    public int sbTxnEditedPos = -1;
    public int fdTxnEditedPos = -1;
    public  int isRunning = 1;
    private static final long TIMEOUT = 25 * 60 * 1000; // 5 minutes in milliseconds
    private long backgroundTime = 0;


    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);

    }

    @Override
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        MultiDex.install(this);
        AppTextView.preloadFonts(this);
        mSession = AppSession.getInstance(getApplicationContext());
        // Insert project token here
//        if (mSession.getHasLoging()) {
//            setMaxNavDate(null);
//        }

        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
        int count = mSession.getCountOfAppOpen();
        count = count + 1;
        mSession.setCountOfAppOpen(count);
        Config.sOncePopupPerLoginSession = false;
        sIinProfileObject = new JSONObject();
        sBseProfileObject = new JSONObject();
        sClientInfo = new JSONObject();
      /*  if (mSession.getUserType().equalsIgnoreCase("") && !mSession.isFirstTimeLaunch()){
            mSession.setFirstTimeLaunch(true);
        }else {
            mSession.setFirstTimeLaunch(false);
        }*/
        if (BuildConfig.DEBUG) {
            Timber.plant(new Timber.DebugTree());
        }

        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
                if (!mSession.getUserBrokerDomain().isEmpty() && appConfigObject.optString("layout").equals("5")) {
                    getConfigData(mSession.getUserBrokerDomain());
                }
            }
        }catch (NullPointerException e){

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        try {
            registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
                private int activityCount = 0;

                @Override
                public void onActivityCreated(@NonNull Activity activity, Bundle bundle) {
                    if (activity instanceof SplashActivity) {
                        mSession.setLastAppInBgTime(0);
                    }
                }

                @Override
                public void onActivityStarted(@NonNull Activity activity) {
                    try {
                        AppSession session = AppSession.getInstance(activity.getApplicationContext());
                        long lastBg = session.getLastAppInBgTime();
                        long now = System.currentTimeMillis();
                        activityCount++;
                        Log.d("MintLifeCycleApp", "===========onActivityStarted called from Application class backgroundTime=" + mSession.getLastAppInBgTime());
                        // If returning from the background, check elapsed time
                        if (lastBg > 0 && now - lastBg >= TIMEOUT) {
                            if (session.getHasLoging() && session.getLoginType().equals("broker")) {
                                Log.d("MintLifeCycleApp", "=======finishAllActivityCalled");
                                ActivityCollector.finishAllExceptMain();
                            }
                            backgroundTime = 0;
                            mSession.setLastAppInBgTime(0);
                            Intent intent = new Intent(getApplicationContext(), SplashActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            startActivity(intent);
                        }else{
                            Log.i("nikki", "onActivityStarted: condtion ignored ");

                        }
                        backgroundTime = 0;
                        mSession.setLastAppInBgTime(backgroundTime);
                    }catch (Exception e){

                    }
                }

                @Override
                public void onActivityStopped(@NonNull Activity activity) {
                    Log.d("MintLifeCycleApp", "onActivityStopped called from Application class backgroundTime="+mSession.getLastAppInBgTime());
                    activityCount--;
                    if (activityCount == 0) {
                        // App goes to the background
                        backgroundTime = System.currentTimeMillis();
                        mSession.setLastAppInBgTime(backgroundTime);
                    }
                }

                @Override
                public void onActivityResumed(@NonNull Activity activity) {

                }

                @Override
                public void onActivityPaused(@NonNull Activity activity) {

                }

                @Override
                public void onActivitySaveInstanceState(@NonNull Activity activity, @NonNull Bundle bundle) {
                }

                @Override
                public void onActivityDestroyed(@NonNull Activity activity) {

                }
            });
        } catch (Exception e) {

        }


        try {
            System.loadLibrary("sqlcipher");
        } catch (Throwable throwable) {
            logE(throwable, "Unable to load SQLCipher native libraries");
        }
    }

    @Override
    public void onCreate(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onCreate(owner);
    }

    @Override
    public void onStart(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStart(owner);
    }


    @Override
    public void onResume(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onResume(owner);
//        setMaxNavDate(null);
       /* handler = new Handler(Looper.getMainLooper());
        runnable = new Runnable() {
            @Override
            public void run() {
                Log.d("MintLifeCycleLog", "handler call on time" + UtilityKotlin.getCurrentDateTime());

                String lastReAuthTime = mSession.getLastReAuthTime();
                String lastReloginTime = mSession.getLastReloginTime();

                if (mSession.getHasLoging() && !lastReAuthTime.equals("")) {
                    long lastReauthTime = Long.parseLong(lastReAuthTime);
                    long secondseAuth = UtilityKotlin.getTimeDifferenceSeconds(lastReauthTime);
                    double ReAuthMinutes = ((double) secondseAuth / 60);

                    long lastReloginCall = Long.parseLong(lastReloginTime);
                    long seconsLastRelogin= UtilityKotlin.getTimeDifferenceSeconds(lastReloginCall);
                    double minutesRelogin = ((double) seconsLastRelogin / 60);
                    if (ReAuthMinutes >= 22 && minutesRelogin>22 && ReAuthMinutes<=27) {
                        Log.d("MintLifeCycleLog", "still alive API called from appApplication on Resume" + UtilityKotlin.getCurrentDateTime());
                        makeAPIiSAlive();
                    }
                }
            }
        };
        handler.postDelayed(runnable, TimeUnit.MINUTES.toMillis(24));

        //When app in background for 10 minutes then app lock enable and last ReAuth time should be less than 25
        String lastReAuthTime = mSession.getLastReAuthTime();
        String lastLoginTime = mSession.getLastReloginTime();
        if (mSession.getHasLoging() && !lastReAuthTime.equals("")) {
            long lastRauthTime = Long.parseLong(lastReAuthTime);
            long secondsAuth = UtilityKotlin.getTimeDifferenceSeconds(lastRauthTime);
            double ReAuthMinutes = ((double) secondsAuth / 60);

            long lastReloginCall = Long.parseLong(lastLoginTime);
            long seconsLastRelogin= UtilityKotlin.getTimeDifferenceSeconds(lastReloginCall);
            double minutesLogin = ((double) seconsLastRelogin / 60);
            if (ReAuthMinutes < 20 && minutesLogin<20) {
               *//* if (mFirstTimeSkippedApplock && mSession.getHasAppLockEnable()) {
                    mFirstTimeSkippedApplock = false;
                    Log.d("binesh", "applock called from Application class ");
                    Intent intent = new Intent(getApplicationContext(), AppLockOptionActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);

                    intent.putExtra("type", "verify_lock");
                    intent.putExtra("callFrom", "application");
                    startActivity(intent);
                }*//*
            }
        }

*/

    }

    @Override
    public void onPause(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onPause(owner);
        System.out.println("MintLifeCycleLog applicationonPause");
        System.out.println("MintLifeCycleLog handler removed");

    /*    handler.removeMessages(0);
        handler.removeCallbacksAndMessages(null);
        handler.removeCallbacks(runnable);*/
  /*      new CountDownTimer(30 * 1000, 100) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                isAppForeground = isAppOnForeground();
                if (!isAppForeground) {
                    new CountDownTimer(1000 * 60 * 10, 1000) {
                        public void onTick(long millisUntilFinished) {
                        }

                        public void onFinish() {
                            mFirstTimeSkippedApplock = true;
                        }
                    }.start();
                }
            }
        }.start();*/
    }

    @Override
    public void onStop(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onStop(owner);
    }

    @Override
    public void onDestroy(@NonNull LifecycleOwner owner) {
        DefaultLifecycleObserver.super.onDestroy(owner);
        // handler.removeCallbacks(runnable);
    }

    private boolean isAppOnForeground() {
        ActivityManager activityManager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null) {
            return false;
        }
        final String packageName = getPackageName();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND && appProcess.processName.equals(packageName)) {
                return true;
            }
        }
        return false;
    }


    public void showProgressBar(Context context) {
        if (context != null && mBar != null) {
            mBar.dismiss();
        }

        mBar = ProgressDialog.show(context, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    }

    public void hideProgressDaolog() {
        if (mBar.isShowing() && mBar != null) {
            mBar.dismiss();
        }
    }

    public void showSnackBar(View view, String message) {
        if (!view.isAttachedToWindow()) return;
        try {
            Snackbar.make(view, message, Snackbar.LENGTH_LONG)
                    .setAction("Action", null).show();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }

    public void showCommonDailog(Context context, String title, String message, final String type) {
        if (type.equals("sessionExpired")) {
            Log.d("MintLifeCycleLog", "sessionExpired");
            removedTempData();
            goToLogin(type);
            LogoutMethod();

        } else {
            showDailog(context, title, message, type);
        }
    }

    public void clearDataForResetPSW(String type) {
        clearChacheSession(type);
    }

    public void goToLogin(String type) {
        logI("goToLogin Called with type: " + type);// Preserve the package name before clearing sessions.
        String packageName = mSession.getCallFromPackage();

        // Clear session data based on the type of logout.
        if ("sessionExpired".equalsIgnoreCase(type) || MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()) {
            clearAllSession();
        } else {
            clearChacheSession(type);
        }
        // Restore the package name after clearing, as clearAllSession() might wipe it.
        mSession.setCallFromPackage(packageName);
        Intent intent = null;
        try {
            // Condition 1: If SDK logout is enabled, always return to the host app.
            if (MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()) {
                logI("SDK logout enabled. Returning to host app: " + packageName);
                intent = new Intent(getApplicationContext(), Class.forName(packageName));
                // Condition 2: If the session expired, decide between Splash and Login.
            } else if ("sessionExpired".equalsIgnoreCase(type)) {
                logI("Session expired. Deciding login path.");
                // If we have domain info and credentials, try to re-login via Splash. Otherwise, go to Login.
                if (mSession.getUserBrokerDomain().length() > 0 && mSession.getUserId().length() > 0 && mSession.getUserpw().length() > 0) {
                    intent = new Intent(getApplicationContext(), SplashActivity.class);
                } else {
                    intent = new Intent(getApplicationContext(), LoginActivity.class);
                }
                intent.putExtra("type", type);
                // Condition 3: Default logout behavior.
            } else {
                logI("Default logout. Returning to host app or Domain screen.");
                // If domain exists, attempt to go back to host app.
                if (mSession.getUserBrokerDomain().length() > 0) {
                    intent = new Intent(getApplicationContext(), Class.forName(packageName));
                } else {
                    // Otherwise, go to DomainActivity as a fallback.
                    intent = new Intent(getApplicationContext(), DomainActivity.class);
                }
            }
        } catch (ClassNotFoundException e) {
            logE("Could not find class for package: " + packageName + ". Exiting app as a fallback.");
            System.exit(0); // Exit if the host app class can't be found.
        } catch (Exception e) {
            logE("An unexpected error occurred while creating intent. Exiting.");
            System.exit(0);
        }

        if (intent != null && !MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()) {
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }else {
            System.exit(0);
        }
    }

    private void clearChacheSession(String type) {
        mSession = AppSession.getInstance(getApplicationContext());

        removedTempData();
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancelAll(); // This will clear all notifications
        }
        boolean intro = mSession.getHasFirstTimeDashBoard();
        String userType = mSession.getUserType();
        String AppType = mSession.getAppType();

        boolean hasOTPVerified = mSession.getHasOTPVerified();
        boolean isNotificationOn = mSession.getHasNotificationEnable();
        boolean appIntroFirstTime = mSession.getHasFirstTimeAppIntroLaunched();
        String pin = mSession.getPIN();
        String userid = mSession.getUserId();
        String userPa = mSession.getUserpw();
        String uAppLockType = mSession.getAppLockType();
        boolean appLockEnable = mSession.getHasAppLockEnable();

        String loginBy = mSession.getLoginBy();
        String googleToken = mSession.getGoogleToken();
        String hostingPath = mSession.getHostingPath();

        String fcmToken = "";
        if (!type.equalsIgnoreCase("logout")) {
            fcmToken = mSession.getFcmToken();
            //mSession.setHasLoging(true);
        } else {
            //mSession.setHasLoging(false);
        }
        String appLogoName = mSession.getAppLogoName();
        String playStoreLink = mSession.getPlayStoreLink();
        String appStoreLink = mSession.getAppStoreLink();
        String companyName = mSession.getCompanyName();
        int onBoarding = mSession.getOnBoarding();
        String userEmail = mSession.getUserEmail();
        String email = mSession.getEmail();
        String website = mSession.getWebsite();
        String mobileNumber = mSession.getMobileNumber();
        String telNumber = mSession.getTelNumber();
        String address = mSession.getAddress();
        String exchangeNseBseMfu = mSession.getExchangeNseBseMfu();
        String appInfo = mSession.getAppInfo();
        String appFeatures = mSession.getAllowedFeatures();
        String appLogo = mSession.getAppLogo();
        String userDomain = mSession.getUserBrokerDomain();
        String localDate = mSession.getShowDialogByCurrentDate();
        String notification = mSession.getNotification();
        String storeApi = mSession.getStoreApi();
        String deviceID = mSession.getDeviceUniqueID();
        String slogan = mSession.getSloganOnLogo();

        String testDomain = mSession.getTestDomainType();
        String data = mSession.getAppConfig();
        int fontProgress = mSession.getFontProgress();

        String language = mSession.getAppLanguage();
        mSession.clear();
        mSession.setAppConfig(data);
        mSession.setFontProgress(fontProgress);
        mSession.setTestDomainType(testDomain);

        mSession.setDeviceUniqueID(deviceID);
        mSession.setStoreApi(storeApi);
//        mSession.setNotification(notification); //as per pm the local stored notification will be cleared when user is logged out
//        mSession.setShowDialogByCurrentDate(localDate);
        mSession.setAppLogoName(appLogoName);
        mSession.setPlayStoreLink(playStoreLink);
        mSession.setAppStoreLink(appStoreLink);
        mSession.setCompanyName(companyName);
        mSession.setOnBoarding(onBoarding);
        mSession.setUserEmail(userEmail);
        mSession.setUserpw(userPa);
        mSession.setEmail(email);
        mSession.setWebsite(website);
        mSession.setMobileNumber(mobileNumber);
        mSession.setTelNumber(telNumber);
        mSession.setAddress(address);
        mSession.setExchangeNseBseMfu(exchangeNseBseMfu);
        mSession.setAppInfo(appInfo);
        mSession.setAllowedFeatures(appFeatures);
        mSession.setHostingPath(hostingPath);
        mSession.setAppLogo(appLogo);
        mSession.setSloganOnLogo(slogan);
        mSession.setAppLanguage(language);


        if (!type.equalsIgnoreCase("logout")) {
            mSession.setFcmToken(fcmToken);
            // mSession.setHasLoging(true);
        } else {
            // mSession.setHasLoging(false);
        }

        mSession.setPIN(pin);
        mSession.setAppLockType(uAppLockType);
        mSession.setHasAppLockEnable(appLockEnable);
        mSession.setUserId(userid);
        mSession.setUserBrokerDomain(userDomain);
        mSession.setHasOTPVerified(hasOTPVerified);
        mSession.setHasNotificationEnable(isNotificationOn);
        mSession.setHasFirstTimeDashBoard(intro);
        mSession.setUserType(userType);
        mSession.setAppType(AppType);
        mSession.setHasFirstTimeAppIntroLaunched(appIntroFirstTime);
        mSession.setAppType(AppType);
        mSession.setLoginBy(loginBy);
        mSession.setGoogleToken(googleToken);
    }

    public void clearAllSession() {
        mSession = AppSession.getInstance(getApplicationContext());
        String packageName =mSession.getCallFromPackage();
        String mDomain =mSession.getUserBrokerDomain();

        removedTempData();

        String notification = mSession.getNotification();
        String storeApi = mSession.getStoreApi();
        String deviceID = mSession.getDeviceUniqueID();

        String testDomain = mSession.getTestDomainType();
        boolean appIntroFirstTime = mSession.getHasFirstTimeAppIntroLaunched();
        String data = mSession.getAppConfig();
        mSession.clear();
        mSession.setAppConfig(data);
        mSession.setUserBrokerDomain(mDomain);
        mSession.setTestDomainType(testDomain);
        mSession.setHasFirstTimeAppIntroLaunched(appIntroFirstTime);

        mSession.setDeviceUniqueID(deviceID);
        mSession.setStoreApi(storeApi);
        mSession.setNotification(notification);


        // When app removed all cache then it will be work
        if (mSession.getTestDomainType().equals("prePord1")) {
            mSession.setHostingPath(".investwell.io/webapi/");
        }else if (mSession.getTestDomainType().equals("prePord2")) {
            mSession.setHostingPath(".getinvestwell.com/webapi/");
        }else if (mSession.getTestDomainType().equals("mintbyiw")) {
            mSession.setHostingPath(".mintbyiw.com/webapi/");
        } else if (mSession.getTestDomainType().equals("iwmint")) {
            mSession.setHostingPath(".iwmint.com/webapi/");
        }else if (mSession.getTestDomainType().equals("preProd4")) {
            mSession.setHostingPath(".letsinvestwell.com/webapi/");
        }else if (mSession.getTestDomainType().equals("preProd5")) {
            mSession.setHostingPath(".your-portfolio.co.in/webapi/");
        } else {
            mSession.setHostingPath(".investwell.app/webapi/");
        }
      /*  Intent intent = null;
        try {
            intent = new Intent(getApplicationContext(), Class.forName(packageName));
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
        } catch (ClassNotFoundException e) {
            System.exit(0);
        } catch (Exception e) {
            System.exit(0);
        }*/



//        Intent intent = new Intent(getApplicationContext(), DomainActivity.class);
//        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
//        startActivity(intent);
    }

    public void clearAllSession2() {
        mSession = AppSession.getInstance(getApplicationContext());
        removedTempData();

        String notification = mSession.getNotification();
        String storeApi = mSession.getStoreApi();
        String deviceID = mSession.getDeviceUniqueID();

        String testDomain = mSession.getTestDomainType();
        boolean appIntroFirstTime = mSession.getHasFirstTimeAppIntroLaunched();
        String data = mSession.getAppConfig();
        mSession.clear();
        mSession.setAppConfig(data);
        mSession.setTestDomainType(testDomain);
        mSession.setHasFirstTimeAppIntroLaunched(appIntroFirstTime);

        mSession.setDeviceUniqueID(deviceID);
        mSession.setStoreApi(storeApi);
        mSession.setNotification(notification);


        // When app removed all cache then it will be work
        if (mSession.getTestDomainType().equals("prePord1")) {
            mSession.setHostingPath(".investwell.io/webapi/");
        }else if (mSession.getTestDomainType().equals("prePord2")) {
            mSession.setHostingPath(".getinvestwell.com/webapi/");
        } else if (mSession.getTestDomainType().equals("iwmint")) {
            mSession.setHostingPath(".iwmint.com/webapi/");
        } else if (mSession.getTestDomainType().equals("preProd4")) {
            mSession.setHostingPath(".letsinvestwell.com/webapi/");
        }else if (mSession.getTestDomainType().equals("preProd5")) {
            mSession.setHostingPath(".your-portfolio.co.in/webapi/");
        } else {
            mSession.setHostingPath(".investwell.app/webapi/");
        }
    }

    public void removedTempData() {
        CLIENT_DASHBOARD_BAL_SUMMARY = "";
        CLIENT_DASHBOARD_LINE__GRAPH = "";

        DASHBOARD_PORTFOLIO = "";
        DASHBOARD_PORTFOLIO_FD = "";
        DASHBOARD_PORTFOLIO_ASSERT = "";
        DASHBOARD_BROKER = "";

        DASHBOARD_TRAN_MEMBERS = "";
        AUM_REPORT = "";
        notification = "";
        sWatchList = "";

        Calendar calendar = Calendar.getInstance();
        sRefreshTimePortfolio = calendar.getTimeInMillis();
        sRefreshTimeBrokerDashBoard = calendar.getTimeInMillis();


        sAppUpdateCalled = true;
        mFirstTimeSkippedApplock = false;
        isAppForeground = false;
        isDaysChange = false;
    }

    private void showDailog(Context context, String title, String message, final String type) {

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.comom_dialog, null);
        dialogBuilder.setView(dialogView);
        final AlertDialog alertDialog = dialogBuilder.create();


        LinearLayout linerMain = dialogView.findViewById(R.id.linerMain);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView tvMessage = dialogView.findViewById(R.id.tvMessage);
        Button btDone = dialogView.findViewById(R.id.btDone);
        Button btCalcel = dialogView.findViewById(R.id.btCalcel);

        RelativeLayout relSubMenu = dialogView.findViewById(R.id.relativeLayout);
        if (title.equals("Failed")) {
            tvMessage.setTextColor(ContextCompat.getColor(context, R.color.red_text_color));
        } else {
            tvMessage.setTextColor(ContextCompat.getColor(context, R.color.black_white));
        }
        tvTitle.setText(title);
        tvMessage.setText(message);
        if (type.equals("update")) {
            btDone.setText(getResources().getString(R.string.update_now));
            btCalcel.setVisibility(View.VISIBLE);
        } else {
            btDone.setText(getResources().getString(R.string.ok));
            btCalcel.setVisibility(View.GONE);
        }


        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        if (Build.VERSION.SDK_INT >= 21) {
            linerMain.setBackground(ContextCompat.getDrawable(context, R.drawable.dialog_background_inset));
            relSubMenu.setBackground(ContextCompat.getDrawable(context, R.drawable.dialog_header_background));
            GradientDrawable drawable = (GradientDrawable) relSubMenu.getBackground();
            drawable.setColor(ContextCompat.getColor(context, R.color.filterToolbar));
        } else {
            relSubMenu.setBackgroundColor(ContextCompat.getColor(context, R.color.filterToolbar));
        }


        btDone.setOnClickListener(v -> {
            alertDialog.dismiss();
            if (type.equals("sessionExpired")) {
                goToLogin(type);
            } else if (type.equals("message")) {

            } else if (type.equals("login_error")) {
                clearAllSession();
            } else if (type.equals("update")) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getApplicationContext().getPackageName())));
            }
        });
        btCalcel.setOnClickListener(v -> alertDialog.dismiss());

        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    public void GtmSetUp(String lavelNo, String UserName) {
      /*  mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        Bundle bundle = new Bundle();
        bundle.putString("LavelNo", lavelNo);
        bundle.putString("UserName", UserName);
        bundle.putString(FirebaseAnalytics.Param.ITEM_ID, getString(R.string.app_name));
        mFirebaseAnalytics.logEvent(FirebaseAnalytics.Event.SELECT_CONTENT, bundle);*/
    }


    private void LogoutMethod() {
        Log.d("MintLifeCycleLog", "LogoutMethod Called");

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.LOGOUT;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "ignoreMessage");
            }
        }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderLoginLogout(mSession);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 2;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    showCommonDailog(getApplicationContext(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    public void setMaxNavDate(TextView tvAsOnDate) {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MAX_NAVDATE;
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        Config.asOnDate = "(as on " + UtilityKotlin.dateFormat2(jsonObjectMain.optString("navUpdatedUpTo")) + ")";
                    } else {
                        Config.asOnDate = "";
                    }
                    if (tvAsOnDate != null) {
                        tvAsOnDate.setText(Config.asOnDate);
                    }
                } catch (JSONException ignored) {

                }
            }
        }, volleyError -> {

        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderBeforeLogin(mSession);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(getApplicationContext());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public void getConfigData(String domain) {
        Log.d("getConfigData", "called getConfigData: ");

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("Subdomain", domain);
            jsonObject.put("Language", UtilityKotlin.getLanguageCodeToValueMap().get(mSession.getAppLanguage()));
        }catch (Exception e) {
            throw new RuntimeException(e);
        }

        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, Config.APP_CONFIG, jsonObject, response -> {
            if (response.optBoolean("Status")) {
                mSession.setAppConfig(response.toString());
                Log.d("getConfigData", "getConfigData: " + response);

            } else {
                try {
                    JSONObject appConfig = new JSONObject(mSession.getAppConfig());
                    appConfig.put("layout", "1");
                    mSession.setAppConfig(appConfig.toString());
                } catch (Exception e) {

                }
                //Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_try_again), Toast.LENGTH_SHORT).show();
            }

        }, e -> {
            // Toast.makeText(getApplicationContext(), getResources().getString(R.string.error_try_again), Toast.LENGTH_SHORT).show();

        });


        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 1;
            }

            @Override
            public void retry(VolleyError error) {

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    public void trackScrollBottomEvent(String refreshMode) {
        JSONObject props = new JSONObject();
        try {
            props.put("refreshMode", refreshMode);
            props.put("deviceType", "Android");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
