package investwell.common.nfo.adapter;

import static investwell.utils.UtilityKotlin.getPicassoTransform;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.common.nfo.OnNfoItemClickListener;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class NfoSchemeAdaptr extends RecyclerView.Adapter<NfoSchemeAdaptr.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnNfoItemClickListener listener;
    private AppSession mSession;


    public NfoSchemeAdaptr(Context context, ArrayList<JSONObject> list, OnNfoItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
    }

    @NotNull
    @Override
    public NfoSchemeAdaptr.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_nfo, viewGroup, false);
        return new NfoSchemeAdaptr.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final NfoSchemeAdaptr.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject status);

    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSchemeGroupName, tvMinAmount, tvNfoOpenDate, tvNfoCloseDate;
        ImageView ivNfoScheme;
        ConstraintLayout clCard;

        public ViewHolder(View view) {
            super(view);
            tvSchemeGroupName = view.findViewById(R.id.tv_scheme_group_name);
            tvMinAmount = view.findViewById(R.id.tv_min_amount);
            tvNfoOpenDate = view.findViewById(R.id.tv_nfo_open_date);
            tvNfoCloseDate = view.findViewById(R.id.tv_nfo_close_date);
            ivNfoScheme = view.findViewById(R.id.iv_nfo_scheme);
            clCard = view.findViewById(R.id.clCard);
        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final OnNfoItemClickListener listener) {
            try {

                final JSONObject jsonObject = mDataList.get(position);


                if (!TextUtils.isEmpty(jsonObject.optString("schemeGroupName")) && !jsonObject.optString("schemeGroupName").equalsIgnoreCase("null")) {
                    tvSchemeGroupName.setText(jsonObject.optString("schemeGroupName"));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("lumpsumMinAmount")) && !jsonObject.optString("lumpsumMinAmount").equalsIgnoreCase("null")) {
                    tvMinAmount.setText(jsonObject.optString("lumpsumMinAmount"));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("nfoOpenDate")) && !jsonObject.optString("nfoOpenDate").equalsIgnoreCase("null")) {
                    tvNfoOpenDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("nfoOpenDate")));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("nfoCloseDate")) && !jsonObject.optString("nfoCloseDate").equalsIgnoreCase("null")) {
                    tvNfoCloseDate.setText(UtilityKotlin.dateFormat2(jsonObject.optString("nfoCloseDate")));
                }

                if (!TextUtils.isEmpty(jsonObject.optString("fundName")) && !jsonObject.optString("fundName").equals("null")
                ) {
                    String mSchemeImageUrl = Config.GET_FUND_IMAGE_URL + jsonObject.optString("fundName") + ".png";
                    if (mSchemeImageUrl.contains("&")) {
                        mSchemeImageUrl = mSchemeImageUrl.replace("&", "");
                    }
                    if (mSchemeImageUrl.contains("&")) {
                        mSchemeImageUrl = mSchemeImageUrl.replace("&", "");
                    }
                    mSchemeImageUrl = mSchemeImageUrl.replaceAll("\\s+", "");
                    Picasso.get().load(mSchemeImageUrl).transform(getPicassoTransform()).error(R.mipmap.tranparent)
                            .into(ivNfoScheme);

                }

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        listener.onNfoItemClick( jsonObject);
                    }
                });

                String description = "Fund name. " +
                        tvSchemeGroupName.getText() +
                        ". " +
                        ". Minimum investment. " +
                        tvMinAmount.getText() +
                        ". " +
                        "Open date. " +
                        tvNfoOpenDate.getText() +
                        ". " +
                        "Close date. " +
                        tvNfoCloseDate.getText() +
                        ". ";

                clCard.setContentDescription(description);



            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
