package investwell.client.fragments.portfolioSummary;

import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mEndDate;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mMemberList;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mSelectedPosition;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mStartingDate;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.KtorHelper.requestCallDownload;
import static investwell.utils.UtilityKotlin.getOneDayEarlier;

import static android.os.Build.VERSION.SDK_INT;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPtSummaryAssertsAdapter;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.UtilityKotlin;


public class FragPtSummaryAsserts extends BaseFragment implements View.OnClickListener {
    private TextView mTvName, mTvCurrent, mTvRealizedGain, mTvUnrealizedGain, mTvXirr, tvWithdrawal;
    RequestQueue requestQueue;
    private FragPtSummaryAssertsAdapter mAdapter;
    private RecyclerView mRecycleView;
    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mCardView;
    private LinearLayout mLinerNoData, llXirrView;
    private boolean mIsActiveFolio = true;
    private RadioGroup mRgFolioFilter;

    private ApiDataBase db;

    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(
                url,
                req,
                res,
                AppConstants.OTHER_ASSET,
                dateTime,
                endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    private AppApplication mAppplication;

    @Override
    public void onResume() {
        super.onResume();
/*        if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        JSONObject appConfigObject = new JSONObject();
        try {
            if (!TextUtils.isEmpty(mSession.getAppInfo()) && !mSession.getAppInfo().equalsIgnoreCase("null")) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }
        } catch (Exception e) {

        }
        View view;
        if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("6"))) {
            view = inflater.inflate(R.layout.frag_pt_other_asserts_layout6, container, false);
        } else {
            view = inflater.inflate(R.layout.frag_pt_other_asserts, container, false);
        }

        db = ApiDataBase.getInstance(mActivity.getApplicationContext());

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        TextView tvPurchaseLevel = view.findViewById(R.id.tvPurchaseLevel);
        tvPurchaseLevel.setText(getString(R.string.investment));
        mTvName = view.findViewById(R.id.tvName);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvRealizedGain = view.findViewById(R.id.tvRealized);
        mTvUnrealizedGain = view.findViewById(R.id.tvUnrealized);
        mTvXirr = view.findViewById(R.id.tvXIRR);
        llXirrView = view.findViewById(R.id.llXirrView);
        mLinerNoData = view.findViewById(R.id.linerNoData);
        mRgFolioFilter = view.findViewById(R.id.rgFolioFilter);
        tvWithdrawal = view.findViewById(R.id.tvWithdrawal);


        mRecycleView = view.findViewById(R.id.recycleView);
        mRecycleView.setHasFixedSize(true);
        mRecycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mAdapter = new FragPtSummaryAssertsAdapter(getActivity(), new ArrayList<JSONObject>(), new FragPtSummaryAssertsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position, String mFileName) {
                try {
                  /*  JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(15, bundle1);*/

                    if (!mFileName.isEmpty()) {
                        downloadFileType2(mFileName);
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        mRecycleView.setAdapter(mAdapter);

        mRgFolioFilter.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioFolio1) {
                        mIsActiveFolio = true;
                        getPtSummaryFD();
}
else if (checkedId == R.id.radioFolio2) {
                        mIsActiveFolio = false;
                        getPtSummaryFD();
}
            }
        });
        getPtSummaryFD();

        return view;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}
    }

    private void SetData(String data) {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        mCardView.setVisibility(View.VISIBLE);
        mLinerNoData.setVisibility(View.GONE);
        ArrayList<JSONObject> list = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(data);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");

                String userName = "";
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                    if (levelNo.equals("98")) {
                        mTvName.setText(getString(R.string.family_total));
                    } else {
                        mTvName.setText(UtilityKotlin.getClientHopObject(mSession).optString("name"));
                    }
                } else {
                    String levelNo = mSession.getLevelNo();
                    if (levelNo.equals("98")) {
                        mTvName.setText(getString(R.string.family_total));
                    } else {
                        mTvName.setText(mSession.getPersonName());
                    }
                }

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentSellValue = jsonObjectSummary.optDouble("sellValue");
                String strWithdrwalAmount = format.format(currentSellValue);
                tvWithdrawal.setText(strWithdrwalAmount);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);


                double gaine2 = jsonObjectSummary.optDouble("purchaseValue");
                String strGain2 = format.format(gaine2);
                mTvRealizedGain.setText(strGain2);

                double totalGain = jsonObjectSummary.optDouble("gain");
                String strTotalGain = format.format(totalGain);
                if (totalGain >= 0) {
                    mTvUnrealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.marketGreen));
                } else {
                    mTvUnrealizedGain.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                }
                mTvUnrealizedGain.setText(strTotalGain);


                if (mSession.getHideXirr().equals("0") && jsonObjectSummary.has("XIRR")) {
                    llXirrView.setVisibility(View.VISIBLE);

                    UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-", "%", 2, false, mTvXirr);
                } else {
                    llXirrView.setVisibility(View.GONE);
                }


                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }


            } else {
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        } finally {
            if (list.size() > 0) {
                mLinerNoData.setVisibility(View.GONE);
                mAdapter.updateList(list, "assert");
            } else {
                mLinerNoData.setVisibility(View.VISIBLE);
                mCardView.setVisibility(View.GONE);
                mAdapter.updateList(list, "assert");

            }
        }

    }

    public void getPtSummaryFD() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")) {
            return;
        }
        mCardView.setVisibility(View.GONE);
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();

        String uId = "";
        String url = "";
        String levelNo = "";
        try {
            JSONObject jsonObject1 = new JSONObject();


            JSONArray jsonArray = new JSONArray();
            if (mStartingDate.equals(mEndDate)) {
                JSONObject dateObject = new JSONObject();
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));

                Date date = getOneDayEarlier();
                if (date != null) {
                    dateObject.put("endDate", formatter.format(date));
                }
                jsonArray.put(dateObject);
            } else {
                JSONObject object = new JSONObject();
                object.put("startDate", mStartingDate);
                jsonArray.put(object);

                JSONObject object2 = new JSONObject();
                object2.put("endDate", mEndDate);
                jsonArray.put(object2);
            }


            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioFixedDepositTable");

            if (mSelectedPosition != 0) {
                JSONObject jsonObject4 = new JSONObject();
                JSONObject jsonObject4_1 = new JSONObject();
                JSONObject jsonObject = mMemberList.get(mSelectedPosition - 1);
                jsonObject4_1.put("levelNo", jsonObject.optString("levelNo"));
                uId = jsonObject.optString("uid");
                jsonObject4_1.put("uid", uId);
                jsonObject4.put("selectedUser", jsonObject4_1);
            } else {
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");

                } else {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                }
                jsonObject1.put("uid", uId);
                jsonObject1.put("levelNo", levelNo);
            }


            ///  https://demo.investwell.app/webapi/client/reports/getPortfolioSummaryForOtherAssets?
            // activeAssetsOnly=false&filters=[{"endDate":"2019-09-10"}]
            // &componentForLoader={"componentName":"folioOtherAssetTable"}
            // &pageSize=20¤tPage=1&investorUid=5553ce3575b8e1a64181794eb86c5b27&selectedUser=
            // {"uid":"5553ce3575b8e1a64181794eb86c5b27","levelNo":"98"}

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_PORTFOLIO_ASSERT + "filters=" + jsonArray.toString()
                    + "&groupBy=" + "fixedSubAssetid" + "&activeFoliosOnly=" + mIsActiveFolio + "&pageSize=100&currentPage=1" +
                    "&investorUid=" + uId + "&selectedUser=" + jsonObject1.toString() + "";
        } catch (Exception e) {

        }

        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_PORTFOLIO_ASSERT);
                        SetData(response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void downloadFileType2(String mFileName) {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")) {
            return;
        }

        String url = "";
        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.DOWNLOAD_SOA + "fileHandle=2" + "&fileName=" + mFileName + /*"&appid=" + mId*/"&downloadType=PDF" + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "pmsSoa", "", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_statement_download), "pdf", mFileSave, uri);
                    }
                });


    }


    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }

    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {
            Log.d("DB", "PERMISSION GRANTED");
        } else {
            isGranted = false;
            Toast.makeText(mActivity, getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
    });

}
