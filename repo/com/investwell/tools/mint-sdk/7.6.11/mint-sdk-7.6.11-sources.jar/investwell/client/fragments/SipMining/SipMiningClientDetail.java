package investwell.client.fragments.SipMining;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;

/**
 * A simple {@link Fragment} subclass.
 */
public class SipMiningClientDetail extends BaseFragment implements OnItemClickListener{
    private RecyclerView mRecyclerView;
    private ShimmerFrameLayout mShimmerViewContainer;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private AppApplication mApplication;
    private boolean loading;
    private int mCurrentPageNo = 1;
    private LinearLayout fullScreenShedow, mLinerNoDataFound;
    private RelativeLayout singleShedow;
    private SipMiningAdapter mAdapter;
    private List<JSONObject> list;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    String mStartingDate, mode, mEndDate, type,fundId,schemeId,appId,clientName;
    private LinearLayout topCard;
    private TextView tvAmount, tvAvgAmount, tvInvestors, tvNoOfSip,mClientName;
    public SipMiningClientDetail() {
        // Required empty public constructor
    }

    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_sip_mining_client_detail, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        }
        setUpToolBar();
        mRecyclerView = view.findViewById(R.id.recycleView);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mRecyclerView.setNestedScrollingEnabled(true);
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new SipMiningAdapter(new ArrayList<JSONObject>(), getContext(), "1", this);
        mRecyclerView.setAdapter(mAdapter);
        tvAmount = view.findViewById(R.id.amount);
        tvAvgAmount = view.findViewById(R.id.avg_amount);
        tvInvestors = view.findViewById(R.id.no_of_sip_investors);
        tvNoOfSip = view.findViewById(R.id.no_of_sip);
        topCard = view.findViewById(R.id.top_card);
        mClientName=view.findViewById(R.id.schemeName);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 20;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getSipMining(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        getSipMining(mCurrentPageNo);
        return view;
    }
    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getString(R.string.txt_sip_mining),
                    true, false, false, false, false, false, false);
        }
    }
    private void getSipMining(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        topCard.setVisibility(View.GONE);
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        } else {
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";

        try {
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "sipMining");
            JSONObject investorObject = new JSONObject();
            Bundle bundle = getArguments();
            mStartingDate = bundle.getString("startDate", "");
            mode = bundle.getString("mode", "");
            mEndDate = bundle.getString("endDate", "");
            type = bundle.getString("type", "");
            fundId = bundle.getString("fundId", "");
            schemeId = bundle.getString("schemeId", "");
            appId=bundle.getString("appId","");
            clientName=bundle.getString("clientName","");
            JSONArray jsonArray = new JSONArray();
            JSONObject fromObject = new JSONObject();
            fromObject.put("fromDate", mStartingDate);
            jsonArray.put(fromObject);

            JSONObject toDateObject = new JSONObject();
            toDateObject.put("toDate", mEndDate);
            jsonArray.put(toDateObject);
            JSONObject schemeObject = new JSONObject();
            JSONArray schemeArray = new JSONArray();
            schemeObject.put("fundid", fundId);
            schemeObject.put("appid", appId);
            schemeObject.put("schid", schemeId);
            schemeArray.put(schemeObject);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                     Config.GET_SIP_MINING_SUMMARY + "currentPage=" + pageNo + "&pageSize=20" + "&orderBy=name" +
                    "&orderByDesc=true" + "&mode=" + mode + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate + "&txnType=" + type + "&groupBy=100"+"&filters="+schemeArray;

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            System.out.println();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        loading = false;
                        list = new ArrayList<>();
                        if (pageNo > 1) {
                            list.addAll(mAdapter.mDataList);
                        }
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);
                            topCard.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mLinerNoDataFound.setVisibility(View.GONE);
                                setDataOnCard();
                                mAdapter.updateList(list);
                            } else {
                                topCard.setVisibility(View.GONE);
                                mLinerNoDataFound.setVisibility(View.VISIBLE);
                                mAdapter.updateList(new ArrayList<JSONObject>());
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }
    @Override
    public void onItemClick(int position) {

    }
    private void setDataOnCard() {
        topCard.setVisibility(View.VISIBLE);
        Bundle bundle=getArguments();
        mClientName.setVisibility(View.VISIBLE);
        mClientName.setText(clientName);
        int noOfSip = Integer.parseInt(bundle.getString("noOfSip",""));
        int investors = Integer.parseInt(bundle.getString("noOfInvestors",""));
        String amount = bundle.getString("amount","");
        String avgAmountPerInvestor = bundle.getString("averageAmount","");
        tvNoOfSip.setText(String.format("%02d",noOfSip));
        tvInvestors.setText(String.format("%02d",investors));
        tvAmount.setText(amount);
        tvAvgAmount.setText(avgAmountPerInvestor);
    }

}
