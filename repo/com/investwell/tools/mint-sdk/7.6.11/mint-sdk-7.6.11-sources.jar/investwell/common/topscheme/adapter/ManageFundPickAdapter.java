package investwell.common.topscheme.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.common.topscheme.callback.OnTopSchemeClickListener;

/**
 * Created by binesh on 8/5/18.
 */

public class ManageFundPickAdapter extends RecyclerView.Adapter<ManageFundPickAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;

    private OnTopSchemeClickListener listener;

    public ManageFundPickAdapter(Context context, ArrayList<JSONObject> list, OnTopSchemeClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_fundpicks, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvFundManagePicks;
        ImageView ivDelete;

        public ViewHolder(View view) {
            super(view);
            tvFundManagePicks = view.findViewById(R.id.tvFundName);
            ivDelete = view.findViewById(R.id.ivDelete);

        }


        public void setItem(final int position, final OnTopSchemeClickListener listener) {
            final JSONObject jsonObject = mDataList.get(position);
            tvFundManagePicks.setText(jsonObject.optString("schemeGroupName"));
            ivDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onAddFavClick(jsonObject,"n");
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onTopSchemeNameClick(jsonObject);
                }
            });



        }

    }



    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
