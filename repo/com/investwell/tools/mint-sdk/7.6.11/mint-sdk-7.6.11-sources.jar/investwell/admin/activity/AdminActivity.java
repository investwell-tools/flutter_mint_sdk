package investwell.admin.activity;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.core.graphics.Insets;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;

import investwell.admin.fragments.AdminPanelFragment;
import investwell.broker.activity.BrokerActivity;
import investwell.client.fragments.others.FragProfileSettings;
import investwell.common.lock.FragChangeAppSecurity;
import investwell.utils.AppSession;
import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;

public class AdminActivity extends AppCompatActivity implements View.OnClickListener {
    private AppSession mSession;
    private RelativeLayout menu1,menu2;
    ImageView mIvMenu1,mIvMenu2;
    TextView mTvMenu1,mTvMenu2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (view, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return new WindowInsetsCompat.Builder(insets)
                    .setInsets(WindowInsetsCompat.Type.systemBars(), Insets.NONE)
                    .build();
        });
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.content_frame);

                if ((mSession.getHasLoging() && mSession.getLoginType().equalsIgnoreCase("admin"))) {
                    if (fragment instanceof AdminPanelFragment) {
                        finish();
                    } else {
                        changeColorAdminDash(1);
                        setEnabled(false);
                        getOnBackPressedDispatcher().onBackPressed();
                        setEnabled(true);
                    }
                } else {
                    changeColorAdminDash(1);
                    getSupportFragmentManager().popBackStack();
                }
            }
        });
        Extensions.checkDevice(this);
        displayViewOther(0, null);
        menu1 = findViewById(R.id.home_menu);
        menu2 = findViewById(R.id.settings_menu);
        mIvMenu1=findViewById(R.id.ivMenu1);
        mIvMenu2=findViewById(R.id.ivMenu2);
        mTvMenu1=findViewById(R.id.tvMenu1);
        mTvMenu2=findViewById(R.id.tvMenu2);
        mSession = AppSession.getInstance(this);
        menu1.setOnClickListener(this);
        menu2.setOnClickListener(this);
        displayViewOther(0,null);
        changeColorAdminDash(1);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (mSession!=null){
            UtilityKotlin.checkReAuth(mSession, AdminActivity.this);
        }
    }

    public void displayViewOther(int position, Bundle bundle) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = new AdminPanelFragment();
                fragment.setArguments(bundle);
                break;
            case 1:
                fragment=new FragProfileSettings();
                fragment.setArguments(bundle);
                break;
            case 2:
                fragment = new FragChangeAppSecurity();
                fragment.setArguments(bundle);
                break;
        }
        if (fragment != null) {

            if (bundle != null && bundle.containsKey("isAnimation")) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction().addToBackStack(null);
                transaction.setCustomAnimations(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left, R.anim.anim_slide_in_righ, R.anim.anim_slide_out_right);
                transaction.replace(R.id.content_frame, fragment);
                transaction.commit();
            } else {
                if (bundle != null && bundle.containsKey("isAddBackToStack")) {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();
                } else {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    int count = getSupportFragmentManager().getBackStackEntryCount();
                    fragmentManager.beginTransaction().addToBackStack(null).replace(R.id.content_frame, fragment, "" + count).commit();
                }
            }
        }
    }
    public void changeColorAdminDash(int index) {
        mTvMenu1.setTextColor(ContextCompat.getColor(this, R.color.default_text_color));
        mTvMenu2.setTextColor(ContextCompat.getColor(this, R.color.default_text_color));

        if (index == 1)
            mTvMenu1.setTextColor(ContextCompat.getColor(this, R.color.primaryToPurplePrimary));
        else if (index == 2)
            mTvMenu2.setTextColor(ContextCompat.getColor(this, R.color.primaryToPurplePrimary));


        changeImageColor(index);
    }


    private void changeImageColor(int index) {
        highlight(mIvMenu1, R.mipmap.home, false);
        highlight(mIvMenu2, R.mipmap.more, false);

        if (index == 1)
            highlight(mIvMenu1, R.mipmap.home_active, true);
        else if (index == 2)
            highlight(mIvMenu2, R.mipmap.more_active, true);

    }

    void highlight(ImageView iv, int drawableid, boolean enable) {
        if (enable) {
            Drawable drawable = ContextCompat.getDrawable(this, drawableid);
            drawable.setColorFilter(ContextCompat.getColor(this, R.color.colorPrimary), PorterDuff.Mode.SRC_ATOP);
            iv.setImageDrawable(drawable);

        } else {
            Drawable drawable = ContextCompat.getDrawable(this, drawableid);
            drawable.setColorFilter(ContextCompat.getColor(this, R.color.default_text_color), PorterDuff.Mode.SRC_ATOP);
            iv.setImageDrawable(drawable);
        }
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.home_menu) {
                displayViewOther(0, null);
                changeColorAdminDash(1);
}
else if (v.getId() == R.id.settings_menu) {
                displayViewOther(1,null);
                changeColorAdminDash(2);
}
    }
}
