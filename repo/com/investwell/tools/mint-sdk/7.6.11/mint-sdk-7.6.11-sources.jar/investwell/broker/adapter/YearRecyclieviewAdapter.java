package investwell.broker.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import investwell.utils.customView.CustomTextViewLight;


public class YearRecyclieviewAdapter extends RecyclerView.Adapter<YearRecyclieviewAdapter.ViewHolder> {

    private String[] mYear;
    private LayoutInflater mInflater;
    private OnItemClickListener listener;
    private Context mContext;
    int index = -1;
    private boolean cliked = false;

    // data is passed into the constructor
    public YearRecyclieviewAdapter(Context context, String[] year, OnItemClickListener listener) {
        this.mInflater = LayoutInflater.from(context);
        this.mYear = year;
        this.listener = listener;
        this.mContext = context;
    }

    // inflates the row layout_gridview_type_two_a from xml when needed
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.year_view_item, parent, false);
        return new ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        holder.setItem(position, listener);

        if (cliked==true){
        }else {
            holder.setColor(position);
        }

    }

    // total number of rows
    @Override
    public int getItemCount() {
        return mYear.length;
    }


    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder {
        CustomTextViewLight myTextView;

        ViewHolder(View itemView) {
            super(itemView);
            myTextView = itemView.findViewById(R.id.years);
        }

        public void setItem(final int position, final OnItemClickListener listener) {

            String value = mYear[position];
            myTextView.setText(value);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    listener.onItemClick(position);
                    index = position;
                    setColor(index);
                    cliked=true;
                    notifyDataSetChanged();

                }
            });


            if (index == position) {
                myTextView.setTextColor(mContext.getResources().getColor(R.color.white));
                myTextView.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));

            } else {
                myTextView.setBackgroundColor(mContext.getResources().getColor(R.color.white));
                myTextView.setTextColor(Color.BLACK);

            }

        }


        public void setColor(int position) {
            for (int i = 0; i < mYear.length; i++) {
                if (position == 7) {
                    myTextView.setTextColor(mContext.getResources().getColor(R.color.white));
                    myTextView.setBackgroundColor(mContext.getResources().getColor(R.color.colorPrimary));
                } else {
                    myTextView.setBackgroundColor(mContext.getResources().getColor(R.color.white));
                    myTextView.setTextColor(Color.BLACK);
                }
            }
        }
    }


}
