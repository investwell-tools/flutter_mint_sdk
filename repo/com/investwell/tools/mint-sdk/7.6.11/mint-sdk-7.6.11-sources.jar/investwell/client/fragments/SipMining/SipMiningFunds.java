package investwell.client.fragments.SipMining;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.SortData;


public class SipMiningFunds extends BaseFragment implements View.OnClickListener, OnItemClickListener {
    private RecyclerView mRecyclerView;
    private ShimmerFrameLayout mShimmerViewContainer;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private RelativeLayout mRelFilterMain;
    private Animation slideUpAnimation, slideDownAnimation;
    private RelativeLayout singleShedow;
    private FloatingActionButton mFilterIcon;
    private LinearLayout mLinFilterPart, mLinerCustomDuration;
    private boolean isClickedApply = false;
    private String type = "SIP";
    private LinearLayout fullScreenShedow, mLinerNoDataFound;
    private TextView mTvStartDate, mTvEndDate, mDateTitle;
    private SipMiningAdapter mAdapter;
    private String mode = "currentlyRunning";
    private List<JSONObject> list;
    private String mStartingDate = "", mEndDate = "";
    private LinearLayout topCard;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private TextView tvAmount, tvAvgAmount, tvInvestors, tvNoOfSip;
    private JSONObject summaryObject;

    public SipMiningFunds() {
        // Required empty public constructor
    }

    @Override
    public void onResume() {
        super.onResume();
  /*      if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        AppApplication mApplication;
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_frag_sip_mining, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        }
        setUpToolBar();
        dateSelector(0);
        mRecyclerView = view.findViewById(R.id.recycleView);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mFilterIcon = view.findViewById(R.id.filters);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        mDateTitle = view.findViewById(R.id.dateTitle);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);
        mTvStartDate = view.findViewById(R.id.tvSTart);
        mTvEndDate = view.findViewById(R.id.tvEnd);
        mFilterIcon.setOnClickListener(this);
        tvAmount = view.findViewById(R.id.amount);
        tvAvgAmount = view.findViewById(R.id.avg_amount);
        tvInvestors = view.findViewById(R.id.no_of_sip_investors);
        tvNoOfSip = view.findViewById(R.id.no_of_sip);
        topCard = view.findViewById(R.id.top_card);
        mTvStartDate.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);
        mLinerCustomDuration = view.findViewById(R.id.linerCustomDuration);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);
        slideUpAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_down);
        mRecyclerView.setNestedScrollingEnabled(true);
        mAdapter = new SipMiningAdapter(new ArrayList<JSONObject>(), getContext(), "2", this);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        final RadioGroup modeRadioGroup = view.findViewById(R.id.modeRadioGroup);
        modeRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                mLinerCustomDuration.setVisibility(View.GONE);
                int position = modeRadioGroup.indexOfChild(view.findViewById(checkedId));
                switch (position) {
                    case 0:
                        mode = "currentlyRunning";
                        dateSelector(position);
                        mLinerCustomDuration.setVisibility(View.GONE);
                        break;
                    case 1:
                        mode = "forthComing";
                        mDateTitle.setText(getString(R.string.txt_nextDate));
                        dateSelector(position);
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                    case 2:
                        mode = "prematurelyTerminated";
                        mDateTitle.setText(getString(R.string.txt_cease_date));
                        dateSelector(position);
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                    case 3:
                        mode = "procuredSummary";
                        mDateTitle.setText(getString(R.string.txt_nextDate));
                        dateSelector(position);
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                    case 4:
                        mode = "upcomingRenewal";
                        mDateTitle.setText(getString(R.string.txt_nextDate));
                        dateSelector(position);
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });
        final RadioGroup radioGroup = view.findViewById(R.id.typeRadioGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                int position = radioGroup.indexOfChild(view.findViewById(checkedId));
                switch (position) {
                    case 0:
                        type = "SIP";
                        break;
                    case 1:
                        type = "STP";
                        break;
                    case 2:
                        type = "SWP";
                        break;
                }
            }
        });
        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);
                mFilterIcon.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        getSipMining();
        return view;
    }

    private void getSipMining() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        topCard.setVisibility(View.GONE);
        singleShedow.setVisibility(View.GONE);
        fullScreenShedow.setVisibility(View.VISIBLE);

        String url = "";

        try {
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "sipMining");
            JSONObject investorObject = new JSONObject();

            JSONArray jsonArray = new JSONArray();
            JSONObject fromObject = new JSONObject();
            fromObject.put("fromDate", mStartingDate);
            jsonArray.put(fromObject);

            JSONObject toDateObject = new JSONObject();
            toDateObject.put("toDate", mEndDate);
            jsonArray.put(toDateObject);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_SIP_MINING_SUMMARY + "currentPage=1" + "&pageSize=1000" + "&orderBy=name" +
                    "&orderByDesc=true" + "&mode=" + mode + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate + "&txnType=" + type + "&groupBy=1001";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            System.out.println();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        list = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");

                                summaryObject = jsonObjectMain.optJSONObject("summary");

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            topCard.setVisibility(View.VISIBLE);
                            mRecyclerView.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mLinerNoDataFound.setVisibility(View.GONE);
                                setDataOnCard(summaryObject);

                                Collections.sort(list, new SortData("noOfSIPs"));
                                Collections.reverse(list);

                                mAdapter.updateList(list);
                            } else {
                                topCard.setVisibility(View.GONE);
                                mLinerNoDataFound.setVisibility(View.VISIBLE);
                                mAdapter.updateList(new ArrayList<JSONObject>());
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getString(R.string.txt_sip_mining),
                    true, false, false, false, false, false, false);
        }
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.filters) {
                mFilterIcon.setVisibility(View.GONE);
                mRelFilterMain.setVisibility(View.VISIBLE);
                mLinFilterPart.startAnimation(slideUpAnimation);
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                mLinFilterPart.startAnimation(slideDownAnimation);
                isClickedApply = true;
                getSipMining();
}
else if (v.getId() == R.id.ivLeft) {
                getActivity().getSupportFragmentManager().popBackStack();
}
else if (v.getId() == R.id.tvSTart) {
                datePicker(true);
}
else if (v.getId() == R.id.tvEnd) {
                datePicker(false);
}
    }


    private void dateSelector(int position) {
        Calendar mCalender = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy");
        Date date = mCalender.getTime();
        switch (position) {
            case 0:
                mStartingDate = formatter.format(date);
                mEndDate = formatter.format(date);
                break;
            case 1:
                mCalender.add(Calendar.DAY_OF_MONTH, 14);
                mStartingDate = formatter.format(date);
                mEndDate = formatter.format(mCalender.getTime());
                mTvStartDate.setText(formatterForText.format(date));
                mTvEndDate.setText(formatterForText.format(mCalender.getTime()));
                break;
            case 2:
                mCalender.add(Calendar.MONTH, -1);
                mStartingDate = formatter.format(mCalender.getTime());
                mEndDate = formatter.format(date);
                mTvStartDate.setText(formatterForText.format(mCalender.getTime()));
                mTvEndDate.setText(formatterForText.format(date));
                break;
            case 3:
                mCalender.add(Calendar.MONTH, -1);
                mStartingDate = formatter.format(mCalender.getTime());
                mEndDate = formatter.format(date);
                mTvStartDate.setText(formatterForText.format(mCalender.getTime()));
                mTvEndDate.setText(formatterForText.format(date));
                break;
            case 4:
                mCalender.add(Calendar.MONTH, 1);
                mStartingDate = formatter.format(date);
                mEndDate = formatter.format(mCalender.getTime());
                mTvStartDate.setText(formatterForText.format(date));
                mTvEndDate.setText(formatterForText.format(mCalender.getTime()));
                break;
        }


    }

    private void datePicker(final boolean isStartDate) {
        Calendar c = Calendar.getInstance();
        int mYear = c.get(Calendar.YEAR);
        int mMonth = c.get(Calendar.MONTH);
        int mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                if (view.isShown()) {
                    NumberFormat formatter = new DecimalFormat("00");
                    String day = formatter.format((dayOfMonth));
                    String month = formatter.format((monthOfYear + 1));
                    String date_time = year + "-" + month + "-" + day;
                    String date_for_text = day + "-" + month + "-" + year;

                    if (isStartDate) {
                        mTvStartDate.setText(date_for_text);
                        mStartingDate = date_time;
                    } else {
                        mTvEndDate.setText(date_for_text);
                        mEndDate = date_time;
                    }
                }

            }
        }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }

    @Override
    public void onItemClick(int position) {
        JSONObject jsonObject1 = list.get(position);
        String fundId = jsonObject1.optString("fundid");
        String name = jsonObject1.optString("name");
        Bundle bundle = new Bundle();
        bundle.putString("fundId", fundId);
        bundle.putString("startDate", mStartingDate);
        bundle.putString("endDate", mEndDate);
        bundle.putString("mode", mode);
        bundle.putString("type", type);
        bundle.putString("name", name);
        mBrokerActivity.displayViewOther(30, bundle);
    }


    private void setDataOnCard(JSONObject summaryObject) {
        topCard.setVisibility(View.VISIBLE);
        int noOfSip = summaryObject.optInt("noOfSIPs");
        int investors = summaryObject.optInt("investors");
        tvNoOfSip.setText(String.format("%02d", noOfSip));
        tvInvestors.setText(String.format("%02d", investors));

        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);

        double amount = summaryObject.optDouble("amount");
        double avgAmountPerInvestor = summaryObject.optDouble("avgAmountPerInvestor");
        tvAmount.setText("" +numberFormat.format(amount));
        tvAvgAmount.setText("" + numberFormat.format(avgAmountPerInvestor));
    }
}
