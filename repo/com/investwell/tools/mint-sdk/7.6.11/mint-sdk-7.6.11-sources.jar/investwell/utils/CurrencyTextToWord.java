package investwell.utils;

import android.content.Context;
import android.text.TextUtils;

import com.iw.mint.sdk.R;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class CurrencyTextToWord {

    public static String convertToIndianCurrency(Context context, String num) {

        BigDecimal bd = new BigDecimal(num);
        long number = bd.longValue();
        long no = bd.longValue();
        int decimal = (int) (bd.remainder(BigDecimal.ONE).doubleValue() * 100);
        int digits_length = String.valueOf(no).length();
        int i = 0;
        String finalResult = "";

        ArrayList<String> str = new ArrayList<>();
        HashMap<Integer, String> words = new HashMap<>();
        words.put(0, "");
        words.put(1, context.getString(R.string.one));
        words.put(2, context.getString(R.string.two));
        words.put(3, context.getString(R.string.three));
        words.put(4, context.getString(R.string.four));
        words.put(5, context.getString(R.string.five));
        words.put(6, context.getString(R.string.six));
        words.put(7, context.getString(R.string.seven));
        words.put(8, context.getString(R.string.eight));
        words.put(9, context.getString(R.string.nine));
        words.put(10, context.getString(R.string.ten));
        words.put(11, context.getString(R.string.eleven));
        words.put(12, context.getString(R.string.twelve));
        words.put(13, context.getString(R.string.thirteen));
        words.put(14, context.getString(R.string.fourteen));
        words.put(15, context.getString(R.string.fifteen));
        words.put(16, context.getString(R.string.sixteen));
        words.put(17, context.getString(R.string.seventeen));
        words.put(18, context.getString(R.string.eighteen));
        words.put(19, context.getString(R.string.nineteen));
        words.put(20, context.getString(R.string.twenty));
        words.put(30, context.getString(R.string.thirty));
        words.put(40, context.getString(R.string.forty));
        words.put(50, context.getString(R.string.fifty));
        words.put(60, context.getString(R.string.sixty));
        words.put(70, context.getString(R.string.seventy));
        words.put(80, context.getString(R.string.eighty));
        words.put(90, context.getString(R.string.ninety));

        String digits[] = {"", context.getString(R.string.hundred), context.getString(R.string.thousand), context.getString(R.string.lakh), context.getString(R.string.crore),context.getString(R.string.arab),context.getString(R.string.kharab),context.getString(R.string.nil),context.getString(R.string.padma),context.getString(R.string.shankh)};

        while (i < digits_length) {
            int divider = (i == 2) ? 10 : 100;
            number = no % divider;
            no = no / divider;
            i += divider == 10 ? 1 : 2;
            if (number > 0) {
                int counter = str.size();
                String plural = (counter > 0 && number > 9) ? "s" : "";
                String tmp = (number < 21) ? words.get(Integer.valueOf((int) number)) + " " +
                        digits[counter] + plural :
                        words.get(Integer.valueOf((int) Math.floor(number / 10) * 10))
                                + " " + words.get(Integer.valueOf((int) (number % 10)))
                                + " " + digits[counter] + plural;
                str.add(tmp);
            } else {
                str.add("");
            }
        }

        Collections.reverse(str);
        String Rupees = null;

        Rupees = TextUtils.join(" ", str).trim();


        String paise = (decimal) > 0 ? context.getString(R.string.and) + words.get(
                Integer.valueOf((int) (decimal - decimal % 10))) + " " +
                words.get(Integer.valueOf((int) (decimal % 10))) : "";
        // AND FORTNY NINE PAISA
        if (!paise.isEmpty()) {

            paise = paise.concat(context.getString(R.string.paise));
        }

        //finalResult = "Rupees " + Rupees + paise + " Only";
        finalResult = Rupees + paise;
        return finalResult.replace("  " ," ")
                .replace("   "," ");
    }


}
