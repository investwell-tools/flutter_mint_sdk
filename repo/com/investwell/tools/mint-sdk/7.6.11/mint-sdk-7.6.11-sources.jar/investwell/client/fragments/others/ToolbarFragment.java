package investwell.client.fragments.others;


import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.appbar.AppBarLayout;
import com.iw.mint.sdk.R;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;


/**
 * A simple {@link Fragment} subclass.
 */
public class ToolbarFragment extends BaseFragment implements View.OnClickListener {
    public ToolbarCallback              toolbarCallbacks;
    private AppTextViewTitle tvToolBarTitle;
    private AppBarLayout cvToolbar;
    private ImageView ivRefresh, ivBack, ivShare, ivSearch, ivInfo, ivPDF, ivExcel;
    private View view;
    private ClientActivity mMainActivity;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private AppApplication mApplication;


    public ToolbarFragment() {
        // Required empty public constructor
    }


    public void setCallback(ToolbarCallback toolbarCallback) {
        this.toolbarCallbacks = toolbarCallback;
    }

    @Override
    public void onResume() {
        super.onResume();
 /*       if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.frag_toolbar, container, false);
        setInitializer(view);
        setListeners();

        return view;
    }


    private void setInitializer(View view) {
        cvToolbar = view.findViewById(R.id.cv_toolBar_parent);
        tvToolBarTitle = view.findViewById(R.id.tv_toolbar_title);
        ivRefresh = view.findViewById(R.id.iv_refresh);
        ivBack = view.findViewById(R.id.ivBack);
        ivShare = view.findViewById(R.id.iv_share);
        ivSearch = view.findViewById(R.id.iv_search);
        ivInfo = view.findViewById(R.id.iv_fatca_info);
        ivPDF = view.findViewById(R.id.iv_pdf_download);
        ivExcel = view.findViewById(R.id.iv_excel_download);
    }

    private void setListeners() {
        ivRefresh.setOnClickListener(this);
        ivBack.setOnClickListener(this);
        ivShare.setOnClickListener(this);
        view.findViewById(R.id.iv_search).setOnClickListener(this);
        ivInfo.setOnClickListener(this);
        ivPDF.setOnClickListener(this);
        ivExcel.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        final Animation rotate;
        if (v.getId() == R.id.ivBack) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isAdded()) return;
                        if (mBrokerActivity != null) {
                            if (tvToolBarTitle.getText().toString().equalsIgnoreCase(getString(R.string.txt_choose_arn))){
                                if (toolbarCallbacks != null)
                                    toolbarCallbacks.onToolbarItemClick(ivBack);
//                                mBrokerActivity.getSupportFragmentManager().popBackStack();
                            }else {
                                mBrokerActivity.onBackPressed();
                            }

                        } else if (mMainActivity != null) {
                            mMainActivity.onBackPressed();
                        }
                    }
                }, 100);
}
else if (v.getId() == R.id.iv_share) {
                final Animation animShake = AnimationUtils.loadAnimation(getContext(), R.anim.shake_anim);
                ivShare.startAnimation(animShake);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        animShake.cancel();
                    }
                }, 1000);
                if (toolbarCallbacks != null)
                    toolbarCallbacks.onToolbarItemClick(ivShare);
}
else if (v.getId() == R.id.iv_refresh) {
                rotate = AnimationUtils.loadAnimation(getContext(), R.anim.rotate_anim);
                ivRefresh.startAnimation(rotate);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        rotate.cancel();
                    }
                }, 1000);
                toolbarCallbacks.onToolbarItemClick(ivRefresh);
}
else if (v.getId() == R.id.iv_search) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (mMainActivity != null) {
                            mMainActivity.displayViewOther(75, null);
                        }

                    }
                }, 200);
}
else if (v.getId() == R.id.iv_fatca_info) {
                toolbarCallbacks.onToolbarItemClick(ivInfo);
}
else if (v.getId() == R.id.iv_pdf_download) {
                final Animation animShake2 = AnimationUtils.loadAnimation(getContext(), R.anim.shake_anim);
                ivPDF.startAnimation(animShake2);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        animShake2.cancel();
                    }
                }, 1000);
                if (toolbarCallbacks != null)
                    toolbarCallbacks.onToolbarItemClick(ivPDF);
}
else if (v.getId() == R.id.iv_excel_download) {
                final Animation animShake3 = AnimationUtils.loadAnimation(getContext(), R.anim.shake_anim);
                ivPDF.startAnimation(animShake3);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        animShake3.cancel();
                    }
                }, 1000);
                if (toolbarCallbacks != null)
                    toolbarCallbacks.onToolbarItemClick(ivExcel);
}
    }

    public void setUpToolBar(String toolBarTitle, boolean isShowingBckBtn, boolean isShowingShareBtn, boolean isShowingSearchBtn, boolean isShowingPdfDownload, boolean isShowingRefreshBtn, boolean isShowingCartBtn, boolean isShowingInfo) {
        /*if (toolBarTitle.toLowerCase().contains("portfolio")){
            cvToolbar.setCardBackgroundColor(ContextCompat.getColor(requireActivity(), R.color.white));
        }*/
        if (isShowingShareBtn) {
            ivShare.setImageResource(R.mipmap.ic_share);
            ivShare.setVisibility(View.VISIBLE);
            ivShare.setContentDescription(getString(R.string.share_button));
        } else {
            ivShare.setVisibility(View.GONE);
        }
        if (isShowingShareBtn && toolBarTitle.equalsIgnoreCase(getResources().getString(R.string.folio_detail))) {
            ivShare.setImageResource(R.drawable.share_folio_details);
            ivShare.setVisibility(View.VISIBLE);
        }

        if (isShowingSearchBtn) {
            ivSearch.setVisibility(View.VISIBLE);
            ivShare.setContentDescription(getString(R.string.share_button));
        } else {
            ivSearch.setVisibility(View.GONE);
        }


        if (isShowingInfo) {
            ivInfo.setVisibility(View.VISIBLE);
            ivInfo.setContentDescription(getString(R.string.refresh_button));
        } else {
            ivInfo.setVisibility(View.GONE);
        }


        if (isShowingBckBtn) {
            final Animation animShake = AnimationUtils.loadAnimation(getContext(), R.anim.left_from_right);
            ivBack.startAnimation(animShake);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    animShake.cancel();
                }
            }, 1000);

            ivBack.setVisibility(View.VISIBLE);

        } else {
            ivBack.setVisibility(View.INVISIBLE);
        }

        if (isShowingRefreshBtn) {
            ivRefresh.setVisibility(View.VISIBLE);
        } else {
            ivRefresh.setVisibility(View.GONE);
        }

        if (isShowingPdfDownload && toolBarTitle.equalsIgnoreCase(getResources().getString(R.string.my_documents))) {
            ivPDF.setVisibility(View.VISIBLE);
            ivPDF.setImageResource(R.mipmap.ic_add_fundpick);
            ivPDF.setContentDescription(getString(R.string.add_documents));
        } else if (isShowingPdfDownload && toolBarTitle.equalsIgnoreCase(getResources().getString(R.string.toolBar_title_notifications))) {
            ivPDF.setVisibility(View.VISIBLE);
            ivPDF.setImageResource(R.mipmap.ic_clear_notification);
            ivPDF.setContentDescription(getString(R.string.clear_notifications));
        }else if (isShowingPdfDownload && toolBarTitle.equalsIgnoreCase(getResources().getString(R.string.capital_gain))) {
            ivPDF.setVisibility(View.VISIBLE);
            ivPDF.setImageResource(R.mipmap.ic_download_report);
            ivPDF.setContentDescription(getString(R.string.download_report));
        }else if (isShowingPdfDownload && toolBarTitle.equalsIgnoreCase(getResources().getString(R.string.txt_Myorder)) || toolBarTitle.equalsIgnoreCase(getString(R.string.txt_video_kyc_status))) {
            ivPDF.setVisibility(View.VISIBLE);
            ivPDF.setImageResource(R.drawable.filter_1);
            ivPDF.setContentDescription(getString(R.string.filter));
        } else if (isShowingPdfDownload) {
            ivPDF.setVisibility(View.VISIBLE);
            ivPDF.setImageResource(R.mipmap.ic_picture_as_pdf);
            ivPDF.setContentDescription(getString(R.string.download));
        } else {
            ivPDF.setVisibility(View.GONE);
        }


        if (toolBarTitle.equals(getResources().getString(R.string.capital_gain))) {
            ivExcel.setVisibility(View.GONE);
            ivExcel.setImageResource(R.mipmap.ic_xl_white);
            ivExcel.setContentDescription(getString(R.string.download));
        } else {
            ivExcel.setVisibility(View.GONE);
        }

        if (toolBarTitle.equals(getResources().getString(R.string.aum_report))){
            if (!isShowingBckBtn){
                ivShare.setVisibility(View.VISIBLE);
                ivShare.setImageResource(R.drawable.filter_icon);
                ivShare.setContentDescription(getString(R.string.filter));
            }else {
                ivShare.setVisibility(View.GONE);//
            }
        }

        if (toolBarTitle.equals(getString(R.string.toolBar_title_goal)) || toolBarTitle.equals(getString(R.string.invest_for_a_purpose))){

            if(isShowingShareBtn){ // for download
                ivShare.setVisibility(View.VISIBLE);
                ivShare.setImageResource(R.mipmap.ic_download_goal);
                ivShare.setContentDescription(getString(R.string.download));
            }
            if(isShowingPdfDownload){ // for add goal
                ivPDF.setVisibility(View.VISIBLE);
                ivPDF.setImageResource(R.mipmap.ic_add_goal);
                ivPDF.setContentDescription(getString(R.string.add_goal));
            }
        } else if (toolBarTitle.equals(getString(R.string.toolBar_title_goal_update)) || toolBarTitle.equals(getString(R.string.goal_summary_details_header_txt)) || toolBarTitle.equals(getString(R.string.txt_purpose_details))) {
            if(isShowingShareBtn){ // for edit goal
                ivShare.setVisibility(View.VISIBLE);
                ivShare.setImageResource(R.mipmap.ic_edit_goal);
                ivShare.setContentDescription(getString(R.string.edit_goal));
            }
            if(isShowingPdfDownload){ // for delete goal
                ivPDF.setVisibility(View.VISIBLE);
                ivPDF.setImageResource(R.mipmap.ic_trace_goal);
                ivPDF.setContentDescription(getString(R.string.delete_goal));
            }
        }

        if(toolBarTitle.equals(getString(R.string.toolBar_title_view_note))){
            ivShare.setVisibility(View.VISIBLE);
            ivShare.setImageResource(R.mipmap.ic_edit_goal);
            ivShare.setContentDescription(getString(R.string.edit_note));
        }
        if(toolBarTitle.equals(getString(R.string.toolBar_title_create_note)) || toolBarTitle.equals(getString(R.string.toolBar_title_edit_note)))
        {
            ivShare.setVisibility(View.VISIBLE);
            ivShare.setImageResource(R.mipmap.ic_tick);
            ivPDF.setContentDescription(getString(R.string.done));
        }

        tvToolBarTitle.setText(!TextUtils.isEmpty(toolBarTitle) ? toolBarTitle : "");

    }

    public void hasSecondryToolBarVisibility(boolean value) {
        cvToolbar.setVisibility(value ? View.VISIBLE : View.GONE);
    }

    public void setTitleTextSize(float size)
    {
        tvToolBarTitle.setTextSize(size);
    }


    public interface ToolbarCallback {
        void onToolbarItemClick(View view);
    }
}
