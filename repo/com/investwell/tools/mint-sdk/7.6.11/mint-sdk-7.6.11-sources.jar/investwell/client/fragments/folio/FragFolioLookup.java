package investwell.client.fragments.folio;

import static android.os.Build.VERSION.SDK_INT;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.KtorHelper.requestCallDownload;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FolioLookupAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.SearchAnimationToolbar;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class FragFolioLookup extends BaseFragment implements View.OnClickListener, SearchAnimationToolbar.OnSearchQueryChangedListener {
    RequestQueue requestQueue;
    FolioLookupAdapter mFolioLookupAdapter;
    private boolean loading = false;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentPageNo = 0;
    private final int mFetchListsize = 15;
    private String mSearchKey = "";
    private Timer timer = new Timer();
    private final long DELAY = 1000; // milliseconds

    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;
    private TextView mTvNothing;
    private ShimmerFrameLayout mShimmerViewContainer;
    RecyclerView mRvFolioLookup;

    private SearchAnimationToolbar toolbar;
    private List<JSONObject> mListFirstData;
    private String mFolioId = "", mSchemeId = "";
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;

    @Override
    public void onResume() {
        super.onResume();
     /*   if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }


    @Override
    public void onStart() {
        super.onStart();
        if (mMainActivity != null)
            mMainActivity.userDidAction("");
    }

    @Override
    public void onStop() {
        super.onStop();

        try {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            IBinder binder = getActivity().getCurrentFocus().getWindowToken();
            if (imm.isAcceptingText() && binder != null) {
                imm.hideSoftInputFromWindow(binder, 0);
            }
        } catch (Exception e) {

        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_lookup, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mTvNothing = view.findViewById(R.id.tvLoading);
        mTvNothing.setVisibility(View.GONE);

        mListFirstData = new ArrayList<>();

        mRvFolioLookup = view.findViewById(R.id.recycleView);
        mRvFolioLookup.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRvFolioLookup.setLayoutManager(mLayoutManager);
        mFolioLookupAdapter = new FolioLookupAdapter(getActivity(), this, new ArrayList<JSONObject>(), new FolioLookupAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });
        mRvFolioLookup.setAdapter(mFolioLookupAdapter);
        mRvFolioLookup.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 15;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getFolioLookup("", mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });


        toolbar = view.findViewById(R.id.toolbar);
        toolbar.setSupportActionBar((AppCompatActivity) getActivity());
        toolbar.setOnSearchQueryChangedListener(this);

        ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_arrow_back);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getFolioLookup("", 1);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {


        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_search, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemId = item.getItemId();

        if (itemId == R.id.action_search) {
            toolbar.onSearchIconClick();
            return true;
        } else if (itemId == android.R.id.home) {
            getActivity().onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSearchCollapsed() {
        mSearchKey = "";
        if (mListFirstData.size() > 0) {
            mFolioLookupAdapter.updateList(mListFirstData);
        } else
            getFolioLookup("", 1);
    }

    @Override
    public void onSearchQueryChanged(final String query) {
        if (query.length() >= 2) {
            timer.cancel();
            timer = new Timer();
            timer.schedule(
                    new TimerTask() {
                        @Override
                        public void run() {
                            if (getActivity() != null) {
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        mSearchKey = query;
                                        getFolioLookup(mSearchKey, 1);
                                    }
                                });

                            }
                        }
                    },
                    DELAY
            );
        }
    }


    @Override
    public void onSearchExpanded() {
        // searchText.setText(R.string.expanded);
    }

    @Override
    public void onSearchSubmitted(String query) {
        System.out.println();
        //searchText.setText(getString(R.string.submitted, query));
    }


    private void SetData(String data, final boolean isSaveTrue, int pageNo) {
        List<JSONObject> list = new ArrayList<>();
        if (pageNo > 1) {
            list.addAll(mFolioLookupAdapter.mDataList);
        }
        try {
            JSONObject jsonObject = null;
            jsonObject = new JSONObject(data);

            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }

                if (isSaveTrue) {
                    mListFirstData.addAll(list);
                }

            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mRvFolioLookup.setVisibility(View.VISIBLE);

            if (list.size() > 0) {
                mTvNothing.setVisibility(View.GONE);
                mFolioLookupAdapter.updateList(list);

            } else {
                mTvNothing.setVisibility(View.VISIBLE);
                mFolioLookupAdapter.updateList(list);
            }

        }


    }

    private void getFolioLookup(final String searchingValue, final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        mCurrentPageNo = pageNo;

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
            mRvFolioLookup.setVisibility(View.VISIBLE);
        } else {
            mRvFolioLookup.setVisibility(View.GONE);
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }


        String url = "";
        try {
            JSONArray filterArray = new JSONArray();


            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("search", "");
            filterArray.put(jsonObject2);
            if (!mSearchKey.isEmpty()) {
                JSONObject jsonObject21 = new JSONObject();
                if (Character.isDigit(mSearchKey.charAt(0))) {
                    jsonObject21.put("folioNo", mSearchKey);
                } else {
                    jsonObject21.put("schemeName", mSearchKey);
                }
                filterArray.put(jsonObject21);
            }


            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                if (UtilityKotlin.getClientHopObject(mSession).length() != 0) {
                    if (Utils.getSelectedLevelNo(mSession).equals("1")){
                        return;
                    }
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("activeOnly", true);
                    filterArray.put(jsonObject);

                    JSONObject jsonObject3 = new JSONObject();
                    jsonObject3.put("componentName", "folioTable");

                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                            Config.GET_FOLIO_LOOKUP_Client + "filters=" + filterArray +
                            "&orderByDesc=true&orderBy=AUM" + "&pageSize=" + mFetchListsize + "&currentPage="
                            + pageNo + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
                } else {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("activeOnly", false);
                    filterArray.put(jsonObject);

                    JSONObject jsonObject3 = new JSONObject();
                    jsonObject3.put("componentName", "FolioLookupTable");
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                            Config.GET_FOLIO_LOOKUP_Broker + "filters=" + filterArray
                            + "&orderByDesc=true&orderBy=AUM" + "&pageSize=" + mFetchListsize + "&currentPage="
                            + pageNo;

                }
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("activeOnly", true);
                filterArray.put(jsonObject);

                JSONObject jsonObject3 = new JSONObject();
                jsonObject3.put("componentName", "folioTable");
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_FOLIO_LOOKUP_Client + "filters=" + filterArray
                        + "&orderByDesc=true&orderBy=AUM" + "&pageSize=" + mFetchListsize + "&currentPage="
                        + pageNo + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
        } catch (Exception e) {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mRvFolioLookup.setVisibility(View.VISIBLE);
        }

  /*https://demo.investwell.app/webapi/broker/folio/getFolios?filters=[{"activeOnly":false},
  {"search":""}]&orderByDesc=true&orderBy=AUM&pageSize=20¤tPage=1&componentForLoader=
  {"componentName":"FolioLookupTable"}&selectedUser={}*/

        if (mSession.getExchangeNseBseMfu().equals("2")) {
            url = url + "&hasBseCode=true";
        }else if (mSession.getExchangeNseBseMfu().equals("3")) {
            url = url + "&hasMfuCode=true";
        }else if (mSession.getExchangeNseBseMfu().equals("4")) {
            url = url + "&hasNseInvestCode=true";
        }
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        loading = false;
                        if(!mSearchKey.isEmpty()){
                            toolbar.announceForAccessibility(getString(R.string.new_results_available_based_on_search_query));
                        }
                        SetData(response, !mSearchKey.isEmpty() && mSearchKey == null, pageNo);


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRvFolioLookup.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        if (mBrokerActivity != null)
            requestQueue = Volley.newRequestQueue(mBrokerActivity);
        else
            requestQueue = Volley.newRequestQueue(mMainActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public void downloadFile2(String folioId, String schemeId) {
        mFolioId = folioId;
        mSchemeId = schemeId;
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        String url = "";
        try {
            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("folioid", mFolioId);
            dateObject.put("schid", mSchemeId);
            jsonArray.put(dateObject);

            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.DOWNLOAD_FOLIO_SLIP_BROKER + "data=" + jsonArray
                        + "&flag=0";

            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.DOWNLOAD_FOLIO_SLIP + "data=" + jsonArray
                        + "&flag=0" + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "folio_lookup", "",new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_folio_slip_download_successfully), "pdf", mFileSave, uri);
                        else {
                            mMainActivity.showCommonDownload(mMainActivity, getString(R.string.txt_successfully), getString(R.string.txt_folio_slip_download_successfully), "pdf", mFileSave, uri);
                        }
                    }
                });

    }

    public void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }

        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }

    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();

        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }

        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private final ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {
            Log.d("DB", "PERMISSION GRANTED");
        } else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2(mFolioId, mSchemeId);
        }
    });
}
