package investwell.common.debugmode;

import android.content.Intent;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import investwell.activity.SplashActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppSession;
import investwell.utils.Extensions;

public class DebugActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private ApiAdapter mAdapter;
    private ApiDataBase mDb;
    private TextView textView83,mTvDebugView;
    private ImageView mIvDebug;
    private AppSession mSession;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        androidx.activity.EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_debug);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (view, insets) -> {
            androidx.core.graphics.Insets systemBars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return new androidx.core.view.WindowInsetsCompat.Builder(insets)
                    .setInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars(), androidx.core.graphics.Insets.NONE)
                    .build();
        });

        Extensions.checkDevice(this);


        initializer();
        setListener();

    }

    private void showDeleteDialog(String title, String msg, String type) {
        new MaterialAlertDialogBuilder(DebugActivity.this)
                .setTitle(title)
                .setMessage(msg)
                .setPositiveButton(getString(R.string.ok), (dialogInterface, i) -> {
                    if (type.equalsIgnoreCase("del")) {
                        AppExecutors.getInstance().diskIO().execute(() -> mDb.apiDao().deleteAll());
                        retrieveTasks();
                    } else {
                        mSession.setEnableDebug(false);
                        new Handler().postDelayed(() -> {
                            Intent intent = new Intent(getApplicationContext(), SplashActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                            startActivity(intent);
                            finish();
                        },2000);

                    }
                })
                .setNegativeButton(getString(R.string.cancel_caps), (dialogInterface, i) -> {

                })
                .show();
    }

    private void initializer() {
        textView83 = findViewById(R.id.textView83);
mTvDebugView=findViewById(R.id.tv_debug_view);
        mSession = AppSession.getInstance(this);
        mIvDebug = findViewById(R.id.iv_debug);
        mRecyclerView = findViewById(R.id.rv_data);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        // Initialize the adapter and attach it to the RecyclerView,
        mAdapter = new ApiAdapter(this);

        mRecyclerView.setAdapter(mAdapter);
        mDb = ApiDataBase.getInstance(getApplicationContext());

    }


    private void setListener() {
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NotNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            // Called when a user swipes left or right on a ViewHolder
            @Override
            public void onSwiped(@NotNull final RecyclerView.ViewHolder viewHolder, int swipeDir) {
                // Here is where you'll implement swipe to delete
                AppExecutors.getInstance().diskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        int position = viewHolder.getAdapterPosition();
                        List<ApiDataModel> tasks = mAdapter.getTasks();
                        mDb.apiDao().deleteApiData(tasks.get(position));
                        retrieveTasks();
                    }
                });
            }

            @Override
            public void onSelectedChanged(RecyclerView.ViewHolder viewHolder, int actionState) {
                if (viewHolder != null) {
                    final View foregroundView = ((ApiAdapter.MyViewHolder) viewHolder).viewForeground;

                    getDefaultUIUtil().onSelected(foregroundView);
                }
            }

            @Override
            public void onChildDrawOver(Canvas c, RecyclerView recyclerView,
                                        RecyclerView.ViewHolder viewHolder, float dX, float dY,
                                        int actionState, boolean isCurrentlyActive) {
                final View foregroundView = ((ApiAdapter.MyViewHolder) viewHolder).viewForeground;
                getDefaultUIUtil().onDrawOver(c, recyclerView, foregroundView, dX, dY,
                        actionState, isCurrentlyActive);
            }

            @Override
            public void clearView(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                final View foregroundView = ((ApiAdapter.MyViewHolder) viewHolder).viewForeground;
                getDefaultUIUtil().clearView(foregroundView);
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView,
                                    RecyclerView.ViewHolder viewHolder, float dX, float dY,
                                    int actionState, boolean isCurrentlyActive) {
                final View foregroundView = ((ApiAdapter.MyViewHolder) viewHolder).viewForeground;

                getDefaultUIUtil().onDraw(c, recyclerView, foregroundView, dX, dY,
                        actionState, isCurrentlyActive);
            }


            @Override
            public int convertToAbsoluteDirection(int flags, int layoutDirection) {
                return super.convertToAbsoluteDirection(flags, layoutDirection);
            }


        }).attachToRecyclerView(mRecyclerView);
        textView83.setOnClickListener(v -> showDeleteDialog(getString(R.string.delete_all_logs), getString(R.string.are_you_sure_you_want_to_delete), "del"));
        mIvDebug.setOnClickListener(v -> {
            showDeleteDialog(getString(R.string.disable_debug_mode), getString(R.string.are_you_sure_you_want_to_disable), "debug");
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        retrieveTasks();



    }

    private void retrieveTasks() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            final List<ApiDataModel> persons = mDb.apiDao().getApiDate();
            runOnUiThread(() -> mAdapter.setTasks(persons));

        });


    }
}