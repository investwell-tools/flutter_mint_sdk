package investwell.client.fragments.transection.additional.common;

import static investwell.utils.ExtensionsKt.getCanNumber;
import static investwell.utils.ExtensionsKt.getMfuId;
import static investwell.utils.ExtensionsKt.getUccCode;
import static investwell.utils.UtilityKotlin.checkFeaturePermissionsOnOff;
import static investwell.utils.UtilityKotlin.constructCartUrl;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.activity.MfuCartWebView;
import investwell.client.fragments.transection.FullScreenBsePopUpDialog;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.BaseFragment;
import investwell.utils.CurrencyTextToWord;
import investwell.utils.Permissions;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.allorderstatus.BseOrderStatusActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.customView.CustomDialog;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class FragRedeemNseBseMfu extends BaseFragment implements View.OnClickListener {
    private TextView purchase_cost, market_value, mTvcardview_top_name_color, mtvShortTermUnit,
            mTvShortTermAmount, mtvLongTermUnit, mTvLongTermAmount, mTvAmount, tvShortTerm, tvLongTerm,tvWordAmount;
    private RequestQueue requestQueue;
    private EditText mEtAmount;
    private final DecimalFormat myFormatter = new DecimalFormat("##,##,###.00");

    private ClientActivity mActivity;
    private AppSession mSession;
    private JSONObject mOldJsonObject, tranJsonObject;
    private ArrayList<JSONObject> mSchemeList;
    private long mMinAmount = 0, mMaxAmount = 0;
    private String mcardview_top_name_color = "";
    private RadioGroup mRadioGroup;
    private String mRedeemType = "amount";
    private LinearLayout mLinerRedeem;
    private AppApplication mAppplication;
    private RadioGroup mRadioGroupSchemeType;
    private TextView mTvLavelSchemeType;
    private String mSchemeType = "";
    private String schemeName = "";
    private String mTransactionType = "";
    private ApiDataBase db;
    private FullScreenBsePopUpDialog popup;

    private List<JSONObject> mJsonARNList;
    private Spinner mSpArn;
    private LinearLayout mLlArn;
    // private SlideToActView slideToPay;

    private String mBseId = "";
    private String mFundName = "";
    private JSONObject profileObject;

    private MaterialButton mTvCart, mTvPlaceOrder;
    private String exchange = "";
    private boolean isNse2 = false;
    private String uccNumber = "",nseUccCode="";


    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(
                url,
                req,
                res,
                AppConstants.REDEEM,
                dateTime,
                endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.Redemption),
                    true, false, false, false, false, false, false);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_additional_redeem, container, false);
        db = ApiDataBase.getInstance(mActivity.getApplicationContext());
        setUpToolBar();
        mActivity.setMainVisibility(this, null);

        mSpArn = view.findViewById(R.id.spArn);
        mLlArn = view.findViewById(R.id.llArn);
        mLlArn.setVisibility(View.GONE);


        TextView user_name = view.findViewById(R.id.user_name);
        tvShortTerm = view.findViewById(R.id.tvShortTerm);
        tvLongTerm = view.findViewById(R.id.tvLongTerm);
        mTvcardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);

        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        purchase_cost = view.findViewById(R.id.purchase_cost);
        market_value = view.findViewById(R.id.market_value);
        mEtAmount = view.findViewById(R.id.amount);
        tvWordAmount = view.findViewById(R.id.tvWordAmount);
        mtvShortTermUnit = view.findViewById(R.id.tvUnit);
        mTvShortTermAmount = view.findViewById(R.id.tvAmount);
        mtvLongTermUnit = view.findViewById(R.id.tvUnit2);
        mTvLongTermAmount = view.findViewById(R.id.tvAmount2);

        mRadioGroup = view.findViewById(R.id.radioGroup);
        mTvAmount = view.findViewById(R.id.tvAmountLavel);
        mLinerRedeem = view.findViewById(R.id.linerRedeem);
        mTvCart = view.findViewById(R.id.tvCart);
        mTvPlaceOrder = view.findViewById(R.id.tvPlaceOrder);

        mSchemeList = new ArrayList<>();

        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mOldJsonObject = new JSONObject(bundle.getString("oldObject"));
                tranJsonObject = new JSONObject(bundle.getString("tranJsonObject"));
                mFundName = mOldJsonObject.optString("fundName");

                if (bundle.containsKey("nse2")){
                    isNse2 = bundle.getBoolean("nse2");
                    exchange = bundle.getString("exchange");
                }else {
                    isNse2 = false;
                }

                if (bundle.containsKey("sIinProfileObject")){
                    profileObject = new JSONObject(bundle.getString("sIinProfileObject"));
                    if (isNse2){
                        mBseId = profileObject.optString("nseInvestid");
                        nseUccCode = getUccCode(isNse2,profileObject,mOldJsonObject);
                    }else {
                        mBseId = profileObject.optString("bseid");
                        uccNumber = getUccCode(isNse2,profileObject,mOldJsonObject);
                    }
                }
                mTransactionType = bundle.getString("transactionType");
                user_name.setText(mOldJsonObject.optString("applicant_name"));
                mTvcardview_top_name_color.setText(mOldJsonObject.optString("schemeName"));
                schemeName = mOldJsonObject.optString("schemeName");
                mMinAmount = tranJsonObject.optLong("minAmount");
                mMaxAmount = tranJsonObject.optLong("maxAmount");


                if (mOldJsonObject.has("purchaseValue")) {
                    purchase_cost.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optString("purchaseValue"))));

                } else {
                    purchase_cost.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optJSONObject("summary").optString("purchaseValue"))));

                }
                if (mOldJsonObject.has("currentValue")) {
                    market_value.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optString("currentValue"))));

                } else {
                    market_value.setText(myFormatter.format(Double.parseDouble(mOldJsonObject.optJSONObject("summary").optString("currentValue"))));

                }
                getBalance(mOldJsonObject.optString("folioid"));
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }
        }


        RadioButton radio1 = mRadioGroup.findViewById(R.id.radio1);
        RadioButton radio2 = mRadioGroup.findViewById(R.id.radio2);

        exchange = Utils.getSelectedExchange(mSession);
        if (mSession.getLoginType().equals("broker")) {
            getArnList();
        }
        if ((exchange.equals("2") && mOldJsonObject.optString("dematAccount").equals("Y")) || (exchange.equals("4") && mOldJsonObject.optString("dematAccount").equals("Y"))) {
            radio1.setVisibility(View.GONE);
            radio2.setChecked(true);
            mLinerRedeem.setVisibility(View.VISIBLE);
            mEtAmount.setHint(R.string.enter_unit);
            mTvAmount.setText(getString(R.string.unit));
            tvWordAmount.setVisibility(View.GONE);
            mRedeemType = "unit";
        } else {
            radio1.setVisibility(View.VISIBLE);
        }

        mRadioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radio1) {
                    mLinerRedeem.setVisibility(View.VISIBLE);
                    mEtAmount.setHint("Enter Amount");
                    mTvAmount.setText(getString(R.string.amount));
                    tvWordAmount.setVisibility(View.VISIBLE);
                    mRedeemType = "amount";
}
else if (checkedId == R.id.radio2) {
                    mLinerRedeem.setVisibility(View.VISIBLE);
                    mEtAmount.setHint("Enter Unit");
                    mTvAmount.setText(getString(R.string.unit));
                    tvWordAmount.setVisibility(View.GONE);
                    mRedeemType = "unit";
}
else if (checkedId == R.id.radio3) {
                    mRedeemType = "all";
                    mLinerRedeem.setVisibility(View.GONE);
                    hideKeyboard(mEtAmount);
}
        });

        mTvLavelSchemeType = view.findViewById(R.id.tvLavelSchemeType);
        mRadioGroupSchemeType = view.findViewById(R.id.radioGroup2);
        mRadioGroupSchemeType.setVisibility(View.GONE);
        mTvLavelSchemeType.setVisibility(View.GONE);

        mRadioGroupSchemeType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioSchemeType1) {
                        mSchemeType = "G";
}
else if (checkedId == R.id.radioSchemeType2) {
                        mSchemeType = "DP";
}
else if (checkedId == R.id.radioSchemeType3) {
                        mSchemeType = "DR";
}
            }
        });
        setInvestmentType();

        view.findViewById(R.id.edit).setOnClickListener(this);
        mTvCart.setOnClickListener(this);
        mTvPlaceOrder.setOnClickListener(this);

        handleAddToCartVisibility();


        mEtAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String word ="";
                if (!TextUtils.isEmpty(charSequence)){
                    try {
                        if (charSequence.length() !=0){
                            word = CurrencyTextToWord.convertToIndianCurrency(requireContext(), charSequence.toString().trim());
                        }else {
                            word =UtilityKotlin.firstLetterCapitalOfSentence("");
                        }
                    }catch (Exception e) {
                        if (BuildConfig.DEBUG)
                            e.printStackTrace();
                    }
                }else {
                    word = UtilityKotlin.firstLetterCapitalOfSentence("");
                }
                tvWordAmount.setText(word);

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        if (isNse2){
            view.findViewById(R.id.llInvestmentType).setVisibility(View.GONE);
        }
        return view;
    }

    public void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.edit) {
                if (mSchemeList.size() > 0) {
                    showSchemesDailog();
                } else {
                    getSchemes(mOldJsonObject.optString("fundid"));
                }
}
else if (v.getId() == R.id.tvPlaceOrder) {
                if(isValidInput()){
                    switch (exchange){
                        case AppConstants.NSE_APP:
                            placeReedemNSE(false);
                            break;
                        case AppConstants.BSE_APP:
                        case AppConstants.NEW_NSE_APP:
                            placeRedemtionBse(true, "", false, "",isNse2);
                            break;
                        case AppConstants.MFU_APP:
                            placeReedemMfu(false);
                            break;
                    }
                }
}
else if (v.getId() == R.id.tvCart) {
                if (mTvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {
                    if (isValidInput()) {
                        if(exchange.equalsIgnoreCase(AppConstants.MFU_APP))
                            insertTxnInMfuCart();
                        else
                            insertTxnInNseOrBseCart();
                    }
                }
                else{
                    Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                    intent.putExtra("url", constructCartUrl(mSession));
                    intent.putExtra("isPopup", true);
                    intent.putExtra("comeFrom", "client");
                    startActivity(intent);
                    new Handler(Looper.getMainLooper()).postDelayed(this::addToCartBtnClicked, 1500);

                }
}
    }

 /*   private OnActiveListener btnTransactOnActiveListener = new OnActiveListener() {
        @Override
        public void onActive() {
            checkValidation();
            if (btnTransact.isActive()) {
                btnTransact.toggleState();
            }
        }
    };*/

    private void handleAddToCartVisibility() {
        if (exchange.equalsIgnoreCase(AppConstants.NSE_APP)) {
            mTvCart.setVisibility(View.GONE);
        } else if (exchange.equalsIgnoreCase(AppConstants.BSE_APP)) {
            boolean isAddToCartBseEnabled = checkFeaturePermissionsOnOff(mSession, "feature1043", Permissions.ADD);
            if(mSession.getShowBseAuthPopup() && isAddToCartBseEnabled)
                mTvCart.setVisibility(View.VISIBLE);
        }else if (exchange.equalsIgnoreCase(AppConstants.NEW_NSE_APP)) {
            boolean isAddToCartNseInvestEnabled = checkFeaturePermissionsOnOff(mSession, "feature1053", Permissions.ADD);
            if(isNse2 && isAddToCartNseInvestEnabled)
                mTvCart.setVisibility(View.VISIBLE);
        } else if (exchange.equalsIgnoreCase(AppConstants.MFU_APP)) {
            boolean isAddToCartMfuEnabled = checkFeaturePermissionsOnOff(mSession, "feature1048", Permissions.ADD);
            if (isAddToCartMfuEnabled)
                mTvCart.setVisibility(View.VISIBLE);
            else
                mTvCart.setVisibility(View.GONE);
        }
    }


    private boolean isValidInput(){
        if (mRedeemType.equals("amount") && mEtAmount.getText().toString().equals("")) {
            Toast.makeText(mActivity, getString(R.string.error_empty_amount), Toast.LENGTH_SHORT).show();
            return false;
        } else if (mRedeemType.equals("unit") && mEtAmount.getText().toString().equals("")) {
            Toast.makeText(mActivity, getString(R.string.txt_please_enter_unit), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void insertTxnInMfuCart() {
        ProgressBarCommon.showDialog(requireContext());

        try {
            JSONObject objectMain = new JSONObject();

            objectMain.put("txnType", "NRS");  // static
            switch (mRedeemType) {
                case "amount":
                    objectMain.put("switchType", "amount");
                    break;
                case "unit":
                    objectMain.put("switchType", "units");
                    break;
                case "all":
                    objectMain.put("switchType", "allUnits");
                    break;
            }
            if(!mRedeemType.equalsIgnoreCase("all"))
                objectMain.put("redeemValue", mEtAmount.getText().toString().trim());
            objectMain.put("type", "sell");  // static
            objectMain.put("subType", "NRS");  // static
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    objectMain.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        objectMain.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }
            objectMain.put("mfuid", getMfuId(profileObject,mOldJsonObject));
            objectMain.put("can", getCanNumber(profileObject,mOldJsonObject));
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));

            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));


            JSONObject itemObject = getItemObjectMfu();
            objectMain.put("item", itemObject);

            String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.INSERT_MFU_CART_ITEM;

            new ApiClient(requireContext(), mSession).makeJsonPostRequest(
                    url,
                    objectMain,
                    isLoading -> {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireContext());
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                        return null;
                    },
                    response -> {
                        try {
                            if (response.optInt("status") == 0) {
                                addToCartBtnClicked();
                                Toast.makeText(requireContext(),getString(R.string.added_successfully),Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(requireContext(),response.optString("message"),Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception ignored) { }
                        return null;
                    },
                    error -> {
                        UtilityKotlin.parseVolleyError(error, mSession, requireContext(), "");
                        return null;
                    },
                    statusCode -> {
                        if (statusCode == 401) {
                            AppApplication appApplication = (AppApplication) getActivity().getApplication();
                            appApplication.showCommonDailog(
                                    requireContext(),
                                    getString(R.string.txt_session_expired),
                                    getString(R.string.txt_please_login_again_for_continue),
                                    "sessionExpired"
                            );
                        }
                        return null;
                    }
            );
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private JSONObject getItemObjectMfu() {
        JSONObject itemObject = new JSONObject();
        try {

            itemObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            itemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            itemObject.put("folioid", mOldJsonObject.optString("folioid"));
            String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
            itemObject.put("schid", schemeId);

            switch (mRedeemType) {
                case "amount":
                    itemObject.put("redeemType", "amount");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "unit":
                    itemObject.put("redeemType", "units");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "all":
                    itemObject.put("redeemType", "allUnits");
                    itemObject.put("redeemValue", "");
                    break;
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return itemObject;
    }

    private void insertTxnInNseOrBseCart() {
        ProgressBarCommon.showDialog(mActivity);

        JSONObject objectMain = new JSONObject();
        try {
            objectMain.put("type", "sell");
            if(isNse2 )
                objectMain.put("exchange", "4");
            else
                objectMain.put("exchange", "2");
            objectMain.put("subType", "NRS");
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));

            JSONObject itemObject = getNseOrBseItemObject();
            objectMain.put("item", itemObject);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.INSERT_NSE_BSE_CART_ITEM;

        new ApiClient(mActivity, mSession).makeJsonPostRequest(
                url,
                objectMain,
                it -> {
                    if (it) {
                        ProgressBarCommon.showDialog(mActivity);
                    } else {
                        ProgressBarCommon.dismissDialog();
                    }
                    return null;
                },
                response -> {
                    try {
                        if (response.optInt("status") == 0) {
                            addToCartBtnClicked();
                            Toast.makeText(mActivity,getString(R.string.added_successfully), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mActivity,response.optString("message"),Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception ignored) {
                    }
                    return null;
                },
                error -> {
                    UtilityKotlin.parseVolleyError(error, mSession, mActivity, "");
                    return null;
                },
                code -> {
                    if (code == 401) {
                        AppApplication appApplication = (AppApplication) getActivity().getApplication();
                        appApplication.showCommonDailog(
                                mActivity,
                                getString(R.string.txt_session_expired),
                                getString(R.string.txt_please_login_again_for_continue),
                                "sessionExpired"
                        );
                    }
                    return null;
                }
        );
    }
    private JSONObject getNseOrBseItemObject() {
        JSONObject itemObject = new JSONObject();

        try {
            // Folio
            itemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            itemObject.put("folioid", mOldJsonObject.optString("folioid"));
            itemObject.put("txnType", "ADDITIONAL");
            if(isNse2) {
                itemObject.put("nseInvestid", mBseId);
                itemObject.put("nseUccCode", nseUccCode);
            }
            else{
                itemObject.put("uccNumber", uccNumber);
                itemObject.put("bseid", mBseId);
            }
            // ARN handling
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    itemObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        itemObject.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        itemObject.put("arnid", folioObject.optString("arnid"));
                    }
                }
            }else {
                itemObject.put("arnid", "");
            }

            itemObject.put("investmentType", mSchemeType);

            itemObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
            itemObject.put("schid", schemeId);

            switch (mRedeemType) {
                case "amount":
                    itemObject.put("redeemType", "amount");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "unit":
                    itemObject.put("redeemType", "units");
                    itemObject.put("redeemValue", mEtAmount.getText().toString().trim());
                    break;
                case "all":
                    itemObject.put("redeemType", "allUnits");
                    itemObject.put("redeemValue", "");
                    break;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }

        return itemObject;
    }

    private void addToCartBtnClicked() {

        String newText;
        if (mTvCart.getText().toString().equalsIgnoreCase(getString(R.string.add_to_cart))) {
            newText = getString(R.string.go_to_cart);
            mTvPlaceOrder.setVisibility(View.GONE);
        } else {
            newText = getString(R.string.add_to_cart);
            mTvPlaceOrder.setVisibility(View.VISIBLE);
        }

        mTvCart.setText(newText);
    }

    private void setInvestmentType() {
        RadioButton radioButton = mRadioGroupSchemeType.findViewById(R.id.radioSchemeType1);
        RadioButton radioButton2 = mRadioGroupSchemeType.findViewById(R.id.radioSchemeType2);
        RadioButton radioButton3 = mRadioGroupSchemeType.findViewById(R.id.radioSchemeType3);
        radioButton.setVisibility(View.GONE);
        radioButton2.setVisibility(View.GONE);
        radioButton3.setVisibility(View.GONE);

        String investmentType = tranJsonObject.optString("investmentType");
        if (investmentType.equalsIgnoreCase("G")) {
            mRadioGroupSchemeType.setVisibility(View.GONE);
            mTvLavelSchemeType.setVisibility(View.GONE);
            mSchemeType = "G";
            // radioButton.setVisibility(View.VISIBLE);
        } else {
            mRadioGroupSchemeType.setVisibility(View.VISIBLE);
            mTvLavelSchemeType.setVisibility(View.VISIBLE);
            radioButton2.setVisibility(View.VISIBLE);
            radioButton3.setVisibility(View.VISIBLE);
        }
    }

    private void placeReedemMfu(boolean isIgnoreDuplicate) {
        Utils.hideKeyboard(mActivity);
        if (!isAdded())
            return;
        ProgressBarCommon.showDialog(requireActivity());
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.PLACE_ORDER_MFU;
        JSONObject objectMain = new JSONObject();

        try {

            JSONObject paymentObject = new JSONObject();
            paymentObject.put("paymentMode", "transfer");
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("uid", Utils.getSelectedUid(mSession));
            objectMain.put("schemeType", "");

            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    objectMain.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        objectMain.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }

            objectMain.put("mfuid", getMfuId(profileObject,mOldJsonObject));
            objectMain.put("can", getCanNumber(profileObject,mOldJsonObject));
            objectMain.put("source", "folio");

            objectMain.put("subType", "NRS");  // static
            objectMain.put("type", "sell");  // static
            objectMain.put("paymentMode", "transfer"); //// static
            objectMain.put("paymentAdded", "true"); // static

            JSONObject redemObject = new JSONObject();
            redemObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            redemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            redemObject.put("folioid", mOldJsonObject.optString("folioid"));
            String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
            redemObject.put("schid", schemeId);
            redemObject.put("investmentType", mSchemeType);
            if (mRedeemType.equals("amount")) {
                redemObject.put("redeemType", "amount");
                redemObject.put("redeemValue", mEtAmount.getText().toString().trim());
            } else if (mRedeemType.equals("unit")) {
                redemObject.put("redeemType", "units");
                redemObject.put("redeemValue", mEtAmount.getText().toString().trim());
            } else if (mRedeemType.equals("all")) {
                redemObject.put("redeemType", "allUnits");
                redemObject.put("redeemValue", "");
            }

            objectMain.put("item", redemObject);
            objectMain.put("paymentDetails", paymentObject);
            if (isIgnoreDuplicate)
                objectMain.put("ignoreDuplicate", "N");

        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(url, objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.PLACE_ORDER_MFU);

                ProgressBarCommon.dismissDialog();
                try {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        Bundle bundle = new Bundle();
                        bundle.putString("resultObject", resultObject.toString());
                        mActivity.displayViewOther(38, bundle);
                    } else if (jsonObject.optInt("status") == 3) {
                        orderExistsDailog("mfu");
                    } else {
                        String message = jsonObject.optString("message");
                        appApplication.showCommonDailog(getActivity(), "Failed", message, "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        ProgressBarCommon.dismissDialog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void orderExistsDailog(String type) {
        if (!isAdded())
            return;
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    if (type.equals("bse")) {
                        placeRedemtionBse(true,
                                "",
                                false,
                                "",
                                isNse2);

                    } else if (type.equals("nse")) {
                        placeReedemNSE(true);
                    } else if (type.equals("mfu")) {
                        placeReedemMfu(true);
                    } else if (type.equals("nse2")) {
                        placeRedemtionBse(true,
                                "",
                                false,
                                "",isNse2);

                    }
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(getActivity(), getString(R.string.alert_dialog_order_exist_header_txt),
                getString(R.string.alert_dialog_order_exist_message_txt),
                getString(R.string.alert_dialog__order_exist_button1),
                getString(R.string.alert_dialog__order_exist_button2),
                true, true);
    }

    private void placeReedemNSE(boolean isIgnoreDuplicate) {
        Utils.hideKeyboard(mActivity);
        if (!isAdded())
            return;
        ProgressBarCommon.showDialog(requireActivity());
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.PLACE_NSE_ORDER;
        JSONObject objectMain = new JSONObject();

        try {

            JSONObject paymentObject = new JSONObject();
            paymentObject.put("paymentMode", "transfer");
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));
            objectMain.put("uid", Utils.getSelectedUid(mSession));
            objectMain.put("schemeType", "");
            objectMain.put("iinNo", mOldJsonObject.optString("iinNo"));
            objectMain.put("subType", "NRS");  // static
            objectMain.put("type", "sell");  // static
            objectMain.put("paymentMode", "transfer"); //// static
            objectMain.put("paymentAdded", "true"); // static


            JSONObject redemObject = new JSONObject();
            redemObject.put("schemeName", mOldJsonObject.optString("schemeName"));
            redemObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            redemObject.put("folioid", mOldJsonObject.optString("folioid"));
            redemObject.put("IIN", mOldJsonObject.optString("iinNo"));
            String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
            redemObject.put("schid", schemeId);
            redemObject.put("investmentType", mSchemeType);
            if (mRedeemType.equals("amount")) {
                redemObject.put("redeemType", "amount");
                redemObject.put("redeemValue", mEtAmount.getText().toString().trim());
            } else if (mRedeemType.equals("unit")) {
                redemObject.put("redeemType", "units");
                redemObject.put("redeemValue", mEtAmount.getText().toString().trim());
            } else if (mRedeemType.equals("all")) {
                redemObject.put("redeemType", "allUnits");
                redemObject.put("redeemValue", "");
            }
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    redemObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        redemObject.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        redemObject.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }

            objectMain.put("item", redemObject);
            objectMain.put("paymentDetails", paymentObject);

            if (isIgnoreDuplicate)
                objectMain.put("ignoreDuplicate", "N");

        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(url, objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.PLACE_NSE_ORDER);

                ProgressBarCommon.dismissDialog();
                try {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject resultObject = jsonObject.optJSONObject("result");

                        Bundle bundle = new Bundle();
                        bundle.putString("resultObject", resultObject.toString());
                        mActivity.displayViewOther(38, bundle);
                    } else if (jsonObject.optInt("status") == 3) {
                        orderExistsDailog("nse");
                    } else {
                        String message = jsonObject.optString("message");
                        appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        ProgressBarCommon.dismissDialog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }


    private void placeRedemtionBse(
            boolean isIgnoreDuplicate,
            String otp,
            boolean isValidated,
            String provisonalOrderId,
            boolean isNseRedeem
    ) {
        Utils.hideKeyboard(getActivity());
        if (!isAdded())
            return;
        ProgressBarCommon.showDialog(requireActivity());

        String url = "";
        if (isNseRedeem){
            url ="https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +Config.NSE_INVEST_PLACE_ORDER;
        }else {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.PLACE_Redemtion_ORDER;
        }
        JSONObject objectMain = new JSONObject();
        try {
            objectMain.put("selectedUser", Utils.getSelectedUserObject(mSession));
            objectMain.put("investorUid", Utils.getSelectedUid(mSession));

            if (!isNseRedeem && isValidated){
                objectMain.put("provisionalOrderid", provisonalOrderId);
                objectMain.put("otp", otp);
            } else {
                // common
                if (mRedeemType.equals("amount")) {
                    objectMain.put("amount", mEtAmount.getText().toString().trim());
                } else {
                    if (isNseRedeem){
                        objectMain.put("amount", 0);
                    }else {
                        objectMain.put("amount", "0");
                    }
                }

                if (mRedeemType.equals("unit")) {
                    objectMain.put("units", mEtAmount.getText().toString().trim());
                } else {
                    if (isNseRedeem){
                        objectMain.put("units", 0);
                    }else {
                    objectMain.put("units", "0");
                    }
                }

                if (mRedeemType.equals("all")) {
                    objectMain.put("allUnits", "Y");
                } else {
                    objectMain.put("allUnits", "N");
                }

                objectMain.put("folioNo", mOldJsonObject.optString("folioNo"));
                objectMain.put("folioid", mOldJsonObject.optString("folioid"));

                String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
                objectMain.put("schid", schemeId);

                if (mSession.getLoginType().equals("broker")) {
                    if (mJsonARNList.size() == 1) {
                        JSONObject folioObject = mJsonARNList.get(0);
                        objectMain.put("arnid", folioObject.optString("arnid"));
                    } else {
                        int position = mSpArn.getSelectedItemPosition();
                        if (position == 0)
                            objectMain.put("arnid", "");
                        else {
                            JSONObject folioObject = mJsonARNList.get(position - 1);
                            objectMain.put("arnid", folioObject.optString("arnid"));
                        }
                    }
                } else {
                     objectMain.put("arnid", "");
                }



                if (isIgnoreDuplicate)
                    objectMain.put("ignoreDuplicate", "N");

                if (isNseRedeem){
                    // nse 2 flow
                    objectMain.put("nseInvestid", mBseId);
                    objectMain.put("txnType", "ADDITIONAL");
                    objectMain.put("nseUccCode", nseUccCode);
                    objectMain.put("txnMode", "R");


                }else {
                    // bse flow
                    objectMain.put("uccNumber", uccNumber);

                }




            }

        } catch (Exception e) {

        }
        final String finalurl = url;
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(finalurl, objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.PLACE_Redemtion_ORDER);

                ProgressBarCommon.dismissDialog();
                try {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject mPlaceOderResponseObj = jsonObject.optJSONObject("result");
                        mPlaceOderResponseObj.put("txnType", "redeem");
                        mPlaceOderResponseObj.put("redeemType", mRedeemType); //amount, unit,all
                        mPlaceOderResponseObj.put("dematAccount", mOldJsonObject.optString("dematAccount"));

                        if (!isNseRedeem){
                            if (!mSession.getShowBseAuthPopup()){
                                Bundle bundle = new Bundle();
                                bundle.putString("bseid", mBseId);
                                bundle.putString("type", "bseRedeem");
                                bundle.putString("payNowOptionType", "");
                                bundle.putString("amount", mEtAmount.getText().toString().trim());
                                mPlaceOderResponseObj.put("ClientCode", uccNumber);
                                bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                bundle.putString("fundName", mFundName);
                                if (mSession.getShowBseAuthPopup()){
                                    bundle.putBoolean("isOtpValidated", true);
                                    if (popup.isAdded() && popup.isVisible()){
                                        popup.dismiss();
                                    }
                                }
                                Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                intent.putExtras(bundle);
                                startActivity(intent);
                            }else {
                                // new flow
                                if (mSession.getShowBseAuthPopup() && isValidated){
                                    Bundle bundle = new Bundle();
                                    bundle.putString("bseid", mBseId);
                                    bundle.putString("type", "bseRedeem");
                                    bundle.putString("payNowOptionType", "");
                                    bundle.putString("amount", mEtAmount.getText().toString().trim());
                                    mPlaceOderResponseObj.put("ClientCode", uccNumber);
                                    bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                                    bundle.putString("fundName", mFundName);
                                    if (mSession.getShowBseAuthPopup()){
                                        bundle.putBoolean("isOtpValidated", isValidated);
                                        if (popup.isAdded() && popup.isVisible()){
                                            popup.dismiss();
                                        }
                                    }
                                    Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                                    intent.putExtras(bundle);
                                    startActivity(intent);
                                }else {
                                    showOTPAuth(
                                            true,
                                            mPlaceOderResponseObj.optString("provisionalOrderid")
                                    );
                                }
                            }
                        }else {
                            Bundle bundle = new Bundle();
                            bundle.putString("nseInvestid", mBseId);
                            bundle.putString("type", "nse2Redeem");
                            bundle.putString("payNowOptionType", "");
                            bundle.putString("amount", mEtAmount.getText().toString().trim());
                            mPlaceOderResponseObj.put("ClientCode", nseUccCode);
                            bundle.putString("resultObject", mPlaceOderResponseObj.toString());
                            bundle.putString("fundName", mFundName);
                            Intent intent = new Intent(getActivity(), BseOrderStatusActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);

                        }


                     /*   JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        Bundle bundle = new Bundle();
                        bundle.putString("resultObject", jsonObject1.toString());
                        mActivity.displayViewOther(38, bundle);*/


                    } else if (jsonObject.optInt("status") == 3) {
                        if (isNseRedeem){
                            orderExistsDailog("nse2");
                        }else {
                            orderExistsDailog("bse");
                        }
                    } else {
                        String message = jsonObject.optString("message");
                        appApplication.showCommonDailog(getActivity(), getString(R.string.failed), message, "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        ProgressBarCommon.dismissDialog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void showOTPAuth(boolean isignoreDuplicate,String mProvisionalOrderid){
        popup = new FullScreenBsePopUpDialog();
        Bundle bundle = new Bundle();
        bundle.putString("profileData",profileObject.toString());
        bundle.putString("purchaseType","Redeem");
        bundle.putString("funname",mFundName);
        bundle.putString("mProvisionalOrderid", mProvisionalOrderid);
        bundle.putBoolean("ispurchase",false);
        popup.setArguments(bundle);
        popup.onValidateButtonClick(new Function1<Bundle, Unit>() {
            @Override
            public Unit invoke(Bundle bundle) {
                // place order by otp
                String otp = bundle.getString("otp");
                placeRedemtionBse( isignoreDuplicate,
                        otp,
                        true,
                        mProvisionalOrderid,
                        false);
                return null;
            }
        });
        popup.show(requireActivity().getSupportFragmentManager(),"FullScreenPopup");
    }


    private void getArnList() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        try {


            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "investOnline");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ARN_LIST_NSE + "exchange=" + exchange +
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

          /*  https://spvithlani.investwell.app/webapi/client/getArns?
            // exchange=2&investorUid=67c025d3f470b86011712f7f974d669d
            // &selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mBar.dismiss();

                        mJsonARNList = new ArrayList<>();
                        ArrayList<String> arnList = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    arnList.add(jsonObject1.optString("arnNo"));
                                    mJsonARNList.add(jsonObject1);
                                }
                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(getActivity(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {

                        } finally {
                            if (mJsonARNList.size() > 1) {
                                mLlArn.setVisibility(View.VISIBLE);
                                setArnList(arnList);
                            } else {
                                mLlArn.setVisibility(View.GONE);
                            }


                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void setArnList(List<String> list) {
        try {
            if (mSession.getLoginType().equalsIgnoreCase("broker")) {
                mLlArn.setVisibility(View.VISIBLE);
            }else {
                mLlArn.setVisibility(View.GONE);
            }
            list.add(0, getString(R.string.select_arn_2));
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpArn.setAdapter(dataAdapter);


        } catch (Exception e) {

        }
    }


    private void getBalance(String folioId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_BALANCE + "folioid=" + folioId + "&considerObjOfFolio=true"
                    + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            //    https://spvithlani.investwell.app/webapi/client/investOnline/getBalanceUnits?
            //    folioid=ad7bb34a7e0f8dfc8e5b006193b14dec&considerObjOfFolio=true
            //    &investorUid=6158fa1dba4bf04015e91d2e2caf5bcc&selectedUser={"uid":
            //    "6158fa1dba4bf04015e91d2e2caf5bcc","levelNo":"98"}
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }


        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl, "GET REQ CONTAINS URL IN REQ", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_BALANCE);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");

                                JSONArray keyList = jsonObject1.optJSONArray("keys");
                                String keyName1 = keyList.optString(0);
                                String keyName2 = keyList.optString(1);
                                JSONObject objLongLockTerm = jsonObject1.optJSONObject(keyName1);
                                JSONObject objShortUnlockedTerm = jsonObject1.optJSONObject(keyName2);

                                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                                format.setMinimumFractionDigits(0);
                                format.setMaximumFractionDigits(2);

                                if (keyName1.equalsIgnoreCase("longTerm")) {
                                    tvLongTerm.setText(getString(R.string.long_term));
                                    tvShortTerm.setText(getString(R.string.short_term));

                                    DecimalFormat df = new DecimalFormat("0.0000");
                                    String unitLongTerm = df.format(objLongLockTerm.optDouble("units"));
                                    String unitShortTerm = df.format(objShortUnlockedTerm.optDouble("units"));

                                    if (unitLongTerm.equals("0.0000")) {
                                        mtvLongTermUnit.setText("0");
                                    } else {
                                        mtvLongTermUnit.setText(unitLongTerm);
                                    }

                                    if (unitShortTerm.equals("0.0000")) {
                                        mtvShortTermUnit.setText("0");
                                    } else {
                                        mtvShortTermUnit.setText(unitShortTerm);
                                    }


                                    double longTermAmount = objLongLockTerm.optDouble("amount");
                                    String strCurrentAmount = format.format(longTermAmount);
                                    mTvLongTermAmount.setText(strCurrentAmount);

                                    double currentValue = objShortUnlockedTerm.optDouble("amount");
                                    String shortTermAmount = format.format(currentValue);
                                    mTvShortTermAmount.setText(shortTermAmount);

                                } else {
                                    tvShortTerm.setText(getString(R.string.Locked));
                                    tvLongTerm.setText(getString(R.string.Unlocked));

                                    DecimalFormat df = new DecimalFormat("0.0000");
                                    String locked = df.format(objLongLockTerm.optDouble("units"));
                                    String unlocked = df.format(objShortUnlockedTerm.optDouble("units"));


                                    if (locked.equals("0.0000")) {
                                        mtvShortTermUnit.setText("0");
                                    } else {
                                        mtvShortTermUnit.setText(locked);
                                    }


                                    if (unlocked.equals("0.0000")) {
                                        mtvLongTermUnit.setText("0");
                                    } else {
                                        mtvLongTermUnit.setText(unlocked);
                                    }

                                    double lock = objLongLockTerm.optDouble("amount");
                                    String strLockAmount = format.format(lock);
                                    mTvShortTermAmount.setText(strLockAmount);

                                    double unlockedValue = objShortUnlockedTerm.optDouble("amount");
                                    String unlockedAmount = format.format(unlockedValue);
                                    mTvLongTermAmount.setText(unlockedAmount);
                                }


                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getSchemes(String fundId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "";

        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FUND_SCHEAMES + "fundid=" + fundId;
            switch (exchange) {
                case "1":
                    url = url + "&hasNseCode=true";
                    break;
                case "2":
                    url = url + "&hasBseCode=true";
                    break;
                case "3":
                    url = url + "&hasMfuCode=true";
                    break;
                case "4":
                    url = url + "&hasNseInvestCode=true";
                    break;
            }
        } catch (Exception e) {

        }

        String finalUrl = url+"&selectedUser="+Utils.getSelectedUserObject(mSession);
        finalUrl = UtilityKotlin.setRefreshKeyInExistingApi(finalUrl, mSession);
        String finalUrl1 = finalUrl;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, finalUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl1, "GET REQ CONTAINS REQ IN URL", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.GET_FUND_SCHEAMES);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.getJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    mSchemeList.add(jsonArray.optJSONObject(i));
                                }
                                showSchemesDailog();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void showSchemesDailog() {
        final boolean[] mIsFirstTime = {true};
        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.change_scheme);
        final Spinner mSchemeSpinner = dialog.findViewById(R.id.scheme);
        Button mSubmitBtn = dialog.findViewById(R.id.submit_btn);

        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < mSchemeList.size(); i++) {
            JSONObject jsonObject = mSchemeList.get(i);
            String data = jsonObject.optString("name");
            list.add(data);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_bg, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
        mSchemeSpinner.setAdapter(dataAdapter);

        mSchemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                int selectedPostion = mSchemeSpinner.getSelectedItemPosition();
                JSONObject jsonObject = mSchemeList.get(selectedPostion);
                mcardview_top_name_color = jsonObject.optString("name");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mcardview_top_name_color.equals(""))
                    mTvcardview_top_name_color.setText(mcardview_top_name_color);
                dialog.dismiss();
            }
        });


        dialog.findViewById(R.id.close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
    }

}

