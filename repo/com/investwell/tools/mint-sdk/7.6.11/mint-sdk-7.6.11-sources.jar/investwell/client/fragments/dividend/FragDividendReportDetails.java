package investwell.client.fragments.dividend;

import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.DividendReportDetailAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;

/**
 * Created by Dev on 16/08/2021.
 */

public class FragDividendReportDetails extends BaseFragment implements View.OnClickListener {
    RequestQueue requestQueue;
    DividendReportDetailAdapter mDividendReportDetailAdapter;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private boolean loading = false;
    private LinearLayoutManager mLayoutManager;
    private ShimmerFrameLayout mShimmerViewContainer;
    private ScrollView mTopLayout;
    private TextView mTvNothing;
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;
    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;
    private TextView mTvInvestorName, mTvSchemeName, mtvfolio, mTvDivReinvTotal, mTvDivPayTotal, mTvDivTdsTotal ;
    private List<JSONObject> mListFirstData;
    private int mCurrentPageNo = 0;
    private int mFetchListsize = 15;
    private String mSearchKey = "";
    RecyclerView mRvDividendReport;
    CardView mclient_total;

    @Override
    public void onResume() {
        super.onResume();
    /*    if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);
            mBrokerActivity.setMainVisibility(this, null);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
            mMainActivity.setMainVisibility(this, null);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.dividend_report_detail),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_dividend_report_details, container, false);
        setUpToolBar();

        mclient_total = view.findViewById(R.id.folio_total);
        mTvInvestorName = view.findViewById(R.id.investorName);
        mTvSchemeName = view.findViewById(R.id.SchemeName);
        mtvfolio= view.findViewById(R.id.tvfolio);
        mTvDivReinvTotal = view.findViewById(R.id.div_reinv_total);
        mTvDivPayTotal = view.findViewById(R.id.div_pay_total);
        mTvDivTdsTotal = view.findViewById(R.id.div_tds_total);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mTvNothing = view.findViewById(R.id.tvLoading);
        mTvNothing.setVisibility(View.GONE);

        mListFirstData = new ArrayList<>();

        if(!isDarkTheme(requireContext()))
            view.findViewById(R.id.llDividendReportDetails).setBackgroundResource(R.mipmap.card_blank);

        mRvDividendReport = view.findViewById(R.id.recycleView);
        mRvDividendReport.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRvDividendReport.setLayoutManager(mLayoutManager);
        mDividendReportDetailAdapter = new DividendReportDetailAdapter(getActivity(),  this, new ArrayList<JSONObject>(), new DividendReportDetailAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });

        mRvDividendReport.setAdapter(mDividendReportDetailAdapter);
        mRvDividendReport.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 15;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getDividendReport(  mCurrentPageNo );
                            }
                        }
                    }
                }
            }
        });

        getDividendReport( 1 );
        return view;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }
    private void SetData(String data, final boolean isSaveTrue, int pageNo) {
        List<JSONObject> list = new ArrayList<>();
        if (pageNo > 1) {
            list.addAll(mDividendReportDetailAdapter.mDataList);
        }
        try {
            JSONObject jsonObject = null;
            jsonObject = new JSONObject(data);

            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                if(jsonObjectMain.length()>0) {
                    JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                    mclient_total.setVisibility(View.VISIBLE);
                    JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                    mTvInvestorName.setText(((JSONObject) jsonArray.get(0)).getString("investor"));
                    mTvSchemeName.setText(((JSONObject) jsonArray.get(0)).getString("scheme"));
                    mtvfolio.setText(((JSONObject) jsonArray.get(0)).getString("folioNo"));
                    mTvDivReinvTotal.setText(String.format("%.2f", jsonObjectSummary.optDouble("reinvest")));
                    mTvDivPayTotal.setText(String.format("%.2f", jsonObjectSummary.optDouble("payout")));
                    mTvDivTdsTotal.setText(String.format("%.2f", jsonObjectSummary.optDouble("tdsAmount")));

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        list.add(jsonObject1);
                    }

                    if (isSaveTrue) {
                        mListFirstData.addAll(list);
                    }
                }

            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        } finally {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mRvDividendReport.setVisibility(View.VISIBLE);

            if (list.size() > 0) {
                mTvNothing.setVisibility(View.GONE);
                mDividendReportDetailAdapter.updateList(list);

            } else {
                mTvNothing.setVisibility(View.VISIBLE);
                mDividendReportDetailAdapter.updateList(list);
            }

        }

    }

    private void getDividendReport( final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
            mRvDividendReport.setVisibility(View.VISIBLE);
        } else {
            mRvDividendReport.setVisibility(View.GONE);
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String url = "";
//        String uId = "";
//        String levelNo = "";
        try {
            JSONArray filterArray = new JSONArray();
            JSONObject jsonObjectSearch = new JSONObject();
            filterArray.put(jsonObjectSearch);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("fromDate", this.getArguments().getString("fromDate"));
            jsonObject.put("toDate", this.getArguments().getString("toDate"));
            jsonObject.put("schid", this.getArguments().getString("schid"));
            jsonObject.put("folioid", this.getArguments().getString("folioid"));
            filterArray.put(jsonObject);
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                JSONObject jsonObject1 = new JSONObject();
                if (UtilityKotlin.getClientHopObject(mSession).length() != 0) {
                    if (Utils.getSelectedLevelNo(mSession).equals("1")){
                        return;
                    }
                    jsonObject1.put("uid", Utils.getSelectedUid(mSession));
                    jsonObject1.put("levelNo", Utils.getSelectedLevelNo(mSession));
                    JSONObject jsonObject2 = new JSONObject();
                    jsonObject2.put("selectedUser",jsonObject1 );
                    filterArray.put(jsonObject2);

                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                            + Config.GET_DIVIDEND_REPORT_CLIENT+ "filters=" + filterArray.toString()
                            +"&orderByDesc=true"+"&pageSize=" + mFetchListsize + "&currentPage="
                            + pageNo +"&investorUid=" + Utils.getSelectedUid(mSession) ;
                } else {
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                            + Config.GET_DIVIDEND_REPORT_CLIENT+ "filters=" + filterArray.toString()
                            + "&orderByDesc=true"+ "&pageSize=" + mFetchListsize + "&currentPage="
                            + pageNo ;
                }
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                        + Config.GET_DIVIDEND_REPORT_CLIENT+ "filters=" + filterArray.toString()
                        + "&orderByDesc=true"+ "&pageSize=" + mFetchListsize + "&currentPage=" + pageNo;
            }
        } catch (Exception e) {
            mShimmerViewContainer.stopShimmer();
            mShimmerViewContainer.setVisibility(View.GONE);
            mRvDividendReport.setVisibility(View.VISIBLE);
        }
        String finalurl = url+"&selectedUser="+Utils.getSelectedUserObject(mSession);
        finalurl = UtilityKotlin.setRefreshKeyInExistingApi(finalurl, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, finalurl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        loading = false;
                        if (!mSearchKey.isEmpty() && mSearchKey == null) {
                            SetData(response, true, pageNo);
                        } else {
                            SetData(response, false, pageNo);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRvDividendReport.setVisibility(View.VISIBLE);

                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        if (mBrokerActivity != null)
            requestQueue = Volley.newRequestQueue(mBrokerActivity);
        else
            requestQueue = Volley.newRequestQueue(mMainActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

}