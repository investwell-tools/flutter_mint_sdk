package investwell.client.fragments.portfolioSummary;

import static investwell.utils.ExtensionsKt.checkExchangeId;
import static investwell.utils.ExtensionsKt.checkFirstHolderPan;
import static investwell.utils.ExtensionsKt.checkFirstPan;
import static investwell.utils.ExtensionsKt.checkSecondHolderName;
import static investwell.utils.ExtensionsKt.checkSecondHolderPan;
import static investwell.utils.ExtensionsKt.checkThirdHolderName;
import static investwell.utils.ExtensionsKt.checkfirstHolderName;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.IinbyFolioAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;

public class FragIinByFolio extends BaseFragment implements View.OnClickListener {
    private AppSession mSession;
    private ClientActivity mActivity;
    private JSONObject mJsonObject;
    private TextView mTvErrorMessage;
    public String mFolioId = "", mAppId = "";
    private AppApplication mAppplication;
    private ToolbarFragment mFragToolBar;
    private Bundle mBundle, mBundle2;
    private IinbyFolioAdapter iinbyFolioAdapter;
    private TextView tvJointHolder, tvNomini, tvTaxAndHolding, tvFolio, tvFirstHolderName, tvLevelTaxHolding;
    String exchange = "";


    @Override
    public void onResume() {
        super.onResume();
     /*   if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.text_choose_iin), true, false, false, false, false, false, false);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.inn_ucc_by_folio, container, false);
        mActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setUpToolBar();
            }
        });

        tvFirstHolderName = view.findViewById(R.id.tvFirstHolderName);
        tvFolio = view.findViewById(R.id.tvFolio);
        tvTaxAndHolding = view.findViewById(R.id.tvTaxAndHolding);
        tvNomini = view.findViewById(R.id.tvNomini);
        tvJointHolder = view.findViewById(R.id.tvJointHolder);
        tvLevelTaxHolding = view.findViewById(R.id.tvLevelTaxHolding);

        mTvErrorMessage = view.findViewById(R.id.tvNothing);
        view.findViewById(R.id.tvContunue).setOnClickListener(this);
        mTvErrorMessage.setVisibility(View.GONE);

        LinearLayout llCard = view.findViewById(R.id.llCard);
        RecyclerView recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        iinbyFolioAdapter = new IinbyFolioAdapter(getActivity(), new ArrayList<JSONObject>(), 0, new IinbyFolioAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {

            }
        });
        recyclerView.setAdapter(iinbyFolioAdapter);
        if (mBundle == null) {
            mBundle2 = new Bundle();
            mBundle = getArguments();
            mBundle2.putAll(mBundle);
        }

        if (mSession.getHasMultiExchange()) {
            exchange = AppApplication.sExchangeType;
            if (exchange == "")
                exchange = mSession.getExchangeNseBseMfu();
        } else {
            if (mSession.getHasNseOpted()) {
                exchange = "1";
            } else if (mSession.getHasBseOpted()) {
                exchange = "2";
            } else if (mSession.getHasMfuOpted()) {
                exchange = "3";
            } else if (mSession.getHasNse2Opted()) {
                exchange = "4";
            } else {
                exchange = mSession.getExchangeNseBseMfu();
            }
        }

        if (mBundle2 != null) {
            List<JSONObject> list = new ArrayList<>();

            try {
                mJsonObject = new JSONObject(mBundle2.getString("oldObject"));
                mJsonObject.put("applicant_name", mJsonObject.optString("applicantName"));
                mFolioId = mJsonObject.optString("folioid");
                mAppId = mJsonObject.optString("appid");
                JSONObject sIinProfileObject =null;
                try {
                sIinProfileObject = new JSONObject(mBundle2.getString("sIinProfileObject"));
                JSONObject folioDetialsObject = sIinProfileObject.optJSONObject("folioDetail");
                if (folioDetialsObject == null) {
                    folioDetialsObject = new JSONObject();
                }

                tvFirstHolderName.setText(folioDetialsObject.optString("firstHolderName"));

                if (mJsonObject.optString("applicantName").isEmpty()) {
                    mJsonObject.put("applicant_name", folioDetialsObject.optString("firstHolderName"));
                }
                tvFolio.setText(folioDetialsObject.optString("folioNo"));
                String value1 = folioDetialsObject.optString("taxStatus");
                String value2 = folioDetialsObject.optString("holdingNature");
                if (!value1.equalsIgnoreCase("null") && !value1.equalsIgnoreCase(""))
                    tvTaxAndHolding.setText(value1 + " (" + value2 + ")");
                else{
                    tvLevelTaxHolding.setVisibility(View.GONE);
                }

                    String nomineeName = folioDetialsObject.optString("nomineeName","");
                    if (nomineeName.equalsIgnoreCase("") || nomineeName.equalsIgnoreCase("null")) {
                    tvNomini.setText(getString(R.string.not_available));
                } else {
                    tvNomini.setText(nomineeName);
                }


                String jt1Name ="";
                String jt2Name ="";
                if (folioDetialsObject.has("jt1Name")) {
                    jt1Name = folioDetialsObject.optString("jt1Name", "");
                } else if (folioDetialsObject.has("JH1Name")) {
                    jt1Name = folioDetialsObject.optString("JH1Name", "");
                } else if (folioDetialsObject.has("jh1Name")) {
                    jt1Name = folioDetialsObject.optString("jh1Name", "");
                }

                if (folioDetialsObject.has("jt2Name")) {
                    jt2Name = folioDetialsObject.optString("jt2Name", "");
                } else if (folioDetialsObject.has("JH2Name")) {
                    jt2Name = folioDetialsObject.optString("JH2Name", "");
                } else if (folioDetialsObject.has("jh2Name")) {
                    jt2Name = folioDetialsObject.optString("jh2Name", "");
                }

//                folioDetialsObject.optString(folioDetialsObject.has("jt1Name") ? "jt1Name" : "JH1Name", "");
//                String jt2Name = folioDetialsObject.optString(folioDetialsObject.has("jt2Name") ? "jt2Name" : "JH2Name", "");

                if (isEmptyOrNull(jt1Name) || isEmptyOrNull(jt2Name)) {
                    tvJointHolder.setText(getString(R.string.not_available));
                } else {
                    tvJointHolder.setText(isEmptyOrNull(jt2Name) ? jt1Name : jt1Name + "," + jt2Name);
                }

                }catch (Exception e){}

                if (sIinProfileObject.optBoolean("recommended")) {
                    JSONArray jsonArray = sIinProfileObject.getJSONArray("data");
                    if (jsonArray.length() > 0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.optJSONObject(i);
                            list.add(object);
                        }
                    }
                }
            } catch (Exception e) {

            } finally {
                if (list.size() > 0) {
                    view.findViewById(R.id.tvContunue).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.llCard).setVisibility(View.VISIBLE);
                    mTvErrorMessage.setVisibility(View.GONE);

                    iinbyFolioAdapter.updateList(list);
                } else {
                    view.findViewById(R.id.tvContunue).setVisibility(View.GONE);
                    view.findViewById(R.id.llCard).setVisibility(View.GONE);
                    mTvErrorMessage.setVisibility(View.VISIBLE);

                    if (exchange.equals("1")) {
                        mTvErrorMessage.setText(getString(R.string.no_iin_available));
                    } else if (exchange.equals("2")) {
                        mTvErrorMessage.setText(getString(R.string.no_ucc_available));
                    } else if (exchange.equals("3")) {
                        mTvErrorMessage.setText(getString(R.string.no_ucc_available));
                    }else if (exchange.equals("4")) {
                        mTvErrorMessage.setText(getString(R.string.no_ucc_available));
                    }
                }
            }
        }

//        if (mSession.getHasMultiExchange()) {
//            exchange = AppApplication.sExchangeType;
//            if (exchange == "")
//                exchange = mSession.getExchangeNseBseMfu();
//        } else {
//            if (mSession.getHasNseOpted()) {
//                exchange = "1";
//            } else if (mSession.getHasBseOpted()) {
//                exchange = "2";
//            } else if (mSession.getHasMfuOpted()) {
//                exchange = "3";
//            } else if (mSession.getHasNse2Opted()) {
//                exchange = "4";
//            } else {
//                // exchange = mSession.getExchangeNseBseMfu();
//            }
//        }
      //  AppApplication.sExchangeType = exchange;
        return view;
    }

    private boolean isEmptyOrNull(String str) {
        return str == null || str.trim().isEmpty() || str.equalsIgnoreCase("null");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvContunue) {
                goForTransactions();
}
    }

    private void goForTransactions() {
        try {
            if (iinbyFolioAdapter.mHashSelection.containsValue(true)) {
                if (exchange.equals("4")){
                    mBundle.putBoolean("nse2",true);
                    mBundle.putString("exchange","4");
                }else{
                    mBundle.putString("exchange",exchange);
                    mBundle.putBoolean("nse2",false);
                }
                JSONObject msIinProfileObject= null;
                for (int i = 0; i < iinbyFolioAdapter.mHashSelection.size(); i++) {
                    if (iinbyFolioAdapter.mHashSelection.get(i)) {
                        JSONObject jsonObject = iinbyFolioAdapter.mDataList.get(i);
                        mBundle.putString("sIinProfileObject", jsonObject.toString());
                        msIinProfileObject = new JSONObject(jsonObject.toString());
                        String id = "";


                        if (exchange.equals("1")) {
                            id = jsonObject.optString("iinNo");
                            mJsonObject.put("iinNo", id);
                        } else if (exchange.equals("2")) {
                            id = jsonObject.optString("uccNumber");
                            mJsonObject.put("uccNumber", id);
                        } else if (exchange.equals("3")) {
                            id = jsonObject.optString("mfuid");
                            mJsonObject.put("mfuid", id);
                            String source = jsonObject.optString("source");
                            mJsonObject.put("source", source);
                            mJsonObject.put("canNumber", jsonObject.optString("canNumber"));
                        }else if (exchange.equals("4")) {
                            id = jsonObject.optString("nseUccCode");
                            mJsonObject.put("nseUccCode", id);
                        }


                    }
                }

                mBundle.putString("oldObject", mJsonObject.toString());
                String transactionType = mBundle.getString("transactionType");

                JSONObject panlist = UtilityKotlin.buildPanList(msIinProfileObject);
                JSONObject nameList = UtilityKotlin.buildNameList(msIinProfileObject);

                if (mActivity!= null){
                    mBundle.putString("panList",panlist.toString());
                    mBundle.putString("nameList",nameList.toString());
                    mBundle.putString("exchangeId",checkExchangeId(msIinProfileObject));
                    mBundle.putString("exchange",exchange);
                    mBundle.putString("appid",mAppId);
                    mBundle.putString("mTransactionType",transactionType);
                    mBundle.putString("mUccIinResponseObject",msIinProfileObject.toString());
                    mBundle.putString("comeFrom","additional");
                    mActivity.displayViewOther(88,mBundle);
                }


               /* if (transactionType.equalsIgnoreCase("NRP")) {
                    if (exchange.equals("1")) {
                        mActivity.displayViewOther(27, mBundle);
                    } else if (exchange.equals("2") || exchange.equals("4")) {
                        mActivity.displayViewOther(8, mBundle);
                    } else if (exchange.equals("3")) {
                        mActivity.displayViewOther(43, mBundle);
                    }

                } else if (transactionType.equalsIgnoreCase("SIP")) {
                    if (exchange.equals("1")) {
                        mActivity.displayViewOther(28, mBundle);
                    } else if (exchange.equals("2") || exchange.equals("4")) {
                        mActivity.displayViewOther(9, mBundle);
                    } else if (exchange.equals("3")) {
                        mActivity.displayViewOther(44, mBundle);
                    }

                } else if (transactionType.equalsIgnoreCase("SWO")) {
                    mActivity.displayViewOther(10, mBundle);
                } else if (transactionType.equalsIgnoreCase("SWP")) {
                    if (exchange.equals("1")) {
                        mActivity.displayViewOther(86, mBundle);
                    } else {
                        mActivity.displayViewOther(11, mBundle);
                    }
                } else if (transactionType.equalsIgnoreCase("STP")) {
                    if (exchange.equals("1")) {
                        mActivity.displayViewOther(87, mBundle);
                    } else {
                        mActivity.displayViewOther(12, mBundle);
                    }
                } else if (transactionType.equalsIgnoreCase("NRS")) {
                    mActivity.displayViewOther(13, mBundle);
                }*/

            } else {
                Toast.makeText(mActivity, R.string.txt_please_select_profile, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {

        }
    }
}
