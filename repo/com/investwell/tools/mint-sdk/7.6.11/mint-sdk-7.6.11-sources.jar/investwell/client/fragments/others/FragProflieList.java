package investwell.client.fragments.others;


import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;

import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.RecyCleProfilesAdapter;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.SearchAnimationToolbar;


public class FragProflieList extends BaseFragment implements View.OnClickListener, SearchAnimationToolbar.OnSearchQueryChangedListener  {
    private AppSession mSession;
    public static String values;
    private ClientActivity mActivity;
    private RequestQueue requestQueue;
    private AppApplication mAppplication;
    private RecyCleProfilesAdapter mAdapter;
    private TextView mTvLoading;
    private ShimmerFrameLayout mShimmerViewContainer;
    private RecyclerView recyclerView;

    private boolean loading = false;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private LinearLayoutManager mLayoutManager;
    private int mCurrentPageNo = 0;
    private int mFetchListsize = 10;
    private Timer timer = new Timer();
    private final long DELAY = 1000; // milliseconds
    private SearchAnimationToolbar toolbar;
    private LinearLayout fullScreenShedow;
    private RelativeLayout singleShedow;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.stopShimmer();
    }

    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmer();
        super.onPause();
    }

    @Override
    public void onStart() {
        super.onStart();
        mActivity.mCvTabBarBottom.setVisibility(View.GONE);
    }

    @Override
    public void onStop() {
        super.onStop();

        try {
            InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            IBinder binder = getActivity().getCurrentFocus().getWindowToken();
            if (imm.isAcceptingText() && binder != null) {
                imm.hideSoftInputFromWindow(binder, 0);
            }
        }catch (Exception e){

        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_client_search, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        toolbar = view.findViewById(R.id.toolbar);
        toolbar.setSupportActionBar((AppCompatActivity) getActivity());
        toolbar.setOnSearchQueryChangedListener(this);
        toolbar.setTitle(getString(R.string.txt_profile_list));

        ((AppCompatActivity) getActivity()).getSupportActionBar().setHomeAsUpIndicator(R.mipmap.ic_arrow_back);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);


        mTvLoading = view.findViewById(R.id.tvLoading);
        mTvLoading.setVisibility(View.GONE);

        recyclerView = view.findViewById(R.id.recycleView);
        recyclerView.setNestedScrollingEnabled(true);
        mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new RecyCleProfilesAdapter(getActivity(), new ArrayList<JSONObject>(), new RecyCleProfilesAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                  /*  JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("folioid", jsonObject.optString("folioid"));
                    bundle1.putString("isAnimation", "true");
                    mActivity.displayViewOther(15, bundle1);*/
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 10;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getProfileList("", mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        getProfileList("", 1);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
        }
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_search, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int itemId = item.getItemId();

        if (itemId == R.id.action_search) {
            toolbar.onSearchIconClick();
            return true;
        } else if (itemId == android.R.id.home) {
            getActivity().onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSearchCollapsed() {
        if (mAdapter.mDataList.size() ==0) {
            getProfileList("", 1);
        }
    }

    @Override
    public void onSearchQueryChanged(final String query) {
        if (query.length() > 0) {
            timer.cancel();
            timer = new Timer();
            timer.schedule(
                    new TimerTask() {
                        @Override
                        public void run() {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    getProfileList(query, 1);                                            }
                            });


                        }
                    },
                    DELAY
            );


        }else{
            getProfileList("", 1);
        }
    }

    @Override
    public void onSearchExpanded() {
        // searchText.setText(R.string.expanded);
    }

    @Override
    public void onSearchSubmitted(String query) {
        System.out.println();
        //searchText.setText(getString(R.string.submitted, query));
    }


    private void getProfileList(String text, final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCurrentPageNo = pageNo;

        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo>1){
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        }else{
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }

        String afterDecode = "";
        try {
            JSONArray jsonArray = new JSONArray();
            if (!text.equalsIgnoreCase("")){
                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("searchFor", text);
                jsonArray.put(jsonObject1);
            }

            JSONObject jsonObject4 = new JSONObject();
            jsonObject4.put("componentName", "investOnlineBse");

            afterDecode = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_PROFILE_LIST + "status=active&filters="
                    + jsonArray.toString() + "&pageSize=" + mFetchListsize + "&currentPage="
                    + pageNo ;

            afterDecode = UtilityKotlin.setRefreshKeyInExistingApi(afterDecode, mSession);
            afterDecode = URLDecoder.decode(afterDecode, "UTF-8");
        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, afterDecode,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        loading = false;
                        List<JSONObject> list = new ArrayList<>();
                        if (pageNo > 1) {
                            list.addAll(mAdapter.mDataList);
                        }
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            recyclerView.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mAdapter.updateList(list);
                                mTvLoading.setVisibility(View.GONE);
                            } else {
                                mAdapter.updateList(new ArrayList<JSONObject>());
                                mTvLoading.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

}
