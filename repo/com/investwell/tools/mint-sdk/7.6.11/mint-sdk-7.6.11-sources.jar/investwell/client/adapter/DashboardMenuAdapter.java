package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;
import investwell.utils.model.FinancialTools;

import java.util.List;


public class DashboardMenuAdapter extends RecyclerView.Adapter<DashboardMenuAdapter.MyViewHolder> {
    private Context mContext;
    public List<FinancialTools> financialToolList;
    private DashboardMenuListener dashListener;

    public DashboardMenuAdapter(Context context, List<FinancialTools> financialToolList, DashboardMenuListener dashListeners) {
        this.financialToolList = financialToolList;
        mContext = context;
        dashListener = dashListeners;
    }

    @NonNull
    @Override
    public DashboardMenuAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row_dashboard_menu, parent, false);

        return new DashboardMenuAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(DashboardMenuAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        FinancialTools financialTools = financialToolList.get(position);
        holder.tvFinancialTerms.setText(!TextUtils.isEmpty(financialTools.getFinancialTerms()) ? financialTools.getFinancialTerms() : "");
        holder.ivMenuIcons.setImageResource(financialTools.getImgFinancialTools());
        holder.llFinancialTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dashListener.onToolsClick(financialTools.getMenuId());
                dashListener.onToolsPosClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return financialToolList.size();
    }

    public interface DashboardMenuListener {
        void onToolsClick(String menuId);
        void onToolsPosClick(int pos);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvFinancialTerms;
        LinearLayout llFinancialTools;
        ImageView ivMenuIcons;

        public MyViewHolder(View view) {
            super(view);
            tvFinancialTerms = view.findViewById(R.id.tv_dashboard_menu_title);
            llFinancialTools=view.findViewById(R.id.ll_menu);
            ivMenuIcons=view.findViewById(R.id.iv_menu_icons);
        }
    }
}
