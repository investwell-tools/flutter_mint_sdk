package investwell.client.adapter;

import static investwell.utils.ExtensionsKt.putSafely;
import static investwell.utils.UtilityKotlin.parseVolleyError;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.client.fragments.transection.BottomScreenPaymentMode;
import investwell.common.allorderstatus.BseOrderStatusActivity;
import investwell.common.transactions.FullScreenPaymentStatus;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;

public class FragMyOrderAdapter extends RecyclerView.Adapter<FragMyOrderAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    Context context;
    private AppSession mSession;
    private BottomScreenPaymentMode bottomPaymentMode;


    public FragMyOrderAdapter(ArrayList<JSONObject> jsonObject, Context context) {
        this.mDataList = jsonObject;
        this.context = context;
        mSession = AppSession.getInstance(context);
    }

    @NonNull
    @Override
    public FragMyOrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.my_order_layout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final FragMyOrderAdapter.ViewHolder holder, int position) {
        if (position == 1) {
            holder.itemView.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                @Override
                public void onScrollChanged() {
                    Rect rect = new Rect();
                    holder.itemView.getGlobalVisibleRect(rect);
                }
            });
        }
        final JSONObject jsonObject1 = mDataList.get(position);
        holder.investor_name.setText(Utils.setFirstLetterCapital(jsonObject1.optString("investorName")));
        holder.investor_name.setSelected(true);
        holder.cardview_top_name_color.setText(jsonObject1.optString("schemeName"));
        Double amountInDoundle = jsonObject1.optDouble("amount");
        if (!Double.isNaN(amountInDoundle)) {
            holder.amount.setText(NumberFormat.getCurrencyInstance(new Locale("en", "in")).format(amountInDoundle));
        }else{
            holder.amount.setText("");
        }
        holder.date.setText(Utils.formatedDate(jsonObject1.optString("updatedAt")));
        holder.status.setText(Utils.setFirstLetterCapital(jsonObject1.optString("status")));
        String unit = jsonObject1.optString("unit");
        holder.unit.setText((unit.equals("null")) ? "0" : unit);
        holder.subType.setText(Utils.SchemeNameFormat(jsonObject1.optString("subType")));

        String exchange = "";
        if (mSession.getHasMultiExchange()){
            exchange = AppApplication.sExchangeType;
            if (exchange == "")
                exchange = mSession.getExchangeNseBseMfu();
        }else{
            if (mSession.getHasNseOpted()){
                exchange = "1";
            }else if (mSession.getHasBseOpted()){
                exchange = "2";
            }else if (mSession.getHasMfuOpted()){
                exchange = "3";
            }else if (mSession.getHasNse2Opted()){
                exchange = "4";
            }else{
                exchange = mSession.getExchangeNseBseMfu();
            }
        }

        if (exchange.equals("1")) {
            holder.tvUCC.setText(context.getResources().getString(R.string.inn));
            holder.ucc.setText(jsonObject1.optString("iinNo"));

        } else if (exchange.equals("2")) {
            holder.tvUCC.setText(context.getResources().getString(R.string.ucc));
            holder.ucc.setText(jsonObject1.optString("uccNumber"));


            if (mSession.getLoginType().equals("broker") && mSession.getClientObject().isEmpty()) {
                System.out.println("broker no need authentication");
                holder.llAuth.setVisibility(View.GONE);
            } else {
            String status = jsonObject1.optString("status");
            String subType = Utils.SchemeNameFormat(jsonObject1.optString("subType"));
            if (status.equalsIgnoreCase("failed") || status.equalsIgnoreCase("success")){
                holder.llAuth.setVisibility(View.GONE);
            }else{
                holder.llAuth.setVisibility(View.VISIBLE);
                if (jsonObject1.optString("isDematAccount").equalsIgnoreCase("Y")) {
                    holder.tvAuthenticate.setText(R.string.Pay_Now_text);
                }else {
                    if (subType.equalsIgnoreCase("Purchase") || subType.equalsIgnoreCase("sip")) {
                        holder.tvAuthenticate.setText(R.string.authenticate_pay);
                    } else {
                        holder.tvAuthenticate.setText(R.string.authenticate_no);
                    }
                }
                if (mSession.getShowBseAuthPopup()){
                    String isFirstPayNow = jsonObject1.optString("firstOrderFlag");
                    if (subType.equalsIgnoreCase("Purchase") || subType.equalsIgnoreCase("sip") || isFirstPayNow.equalsIgnoreCase("Y")) {
                        holder.tvAuthenticate.setText(R.string.Pay_Now_text);
                    }else {
                        holder.tvAuthenticate.setVisibility(View.GONE);
                    }
                }
            }

            holder.llAuth.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (!mSession.getShowBseAuthPopup()) {
                            Bundle bundle = new Bundle();
                            bundle.putString("bseid", jsonObject1.optString("bseid"));
                            jsonObject1.put("orderNo", jsonObject1.optString("paymentRefNo"));
                            jsonObject1.put("dematAccount", jsonObject1.optString("isDematAccount"));

                            bundle.putString("payNowOptionType", "");
                            bundle.putString("amount", jsonObject1.optString("amount"));
                            bundle.putString("resultObject", jsonObject1.toString());
                            bundle.putString("fundName", "");
                            bundle.putString("comingFrom", "orderHistory");
                            Intent intent = new Intent(context, BseOrderStatusActivity.class);
                            intent.putExtras(bundle);
                            context.startActivity(intent);
                        }else {

                            // V2 api
                            Bundle mbBundle = new Bundle();
                            mbBundle.putString("mBseId", jsonObject1.optString("bseid"));
                            bottomPaymentMode = BottomScreenPaymentMode.create(
                                    context,
                                    R.style.ModalBottomSheetDialog,
                                    mbBundle
                            );
                            bottomPaymentMode.setListener(resultBundle -> {
                                try {
//                                        val mOtp =resultBundle?.getString("otp")!!
                                    String mOrderId = resultBundle.getString("orderid");
                                    String loopbackUrl = resultBundle.getString("loopbackUrl");
                                    String mode = resultBundle.getString("mode");
                                    JSONObject paymentDetails = new JSONObject(resultBundle.getString("paymentDetails"));
                                    payWithOTPV2(
                                            jsonObject1.optString("orderid"),
                                            jsonObject1.optString("subOrderid"),
                                            mode,
                                            paymentDetails,
                                            loopbackUrl,
                                            holder.llAuth
                                        );
                                    bottomPaymentMode.dismiss();
                                } catch (Exception e) {
                                }
                            });
                            bottomPaymentMode.show();
                        }
                    }catch (Exception e){

                    }
                }
            });
            }
        } else if (exchange.equals("3")) {
            holder.tvUCC.setText(context.getResources().getString(R.string.can));
            holder.ucc.setText(jsonObject1.optString("canNumber"));

        }

        String orderNo = jsonObject1.optString("paymentRefNo");
        holder.order_no.setText(orderNo.equals("null") ? "Not Available" : orderNo);
        if (jsonObject1.optString("status").equalsIgnoreCase("failed")) {
            holder.status.setTextColor(ContextCompat.getColor(context, R.color.red_text_color));
        } else {
            holder.status.setTextColor(ContextCompat.getColor(context, R.color.green_text_color));
        }

        if (jsonObject1.optString("remark").length()>0){
            holder.remarkView.setVisibility(View.VISIBLE);
            holder.remark.setText(jsonObject1.optString("remark"));
        }else{
            holder.remarkView.setVisibility(View.GONE);
        }



    }

    private void showHideLoader(boolean isLoading){
        if (isLoading){
            ProgressBarCommon.showDialog(context);
        }else{
            ProgressBarCommon.dismissDialog();
        }
    }
    private void payWithOTPV2(String orderid,String subOrderid, String paymentMode, JSONObject paymentDetails, String loopbackUrl, LinearLayout llAuth) {

        String url ="";
        if (mSession.getLoginType().equalsIgnoreCase("broker") && mSession.getClientObject().isEmpty()) {
         url= "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.MAKE_PAYMENT_BROKER_V2;
        }else {
            if (Utils.getSelectedLevelNo(mSession).equals("1")){
                return;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.MAKE_PAYMENT_V2_CLIENT;
        }
        try {
            JSONObject payload = new JSONObject();
            payload.put("orderid",orderid);
            putSafely(payload,"subOrderid",subOrderid);
            payload.put("paymentMode",paymentMode);
            payload.put("accountNo",paymentDetails.optString("accountNo"));
            payload.put("ifscCode",paymentDetails.optString("ifscCode"));
            payload.put("bankName",paymentDetails.optString("bankName"));
            payload.put("loopbackUrl",loopbackUrl);
            if (paymentMode.contains("upi")){
                payload.put("vpaNo",paymentDetails.optString("vpaNo"));
            }else if (paymentMode.contains("neft/rtgs")){
                payload.put("neftReferenceNo",paymentDetails.optString("neftReferenceNo"));
            }
            payload.put("bankName",paymentDetails.optString("bankName"));
            payload.put("selectedUser",Utils.getSelectedUserObject(mSession));

            ApiClient api = new ApiClient(context, mSession);

            api.makeJsonPostRequest(
                    url,
                    payload,
                    isLoading -> {
                        showHideLoader(isLoading);
                        return null;
                    },
                    response -> {
                        Bundle mBundle = new Bundle();
                        try{
                            if (response.optInt("status") == 0) {
                                JSONObject mPlaceOderResponseObj = response.optJSONObject("result");

                                if (mPlaceOderResponseObj != null) {
                                    String orderNumber = !mPlaceOderResponseObj.optString("OrderNumber").equals("null") &&
                                            !mPlaceOderResponseObj.optString("OrderNumber").isEmpty()
                                            ? mPlaceOderResponseObj.optString("OrderNumber")
                                            : "";

                                    String paymentData = !mPlaceOderResponseObj.optString("paymentData").equals("null") &&
                                            !mPlaceOderResponseObj.optString("paymentData").isEmpty()
                                            ? mPlaceOderResponseObj.optString("paymentData")
                                            : "";

                                    String status = mPlaceOderResponseObj.optString("status");

                                    if (!paymentData.isEmpty() && !status.equals("failed")) {
                                        // New screen flow with design
                                        mBundle.putString("type", "success");
                                        mBundle.putString("title", "Payment");
                                        mBundle.putString("mTitle", orderNumber);
                                        mBundle.putString("mode", paymentMode);
                                        mBundle.putString("mDescription", context.getString(R.string.txt_bse_order_status_des));
                                        mBundle.putBoolean("lottie", true);
                                        mBundle.putString("message", mPlaceOderResponseObj.optString("amount"));
                                        mBundle.putString("paymentData", paymentData);
                                        mBundle.putString("call_from", "myorder");

                                        popupSuccessOrFailed(mBundle, ((FragmentActivity) context).getSupportFragmentManager());

                                        if (paymentMode.contains("Net Banking")) {
                                            Intent netBankingContent = new Intent(context, AppIntoMintWebPortalActivity.class);
                                            netBankingContent.putExtra("title", "Transaction");
                                            netBankingContent.putExtra("htmlContent", paymentData);
                                            netBankingContent.putExtra("endPointUrl", loopbackUrl);
                                            context.startActivity(netBankingContent);
                                        }
                                    } else {
                                        // Order ID is missing
                                        mBundle.putString("type", "failed");
                                        mBundle.putString("title", "Couldn't proceed with the payment");
                                        mBundle.putBoolean("lottie", true);
                                        mBundle.putString("mode",paymentMode);
                                        mBundle.putString("message", context.getString(R.string.txt_bse_failed_order_message));
                                        mBundle.putString("call_from", "myorder");

                                        popupSuccessOrFailed(mBundle, ((FragmentActivity) context).getSupportFragmentManager());
                                    }
                                }
                            } else if (response.optInt("status") == -1) {
                                if (mSession.getShowBseAuthPopup()) {
                                    mBundle.putString("type", "failed");
                                    mBundle.putString("title", "Couldn't proceed with the payment");
                                    mBundle.putBoolean("lottie", true);
                                    mBundle.putString("mode",paymentMode);
                                    mBundle.putString("message", context.getString(R.string.txt_bse_failed_order_message));
                                    mBundle.putString("call_from", "myorder");

                                    popupSuccessOrFailed(mBundle, ((FragmentActivity) context).getSupportFragmentManager());
                                } else {
                                    String message = response.optString("message");
                                    if (llAuth.isAttachedToWindow()) {
                                        Snackbar.make(llAuth, message, Snackbar.LENGTH_LONG).show();
                                    }
                                }
                            }
                        }catch (Exception e){}
                        return null;
                    },
                    error -> {
                        parseVolleyError(error, mSession, context, "");
                        return null;
                    },
                    statusCode -> {
                        if (statusCode == 401) {
                            new AppApplication().showCommonDailog(
                                    context,
                                    context.getResources().getString(R.string.txt_session_expired),
                                    context.getResources().getString(R.string.txt_please_login_again_for_continue),
                                    "sessionExpired"
                            );
                        }
                        return null;
                    }
            );

        }catch (Exception e){}

    }

    private void popupSuccessOrFailed(Bundle dataBunndle, FragmentManager fragmentManager){
        FullScreenPaymentStatus popup = new FullScreenPaymentStatus();
        popup.setArguments(dataBunndle);
        popup.onValidateButtonClick(bundle -> {
            popup.dismiss();
            return null;
        });

        popup.show(fragmentManager, "FullScreenPopup");
    }
    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView cardview_top_name_color,tvAuthenticate, investor_name, amount, unit, status, order_no, ucc, date, tvUCC, remark, subType;
        LinearLayout remarkView, llAuth;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardview_top_name_color = itemView.findViewById(R.id.cardview_top_name_color);
            investor_name = itemView.findViewById(R.id.investor_name);
            amount = itemView.findViewById(R.id.amount);
            unit = itemView.findViewById(R.id.unit);
            status = itemView.findViewById(R.id.status);
            order_no = itemView.findViewById(R.id.order_no);
            ucc = itemView.findViewById(R.id.ucc);
            date = itemView.findViewById(R.id.date);
            tvUCC = itemView.findViewById(R.id.tvUCC);
            remark = itemView.findViewById(R.id.remark);
            remarkView = itemView.findViewById(R.id.remarkView);
            subType = itemView.findViewById(R.id.subType);
            llAuth = itemView.findViewById(R.id.llAuth);
            tvAuthenticate = itemView.findViewById(R.id.tvAuthenticate);
        }

    }

}
