package investwell.client.fragments.aum;

import static investwell.utils.UtilityKotlin.isDarkTheme;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.Frag_Aum_Adapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

;


public class FragAumReport extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    TextView mTvTotal, mTvDEbt, mTvEquity, tvHybrid, mTvOther, mTvArbi, mTvLiqUltra, mTvCgar;
    Frag_Aum_Adapter mAumAdapter;
    private AutoCompleteTextView mSpArn, spUserType, spCategory, spUser;
    int mPosArn = -1, mposUserType = -1, mPosCat = -1, mPosUser = -1;
    int mposLocalUserType = -1, mPosLocalUser = -1, mPosLocalCat = -1, mPosLocalArn = -1;
    private ConstraintLayout cl_arn, cl_user_type;
    private List<JSONObject> mJsonARNList, mJsonUserTypeList, mJsonCategoryList, mJsonUserList, mJsonFilteredResult;
    private List<String> mcatLocalList = new ArrayList<>();
    private List<String> mArnLocalList = new ArrayList<>();
    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mLinerMain, llAumCard;
    private TextView mTvNothing, tvErrorUserType, tvErrorUser;
    private ToolbarFragment fragToolBar;
    private boolean isCheckedFilter = false;
    private ChipGroup chip_group;
    private Chip chip;
    private JSONObject jsonObjectUserType;
    private AlertDialog alertDialog;
    private AlertDialog.Builder dialogBuilder;
    private ProgressDialog mBar = null;
    private String AUM_FILTERED = "", AUM_FILTER = "", CATEGOTY = "", ARNID = "";
    private ArrayList<String> userList;
    private ArrayList<String> uList;
    private TextInputLayout til_user;
    private boolean isSelected = false;
    private String currentUser = "";

    @Override
    public void onResume() {
        super.onResume();
  /*      if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.aum_report),
                    false, false, false, false, false, false, false);
            fragToolBar.setCallback(this);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_aum_report, container, false);
        setUpToolBar();
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mLinerMain = view.findViewById(R.id.linerMain);
        llAumCard = view.findViewById(R.id.ll_card_aum);
        if(!isDarkTheme(requireContext()))
            llAumCard.setBackgroundResource(R.mipmap.card_blank);
        mTvNothing = view.findViewById(R.id.tvNothing);

        // filter


        mTvTotal = view.findViewById(R.id.tvTotal);
        mTvDEbt = view.findViewById(R.id.tvDept);
        mTvEquity = view.findViewById(R.id.tvEquity);
        mTvLiqUltra = view.findViewById(R.id.tvLiqUltra);
        mTvOther = view.findViewById(R.id.tvOther);
        mTvArbi = view.findViewById(R.id.tvArbi);
        tvHybrid = view.findViewById(R.id.tvHybrid);

        RecyclerView recycleView = view.findViewById(R.id.recycleView);

        recycleView.setHasFixedSize(true);
        recycleView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        mAumAdapter = new Frag_Aum_Adapter(getActivity(), new ArrayList<JSONObject>(), new Frag_Aum_Adapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    JSONObject jsonObject = mAumAdapter.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("fundid", jsonObject.optString("fundid"));
                    String schemeId = Utils.getSchemeIdFromAll(jsonObject);
                    bundle1.putString("schemeId", schemeId);
                    bundle1.putString("name", jsonObject.optString("name"));
                    bundle1.putString("filter", AUM_FILTER);
                    bundle1.putString("category", CATEGOTY);
                    bundle1.putString("arnid", ARNID);
                    bundle1.putString("isAnimation", "true");

                    if (mBrokerActivity != null) {
                        mBrokerActivity.displayViewOther(25, bundle1);
                    } else {
                        mMainActivity.displayViewOther(25, bundle1);
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        recycleView.setAdapter(mAumAdapter);

        // setUserVisibleHint(true);
        if (AppApplication.AUM_REPORT.isEmpty()) {
            getAum();
        } else {
            if (AUM_FILTERED.isEmpty()) {
                SetData();
            } else {
                try {
                    ArrayList<JSONObject> resultList = new ArrayList<>();
                    JSONObject jsonObject = new JSONObject(AUM_FILTERED);
                    setAUMDATA(jsonObject, resultList);
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }


            }

        }

        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                getActivity().getSupportFragmentManager().popBackStack();
}

    }

    private void callUserType() {
        mJsonUserTypeList = new ArrayList<>();
        userList = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(mSession.getAllLoginData());

            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.optJSONArray("lowerReportingLevels");
                for (int i = 0; i < jsonArray.length(); i++) {
                    jsonObjectUserType = jsonArray.getJSONObject(i);
                    userList.add(jsonObjectUserType.optString("levelName"));
                    mJsonUserTypeList.add(jsonObjectUserType);
                }
            } else if (jsonObject.optInt("status") == -1) {
                if (mBrokerActivity != null) {
                    Toast.makeText(mBrokerActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(mMainActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        } finally {
            if (mJsonUserTypeList.size() > 1)
                setUserTypeList(userList);
        }

    }

    private void setUserTypeList(final List<String> list) {
        try {
//            list.add(0, "Select Type");
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(requireContext(), R.layout.spinner_dropdown, list);
            spUserType.setAdapter(dataAdapter);
            spUserType.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long rowId) {
                    String selection = (String) parent.getItemAtPosition(position);
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).equals(selection)) {
                            mposUserType = i;
                            mposLocalUserType = i;
                            String s = spUser.getText().toString();
                            til_user.setVisibility(View.VISIBLE);
                            if (!s.isEmpty()) {
                                uList.clear();
                                spUser.setText("");
                            }
                            break;
                        }
                    }
                }
            });

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    private void callARN() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_ARN;
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity());
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mJsonARNList = new ArrayList<>();
                ArrayList<String> arnList = new ArrayList<>();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            arnList.add(jsonObject1.optString("arnNo"));
                            mJsonARNList.add(jsonObject1);
                        }
                    } else if (jsonObject.optInt("status") == -1) {
                        if (mBrokerActivity != null) {
                            Toast.makeText(mBrokerActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mMainActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (mJsonARNList.size() > 1)
                        setArnList(arnList);
                }
            }
        });

    }

    private void addChipToGroup(String s) {
        chip = new Chip(requireContext());
//        chip.setChipIcon(ContextCompat.getDrawable(getActivity(),R.drawable.plane_cross));
        chip.setChipIconVisible(true);
        chip.setCloseIconVisible(true);
        chip.setClickable(true);
        chip.setCheckable(false);
        chip_group.addView((View) chip);
        chip.setOnCloseIconClickListener(view -> {
            chip_group.removeView((View) chip);
        });
    }

    private void setArnList(final List<String> list) {
        list.add(0,getString(R.string.all_my_arns));
        mArnLocalList = list;
        try {
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(requireContext(), R.layout.spinner_dropdown, list);
            mSpArn.setAdapter(dataAdapter);
            mSpArn.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long rowId) {
                    String selection = (String) parent.getItemAtPosition(position);

                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).equals(selection)) {
                            mPosArn = i;
                            mPosLocalArn = i;
                            break;
                        }
                    }

                }
            });
            if (mPosLocalArn == -1) {
                mSpArn.setText(dataAdapter.getItem(0).toString(), false);
            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    private void SetData() {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        try {
            ArrayList<JSONObject> list = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(AppApplication.AUM_REPORT);
            setAUMDATA(jsonObject, list);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

    }

    private void setAUMDATA(JSONObject jsonObject, ArrayList<JSONObject> list) {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        if (jsonObject.optInt("status") == 0) {
            JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
            JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
            if (jsonArray.length() > 0) {
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                mLinerMain.setVisibility(View.VISIBLE);
                llAumCard.setVisibility(View.VISIBLE);
                mTvNothing.setVisibility(View.GONE);

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double AUM = jsonObjectSummary.optDouble("AUM");
                String strAUM = format.format(AUM);
                mTvTotal.setText(strAUM);

                double Debt = jsonObjectSummary.optDouble("Debt");
                String strDebt = format.format(Debt);
                mTvDEbt.setText(strDebt);

                double Equity = jsonObjectSummary.optDouble("Equity");
                String strEquity = format.format(Equity);
                mTvEquity.setText(strEquity);


                double liqAltra = jsonObjectSummary.optDouble("Liquid and Ultra Short");
                String strliqAltra = format.format(liqAltra);
                mTvLiqUltra.setText(strliqAltra);

                double Other = jsonObjectSummary.optDouble("Other");
                String strOther = format.format(Other);
                mTvOther.setText(strOther);

                double Arbitrage = jsonObjectSummary.optDouble("Arbitrage");
                String strArbitrage = format.format(Arbitrage);
                mTvArbi.setText(strArbitrage);

                double Hybrid = jsonObjectSummary.optDouble("Hybrid");
                String strHybrid = format.format(Hybrid);
                tvHybrid.setText(strHybrid);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }
                mAumAdapter.updateList(list, "data_by_fund");
            } else {
                mAumAdapter.updateList(list, "data_by_fund");
                llAumCard.setVisibility(View.GONE);
                mTvNothing.setVisibility(View.VISIBLE);
            }


        }
    }

    private void getAum() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        JSONArray jsonArray = new JSONArray();
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_AUM_REPORT
                + "filters=" + jsonArray.toString() + "&groupBy=1001&orderBy=AUM&orderByDesc=true"
                + "&pageSize=100" +
                "&currentPage=1";

        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                AppApplication.AUM_REPORT = response;
                SetData();
            }
        });

    }

    private void filterDialog() {
        dialogBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View dialogView = inflater.inflate(R.layout.dialog_aum_filter, null);
        dialogBuilder.setView(dialogView);
        alertDialog = dialogBuilder.create();
        Button reset, apply;
        ImageView ivCloseDialog;
        reset = (Button) dialogView.findViewById(R.id.tvReset);
        apply = (Button) dialogView.findViewById(R.id.tvApply);
        ivCloseDialog = dialogView.findViewById(R.id.iv_close);
        chip_group = dialogView.findViewById(R.id.chip_group);
        mSpArn = dialogView.findViewById(R.id.spArn);
        spUserType = dialogView.findViewById(R.id.spUserType);
        spCategory = dialogView.findViewById(R.id.spCategory);
        spUser = dialogView.findViewById(R.id.spUser);
        cl_arn = dialogView.findViewById(R.id.cl_arn);
        cl_user_type = dialogView.findViewById(R.id.cl_user_type);
        til_user = dialogView.findViewById(R.id.til_user);


        // error tv
        tvErrorUserType = dialogView.findViewById(R.id.tvError_userType);
        tvErrorUser = dialogView.findViewById(R.id.tvError_user);

        mSpArn.setTag(mSpArn.getKeyListener());
        mSpArn.setKeyListener(null);

//        spUser.setTag(mSpArn.getKeyListener());
        spUser.setThreshold(1);
//        spUser.setKeyListener(null);

        spUser.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                isSelected = spUser.isSelected();
/*                isSelected = spUser.isSelected();
                if (mposLocalUserType ==-1 ){
                    tvErrorUserType.setVisibility(View.VISIBLE);
                    tvErrorUserType.setText("Please choose user type");
                }else*/
                if (charSequence.toString().length() >= 3) {
                    tvErrorUserType.setVisibility(View.GONE);
                    tvErrorUserType.setText("");
                    callUsersAPI(charSequence.toString());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
//                if (mposUserType ==-1 || mposUserType ==0){
//                    tvErrorUserType.setVisibility(View.VISIBLE);
//                    tvErrorUserType.setText("Please choose user type");
//                }else if (editable.toString().length()>=3){
//                    tvErrorUserType.setVisibility(View.GONE);
//                    tvErrorUserType.setText("");
//                    callUsersAPI(editable.toString());
//                }
            }
        });
        spCategory.setTag(spUserType.getKeyListener());
        spCategory.setKeyListener(null);

        spUserType.setTag(spUserType.getKeyListener());
        spUserType.setKeyListener(null);


        reset.setOnClickListener(view -> {
            clearData();
        });
        apply.setOnClickListener(view -> checkValidation());
        ivCloseDialog.setOnClickListener(view -> {
            alertDialog.dismiss();
        });
        alertDialog.setCancelable(true);
        alertDialog.show();

        mPosCat = -1;
        mposUserType = -1;
        mPosArn = -1;
        callUserType();//
        callARN();
        callCategoryType();
        if (!AUM_FILTERED.isEmpty()) {
            setFilterData();
        }

        if (spUserType.getText().toString().equals(""))
            til_user.setVisibility(View.GONE);
        else
            til_user.setVisibility(View.VISIBLE);

    }

    private void setFilterData() {
        try {
            if ((uList != null && !uList.isEmpty()) || (userList != null && !userList.isEmpty())) {
                if (mposLocalUserType != -1) {
                    spUserType.setText(userList.get(mposLocalUserType).toString(), false);
                }
                spUser.setText(currentUser, false);
                if (mPosLocalCat == -1) {
                    spCategory.setText(getString(R.string.all));
                } else {
                    spCategory.setText(mcatLocalList.get(mPosLocalCat).toString(), false);
                }
                if (mPosLocalArn == -1) {
                    mSpArn.setText(getString(R.string.all));
                } else
                    mSpArn.setText(mArnLocalList.get(mPosLocalArn).toString(), false);

                clearError();
//            spCategory.setText();

            }
        } catch (IndexOutOfBoundsException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    private void clearData() {
        spUserType.setText("");
        spUser.setText("");
        spCategory.setText("");
        mSpArn.setText("");
        if (!AUM_FILTERED.isEmpty()) {
            AUM_FILTERED = "";
            AUM_FILTER = "";
        }
        alertDialog.dismiss();
        SetData();

    }

    /**
     * url https://spvithlani.investwell.app/webapi/auth/getLevelUsersFiltered?filters=[{"nameLike":"malay"}]&levelNo=100
     * &componentForLoader={"componentName":"getLevelUser"}&pageSize=100&currentPage=1&selectedUser={}
     *
     * @param nameLink
     */
    private void callUsersAPI(String nameLink) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = "", levelNo = "";
        try {
            JSONObject componentObject = new JSONObject();
            JSONObject nameLinkObject = new JSONObject();
            componentObject.put("componentName", "getLevelUser");
            nameLinkObject.put("nameLike", nameLink);
            if (mposLocalUserType != -1) {
                levelNo = mJsonUserTypeList.get(mposLocalUserType).optString("levelNo");
            } else
                levelNo = mJsonUserTypeList.get(mposLocalUserType).optString("levelNo");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.USERS_FILTERED
                    + "filters=[" + nameLinkObject + "]" + "&levelNo=" + levelNo + "&pageSize=100&currentPage=1";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (IndexOutOfBoundsException ignored) {

        } catch (Exception e) {

        }

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mJsonUserList = new ArrayList<>();
                uList = new ArrayList<>();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            uList.add(jsonObject1.optString("name"));
                            mJsonUserList.add(jsonObject1);
                        }
                    } else if (jsonObject.optInt("status") == -1) {
                        if (mBrokerActivity != null) {
                            Toast.makeText(mBrokerActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mMainActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (RuntimeException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                } catch (Exception e) {
                } finally {
                    if (!mJsonUserList.isEmpty()) {
                        setUserList(uList);
                        tvErrorUser.setVisibility(View.GONE);
                        tvErrorUser.setText("");
                    } else {
                        tvErrorUser.setVisibility(View.VISIBLE);
                        tvErrorUser.setText("User Not found");
                    }
                }
            }
        });

    }

    private void setUserList(List<String> list) {
        try {
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(requireContext(), R.layout.spinner_dropdown, list);
            spUser.setAdapter(dataAdapter);
            spUser.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long rowId) {
                    String selection = (String) parent.getItemAtPosition(position);

                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).equals(selection)) {
                            mPosUser = i;
                            mPosLocalUser = i;
                            isSelected = true;
                            currentUser = selection;
                            break;
                        }
                    }

                }
            });

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }

    private void closeKeyboard() {
        InputMethodManager imm = (InputMethodManager) requireActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isAcceptingText()) {
            imm.hideSoftInputFromWindow(spUser.getRootView().getWindowToken(), 0);
        }
    }

    private void checkValidation() {

        if (currentUser.equalsIgnoreCase(spUser.getText().toString())) {
            isSelected = true;
        }
        if (!isSelected) {
            if (spUser.getText().toString().equals("")) {
                currentUser = "";
                clearError();
                closeKeyboard();
                alertDialog.dismiss();
                callApplyFilterAPI();
            } else {
                AUM_FILTER = "Y";
                tvErrorUserType.setVisibility(View.GONE);
                tvErrorUser.setVisibility(View.VISIBLE);
                tvErrorUserType.setText("");
                tvErrorUser.setText(R.string.please_choose_user);
            }
        } else {
            clearError();
            closeKeyboard();
            alertDialog.dismiss();
            callApplyFilterAPI();
        }

    }


    private void callApplyFilterAPI() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        if (currentUser.equalsIgnoreCase("")) {
            AUM_FILTER = "N";
        } else {
            AUM_FILTER = "Y";
        }
        String url = "", uid = "";
        try {
            JSONArray filtersArray = new JSONArray();
            JSONObject filter1 = new JSONObject();
            JSONObject filter2 = new JSONObject();
            JSONObject filter3 = new JSONObject();
            JSONObject selectedUser = new JSONObject();
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "aumReport");


            if (mJsonARNList != null && mJsonARNList.size() != 0) {
                if (mPosArn <= 0) {
                    filter1.put("arnid", "");
                } else {
                    ARNID = "" + mJsonARNList.get(mPosArn - 1).optString("arnid");
                    filter1.put("arnid", mJsonARNList.get(mPosArn - 1).optString("arnid"));
                }
            } else {
                filter1.put("arnid", "");
            }

            if (mJsonCategoryList != null && mJsonCategoryList.size() != 0) {
                if (mPosCat <= 0) {
                    filter2.put("category", "");
                } else {
                    String categoryValue = mJsonCategoryList.get(mPosCat - 1).optString("objective");
                    String encodedFilters = URLEncoder.encode(categoryValue, "UTF-8");
                    CATEGOTY = encodedFilters; //"" + mJsonCategoryList.get(mPosCat - 1).optString("objective");
                    filter2.put("category", encodedFilters);
                }
            } else {
                filter2.put("category", "");
            }

            filter3.put("selectedUser", selectedUser);
            filtersArray.put(filter1);
            filtersArray.put(filter2);
            if (mJsonUserList != null && mJsonUserList.size() != 0) {
                int pos;// when user select any user then it addtextonchanged listener again call
                if (mJsonUserList.size() == 1)
                    pos = 0;
                else
                    pos = mPosUser;
                selectedUser.put("uid", mJsonUserList.get(pos).optString("uid").toString());
                selectedUser.put("name", mJsonUserList.get(pos).optString("name").toString());
                selectedUser.put("username", mJsonUserList.get(pos).optString("username").toString());
                selectedUser.put("userBusinessCode", mJsonUserList.get(pos).optString("userBusinessCode").toString());
                selectedUser.put("levelid", mJsonUserList.get(pos).optString("levelid").toString());
                selectedUser.put("email", mJsonUserList.get(pos).optString("email").toString());
                selectedUser.put("phone", mJsonUserList.get(pos).optString("phone").toString());
                selectedUser.put("levelNo", mJsonUserList.get(pos).optString("levelNo").toString());
                selectedUser.put("brokerUid", mJsonUserList.get(pos).optString("brokerUid").toString());
                selectedUser.put("pan", mJsonUserList.get(pos).optString("pan").toString());
                selectedUser.put("levelName", mJsonUserList.get(pos).optString("name").toString());
                selectedUser.put("selectIndex", 1);
                selectedUser.put("index", 1);
                filtersArray.put(filter3);
            }


//            filtersArray2.put(filter3);
            AppApplication.AUM_FILTER1 = filter1;
            AppApplication.AUM_FILTER2 = filter2;
            AppApplication.AUM_FILTER3 = filter3;


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_AUM_REPORT
                    + "orderBy=name&orderByDesc=false" + "&groupBy=1001" + "&filters=" + filtersArray.toString() + "";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (NullPointerException e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {

            @Override
            public void onLoading(boolean isLoading) {
                if (isLoading) {
                    ProgressBarCommon.showDialog(requireActivity());
                } else {
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mJsonFilteredResult = new ArrayList<>();
                ArrayList<JSONObject> resultList = new ArrayList<>();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    AUM_FILTERED = response;

                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        setAUMDATA(jsonObject, resultList);

                        mJsonFilteredResult.add(jsonObjectMain);
                    } else if (jsonObject.optInt("status") == -1) {
                        if (mBrokerActivity != null) {
                            Toast.makeText(mBrokerActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mMainActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {

                } finally {
                    if (alertDialog.isShowing()) {
                        alertDialog.dismiss();
                    }
                }
            }
        });



    }

    private void clearError() {
        tvErrorUserType.setVisibility(View.GONE);
        tvErrorUser.setVisibility(View.GONE);
        tvErrorUserType.setText("");
        tvErrorUser.setText("");
    }


    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                filterDialog();
}
    }

    private void callCategoryType() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }

        /**
         * url should be
         * https://spvithlani.investwell.app/webapi/broker/utilities/getObjectives?columnName=objectiveName&orderBy=objective&orderByDesc=false&componentForLoader={"componentName":"aumReportList"}&selectedUser={}
         */

        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.AUM_REPORT_CATEGORY
                + "columnName=objectiveName&orderBy=objective&orderByDesc=false&";
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onSuccess(@NonNull String response, int statusCode) {
                mJsonCategoryList = new ArrayList<>();
                ArrayList<String> catList = new ArrayList<>();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONArray jsonArray = jsonObject.optJSONArray("result");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            catList.add(jsonObject1.optString("objective"));
                            mJsonCategoryList.add(jsonObject1);
                        }
                    } else if (jsonObject.optInt("status") == -1) {
                        if (mBrokerActivity != null) {
                            Toast.makeText(mBrokerActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(mMainActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {

                } finally {
                    if (mJsonCategoryList.size() > 1)
                        setCatList(catList);
                }
            }
        });


    }

    private void setCatList(final List<String> list) {
        list.add(0,getString(R.string.all_caps));
        mcatLocalList = list;
        try {
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(requireContext(), R.layout.spinner_dropdown, list);
            spCategory.setAdapter(dataAdapter);
            spCategory.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long rowId) {
                    String selection = (String) parent.getItemAtPosition(position);
                    for (int i = 0; i < list.size(); i++) {
                        if (list.get(i).equals(selection)) {
                            mPosCat = i;
                            mPosLocalCat = i;
                            String editableData = spUser.getText().toString();
                            break;
                        }
                    }

                }
            });
            if (mPosLocalCat == -1) {
                spCategory.setText(dataAdapter.getItem(0).toString(), false);
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                e.printStackTrace();
        }
    }
}
