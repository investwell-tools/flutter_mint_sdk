package investwell.client.fragments.SipMining;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.SortData;

/**
 * A simple {@link Fragment} subclass.
 */
public class SipMininigClient extends BaseFragment implements OnItemClickListener {
    private RecyclerView mRecyclerView;
    private ShimmerFrameLayout mShimmerViewContainer;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private AppApplication mApplication;
    private LinearLayout fullScreenShedow, mLinerNoDataFound;
    private RelativeLayout singleShedow;
    private SipMiningAdapter mAdapter;
    private List<JSONObject> list;
    String mStartingDate, mode, mEndDate, type, fundId, schemeId, appId;
    private LinearLayout topCard;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;
    private TextView tvAmount, tvAvgAmount, tvInvestors, tvNoOfSip;
    private JSONObject summaryObject;

    public SipMininigClient() {
        // Required empty public constructor
    }


    @Override
    public void onResume() {
        super.onResume();
/*        if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_sip_mininig_client, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        }
        setUpToolBar();
        mRecyclerView = view.findViewById(R.id.recycleView);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mRecyclerView.setNestedScrollingEnabled(true);
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mAdapter = new SipMiningAdapter(new ArrayList<JSONObject>(), getContext(), "2", this);
        mRecyclerView.setAdapter(mAdapter);
        tvAmount = view.findViewById(R.id.amount);
        tvAvgAmount = view.findViewById(R.id.avg_amount);
        tvInvestors = view.findViewById(R.id.no_of_sip_investors);
        tvNoOfSip = view.findViewById(R.id.no_of_sip);
        topCard = view.findViewById(R.id.top_card);


        getSipMining();
        return view;
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getString(R.string.txt_sip_mining),
                    true, false, false, false, false, false, false);
        }
    }

    private void getSipMining() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        topCard.setVisibility(View.GONE);
        singleShedow.setVisibility(View.GONE);
        fullScreenShedow.setVisibility(View.VISIBLE);

        String url = "";

        try {
            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "sipMining");
            JSONObject investorObject = new JSONObject();
            Bundle bundle = getArguments();

            mStartingDate = bundle.getString("startDate", "");
            mode = bundle.getString("mode", "");
            mEndDate = bundle.getString("endDate", "");
            type = bundle.getString("type", "");
            fundId = bundle.getString("fundId", "");
            schemeId = bundle.getString("schemeId", "");
            JSONArray jsonArray = new JSONArray();
            JSONObject fromObject = new JSONObject();
            fromObject.put("fromDate", mStartingDate);
            jsonArray.put(fromObject);

            JSONObject toDateObject = new JSONObject();
            toDateObject.put("toDate", mEndDate);
            jsonArray.put(toDateObject);
            JSONObject schemeObject = new JSONObject();
            JSONArray schemeArray = new JSONArray();
            schemeObject.put("fundid", fundId);
            schemeObject.put("schid", schemeId);
            schemeArray.put(schemeObject);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_SIP_MINING_SUMMARY + "currentPage=1"  + "&pageSize=1000" + "&orderBy=name" +
                    "&orderByDesc=true" + "&mode=" + mode + "&fromDate=" + mStartingDate + "&toDate=" + mEndDate + "&txnType=" + type + "&groupBy=100"+ "&filters=" + schemeArray;

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {
            System.out.println();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        list = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                summaryObject = jsonObjectMain.optJSONObject("summary");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);
                            topCard.setVisibility(View.VISIBLE);
                            if (list.size() > 0) {
                                mLinerNoDataFound.setVisibility(View.GONE);
                                setDataOnCard(summaryObject);
                                Collections.sort(list, new SortData("noOfSIPs"));
                                Collections.reverse(list);
                                mAdapter.updateList(list);
                            } else {
                                topCard.setVisibility(View.GONE);
                                mLinerNoDataFound.setVisibility(View.VISIBLE);
                                mAdapter.updateList(new ArrayList<JSONObject>());
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);


                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    @Override
    public void onItemClick(int position) {
        JSONObject jsonObject = list.get(position);
        Bundle bundle = new Bundle();
        bundle.putString("fundId", fundId);
        bundle.putString("schemeId", schemeId);
        bundle.putString("startDate", mStartingDate);
        bundle.putString("appId", mStartingDate);
        bundle.putString("endDate", mEndDate);
        bundle.putString("mode", mode);
        bundle.putString("type", type);
        bundle.putString("clientName", jsonObject.optString("name"));
        bundle.putString("appId", jsonObject.optString("appid"));
        bundle.putString("noOfInvestors", jsonObject.optString("investors"));
        bundle.putString("noOfSip", jsonObject.optString("noOfSIPs"));

        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);

        double amount = jsonObject.optDouble("amount");
        double avgAmountPerInvestor = jsonObject.optDouble("avgAmountPerInvestor");


        bundle.putString("averageAmount", numberFormat.format(avgAmountPerInvestor));
        bundle.putString("amount", numberFormat.format(amount));
        mBrokerActivity.displayViewOther(32, bundle);
    }

    private void setDataOnCard(JSONObject summaryObject) {
        topCard.setVisibility(View.VISIBLE);
        int noOfSip = summaryObject.optInt("noOfSIPs");
        int investors = summaryObject.optInt("investors");
        tvNoOfSip.setText(String.format("%02d", noOfSip));
        tvInvestors.setText(String.format("%02d", investors));

        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);

        double amount = summaryObject.optDouble("amount");
        double avgAmountPerInvestor = summaryObject.optDouble("avgAmountPerInvestor");
        tvAmount.setText("" +numberFormat.format(amount));
        tvAvgAmount.setText("" + numberFormat.format(avgAmountPerInvestor));
    }
}
