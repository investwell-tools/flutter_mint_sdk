package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.dividend.FragDividendReport;
import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * Created by Dev on 16/08/2021.
 */

public class DividendReportAdapter extends RecyclerView.Adapter<DividendReportAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private DividendReportAdapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragDividendReport mFragDividendReport;
    private AppSession mSession;

    public DividendReportAdapter(Context context, FragDividendReport fragDividendReport, ArrayList<JSONObject> list, DividendReportAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mFragDividendReport = fragDividendReport;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_dividend_report_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, text1, text2, text3, tvfolio;
        CardView card_view;
        ImageView ivDivDetail;
        View ivThreeUpper;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvfolio = view.findViewById(R.id.tvfolio);
            text1 = view.findViewById(R.id.text1);
            text2 = view.findViewById(R.id.text2);
            text3 = view.findViewById(R.id.text3);
            card_view = view.findViewById(R.id.card_view);
            ivDivDetail = view.findViewById(R.id.ivDivDetail);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObject = mDataList.get(position);

                tvName.setText(jsonObject.optString("scheme"));
                tvfolio.setText(jsonObject.optString("folioNo"));
                text1.setText(String.format("%.2f", jsonObject.optDouble("reinvest")) );
                text2.setText(String.format("%.2f", jsonObject.optDouble("payout")));
                text3.setText(String.format("%.2f", jsonObject.optDouble("tdsAmount")));

                ivDivDetail.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onClick(View v) {
                        Bundle bundle1 = new Bundle();
                        ClientActivity mainActivity = null;
                        if (mContext instanceof ClientActivity) {
                            mainActivity = (ClientActivity) mContext;
                        }
                        bundle1.putString("folioid", jsonObject.optString("folioid"));
                        String schemeId = Utils.getSchemeIdFromAll(jsonObject);
                        bundle1.putString("schid", schemeId);
                        bundle1.putString("appid", jsonObject.optString("appid"));
                        bundle1.putString("fromDate", jsonObject.optString("fromDate"));
                        bundle1.putString("toDate", jsonObject.optString("toDate"));

                        bundle1.putString("isAnimation", "true");
                        if (mainActivity!=null)
                            mainActivity.displayViewOther(72, bundle1);

                    }
                });
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });

        }
    }
    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


}
