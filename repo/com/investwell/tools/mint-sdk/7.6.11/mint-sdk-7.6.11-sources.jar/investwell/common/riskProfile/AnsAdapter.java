package investwell.common.riskProfile;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class AnsAdapter extends RecyclerView.Adapter<AnsAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private AnsAdapter.OnAnswerItemClick listener;

    public AnsAdapter(Context context, ArrayList<JSONObject> list, AnsAdapter.OnAnswerItemClick listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_risk_answer, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    interface OnAnswerItemClick {
        void onAnswerClick(JSONObject mJson, Boolean isClicked);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        MaterialButton mbAnsOptions;

        public ViewHolder(View view) {
            super(view);
            mbAnsOptions = view.findViewById(R.id.mbAnsOptions);
        }


        public void setItem(final int position, final OnAnswerItemClick listener) {
            final JSONObject jsonObject = mDataList.get(position);
            mbAnsOptions.setText(Utils.SchemeNameFormat(jsonObject.optString("option")));

            mbAnsOptions.setOnClickListener(v -> listener.onAnswerClick(jsonObject, true));

        }

    }



    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
