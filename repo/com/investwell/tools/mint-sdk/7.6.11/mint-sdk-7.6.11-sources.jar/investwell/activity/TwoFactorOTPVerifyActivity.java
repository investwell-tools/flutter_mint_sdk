package investwell.activity;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.Extensions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import investwell.admin.activity.AdminActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.common.lock.AppLockOptionActivity;
import investwell.utils.AppSession;
import investwell.utils.BroadcastService;
import investwell.utils.Config;
import investwell.utils.PinEntryView;


public class TwoFactorOTPVerifyActivity extends AppCompatActivity implements View.OnClickListener {
    private ProgressDialog mBar;
    private AppSession mSession;
    private PinEntryView mEtOTP;
    private String verificationId;
    private TextView mTvPhoneNumber, mTvTimer;
    private String mPhoneNumber = "", mToken = "", mEmailAddress = "";
    private RequestQueue requestQueue;
    private String mLoginType = "";
    public String mCallCommingFrom = "login";


    @Override
    public void onDestroy() {
        stopService(new Intent(this, BroadcastService.class));
        super.onDestroy();
    }

    @Override
    public void onStop() {
        try {
            unregisterReceiver(broadcastReceiver);
        } catch (Exception e) {
        }
        super.onStop();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            registerReceiver(broadcastReceiver, new IntentFilter("FBR-IMAGE"), RECEIVER_EXPORTED);
        }else{
            registerReceiver(broadcastReceiver, new IntentFilter("FBR-IMAGE"));
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        unregisterReceiver(broadcastReceiver);
    }


    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateGUI(intent); // or whatever method used to update your GUI fields
        }
    };


    private void updateGUI(Intent intent) {
        if (intent.getExtras() != null) {
            long millisUntilFinished = intent.getLongExtra("countdown", 0);
            String time = convertSecondsToHMmSs(millisUntilFinished / 1000);
            String finalMEssage = getString(R.string.otp_expires_in) + time;
            mTvTimer.setText("" + finalMEssage);
        }
    }

    private String convertSecondsToHMmSs(long seconds) {
        long s = seconds % 60;
        long m = (seconds / 60) % 60;
        return String.format("%02d:%02d", m, s);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        androidx.activity.EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
         if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_two_factor_otp_verification);
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content), (view, insets) -> {
            androidx.core.graphics.Insets systemBars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return new androidx.core.view.WindowInsetsCompat.Builder(insets)
                    .setInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars(), androidx.core.graphics.Insets.NONE)
                    .build();
        });
        if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        Extensions.checkDevice(this);
        mSession = AppSession.getInstance(this);
        findViewById(R.id.ivBack).setOnClickListener(this);
        findViewById(R.id.tvResend).setOnClickListener(this);
        findViewById(R.id.tvLogin).setOnClickListener(this);
        mTvPhoneNumber = findViewById(R.id.tvPhone);
        mTvTimer = findViewById(R.id.tvTimer);
        mEtOTP = findViewById(R.id.etUserId);

        Intent intent = getIntent();
        if (intent != null) {
            mPhoneNumber = intent.getStringExtra("mobile");
            mToken = intent.getStringExtra("token");
            mTvPhoneNumber.setText(mPhoneNumber);
        }
        mEtOTP.requestFocus();
        sendOTP();
        // mEtOTP.setText("123456");
        //   sendVerificationCode("+91" + mPhoneNumber);


    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvLogin) {
                String code = mEtOTP.getText().toString().trim();
                if (code.isEmpty() || code.length() < 6) {
                    Toast.makeText(this, getString(R.string.please_enter_otp), Toast.LENGTH_SHORT).show();
                    return;
                }
                authinticateOTP();
}
else if (v.getId() == R.id.tvResend) {
                stopService(new Intent(this, BroadcastService.class));
                sendOTP();
}
else if (v.getId() == R.id.tvForgot) {
}
else if (v.getId() == R.id.ivBack) {
                finish();
}
    }


    private void sendOTP() {
        final ProgressDialog mBar = ProgressDialog.show(TwoFactorOTPVerifyActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_OTP;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        UtilityKotlin.setRefreshKey(mSession);
                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            AppApplication appApplication = (AppApplication) getApplication();
                            if (jsonObject.optInt("status") == 0) {
                                startService(new Intent(TwoFactorOTPVerifyActivity.this, BroadcastService.class));

                            } else if (jsonObject.optInt("status") == -1) {
                                appApplication.showCommonDailog(TwoFactorOTPVerifyActivity.this, getString(R.string.failed), jsonObject.optString("message"), "message");
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                                e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("selectedUser", Utils.getSelectedUserObject(mSession).toString());
                params.put("token", mToken);
                return params;

            }

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(TwoFactorOTPVerifyActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(TwoFactorOTPVerifyActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void authinticateOTP() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isAcceptingText()) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }

        final ProgressDialog mBar = ProgressDialog.show(TwoFactorOTPVerifyActivity.this, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.AUTHENTICATE_OTP;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        UtilityKotlin.setRefreshKey(mSession);
                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            AppApplication appApplication = (AppApplication) getApplication();
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                if (getString(R.string.subdomain).equals("mint")) {
                                    appApplication.GtmSetUp(jsonObjectMain.optString("levelNo"), jsonObjectMain.optString("name"));
                                }

                                mSession.setUsername(jsonObjectMain.optString("username"));
                                mSession.setName(jsonObjectMain.optString("name"));
                                mSession.setBrokerFullName(jsonObjectMain.optString("name"));

                                mSession.setUid(jsonObjectMain.optString("uid"));
                                mSession.setLead(jsonObjectMain.optString("isLead"));
                                mSession.setUserBrokerDomain(jsonObjectMain.optString("brokerDomain"));
                                mSession.setLoginType(jsonObjectMain.optString("userType"));
                                mSession.setLevelId(jsonObjectMain.optString("levelid"));
                                mSession.setBid(jsonObjectMain.optString("bid"));
                                mSession.setBrokerUID(jsonObjectMain.optString("brokerUid"));
                                mSession.setLowerReportingLevels(jsonObjectMain.optString("lowerReportingLevels"));
                                mSession.setLevelNo(jsonObjectMain.optString("levelNo"));
                                mSession.setReportingLevelName(jsonObjectMain.optString("reportingLevelName"));
                                mSession.setEmail(jsonObjectMain.optString("email"));
                                mSession.setClientPhotoName(jsonObjectMain.optString("profileImage"));
                                mSession.setIsLargeIfa(jsonObjectMain.optInt("isLargeIfa"));
                                appApplication.removedTempData();
                                mSession.setHideXirr(jsonObjectMain.optString("hideXirr"));
                                mSession.setPAN(jsonObjectMain.optString("pan"));
                                mSession.setAppId(jsonObjectMain.optString("appid"));


                                if (jsonObjectMain.optString("allowSOADownload").equals("1")) {
                                    mSession.setHasSoaDownloadEnable(true);
                                } else {
                                    mSession.setHasSoaDownloadEnable(false);
                                }
                                AppApplication.sExchangeType = "";

                                if (jsonObjectMain.optString("txnEnable").equals("1")) {
                                    mSession.setHasTransectionEnable(true);
                                } else {
                                    mSession.setHasTransectionEnable(false);
                                }

                                if (jsonObjectMain.optString("useEdge360").equals("1")) {
                                    mSession.setHasEdge360(true);
                                } else {
                                    mSession.setHasEdge360(false);
                                }

                                if (jsonObjectMain.optString("hideMetrics").equals("1")) {
                                    mSession.setHasBDCardWithStar(true);
                                } else {
                                    mSession.setHasBDCardWithStar(false);
                                }
//                                mSession.setShowBseAuthPopup(jsonObjectMain.optString("showBseAuthPopup").equals("1"));

                                if (jsonObjectMain.optString("bseOpted").equals("1")) {
                                    mSession.setHasBseOpted(true);
                                } else {
                                    mSession.setHasBseOpted(false);
                                }

                                if (jsonObjectMain.optString("nseOpted").equals("1")) {
                                    mSession.setHasNseOpted(true);
                                } else {
                                    mSession.setHasNseOpted(false);
                                }
                                mSession.setHasNse2Opted(jsonObjectMain.optString("nseInvestOpted").equals("1"));

                                if (jsonObjectMain.optString("mfuOpted").equals("1")) {
                                    mSession.setHasMfuOpted(true);
                                } else {
                                    mSession.setHasMfuOpted(false);
                                }

                                if (mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNse2Opted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasMfuOpted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasBseOpted() && mSession.getHasNseOpted()) && !mSession.getHasMfuOpted() && !mSession.getHasNse2Opted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasBseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasNseOpted() && !mSession.getHasNse2Opted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasBseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasNseOpted() && !mSession.getHasMfuOpted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasNseOpted() && mSession.getHasMfuOpted()) && !mSession.getHasBseOpted() && !mSession.getHasNse2Opted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasNseOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasMfuOpted()) {
                                    mSession.setHasMultiExchange(true);
                                } else if ((mSession.getHasMfuOpted() && mSession.getHasNse2Opted()) && !mSession.getHasBseOpted() && !mSession.getHasNseOpted()) {
                                    mSession.setHasMultiExchange(true);
                                } else {
                                    mSession.setHasMultiExchange(false);
                                }
                                // nseInvest can't be default exchange
                                if (!mSession.getHasMultiExchange()){
                                    boolean hasBse = mSession.getHasBseOpted();
                                    boolean hasNse = mSession.getHasNseOpted();
                                    boolean hasMfu = mSession.getHasMfuOpted();
                                    boolean hasNse2 = mSession.getHasNse2Opted();
                                    String exchange = "";
                                    if (hasNse) {
                                        exchange = "1";
                                    } else if (hasBse) {
                                        exchange = "2";
                                    } else if (hasMfu) {
                                        exchange = "3";
                                    } else if (hasNse2) {
                                        exchange = "4";
                                    }
                                    mSession.setExchangeNseBseMfu(exchange);
                                }

                                mSession.setHasOTPVerified(true);

                                mSession.setHasLoging(true);
                                Config.sOncePopupPerLoginSession = false;

                                if (mSession.getHasAppLockEnable()) {
                                    if (mSession.getLoginType().equals("broker")) {
                                        Intent intent = new Intent(getApplicationContext(), BrokerActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                        startActivity(intent);
                                        finish();
                                    } else if (mSession.getLoginType().equals("admin")) {
                                        Intent intent = new Intent(getApplicationContext(), AdminActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                        startActivity(intent);
                                        finish();
                                    } else {
                                        Intent intent = new Intent(getApplicationContext(), ClientActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
                                        startActivity(intent);
                                        finish();
                                    }


                                } else {
                                    Intent intent = new Intent(getApplicationContext(), AppLockOptionActivity.class);
                                    intent.putExtra("type", "set_screen_lock");
                                    intent.putExtra("callFrom", "login");
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);

                                    startActivity(intent);
                                    finish();
                                }


                            } else if (jsonObject.optInt("status") == -1) {
                                appApplication.showCommonDailog(TwoFactorOTPVerifyActivity.this, getString(R.string.failed), jsonObject.optString("message"), "message");
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getApplicationContext(), "");

                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("selectedUser", Utils.getSelectedUserObject(mSession).toString());
                params.put("token", mToken);
                params.put("otp", mEtOTP.getText().toString());
                params.put("rememberMe", "true");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getApplicationContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getApplicationContext());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getApplication();
                    appApplication.showCommonDailog(TwoFactorOTPVerifyActivity.this, getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(TwoFactorOTPVerifyActivity.this);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
