package investwell.charts.mikephil.charting.interfaces.dataprovider;

import investwell.charts.mikephil.charting.data.ScatterData;

public interface ScatterDataProvider extends BarLineScatterCandleBubbleDataProvider {

    ScatterData getScatterData();
}
