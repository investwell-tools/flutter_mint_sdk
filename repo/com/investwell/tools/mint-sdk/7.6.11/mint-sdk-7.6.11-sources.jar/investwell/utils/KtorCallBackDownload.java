package investwell.utils;

import android.net.Uri;

import androidx.annotation.Nullable;

import java.io.File;

public abstract interface KtorCallBackDownload {
    default void onLoading(boolean isLoading){}
    void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode);
    default void onError(String errorMessage,int statusCode){}

}


