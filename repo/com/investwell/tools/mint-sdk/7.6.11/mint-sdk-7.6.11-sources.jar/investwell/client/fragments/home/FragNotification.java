package investwell.client.fragments.home;

import static investwell.utils.UtilityKotlin.hasReAuthTimeNotValid;
import static investwell.utils.UtilityKotlin.showSnackbar;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import investwell.activity.AppApplication;
import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.NotificationAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.CrmBuilder;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;
import investwell.utils.customView.CustomDialog;

public class FragNotification extends BaseFragment implements ToolbarFragment.ToolbarCallback, CustomDialog.DialogBtnCallBack, NotificationAdapter.OnNotificationClick {
    private RecyclerView mNotifyRecycle;
    private AppSession mSession;
    private NotificationAdapter notificationAdapter;
    private ClientActivity mActivity;
    private BrokerActivity mBrokerActivity;
    private View view;
    private String txtNotification="";
    private ToolbarFragment fragToolBar;
    private CustomDialog customDialog;
    private String notificationListStatus="";

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mActivity.setMainVisibility(this, null);
        }else if(context instanceof BrokerActivity){
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mBrokerActivity.setMainVisibility(this, null);
        }
    }

    private View viewNoData;
    private ImageView ivErrorImage;
    private TextView tvErrorMessage;
    private List<JSONObject> notificationList = new ArrayList<>();
    private JSONObject crmNotificationObject = new JSONObject();

    private static final int MAX_SESSION_SIZE = 50;
    private static final int MAX_UI_SIZE = 25;

    @Override
    public void onStop(){
        super.onStop();

        AppApplication.notification = "";
        Intent myIntent = new Intent("FBR-IMAGE");
        myIntent.putExtra("action", AppApplication.notification);
        getActivity().sendBroadcast(myIntent);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_frag_notification, container, false);


        mNotifyRecycle = view.findViewById(R.id.notify_recycle);
        view.findViewById(R.id.viewLine).setVisibility(View.GONE);


        errorContentInitializer(view);
        mNotifyRecycle.setHasFixedSize(true);
        mNotifyRecycle.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        customDialog = new CustomDialog(this);
        notificationAdapter = new NotificationAdapter(this, new ArrayList<JSONObject>());
        mNotifyRecycle.setAdapter(notificationAdapter);

        if (mSession.getNotification().isEmpty()) {
            mNotifyRecycle.setVisibility(View.GONE);
            viewNoData.setVisibility(View.VISIBLE);
        } else {
            mNotifyRecycle.setVisibility(View.VISIBLE);
            viewNoData.setVisibility(View.GONE);
            setRecycleData();
        }
        if (mSession.getAllowedCrm()
                && mSession.getHasLoging()
                && mSession.getLoginType().equalsIgnoreCase("broker")
                && mSession.getClientObject().isEmpty()
        ) {
            checkCrmNotification();
            openNotificationData();
        }
        setUpToolBar();

        return view;
    }

    private void openNotificationData(){
        try {
            Bundle bundle = getArguments();
            if (bundle != null) {
                String data = bundle.getString("data");
                if (!TextUtils.isEmpty(data)) {
                    JSONObject jsonObject = new JSONObject(data);
                    String crmUrl = jsonObject.optString("entityHyperLink", "");
                    boolean isDarkMode =CrmBuilder.isSystemDarkTheme2(requireActivity());
                    if (!TextUtils.isEmpty(crmUrl)){
                        String commonUrl =crmUrl+"?hideSideBar=true&isDarkMode="+ isDarkMode;
                        Intent crmIntent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
                        crmIntent.putExtra("url", commonUrl);
                        crmIntent.putExtra("title", "CRM");
                        crmIntent.putExtra("isCrm", true);
                        requireActivity().startActivity(crmIntent);
                    }
                }
            }
        } catch (Exception ignore) {
        }
    }

    //Error Content Notification
    private void errorContentInitializer(View view) {
        viewNoData = view.findViewById(R.id.content_no_data);
        tvErrorMessage = viewNoData.findViewById(R.id.tv_error_message);
        ivErrorImage = viewNoData.findViewById(R.id.iv_error_image);
        ivErrorImage.setImageResource(R.mipmap.notification_error);
        tvErrorMessage.setText(R.string.notifications_paceholder_txt);
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.toolBar_title_notifications),
                    true, false, false, false, false, false, false);
            fragToolBar.setCallback(this);
        }
    }


    private void showDialog(String msg, boolean showCancelBtn, boolean showDoneBtn) {
        if (showCancelBtn && showDoneBtn) {
            customDialog.showDialog(getActivity(), getResources().getString(R.string.alert_dialog_header_txt),
                    msg,
                    getResources().getString(R.string.dialog_no_mandate_btn_proceed_txt),
                    getResources().getString(R.string.dialog_no_mandate_btn_cancel_txt), true, true);
        } else {
            customDialog.showDialog(getActivity(), getResources().getString(R.string.alert_dialog_header_txt),
                    msg,
                    getResources().getString(R.string.dialog_no_mandate_btn_proceed_txt),
                    getResources().getString(R.string.dialog_no_mandate_btn_cancel_txt), false, true);
        }

    }

    private void setRecycleData() {
        try {
            List<JSONObject> list = getSessionList();
            // mark all as read
            for (JSONObject obj : list) {
                obj.put("isReadNotification", true);
            }
            list = processList(list);
            saveToSession(list);
            updateUI(list);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private String prepareCrmBaseUrl() {
        return "https://" +mSession.getUserBrokerDomain() + mSession.getHostingPath();
    }

    private void checkCrmNotification() {
        if (hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        String url = prepareCrmBaseUrl() + Config.CRM_Notification_LIST +"limit="+MAX_UI_SIZE+"&offset=0&mode=1";

        KtorHelper.requestCall(requireActivity(), mSession, url, ApiRequestType.GET, new JSONObject(), AppHeaderType.AFTER_LOGIN, new KtorCallBack() {
            @Override
            public void onLoading(boolean isLoading) {
                KtorCallBack.super.onLoading(isLoading);
                if (isLoading){
                    ProgressBarCommon.showDialog(requireActivity());
                }else{
                    ProgressBarCommon.dismissDialog();
                }
            }

            @Override
            public void onSuccess(String response, int statusCode) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    int status = jsonObject.optInt("status",-1);
                    if (status==0){
                        JSONArray resultArray = jsonObject.optJSONArray("result");
                        mergeAndStoreNotifications(resultArray);
                    }else{
                     showSnackbar(view, jsonObject.optString("message"));
                    }
                } catch (Exception ignore) {
                }
            }
        });

    }
    private void mergeAndStoreNotifications(JSONArray apiArray) {
        try {
            notificationList = getSessionList();

            // Add API data
            for (int i = 0; i < apiArray.length(); i++) {
                JSONObject obj = apiArray.optJSONObject(i);
                if (obj != null && !obj.optString("title").isEmpty()) {
                    obj.put("isReadNotification", false);
                    notificationList.add(obj);
                }
            }

            notificationList = processList(notificationList);

//            saveToSession(notificationList);
            updateUI(notificationList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<JSONObject> processList(List<JSONObject> list) {
        Map<String, JSONObject> map = new LinkedHashMap<>();

        for (JSONObject obj : list) {
            String id = obj.optString("id");
            String key;

            if (!TextUtils.isEmpty(id) && !"null".equalsIgnoreCase(id)) {
                key = id;
            } else {
                key = obj.optString("title") + "_" +
                        obj.optString("createdAt") + "_" +
                        obj.hashCode();
            }

//            map.putIfAbsent(key, obj); // cleaner
            map.put(key, obj); // cleaner
        }

        List<JSONObject> finalList = new ArrayList<>(map.values());

        //  latest first (recent on top)
        Collections.sort(finalList, (o1, o2) -> {
            long t1 = getTimeMillis(o1.optString("createdAt"));
            long t2 = getTimeMillis(o2.optString("createdAt"));

            return Long.compare(t2, t1); // DESC
        });

        if (finalList.size() > MAX_SESSION_SIZE) {
            finalList = finalList.subList(0, MAX_SESSION_SIZE);
        }

        return finalList;
    }

    private long getTimeMillis(String dateStr) {
        if (TextUtils.isEmpty(dateStr)) return 0;

        try {
            // API format (UTC)
            if (dateStr.contains("T")) {
                SimpleDateFormat apiFormat =
                        new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
                apiFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

                Date date = apiFormat.parse(dateStr);
                return date != null ? date.getTime() : 0;
            }

            // Local format
            SimpleDateFormat localFormat =
                    new SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.ENGLISH);
            localFormat.setLenient(false);
            Date date = localFormat.parse(dateStr);
            return date != null ? date.getTime() : 0;

        } catch (Exception e) {
            return 0;
        }
    }

    private List<JSONObject> getSessionList() throws Exception {
        List<JSONObject> list = new ArrayList<>();
        if (!mSession.getNotification().isEmpty()) {
            JSONArray array = new JSONArray(mSession.getNotification());
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj != null) list.add(obj);
            }
        }
        return list;
    }

    private void saveToSession(List<JSONObject> list) {
        JSONArray array = new JSONArray();
        for (JSONObject obj : list) {
            String source = obj.optString("source", "");
            // Skip if source is CRM
            if (!"crm".equalsIgnoreCase(source) && obj.optBoolean("isReadNotification",false)) {
                array.put(obj);
            }
        }
        mSession.setNotification(array.toString());
    }

    private void updateUI(List<JSONObject> list) {

        List<JSONObject> uiList = list.size() > MAX_UI_SIZE
                ? list.subList(0, MAX_UI_SIZE)
                : list;

        if (uiList.isEmpty()) {
            notificationListStatus = "hide notification";
            mSession.setNotifyIcon("no");
            mNotifyRecycle.setVisibility(View.GONE);
            viewNoData.setVisibility(View.VISIBLE);
        } else {
            notificationListStatus = "show notification";
            mSession.setNotifyIcon("yes");
            mNotifyRecycle.setVisibility(View.VISIBLE);
            viewNoData.setVisibility(View.GONE);
        }

        notificationAdapter.updateList(new ArrayList<>(uiList));
    }
    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                if (mSession.getNotification().isEmpty()) {
                    showDialog(getResources().getString(R.string.alert_empty_notification_header_txt), true, false);
                    txtNotification = "No Operations";

                } else {
                    showDialog(getResources().getString(R.string.alert_dialog_notification_clear_txt), true, true);
                }
}
    }

    @Override
    public void onDialogBtnClick(View view) {
        if (view.getId() == R.id.btDone) {
                if (txtNotification.equalsIgnoreCase("No Operations")) {
                    viewNoData.setVisibility(View.VISIBLE);
                    mNotifyRecycle.setVisibility(View.GONE);

                } else {
                    mSession.setNotification("");
                    mNotifyRecycle.setVisibility(View.GONE);
                    //
                }
}
else if (view.getId() == R.id.btCalcel) {
}
    }

    @Override
    public void OnItem(int position) {

    }

    @Override
    public void OnUrlClick(String url) {
        try {
            Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
            intent.putExtra("url", url);
            intent.putExtra("title", getString(R.string.alert_dialog_notification_header_txt));
            startActivity(intent);
        }catch (Exception ignore){}
    }

    @Override
    public void onItemClick(int position, JSONObject obj) {

        String source = obj.optString("source", "");
        boolean isCrm = isValidString(source) && "crm".equalsIgnoreCase(source);

        String crmUrl = obj.optString("entityHyperLink", "");
        String link = obj.optString("link", "");

        //  CRM Flow
        if (isCrm && isValidString(crmUrl) && mSession.getHasLoging()) {
            boolean isDarkMode = CrmBuilder.isSystemDarkTheme2(requireActivity());
            String finalUrl = crmUrl + "?hideSideBar=true&isDarkMode=" + isDarkMode;
            Intent intent = new Intent(requireActivity(), AppIntoMintWebPortalActivity.class);
            intent.putExtra("url", finalUrl);
            intent.putExtra("title", "CRM");
            intent.putExtra("isCrm", true);
            startActivity(intent);
            return;
        }
        // Normal Link Flow (works for BOTH CRM fallback + non-CRM)
        if (!TextUtils.isEmpty(link) && !"null".equalsIgnoreCase(link)) {
            try {
                link = link.trim();
                if (!link.startsWith("http://") && !link.startsWith("https://")) {
                    link = "http://" + link;
                }
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                startActivity(i);

            } catch (ActivityNotFoundException e) {
                Toast.makeText(requireActivity(), R.string.can_t_open, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean isValidString(String value) {
        return !TextUtils.isEmpty(value) && !"null".equalsIgnoreCase(value);
    }

}
