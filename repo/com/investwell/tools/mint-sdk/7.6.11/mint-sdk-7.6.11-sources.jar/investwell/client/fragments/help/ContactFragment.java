package investwell.client.fragments.help;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import investwell.activity.WebViewActivity;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;


public class ContactFragment extends BaseFragment implements View.OnClickListener {


    private AppSession mSession;
    private String completeAddress = "", appAddressGoogleLink = "", email = "", phone1 = "", phone2 = "", phone3 = "", phone4 = "", aboutUs = "",cDetailsName="",cDetailsPhone="",cDetailsEmail="",cDetailsLevelName="";
    private LinearLayout  llEmailManager, llCallManager, llAddressManager, llWebsiteManager,llContactDetails;
    private TextView  tvCallManagerHeading, tvCallTitleHeading, tvWealthManagerTitleHeading, tvEmailTitleHeading, tvWebsiteTitleHeading, tvAddressTitleHeading,tv_company_name;
    private TextView  tvCall1, tvCall2, tvCall3,tvCall4, tvComma, tvEmailManagerDesc, tvWebManagerDesc, tvAddressManagerDesc,tv_level_name,tv_levelC_name,tv_levelC_phone,tv_levelC_email;
    private ImageView ivWealthEmail, ivWealthCall, ivCallUser;
    private TextView tvAddressLink, tvSlogan;
    private JSONObject mAppJSONObject,mContactJSONObject;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_contact, container, false);
        mSession = AppSession.getInstance(getActivity());
        initializer(view);
        setUpUi();
        setListeners();

        return view;
    }

    private void initializer(View view) {
        llCallManager = view.findViewById(R.id.ll_call_manager);
        tvCall1 = view.findViewById(R.id.tvCall1);
        tvCall2 = view.findViewById(R.id.tvCall2);
        tvCall3 = view.findViewById(R.id.tvCall3);
        tvCall4 = view.findViewById(R.id.tvCall4);
        tvComma = view.findViewById(R.id.tvComma);
        tvSlogan = view.findViewById(R.id.tvSlogan);
        tvSlogan.setText(mSession.getSloganOnLogo());

        // client features
        tv_level_name = view.findViewById(R.id.tv_level_name);
        tv_levelC_name = view.findViewById(R.id.tv_levelC_name);
        tv_levelC_phone = view.findViewById(R.id.tv_levelC_phone);
        tv_levelC_email = view.findViewById(R.id.tv_levelC_email);

        llAddressManager = view.findViewById(R.id.ll_address_manager);
        llEmailManager = view.findViewById(R.id.ll_email_manager);
        llWebsiteManager = view.findViewById(R.id.ll_website_manager);
        tvCallManagerHeading = view.findViewById(R.id.tvCallManagerHeading);
        tvWealthManagerTitleHeading = view.findViewById(R.id.tvWealthManagerTitleHeading);
        tvCallTitleHeading = view.findViewById(R.id.tvCallTitleHeading);
        tvEmailTitleHeading = view.findViewById(R.id.tvEmailTitleHeading);
        tvWebsiteTitleHeading = view.findViewById(R.id.tvWebsiteTitleHeading);
        tvAddressTitleHeading = view.findViewById(R.id.tvAddressTitleHeading);
        tvEmailManagerDesc = view.findViewById(R.id.tvEmailManagerDesc);
        tvWebManagerDesc = view.findViewById(R.id.tvWebManagerDesc);
        tvAddressManagerDesc = view.findViewById(R.id.tvAddressManagerDesc);
        ivWealthCall = view.findViewById(R.id.iv_call_wealth_manager);
        ivWealthEmail = view.findViewById(R.id.iv_mail_wealth_manager_desc);
        tvAddressLink = view.findViewById(R.id.tv_address_link);
        ivCallUser = view.findViewById(R.id.ivIconCall);
        llContactDetails = view.findViewById(R.id.ll_contactDetails);

        // company name
        tv_company_name = view.findViewById(R.id.tv_company_name);


        if (!TextUtils.isEmpty(mSession.getAppInfo())) {
            try {
                mAppJSONObject = new JSONObject(mSession.getAppInfo());
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        } else {
            mAppJSONObject = new JSONObject();
        }
    }


    private void setContactDetails(){
        cDetailsName = mContactJSONObject.optString("name");
        cDetailsEmail = mContactJSONObject.optString("email");
        cDetailsPhone = mContactJSONObject.optString("phone");
        cDetailsLevelName = mContactJSONObject.optString("levelName");
        if (cDetailsEmail.equals("null")){
            cDetailsEmail ="";
        }
        if (cDetailsPhone.equals("null")){
            cDetailsPhone="";
        }
        tv_level_name.setText(""+cDetailsLevelName);
        tv_levelC_name.setText(""+cDetailsName);
        tv_levelC_email.setText(""+cDetailsEmail);
        tv_levelC_phone.setText(""+cDetailsPhone);
    }

    private void setUpUi() {
        // set CompanyName
        if (!mAppJSONObject.optString("compName").equals("null") && !mAppJSONObject.optString("compName").equals("")){
            tv_company_name.setText(""+mAppJSONObject.optString("compName"));
        }else
            tv_company_name.setVisibility(View.GONE);

        //Sub broker data
        if (mAppJSONObject.optJSONObject("userBusinessDetails") != null && mAppJSONObject.optJSONObject("userBusinessDetails").length() != 0) {
            //Phone Sub broker
            if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("phone"))
                    && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("phone").equalsIgnoreCase("null")) {
                phone3 = mAppJSONObject.optJSONObject("userBusinessDetails").optString("phone");
                tvCall1.setText(phone3);
                tvCall1.setVisibility(View.VISIBLE);
                llCallManager.setVisibility(View.VISIBLE);
            } else {
                tvCall1.setVisibility(View.GONE);
                llCallManager.setVisibility(View.GONE);
            }

            //Email sub broker
            if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("email"))) {
                email = mAppJSONObject.optJSONObject("userBusinessDetails").optString("email");

                tvEmailTitleHeading.setText(getResources().getString(R.string.help_email_title_txt));
                if (!email.equalsIgnoreCase("null")) {
                    tvEmailManagerDesc.setText(email);
                    llEmailManager.setVisibility(View.VISIBLE);
                } else {
                    llEmailManager.setVisibility(View.GONE);
                }
            } else {
                llEmailManager.setVisibility(View.GONE);
            }

            //Website
            if (mAppJSONObject.optJSONObject("userBusinessDetails").has("website") && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("website"))) {
                aboutUs = mAppJSONObject.optJSONObject("userBusinessDetails").optString("website");
                tvWebsiteTitleHeading.setText(getResources().getString(R.string.help_website_title_txt));
                if (!aboutUs.equalsIgnoreCase("null")) {
                    tvWebManagerDesc.setText(aboutUs);
                    llWebsiteManager.setVisibility(View.VISIBLE);
                } else {
                    llWebsiteManager.setVisibility(View.GONE);
                }
            } else {
                llWebsiteManager.setVisibility(View.GONE);
            }

            if ((!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) || !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) || !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) ||
                    !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state")) || !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country")))
            ) {

                if ((!mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null"))
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")
                ) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")
                                + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("city") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("state") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("country");
                    }
                } else if (!mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1") + mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("city") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("state") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("country");
                    }
                } else if (!mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("city") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("state") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("country");
                    }
                } else if (mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("city") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("state") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("country");
                    }
                } else if (!mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("state") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("country");
                    }
                } else if (!mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("country"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("city") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("country");
                    }
                } else if (!mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && !mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    if (!TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1")) && !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("city")) &&
                            !TextUtils.isEmpty(mAppJSONObject.optJSONObject("userBusinessDetails").optString("state"))) {
                        completeAddress = mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2") + ", " + mAppJSONObject.optJSONObject("userBusinessDetails").optString("city") + ", " + mAppJSONObject.optString("state");
                    }
                } else if (mAppJSONObject.optJSONObject("userBusinessDetails").optString("address1").equalsIgnoreCase("null") && mAppJSONObject.optJSONObject("userBusinessDetails").optString("address2").equalsIgnoreCase("null")
                        && mAppJSONObject.optJSONObject("userBusinessDetails").optString("city").equalsIgnoreCase("null")
                        && mAppJSONObject.optJSONObject("userBusinessDetails").optString("state").equalsIgnoreCase("null")
                        && mAppJSONObject.optJSONObject("userBusinessDetails").optString("country").equalsIgnoreCase("null")) {
                    completeAddress = "";
                }


                appAddressGoogleLink = mAppJSONObject.optString("googleCoordinates");
                Log.d("gdata:", completeAddress);
                tvAddressTitleHeading.setText(getResources().getString(R.string.help_address_title_txt));
                if (completeAddress.equalsIgnoreCase("null") || TextUtils.isEmpty(completeAddress)) {
                    tvAddressManagerDesc.setVisibility(View.GONE);
                } else {
                    tvAddressManagerDesc.setText(completeAddress);
                    tvAddressManagerDesc.setVisibility(View.VISIBLE);
                }

                llAddressManager.setVisibility(View.VISIBLE);
                tvAddressLink.setVisibility(View.GONE);
            } else {
                llAddressManager.setVisibility(View.GONE);

            }
        } else {
            if (!mSession.getLoginType().equals("broker")) {
                try {
                    mContactJSONObject = new JSONObject(mSession.getContactDetails());
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }else {
                mContactJSONObject = new JSONObject();
            }
           if (mContactJSONObject !=null && mContactJSONObject.length() >0){

               if (!mSession.getLoginType().equals("broker")) {
                   setContactDetails();
                   llContactDetails.setVisibility(View.VISIBLE);
               }else
                   llContactDetails.setVisibility(View.GONE);

           }else {
               llContactDetails.setVisibility(View.GONE);
               if (!TextUtils.isEmpty(mAppJSONObject.optString("telNo1")) || !TextUtils.isEmpty(mAppJSONObject.optString("telNo2")) || !TextUtils.isEmpty(mAppJSONObject.optString("mobileNo1")) || !TextUtils.isEmpty(mAppJSONObject.optString("mobileNo2"))) {
                   llCallManager.setVisibility(View.VISIBLE);
                   phone1 = mAppJSONObject.optString("telNo1");
                   phone2 = mAppJSONObject.optString("telNo2");
                   phone3 = mAppJSONObject.optString("mobileNo1");
                   phone4 = mAppJSONObject.optString("mobileNo2");
                   if (phone1.equals("null")) {
                       phone1 = "";
                   }

                   if (phone2.equals("null")) {
                       phone2 = "";
                   }

                   if (phone3.equals("null")) {
                       phone3 = "";
                   }

                   if (phone4.equals("null")) {
                       phone4 = "";
                   }

                   tvCallManagerHeading.setText(getResources().getString(R.string.help_contact_title));
                   tvCallTitleHeading.setText(getResources().getString(R.string.help_call_txt));

                   tvCall4.setVisibility(View.GONE);
                   tvComma.setVisibility(View.GONE);

                   if (!phone1.equals("") && !phone2.equals("") && !phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone2);
                       tvCall3.setText(" , " + phone3);
                       tvComma.setText(" , ");
                       tvCall4.setText(phone4);
                       tvCall4.setVisibility(View.VISIBLE);
                       tvComma.setVisibility(View.VISIBLE);
                   }else if (phone1.equals("") && !phone2.equals("") && !phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone2);
                       tvCall2.setText(" , " + phone3);
                       tvCall3.setText(" , " + phone4);
                   }else if (!phone1.equals("") && phone2.equals("") && !phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone3);
                       tvCall3.setText(" , " + phone4);
                   }else if (!phone1.equals("") && !phone2.equals("") && phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone2);
                       tvCall3.setText(" , " + phone4);
                   }else if (!phone1.equals("") && !phone2.equals("") && !phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone2);
                       tvCall3.setText(" , " + phone3);
                   }

                   else if (phone1.equals("") && phone2.equals("") && !phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone3);
                       tvCall2.setText(" , " + phone4);
                   }else if (phone1.equals("") && !phone2.equals("") && phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone2);
                       tvCall2.setText(" , " + phone4);
                   }else if (phone1.equals("") && !phone2.equals("") && !phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone2);
                       tvCall2.setText(" , " + phone3);
                   }else if (!phone1.equals("") && phone2.equals("") && phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone2);
                   }else if (!phone1.equals("") && phone2.equals("") && !phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone3);
                   }else if (!phone1.equals("") && !phone2.equals("") && phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone2);
                   }else if (!phone1.equals("") && phone2.equals("") && phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone1);
                       tvCall2.setText(" , " + phone4);
                   }

                   else if (phone1.equals("") && phone2.equals("") && phone3.equals("") && !phone4.equals("")) {
                       tvCall1.setText(phone4);
                   }else if (phone1.equals("") && phone2.equals("") && !phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone3);
                   }else if (phone1.equals("") && !phone2.equals("") && phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone2);
                   }else if (!phone1.equals("") && phone2.equals("") && phone3.equals("") && phone4.equals("")) {
                       tvCall1.setText(phone1);
                   }else{
                       tvCall2.setVisibility(View.GONE);
                   }

                   llCallManager.setVisibility(View.VISIBLE);

               /* if (!TextUtils.isEmpty(phone1) && !TextUtils.isEmpty(phone2) && !TextUtils.isEmpty(phone3) && !TextUtils.isEmpty(phone4)) {
                    tvCall1.setText(phone3);
                    if (!phone1.equalsIgnoreCase("null")) {
                        tvCall2.setText(" , " + phone1);
                        tvCall2.setVisibility(View.VISIBLE);
                    } else {
                        tvCall2.setVisibility(View.GONE);
                    }


                    if (!phone2.equalsIgnoreCase("null")) {
                        tvCall3.setText(" , " + phone2);
                        tvCall3.setVisibility(View.VISIBLE);
                    } else {
                        tvCall3.setVisibility(View.GONE);
                    }

                    if (!phone4.equalsIgnoreCase("null")) {
                        tvCall4.setText(" , " + phone4);
                        tvCall4.setVisibility(View.VISIBLE);
                    } else {
                        tvCall4.setVisibility(View.GONE);
                    }


                } else if (!TextUtils.isEmpty(phone1) && TextUtils.isEmpty(phone3)) {

                    tvCall2.setText(phone1);

                } else if (TextUtils.isEmpty(phone1) && !TextUtils.isEmpty(phone3)) {
                    tvCall1.setText(phone3);
                } else {
                    tvCall2.setVisibility(View.GONE);
                }*/


              /*  if (phone1 == null || TextUtils.isEmpty(phone1)) {
                    tvCall2.setVisibility(View.GONE);
                } else {
                    tvCall2.setVisibility(View.VISIBLE);
                }
                if (phone3 == null || TextUtils.isEmpty(phone3)) {
                    tvCall1.setVisibility(View.GONE);
                } else {
                    tvCall1.setVisibility(View.VISIBLE);
                }
                llCallManager.setVisibility(View.VISIBLE);*/
               } else {
                   llCallManager.setVisibility(View.GONE);
               }

               if (!TextUtils.isEmpty(mAppJSONObject.optString("email"))) {
                   email = mAppJSONObject.optString("email");

                   tvEmailTitleHeading.setText(getResources().getString(R.string.help_email_title_txt));
                   if (!email.equalsIgnoreCase("null")) {
                       tvEmailManagerDesc.setText(email);
                       llEmailManager.setVisibility(View.VISIBLE);
                   } else {
                       llEmailManager.setVisibility(View.GONE);
                   }
               } else {
                   llEmailManager.setVisibility(View.GONE);
               }
           }
            if (!TextUtils.isEmpty(mAppJSONObject.optString("website"))) {
                aboutUs = mAppJSONObject.optString("website");
                tvWebsiteTitleHeading.setText(getResources().getString(R.string.help_website_title_txt));
                if (!aboutUs.equalsIgnoreCase("null")) {
                    tvWebManagerDesc.setText(aboutUs);
                    llWebsiteManager.setVisibility(View.VISIBLE);
                } else {
                    llWebsiteManager.setVisibility(View.GONE);
                }
            } else {
                llWebsiteManager.setVisibility(View.GONE);


            }

            String add1 = "", add2 = "", add3 = "", city = "", state = "", pin = "";
            if ((!TextUtils.isEmpty(mAppJSONObject.optString("address1")) || !TextUtils.isEmpty(mAppJSONObject.optString("address2")) ||
                    !TextUtils.isEmpty(mAppJSONObject.optString("address3")) || !TextUtils.isEmpty(mAppJSONObject.optString("city")) ||
                    !TextUtils.isEmpty(mAppJSONObject.optString("state")) || !TextUtils.isEmpty(mAppJSONObject.optString("pin")))) {


                if (!mAppJSONObject.optString("address1").equalsIgnoreCase("null") &&
                        !mAppJSONObject.optString("address1").equalsIgnoreCase("")) {
                    add1 = mAppJSONObject.optString("address1") + ", ";
                }
                if (!mAppJSONObject.optString("address2").equalsIgnoreCase("null")
                        && !mAppJSONObject.optString("address2").equalsIgnoreCase("")) {
                    add2 = mAppJSONObject.optString("address2") + ", ";
                }
                if (!mAppJSONObject.optString("address3").equalsIgnoreCase("null") &&
                        !mAppJSONObject.optString("address3").equalsIgnoreCase("")) {
                    add3 = mAppJSONObject.optString("address3") + ", ";
                }
                if (!mAppJSONObject.optString("city").equalsIgnoreCase("null") &&
                        !mAppJSONObject.optString("city").equalsIgnoreCase("")) {
                    city = mAppJSONObject.optString("city") + ", ";
                }
                if (!mAppJSONObject.optString("state").equalsIgnoreCase("null") &&
                        !mAppJSONObject.optString("state").equalsIgnoreCase("")) {
                    state = mAppJSONObject.optString("state") + ", ";
                }
                if (!mAppJSONObject.optString("pin").equalsIgnoreCase("null") &&
                        !mAppJSONObject.optString("pin").equalsIgnoreCase("")) {
                    pin = mAppJSONObject.optString("pin");
                }


                String completeAddress = add1 + add2 + add3 + city + state + pin;
                Log.d("gMap:", completeAddress);
                if (completeAddress.endsWith(",")) {
                    completeAddress = completeAddress.substring(0, completeAddress.length() - 1);
                }

                appAddressGoogleLink = mAppJSONObject.optString("googleCoordinates");
                tvAddressTitleHeading.setText(getResources().getString(R.string.help_address_title_txt));
                if (completeAddress.equalsIgnoreCase("null") || TextUtils.isEmpty(completeAddress)) {
                    tvAddressManagerDesc.setVisibility(View.GONE);
                    llAddressManager.setVisibility(View.GONE);
                    tvAddressLink.setVisibility(View.GONE);

                } else {
                    tvAddressManagerDesc.setText(completeAddress);
                    tvAddressManagerDesc.setVisibility(View.VISIBLE);
                    llAddressManager.setVisibility(View.VISIBLE);
                    tvAddressLink.setVisibility(View.VISIBLE);
                }

                if (appAddressGoogleLink.equalsIgnoreCase("null") || TextUtils.isEmpty(appAddressGoogleLink)){
                    tvAddressLink.setVisibility(View.GONE);
                }

            }
        }


    }

    private void setListeners() {
        ivWealthCall.setOnClickListener(this);
        ivWealthEmail.setOnClickListener(this);
        tvAddressLink.setOnClickListener(this);
        tvCall2.setOnClickListener(this);
        tvCall3.setOnClickListener(this);
        tvCall1.setOnClickListener(this);
        tvCall4.setOnClickListener(this);
        llWebsiteManager.setOnClickListener(this);
        llEmailManager.setOnClickListener(this);
        ivCallUser.setOnClickListener(this);

        tv_levelC_phone.setOnClickListener(this);
        tv_levelC_email.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.tv_address_link) {
                onViewDirectionClick();
}
else if (view.getId() == R.id.ll_email_manager) {
                onEmailRowClick();
}
else if (view.getId() == R.id.ll_website_manager) {
                onWebsiteRowClick();
}
else if (view.getId() == R.id.tvCall1) {
                onCallRowClick();
}
else if (view.getId() == R.id.tvCall2) {
                onCallRow2Click();
}
else if (view.getId() == R.id.tvCall3) {
                onCallRow3Click();
}
else if (view.getId() == R.id.tvCall4) {
                onCallRow4Click();
}
else if (view.getId() == R.id.ivIconCall) {
                String call1 = "";
                if (!TextUtils.isEmpty(phone1)) {
                     call1 = phone1;
                }else if (!TextUtils.isEmpty(phone2)) {
                    call1 = phone2;
                }else if (!TextUtils.isEmpty(phone3)) {
                    call1 = phone3;
                }else if (!TextUtils.isEmpty(phone4)) {
                    call1 = phone4;
                }
                if (call1.contains(",")){
                    call1 = call1.replaceAll("[^0-9]","");
                }
                Intent inten = new Intent(Intent.ACTION_DIAL);
                inten.setData(Uri.parse("tel:" + call1));
                startActivity(inten);
}
else if (view.getId() == R.id.tv_levelC_email) {
                String brokerName = "";
                if (!TextUtils.isEmpty(mContactJSONObject.optString("name"))) {
                    brokerName = mContactJSONObject.optString("name");
                }
                String recepientEmail = tv_levelC_email.getText().toString().trim(); // either set to destination email or leave empty
                String subject = "Query From " + brokerName;
                Intent intent = new Intent(Intent.ACTION_SEND);
                String[] strTo = {recepientEmail};
                intent.putExtra(Intent.EXTRA_EMAIL, strTo);
                intent.putExtra(Intent.EXTRA_SUBJECT, subject);
                intent.putExtra(Intent.EXTRA_TEXT, "");
                intent.setType("message/rfc822");
                intent.setPackage("com.google.android.gm");
                startActivity(intent);
}
else if (view.getId() == R.id.tv_levelC_phone) {
                String ph = tv_levelC_phone.getText().toString();
                if (ph.contains("")){
                    ph = ph.replaceAll("[^0-9]","");
                }
                Intent inten = new Intent(Intent.ACTION_DIAL);
                inten.setData(Uri.parse("tel:" + ph));
                startActivity(inten);
}
    }

    private void onViewDirectionClick() {


        String u = "https://www.google.com/maps/search/?api=1&query=";

        if (appAddressGoogleLink.contains("https")) {
            Uri.parse(appAddressGoogleLink);

        } else {
            Uri.parse(u + appAddressGoogleLink);
        }

        Intent intent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(u + appAddressGoogleLink));
        intent.setClassName("com.google.android.apps.maps", "com.google.android.maps.MapsActivity");
        startActivity(intent);

    }



    private void onCallRowClick() {
        String call1 = tvCall1.getText().toString();
        if (call1.contains(",")){
            call1 = call1.replaceAll("[^0-9]","");
        }
        Intent inten = new Intent(Intent.ACTION_DIAL);
        inten.setData(Uri.parse("tel:" + call1));
        startActivity(inten);
    }


    private void onCallRow2Click() {
        String call2 = tvCall2.getText().toString();
        if (call2.contains(",")){
            call2 = call2.replaceAll("[^0-9]","");
        }
        Intent inten = new Intent(Intent.ACTION_DIAL);
        inten.setData(Uri.parse("tel:" + call2));
        startActivity(inten);
    }

    private void onCallRow3Click() {
        String call3 = tvCall3.getText().toString();
        if (call3.contains(",")){
            call3 = call3.replaceAll("[^0-9]","");
        }
        Intent inten = new Intent(Intent.ACTION_DIAL);
        inten.setData(Uri.parse("tel:" + call3));
        startActivity(inten);
    }

    private void onCallRow4Click() {
        String call4 = tvCall4.getText().toString();
        if (call4.contains(",")){
            call4 = call4.replaceAll("[^0-9]","");
        }
        Intent inten = new Intent(Intent.ACTION_DIAL);
        inten.setData(Uri.parse("tel:" + call4));
        startActivity(inten);
    }

    private void onEmailRowClick() {
        String brokerName = "";
        if (!TextUtils.isEmpty(mAppJSONObject.optString("compName"))) {
            brokerName = mAppJSONObject.optString("compName");
        }
        String recepientEmail = email; // either set to destination email or leave empty
        String subject = "Query From " + brokerName;
        Intent intent = new Intent(Intent.ACTION_SEND);
        String[] strTo = {recepientEmail};
        intent.putExtra(Intent.EXTRA_EMAIL, strTo);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, "");
        intent.setType("message/rfc822");
        intent.setPackage("com.google.android.gm");
        startActivity(intent);

    }

    private void onWebsiteRowClick() {
        Intent intent = new Intent(getActivity(), WebViewActivity.class);
        intent.putExtra("title", getString(R.string.our_website));
        intent.putExtra("url", aboutUs);
        startActivity(intent);
    }
}
