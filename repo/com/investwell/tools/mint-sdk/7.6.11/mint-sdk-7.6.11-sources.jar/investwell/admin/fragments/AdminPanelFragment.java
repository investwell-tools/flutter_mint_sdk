package investwell.admin.fragments;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.admin.activity.AdminActivity;
import investwell.admin.adapters.AdminPanelAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Utils;

/**
 * A simple {@link Fragment} subclass.
 */
public class AdminPanelFragment extends BaseFragment {
    private RecyclerView mRecyclerView;
    private ShimmerFrameLayout mShimmerViewContainer;
    private boolean loading;
    private int mCurrentPageNo = 1;
    private LinearLayout fullScreenShedow, mLinerNoDataFound;
    private RelativeLayout singleShedow;
    private AdminPanelAdapter mAdapter;
    private List<JSONObject> list;
    private JSONObject adminObject;
    private AppSession mSession;
    private AppApplication mApplication;
    private AdminActivity mAdminActivity;
    private int pastVisiblesItems, visibleItemCount, totalItemCount;

    public AdminPanelFragment() {
        // Required empty public constructor
    }

    @Override
    public void onResume() {
        super.onResume();
 /*       if (mAdminActivity != null)
            FirebaseAnalytics.getInstance(mAdminActivity).setCurrentScreen(mAdminActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof AdminActivity) {
            this.mAdminActivity = (AdminActivity) context;
            mSession = AppSession.getInstance(mAdminActivity);
            mApplication = (AppApplication) mAdminActivity.getApplication();
            mSession = AppSession.getInstance(mAdminActivity);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_admin_panel_fragmet, container, false);

        setUpToolBar();
        mRecyclerView = view.findViewById(R.id.recycleView);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        fullScreenShedow = view.findViewById(R.id.fullScreenShedow);
        singleShedow = view.findViewById(R.id.singleShedow);
        mRecyclerView.setNestedScrollingEnabled(true);
        mSession = AppSession.getInstance(getActivity());
        mLinerNoDataFound = view.findViewById(R.id.linerNoData);
        mAdapter = new AdminPanelAdapter(new ArrayList<JSONObject>(), getContext());
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {          /*check for scroll down*/
                    visibleItemCount = mLayoutManager.getChildCount();
                    totalItemCount = mLayoutManager.getItemCount();
                    pastVisiblesItems = mLayoutManager.findFirstVisibleItemPosition();

                    if (!loading) {
                        if ((visibleItemCount + pastVisiblesItems) >= totalItemCount) {
                            double value = ((double) totalItemCount) / 20;
                            int page = (int) value;
                            if (mCurrentPageNo == page) {
                                loading = true;
                                mCurrentPageNo = mCurrentPageNo + 1;
                                getAdminData(mCurrentPageNo);
                            }
                        }
                    }
                }
            }
        });

        getAdminData(mCurrentPageNo);
        return view;
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar("Admin",
                    false, false, false, false, false, false, false);
        }
    }

    private void getAdminData(final int pageNo) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";
        mCurrentPageNo = pageNo;
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();
        if (pageNo > 1) {
            singleShedow.setVisibility(View.VISIBLE);
            fullScreenShedow.setVisibility(View.GONE);
        } else {
            singleShedow.setVisibility(View.GONE);
            fullScreenShedow.setVisibility(View.VISIBLE);
        }
        JSONObject componentObject = new JSONObject();
        try {
            componentObject.put("componentName", "ifaOnboarding");
            url = "https://admin.investwell.app/webapi/admin/users/getUsersWithIfaInfo?activeOnly=true&pageSize=20&currentPage="
                    + pageNo + "&userType=broker"+ "&orderByDesc=true&orderBy=bid" +
                    "&selectedUser="+ Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (JSONException e) {
            if (BuildConfig.DEBUG)
                   e.printStackTrace();
        }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        loading = false;
                        list = new ArrayList<>();
                        if (pageNo > 1) {
                            list.addAll(mAdapter.mDataList);
                        }
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    list.add(jsonObject1);
                                }

                            }
                        } catch (Exception e) {

                        } finally {
                            mShimmerViewContainer.stopShimmer();
                            mShimmerViewContainer.setVisibility(View.GONE);
                            mRecyclerView.setVisibility(View.VISIBLE);

                            if (list.size() > 0) {
                                mLinerNoDataFound.setVisibility(View.GONE);
                                mAdapter.updateList(list);
                            } else {
                                mLinerNoDataFound.setVisibility(View.VISIBLE);
                                mAdapter.updateList(new ArrayList<JSONObject>());
                            }
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        mRecyclerView.setVisibility(View.VISIBLE);

                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(mAdminActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

}
