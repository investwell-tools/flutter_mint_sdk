package investwell.client.fragments.others;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.UtilityKotlin.checkFeaturePermissionsOnOff;
import static investwell.utils.UtilityKotlin.checkFeaturePermissionsOnOffByObject;
import static investwell.utils.UtilityKotlin.constructCartUrl;
import static investwell.utils.UtilityKotlin.loadImageWithAuthentication;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import investwell.activity.AppApplication;
import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.activity.WatchListActivity;
import investwell.client.adapter.DashboardMenuAdapterV2;
import investwell.client.manageProfiles.ManageProfilesHomeActivity;
import investwell.common.allprofiles.BseProfileActivity;
import investwell.common.allprofiles.MfuProfileActivity;
import investwell.common.allprofiles.NseProfileActivity;
import investwell.common.alltransactions.CommonExchangeActivity;
import investwell.common.riskProfile.RiskProfileActivity;
import investwell.common.riskProfile.RiskProfileQuestionnaireClientActivity;
import investwell.mintSdk.MintAppConfiguration;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.GridSpacingItemDecoration;
import investwell.utils.Permissions;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class BottomSheetFragmentClient extends BottomSheetDialogFragment implements View.OnClickListener, DashboardMenuAdapterV2.DashboardMenuListener {
    private DashboardMenuAdapterV2 dashboardMenuAdapter;
    private List<JSONObject> financialToolsList;
    private RecyclerView rvFinancialTools;
    private View view;
    public ImageView ivLogout, ivSetting, mIvProfileImage;
    private TextView tvName;
    private AppSession mSession;
    private ClientActivity mMainActivity;
    private String mRiskProfile = "", mRiskProfileValitUpto = "";
    private String mWhereToNavigate = "";
    JSONObject appConfigObject = null;
    private ArrayList<JSONObject> sectionJSONObjectList;
    private String childCode;
    private ProgressBar pbProfileImage;


    public BottomSheetFragmentClient() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mMainActivity = (ClientActivity) context;
        mSession = AppSession.getInstance(mMainActivity);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_bottom_sheet_dialog, container, false);
        setInitializer();
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        callCheckRiskProfileApi();
    }

    private void setInitializer() {

        mMainActivity.setMainVisibility(this, null);
        financialToolsList = new ArrayList<>();
        rvFinancialTools = view.findViewById(R.id.rv_menus);
        tvName = view.findViewById(R.id.tv_user_name);
        mIvProfileImage = view.findViewById(R.id.iv_profile_image);
        pbProfileImage = view.findViewById(R.id.pbProfileImage);
        ivLogout = view.findViewById(R.id.iv_shut_down);
        ivSetting = view.findViewById(R.id.iv_setting);
        if (MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()){
            ivLogout.setVisibility(View.VISIBLE);
        }else {
            ivLogout.setVisibility(View.GONE);
        }
        if ((mSession.getLoginType().equalsIgnoreCase("broker"))) {
            ivSetting.setVisibility(View.GONE);
            ivLogout.setVisibility(View.GONE);
        } else {
            ivSetting.setVisibility(View.VISIBLE);
            if (MintAppConfiguration.INSTANCE.isSDKLogOutButtonEnable()){
                ivLogout.setVisibility(View.VISIBLE);
            }else {
                ivLogout.setVisibility(View.GONE);
            }
        }

        tvName.setText(!TextUtils.isEmpty(mSession.getPersonName()) ? mSession.getPersonName() : "");
        view.findViewById(R.id.iv_shut_down).setOnClickListener(this);
        view.findViewById(R.id.iv_setting).setOnClickListener(this);
        view.findViewById(R.id.ll_name).setOnClickListener(this);
        view.findViewById(R.id.ll_name).setContentDescription(
                "Hello. " + tvName.getText().toString() + "... For Profile Details"
        );
        mIvProfileImage.setOnClickListener(this);

        if (!mSession.getClientPhotoName().isEmpty() && !mSession.getClientPhotoName().equals("null")) {
            loadImageWithAuthentication(requireContext(), mSession, mIvProfileImage, pbProfileImage, false);
        } else {
            mIvProfileImage.setImageResource(R.mipmap.profileplaceholder);
        }


        try {
            if (!mSession.getAppInfo().isEmpty())
                appConfigObject = new JSONObject(mSession.getAppInfo());
            // appConfigObject.put("layout", "3");
        } catch (JSONException e) {
            appConfigObject = new JSONObject();
            // Log.d("mint", e.getLocalizedMessage());
        }
        setDashboardMenuAdapter();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.iv_shut_down) {
                mMainActivity.showLogOutAlert();
                dismiss();
}
else if (v.getId() == R.id.iv_setting) {
                mMainActivity.displayViewOther(62, null);
}
else if (v.getId() == R.id.iv_profile_image) {
}
else if (v.getId() == R.id.ll_name) {
                mMainActivity.displayViewOther(65, new Bundle());
                dismiss();
}
    }

    @Override
    public void onToolsClick(String menuId) {
        Bundle bundle = new Bundle();
        String exchange = Utils.getSelectedExchange(mSession);
        if (menuId.equalsIgnoreCase("newInvestment")) {
            Intent intent = null;
            switch (exchange) {
                case "0":
                    Toast.makeText(mMainActivity, "Profile Creation not allowed. Please contact Administrator", Toast.LENGTH_SHORT).show();
                    break;
                case "1":
                    if (mSession.getLead().equalsIgnoreCase("1")) {
                        mMainActivity.callClientInfoApi(true, false);
                    } else {
                        bundle = new Bundle();
                        intent = new Intent(getActivity(), NseProfileActivity.class);
                        bundle.putString("type", "investmentProfile");
                        bundle.putString("transactionRoute", "clientHome");
                        bundle.putString("toolbarTitle", "clientHome");
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }

                    break;
                case "2":
                    if (mSession.getLead().equalsIgnoreCase("1")) {
                        mMainActivity.callClientInfoApi(true, false);
                    } else {
                        bundle = new Bundle();
                        intent = new Intent(getActivity(), BseProfileActivity.class);
                        bundle.putString("type", "investmentProfile");
                        bundle.putString("transactionRoute", "clientHome");
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                    break;
                case "4":
                    if (mSession.getLead().equalsIgnoreCase("1")) {
                        mMainActivity.callClientInfoApi(true,false);
                    } else {
                        bundle = new Bundle();
                        intent = new Intent(getActivity(), BseProfileActivity.class);
                        bundle.putString("type", "investmentProfile");
                        bundle.putBoolean("nse2", true);
                        bundle.putString("transactionRoute", "clientHome");
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                    break;
                case "3":
                    if (mSession.getLead().equalsIgnoreCase("1")) {
                        mMainActivity.callClientInfoApi(true, false);
                    } else {
                        bundle = new Bundle();
                        intent = new Intent(getActivity(), MfuProfileActivity.class);
                        bundle.putString("type", "investmentProfile");
                        bundle.putString("transactionRoute", "clientHome");
                        intent.putExtras(bundle);
                        startActivity(intent);

                    }
                    break;
            }
        } else if (menuId.equalsIgnoreCase("managedProfile")) {
            if(mSession.getHasMultiExchange()){
                Intent intent = new Intent(getActivity(), CommonExchangeActivity.class);
                intent.putExtra("type", "manageProfile");
                startActivity(intent);
            }
            else {
                Intent intent = new Intent(getActivity(), ManageProfilesHomeActivity.class);
                startActivity(intent);
            }
        } else if (menuId.equalsIgnoreCase("myJourney")) {
            bundle.putString("call_from", "client_menu");
            mMainActivity.displayViewOther(82, bundle);
        } else if (menuId.equalsIgnoreCase("myorder")) {
            boolean isViewEnableNse = checkFeaturePermissionsOnOff(mSession, "feature1020", Permissions.VIEW);
            boolean isViewEnableBSe = checkFeaturePermissionsOnOff(mSession, "feature1023", Permissions.VIEW);
            boolean isViewEnableMfu = checkFeaturePermissionsOnOff(mSession, "feature1026", Permissions.VIEW);
            boolean isViewEnableNSEInvest = checkFeaturePermissionsOnOff(mSession, "feature1052", Permissions.VIEW);

            int trueCount = (isViewEnableNse ? 1 : 0) + (isViewEnableBSe ? 1 : 0) + (isViewEnableMfu ? 1 : 0) + (isViewEnableNSEInvest ? 1 : 0);
            if (mSession.getHasMultiExchange()) {
                if (trueCount == 1) {
                    if (isViewEnableNse) {
                        AppApplication.sExchangeType = "1";
                    } else if (isViewEnableBSe) {
                        AppApplication.sExchangeType = "2";
                    } else if (isViewEnableMfu){
                        AppApplication.sExchangeType = "3";
                    } else if (isViewEnableNSEInvest){
                        AppApplication.sExchangeType = "4";
                    }else {

                    }
                    mMainActivity.displayViewOther(35, bundle);
                } else {
                    bundle.putString("comefrom", "myorderClient");
                    mMainActivity.displayViewOther(76, bundle);
                }
            } else {
                mMainActivity.displayViewOther(35, bundle);
            }
        } else if (menuId.equalsIgnoreCase("feature1005")) {
            mMainActivity.displayViewOther(36, bundle);
        } else if (menuId.equalsIgnoreCase("feature1007")) {
            mMainActivity.displayViewOther(49, bundle);
        } else if (menuId.equalsIgnoreCase("feature1014")) {
            mMainActivity.displayViewOther(17, bundle);
        } else if (menuId.equalsIgnoreCase("feature1015")) {
            mMainActivity.displayViewOther(20, bundle);
        } else if (menuId.equalsIgnoreCase("feature1045")) {
            startActivity(new Intent(mMainActivity, WatchListActivity.class));
        } else if (menuId.equalsIgnoreCase("ELSS")) {
            mMainActivity.displayViewOther(73, bundle);
        } else if (menuId.equalsIgnoreCase("feature3")) {
            bundle.putString("call_from", "client_menu");
            mMainActivity.displayViewOther(14, bundle);
        } else if (menuId.equalsIgnoreCase("feature1010")) {
            //   mMainActivity.displayViewOther(35, bundle);
            if (mWhereToNavigate.equalsIgnoreCase("rp")) {
                bundle.putString("riskProfile", mRiskProfile);
                bundle.putString("validUpto", mRiskProfileValitUpto);
                startActivity(new Intent(mMainActivity, RiskProfileActivity.class).putExtras(bundle));
            } else {
                startActivity(new Intent(mMainActivity, RiskProfileQuestionnaireClientActivity.class));
            }
        } else if (menuId.equalsIgnoreCase("feature1004")) {
            mMainActivity.displayViewOther(21, bundle);
        } else if (menuId.equalsIgnoreCase("feature1027")) {
            bundle.putString("call_from", "client_menu");
            String levelNo = "";
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            } else {
                levelNo = mSession.getLevelNo();
            }
            if (levelNo.equals("98")) mMainActivity.displayViewOther(70, bundle);
            if (levelNo.equals("100")) mMainActivity.displayViewOther(71, bundle);
        } else if (menuId.equalsIgnoreCase("MyDocument")) {
            mMainActivity.displayViewOther(79, bundle);
        } else if (menuId.equalsIgnoreCase("feature1047")) {
            mMainActivity.displayViewOther(92, bundle);
        } else if (menuId.equalsIgnoreCase("cart")) {


            boolean isViewEnableMfu = checkFeaturePermissionsOnOff(mSession, "feature1048", Permissions.VIEW);
            boolean isViewEnableNSEInvest = checkFeaturePermissionsOnOff(mSession, "feature1053", Permissions.VIEW);
            boolean isViewEnableBSE = checkFeaturePermissionsOnOff(mSession, "feature1043", Permissions.VIEW) && mSession.getShowBseAuthPopup();

            int trueCount = (isViewEnableMfu ? 1 : 0) + (isViewEnableNSEInvest ? 1 : 0) + (isViewEnableBSE ? 1 : 0);
            if (mSession.getHasMultiExchange()) {
                if (trueCount == 1) {
                    if (isViewEnableMfu)
                        AppApplication.sExchangeType = "3";
                    else if (isViewEnableBSE)
                        AppApplication.sExchangeType = "2";
                    else if (isViewEnableNSEInvest)
                        AppApplication.sExchangeType = "4";

                    Intent intent = new Intent(mMainActivity, AppIntoMintWebPortalActivity.class);
                    intent.putExtra("url", constructCartUrl(mSession));
                    intent.putExtra("isPopup", true);
                    intent.putExtra("comeFrom", "clientHome");
                    startActivity(intent);
                } else {
                    bundle.putString("comefrom", "cart");
                    mMainActivity.displayViewOther(76, bundle);
                }
            } else {
                Intent intent = new Intent(mMainActivity, AppIntoMintWebPortalActivity.class);
                intent.putExtra("url", constructCartUrl(mSession));
                intent.putExtra("isPopup", true);
                intent.putExtra("comeFrom", "clientHome");
                startActivity(intent);

            }
        }

    }

    @Override
    public void onToolsPosClick(int pos) {

    }

    /*******************************************
     * Method used to set dynamic financial items
     *******************************************/

    private void setDashboardMenuAdapter() {
        dashboardMenuAdapter = new DashboardMenuAdapterV2(mMainActivity, new ArrayList<>(), this);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mMainActivity, 3);

        rvFinancialTools.setLayoutManager(gridLayoutManager);
        rvFinancialTools.addItemDecoration(new GridSpacingItemDecoration(3, dpToPx(0), true));
        rvFinancialTools.setNestedScrollingEnabled(false);
        rvFinancialTools.setAdapter(dashboardMenuAdapter);
        commonMenuValidation();
    }

    /****************************************
     * Converting dp to pixel
     ****************************************/
    private int dpToPx(int dp) {
        Resources r = getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    private void commonMenuValidation() {
        try {
            List<JSONObject> firstFilterMenu = new ArrayList();
            var defaultAllMenu = UtilityKotlin.defaultClientMenus(requireContext());

            String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession, AppApplication.TMP_ALLOWED_FEATURED);
            JSONObject allowedFeatureObj = new JSONObject(allowedFeatured);
            JSONArray tempJsonArray = allowedFeatureObj.optJSONArray("data");


            for (int d = 0; d < defaultAllMenu.size(); d++) {
                JSONObject menuObject = defaultAllMenu.get(d);
                checkAndValidate(menuObject, tempJsonArray, firstFilterMenu);
            }


            if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("3"))) {
                ArrayList<JSONObject> finalFilterList = setMenuListLayout3(firstFilterMenu);
                dashboardMenuAdapter.updateList(finalFilterList);
            } else if ((!TextUtils.isEmpty(appConfigObject.optString("layout")) && appConfigObject.optString("layout").equalsIgnoreCase("5"))) {
                ArrayList<JSONObject> finalFilterList = setMenuListLayout5(firstFilterMenu);
                dashboardMenuAdapter.updateList(finalFilterList);
            } else {
                dashboardMenuAdapter.updateList(firstFilterMenu);
            }


        } catch (JSONException ignored) {

        }
    }

    private void checkAndValidate(JSONObject menuObject, JSONArray tempJsonArray, List<JSONObject> firstFilterMenu) {
        try {
            String childCode = menuObject.optString("ChildCode");
            boolean isElssFound = false;
            for (int i = 0; i < tempJsonArray.length(); i++) {
                JSONObject jsonObject = tempJsonArray.optJSONObject(i);
//
                // for new investment
                if (childCode.equalsIgnoreCase("newInvestment")) {
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1017", Permissions.VIEW) && mSession.getHasTransectionEnable() && mSession.getExchangeNseBseMfu().equalsIgnoreCase("1")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1017")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1021", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("2")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1021")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1024", Permissions.VIEW) && mSession.getHasTransectionEnable() && mSession.getExchangeNseBseMfu().equalsIgnoreCase("3")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1024")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1042", Permissions.VIEW) && mSession.getHasTransectionEnable() && mSession.getExchangeNseBseMfu().equalsIgnoreCase("4")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1042")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("managedProfile")) {
                    // for profile
                    // feature1041
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1028", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("1")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1028")).optString("label"));
                        firstFilterMenu.add(menuObject);

                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1032", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("2")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1032")).optString("label"));
                        firstFilterMenu.add(menuObject);

                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1033", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("3")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1033")).optString("label"));
                        firstFilterMenu.add(menuObject);

                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1041", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("4")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1041")).optString("label"));
                        firstFilterMenu.add(menuObject);

                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("MyJourney")) {
                    // MyJourney
                    firstFilterMenu.add(menuObject);
                    break;
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("myorder")) {
                    // my order
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1020", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("1")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1020")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1023", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("2")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1023")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    } else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1026", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("3")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1026")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1052", Permissions.VIEW) && mSession.getExchangeNseBseMfu().equalsIgnoreCase("4")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1052")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                    //feature1052

                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1005")) {
                    // My SIP
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1005", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1005")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }

                }else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1007")) {
                    // My Goal
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1007", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1007")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1014")) {
                    // Capital Gain Realized
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1014", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1014")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1015")) {
                    // Capital gain unrealized
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1015", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1015")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1045")) {
                    // Watchlist
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1045", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1045")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("ELSS")) {
                    // ELSS
                    if (jsonObject.has("feature84")) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature84")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        isElssFound = true;
                        break;
                    }

                }else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature3")) {
                    // Folio lookup
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1006", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1006")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                }  else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1010")) {
                    // Risk Profile
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1010", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1010")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1004")) {
                    // Insurance
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1004", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1004")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1027")) {
                    // Dividend
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1027", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1027")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                }  else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("MyDocument")) {
                    // My Doc
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1009", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1009")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                } else if (Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("feature1047")) {
                    // Cas Import
                    if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1047", Permissions.VIEW)) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1047")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                }
                else  if (childCode.equalsIgnoreCase("cart")) {
                    boolean hasBse = mSession.getHasBseOpted();
                    boolean hasNse = mSession.getHasNseOpted();
                    boolean hasMfu = mSession.getHasMfuOpted();
                    boolean hasNse2 = mSession.getHasNse2Opted();
                    // cart
                    logD("Ekta Jain Cart checkAndValidate: " + checkFeaturePermissionsOnOffByObject(jsonObject, "feature1048", Permissions.VIEW));
                    if ( checkFeaturePermissionsOnOffByObject(jsonObject, "feature1048", Permissions.VIEW) && hasMfu) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1048")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                    else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1053", Permissions.VIEW) && hasNse2) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1053")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                    else if (checkFeaturePermissionsOnOffByObject(jsonObject, "feature1043", Permissions.VIEW) && mSession.getShowBseAuthPopup() && hasBse ) {
                        menuObject.put("ChildTitle", Objects.requireNonNull(jsonObject.optJSONObject("feature1043")).optString("label"));
                        firstFilterMenu.add(menuObject);
                        break;
                    }
                }

            }

            if (!isElssFound &&  Objects.requireNonNull(menuObject.optString("ChildCode")).equalsIgnoreCase("ELSS")){
                firstFilterMenu.add(menuObject);
            }

            // if child code not found in mint feature list api then direct it
            /*if (!isAdded && !isConditionChecked)
                firstFilterMenu.add(menuObject);*/
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
    }


    private ArrayList<JSONObject> setMenuListLayout3(List<JSONObject> firstFilterMenu) {
        ArrayList<JSONObject> firstMenuList = new ArrayList<>();
        for (int i = 0; i < firstFilterMenu.size(); i++) {
            JSONObject jsonObject = firstFilterMenu.get(i);
            replaceMenuIconForLayout3(jsonObject);
            firstMenuList.add(jsonObject);
        }
        return firstMenuList;
    }

    private void replaceMenuIconForLayout3(JSONObject jsonObject) {
        try {
            if (jsonObject.optString("ChildCode").equalsIgnoreCase("managedProfile")) {
                jsonObject.put("MenuIcon", R.mipmap.home3_investment_profile);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("MyJourney")) {
                jsonObject.put("MenuIcon", R.mipmap.home3_myjourney);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("myorder")) {
                jsonObject.put("MenuIcon", R.mipmap.myorder);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1005")) {
                jsonObject.put("MenuIcon", R.mipmap.mysip);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1010")) {
                jsonObject.put("MenuIcon", R.mipmap.risk_profile);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1014")) {
                jsonObject.put("MenuIcon", R.mipmap.capital_gain);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1015")) {
                jsonObject.put("MenuIcon", R.mipmap.home3_capital_gain_unrealzed);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1045")) {
                jsonObject.put("MenuIcon", R.mipmap.my_watch_list);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("ELSS")) {
                jsonObject.put("MenuIcon", R.mipmap.ic_elss_investment);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature3")) {
                jsonObject.put("MenuIcon", R.mipmap.folio_lookup);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1027")) {
                jsonObject.put("MenuIcon", R.mipmap.dividend_report);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("MyDocument")) {
                jsonObject.put("MenuIcon", R.mipmap.ic_mydoc);
            } else if (jsonObject.optString("ChildCode").equalsIgnoreCase("feature1047")) {
                jsonObject.put("MenuIcon", R.drawable.cas_new_icon);
            }
        } catch (Exception ignored) {

        }
    }

    private ArrayList<JSONObject> setMenuListLayout5(List<JSONObject> firstFilterMenu) {
        ArrayList<JSONObject> finalMenuList = new ArrayList<>();

        JSONArray sectionJSONArray = Utils.getConfigData(mSession).optJSONArray("APPMenuSectionList");
        ArrayList<JSONObject> sectionJSONObjectList = new ArrayList<>();
        try {
            assert sectionJSONArray != null;
            JSONObject jsonObject = sectionJSONArray.optJSONObject(0);
            JSONArray menuArray = jsonObject.optJSONArray("SectionChildList");
            if (jsonObject.optString("Priority").equalsIgnoreCase("99")) {
                if (menuArray != null) {
                    for (int j = 0; j < menuArray.length(); j++) {
                        JSONObject childList = menuArray.optJSONObject(j);
                        sectionJSONObjectList.add(childList);
                    }
                }
            }

            // compare both list
            for (int i = 0; i < firstFilterMenu.size(); i++) {
                JSONObject firstFilterObject = firstFilterMenu.get(i);
                String firstFilterChildCode = firstFilterObject.optString("ChildCode");
                boolean isMatched = false;

                for (int j = 0; j < sectionJSONObjectList.size(); j++) {
                    JSONObject v5CheckObject = sectionJSONObjectList.get(j);
                    String v5ChildCode = v5CheckObject.optString("ChildCode");
                    String v5mTitle = v5CheckObject.optString("ChildTitle");
                    String v5Priority = v5CheckObject.optString("PriorityNo");
                    if (v5ChildCode.equalsIgnoreCase(firstFilterChildCode)) {
                        firstFilterObject.put("ChildTitle", v5mTitle);
                        firstFilterObject.put("PriorityNo", v5Priority);
                        isMatched = true;
                        break;
                    }
                }

                if (isMatched) {
                    finalMenuList.add(firstFilterObject);
                }else{
                    // on place of 100 we can put any number greater that default its size(16)
                    firstFilterObject.put("PriorityNo", i+100);
                    finalMenuList.add(firstFilterObject);
                }
                Collections.sort(finalMenuList, new SortData("PriorityNo"));
            }
        } catch (Exception ignored) {

        }
        return finalMenuList;
    }


    private void callCheckRiskProfileApi() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        if (!TextUtils.isEmpty(mSession.getUserBrokerDomain())) {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CHECK_RISK_PROFILE_CLIENT + "?selectedUser=" + Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        }
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.optInt("status") == 0) {

                    JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                    if (jsonObjectMain != null) {
                        if (!TextUtils.isEmpty(jsonObjectMain.optString("riskProfile")) && (!jsonObjectMain.optString("riskProfile").equalsIgnoreCase("null"))) {
                            mWhereToNavigate = "rp";
                            mRiskProfile = jsonObjectMain.optString("riskProfile");
                            String validUpto = jsonObjectMain.optString("riskProfilerValidityDate");
                            mRiskProfileValitUpto = Utils.formatedDate(validUpto);
                        }
                    }
                }
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                    e.printStackTrace();
            }
        }, volleyError -> {
            if (!isAdded())
                return;
            if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                VolleyError error = new VolleyError(new String(volleyError.networkResponse.data));
                try {
                    JSONObject jsonObject = new JSONObject(error.getMessage());
                    Log.d("error", error.getMessage());
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }) {

            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, requireContext());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, requireActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });


        RequestQueue requestQueue = Volley.newRequestQueue(mMainActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public class SortData implements Comparator {
        String keyname = "";

        public SortData(String df) {
            keyname = df;
        }

        @Override
        public int compare(Object o1, Object o2) {
            String a = "0";
            String b = "0";
            a = ((JSONObject) o1).optString(keyname);
            b = ((JSONObject) o2).optString(keyname);

            int ia = 0, ib = 0;
            int nza = 0, nzb = 0;
            char ca, cb;
            int result;

            while (true) {
                // only count the number of zeroes leading the last number compared
                nza = nzb = 0;

                ca = charAt(a, ia);
                cb = charAt(b, ib);

                // skip over leading spaces or zeros
                while (Character.isSpaceChar(ca) || ca == '0') {
                    if (ca == '0') {
                        nza++;
                    } else {
                        // only count consecutive zeroes
                        nza = 0;
                    }

                    ca = charAt(a, ++ia);
                }

                while (Character.isSpaceChar(cb) || cb == '0') {
                    if (cb == '0') {
                        nzb++;
                    } else {
                        // only count consecutive zeroes
                        nzb = 0;
                    }

                    cb = charAt(b, ++ib);
                }

                // process run of digits
                if (Character.isDigit(ca) && Character.isDigit(cb)) {
                    if ((result = compareRight(a.substring(ia), b.substring(ib))) != 0) {
                        return result;
                    }
                }

                if (ca == 0 && cb == 0) {
                    // The strings compare the same. Perhaps the caller
                    // will want to call strcmp to break the tie.
                    return nza - nzb;
                }

                if (ca < cb) {
                    return -1;
                } else if (ca > cb) {
                    return +1;
                }

                ++ia;
                ++ib;
            }
        }

        private char charAt(String s, int i) {
            if (i >= s.length()) {
                return 0;
            } else {
                return s.charAt(i);
            }
        }

        int compareRight(String a, String b) {
            int bias = 0;
            int ia = 0;
            int ib = 0;

            // The longest run of digits wins. That aside, the greatest
            // value wins, but we can't know that it will until we've scanned
            // both numbers to know that they have the same magnitude, so we
            // remember it in BIAS.
            for (; ; ia++, ib++) {
                char ca = charAt(a, ia);
                char cb = charAt(b, ib);

                if (!Character.isDigit(ca) && !Character.isDigit(cb)) {
                    return bias;
                } else if (!Character.isDigit(ca)) {
                    return -1;
                } else if (!Character.isDigit(cb)) {
                    return +1;
                } else if (ca < cb) {
                    if (bias == 0) {
                        bias = -1;
                    }
                } else if (ca > cb) {
                    if (bias == 0)
                        bias = +1;
                } else if (ca == 0 && cb == 0) {
                    return bias;
                }
            }
        }
    }

}
