package investwell.common.debugmode.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "apiData")
public class ApiDataModel {

    @PrimaryKey(autoGenerate = true)
    private int id;
    @ColumnInfo(name = "apiName")
    private String mApiName;
    @ColumnInfo(name = "apiReq")
    private String mApiReq;
    @ColumnInfo(name = "apiRes")
    private String mApiRes;
    @ColumnInfo(name = "screeName")
    private String screen_name;
    @ColumnInfo(name = "apiDateTime")
    private String mApiDateTime;

    @Ignore
    public ApiDataModel(String mApiName, String mApiReq, String mApiRes, String screen_name, String mApiDateTime, String api_end_point) {
        this.mApiName = mApiName;
        this.mApiReq = mApiReq;
        this.mApiRes = mApiRes;
        this.screen_name = screen_name;
        this.mApiDateTime = mApiDateTime;
        this.api_end_point = api_end_point;
    }

    public ApiDataModel(int id, String mApiName, String mApiReq, String mApiRes, String screen_name, String mApiDateTime, String api_end_point) {
        this.id = id;
        this.mApiName = mApiName;
        this.mApiReq = mApiReq;
        this.mApiRes = mApiRes;
        this.screen_name = screen_name;
        this.mApiDateTime = mApiDateTime;
        this.api_end_point = api_end_point;
    }

    public String getApi_end_point() {
        return api_end_point;
    }

    public void setApi_end_point(String api_end_point) {
        this.api_end_point = api_end_point;
    }

    @ColumnInfo(name = "apiEndPoint")
    private String api_end_point;


    public String getScreen_name() {
        return screen_name;
    }

    public void setScreen_name(String screen_name) {
        this.screen_name = screen_name;
    }

    public String getApiName() {
        return mApiName;
    }

    public void setApiName(String mApiName) {
        this.mApiName = mApiName;
    }

    public String getApiReq() {
        return mApiReq;
    }

    public void setApiReq(String mApiReq) {
        this.mApiReq = mApiReq;
    }

    public String getApiRes() {
        return mApiRes;
    }

    public void setApiRes(String mApiRes) {
        this.mApiRes = mApiRes;
    }

    public String getApiDateTime() {
        return mApiDateTime;
    }

    public void setApiDateTime(String mApiDateTime) {
        this.mApiDateTime = mApiDateTime;
    }



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


}
