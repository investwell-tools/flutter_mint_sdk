package investwell.client.adapter;

import static investwell.utils.UtilityKotlin.isAccessibilityOn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class SoaAdapter extends RecyclerView.Adapter<SoaAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private SoaAdapter.OnItemClickListener listener;

    public SoaAdapter(Context context, ArrayList<JSONObject> list, SoaAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_soa_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvAmount, tvNAV, tvUnits, tvDate, tvBalanceUnit, tvARN;
        CardView card_view;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvAmount = view.findViewById(R.id.tvAmount);
            tvNAV = view.findViewById(R.id.tvNAV);
            tvUnits = view.findViewById(R.id.tvUnits);
            tvDate = view.findViewById(R.id.tvDate);
            tvBalanceUnit = view.findViewById(R.id.tvBalanceUnit);
            card_view = view.findViewById(R.id.card_view);
            tvARN = view.findViewById(R.id.tvARN);
        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);


                final JSONObject jsonObject = mDataList.get(position);
                //tvName.setText(jsonObject.optString("txnType"));
                tvName.setText(Utils.SchemeNameFormat(jsonObject.optString("txnType")));

                double balanceUnits = jsonObject.optDouble("amount");
                String strPurchaseValue = format.format(balanceUnits);
                tvAmount.setText(strPurchaseValue);
                tvNAV.setText(jsonObject.optString("nav"));
                double longValue = jsonObject.optDouble("units");
                String data1 = String.format("%.4f", longValue);
                tvUnits.setText(data1);
                /*if (longValue > 0) {
                    String data1 = String.format("%.4f", longValue);
                    tvUnits.setText(data1);
                } else {
                    tvUnits.setText("0");
                }*/

                tvARN.setText(jsonObject.optString("arnNo"));
                tvDate.setText(Utils.formatedDateddMMMyyyy2(jsonObject.optString("date")));


/*{
"txnid":"151c1af5827f73c3fd122dcb132163e9",
"amount":400000,
"currentNav":11.223,
"currentNavDate":"2019-08-08T18:30:00.000Z",
"nav":12.8401,
"units":31152.428,
"date":"2017-06-12",
"txnType":"NRP",
"type":0,
"nature":"FRESH PURCHASE",
"remarks":"",
"fileOperationid":null,
"checksum":"e714eaa646674d518d64eaa4eeb36d76",
"arnid":"09b547734038d2f5edea90f2823860a9",
"updatedAt":"2019-08-06T09:14:59.000Z",
"seqNo":"10696813216",
"txnNo":"65035630",
"arnNo":"ARN-00001",
"balUnits":31152.428,
"folioId":"73812d055c8e410192eac14a3f144563"
}*/
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            AccessibilityManager accessibilityManager = (AccessibilityManager) mContext.getSystemService(Context.ACCESSIBILITY_SERVICE);

            if (accessibilityManager != null) {
                AccessibilityManager.AccessibilityStateChangeListener accessibilityListener = enabled -> {
                    if (!enabled) {
                        itemView.setOnClickListener(v -> listener.onItemClick(position));
                    }
                };
                accessibilityManager.addAccessibilityStateChangeListener(accessibilityListener);
            }



        }

    }



    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
