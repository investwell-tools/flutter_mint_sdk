package investwell.client.fragments.SipMining;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

public class SipMiningAdapter extends RecyclerView.Adapter<SipMiningAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    Context context;
    private AppSession mSession;
    private String type;
    private OnItemClickListener onItemClickListener;
    NumberFormat numberFormat;

    public SipMiningAdapter(ArrayList<JSONObject> mDataList, Context context, String type, OnItemClickListener onItemClickListener) {
        this.mDataList = mDataList;
        this.context = context;
        mSession = AppSession.getInstance(context);
        this.onItemClickListener = onItemClickListener;
        this.type = type;

        numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.sip_mining_summary_layout, viewGroup, false);
        return new ViewHolder(view, onItemClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
        final JSONObject jsonObject1 = mDataList.get(position);
        if (position == 1) {
            holder.itemView.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
                @Override
                public void onScrollChanged() {
                    Rect rect = new Rect();
                    holder.itemView.getGlobalVisibleRect(rect);
                }
            });
        }
        if (type.equals("1")) {
            holder.summaryCard.setVisibility(View.GONE);
            holder.detailCard.setVisibility(View.VISIBLE);
            holder.cardview_top_name_color.setText(jsonObject1.optString("name"));
            holder.startDate.setText(UtilityKotlin.dateFormat2(jsonObject1.optString("startDate")));
            holder.nextDate.setText(UtilityKotlin.dateFormat2(jsonObject1.optString("ceaseDate")));
            if (jsonObject1.optString("nextDate").equals("null")) {
                holder.nextDateTitle.setText(context.getString(R.string.txt_cease_date));
                holder.nextDate.setText(UtilityKotlin.dateFormat2(jsonObject1.optString("ceaseDate")));
            } else
                holder.nextDate.setText(UtilityKotlin.dateFormat2(jsonObject1.optString("nextDate")));
            holder.endDate.setText(UtilityKotlin.dateFormat2(jsonObject1.optString("endDate")));
            holder.folio.setText(jsonObject1.optString("folioNo"));
            holder.frequency.setText(Utils.setFirstLetterCapital(jsonObject1.optString("frequency")));

           // holder.amount.setText(NumberFormat.getCurrencyInstance(new Locale("en", "in")).format(jsonObject1.optDouble("amount")));
            double amount = jsonObject1.optDouble("amount");
            holder.amount.setText("" +numberFormat.format(amount));

        } else if (type.equals("2")) {
            holder.summaryCard.setVisibility(View.VISIBLE);
            holder.detailCard.setVisibility(View.GONE);
            holder.fundname.setText(jsonObject1.optString("name"));
            holder.no_of_sip_investors.setText(String.format("%02d", jsonObject1.optInt("investors")));
            holder.no_of_sip.setText(String.format("%02d", jsonObject1.optInt("noOfSIPs")));

            double amount = jsonObject1.optDouble("amount");
            double avgAmountPerInvestor = jsonObject1.optDouble("avgAmountPerInvestor");
            holder.amount1.setText("" +numberFormat.format(amount));
            holder.avg_amount.setText("" + numberFormat.format(avgAmountPerInvestor));
        }

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView cardview_top_name_color, amount, startDate, nextDate, frequency, folio, endDate,
                fundname, amount1, avg_amount, no_of_sip, no_of_sip_investors, nextDateTitle;
        private CardView detailCard, summaryCard;
        OnItemClickListener onItemClickListener;

        public ViewHolder(@NonNull View itemView, OnItemClickListener onItemClickListener) {
            super(itemView);
            cardview_top_name_color = itemView.findViewById(R.id.cardview_top_name_color);
            amount = itemView.findViewById(R.id.amount);
            startDate = itemView.findViewById(R.id.start_date);
            nextDate = itemView.findViewById(R.id.next_date);
            frequency = itemView.findViewById(R.id.frequency);
            folio = itemView.findViewById(R.id.folio);
            endDate = itemView.findViewById(R.id.end_date);
            detailCard = itemView.findViewById(R.id.detail_card);
            nextDateTitle = itemView.findViewById(R.id.nextDateTitle);

            summaryCard = itemView.findViewById(R.id.summary_card);
            fundname = itemView.findViewById(R.id.fundname);
            amount1 = itemView.findViewById(R.id.amount1);
            avg_amount = itemView.findViewById(R.id.avg_amount);
            no_of_sip = itemView.findViewById(R.id.no_of_sip);
            no_of_sip_investors = itemView.findViewById(R.id.no_of_sip_investors);
            this.onItemClickListener = onItemClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            onItemClickListener.onItemClick(getAdapterPosition());
        }
    }

}
