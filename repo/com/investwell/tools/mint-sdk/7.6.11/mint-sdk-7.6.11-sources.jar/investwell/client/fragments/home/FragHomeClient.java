package investwell.client.fragments.home;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.UtilityKotlin.getNetworkResponse;
import static investwell.utils.UtilityKotlin.hasReAuthTimeNotValid;
import static investwell.utils.UtilityKotlin.returnHeaderAfterLogin;
import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AlphaAnimation;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.ImageViewCompat;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.tabs.TabLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.activity.WebActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.ElssRetirement;
import investwell.client.adapter.ElssRetirementAdapter;
import investwell.client.adapter.FragViewPagerAdapter;
import investwell.client.adapter.OnElssRetirementClick;
import investwell.client.adapter.OtherInsuranceAdapter;
import investwell.common.allprofiles.BseProfileActivity;
import investwell.common.allprofiles.MfuProfileActivity;
import investwell.common.allprofiles.NseProfileActivity;
import investwell.common.debugmode.DebugActivity;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.common.newCalculator.ui.NewCalculatorActivity;
import investwell.common.newCalculator.domain.model.CalculatorType;
import investwell.common.nfo.NfoActivity;
import investwell.common.onboarding.marketupdate.MarketUpdateActivity;
import investwell.common.permissions.PermissionHandlerViewModel;
import investwell.common.piechart.others.AnimatedPieView;
import investwell.common.topscheme.TopSchemeActivity;
import investwell.utils.ApiRequestType;
import investwell.textview.AppTextView;
import investwell.utils.AppConstants;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.CustomViewPager;
import investwell.utils.KtorCallBack;
import investwell.utils.KtorHelper;
import investwell.utils.ExtensionsKt;
import investwell.utils.ProgressBarCommon;
import investwell.utils.TimeDateUtils;
import investwell.utils.TypeWriter;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import investwell.utils.model.InvestmentRoutes;
import kotlin.Unit;

public class FragHomeClient extends BaseFragment implements View.OnClickListener, OnElssRetirementClick {
    private View view;
    private AppSession mSession;
    private TextView market_value, tvOneDayChangeInPercent, tvGainInPercentage, mTvOneDayChange, mTvGain, mTvUserName, mTvAbsReturn, mTvPurchaseValue, mTvSpecialMsg, mTvAsOndate, mTvOverallGain, mTvOverallGainPercentage;
    public static String values;

    private MaterialButton mTvReadMore;
    private ClientActivity mActivity;
    private RequestQueue requestQueue;
    private AppApplication mAppplication;
    private AnimatedPieView mAnimatedPieView;
    private TextView mTvNothing, tv_notification_badge;

    private final boolean mIsFirstTimeSpinnerCalled = true;
    private LinearLayout mLinerLineChart, mLPairChart;
    private ImageView mIvBack, mGainInfo, mIvContact;
    private RelativeLayout relOneDayChange, relGainLayout;
    private LinearLayout mllCalculator, mLlCross, llUpdation;
    private View mContentSpecialMsgView;
    private String specialMsgUrl = "";
    private final String mIInId = "";
    private Bundle mBundle;
    private final List<InvestmentRoutes> invRouteList = new ArrayList<>();
    private FrameLayout fl_notifications;
    private int mClickCount = 0;
    private ApiDataBase db;
    private TextView mTvFundPick;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ToggleButton mTBExpandCollapse;
    private LinearLayout llExpandCollapse;
    private CardView mCardGraphBody;
    Dialog mPopupMessageDialog;
    String localImagePath = "";

    private RelativeLayout rl_calculators;

    public CustomViewPager mViewPager;
    public FragViewPagerAdapter mPagerAdapter;
    public TabLayout mTabLayout;
    private boolean isNoData = false;
    private CardView mCardViewSummary;
    private CardView cvJounrny;
    private RecyclerView rvOtherInsurance;
    private OtherInsuranceAdapter mOtherInsuranceAdapter;

    private NestedScrollView mLLFullBody;
    private ShimmerFrameLayout mShimmerViewContainer;
    private ProgressBar pbLoaderOnArn;
    private ConstraintLayout clGoal;
    private RecyclerView rvElssRetirement;
    private ElssRetirementAdapter elssRetirementAdapter;
    private List<ElssRetirement> elssRetirementArrayList;
    private View includeNotificationBanner;
    private PermissionHandlerViewModel permissionViewModel;

    private void insertApiData(String url, String req, String res, String dateTime, String endPoint) {
        final ApiDataModel api = new ApiDataModel(
                url,
                req,
                res,
                AppConstants.HOME_WITH,
                dateTime,
                endPoint);


        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        System.out.println("MintLifeCycleLog Clientfragment");
        mActivity.setMainVisibility(this, null);
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            mIvBack.setVisibility(View.VISIBLE);
            mIvContact.setVisibility(View.GONE);
        } else {
            mIvBack.setVisibility(View.GONE);
            mIvContact.setVisibility(View.VISIBLE);
        }

        //  mActivity.getClientBalSummery();
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onResume() {
        super.onResume();
        permissionViewModel.updatePermissionStatus(requireActivity());
/*        if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        if (view == null) view = inflater.inflate(R.layout.frag_client_home, container, false);
        permissionViewModel  = new ViewModelProvider(this).get(PermissionHandlerViewModel.class);

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (mActivity != null) {
            db = ApiDataBase.getInstance(mActivity.getApplicationContext());
        }
        clGoal = view.findViewById(R.id.cl_goal);
        clGoal.setVisibility(View.GONE);
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mLLFullBody = view.findViewById(R.id.scrolViewFullBody);
        mTvFundPick = view.findViewById(R.id.tv_invest_fund_picks_title);
        mCardGraphBody = view.findViewById(R.id.cv_graph);
        mTBExpandCollapse = view.findViewById(R.id.tb_expand_collapse_chart);
        llExpandCollapse = view.findViewById(R.id.ll_expand_collapse_layout);
        mCardViewSummary = view.findViewById(R.id.cvSummary);
        // mCardGraphBody.setVisibility(View.GONE);
        mTvFundPick.setText(getString(R.string.fund_picks));
        mTvUserName = view.findViewById(R.id.tvName);
        llUpdation = view.findViewById(R.id.llUpdation);
        tv_notification_badge = view.findViewById(R.id.tv_notification_badge);
        mIvContact = view.findViewById(R.id.iv_contact_us);
        mTvAsOndate = view.findViewById(R.id.asOndate);
        mTvAbsReturn = view.findViewById(R.id.days_change);
        rvOtherInsurance = view.findViewById(R.id.rvOtherInsurance);
        rl_calculators = view.findViewById(R.id.rl_calculators);

        rvElssRetirement = view.findViewById(R.id.rv_elss_retirement);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false);
        rvElssRetirement.setLayoutManager(layoutManager);
        TextView tvGoal = view.findViewById(R.id.tv_goal_title);
        TextView tvInvestTopSchemeTitle = view.findViewById(R.id.tv_invest_top_scheme_title);
        TextView tvTopSchemeDesc = view.findViewById(R.id.tv_invest_route_top_scheme_desc);

        TextView tvTopSipTitle = view.findViewById(R.id.tv_top_sip_title);

        TextView tvGoalDesc = view.findViewById(R.id.tv_goal_desc);

        if (mSession.getUserBrokerDomain().equalsIgnoreCase("goalchicapital")){
            tvGoal.setText(R.string.your_goals_our_solutions);
            tvGoalDesc.setText(R.string.your_financial_goals);
            tvInvestTopSchemeTitle.setText(R.string.mutual_funds_scheme_performance);
            tvTopSchemeDesc.setText(R.string.get_detailed_info_on_every_fund_to_make_the_best_informed_decisions);
            tvTopSipTitle.setText(R.string.sip_performance_metrics);
        }


        market_value = view.findViewById(R.id.market_value);
        mTvPurchaseValue = view.findViewById(R.id.tvPurchase);
        mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
        tvOneDayChangeInPercent = view.findViewById(R.id.tvOneDayChangeInPercent);
        tvGainInPercentage = view.findViewById(R.id.tvGainInPercentage);
        relOneDayChange = view.findViewById(R.id.relOneDayChange);
        relGainLayout = view.findViewById(R.id.relGainLayout);
        mTvOverallGain = view.findViewById(R.id.tvOverallGain);
        mTvOverallGainPercentage = view.findViewById(R.id.tvOverallGainInPercentage);
        mTvGain = view.findViewById(R.id.gain);

        pbLoaderOnArn = view.findViewById(R.id.pbLoaderOnArn);

        mAnimatedPieView = view.findViewById(R.id.animatedPieView);
        mTvNothing = view.findViewById(R.id.tvNothing);
        mLinerLineChart = view.findViewById(R.id.linerLineChart);
        mLPairChart = view.findViewById(R.id.linerPieChart);
        mGainInfo = view.findViewById(R.id.gain_info);
        mIvBack = view.findViewById(R.id.ivLeft);
        mllCalculator = view.findViewById(R.id.llCalculator);
        mContentSpecialMsgView = view.findViewById(R.id.content_dashboard_special_message);
        mTvSpecialMsg = mContentSpecialMsgView.findViewById(R.id.tv_special_message);
        mTvReadMore = mContentSpecialMsgView.findViewById(R.id.tvReadMore);
        mLlCross = mContentSpecialMsgView.findViewById(R.id.llCross);
        mGainInfo.setOnClickListener(v -> showGainInfoDialog(getString(R.string.dialog_gain_info_dashboard)));
        view.findViewById(R.id.iv_overall_gain_info).setOnClickListener(v -> showGainInfoDialog(getString(R.string.dialog_overall_gain_info_dashboard)));

        view.findViewById(R.id.ll_profile_not_complete).setOnClickListener(this);
        view.findViewById(R.id.btn_continue_home_invest).setOnClickListener(this);
        view.findViewById(R.id.cl_goal).setOnClickListener(this);
        if (mSession.getLead().equalsIgnoreCase("1")) {
            view.findViewById(R.id.ll_profile_not_complete).setVisibility(View.VISIBLE);
            view.findViewById(R.id.ll_profile_not_complete).setOnClickListener(this);
        } else {
            view.findViewById(R.id.ll_profile_not_complete).setVisibility(View.GONE);
        }
        ImageView ivAppLogo = view.findViewById(R.id.ivAppLogo);
        String imagePath = mSession.getAppLogo();
        fl_notifications = view.findViewById(R.id.fl_notifications);
        fl_notifications.setOnClickListener(this);
        view.findViewById(R.id.iv_notification).setOnClickListener(this);
        view.findViewById(R.id.ivRefresh).setOnClickListener(this);

        includeNotificationBanner = view.findViewById(R.id.includeNotificationBanner);
        AppTextView tvNotificationDisabledMessage = includeNotificationBanner.findViewById(R.id.tvNotificationDisabledMessage);
        includeNotificationBanner.findViewById(R.id.ivNotificationDisabledClose).setOnClickListener(this);
        String text = getString(R.string.notification_disabled_banner_text) + " " + getString(R.string.enable_now);
        tvNotificationDisabledMessage.setText(text);
        ExtensionsKt.setClickableText(
                tvNotificationDisabledMessage,
                tvNotificationDisabledMessage.getText().toString(),
                getString(R.string.enable_now),
                () -> {
                    mActivity.requestNotificationPermission(true);
                    return Unit.INSTANCE;
                }
        );


        mViewPager = view.findViewById(R.id.viewPager);
        mTabLayout = view.findViewById(R.id.tabLayout);

        cvJounrny = view.findViewById(R.id.cvjouney);
        cvJounrny.setOnClickListener(this);

        // allowed loan against mf
        view.findViewById(R.id.cv_dashboard_loan).setVisibility(View.GONE);
        view.findViewById(R.id.rl_additional_sec_container).setOnClickListener(this);

        setTintColorIfDark(requireActivity(), ivAppLogo);
        ivAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getString(R.string.subdomain).equals("mint")) {
            fl_notifications.setVisibility(View.INVISIBLE);
            if (!imagePath.equals("")) {
                Picasso.get().load(imagePath).error(R.drawable.app_logo_secondry_mint).into(ivAppLogo);
            } else {
                ivAppLogo.setImageResource(R.drawable.app_logo_secondry_mint);
            }
        } else {
            if (mSession.getLoginType().equals("broker")) {
                fl_notifications.setVisibility(View.GONE);
            } else {
                fl_notifications.setVisibility(View.VISIBLE);
            }
            ivAppLogo.setImageResource(R.mipmap.app_logo_secondry);
        }

        view.findViewById(R.id.sip_cal).setOnClickListener(this);
        view.findViewById(R.id.lumpsum_cal).setOnClickListener(this);
        view.findViewById(R.id.cost_cal).setOnClickListener(this);
        view.findViewById(R.id.education_cal).setOnClickListener(this);
        view.findViewById(R.id.marriage_cal).setOnClickListener(this);
        view.findViewById(R.id.retirement_cal).setOnClickListener(this);
        view.findViewById(R.id.tvSipPlanner).setOnClickListener(this);
        view.findViewById(R.id.tvSwpPlanner).setOnClickListener(this);
        view.findViewById(R.id.tvStpPlanner).setOnClickListener(this);
        view.findViewById(R.id.tvStepUpCal).setOnClickListener(this);
        view.findViewById(R.id.tvSTPCalculator).setOnClickListener(this);
        view.findViewById(R.id.tvSWPCalculator).setOnClickListener(this);
        mIvContact.setOnClickListener(this);
        view.findViewById(R.id.sip_tenure).setOnClickListener(this);
        view.findViewById(R.id.tvEmiCal).setOnClickListener(this);
        view.findViewById(R.id.tvStepUpCal).setOnClickListener(this);
        view.findViewById(R.id.iv_contact_us).setOnClickListener(this);
        mTvReadMore.setOnClickListener(this);
        mContentSpecialMsgView.findViewById(R.id.ivCross).setOnClickListener(this);
        mLlCross.setOnClickListener(this);
        mIvBack.setOnClickListener(this);

        int imageId = UtilityKotlin.checkExistResources("step_up_cal", "mipmap", requireActivity());
        if (imageId != 0) {
            TextView tvTenure = view.findViewById(R.id.tvStepUpCal);
            tvTenure.setCompoundDrawablesWithIntrinsicBounds(0, imageId, 0, 0);
        }

        if (mSession.getHasLoging()) {
            updateApiData();
        }

        swipeRefreshLayout = view.findViewById(R.id.swipe_layout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                swipeRefreshLayout.setRefreshing(false);
                if (mSession.getHasLoging()) {
                    Calendar calendar = Calendar.getInstance();
                    mAppplication.sRefreshTimePortfolio = calendar.getTimeInMillis();
                    AppApplication.DASHBOARD_PORTFOLIO = "";
                    mActivity.getClientBalSummery();
                }
            }
        });
        if (mSession.getHasLoging()) {
            mActivity.userDidAction("home");
        }

        rvOtherInsurance.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        mOtherInsuranceAdapter = new OtherInsuranceAdapter(getActivity(), (title, url) -> {

            Intent mIntent = new Intent(mActivity, AppIntoMintWebPortalActivity.class);
            mIntent.putExtra("title", title);
            mIntent.putExtra("url", url);
            startActivity(mIntent);
        });
        rvOtherInsurance.setAdapter(mOtherInsuranceAdapter);

        if (Utils.getCustomLinks(mSession).size() != 0) {
            rvOtherInsurance.setVisibility(View.VISIBLE);
        } else {
            rvOtherInsurance.setVisibility(View.GONE);
        }
        mOtherInsuranceAdapter.setdata(Utils.getCustomLinks(mSession));

        //setDateSpinner();


        try {
            JSONObject appConfigObject = new JSONObject(mSession.getAppInfo());
            if (mSession.getFutureProjectionCalculator() != 0) {
                mllCalculator.setVisibility(View.VISIBLE);
            } else {
                mllCalculator.setVisibility(View.GONE);
            }
            /*  if (!getString(R.string.subdomain).equals("mint")) {*/
            if (!TextUtils.isEmpty(appConfigObject.optString("specialMessage")) && !appConfigObject.optString("specialMessage").equalsIgnoreCase("null")) {
                mContentSpecialMsgView.setVisibility(View.VISIBLE);
            } else {
                mContentSpecialMsgView.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(appConfigObject.optString("specialMessage")) && !appConfigObject.optString("specialMessage").equalsIgnoreCase("null")) {
                mTvSpecialMsg.setVisibility(View.VISIBLE);
                mTvSpecialMsg.setText(appConfigObject.optString("specialMessage"));
            } else {
                mTvSpecialMsg.setVisibility(View.GONE);
            }
            if (!TextUtils.isEmpty(appConfigObject.optString("specialMessageLink")) && !appConfigObject.optString("specialMessageLink").equalsIgnoreCase("null")) {
                mTvReadMore.setVisibility(View.VISIBLE);
                specialMsgUrl = appConfigObject.optString("specialMessageLink");
            } else {
                mTvReadMore.setVisibility(View.GONE);
            }

            setUpInvestRouteStaticUi();
            if (((!appConfigObject.optString("popupMessage").isEmpty() && !appConfigObject.optString("popupMessage").equalsIgnoreCase("null")) || (!appConfigObject.optString("popupURL").isEmpty() && !appConfigObject.optString("popupURL").equalsIgnoreCase("null")) || (!appConfigObject.optString("popupImagePath").isEmpty() && !appConfigObject.optString("popupImagePath").equalsIgnoreCase("null")))) {

                localImagePath = appConfigObject.optString("popupImagePath");
                if (!localImagePath.equals(mSession.getShowDialogByCurrentDate())) {
                    if (mActivity != null) {
                        if (!Config.sOncePopupPerLoginSession) {
                            showPopUpDialog(appConfigObject);
                            Config.sOncePopupPerLoginSession = true;
                        }
                    }

                }
            } else {
//                mSession.setShowDialog(false);
            }

            if ((!TextUtils.isEmpty(appConfigObject.optString("showInvestmentSummary")) && !appConfigObject.optString("showInvestmentSummary").equalsIgnoreCase("null")) && appConfigObject.optString("showInvestmentSummary").equalsIgnoreCase("1")) {
                view.findViewById(R.id.clOverallGainLayout).setVisibility(View.VISIBLE);

                if (AppApplication.OVER_SUMMARY_SUMMARY.equals("")) {
                    getOverallGainApi();
                } else {
                    setOverallGainValue();
                }
            } else {
                view.findViewById(R.id.clOverallGainLayout).setVisibility(View.GONE);
            }

        } catch (Exception e) {
            mllCalculator.setVisibility(View.VISIBLE);
        }
        if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
            view.findViewById(R.id.iv_contact_us).setVisibility(View.VISIBLE);
        } else {
            view.findViewById(R.id.iv_contact_us).setVisibility(View.GONE);
        }

        view.findViewById(R.id.cl_latest_nav).setOnClickListener(this);
        view.findViewById(R.id.cl_market_update).setOnClickListener(this);
        view.findViewById(R.id.cl_top_sip_scheme).setOnClickListener(this);
        view.findViewById(R.id.cl_top_scheme).setOnClickListener(this);
        view.findViewById(R.id.cl_fund_picks).setOnClickListener(this);
        view.findViewById(R.id.cl_nfo).setOnClickListener(this);
//        setIncompleteCardAnimation();
//           notificationCount();
        ivAppLogo.setOnClickListener(v -> {
            if (mSession.getEnableDebug()) {
                UtilityKotlin.showDebugModeLoading(mActivity);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        startActivity(new Intent(mActivity, DebugActivity.class));
                    }
                }, 3000);

            } else {
                mClickCount = mClickCount + 1;
                if (mClickCount == 50) {
                    UtilityKotlin.launchDebugMode(mActivity);
                    mClickCount = 0;
                }
            }
        });
        checkCalculatorPermission();
        if(mSession.getLoginType().equals("client"))
            openRiskProfilerPopUp(mActivity);

        observePermission();

        return view;
    }

    private void observePermission() {
        permissionViewModel.isPermissionGrantedLiveData().observe(getViewLifecycleOwner(), this::updateBellIconAndNotificationBannerStatus);
    }

    private void updateBellIconAndNotificationBannerStatus(boolean isGranted) {
        ImageView ivNotification =view.findViewById(R.id.iv_notification);
        if (isGranted) {
            ivNotification.setImageResource(R.mipmap.ic_app_notification);
        }else{
            ivNotification.setImageResource(R.mipmap.ic_app_notification_red);
            ivNotification.clearColorFilter();
            ImageViewCompat.setImageTintList(ivNotification, null);
            ivNotification.clearColorFilter();
            ivNotification.invalidate();
            ivNotification.requestLayout();
        }
        boolean isCustomApp = !getString(R.string.subdomain).equals("mint");
        if (isCustomApp && !isGranted &&  mSession.getLoginType().equals("client") && mActivity.shouldShowNotification()) {
            includeNotificationBanner.setVisibility(View.VISIBLE);
        }
        else{
            includeNotificationBanner.setVisibility(View.GONE);
        }
    }


    private void checkCalculatorPermission() {
        if (mSession.getFutureProjectionCalculator() != 0) {
            rl_calculators.setVisibility(View.VISIBLE);
            if (mSession.getSIPCalculator() == 0) {
                view.findViewById(R.id.tvSipPlanner).setVisibility(View.INVISIBLE);
                view.findViewById(R.id.tvStpPlanner).setVisibility(View.INVISIBLE);
                view.findViewById(R.id.tvSwpPlanner).setVisibility(View.INVISIBLE);
                view.findViewById(R.id.view_planner1).setVisibility(View.INVISIBLE);
                view.findViewById(R.id.view_planner2).setVisibility(View.INVISIBLE);
            }
        } else {
            rl_calculators.setVisibility(View.GONE);
        }
    }


    private void updateApiData() {
        try {
            mShimmerViewContainer.setVisibility(View.VISIBLE);
            mLLFullBody.setVisibility(View.GONE);
            mShimmerViewContainer.startShimmer();

            Calendar calendar = Calendar.getInstance();
            long currentTimeInMilli = calendar.getTimeInMillis();
            long difference = currentTimeInMilli - mAppplication.sRefreshTimePortfolio;
            long minutes = (difference / 1000) / 60;
            if (minutes >= 10) {
                mAppplication.sRefreshTimePortfolio = calendar.getTimeInMillis();
                AppApplication.DASHBOARD_PORTFOLIO = "";
                mActivity.getClientBalSummery();
            } else {
                if (AppApplication.CLIENT_DASHBOARD_BAL_SUMMARY.equals("")) {
                    mActivity.getClientBalSummery();
                } else {
                    setSummary();
                    updateViewPagerView();
                }


            }
        } catch (Exception e) {
            mShimmerViewContainer.setVisibility(View.GONE);
            mShimmerViewContainer.stopShimmer();
            mLLFullBody.setVisibility(View.VISIBLE);

        }

        if (!Config.asOnDate.isEmpty()) {
            mTvAsOndate.setVisibility(View.VISIBLE);
            mTvAsOndate.setText(Config.asOnDate);
        } else {
            setMaxNavDate();
        }
    }

    public void updateViewPagerView() {
        mShimmerViewContainer.setVisibility(View.GONE);
        mShimmerViewContainer.stopShimmer();
        mLLFullBody.setVisibility(View.VISIBLE);

        if (isNoData) {
            mCardGraphBody.setVisibility(View.GONE);
            llExpandCollapse.setVisibility(View.GONE);
//            mTBExpandCollapse.setVisibility(View.GONE);
        } else {
            //setting up expand collapse of chart box
            llExpandCollapse.setVisibility(View.VISIBLE);
//            mTBExpandCollapse.setVisibility(View.VISIBLE);
            boolean status = mSession.getHomeChartBoxExpandStatus();
            mTBExpandCollapse.setChecked(status);

            if (mTBExpandCollapse.isChecked()) mCardGraphBody.setVisibility(View.VISIBLE);else mCardGraphBody.setVisibility(View.GONE);

            mTBExpandCollapse.setOnCheckedChangeListener((buttonView, isChecked) -> {

                if (isChecked)
                    mCardGraphBody.setVisibility(View.VISIBLE);
                else
                    mCardGraphBody.setVisibility(View.GONE);

                mSession.setHomeChartBoxExpandStatus(isChecked);
            });

            List<Fragment> fragList = new ArrayList<>();
            Bundle bundle;
            Fragment fragment = new FragGraphHome1();
            bundle = new Bundle();
            bundle.putString("type", "tab1");
            fragment.setArguments(bundle);
            fragList.add(fragment);

            Fragment fragment2 = new FragGraphHome1();
            bundle = new Bundle();
            bundle.putString("type", "tab2");
            fragment2.setArguments(bundle);
            fragList.add(fragment2);

            Fragment fragment3 = new FragGraphHome1();
            bundle = new Bundle();
            bundle.putString("type", "tab3");
            fragment3.setArguments(bundle);
            fragList.add(fragment3);

            Fragment fragment4 = new FragGraphHome1();
            bundle = new Bundle();
            bundle.putString("type", "tab4");
            fragment4.setArguments(bundle);
            fragList.add(fragment4);

            if (mPagerAdapter == null) {
                mPagerAdapter = new FragViewPagerAdapter(getChildFragmentManager(), fragList);
                mViewPager.setAdapter(mPagerAdapter);
                mTabLayout.setupWithViewPager(mViewPager);
            }
            mTabLayout.getTabAt(0).setText(R.string.txt_asserts);
            mTabLayout.getTabAt(1).setText(R.string.Category);
            mTabLayout.getTabAt(2).setText(R.string.Investor);
            mTabLayout.getTabAt(3).setText(R.string.txt_funds);
        }

    }

    private void setUpInvestRouteStaticUi() {
        try {
            JSONObject appConfigObject = new JSONObject();
            if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
            }
            if (appConfigObject != null) {
                /*if (!getString(R.string.subdomain).equals("mint")) {

                } else {
                    view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.cl_fund_picks).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                }*/

                if (mSession.getHasLoging()) {

                    if ((!TextUtils.isEmpty(appConfigObject.optString("fundPicks")) && !appConfigObject.optString("fundPicks").equalsIgnoreCase("null")) && appConfigObject.optString("fundPicks").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_fund_picks).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_fund_picks).setVisibility(View.GONE);
                    }

                    if ((!TextUtils.isEmpty(appConfigObject.optString("topSchemes")) && !appConfigObject.optString("topSchemes").equalsIgnoreCase("null")) && appConfigObject.optString("topSchemes").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_top_scheme).setVisibility(View.GONE);
                    }

                    if ((!TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes")) && !appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null")) && appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.GONE);
                    }

                    if ((!TextUtils.isEmpty(appConfigObject.optString("latestNav")) && !appConfigObject.optString("latestNav").equalsIgnoreCase("null")) && appConfigObject.optString("latestNav").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_latest_nav).setVisibility(View.GONE);
                    }

                    if ((!TextUtils.isEmpty(appConfigObject.optString("NFO")) && !appConfigObject.optString("NFO").equalsIgnoreCase("null")) && appConfigObject.optString("NFO").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                        view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_nfo).setVisibility(View.GONE);
                    }

                    if (((TextUtils.isEmpty(appConfigObject.optString("NFO"))
                            || appConfigObject.optString("NFO").equalsIgnoreCase("null"))
                            || !appConfigObject.optString("NFO").equalsIgnoreCase("1"))
                            && ((TextUtils.isEmpty(appConfigObject.optString("topSchemes"))
                            || appConfigObject.optString("topSchemes").equalsIgnoreCase("null"))
                            || !appConfigObject.optString("topSchemes").equalsIgnoreCase("1"))
                            && ((TextUtils.isEmpty(appConfigObject.optString("fundPicks"))
                            || appConfigObject.optString("fundPicks").equalsIgnoreCase("null"))
                            || !appConfigObject.optString("fundPicks").equalsIgnoreCase("1"))
                            && ((TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes"))
                            || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null"))
                            || !appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1"))

                    ) {
                        view.findViewById(R.id.cv_dashboard_investment).setVisibility(View.GONE);
                    } else {
                        // view.findViewById(R.id.ll_inv).setVisibility(View.VISIBLE);
                    }



                    if (((TextUtils.isEmpty(appConfigObject.optString("latestNav"))
                            || appConfigObject.optString("latestNav").equalsIgnoreCase("null"))
                            || !appConfigObject.optString("latestNav").equalsIgnoreCase("1"))
                            && ((TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes"))
                            || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null"))
                            || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1"))) {
                        view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                        view.findViewById(R.id.v_sip).setVisibility(View.GONE);
                    }

                    try {
                        JSONObject jsoObject = new JSONObject(mSession.getAllowedFeatures());
                        JSONArray jsonArray = jsoObject.optJSONArray("data");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            if (jsonArray.optJSONObject(i).has("feature1044")) {
                                if (!mSession.getVoltPartnerCode().equalsIgnoreCase("")){
                                    // removing volt sdk bcoz of containing unusable permissions
                                    view.findViewById(R.id.cv_dashboard_loan).setVisibility(View.VISIBLE);
                                }
                                break;
                            } else {
                                view.findViewById(R.id.cv_dashboard_loan).setVisibility(View.GONE);
                            }
                        }

                        clGoal.setVisibility(View.GONE);
                        String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
                        if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
                            JSONObject mJsoObject = null;
                            try {
                                mJsoObject = new JSONObject(allowedFeatured);
                                JSONArray jsonArray2 = mJsoObject.optJSONArray("data");

                                for (int i = 0; i < jsonArray2.length(); i++) {
                                    if (jsonArray2.optJSONObject(i).has("feature1007")) {
                                        clGoal.setVisibility(View.VISIBLE);
                                    }

                                }

                            } catch (JSONException e) {

                            }
                        }
                    } catch (JSONException e) {

                    }

                } else {
                    clGoal.setVisibility(View.GONE);
                    view.findViewById(R.id.cl_fund_picks).setVisibility(View.GONE);
                    if ((!TextUtils.isEmpty(appConfigObject.optString("topSchemes")) && !appConfigObject.optString("topSchemes").equalsIgnoreCase("null")) && appConfigObject.optString("topSchemes").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_top_scheme).setVisibility(View.GONE);
                    }

                    if ((!TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes")) && !appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null")) && appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                    } else {
                        view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.GONE);
                    }

                    if ((!TextUtils.isEmpty(appConfigObject.optString("NFO")) && !appConfigObject.optString("NFO").equalsIgnoreCase("null")) && appConfigObject.optString("NFO").equalsIgnoreCase("1")) {
                        view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                        view.findViewById(R.id.v_nfo).setVisibility(View.GONE);
                    } else {
                        view.findViewById(R.id.cl_nfo).setVisibility(View.GONE);
                    }

                    if (((TextUtils.isEmpty(appConfigObject.optString("latestNav")) || appConfigObject.optString("latestNav").equalsIgnoreCase("null")) || !appConfigObject.optString("latestNav").equalsIgnoreCase("1"))) {
                        view.findViewById(R.id.cl_latest_nav).setVisibility(View.GONE);
                    } else {
                        view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);
                    }

                    if (((TextUtils.isEmpty(appConfigObject.optString("latestNav")) || appConfigObject.optString("latestNav").equalsIgnoreCase("null")) || !appConfigObject.optString("latestNav").equalsIgnoreCase("1")) && ((TextUtils.isEmpty(appConfigObject.optString("topSIPSchemes")) || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("null")) || appConfigObject.optString("topSIPSchemes").equalsIgnoreCase("1"))) {
                        view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                        view.findViewById(R.id.v_sip).setVisibility(View.GONE);
                    }
                }

            } else {
                //view.findViewById(R.id.ll_inv).setVisibility(View.GONE);
            }
            // rename invest in top performers to Scheme Performance and top scheme as per sumit saini
            if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){

                TextView tvInvestTopSchemeTitle = view.findViewById(R.id.tv_invest_top_scheme_title);
                TextView tvInvestRouteTopSchemeDesc = view.findViewById(R.id.tv_invest_route_top_scheme_desc);
                TextView tvTopSipTitle = view.findViewById(R.id.tv_top_sip_title);
                TextView tvTopSipDesc = view.findViewById(R.id.tv_top_sip__desc);

                tvInvestTopSchemeTitle.setText(R.string.scheme_performance);
                tvInvestRouteTopSchemeDesc.setText(R.string.view_performance_of_all_mutual_funds_schemes);

                tvTopSipTitle.setText(R.string.sip_scheme_performance);
                tvTopSipDesc.setText(R.string.txt_view_schemes_on_the_basis_of_trailing);

            }
        } catch (Exception e) {
        } /*finally {
            if (getString(R.string.subdomain).equals("mint")) {
                // view.findViewById(R.id.ll_inv).setVisibility(View.VISIBLE);
                view.findViewById(R.id.llInvestmentRoute).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cv_dashboard_sec).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.v_refer).setVisibility(View.VISIBLE);
                view.findViewById(R.id.v_nfo).setVisibility(View.VISIBLE);

                view.findViewById(R.id.cl_top_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_latest_nav).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_market_update).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_nfo).setVisibility(View.VISIBLE);
                // view.findViewById(R.id.cl_fund_picks).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_top_sip_scheme).setVisibility(View.VISIBLE);
                if (mSession.getHasLoging()) {
                    view.findViewById(R.id.cl_fund_picks).setVisibility(View.VISIBLE);
                } else {
                    view.findViewById(R.id.cl_fund_picks).setVisibility(View.GONE);
                }
            }
        }*/

        finally {
            String allowedFeatured = UtilityKotlin.getAllowedFeatured(mSession,AppApplication.TMP_ALLOWED_FEATURED);
            // TODO: mf bazaar

            if (mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")){
                if (allowedFeatured != null && !TextUtils.isEmpty(allowedFeatured)) {
                    JSONObject mJsoObject = null;
                    try {
                        mJsoObject = new JSONObject(allowedFeatured);
                        JSONArray jsonArray = mJsoObject.optJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            if (jsonArray.optJSONObject(i).has("feature1007")) {
                                view.findViewById(R.id.cl_goal).setVisibility(View.VISIBLE);
                            }
                        }

                    } catch (JSONException e) {
                    }
                }
                view.findViewById(R.id.cl_goal).setOnClickListener(this);

                ImageView goalIcon = view.findViewById(R.id.iv_goal);
                TextView goalTitle = view.findViewById(R.id.tv_goal_title);
                TextView goalDesc = view.findViewById(R.id.tv_goal_desc);
                goalTitle.setText(getString(R.string.invest_for_a_purpose));
                goalDesc.setText(getString(R.string.invest_for_a_purpose_of_your_choice));
                ImageView ivExistingScheme = view.findViewById(R.id.iv_existing_scheme);
                goalIcon.setImageResource(R.mipmap.goal_colorfull);

                int icon = UtilityKotlin.checkExistResources("existing_schemes","mipmap",requireActivity());
                if (icon !=0){
                    ivExistingScheme.setImageResource(icon);
                }

                ImageView ivtransferHolding = view.findViewById(R.id.iv_transfer_holding);
                int iconHolding = UtilityKotlin.checkExistResources("transfer_holding","mipmap",requireActivity());
                if (iconHolding !=0){
                    ivtransferHolding.setImageResource(iconHolding);
                }

                // top fund scheme performance
                TextView tvInvestTopSchemeTitle = view.findViewById(R.id.tv_invest_top_scheme_title);
                TextView tvTopSchemeDesc = view.findViewById(R.id.tv_invest_route_top_scheme_desc);

                if (getString(R.string.subdomain).equals("mfbazaar")) {
                    tvInvestTopSchemeTitle.setText(getString(R.string.top_fund_scheme_performance_mf_bazaar));
                }else{
                    tvInvestTopSchemeTitle.setText(getString(R.string.top_fund_scheme_performance));
                }
                tvTopSchemeDesc.setText(R.string.view_performance_of_all_mutual_funds_schemes);

                // Search by amc
                view.findViewById(R.id.cl_amc).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_amc).setOnClickListener(this);
                TextView tvAmcTitle = view.findViewById(R.id.tv_amc_title);
                TextView tvAmcDesc = view.findViewById(R.id.tv_amc_desc);
                tvAmcTitle.setText(R.string.search_by_amc);
                tvAmcDesc.setText(R.string.select_amc_choose_fund_to_invest);

                // top sip performance
                TextView topSipPerformance = view.findViewById(R.id.tv_top_sip_title);
                if (getString(R.string.subdomain).equals("mfbazaar")) {
                    topSipPerformance.setText(getString(R.string.top_sip_scheme_performance_mf_bazaar));
                }else{
                    topSipPerformance.setText(getString(R.string.top_sip_scheme_performance));
                }

                // transfer holding
                view.findViewById(R.id.cl_transfer_holding).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_transfer_holding).setOnClickListener(this);
                // invest in existing scheme

                view.findViewById(R.id.cl_existing_scheme).setVisibility(View.VISIBLE);
                view.findViewById(R.id.cl_existing_scheme).setOnClickListener(this);
                // elss retirement list
                view.findViewById(R.id.rl_elss_retirement).setVisibility(View.VISIBLE);
                TextView tv_dashboard_items_title3 = view.findViewById(R.id.tv_dashboard_items_title3);
                tv_dashboard_items_title3.setText(getString(R.string.txt_elss_retirement_children_liquid_gold_fund_mf_bazaar));
                // set elss rv
                elssRetirementArrayList = new ArrayList<>();

                elssRetirementAdapter = new ElssRetirementAdapter(requireActivity(),this);
                rvElssRetirement.setAdapter(elssRetirementAdapter);
                getObjectives();
            }

        }


    }

    @Override
    public void onElssRetirement(int action, @Nullable String objectiveId,String mTitle) {
        taxSaverTopScheme(objectiveId,mTitle);
    }
    private void taxSaverTopScheme(String objId,String mTitle){
        Intent intent= null;
        intent = new Intent(mActivity, TopSchemeActivity.class);
        AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
        intent.putExtra("objId", objId);
        intent.putExtra("filter", "no");
        if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){
            intent.putExtra("toolBarTitle", getString(R.string.scheme_performance));
        }else if (mSession.getUserBrokerDomain().equalsIgnoreCase("mfbazaar")){
            intent.putExtra("toolBarTitle", mTitle);
        }
                  /*  intent.putExtra("title", getString(R.string.txt_top_scheme));
                    intent.putExtra("isShowToolBar", "yes");
                    intent.putExtra("url", requireActivity().getResources().getString(R.string.top_scheme_url));*/
        startActivity(intent);
    }
    private void getObjectives(){

        Map<String, ElssRetirement> objectiveActionMap = new HashMap<>();

//        objectiveActionMap.put("Solution: Retirement Debt", new ElssRetirement(R.mipmap.debt_retirement, "Retirement Debt", 2));
//        objectiveActionMap.put("Solution: Retirement Equity", new ElssRetirement(R.mipmap.retirement_equity, "Retirement Equity", 3));
//        objectiveActionMap.put("Solution: Children Debt", new ElssRetirement(R.mipmap.debt_child_education, "Children Debt", 4));
//        objectiveActionMap.put("Solution: Children Equity", new ElssRetirement(R.mipmap.children_funds, "Children Equity", 5));
//        objectiveActionMap.put("Debt: Liquid", new ElssRetirement(R.mipmap.liquid_funds, "Liquid Funds", 6));
//        objectiveActionMap.put("Gold: Gold Funds", new ElssRetirement(R.mipmap.gold_funds, "Gold Funds", 7));


        String url = "";
        if (!TextUtils.isEmpty(mSession.getUserBrokerDomain())) {
            if (!mSession.getHasLoging()) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TOP_SCHEME_OPEN_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
            } else {
                if (hasReAuthTimeNotValid(mSession, requireActivity())) {
                    return;
                }
                if ("broker".equals(mSession.getLoginType()) && mSession.getClientObject().isEmpty()) {
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TOP_SCHEME_BROKER_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
                } else {
                    if (Utils.getSelectedLevelNo(mSession).equals("1")){
                        return;
                    }
                    url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_TOP_SCHEME_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName&selectedUser=" + Utils.getSelectedUserObject(mSession);
                }
            }
        } else {
            if (!mSession.getHasLoging()) {
                url = "https://demo" + mSession.getHostingPath() + Config.GET_TOP_SCHEME_OPEN_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
            } else {
                if ("broker".equals(mSession.getLoginType()) && mSession.getClientObject().isEmpty()) {
                    url = "https://demo" + mSession.getHostingPath() + Config.GET_TOP_SCHEME_BROKER_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName";
                } else {
                    if (Utils.getSelectedLevelNo(mSession).equals("1")){
                        return;
                    }
                    url = "https://demo" + mSession.getHostingPath() + Config.GET_TOP_SCHEME_OBJ_DATA + "?orderBy=objective&orderByDesc=false&columnName=objectiveName&selectedUser=" + Utils.getSelectedUserObject(mSession);
                }
            }
        }

        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        ProgressBarCommon.showDialog(getActivity());
        StringRequest stringRequest = new StringRequest(Request.Method.GET,url,response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                if (jsonObject.optInt("status") == 0) {

                    JSONArray jsonArray = jsonObject.optJSONArray("result");
                    for (int i = 0; i< (jsonArray != null ? jsonArray.length() : 0); i++){
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        String objective = jsonObject1.optString("objective");
                        String objectiveId = jsonObject1.optString("objectiveid");

                        if (objective.equalsIgnoreCase("Equity: ELSS")){
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.elss_funds,"Invest in ELSS Fund",1,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        } else if (objective.equalsIgnoreCase("Solution: Retirement Debt")) {
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.debt_retirement,"Invest in Retirement Debt",2,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        } else if (objective.equalsIgnoreCase("Solution: Retirement Equity")) {
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.retirement_equity,"Invest in  Retirement Equity",3,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        }else if (objective.equalsIgnoreCase("Solution: Children Debt")) {
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.debt_child_education,"Invest in Children Debt",4,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        }else if (objective.equalsIgnoreCase("Solution: Children Equity")) {
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.children_funds,"Invest in  Children Equity",5,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        }else if (objective.equalsIgnoreCase("Debt: Liquid")) {
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.liquid_funds,"Invest in Liquid Funds",6,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        }else if (objective.equalsIgnoreCase("Gold: Gold Funds")) {
                            ElssRetirement el1 = new ElssRetirement(R.mipmap.gold_funds,"Invest in Gold Funds",7,objective,objectiveId);
                            elssRetirementArrayList.add(el1);
                        }
                    }

                    Collections.sort(elssRetirementArrayList, (o1, o2) -> Integer.compare(o1.getAction(), o2.getAction()));

                }else {
                    UtilityKotlin.onSnackFailure(
                            rvElssRetirement,
                            jsonObject.optString("message"),
                            requireContext()
                    );
                }
            } catch (JSONException e) {
            }finally {
                ProgressBarCommon.dismissDialog();
                if (elssRetirementArrayList.size() !=0){
                    elssRetirementAdapter.update(elssRetirementArrayList);
                }
            }
        },volleyError -> {
            if (!isAdded())
                return;
            ProgressBarCommon.dismissDialog();
            UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return returnHeaderAfterLogin(mSession, requireContext());
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                getNetworkResponse(mSession, response,requireContext());
                return super.parseNetworkResponse(response);
            }
        };

        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 5000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 5;
            }

            @Override
            public void retry(VolleyError volleyError) throws VolleyError {
                int statusCode = volleyError.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });

        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);


    }





    /**
     * Prepares sample data to provide data set to adapter
     */

    private void showPopUpDialog(JSONObject appConfigObject) {
        if (mPopupMessageDialog != null) {
            mPopupMessageDialog.dismiss();
        }
        mPopupMessageDialog = new Dialog(mActivity);
        mPopupMessageDialog.setContentView(R.layout.special_message_popup);
        ImageView mIvBanner = mPopupMessageDialog.findViewById(R.id.ivBanner);
        RelativeLayout mRlCont = mPopupMessageDialog.findViewById(R.id.rl_cont);
        ImageView mIvExp = mPopupMessageDialog.findViewById(R.id.iv_exp);
        Button mIvClose = mPopupMessageDialog.findViewById(R.id.ivClose);
        mIvClose.setTransformationMethod(null);
        TextView mTvMessage = mPopupMessageDialog.findViewById(R.id.tvMessage);
        Button mBtnKnowMore = mPopupMessageDialog.findViewById(R.id.btnKnowMore);
        CheckBox mCheckBox = mPopupMessageDialog.findViewById(R.id.checkBox);
        mPopupMessageDialog.setCancelable(false);

        if (!appConfigObject.optString("popupURL").isEmpty() && !appConfigObject.optString("popupURL").equalsIgnoreCase("null")) {
            mBtnKnowMore.setVisibility(View.VISIBLE);

        } else {
            mBtnKnowMore.setVisibility(View.GONE);

        }
        if (!appConfigObject.optString("popupMessage").isEmpty() && !appConfigObject.optString("popupMessage").equalsIgnoreCase("null")) {
            mTvMessage.setText(appConfigObject.optString("popupMessage"));
            mTvMessage.setVisibility(View.VISIBLE);
        } else {
            mTvMessage.setVisibility(View.GONE);
        }


        mBtnKnowMore.setOnClickListener(view -> {
            Intent intent;
            if (mActivity != null) {
                intent = new Intent(mActivity, WebActivity.class);
            } else {
                intent = new Intent(mActivity, WebActivity.class);
            }
            intent.putExtra("title", getString(R.string.information));
            intent.putExtra("url", appConfigObject.optString("popupURL"));
            startActivity(intent);
            mPopupMessageDialog.dismiss();
        });
        mIvClose.setOnClickListener(v -> {
//            mSession.setShowCrossDialog(false);
            mPopupMessageDialog.dismiss();
        });


        mCheckBox.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                // mSession.setShowDialog(false);
                mSession.setShowDialogByCurrentDate(localImagePath);
            }
        });

        mIvBanner.setOnClickListener(v -> {
            String url = "https://" + appConfigObject.optString("popupImagePath");
            showCustomDialo(url);
        });

        if (!TextUtils.isEmpty(appConfigObject.optString("popupImagePath")) && !appConfigObject.optString("popupImagePath").equalsIgnoreCase("null")) {
            mIvBanner.setVisibility(View.VISIBLE);
            boolean isFound = appConfigObject.optString("popupImagePath").contains("http");
            boolean isF2 = appConfigObject.optString("popupImagePath").contains("https");
            String url = "";
            if (isFound || isF2) {
                url = appConfigObject.optString("popupImagePath");
            } else {
                url = "https://" + appConfigObject.optString("popupImagePath");
            }
            Picasso.get().load(url).memoryPolicy(MemoryPolicy.NO_CACHE).networkPolicy(NetworkPolicy.NO_CACHE).into(mIvBanner, new Callback() {
                @Override
                public void onSuccess() {
                    // mSession.setAppLogo(imagePath);
                    if (getActivity() != null && mPopupMessageDialog != null) {
                        mPopupMessageDialog.show();
                    }

                }

                @Override
                public void onError(Exception e) {
                    mIvBanner.setVisibility(View.GONE);

                }
            });
        } else {
            mIvBanner.setVisibility(View.GONE);
            if (getActivity() != null && mPopupMessageDialog != null) {
                mPopupMessageDialog.show();
            }
        }


    }

    private void showCustomDialo(String s) {
        final Dialog d = new Dialog(mActivity, android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        d.setContentView(R.layout.dialog_zoom);
        ImageView mIvClose = d.findViewById(R.id.ivClose);
        investwell.utils.customView.ZoomClass mIvBanner = d.findViewById(R.id.iv_zoom);
        if (!TextUtils.isEmpty(s) && !s.equalsIgnoreCase("null")) {
            mIvBanner.setVisibility(View.VISIBLE);
            if (mActivity != null) {
                Picasso.get().load(s).into(mIvBanner);
            }
        } else {
            mIvBanner.setVisibility(View.GONE);
        }

        mIvClose.setOnClickListener(view -> d.dismiss());
        d.show();
    }


    @Override
    public void onClick(View v) {
        Intent intent;
        if (v.getId() == R.id.ivLeft) {
                mActivity.onBackPressedHandled();
}
else if (v.getId() == R.id.ll_profile_not_complete) {
                /*    if (!TextUtils.isEmpty(mSession.getIinId())) {
                 *//*        mActivity.callAppIInApi();*//*
                } else {*/
                mActivity.callClientInfoApi(true,true);
                /* }*/
}
else if (v.getId() == R.id.btn_continue_home_invest) {
                System.out.println();
                mActivity.callClientInfoApi(true, true);
}
else if (v.getId() == R.id.cl_transfer_holding) {
                mActivity.displayViewOther(89, null);
}
else if (v.getId() == R.id.cl_goal) {
                mActivity.displayViewOther(49, null);
}
else if (v.getId() == R.id.cl_existing_scheme) {
                mActivity.displayViewOther(30,null);
}
else if (v.getId() == R.id.cl_amc) {
                mActivity.displayViewOther(90,null);
}
else if (v.getId() == R.id.sip_cal) {
            startActivity(new Intent(mActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SIP.GoalAmount.INSTANCE.getKey()));

        }
else if (v.getId() == R.id.lumpsum_cal) {
            startActivity(new Intent(mActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.LUMPSUM.INSTANCE.getKey()));
        }
else if (v.getId() == R.id.cost_cal) {
            startActivity(new Intent(mActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.CostOfDelay.INSTANCE.getKey()));
}
else if (v.getId() == R.id.iv_contact_us) {
                mActivity.displayViewOther(39, null);
}
else if (v.getId() == R.id.ivCross) {
                mContentSpecialMsgView.setVisibility(View.GONE);
}
else if (v.getId() == R.id.tvReadMore) {
                intent = new Intent(mActivity, WebActivity.class);
                intent.putExtra("title", getString(R.string.information));
                intent.putExtra("isShowToolBar", "yes");
                intent.putExtra("url", specialMsgUrl);
                startActivity(intent);
}
else if (v.getId() == R.id.education_cal) {
                mActivity.displayViewCalculator(7, null);
}
else if (v.getId() == R.id.marriage_cal) {
                mActivity.displayViewCalculator(8, null);
}
else if (v.getId() == R.id.retirement_cal) {
                mActivity.displayViewCalculator(6, null);
}
else if (v.getId() == R.id.sip_tenure) {
                Intent intent2 = new Intent(getActivity(), WebActivity.class);
                intent2.putExtra("title", getString(R.string.sip_tenure));
                intent2.putExtra("url", getString(R.string.sip_tenure_link));
                startActivity(intent2);
}
else if (v.getId() == R.id.tvSipPlanner) {
                intent = new Intent(mActivity, WebActivity.class);
                intent.putExtra("title", getString(R.string.sip_planner));
                intent.putExtra("url", getString(R.string.sip_planner_url));
                startActivity(intent);
}
else if (v.getId() == R.id.tvStpPlanner) {
                intent = new Intent(mActivity, WebActivity.class);
                intent.putExtra("title", getString(R.string.stp_planner));
                intent.putExtra("url", getString(R.string.stp_planner_url));
                startActivity(intent);
}
else if (v.getId() == R.id.tvSwpPlanner) {
                intent = new Intent(mActivity, WebActivity.class);
                intent.putExtra("title", getString(R.string.swp_planner));
                intent.putExtra("url", getString(R.string.swp_planner_url));
                startActivity(intent);
}
else if (v.getId() == R.id.tvEmiCal) {
                mActivity.displayViewCalculator(4, null);
}
else if (v.getId() == R.id.cl_top_scheme) {
                if (mActivity != null) {
                    intent = new Intent(mActivity, TopSchemeActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                    intent.putExtra("fundPick", "no");
                    if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){
                        intent.putExtra("toolBarTitle", getString(R.string.scheme_performance));
                    }
                    startActivity(intent);
                }
}
else if (v.getId() == R.id.cl_fund_picks) {
                if (mActivity != null) {
                   /* intent = new Intent(mActivity, FundPicksActivity.class);
                    intent.putExtra("fundPick", "yes");
                    startActivity(intent);*/
                    intent = new Intent(requireActivity(), TopSchemeActivity.class);
                    intent.putExtra("toolBarTitle", getString(R.string.txt_fund_pick_name));
                    startActivity(intent);
                }
}else if (v.getId() == R.id.tvSTPCalculator){
            startActivity(new Intent(mActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.STP.INSTANCE.getKey()));

        }else if (v.getId() == R.id.tvSWPCalculator){
            startActivity(new Intent(mActivity, NewCalculatorActivity.class).putExtra("calculatorType", CalculatorType.SWP.INSTANCE.getKey()));

        }
else if (v.getId() == R.id.cl_top_sip_scheme) {
                if (mActivity != null) {
                    /*intent = new Intent(mActivity, WebActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                    intent.putExtra("title", getString(R.string.txt_top_sip_schemes));
                    intent.putExtra("isShowToolBar", "yes");
                    intent.putExtra("url", getString(R.string.top_sip_url));
                    startActivity(intent);*/
                    intent = new Intent(requireActivity(), TopSchemeActivity.class);
                    if (mSession.getUserBrokerDomain().equalsIgnoreCase("vistawealth")){
                        intent.putExtra("toolBarTitle", getString(R.string.sip_scheme_performance));
                    }else {
                        intent.putExtra("toolBarTitle", getString(R.string.dashboard_top_sip_title));
                    }
                    startActivity(intent);
                }
}
else if (v.getId() == R.id.cl_latest_nav) {
                if (mActivity != null) {
                    mActivity.displayViewOther(99,new  Bundle());
                }
}
else if (v.getId() == R.id.cl_market_update) {
                if (mActivity != null) {
                    intent = new Intent(mActivity, MarketUpdateActivity.class);
                    startActivity(intent);
                }
}
else if (v.getId() == R.id.cl_nfo) {
                if (mActivity != null) {
                    intent = new Intent(mActivity, NfoActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                    startActivity(intent);
                }
}
else if (v.getId() == R.id.tvStepUpCal) {
                mActivity.displayViewCalculator(3, null);
}
else if (v.getId() == R.id.iv_notification) {
}
else if (v.getId() == R.id.fl_notifications) {
                mActivity.displayViewOther(46, null);
}
else if (v.getId() == R.id.ivRefresh) {
                Calendar calendar = Calendar.getInstance();
                mAppplication.sRefreshTimePortfolio = calendar.getTimeInMillis();
                AppApplication.DASHBOARD_PORTFOLIO = "";
                mActivity.getClientBalSummery();
}
else if (v.getId() == R.id.rl_additional_sec_container) {
                mActivity.displayViewOther(81, null);
}
else if (v.getId() == R.id.cvjouney) {
                mActivity.displayViewOther(82, null);
}else if (v.getId() == R.id.ivNotificationDisabledClose){
            mSession.setNotificationBannerCloseTime(System.currentTimeMillis());
            includeNotificationBanner.setVisibility(View.GONE);

        }
    }


    /*************************************************
     * Method called to calculate notification count
     ***********************************************************/
    public void notificationCount() {
        try {
            if (!mSession.getNotification().isEmpty()) {
                JSONArray jsonArray = new JSONArray(mSession.getNotification());
                List<JSONObject> newNotificationList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.optJSONObject(i);
                    if (!object.optBoolean("isReadNotification")) {
                        newNotificationList.add(object);
                    }
                }
                if (tv_notification_badge != null) {
                    if (newNotificationList.size() > 0) {
                        tv_notification_badge.setVisibility(View.VISIBLE);
                        tv_notification_badge.setText("" + newNotificationList.size());
                    } else {
                        tv_notification_badge.setVisibility(View.GONE);
                    }

                }
            } else {
                if (tv_notification_badge != null) {
                    tv_notification_badge.setVisibility(View.GONE);
                }
            }

        } catch (Exception e) {
        }
    }

    private void setOverallGainValue() {

        try {
            JSONObject jsonObject = new JSONObject(AppApplication.OVER_SUMMARY_SUMMARY);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double oneDayChange = jsonObjectMain.optDouble("netGain");
                Utils.setRuppesSymbol(mTvOverallGain, oneDayChange, mActivity);
                if (mSession.getHideXirr().equals("0") && jsonObjectMain.has("XIRR")) {
                    mTvOverallGainPercentage.setVisibility(View.VISIBLE);
                    UtilityKotlin.safeDisplayXirrPercentValue(
                            jsonObjectMain,
                            "XIRR",
                            "",
                            "%",
                            2,
                            true,
                            mTvOverallGainPercentage,
                            true
                    );
                }
                else{
                    mTvOverallGainPercentage.setVisibility(View.GONE);
                }

            }
        } catch (Exception e) {

        }
    }

    public void setSummary() {
        try {
            mShimmerViewContainer.setVisibility(View.GONE);
            mShimmerViewContainer.stopShimmer();
            mLLFullBody.setVisibility(View.VISIBLE);
            JSONObject jsonObject = new JSONObject(AppApplication.CLIENT_DASHBOARD_BAL_SUMMARY);
            if (jsonObject.optInt("status") == 0) {
                mCardViewSummary.setVisibility(View.VISIBLE);
                isNoData = false;
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = 0;
                if (jsonObjectMain != null) {
                    currentValue = jsonObjectMain.optDouble("currentValue");
                }
                String strCurrentAmount = format.format(currentValue);
                market_value.setText(strCurrentAmount);

                double purchaseValue = jsonObjectMain.optDouble("purchaseValue");
                String strPurchaseValue = format.format(purchaseValue);
                mTvPurchaseValue.setText(strPurchaseValue);
                if (mSession.getLead().equalsIgnoreCase("0") && (currentValue == 0.0 && purchaseValue == 0.0)) {
                    view.findViewById(R.id.cv_invest_now).setVisibility(View.VISIBLE);

                    TypeWriter mtv = view.findViewById(R.id.textView15);
                    mtv.setCharacterDelay(100);
                    mtv.animateText(getString(R.string.no_current_investments));
                    AlphaAnimation anim = new AlphaAnimation(0.0f, 1.0f);
                    anim.setDuration(5000);
                    view.findViewById(R.id.btn_home_invest).startAnimation(anim);
                    view.findViewById(R.id.btn_home_invest).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.btn_home_invest).setOnClickListener(view -> {
                        if (mSession.getExchangeNseBseMfu().equalsIgnoreCase("1")) {
                            Bundle bundle = new Bundle();
                            Intent intent = new Intent(getActivity(), NseProfileActivity.class);
                            bundle.putString("type", "investmentProfile");
                            bundle.putString("transactionRoute", "clientHome");
                            intent.putExtras(bundle);
                            startActivity(intent);

                        } else if (mSession.getExchangeNseBseMfu().equalsIgnoreCase("2")) {
                            Bundle bundle = new Bundle();
                            Intent intent = new Intent(getActivity(), BseProfileActivity.class);
                            bundle.putString("type", "investmentProfile");
                            bundle.putString("transactionRoute", "clientHome");
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else if (mSession.getExchangeNseBseMfu().equalsIgnoreCase("3")) {
                            Bundle bundle = new Bundle();
                            Intent intent = new Intent(getActivity(), MfuProfileActivity.class);
                            bundle.putString("type", "investmentProfile");
                            bundle.putString("transactionRoute", "clientHome");
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else if (mSession.getExchangeNseBseMfu().equalsIgnoreCase("4")) {
                            Bundle bundle = new Bundle();
                            Intent intent = new Intent(getActivity(), BseProfileActivity.class);
                            bundle.putString("type", "investmentProfile");
                            bundle.putBoolean("nse2", true);
                            bundle.putString("transactionRoute", "clientHome");
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                    });
                } else {
                    view.findViewById(R.id.cv_invest_now).setVisibility(View.GONE);
                }
                if (currentValue == 0.0 && purchaseValue == 0.0) {
                    isNoData = true;
                    mCardViewSummary.setVisibility(View.GONE);
                    mLinerLineChart.setVisibility(View.GONE);
                    mLPairChart.setVisibility(View.GONE);
                    cvJounrny.setVisibility(View.GONE);
                } else {
                    mLinerLineChart.setVisibility(View.VISIBLE);
                    mLPairChart.setVisibility(View.VISIBLE);
                    mCardViewSummary.setVisibility(View.VISIBLE);
                    cvJounrny.setVisibility(View.VISIBLE);
                }
                if (mAppplication.isDaysChange) {
                    relOneDayChange.setVisibility(View.VISIBLE);
                    if (!jsonObjectMain.optString("oneDayChange").equalsIgnoreCase("null")) {
                        AppApplication.ONE_DAY_CHANGE = true;
                        double oneDayChange = jsonObjectMain.optDouble("oneDayChange");
                        Utils.setRuppesSymbol(mTvOneDayChange, oneDayChange, mActivity);

                        double changePercent = jsonObjectMain.optDouble("changePercent");
                        Utils.checkNegativeAndPositivePercentage(tvOneDayChangeInPercent, changePercent, mActivity);

                    } else {
//                        Utils.checkNegativeAndPositiveValue(mTvOneDayChange, 0.0, mActivity);
                        relOneDayChange.setVisibility(View.GONE);
                        AppApplication.ONE_DAY_CHANGE = false;
                    }

                } else {
                    relOneDayChange.setVisibility(View.GONE);
                }
                double gaine = jsonObjectMain.optDouble("gain");
                Utils.setRuppesSymbol(mTvGain, gaine, mActivity);

                double returnPercentage = jsonObjectMain.optDouble("returnPercentage");
                Utils.checkNegativeAndPositivePercentage(tvGainInPercentage, returnPercentage, mActivity);


              /*  if (!jsonObjectMain.optString("returnPercentage").equalsIgnoreCase("null")) {
                    double cgrValue = jsonObjectMain.optDouble("returnPercentage");
                    Utils.checkNegativeAndPositivePercentage(mTvAbsReturn, cgrValue, mActivity);
                } else {
                    mTvAbsReturn.setText("0%");
                }*/

                String userName = "";
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    userName = UtilityKotlin.getClientHopObject(mSession).optString("name");
                } else {
                    userName = mSession.getPersonName();
                }
                mTvUserName.setText(userName);

                if (jsonObjectMain.optBoolean("foliosUnderProcess")) {
                    llUpdation.setVisibility(View.VISIBLE);
                } else {
                    llUpdation.setVisibility(View.GONE);
                }
            }
        } catch (JSONException e) {
            Toast.makeText(getActivity(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

        }
    }


    private void setMaxNavDate() {
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MAX_NAVDATE ;
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                        mTvAsOndate.setVisibility(View.VISIBLE);
                        Config.asOnDate = "(as on " + UtilityKotlin.dateFormat2(jsonObjectMain.optString("navUpdatedUpTo")) + ")";
                        mTvAsOndate.setText(Config.asOnDate);

                    } else {
                        mTvAsOndate.setVisibility(View.GONE);
                    }
                } catch (JSONException e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderBeforeLogin(mSession);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        RequestQueue requestQueue;
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getOverallGainApi() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())) {
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }

        String url = "";
        try {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_DASHBOARD_XIRR + "investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "&levelNo=" + Utils.getSelectedLevelNo(mSession);

            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }
        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        String finalUrl= url;
        KtorHelper.requestCall(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                new KtorCallBack() {

                    @Override
                    public void onLoading(boolean isLoading){
                        if(isLoading){
                            mShimmerViewContainer.setVisibility(View.VISIBLE);
                            mLLFullBody.setVisibility(View.GONE);
                            mShimmerViewContainer.startShimmer();

                            pbLoaderOnArn.setVisibility(View.VISIBLE);

                            mTvOverallGainPercentage.setVisibility(View.GONE);
                            mTvOverallGain.setVisibility(View.GONE);

                        }
                        else{
                            mShimmerViewContainer.setVisibility(View.GONE);
                            mShimmerViewContainer.stopShimmer();
                            mLLFullBody.setVisibility(View.VISIBLE);

                            pbLoaderOnArn.setVisibility(View.GONE);

                            mTvOverallGainPercentage.setVisibility(View.VISIBLE);
                            mTvOverallGain.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onSuccess(String response, int statusCode) {

                        insertApiData(finalUrl, "GET API CONTAINS REQUEST IN URL", response, TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()), Config.BAL_SUMMERY);
                        AppApplication.OVER_SUMMARY_SUMMARY = response;
                        setOverallGainValue();

                    }

                }

        );
    }

    private void showGainInfoDialog(String value) {
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(requireContext(), R.style.CustomAlertDialog);

        builder.setMessage(value);
        builder.setPositiveButton("OK", (dialog, which) -> dialog.dismiss());

        androidx.appcompat.app.AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


}
