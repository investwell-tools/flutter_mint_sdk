package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class FragPtSortingAdapter extends RecyclerView.Adapter<FragPtSortingAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private AppSession mSession;
    private Context mContext;
    private OnItemClickListener listener;
    AppApplication mAppplication;
    private NumberFormat format;

    public FragPtSortingAdapter(Context context, ArrayList<JSONObject> list, OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mSession = AppSession.getInstance(mContext);
        mAppplication = (AppApplication) context.getApplicationContext();
        format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.portfolio_sorting_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);

        void onSchemeClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tvSchemeName, tvFolio, tvMarketValue, tvDividentInt, tvGain, tvCagr,tvPurchaseValue,
                tvAverageDays, tvAbsReturn, tvOneDayChange, tvPurchaseLevel, tvCagrLavel;

        private LinearLayout llLine3, llDivident;
        private RelativeLayout llLine4;


        public ViewHolder(View view) {
            super(view);
             tvSchemeName = view.findViewById(R.id.tvSchemeName);
             tvFolio = view.findViewById(R.id.tvFolio);
             tvMarketValue = view.findViewById(R.id.tvMarketValue);
             tvDividentInt = view.findViewById(R.id.tvDividentInt);

             tvGain = view.findViewById(R.id.tvGain);
             tvCagr = view.findViewById(R.id.tvCagr);
             tvPurchaseValue = view.findViewById(R.id.tvPurchaseValue);
             tvAverageDays = view.findViewById(R.id.tvAverageDays);
             tvAbsReturn = view.findViewById(R.id.tvAbsReturn);
             tvOneDayChange = view.findViewById(R.id.tvOneDayChange);
             llLine3 = view.findViewById(R.id.llLine3);
             llLine4 = view.findViewById(R.id.llLine4);
             tvPurchaseLevel = view.findViewById(R.id.tvPurchaseLevel);
             tvCagrLavel = view.findViewById(R.id.tvCagrLavel);
            llDivident = view.findViewById(R.id.llDivident);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                final JSONObject innerObject = mDataList.get(position);
                tvSchemeName.setText(innerObject.optString("schemeName"));
                if (mSession.getHasShowXirr()) {
                    llLine3.setVisibility(View.GONE);
                    llLine4.setVisibility(View.GONE);
                    tvCagrLavel.setText(mContext.getString(R.string.overall_gain));
                    if (mSession.getHideXirr().equals("0")) {
                        tvPurchaseLevel.setText(mContext.getString(R.string.XIRR));
                    } else {
                        tvPurchaseLevel.setVisibility(View.GONE);
                        tvPurchaseValue.setVisibility(View.GONE);
                    }
                    tvFolio.setText("["+innerObject.optString("folioNo")+"]");

                    UtilityKotlin.safeDisplayXirrPercentValue(innerObject, "XIRR", "-", "%", 2, true, tvPurchaseValue);

                    double gain = innerObject.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(tvGain,gain,mContext);


                /*    double gain = innerObject.optDouble("gain");
                    String gainStr = format.format(gain);
                    tvCagrGainValue.setText(gainStr);

                    if (gain>0){
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    }else{
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }*/

                    double currentValue = innerObject.optDouble("currentValue");
                    String currentValueStr = format.format(currentValue);
                    tvMarketValue.setText(currentValueStr);

                    double changePercent2 = innerObject.optDouble("changePercent");
                    String changePercentStr2 = String.format("%.2f", changePercent2) + "%";

                    if(mAppplication.isDaysChange) {
                        double oneDayChange2 = innerObject.optDouble("oneDayChange");
                        String oneDayChange2Str = format.format(oneDayChange2);
                        String finalValueStr2 = oneDayChange2Str + " (" + changePercentStr2 + ")";
                        tvOneDayChange.setText(finalValueStr2);
                        tvOneDayChange.setVisibility(View.VISIBLE);
                        if (oneDayChange2 == 0) {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black_white));
                        }else if (oneDayChange2 > 0) {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        } else {
                            tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        }
                    }else{
                        tvOneDayChange.setVisibility(View.GONE);
                    }


                } else {
                    llLine3.setVisibility(View.VISIBLE);
                    llLine4.setVisibility(View.VISIBLE);
                    tvCagrLavel.setText(mContext.getString(R.string.gain_cgr));
                    tvPurchaseLevel.setText(mContext.getString(R.string.purchase_value));
                    JSONObject schemeSummary = innerObject.optJSONObject("summary");

                    double purchaseValue = schemeSummary.optDouble("purchaseValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvPurchaseValue.setText(strPurchaseValue);

                    double dividend = schemeSummary.optDouble("dividend");
                    if (dividend>0) {
                        String strdividend = format.format(dividend);
                        tvDividentInt.setText(strdividend);
                        llDivident.setVisibility(View.VISIBLE);
                    }else{
                        llDivident.setVisibility(View.GONE);
                    }

                    double gain = schemeSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(tvGain,gain,mContext);

                    double cgrValue = schemeSummary.optDouble("CAGR");
                    Utils.checkNegativeAndPositiveWithSign(tvCagr, cgrValue, mContext);

                  /*  double cgrValue = schemeSummary.optDouble("CAGR");
                    String data2 = String.format("%.2f", cgrValue) + "%";
                    double totalGain = schemeSummary.optDouble("gain");
                    String gainValueStr = format.format(totalGain);
                    String finalValueStr = gainValueStr + " (" + data2 + ")";
                    tvCagrGainValue.setText(finalValueStr);
                    if (totalGain>0){
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    }else{
                        tvCagrGainValue.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }*/

                    try {
                        double avgHoldingDays = schemeSummary.optDouble("avgHoldingDays");
                        long rounded = Math.round(avgHoldingDays);
                        int days = (rounded <= Integer.MAX_VALUE) ? (int) rounded : Integer.MAX_VALUE;
                        tvAverageDays.setText("" + days);
                    }catch (Exception e){
                        tvAverageDays.setText("");
                    }

                    double absoluteReturn = schemeSummary.optDouble("absoluteReturn");
                    String data3 = String.format("%.2f", absoluteReturn) + "%";
                    tvAbsReturn.setText(data3);

                    double currentValue = schemeSummary.optDouble("currentValue");
                    String currentValueStr = format.format(currentValue);
                    tvMarketValue.setText(currentValueStr);

                    double changePercent2 = schemeSummary.optDouble("changePercent");
                    String changePercentStr2 = String.format("%.2f", changePercent2) + "%";

                    double oneDayChange2 = schemeSummary.optDouble("oneDayChange");
                    String oneDayChange2Str = format.format(oneDayChange2);
                    String finalValueStr2 = oneDayChange2Str + " (" + changePercentStr2 + ")";
                    tvOneDayChange.setText(finalValueStr2);
                    if (oneDayChange2 ==0){
                        tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.black_white));
                    }else if (oneDayChange2>0){
                        tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                    }else{
                        tvOneDayChange.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                    }
                    tvFolio.setText("["+innerObject.optString("folioNo")+"]");


                }

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // listener.onItemClick(position);
                        try {
                            ClientActivity activty = (ClientActivity) mContext;
                            Bundle bundle1 = new Bundle();
                            bundle1.putString("data", innerObject.toString());
                            bundle1.putString("isAnimation", "true");
                            if (innerObject.has("name")) {
                                bundle1.putString("applicant_name", innerObject.optString("name"));
                            } else {
                                bundle1.putString("applicant_name", innerObject.optString("applicantName"));
                            }

                            activty.displayViewOther(31, bundle1);
                        } catch (Exception e) {

                        }
                    }
                });

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }



        }

    }


    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
