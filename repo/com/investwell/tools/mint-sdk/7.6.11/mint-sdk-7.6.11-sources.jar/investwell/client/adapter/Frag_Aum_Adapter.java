package investwell.client.adapter;

import static android.content.Context.INPUT_METHOD_SERVICE;


import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.NoConnectionError;
import com.android.volley.VolleyError;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.activity.LoginActivity;
import investwell.client.activity.ClientActivity;
import investwell.di.viewmodel.ApiClient;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class Frag_Aum_Adapter extends RecyclerView.Adapter<Frag_Aum_Adapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private Frag_Aum_Adapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private String mType = "";
    private AppSession mSession;
    private final AppApplication appApplication;

    public Frag_Aum_Adapter(Context context, ArrayList<JSONObject> list, Frag_Aum_Adapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        appApplication = (AppApplication) context.getApplicationContext();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.frag_aum_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSchemeName, tvAmount, tvAllocation, tvNameLavel;
        ImageView next_arrow;

        public ViewHolder(View view) {
            super(view);
            tvSchemeName = view.findViewById(R.id.tvSchemeName);
            tvAmount = view.findViewById(R.id.tvAmount);
            tvAllocation = view.findViewById(R.id.tvAllocation);
            tvNameLavel = view.findViewById(R.id.tvNameLavel);
            next_arrow = view.findViewById(R.id.next_arrow);

        }


        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObject = mDataList.get(position);
                mSession = AppSession.getInstance(mContext);
                if (mType.equalsIgnoreCase("data_by_fund")){
                    next_arrow.setVisibility(View.VISIBLE);
                    tvNameLavel.setText(mContext.getString(R.string.fund_name));
                }else if (mType.equalsIgnoreCase("data_by_scheme")){
                    next_arrow.setVisibility(View.VISIBLE);
                    tvNameLavel.setText(mContext.getResources().getString(R.string.cardview_top_name_color));
                }else if (mType.equalsIgnoreCase("data_by_user")){
                    next_arrow.setVisibility(View.VISIBLE);
                    tvNameLavel.setText(mContext.getResources().getString(R.string.name));
                }else if (mType.equalsIgnoreCase("Y")){
                    next_arrow.setVisibility(View.GONE);
                }

                tvSchemeName.setText(jsonObject.optString("name"));

                double AUM = jsonObject.optDouble("AUM");
                String strAUM = format.format(AUM);
                tvAmount.setText(strAUM);

                double cgrValue = jsonObject.optDouble("allocation");
                String data2 = String.format("%.2f", cgrValue) + "%";
                tvAllocation.setText(data2);
                String name = Utils.setFirstLetterCapital(jsonObject.optString("name"));
                final String phoneNumber = jsonObject.optString("mobile");

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mType.equalsIgnoreCase("data_by_user")){
                            callPermissionsApi(name,phoneNumber,jsonObject);
                            // AppApplication.DASHBOARD_BROKER = "";
                            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(INPUT_METHOD_SERVICE);
                            imm.hideSoftInputFromWindow(v.getWindowToken(), InputMethodManager.RESULT_UNCHANGED_SHOWN);
                        }else if (!mType.equalsIgnoreCase("Y")) {
                            listener.onItemClick(position);
                        }
                    }
                });

            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }



        }

    }

    private void callPermissionsApi(String name,String phoneNumber,JSONObject jsonObject) {
        String uId = "";
        String levelNo = "";
        String url = "";
        JSONObject selectedUser = new JSONObject();
        try {
            uId = jsonObject.optString("uid");
            levelNo = jsonObject.optString("levelNo");
            if (selectedUser != null) {
                selectedUser.put("uid", uId);
                selectedUser.put("levelNo", levelNo);
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.CLIENT_ALLOWED_FEATURES +selectedUser;
        } catch (Exception e){if (BuildConfig.DEBUG)
                        e.printStackTrace();}

        ApiClient client = new ApiClient(mContext,mSession);
        client.makeGetRequest(url,
                isLoading->{
                if (isLoading){
                    ProgressBarCommon.showDialog(mContext);
                }else {
                    ProgressBarCommon.dismissDialog();
                }
                    return null;
                }, response->{
                    JSONObject jsonObjectRes = null;
                    try {
                        jsonObjectRes = new JSONObject(response);
                        JSONObject resultData = jsonObjectRes.optJSONObject("result");
                        if (jsonObjectRes.optInt("status") == 0) {

                            if (resultData != null) {
                                AppApplication.TMP_ALLOWED_FEATURED = resultData.toString();
                            }

                            try {
                                mSession.setClientObject(jsonObject.toString());
                                Log.d("client_object_clear", "data Assigned: Frag_Aum_adapter");
                                AppApplication.CLIENT_DASHBOARD_BAL_SUMMARY = "";
                                AppApplication.DASHBOARD_PORTFOLIO = "";
                                AppApplication.DASHBOARD_PORTFOLIO_FD = "";
                                AppApplication.DASHBOARD_PORTFOLIO_ASSERT = "";
                                // AppApplication.DASHBOARD_BROKER = "";
                                AppApplication.DASHBOARD_TRAN_MEMBERS = "";
                                AppApplication.COMING_FROM_PATH = AppConstants.CLIENT_USER;
                                mSession.setPersonName(name);
                                mSession.setUserMob(phoneNumber);

                                Intent intent = new Intent(mContext, ClientActivity.class);
                                intent.putExtra("coming_from", "broker");
                                mContext.startActivity(intent);
                            } catch (Exception e) {
                                if (BuildConfig.DEBUG)
                        e.printStackTrace();
                            }


                        } else {
                            String errorMessge = jsonObjectRes.optString("message");
                            if (!errorMessge.equalsIgnoreCase("invalid request"))
                                Toast.makeText(mContext, errorMessge, Toast.LENGTH_SHORT).show();
                        }
                    }catch (Exception e){

                    }
                    return null;
                }, volleyError -> {

//                    if (mBar != null)
//                        mBar.dismiss();
                    if (volleyError.networkResponse != null && volleyError.networkResponse.data != null) {
                        VolleyError error = new VolleyError(new String(volleyError.networkResponse.data));
                        try {
                            JSONObject jsonObject2 = new JSONObject(error.getMessage());
                            Toast.makeText(mContext, jsonObject2.optString("error"), Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    } else if (volleyError instanceof NoConnectionError) {
                        Toast.makeText(mContext, mContext.getResources().getString(R.string.no_internet), Toast.LENGTH_LONG).show();
                    } else {
                        String error = volleyError.getLocalizedMessage();
                    }

                    return null;
                },status->{
                    if (status == 401) {
                        appApplication.showCommonDailog(mContext, mContext.getString(R.string.txt_session_expired), mContext.getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                    }
                    return null;
                });

    }


    public void updateList(List<JSONObject> list, String type) {
        mDataList.clear();
        mDataList.addAll(list);
        mType = type;
        notifyDataSetChanged();
    }

}
