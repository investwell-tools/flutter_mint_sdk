package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.List;

import investwell.utils.AppSession;


public class DashboardMenuAdapterV2 extends RecyclerView.Adapter<DashboardMenuAdapterV2.MyViewHolder> {
    private Context mContext;
    public List<JSONObject> mDataList;
    private DashboardMenuListener dashListener;
    private AppSession mSession;

    public DashboardMenuAdapterV2(Context context, List<JSONObject> financialToolList, DashboardMenuListener dashListeners) {
        this.mDataList = financialToolList;
        mContext = context;
        dashListener = dashListeners;
        mSession = AppSession.getInstance(mContext);
    }

    @NonNull
    @Override
    public DashboardMenuAdapterV2.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_row_dashboard_menu, parent, false);

        return new DashboardMenuAdapterV2.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(DashboardMenuAdapterV2.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        JSONObject jsonObject = mDataList.get(position);
        holder.tvFinancialTerms.setText(jsonObject.optString("ChildTitle"));

        /*if (position==0 && mSession.getUserBrokerDomain().equalsIgnoreCase("wmggroup")){
            holder.ivMenuIcons.setImageResource(R.mipmap.menu11);
        }else{
            holder.ivMenuIcons.setImageResource(jsonObject.optInt("MenuIcon"));
        }*/
        holder.ivMenuIcons.setImageResource(jsonObject.optInt("MenuIcon"));


        holder.llFinancialTools.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dashListener.onToolsClick(jsonObject.optString("ChildCode"));
                dashListener.onToolsPosClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public interface DashboardMenuListener {
        void onToolsClick(String menuId);
        void onToolsPosClick(int pos);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvFinancialTerms;
        LinearLayout llFinancialTools;
        ImageView ivMenuIcons;

        public MyViewHolder(View view) {
            super(view);
            tvFinancialTerms = view.findViewById(R.id.tv_dashboard_menu_title);
            llFinancialTools=view.findViewById(R.id.ll_menu);
            ivMenuIcons=view.findViewById(R.id.iv_menu_icons);
        }
    }
}
