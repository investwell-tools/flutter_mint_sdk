package investwell.utils;


import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import com.android.volley.NetworkResponse;
import com.android.volley.toolbox.HttpHeaderParser;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import investwell.activity.AppApplication;

public class Utils {

    public static final String[] place_of_birth = new String[]
            {"Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh",
                    "Chhattisgarh", "Dadra and Nagar Haveli", "Daman and Diu", "Goa", "Gujarat", "Haryana", "Himachal Pradesh",
                    "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra",
                    "Manipur", "Meghalaya", "Mizoram", "Nagaland", "New Delhi", "ODISHA", "OMAN", "Others", "Puducherry", "Punjab",
                    "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal"};
    public static final String[] place_of_birth_code = new String[]{"AN", "AP", "AR", "AS", "BH", "CH", "CG", "DN", "DD", "GO", "GU", "HA",
            "HP", "KR", "JD", "KA", "KE", "LD", "MP", "MA", "MN", "ME", "MI", "NA", "ND", "OD", "OM", "OT", "PO", "PU", "RA", "SI",
            "TN", "TE", "TR", "UP", "UR", "WB"};
    public static final String[] occupation_code = new String[]{"01", "02", "03", "04", "05", "06", "07", "08"};
    public static final String[] occupation_code_MFU = new String[]{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "99"};
    public static final String[] holding_code = new String[]{"SI", "JO", "AS"};
    public static final String[] holding_name = new String[]{"Single", "Joint", "Survivor"};
    public static final String[] email_relation = new String[]{"Self", "Family"};
    public static final String[] holding_name_broker = new String[]{"Single", "Anyone or Survivor", "Joint"};
    public static final String[] holding_code_broker = new String[]{"SI", "AS", "JO"};
    public static final String[] nominee_auth_mode = new String[]{"OTP Authentication"};
    public static final String[] email_mobile_relation = new String[]{"SELF", "SPOUSE", "DEPENDENT CHILDREN", "DEPENDENT SIBLINGS", "DEPENDENT PARENTS", "GUARDIAN", "PMS", "CUSTODIAN", "POA"};
    public static final String[] email_mobile_relation_mfu = new String[]{"SELF", "SPOUSE", "DEPENDENT CHILDREN", "DEPENDENT SIBLINGS", "DEPENDENT PARENTS"};
    public static final String[] email_mobile_relation_code_mfu = new String[]{"SE", "SP", "DC", "DS", "DP"};
    public static final String[] guardian_minor_email_mobile_relation_mfu = new String[]{"SELF", "DEPENDENT SIBLINGS", "GUARDIAN"};
    public static final String[] guardian_minor_email_mobile_relation_code_mfu = new String[]{"SE","DS","GD"};
    public static final String[] email_mobile_relation_code = new String[]{"SE", "SP", "DC", "DS", "DP", "GD", "PM", "CD", "PO"};
    public static final String[] guardian_relation = new String[]{"Father", "Mother", "Court Appointed Legal Guardian"};
    public static final String[] guardian_relationship_mfu_fmc= new String[]{"Father","Mother","Court Appointed Legal Guardian"};
    public static final String[] guardian_relationship_proof_mfu= new String[]{"Birth Certificate", "Ration Card","Passport", "PAN Card", "Court Order"};
    public static final String[] guardian_relation_mfu = new String[] {
            "Father",                      // Code: MFU24
            "Mother",                      // Code: MFU25
            "Court appointed legal guardian", // Code: MFU26
            //acc to new doc below relations were removed
//            "Aunt",                        // Code: MFU27
//            "Brother-in-law",              // Code: MFU28
//            "Brother",                     // Code: MFU29
//            "Daughter",                    // Code: MFU30
//            "Daughter-in-law",             // Code: MFU31
//            "Father-in-law",               // Code: MFU32
//            "Grand daughter",              // Code: MFU33
//            "Grand father",                // Code: MFU34
//            "Grand mother",                // Code: MFU35
//            "Grand son",                   // Code: MFU36
//            "Mother-in-law",               // Code: MFU37
//            "Nephew",                      // Code: MFU38
//            "Niece",                       // Code: MFU39
//            "Sister",                      // Code: MFU40
//            "Sister-in-law",               // Code: MFU41
//            "Son",                         // Code: MFU42
//            "Son-in-law",                  // Code: MFU43
//            "Spouse",                      // Code: MFU44
//            "Uncle",                       // Code: MFU45
//            "Others"                       // Code: MFU46
    };


    public static final String[] guardian_relation_code = new String[]{"F","M","C"};
    public static final String[] guardian_relation_code_bse = new String[]{"06","13","23"};
    public static final String[] guardian_relationship_code_mfu_fmc = new String[]{"01","02","03"};
    public static final String[] guardian_relationship_proof_code_mfu= new String[]{"01","02","03","04","05"};
    public static final String[] guardian_relation_code_mfu = new String[]{
            "MFU24", // FATHER
            "MFU25", // MOTHER
            "MFU26", // COURT APPOINTED LEGAL GUARDIAN
            //acc to new doc belowe changes were removed
//            "MFU27", // AUNT
//            "MFU28", // BROTHER-IN-LAW
//            "MFU29", // BROTHER
//            "MFU30", // DAUGHTER
//            "MFU31", // DAUGHTER-IN-LAW
//            "MFU32", // FATHER-IN-LAW
//            "MFU33", // GRAND DAUGHTER
//            "MFU34", // GRAND FATHER
//            "MFU35", // GRAND MOTHER
//            "MFU36", // GRAND SON
//            "MFU37", // MOTHER-IN-LAW
//            "MFU38", // NEPHEW
//            "MFU39", // NIECE
//            "MFU40", // SISTER
//            "MFU41", // SISTER-IN-LAW
//            "MFU42", // SON
//            "MFU43", // SON-IN-LAW
//            "MFU44", // SPOUSE
//            "MFU45", // UNCLE
//            "MFU46"  // OTHERS
    };

    public static final Map<String, String> nomineeRelationMap = new HashMap<>() {{
        put("01", "Aunt");
        put("02", "Brother-in-law");
        put("03", "Brother");
        put("04", "Daughter");
        put("05", "Daughter-in-law");
        put("06", "Father");
        put("07", "Father-in-law");
        put("08", "Grand daughter");
        put("09", "Grand father");
        put("10", "Grand mother");
        put("11", "Grand son");
        put("12", "Mother-in-law");
        put("13", "Mother");
        put("14", "Nephew");
        put("15", "Niece");
        put("16", "Sister");
        put("17", "Sister-in-law");
        put("18", "Son");
        put("19", "Son-in-law");
        put("20", "Spouse");
        put("21", "Uncle");
        put("22", "Others");
    }};


    public static final String[] nominee_Relation_code_bse = new String[]{
            "01", // Aunt
            "02", // Brother-in-law
            "03", // Brother
            "04", // Daughter
            "05", // Daughter-in-law
            "06", // Father
            "07", // Father-in-law
            "08", // Grand daughter
            "09", // Grand father
            "10", // Grand mother
            "11", // Grand son
            "12", // Mother-in-law
            "13", // Mother
            "14", // Nephew
            "15", // Niece
            "16", // Sister
            "17", // Sister-in-law
            "18", // Son
            "19", // Son-in-law
            "20", // Spouse
            "21", // Uncle
            "22"  // Others
    };
    public static final String[] nominee_Relation_code_mfu = new String[]{
            "MFU01", // FATHER
            "MFU02", // MOTHER
            "MFU03", // COURT APPOINTED LEGAL GUARDIAN
            "MFU04", // AUNT
            "MFU05", // BROTHER-IN-LAW
            "MFU06", // BROTHER
            "MFU07", // DAUGHTER
            "MFU08", // DAUGHTER-IN-LAW
            "MFU09", // FATHER-IN-LAW
            "MFU10", // GRAND DAUGHTER
            "MFU11", // GRAND FATHER
            "MFU12", // GRAND MOTHER
            "MFU13", // GRAND SON
            "MFU14", // MOTHER-IN-LAW
            "MFU15", // NEPHEW
            "MFU16", // NIECE
            "MFU17", // SISTER
            "MFU18", // SISTER-IN-LAW
            "MFU19", // SON
            "MFU20", // SON-IN-LAW
            "MFU21", // SPOUSE
            "MFU22", // UNCLE
            "MFU23"  // OTHERS
    };


    // Array for corresponding relations
    public static final String[] nominee_relation_list = new String[]{
            "Aunt",
            "Brother-in-law",
            "Brother",
            "Daughter",
            "Daughter-in-law",
            "Father",
            "Father-in-law",
            "Grand daughter",
            "Grand father",
            "Grand mother",
            "Grand son",
            "Mother-in-law",
            "Mother",
            "Nephew",
            "Niece",
            "Sister",
            "Sister-in-law",
            "Son",
            "Son-in-law",
            "Spouse",
            "Uncle",
            "Others"
    };
    public static final String[] nominee_relation_list_mfu = {
            "Father", // MFU01
            "Mother", // MFU02
            "Court Appointed Legal Guardian", // MFU03
            "Aunt", // MFU04
            "Brother-in-Law", // MFU05
            "Brother", // MFU06
            "Daughter", // MFU07
            "Daughter-in-Law", // MFU08
            "Father-in-Law", // MFU09
            "Grand Daughter", // MFU10
            "Grand Father", // MFU11
            "Grand Mother", // MFU12
            "Grand Son", // MFU13
            "Mother-in-Law", // MFU14
            "Nephew", // MFU15
            "Niece", // MFU16
            "Sister", // MFU17
            "Sister-in-Law", // MFU18
            "Son", // MFU19
            "Son-in-Law", // MFU20
            "Spouse", // MFU21
            "Uncle", // MFU22
            "Others" // MFU23
    };
    public static final String[] process_mode = new String[]{"Digital", "Physical"};
    public static final String[] process_mode_code = new String[]{"D", "P"};
    public static final String[] occupation_name_list = new String[]{"Agriculturist","Business", "Business Manufacturing", "Business Trading",
            "Financial Institution", "Forex Dealer", "Government Body", "Government Service", "Housewife",
            "Insurance Company", "NPS TRUST", "Non-Government Service", "Not Specified", "Others", "PF Trust", "Private Sector Service",
            "Profession - Engineering", "Profession - Finance", "Profession - Legal", "Profession - Medicine", "Professional",
            "Public Sector / Government Service", "Retired", "Service", "Student"};
    public static final String[] occupation_code_list = new String[]{"4","1", "1A", "1B", "35", "43", "51", "2A", "6", "64",
            "50", "2B", "9", "8", "49", "41", "3C", "3B", "3D", "3A", "3", "42", "5", "2", "7"};

    public static final String[] occupation_name_list_mfu = new String[]{
            "Private Sector Service",
            "Public Sector",
            "Business",
            "Professional",
            "Agriculturist",
            "Retired",
            "Housewife",
            "Student",
            "Forex Dealer",
            "Government Service",
            "Doctor",
            "Others"};
    public static final String[] occupation_code_list_mfu = new String[]{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "99"};

    public static final String[] bank_proof_list_mfu = new String[]{ "Latest Bank Passbook", "Latest Bank Account Statement", "Cheque Copy", "Bank Letter"};
    public static final String[] bank_proof_list_code_mfu = new String[]{"14", "15", "77", "78"};


    public static boolean isTablet(Activity activity) {
        return (activity.getResources().getConfiguration().screenLayout
                & Configuration.SCREENLAYOUT_SIZE_MASK)
                >= Configuration.SCREENLAYOUT_SIZE_LARGE;
    }

    // Android 8.0+ throws IllegalStateException("Only fullscreen activities can request
    // orientation") when the activity isn't running fullscreen (split-screen/freeform
    // multi-window, or certain translucent/floating themes). There's no reliable public
    // check for the theme case, so skip in known multi-window mode and swallow the rest.
    public static void setRequestedOrientationSafely(Activity activity, int orientation) {
        try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !activity.isInMultiWindowMode()) {
                activity.setRequestedOrientation(orientation);
            }
        } catch (IllegalStateException ignored) {
        }
    }

    // Function to convert Set<String> to String[]
    public static String[] convert(Set<String> setOfString) {

        // Create String[]  from setOfString
        String[] arrayOfString = setOfString
                .toArray(new String[0]);

        // return the formed String[]
        return arrayOfString;
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

    }

    public static boolean isEmptyOrNull(String str) {
        return str == null || str.trim().isEmpty() || str.equalsIgnoreCase("null");
    }

    public static TextView formatToLacCrore(TextView textView, Double doubleValue, Context context) {
      //  NumberFormat numberFormat = NumberFormat.getInstance(Locale.getDefault());
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);

        String value = "";


        if (doubleValue >= 10000000) {
            numberFormat.setMaximumFractionDigits(2);
            numberFormat.setMinimumFractionDigits(2);
            value =  numberFormat.format(doubleValue / 10000000) + " Cr";
        } else if (doubleValue >= 100000) {
            numberFormat.setMaximumFractionDigits(2);
            numberFormat.setMinimumFractionDigits(2);
            value =  numberFormat.format(doubleValue / 100000) + " L";
        }else if (doubleValue >= 1000) {
            numberFormat.setMaximumFractionDigits(2);
            numberFormat.setMinimumFractionDigits(2);
            value =  numberFormat.format(doubleValue / 1000) + " K";
        } else {
            value =  numberFormat.format(doubleValue);
        }

        textView.setText(value);
        return textView;
    }

    public static List<String> getFeatureSettingByName(JSONArray jsonArray, String featureName) {
        List<String> featureSettings = new ArrayList<>();
        try {
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if (jsonObject.optString("FeatureName").equalsIgnoreCase(featureName)) {
                    String additionalSetting = jsonObject.optString("AdditionalSetting", "");
                    // Split the additional setting by commas and add to the list
                    if (!additionalSetting.isEmpty()) {
                        String[] settingsArray = additionalSetting.split(",");
                        for (String setting : settingsArray) {
                            featureSettings.add(setting.trim()); // Trim whitespace
                        }
                    }
                    break; // Exit loop once the feature is found
                }
            }
        } catch (JSONException e) {
            e.printStackTrace(); // Handle JSON exceptions
        }
        return featureSettings; // Return the list of settings
    }

    public static  List<String> getLanguageList(){
        List<String> languageList = new ArrayList<>();
        languageList.add("English");
        languageList.add("Hindi");
        languageList.add("Gujarati");
        languageList.add("Marathi");
        languageList.add("Telugu");
        languageList.add("Tamil");
        return languageList;
    }

    public static  List<String> getThemeList(){
       List<String> themeList = new ArrayList<>();
        themeList.add("System Default");
        themeList.add("Light");
        themeList.add("Dark");
       return themeList;
    }

    public static JSONObject getConfigData(AppSession mSession) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(!TextUtils.isEmpty(mSession.getAppConfig()) ? mSession.getAppConfig() : "");
        } catch (JSONException ignored) {

        }
        return jsonObject;
    }

    public static JSONObject responseHeader(NetworkResponse response) {
        JSONObject jsonObject = null;
        try {
            String json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
            jsonObject = new JSONObject(json);

        } catch (Exception e) {
            jsonObject = new JSONObject();
        }

        return jsonObject;
    }
    public static TextView setRuppesSymbol(TextView textView, Double doubleValue, Context context) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        textView.setTextColor(ContextCompat.getColor(context, R.color.black));

        if (Double.isNaN(doubleValue)) {
            doubleValue = 0.0;
        }

        String strTotalGain = format.format(doubleValue);
        // strTotalGain = strTotalGain.replace("-", "");
        textView.setText(strTotalGain);
        return textView;
    }

    public static TextView setRuppesSymbolLayout6(TextView textView, Double doubleValue, Context context) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        textView.setTextColor(ContextCompat.getColor(context, R.color.black));

        if (Double.isNaN(doubleValue)) {
            doubleValue = 0.0;
        }

        if (doubleValue == 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        } else if (doubleValue > 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.green2));
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.red_2));
        }

        String strTotalGain = format.format(doubleValue);
        // strTotalGain = strTotalGain.replace("-", "");
        textView.setText(strTotalGain);
        return textView;
    }

    public static String formatToLacCroreString(Float doubleValue) {
        NumberFormat numberFormat = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        numberFormat.setMinimumFractionDigits(0);
        numberFormat.setMaximumFractionDigits(0);

        String value = "";


        if (doubleValue >= 10000000) {
            numberFormat.setMaximumFractionDigits(2);
            numberFormat.setMinimumFractionDigits(2);
            value =  numberFormat.format(doubleValue / 10000000) + " Cr";
        } else if (doubleValue >= 100000) {
            numberFormat.setMaximumFractionDigits(2);
            numberFormat.setMinimumFractionDigits(2);
            value =  numberFormat.format(doubleValue / 100000) + " L";
        }else if (doubleValue >= 1000) {
            numberFormat.setMaximumFractionDigits(2);
            numberFormat.setMinimumFractionDigits(2);
            value =  numberFormat.format(doubleValue / 1000) + " K";
        } else {
            value =  numberFormat.format(doubleValue);
        }

        return value;
    }


  public static String getHasExchangeCode(AppSession session){
      String varableForBSeMfu = getSelectedExchange(session);
      if (varableForBSeMfu.equals("1")) {
          varableForBSeMfu = "&hasNseCode=true";
      }else if (varableForBSeMfu.equals("2")) {
          varableForBSeMfu = "&hasBseCode=true";
      } else if (varableForBSeMfu.equals("3")) {
          varableForBSeMfu = "&hasMfuCode=true";
      }else if (varableForBSeMfu.equals("4")) {
          varableForBSeMfu = "&hasNseInvestCode=true";
      }
      return varableForBSeMfu;
  }

    public static String getSelectedExchange(AppSession mSession) {
        String exchange = "";
        if (mSession.getHasLoging()) {
            if (mSession.getHasMultiExchange()) {
                exchange = AppApplication.sExchangeType;
                if (exchange.equals("")) {
                    exchange = mSession.getExchangeNseBseMfu();
                }
            } else {
                if (mSession.getHasNseOpted()) {
                    exchange = "1";
                } else if (mSession.getHasBseOpted()) {
                    exchange = "2";
                } else if (mSession.getHasMfuOpted()) {
                    exchange = "3";
                } else if (mSession.getHasNse2Opted()) {
                    exchange = "4";
                }  else {
                    exchange = mSession.getExchangeNseBseMfu();
                }
            }
        }else{
             exchange = mSession.getExchangeNseBseMfu();
        }
        return exchange != null ? exchange : "";
    }

    public static JSONObject getSelectedUserObject(AppSession mSession) {
        String uId = "";
        String levelNo = "";
        JSONObject jsonObject = new JSONObject();
        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                if (mSession.getClientObject().isEmpty()) {
                    uId = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                } else {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                }
            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }

            if (jsonObject != null) {
                jsonObject.put("uid", uId);
                jsonObject.put("levelNo", levelNo);
            }
        } catch (Exception e) {

        }
        return jsonObject;
    }
    public static Activity CurrentActivity(Activity activity1) {
        return activity1;
    }

    public static String getSelectedUid(AppSession mSession) {
        String uId = "";
        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                if (mSession.getClientObject().isEmpty()) {
                    uId = mSession.getUid();
                } else {
                    uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                }
            } else {
                uId = mSession.getUid();
            }

        } catch (Exception e) {

        }
        return uId;
    }

    public static String getSelectedLevelNo(AppSession mSession) {
        String levelNo = "";
        try {
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                if (mSession.getClientObject().isEmpty()) {
                    levelNo = mSession.getLevelNo();
                } else {
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                }
            } else {
                levelNo = mSession.getLevelNo();
            }

        } catch (Exception e) {

        }
        return levelNo;
    }


    public static ArrayList<JSONObject> getCustomLinks(AppSession mSession){
        JSONArray jsonArray = null;
        ArrayList<JSONObject> jsonObjects = new ArrayList<>();
        JSONObject appConfigObject;
        List<String> keywords = List.of("Policies & Agreements", "Grievance Redressal", "Legal & Regulatory");

        try {
            if (mSession.getAppInfo() != null && !TextUtils.isEmpty(mSession.getAppInfo())) {
                appConfigObject = new JSONObject(mSession.getAppInfo());
                String customLinks =  appConfigObject.isNull("customLinks") ? "" : appConfigObject.optJSONArray("customLinks").toString();
                if (customLinks.length() !=0){
                    jsonArray = new JSONArray(customLinks);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        jsonObject.put("ChildCode", "CustomSection");
                        String title = jsonObject.optString("title");
                        if (!keywords.contains(title)){
                            jsonObjects.add(jsonObject);
                        }
                    }
                }
            }else {
                new JSONObject();
            }


        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return jsonObjects;
    }

    public static TextView setRuppesSymbol2(TextView textView, Double doubleValue, Context context) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        textView.setTextColor(ContextCompat.getColor(context, R.color.colorGreen));

        if (Double.isNaN(doubleValue)) {
            doubleValue = 0.0;
        }

        String strTotalGain = format.format(doubleValue);
        // strTotalGain = strTotalGain.replace("-", "");
        textView.setText(strTotalGain);
        return textView;
    }


    public static String getAppType() {
        // 0 = mint
        // 1 = custom
      String appType = "";
        if (BuildConfig.LIBRARY_PACKAGE_NAME.equals("com.iw.mint.sdk")) {
            appType = "0";
        }else{
            appType = "1";
        }

        return appType;

    }


    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[a-zA-Z])(?=.*[0-9])(?=\\S+$).{8,}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }

    public static TextView checkNegativeAndPositiveValue(TextView textView, Double doubleValue, Context context) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        if (doubleValue == 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        } else if (doubleValue > 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.marketGreen));
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.red));
        }
        String strTotalGain = format.format(doubleValue);
        textView.setText(strTotalGain);
        return textView;
    }

    public static TextView checkNegativeAndPositiveValueLayout6(TextView textView, Double doubleValue, Context context) {
        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);

        if (doubleValue == 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        } else if (doubleValue > 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.green2));
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.red_2));
        }
        String strTotalGain = format.format(doubleValue);
        textView.setText(strTotalGain);
        return textView;
    }

    public static TextView checkNegativeAndPositiveWithSign(TextView textView, Double doubleValue, Context context) {

        try {
            if (doubleValue == 0) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.black));
            } else if (doubleValue > 0) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.marketGreen));
            } else {
                textView.setTextColor(ContextCompat.getColor(context, R.color.red));
            }
            if (Double.isNaN(doubleValue)) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.black));
                textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
                textView.setText("(" + 0.0 + ")");
            } else {
                String percentage = "";
                if (doubleValue > 0) {
                    percentage = String.format("%.2f",  doubleValue) + "%";
                    percentage = "+" +percentage;
                } else {
                    percentage = String.format("%.2f", doubleValue) + "%";
                }
                // percentage = percentage.replace("-", "");
                textView.setText("(" + percentage + ")");
            }
        }catch (Exception e){
            System.out.println(e.getLocalizedMessage());
        }
        return textView;
    }

    public static TextView checkNegativeAndPositiveWithSignLayout6(TextView textView, Double doubleValue, Context context) {

        try {
            if (doubleValue == 0) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.black));
            } else if (doubleValue > 0) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.green2));
            } else {
                textView.setTextColor(ContextCompat.getColor(context, R.color.red_2));
            }
            if (Double.isNaN(doubleValue)) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.black));
                textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
                textView.setText("0.0");
            } else {
                String percentage = "";
                percentage = String.format("%.2f",  doubleValue) + "%";
                textView.setText("" + percentage);
            }
        }catch (Exception e){
            System.out.println(e.getLocalizedMessage());
        }
        return textView;
    }


    public static TextView checkNegativeAndPositivePercentage(TextView textView, Double doubleValue, Context context) {

        if (doubleValue == 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        } else if (doubleValue > 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.marketGreen));
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.red));
        }
        if (Double.isNaN(doubleValue)) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
            textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
            textView.setText("(" + 0.0 + ")");
        } else {
            String percentage = String.format("%.2f", doubleValue) + "%";
            // percentage = percentage.replace("-", "");
            textView.setText("(" + percentage + ")");
        }
        return textView;
    }

    public static TextView checkNegativeAndPositivePercentageDarkGreen(TextView textView, Double doubleValue, Context context) {

        if (doubleValue == 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        } else if (doubleValue > 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.marketGreen));
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.red_for_dashboard));
        }
        if (Double.isNaN(doubleValue)) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
            textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
            textView.setText("("+0.0+")");
        } else{
            String percentage = String.format("%.2f", doubleValue) + "%";
            // percentage = percentage.replace("-", "");
            textView.setText("("+percentage+")");
        }
        return textView;
    }

    public static TextView checkNegativeAndPositivePercentageDarkGreenLayout6(TextView textView, Double doubleValue, Context context) {
        if (Double.isNaN(doubleValue)) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
            textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
            textView.setText("("+0.0+")");
        } else{
            if (doubleValue > 0) {
                textView.setTextColor(ContextCompat.getColor(context, R.color.green2));
            } else {
                textView.setTextColor(ContextCompat.getColor(context, R.color.red_2));
            }

            String percentage = String.format("%.2f", doubleValue) + "%";
            // percentage = percentage.replace("-", "");
            textView.setText("("+percentage+")");
        }
        return textView;
    }


    public static TextView checkNegativeAndPositivePercentageInBracket(TextView textView, Double doubleValue, Context context) {

        if (doubleValue == 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
        } else if (doubleValue > 0) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.green2));
            textView.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_arrow_drop_up_24), null);
        } else {
            textView.setTextColor(ContextCompat.getColor(context, R.color.red));
            textView.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_arrow_drop_down_24), null);
        }

        if (Double.isNaN(doubleValue)) {
            textView.setTextColor(ContextCompat.getColor(context, R.color.black));
            textView.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
            textView.setText("(" + 0.0 + ")");
        } else {
            String percentage = String.format("%.2f", doubleValue) + "%";
            textView.setText("(" + percentage + ")");
        }

        return textView;
    }


    public static String setFirstLetterCapital(String name) {
        String value = "";
        StringBuffer capBuffer = new StringBuffer();
        Matcher capMatcher = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(name);
        while (capMatcher.find()) {
            capMatcher.appendReplacement(capBuffer, capMatcher.group(1).toUpperCase() + capMatcher.group(2).toLowerCase());
        }
        value = capMatcher.appendTail(capBuffer).toString();
        if (value.equals("Null")){
            value = "";
        }

        return value;
    }

    public static String nullStringHandle(Context context, String value) {
        String returnValue = "";
        if (value.equals("") || value.equalsIgnoreCase("null")) {
            returnValue = context.getString(R.string.not_available);
        } else {
            returnValue = setFirstLetterCapital(value);
        }
        return returnValue;
    }


    public static void hideKeyBoardFromAnyWhere(Context context) {
        InputMethodManager inputManager =
                (InputMethodManager) context.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(new View(context).getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

    }

    public static String getSchemeIdFromAll(JSONObject jsonObject) {
        String schemeId = "";
        if (jsonObject.has("schemeId")) {
            schemeId = jsonObject.optString("schemeId");
        } else if (jsonObject.has("schemeid")) {
            schemeId = jsonObject.optString("schemeid");
        } else if (jsonObject.has("schid")) {
            schemeId = jsonObject.optString("schid");
        }

        return schemeId;
    }

    public static String formatedDate(String unFormatedDate) {
        String formatedDate = "";
        try {
            //2019-05-06T18:30:00.000Z
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy",new Locale("en","in"));
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));


            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }

    public static String formatedDateWithoutDash(String unFormatedDate) {
        String formatedDate = "";
        try {
            //2019-05-06T18:30:00.000Z
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM yyyy",new Locale("en","in"));
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));


            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }

    public static int daysCount(String unFormatedDate) {
        int days = 0;

        try {
            //2019-05-06T18:30:00.000Z
            Calendar calendar =Calendar.getInstance();
            long todayTimiinMilliSecond = calendar.getTimeInMillis();

            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy");
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));

            Date date = inputFormat.parse(unFormatedDate);
            long givenDateInMilli = date.getTime();
            long difference = givenDateInMilli- todayTimiinMilliSecond;
            days = (int) (difference/(1000*60*60*24));
        } catch (Exception e) {

        }
        return days;
    }

    public static String formatedDate3(String unFormatedDate) {
        String formatedDate = "";
        try {
            //2019-05-06T18:30:00.000Z
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));


            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }

    public static String formatedDate4(String unFormatedDate) {
        String formatedDate = "";
        try {
            //2019-05-06T18:30:00.000Z
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));


            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }




    public static String formatedDateddMMMyyyy2(String unFormatedDate) {
        String formatedDate = "";
        try {
            // "date":"2017-06-12"
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMM yyyy");
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }

    public static String formatedDate5(String unFormatedDate) {
        String formatedDate = "";
        try {
            //2019-05-06T18:30:00.000Z
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));


            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }

    public static String formatedDateFullMonth(String unFormatedDate) {
        String formatedDate = "";
        try {
            //2019-05-06T18:30:00.000Z
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd MMMM hh:mm a");
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }

    public static String getTodayDateString() {
        String todayDate = "";
        try {
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
            todayDate = outputFormat.format(new Date());
        } catch (Exception e) {

        }
        return todayDate;
    }
    public static String getTodayDateString2() {
        String todayDate = "";
        try {
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
            todayDate = outputFormat.format(new Date());
        } catch (Exception e) {

        }
        return todayDate;
    }

    public static Date getTodayDate(String date) {
        Date afterFormat = null;
        try {
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy");
            afterFormat = outputFormat.parse(date);
        } catch (Exception e) {

        }
        return afterFormat;
    }

    public static String formatedDate2(String unFormatedDate) {
        String formatedDate = "";
        try {
            // "date":"2017-06-12"
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            inputFormat.setTimeZone(TimeZone.getTimeZone("UTC"));

            SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-yyyy");
            outputFormat.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
            Date date = inputFormat.parse(unFormatedDate);
            formatedDate = outputFormat.format(date);
        } catch (Exception e) {

        }
        return formatedDate;
    }


    //OPT STRING
    public static String optString(JSONObject json, String key) {

        if (json.isNull(key))
            return null;
        else
            return json.optString(key, null);
    }

    public static boolean txnTypeColor(String name) {
        boolean isColorRed = false;
        try {
            if (name.equals("SWO") || name.equals("SWP")) {
                //Red
                isColorRed = true;
            } else if (name.equals("NRS") || name.equals("ESS") || name.equals("EBS")) {
                //Red
                isColorRed = true;
            } else if (name.equals("STO")) {
                //Red
                isColorRed = true;
            } else {
                isColorRed = false;
            }


        } catch (Exception e) {

        }
        return isColorRed;
    }


    public static String SchemeNameFormat(String name) {
        String formatedName = "";
        try {
            if (name.equals("SWI")) {
                formatedName = "Switch In";
            } else if (name.equals("DVP")) {
                formatedName = "Dividend Payout";
            } else if (name.equals("SWO")) {
                //Red
                formatedName = "Switch Out";
            } else if (name.equals("NRP") || name.equals("ESP") || name.equals("EBP")) {
                formatedName = "Purchase";
            } else if (name.equals("DIR")) {
                formatedName = "Dividend Reinvestment";
            } else if (name.equals("NRS") || name.equals("ESS") || name.equals("EBS")) {
                //Red
                formatedName = "Sell";
            } else if (name.equals("BON") || name.equals("BOB")|| name.equals("BOS")) {
                formatedName = "Bonus";
            } else if (name.equals("STI")) {
                formatedName = "Systematic Transfer In";
            } else if (name.equals("STO")) {
                //Red
                formatedName = "Systematic Transfer Out";
            } else if (name.equals("POS")) {
                formatedName = "Dividend Paid";
            } else if (name.equals("POB")) {
                formatedName = "Interest";
            } else if (name.equals("SI")) {
                formatedName = "Single";
            } else if (name.equals("JO")) {
                formatedName = "Joint";
            } else if (name.equals("AS")) {
                formatedName = "Anyone or Survivor";
            } else if (name.equals("ES")) {
                formatedName = "Either or Survivor";
            } else {
                formatedName = name;
            }


        } catch (Exception e) {

        }
        return formatedName;
    }


    public static void applySelectedTheme(String theme, AppSession mSession) {
        mSession.setTheme(theme);
        switch (theme) {
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }
    }

    public static void setTheme(Context context, AppSession mSession) {
        if (context.getString(R.string.dark_theme_enabled).equals("false")) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            return;
        }
        switch (mSession.getTheme()) {
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }

    }


}
