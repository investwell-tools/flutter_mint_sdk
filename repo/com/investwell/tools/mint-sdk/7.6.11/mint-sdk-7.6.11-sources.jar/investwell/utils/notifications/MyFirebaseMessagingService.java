package investwell.utils.notifications;


import static investwell.di.core.LogExtKt.logD;
import static investwell.di.core.LogExtKt.logE;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import investwell.activity.AppApplication;
import investwell.activity.LoginActivity;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;


/**
 * Created by Binesh on 5/27/2016.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    public static final String INTENT_FILTER = "INTENT_FILTER";
    public static final int NOTIFICATION_ID = 1001;

    @Override
    public void onNewToken(@NonNull String s) {
        super.onNewToken(s);
        AppSession appSession = AppSession.getInstance(getApplication());
        appSession.setFcmToken(s);
        logD("fcm : newTOken");
        if (!getString(R.string.subdomain).equals("mint")) {
            String topicName = "mintandroid" + getApplicationContext().getString(R.string.subdomain);
            FirebaseMessaging.getInstance().subscribeToTopic(topicName);
        }
    }

    @Override
    public void onMessageReceived(@NotNull RemoteMessage remoteMessage) {
        try {
            logD("fcm : getData payload "+remoteMessage.getData());
            logD("fcm : getNotification payload "+remoteMessage.getNotification());
            Map<String, String> params = remoteMessage.getData();
            JSONObject object = new JSONObject(params);

            if (!object.has("title") || !object.has("text")) {
                RemoteMessage.Notification notification = remoteMessage.getNotification();
                if (notification != null) {
                    object.put("title", notification.getTitle());
                    object.put("text", notification.getBody());
                    object.put("body", notification.getBody());
                }
            }

            notificationNewPattern(object,
                    AppSession.getInstance(getApplication()),
                    getApplicationContext(),
                    null);

        } catch (Exception e) {
            logE("fcm "+e.getMessage());
        }
    }

    public static String getCurrentFormattedDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    private int getUnreadNotificationCount(AppSession session) {
        int unreadCount = 0;
        try {
            if (!session.getNotification().isEmpty()) {
                JSONArray jsonArray = new JSONArray(session.getNotification());
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.optJSONObject(i);
                    if (object != null && !object.optBoolean("isReadNotification")) {
                        unreadCount++;
                    }
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG) e.printStackTrace();
        }
        return unreadCount;
    }
    private void saveNotification(JSONObject object, AppSession session) {
        try {

            String time = getCurrentFormattedDateTime();
            object.put("createdAt", time);
            if (!session.getNotification().isEmpty()) {
                JSONArray jsonArray = new JSONArray(session.getNotification());
                object.put("isReadNotification", false);
                String source = object.optString("source", "");
                // Skip if source is CRM
                jsonArray.put(object);

                session.setNotification(jsonArray.toString());
            } else {
                JSONArray firstTimeArray = new JSONArray();
                object.put("isReadNotification", false);
                String source = object.optString("source", "");
                firstTimeArray.put(object);
                session.setNotification(firstTimeArray.toString());
            }

            AppApplication.notification = "1";
            Intent myIntent = new Intent("FBR-IMAGE");
            myIntent.putExtra("action", AppApplication.notification);
            this.sendBroadcast(myIntent);

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }


    public void notificationNewPattern(JSONObject object, AppSession session, Context context, Bitmap bitmap) {
        if (object.has("type") && object.optString("type").equals("local")){
            logD("local notification , no need to save it");
        }else{
            saveNotification(object, session);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(NOTIFICATION_SERVICE);
            String channelId = context.getString(R.string.default_notification_channel_id);
            String name = context.getString(R.string.app_name);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel mChannel = new NotificationChannel(channelId, name, importance);
            mChannel.setDescription("");
            mChannel.enableLights(true);
            mChannel.setLightColor(Color.RED);
            mChannel.enableVibration(true);
            mChannel.setVibrationPattern(new long[]{100, 200, 300});
            notificationManager.createNotificationChannel(mChannel);
            Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

            Intent intent1 =  new Intent();
            if (object.has("type") && object.optString("type").equals("local")){
                System.out.println("local notification , no need to save it");
            }else{
                if (!session.getHasLoging()) {
                    intent1 = new Intent(context, BrokerActivity.class);
                } else if (session.getHasLoging() && session.getLoginType().equals("broker")) {
                    intent1 = new Intent(context, BrokerActivity.class);
                } else {
                    intent1 = new Intent(context, ClientActivity.class);
                }
                Bundle bundle = new Bundle();
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                bundle.putString("coming_from", "notification");
                bundle.putString("data", object.toString());
                intent1.putExtras(bundle);
            }


            PendingIntent pendingIntent = PendingIntent.getActivity(
                    context,
                    123,
                    intent1,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            int unreadCount = getUnreadNotificationCount(session);
            NotificationCompat.Builder notificationBuilder
                    = new NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(R.mipmap.notification_icon) //your app icon
                    .setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                    .setNumber(unreadCount)
                    .setChannelId(channelId)
                    .setContentTitle(object.optString("title"))
                    .setSound(defaultSoundUri)
                    .setContentText(object.optString("text"))
                    .setAutoCancel(true).setContentIntent(pendingIntent);
// Set the image for the notification
            if (bitmap ==null) {
                if (!TextUtils.isEmpty(object.optString("imgpath"))&&!object.optString("imgpath").equalsIgnoreCase("null")) {
                     bitmap = getBitmapFromUrl(object.optString("imgpath"));
                    notificationBuilder.setStyle(
                            new NotificationCompat.BigPictureStyle()
                                    .bigPicture(bitmap)
                                    .bigLargeIcon((Bitmap) null)
                    ).setLargeIcon(bitmap);
                }
            }else{
                notificationBuilder.setStyle(
                        new NotificationCompat.BigPictureStyle()
                                .bigPicture(bitmap)
                                .bigLargeIcon((Bitmap) null)
                ).setLargeIcon(bitmap);
            }

            notificationBuilder.build().flags = Notification.FLAG_AUTO_CANCEL;
            notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build());


        } else {
            sendNotification(object, session, context);
        }
    }

    public Bitmap getBitmapFromUrl(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            return BitmapFactory.decodeStream(input);

        } catch (Exception e) {
            logD("Error in getting notification image: " + e.getLocalizedMessage());
            return null;
        }
    }

    private void sendNotification(JSONObject object, AppSession session, Context context) {
        Intent intent1 =  new Intent();
        if (object.has("type") && object.optString("type").equals("local")){
            logD("local notification , no need to save it");
        }else{
            if (!session.getHasLoging()) {
                intent1 = new Intent(context, BrokerActivity.class);
            } else if (session.getHasLoging() && session.getLoginType().equals("broker")) {
                intent1 = new Intent(context, BrokerActivity.class);
            } else {
                intent1 = new Intent(context, ClientActivity.class);
            }
            Bundle bundle = new Bundle();
            bundle.putString("coming_from", "notification");
            bundle.putString("data", object.toString());
            intent1.putExtras(bundle);
//            intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }


        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder builder = new Notification.Builder(this);
        builder.setContentIntent(pendingIntent)
                .setContentTitle(getResources().getString(R.string.app_name))
                .setDefaults(Notification.DEFAULT_SOUND)
                .setAutoCancel(true)
                .setStyle(new Notification.BigTextStyle().bigText(object.optString("text")))
                .setContentTitle(object.optString("title"))
                .setContentText(object.optString("text"));

        builder.setLargeIcon(BitmapFactory.decodeResource(context
                .getResources(), R.mipmap.notification_icon));
        builder.setSmallIcon(R.mipmap.notification_icon);
        builder.setColor(getResources().getColor(R.color.colorAccent));
        builder.setNumber(getUnreadNotificationCount(session));

        Notification  notification = builder.build();
        notification.flags = Notification.FLAG_AUTO_CANCEL;
        notificationManager.notify(NOTIFICATION_ID, notification);
    }
}
