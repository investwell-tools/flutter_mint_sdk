package investwell.client.fragments.SipMining;

public interface OnItemClickListener{
    void onItemClick(int position);
}
