package investwell.client.fragments.portfolioSummary;

import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mEndDate;
import static investwell.client.fragments.portfolioSummary.FragPtSummaryHome.mStartingDate;
import static investwell.utils.UtilityKotlin.getOneDayEarlier;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPtSummaryListInSideListAdapter;
import investwell.client.adapter.FragPtSummaryMutualFundAdapterV2;
import investwell.utils.AppSession;
import investwell.utils.Config;


public class FragPtSummaryMFV2NotUsed extends BaseFragment implements View.OnClickListener {
    private TextView mTvName, mTvCurrent, mTvTotalGain, mTvXirr, mTvCagr, mTvOneDayChange;
    RequestQueue requestQueue;
    private FragPtSummaryMutualFundAdapterV2 mAdapterForClient;
    private FragPtSummaryListInSideListAdapter mAdapterForScheme;
    private RecyclerView mRecycleView;
    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private LinearLayout mCardView;
    private String mGroupById = "";
    private RadioGroup mRgFolioFilter;
    private LinearLayout mLinerNoData;
    private AppApplication mAppplication;
    public boolean mIsActiveFolio = true;
    private ImageView mGainInfo;
    private LinearLayout llPurchase;
    private TextView tvXirrLevel, tvGainLevel, tvPurchageValue;
    private LinearLayout ll_cagr, ll_xirr_section;

    @Override
    public void onResume() {
        super.onResume();
      /*  if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(@NotNull Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        updateApiData();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_pt_summary_mutualfund, container, false);
        initializer(view);
        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            if (levelNo.equals("100")) {
                mGroupById = "1005";
            } else {
                mGroupById = "100";
            }
        } else {
            if (mSession.getLevelNo().equals("100")) {
                mGroupById = "1005";
            } else {
                mGroupById = "100";
            }
        }

        mRecycleView = view.findViewById(R.id.recycleView);
        ll_cagr = view.findViewById(R.id.ll_cagr);
        ll_xirr_section = view.findViewById(R.id.ll_xirr_section);
        mRecycleView.setHasFixedSize(true);
        mRecycleView.setLayoutManager(new LinearLayoutManager(mActivity, LinearLayoutManager.VERTICAL, false));
        mAdapterForScheme = new FragPtSummaryListInSideListAdapter(getActivity(), new ArrayList<>());

        mAdapterForClient = new FragPtSummaryMutualFundAdapterV2(mActivity, new ArrayList<>(), new FragPtSummaryMutualFundAdapterV2.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    JSONObject jsonObject = mAdapterForClient.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    if (mGroupById.equals("1005")) {
                        bundle1.putString("data", jsonObject.toString());
                        bundle1.putString("isAnimation", "true");
                        bundle1.putString("applicant_name", jsonObject.optString("applicantName"));
                        mActivity.displayViewOther(31, bundle1);
                    } else {
                        bundle1.putString("data", jsonObject.toString());
                        bundle1.putString("isAnimation", "true");
                        bundle1.putBoolean("isActiveFolio", mIsActiveFolio);
                        bundle1.putString("applicant_name", jsonObject.optString("applicantName"));
                        bundle1.putString("clientObject", jsonObject.toString());
                        bundle1.putString("appUid", jsonObject.optString("uid"));
                        bundle1.putString("appLevelNo", jsonObject.optString("levelNo"));
                        mActivity.displayViewOther(32, bundle1);
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }

            @Override
            public void onSchemeClick(int position) {
                try {
                    JSONObject jsonObject = mAdapterForClient.mDataList.get(position);
                    Bundle bundle1 = new Bundle();
                    if (mGroupById.equals("1005")) {
                        bundle1.putString("data", jsonObject.toString());
                        bundle1.putString("isAnimation", "true");
                        bundle1.putString("applicant_name", jsonObject.optString("applicantName"));
                        mActivity.displayViewOther(31, bundle1);
                    } else {
                        bundle1.putString("data", jsonObject.toString());
                        bundle1.putString("isAnimation", "true");
                        bundle1.putBoolean("isActiveFolio", mIsActiveFolio);
                        bundle1.putString("applicant_name", jsonObject.optString("applicantName"));
                        bundle1.putString("appUid", jsonObject.optString("uid"));
                        bundle1.putString("appLevelNo", jsonObject.optString("levelNo"));
                        mActivity.displayViewOther(32, bundle1);
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        });
        mRecycleView.setAdapter(mAdapterForClient);
        mRecycleView.setAdapter(mAdapterForScheme);
        mGainInfo.setOnClickListener(v -> showGainInfoDialog());

        mRgFolioFilter.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioFolio1) {
                    mIsActiveFolio = true;
                    getPortfolio();
}
else if (checkedId == R.id.radioFolio2) {
                    mIsActiveFolio = false;
                    getPortfolio();
}
        });


        TextView tvCagr = view.findViewById(R.id.tvCagrLevel);
        if (mSession.getHasShowXirr()) {
            tvCagr.setText(getString(R.string.XIRR));
        } else {
            tvCagr.setText(getString(R.string.CAGR));
        }
        return view;
    }


    private void updateApiData() {
        try {
            Calendar calendar = Calendar.getInstance();
            long currentTimeInMilli = calendar.getTimeInMillis();
            long difference = currentTimeInMilli - mAppplication.sRefreshTimePortfolio;
            long minutes = (difference / 1000) / 60;
            if (minutes >= 10) {
                if (mSession.getHasShowXirr()) {
                    mRgFolioFilter.setVisibility(View.VISIBLE);
                    mGainInfo.setVisibility(View.VISIBLE);
                    llPurchase.setVisibility(View.INVISIBLE);
                    tvGainLevel.setText(getString(R.string.Overall_Gain));
                    tvXirrLevel.setText(getString(R.string.XIRR));
                    ll_cagr.setVisibility(View.GONE);
                    ll_xirr_section.setVisibility(View.VISIBLE);

                    mAppplication.sRefreshTimePortfolio = calendar.getTimeInMillis();
                    mAppplication.CLIENT_DASHBOARD_BAL_SUMMARY = "";
                    getPortfolio();
                } else {
                    mRgFolioFilter.setVisibility(View.GONE);
                    mGainInfo.setVisibility(View.GONE);
                    llPurchase.setVisibility(View.VISIBLE);
                    tvGainLevel.setText(getString(R.string.current_gain));
                    ll_cagr.setVisibility(View.VISIBLE);
                    ll_xirr_section.setVisibility(View.GONE);

                    mAppplication.sRefreshTimePortfolio = calendar.getTimeInMillis();
                    mAppplication.CLIENT_DASHBOARD_BAL_SUMMARY = "";
                    getPortfolio();
                }
            } else {
                if (mSession.getHasShowXirr()) {
                    mRgFolioFilter.setVisibility(View.VISIBLE);
                    mGainInfo.setVisibility(View.VISIBLE);
                    llPurchase.setVisibility(View.INVISIBLE);
                    tvGainLevel.setText(getString(R.string.Overall_Gain));
                    tvXirrLevel.setText(getString(R.string.XIRR));
                    ll_cagr.setVisibility(View.GONE);
                    ll_xirr_section.setVisibility(View.VISIBLE);
                    if (AppApplication.DASHBOARD_PORTFOLIO.isEmpty()) {
                        getPortfolio();
                    } else {
                        SetData();
                    }
                } else {
                    mRgFolioFilter.setVisibility(View.GONE);
                    mGainInfo.setVisibility(View.GONE);
                    llPurchase.setVisibility(View.VISIBLE);
                    tvGainLevel.setText(getString(R.string.current_gain));
                    ll_cagr.setVisibility(View.VISIBLE);
                    ll_xirr_section.setVisibility(View.GONE);
                    if (AppApplication.DASHBOARD_PORTFOLIO.isEmpty()) {
                        getPortfolio();
                    } else {
                        SetData();
                    }
                }
            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }

    private void initializer(View view) {
        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        llPurchase = view.findViewById(R.id.llPurchase);
        tvXirrLevel = view.findViewById(R.id.tvXirrLevel);
        tvGainLevel = view.findViewById(R.id.tvGainLevel);
        tvPurchageValue = view.findViewById(R.id.tvPurchageValue);
        mTvName = view.findViewById(R.id.tvName);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvTotalGain = view.findViewById(R.id.tvTotalGain);
        mTvXirr = view.findViewById(R.id.tvXIRR);
        mTvCagr = view.findViewById(R.id.tvCagr);
        mTvOneDayChange = view.findViewById(R.id.tvOneDayChange);
        mRgFolioFilter = view.findViewById(R.id.rgFolioFilter);
        mLinerNoData = view.findViewById(R.id.linerNoData);
        mGainInfo = view.findViewById(R.id.gain_info);

    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}

    }

    private void showGainInfoDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setMessage(getString(R.string.dialog_gain_info_portfolio));
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alert = builder.create();
        alert.setTitle(getString(R.string.overall_gain));
        alert.show();


    }

    private void SetData() {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        mCardView.setVisibility(View.VISIBLE);
        mLinerNoData.setVisibility(View.GONE);
        ArrayList<JSONObject> list = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(AppApplication.DASHBOARD_PORTFOLIO);
            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                String userName = "";
                if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                    String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                    if (levelNo.equals("98")) {
                        mTvName.setText(getString(R.string.total));
                    } else {
                        mTvName.setText(UtilityKotlin.getClientHopObject(mSession).optString("name"));
                    }
                } else {
                    String levelNo = mSession.getLevelNo();
                    if (levelNo.equals("98")) {
                        mTvName.setText(getString(R.string.total));
                    } else {
                        mTvName.setText(mSession.getPersonName());
                    }
                }

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                double currentValue = jsonObjectSummary.optDouble("currentValue");
                String strCurrentAmount = format.format(currentValue);
                mTvCurrent.setText(strCurrentAmount);
                if (mAppplication.ONE_DAY_CHANGE){
                    if (jsonObjectSummary.has("oneDayChange")) {
                        double oneDayChange = jsonObjectSummary.optDouble("oneDayChange");
                        String strOneDayChange = format.format(oneDayChange);
                        if (oneDayChange == 0) {
                            mTvOneDayChange.setVisibility(View.GONE);
                        } else if (oneDayChange > 0) {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText("  (+" + strOneDayChange + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.green2));
                        } else {
                            mTvOneDayChange.setVisibility(View.VISIBLE);
                            mTvOneDayChange.setText("  (" + strOneDayChange + ")");
                            mTvOneDayChange.setTextColor(ContextCompat.getColor(mActivity, R.color.red));
                        }
                    }
            }

                if (mSession.getHasShowXirr()) {
                    if (mSession.getHideXirr().equals("0")) {
                        ll_xirr_section.setVisibility(View.VISIBLE);

                        UtilityKotlin.safeDisplayXirrPercentValue(jsonObjectSummary, "XIRR", "-","%",2,false,mTvXirr);

                    }else
                        ll_xirr_section.setVisibility(View.GONE);
                    double totalGain = jsonObjectSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(mTvTotalGain, totalGain, mActivity);

                } else {
                    double cgrValue = jsonObjectSummary.optDouble("CAGR");
                    String data2 = String.format("%.2f", cgrValue) + "%";

                    mTvCagr.setText(data2);

                    double totalGain = jsonObjectSummary.optDouble("gain");
                    Utils.checkNegativeAndPositiveValue(mTvTotalGain, totalGain, mActivity);

                    double purchaseValue = jsonObjectSummary.optDouble("purchaseValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    tvPurchageValue.setText(strPurchaseValue);
                }


                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    list.add(jsonObject1);
                }
                // Collections.sort(list, new SortData());

            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();

        } finally {
            if (list.size() > 0) {
                if (list.size() == 1) {
                    mGroupById = "1005";
                    JSONObject clientObject = list.get(0);
                    JSONArray jsonArray = clientObject.optJSONArray("data");
                    List<JSONObject> schemeList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        schemeList.add(jsonObject1);
                    }
                    mLinerNoData.setVisibility(View.GONE);

                    mRecycleView.setAdapter(mAdapterForScheme);
                    mAdapterForScheme.updateList(schemeList, clientObject.optString("name"));

                } else {
                    mGroupById = "100";
                    mLinerNoData.setVisibility(View.GONE);
                    mRecycleView.setAdapter(mAdapterForClient);
                    mCardView.setVisibility(View.VISIBLE);
                    mAdapterForClient.updateList(list);
                }

            } else {
                mRecycleView.setAdapter(mAdapterForClient);
                mAdapterForClient.updateList(list);
                mCardView.setVisibility(View.GONE);
                mLinerNoData.setVisibility(View.VISIBLE);
            }
        }

    }

    private void getPortfolio() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        mCardView.setVisibility(View.GONE);
        mShimmerViewContainer.setVisibility(View.VISIBLE);
        mShimmerViewContainer.stopShimmer();


        String url = "";
        try {
            @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            JSONArray jsonArray = new JSONArray();

            if (mStartingDate.equals(mEndDate)) {
                JSONObject dateObject = new JSONObject();
                Date date = getOneDayEarlier();
                if (date != null) {
                    dateObject.put("endDate", formatter.format(date));
                }
                jsonArray.put(dateObject);
            } else {
                JSONObject object = new JSONObject();
                object.put("startDate", mStartingDate);
                jsonArray.put(object);
                JSONObject object2 = new JSONObject();
                object2.put("endDate", mEndDate);
                jsonArray.put(object2);
            }


            JSONObject selectedObject = new JSONObject();
            selectedObject.put("selectedUser", Utils.getSelectedUserObject(mSession));
            jsonArray.put(selectedObject);


            if (mSession.getHasShowXirr()) {
                JSONObject activeFolioObject = new JSONObject();
                activeFolioObject.put("activeFoliosOnly", mIsActiveFolio);
                jsonArray.put(activeFolioObject);

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.XIRR_PORTFOLIO_RETURN_NEW_API + "&filters=" + jsonArray.toString() +
                        "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            } else {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                        Config.CAGR_PORTFOLIO_RETURN_NEW_API + "filters=" + jsonArray.toString() +
                        "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);

            }

        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {

                    AppApplication.DASHBOARD_PORTFOLIO = response;
                    SetData();
                },
                volleyError -> {
                    if (!isAdded())
                        return;
                    UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    public class SortData implements Comparator {

        @Override
        public int compare(Object o1, Object o2) {
            String a = "0";
            String b = "0";
            a = ((JSONObject) o1).optString("dueDiligence");
            b = ((JSONObject) o2).optString("dueDiligence");

            int ia = 0, ib = 0;
            int nza = 0, nzb = 0;
            char ca, cb;
            int result;

            while (true) {
                // only count the number of zeroes leading the last number compared
                nza = nzb = 0;

                ca = charAt(a, ia);
                cb = charAt(b, ib);

                // skip over leading spaces or zeros
                while (Character.isSpaceChar(ca) || ca == '0') {
                    if (ca == '0') {
                        nza++;
                    } else {
                        // only count consecutive zeroes
                        nza = 0;
                    }

                    ca = charAt(a, ++ia);
                }

                while (Character.isSpaceChar(cb) || cb == '0') {
                    if (cb == '0') {
                        nzb++;
                    } else {
                        // only count consecutive zeroes
                        nzb = 0;
                    }

                    cb = charAt(b, ++ib);
                }

                // process run of digits
                if (Character.isDigit(ca) && Character.isDigit(cb)) {
                    if ((result = compareRight(a.substring(ia), b.substring(ib))) != 0) {
                        return result;
                    }
                }

                if (ca == 0 && cb == 0) {
                    // The strings compare the same. Perhaps the caller
                    // will want to call strcmp to break the tie.
                    return nza - nzb;
                }

                if (ca < cb) {
                    return -1;
                } else if (ca > cb) {
                    return +1;
                }

                ++ia;
                ++ib;
            }
        }

        private char charAt(String s, int i) {
            if (i >= s.length()) {
                return 0;
            } else {
                return s.charAt(i);
            }
        }

        int compareRight(String a, String b) {
            int bias = 0;
            int ia = 0;
            int ib = 0;

            // The longest run of digits wins. That aside, the greatest
            // value wins, but we can't know that it will until we've scanned
            // both numbers to know that they have the same magnitude, so we
            // remember it in BIAS.
            for (; ; ia++, ib++) {
                char ca = charAt(a, ia);
                char cb = charAt(b, ib);

                if (!Character.isDigit(ca) && !Character.isDigit(cb)) {
                    return bias;
                } else if (!Character.isDigit(ca)) {
                    return -1;
                } else if (!Character.isDigit(cb)) {
                    return +1;
                } else if (ca < cb) {
                    if (bias == 0) {
                        bias = -1;
                    }
                } else if (ca > cb) {
                    if (bias == 0)
                        bias = +1;
                } else if (ca == 0 && cb == 0) {
                    return bias;
                }
            }
        }
    }
}
