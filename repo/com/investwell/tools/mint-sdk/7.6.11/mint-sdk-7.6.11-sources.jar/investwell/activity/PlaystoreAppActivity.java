package investwell.activity;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import investwell.utils.AppSession;
import investwell.utils.Extensions;
import investwell.utils.Utils;


public class PlaystoreAppActivity extends BaseActivity implements View.OnClickListener {
    private final int SPLASH_DISPLAY_LENGTH = 2000;
    private AppSession mSession;
    private String mType = "";
    private JSONObject appConfigObject;
    private String mDomainName = "", mLogoPath = "", mCompName="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         if (!Utils.isTablet(this))
            Utils.setRequestedOrientationSafely(this, ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        mSession = AppSession.getInstance(PlaystoreAppActivity.this);

        setContentView(R.layout.playstore_app_activity);
        MaterialButton tvSkip = findViewById(R.id.tvSkip);
        MaterialButton tvDownload = findViewById(R.id.tvDownload);
        TextView tvMessage = findViewById(R.id.tvMessage);
        ImageView ivBack = findViewById(R.id.ivBack);
        ImageView ivLogo = findViewById(R.id.ivLogo);
        TextView tvSlogan = findViewById(R.id.tvSlogan);
        String imagePath = mSession.getAppLogo();

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("domain_name")) {
            mDomainName = intent.getStringExtra("domain_name");
        } else {
            mDomainName = mSession.getUserBrokerDomain();
        }
        if (intent != null && intent.hasExtra("logoPath")) {
            mLogoPath = intent.getStringExtra("logoPath");
        } else {
            mLogoPath = mSession.getAppLogo();
        }
        if (intent != null && intent.hasExtra("compName")) {
            mCompName = intent.getStringExtra("compName");
        } else {
            mCompName = mDomainName;
        }
        tvSlogan.setText(mSession.getSloganOnLogo());

        setTintColorIfDark(this,ivLogo);
        ivLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getString(R.string.subdomain).equals("mint")) {
            if (!imagePath.equals("")) {
                Picasso.get().load(imagePath)
                        .error(R.drawable.app_logo_secondry_mint).into(ivLogo);
            } else {
                // ivLogo.setImageResource(R.drawable.app_logo_secondry);
            }
        }

        tvSkip.setOnClickListener(this);
        tvDownload.setOnClickListener(this);
        ivBack.setOnClickListener(this);

        String message = getString(R.string.custom_app_available_for)+mSession.getCompanyName()+"."+getString(R.string.please_download_the_app_from_the_playstore);
        tvMessage.setText(message);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.ivBack) {
                finish();
}
else if (view.getId() == R.id.tvSkip) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                intent.putExtra("domain_name", mDomainName);
                intent.putExtra("logoPath", mLogoPath);
                intent.putExtra("compName",mCompName);
                startActivity(intent);
                PlaystoreAppActivity.this.overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
}
else if (view.getId() == R.id.tvDownload) {
                try {
                    String playStoreAppLink = mSession.getPlayStoreLink();
                    Intent viewIntent = new Intent("android.intent.action.VIEW",
                            Uri.parse(playStoreAppLink));
                    startActivity(viewIntent);
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), R.string.unable_to_connect_try_again,
                            Toast.LENGTH_LONG).show();
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
}


    }



}

