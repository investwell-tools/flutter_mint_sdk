package investwell.client.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import org.json.JSONObject;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.dividend.FragDividendReportFamily;
import investwell.utils.AppSession;

/**
 * Created by Dev on 16/08/2021.
 */

public class DividendReportFamilyAdapter extends RecyclerView.Adapter<DividendReportFamilyAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private DividendReportFamilyAdapter.OnItemClickListener listener;
    private boolean mIsFolioMenuOpen = false;
    private FragDividendReportFamily mFragDividendReport;
    private AppSession mSession;

    public DividendReportFamilyAdapter(Context context, FragDividendReportFamily fragDividendReport, ArrayList<JSONObject> list, DividendReportFamilyAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mFragDividendReport = fragDividendReport;
        mSession = AppSession.getInstance(mContext);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_dividend_report_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, text1, text2, text3, tvfolio;
        CardView card_view;
        ImageView ivDivDetail;
        View ivThreeUpper;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvfolio = view.findViewById(R.id.tvfolio);
            text1 = view.findViewById(R.id.text1);
            text2 = view.findViewById(R.id.text2);
            text3 = view.findViewById(R.id.text3);
            card_view = view.findViewById(R.id.card_view);
            ivDivDetail = view.findViewById(R.id.ivDivDetail);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);

                final JSONObject jsonObject = mDataList.get(position);
                tvfolio.setVisibility(View.GONE);
                tvName.setText(jsonObject.optString("investor"));
                text1.setText(String.format("%.2f", jsonObject.optDouble("reinvest")) );
                text2.setText(String.format("%.2f", jsonObject.optDouble("payout")));
                text3.setText(String.format("%.2f", jsonObject.optDouble("tdsAmount")));

                ivDivDetail.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("RestrictedApi")
                    @Override
                    public void onClick(View v) {
                        Bundle bundle1 = new Bundle();
                        ClientActivity mainActivity = null;
                        if (mContext instanceof ClientActivity) {
                            mainActivity = (ClientActivity) mContext;
                        }
                        bundle1.putString("investorName", jsonObject.optString("investor"));
                        bundle1.putString("appid", jsonObject.optString("appid"));
                        bundle1.putString("fromDate", jsonObject.optString("fromDate"));
                        bundle1.putString("toDate", jsonObject.optString("toDate"));
                        bundle1.putString("uid",jsonObject.optString("uid"));
                        bundle1.putString("levelNo","100");
                        bundle1.putString("isAnimation", "true");
                        if (mainActivity!=null)
                            mainActivity.displayViewOther(71, bundle1);

                    }
                });
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(position);
                }
            });

        }
    }
    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }


}
