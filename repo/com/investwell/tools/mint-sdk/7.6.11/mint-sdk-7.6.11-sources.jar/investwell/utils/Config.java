package investwell.utils;

import android.os.Build;

import java.util.HashMap;


public class Config {
    public static String asOnDate="";
    public static String mintInternalVersion = "20";
    public static String manufacturerModel  = Build.MODEL +", " +Build.DEVICE + ", " + Build.MANUFACTURER+ ", " + Build.BOARD+ ", " + Build.BRAND+ ", " + Build.VERSION.RELEASE;


    public static boolean sOncePopupPerLoginSession = false;
    public static String IMAGE_PATH = "https://docs.investwellonline.com/cloud_investwell_images/logo/Large/";
    public static String COMMON_IMAGE_PATH = "https://docs.investwellonline.com/cloud_investwell_images/";
    public static String VOLT_BASE_URL ="https://api.voltmoney.in/v1/";
    public static String VOLT_AUTH =VOLT_BASE_URL+"partner/platform/auth/login";
    public static String VOLT_CREATE_PARTNER_ACCOUNT =VOLT_BASE_URL+"partner/platform/las/partner";
    public static String VOLT_APP_KEY_STAGING ="las-investwell-staging@voltmoney.in";
    public static String VOLT_APP_SECRET_STAGING="9564b42ccca3465b8ab955ebb2491473";
    public static String VOLT_APP_KEY_PRODUCTION ="las-investwell-prod@voltmoney.in";
    public static String VOLT_APP_SECRET_PRODUCTION="a1b676b63bd8493098757af8bcb73382";

    public static String APP_CONFIG="https://mintes.mintservices.in/MintExternalService.svc/APPConfigMint";

    /**
     * :::::::::::::::::::::::::::::: START Web Configuration ::::::::::::::::::::::::::::::*
     * */

    public static String EXIT_WEB_TO_APP_NSE ="#/broker/investOnlineMain/0?redirectionUrl=true";
    public static String EXIT_WEB_TO_APP_BSE ="#/broker/investOnlineBSE/0?redirectionUrl=true";

    public static String BROKER_APP_TO_WEB_NSE ="#/broker/investOnlineMain/0?";
    public static String BROKER_APP_TO_WEB_BSE ="#/broker/investOnlineBSE/0?";

    /**
     * :::::::::::::::::::::::::::::: END Web Configuration ::::::::::::::::::::::::::::::*
     * */

    /********************************************Auth****************************************/
    public static String ADMIN_AUTHENTICATION = "auth/adminToBrokerLogin";
    public static String AUTHENTICATION = "auth/login";
    public static String SSO_LOGIN = "auth/SSOLogin";
    public static String GOOGLE_AUTHENTICATION = "auth/androidGoogleSignIn";
    public static String LOGOUT = "auth/logout";

    public static String RESET_PSW= "auth/resetPassword";
    public static String RESET_PSW_CHECK_TOKEN= "auth/checkTokenValidity?";

    public static String OTP_LOGIN ="auth/loginMobileOTP";
    public static String OTP_LOGIN_VERIFY ="auth/authenticateOtp";
    public static String STILL_ALIVE = "auth/stillAlive";
    public static String POST_SIGN_UP_API = "auth/signup";
    public static String POST_SIGN_UP_OTP_API = "auth/sendSignUpOtp";
    public static String SEND_OTP = "auth/sendOTP";
    public static String AUTHENTICATE_OTP = "auth/authenticateOTP";
    public static String FORGOT_PASSWORD = "auth/sendPasswordResetMail";
    public static String USERS_FILTERED = "auth/getLevelUsersFiltered?";  // used for broker only
    public static String DOWNLOAD_DOCUMENT = "auth/file/download?";
    public static String UPLOAD_PROFILE_PHOTO = "auth/file/upload";
    public static String GET_CHECK_MAIL_PHONE_AVAIL_API = "auth/checkEmailAndPhoneAvailability";
    public static String GET_MEMBERS = "auth/getLevelUsers?";
    public static String GET_LOGGEDIN_USER = "auth/getLoggedInUser?";

    public static String CHECK_NETWORK_AVAILABILITY = "auth/checkSystemAvailability?";


    /********************************************File****************************************/
    public static String DOWNLOAD_SOA = "file/download?";

    /********************************************Op****************************************/

    /**
     * :::::::::::::::::::::::::::::::: CRM START::::::::::::::::::::::::::::::::
     * */

    public static String  CRM_GET_TASKS_SUMMARY="crmApi/master/getTasksSummary?";
    public static String  CRM_GET_LEADS_SUMMARY="crmApi/master/getLeadsSummary?";
    public static String  CRM_GET_LOGGED_IN="crmApi/auth/getLoggedInUser?";
    public static String  CRM_GET_LEADS="crm/leads?";
    public static String  CRM_GET_TASKS="crm/tasks?";
    public static String  END_CRM_SESSION="crm/dashboard";
    public static String CRM_Notification_LIST ="broker/imail/getNotificationList?";
    /**
     * :::::::::::::::::::::::::::::::: CRM END::::::::::::::::::::::::::::::::
     * */
    public static String GET_BROKER_PUBLIC_INFO = "op/getBrokerPublicInfo?";
    public static String GET_TOP_SCHEME_OPEN_DATA = "op/getTopSchemes";
    public static String GET_TOP_SCHEME_OPEN_FUND_DATA = "op/getFunds";
    public static String GET_TOP_SCHEME_OPEN_OBJ_DATA = "op/getObjectives";
    public static String GET_FACT_SHEET_OPEN_DATA = "op/getFactSheetData";
    public static String GET_FACT_SHEET_OPEN_GRAPH_DATA = "op/getNavGraph";
    public static String GET_FACT_SHEET_OPEN_PDF_DATA = "op/getFactSheetPDF";
    public static String GET_NFO_SCHEME_OPEN_LIST_API = "op/getNFOSchemes";
    public static String POST_CHECK_PAN_KYC_API = "op/checkKYC";
    public static String GET_MAX_NAVDATE = "op/getMaxNavDate";
    public static String GET_Allowed_Modules = "op/getAllowedModules";

    /*******************************************End Web session ****************************************/
    public static String END_SESSION_CLIENT_PROFILE = "client/manageProfileNseInvest";
    public static String END_SESSION_BROKER_PROFILE = "broker/manageProfileNseInvest";
    public static String START_SESSION_BROKER_EDIT_UCC = "#/broker/exchangeProfileList/nseInvest?";
    public static String END_SESSION_BROKER_DASHBOARD = "broker/dashboard";
    public static String END_SESSION_CLIENT_DASHBOARD = "client/dashboard";


    /********************************************Client****************************************/

    public static String NSE_STATE_LIST_CLIENT="client/investOnline/getNSEStateMaster?";
    public static String CLIENT_TRACK_NSE_INVEST_ORDER="client/investOnline/trackNseInvestOrders?";
    public static String CLIENT_TRACK_NSE_GET_ACTION_ORDER="client/investOnline/getActionForOrders?";
    public static String CLIENT_RUNNING_SIP="client/sip/getRunningSystematicTxn?";
    public static String CLIENT_NSE2_EXCHANGE_REGISTRATION="client/exchangeRegistration/";
    public static String CLIENT_NSE2_STEP_COMPLETION="client/completeExchangeCreation/nseInvest/";
    public static String CLIENT_SCHEDULE_SIP="client/sip/sendSipModificationRequest";
    public static String GET_CLIENT_PROFILE_IMAGE="client/getInvestorImage?";

    public static String SEND_VIDEO_KYC_ON_MAIL="client/investOnline/sendVideoKycLinkOnMail?";
    public static String CHECK_NACH_BANK ="client/investOnline/checkNACHBank?";
    public static String CHECK_NSE_NACH_BANK ="client/investOnline/checkNseNachBank?";
    public static String RESEND_OTP_ORDER_AUTH ="util/sendOtpV2";
    public static String VALIDATE_OTP_ORDER_AUTH ="util/validateOtpV2";

    public static String GET_CLIENTS_UNDER_USER_FOR_CLIENT = "client/getClientsUnderUser?";
    public static String CLIENT_SUBMIT_DOCUMENT = "client/investOnline/submitDocument";
    public static String BAL_SUMMERY = "client/dashboard/getClientDashboardSummary?";
    public static String GET_TARGET_SCHEME = "client/investOnline/getSchemes?";
    public static String GET_GRAPH = "client/dashboard/getConsolidatedAllocationAnalysis?";
    public static String GET_LINE_GRAPH = "client/dashboard/getNavDateVSAUMNetInvGraph?";
    public static String GET_PORTFOLIO = "client/dashboard/getPortfolioReturns?";
    public static String GET_EXISTING_INVESTMENT = "client/investOnline/getFolios?";
    public static String GET_PORTFOLIO_FD = "client/reports/getPortfolioReturnsForFixedAssets?";
    public static String GET_PORTFOLIO_ASSERT = "client/reports/getPortfolioSummaryForOtherAssets?";
    public static String GET_PMS_SOA_CLIENT ="client/SOA/getPmsSOAFile?";
    public static String GET_NOMINEE_AUTH_DATA ="client/investOnline/getNomineeAuthData";
    public static String INVEST_ONLINE_AUTH_NOMINEE = "client/investOnline/authNominee";
    public static String GET_PT_SUMMARY_MUTUALFUND = "client/dashboard/getPortfolioSummaryForMutualFunds?";
    public static String GET_PT_SUMMARY_RETURN_SHAREBOND = "client/dashboard/getPortFolioReturnsForSharesAndBonds?";
    public static String GET_PT_SUMMARY_SHAREBOND_DETAILS = "client/dashboard/getDetailedPortFolioReturnsForShareAndBond?";

    public static String GET_SHARE_BOND_TRAN_HIST = "client/shares/getShareBondTxns?";
    public static String GET_PT_SUMMARY_RETURN_FD = "client/reports/getPortfolioReturnsForFixedAssets?";
    public static String GET_PT_SUMMARY_RETURN_FD_FH = "client/reports/getPortfolioFDReturnsForNativeApps?";
    public static String GET_TRANSECTIONS_CLient = "client/txn/getTxnStatement?";
    public static String GET_UCC_LIST = "client/investOnline/getUccList?";
    public static String GET_SELECTED_UCC ="client/investOnline/getSelectedUserUCCs?";
    public static String GET_SELECTED_UCC_NSE2 ="client/investOnline/getNseUccList?";
    public static String PLACE_SWITCH_ORDER_NSE2 ="client/investOnline/placeNseSwitchOrder";
    public static String GET_SELECTED_NSE2_ACTIVE_PROFILE ="client/investOnline/getManageProfileData?";
    public static String GET_CAN_LIST = "client/investOnline/getCANList?";
    public static String GET_ARN_LIST_NSE = "client/getArns?";
    public static String TRANSFER_HOLDING_CLIENT = "client/investOnline/transferHoldingUnits";
    public static String GET_TARGET_SCHEME_BROKER = "broker/investOnline/getSchemes?";
    public static String MF_CENTRAL_DATA_CLIENT = "client/cas/getMFCentralCasData";
    public static String BROKER_MF_CENTRAL_CAS_DATA = "broker/cas/getMFCentralCasData";
    public static String BROKER_DELETE_CENTRAL_CAS_DATA = "broker/cas/deleteCasTxns";
    public static String GET_CAS_DATA_BROKER ="broker/cas/getCasData?";
    public static String GET_KYC_DATA_BROKER ="broker/investOnline/getVideoKycStatus?";
    public static String RSEND_VIDEO_LINK_BROKER ="broker/investOnline/sendVideoKycLinkOnMail?";
    public static String KYC_BROKER_UPDATE_LOGS ="broker/investOnline/updateVideoKycLogs";
    public static String BROKER_VOLT ="broker/voltMFLogin";

    public static String GET_CAS_UPLOAD_LOGS = "broker/cas/getCasUploadLogs?";
    public static String GET_CAS_UPLOAD_LOGS_CLIENT = "client/cas/getCasUploadLogs?";

    public static String GET_TOP_SCHEME_FUND_DATA = "client/investOnline/getFunds";
    public static String GET_TOP_SCHEME_OBJ_DATA = "client/getObjectives";
    public static String GET_FUND_LIST_NSE = "client/investOnline/getFunds?";
    public static String GET_TOP_SCHEME_LIST_NSE = "client/investOnline/getTopSchemes?";
    public static String GET_TOP_SCHEME_DATA = "client/utilities/getTopSchemes";


    public static String GET_FOLIO_LIST_NSE = "client/investOnline/getAdditionalFolios?";
    public static String GET_FOLIO_LIST_NSE2 = "client/investOnline/getAdditionalFoliosV2?";
    public static String GET_TRANSECTION_TYPE = "client/investOnline/getSchemeNSEInfo?";
    public static String GET_IIN_BY_FOLIO = "client/investOnline/getIINByFolios?";
    public static String GET_FUND_SCHEAMES = "client/investOnline/getFundSchemes?";
    public static String GET_BALANCE = "client/investOnline/getBalanceUnits?";
    public static String GET_SCHEME_GROUPS = "client/investOnline/getTargetSchemeGroups?";
    public static String GET_INVESTMENT_TYPE = "client/investOnline/getValidInvestmentTypes?";
    public static String GET_BSEID = "client/investOnline/getBseProfile?";
    public static String GET_MANDATE_LIST = "client/investOnline/getUccMandates?";
    public static String GET_MANDATE_NSE2_LIST = "client/investOnline/getNseUccMandates?";
    public static String GET_PREPARE_ORDER_DATA_NSE2 = "client/investOnline/prepareOrderData?";
    public static String GET_SWP_DATE = "client/investOnline/getDatesAndFrequencies?";
    public static String GET_FAMILY_HEAD_EMAIL = "client/reports/getFamilyHeadEmail?";
    public static String DOWNLOAD_PDF = "client/reports/capitalGain/exportPDF?";
    public static String DOWNLOAD_PDF_V2 = "client/reports/capitalGain/exportPDFV2?";
    public static String Capitalgain_Realized_Exl = "client/reports/capitalGain/downloadRealizedCapitalGainXls?";
    public static String Capitalgain_Realized_Exl_V2 = "client/reports/capitalGain/downloadRealizedCapitalGainXlsV2?";
    public static String Capitalgain_Realized_SCH112ACSV = "client/reports/capitalGain/sch112ACSVDownload?";
    public static String Capitalgain_Realized_Report = "client/reports/capitalGain/getRealized?";
    public static String Capitalgain_Realized_Report_After2024 = "client/reports/capitalGain/getPeriodWiseRealizedCapitalGain?";
    public static String Capitalgain_Realized_Report_MF_V2 = "client/reports/capitalGain/getRealizedV2?";


    public static String Capitalgain_Realized_Report_SB = "client/reports/capitalGain/getRealizedSb?";
    public static String Capitalgain_Realized_Report_SB_V2 = "client/reports/capitalGain/getRealizedSbV2?";
    public static String DOWNLOAD_PORTFOLIO_REPORT = "client/reports/downloadPortfolioReport?";
    public static String DOWNLOAD_PORTFOLIO_SUMMARY_PDF = "client/dashboard/downloadPortfolioSummary?";
    public static String DOWNLOAD_COMPLETE_PORTFOLIO_SUMMARY_PDF = "client/dashboard/downloadCompletePortfolioSummary?";
    public static String DOWNLOAD_CAPITAL_GAIN_UNREALIZED_PDF = "client/reports/capitalGain/exportUnrealizedPDFV2?";
    public  static  String DOWNLOAD_CAPITAL_GAIN_UNREALIZED_XLS ="client/reports/capitalGain/downloadUnrealizedCapitalGainXlsV2?";
    public static String DOWNLOAD_FOLIO_SLIP = "client/folios/getTransactionSlip?";
    public static String SEND_REPORT_ON_EMAIL = "client/reports/sendReportEmailToUsers?";
    public static String GET_FOLIO_LOOKUP_Client = "client/folios/getFolios?";
    public static String GET_FOLIO_SCHEME_DETAILS = "client/dashboard/getDetailedPortFolioReturns?";
    public static String GET_LIFE_INSURANCE_CLIENT = "client/insurance/getInsuranceList?";
    public static String GET_FOLIO_DETAILS_Client = "client/folios/getFolioDetails?";
    public static String GET_MY_SIP_ADVANCE = "client/sip/getAdvanceSIPDetails?";
    public static String GET_SOA = "client/dashboard/getSOA?";
    public static String GET_FUNDSNET_LOGIN_CAPTCHA_CLIENT = "client/SOA/getFundsNetLoginCaptcha?";
    public static String GET_FUNDSNET_TOKEN_CLIENT = "client/SOA/getFundsNetToken?";
    public static String DOWNLOAD_FUNDSNET_SOA_CLIENT = "client/SOA/downloadFundsNetSOA?";
    public static String GET_CAMS_EDGE360_CAPTCHA_CLIENT = "client/SOA/getEdge360Captcha?";
    public static String GET_CAMS_CAPTCHA_CLIENT = "client/SOA/getCamsSecret?";
    public static String GET_FILE_NAME_VERYFY_CAPTCHA_CLIENT = "client/SOA/getEdge360SOA?";
    public static String GET_MY_ORDER_CLIENT = "client/investOnline/getOrders?";
    public static String GET_FILE_NAME_CLIENT = "client/SOA/downloadSOA?";
    public static String GET_FILE_NAME_VERIFY_CAPTCHA_CLIENT = "client/SOA/downloadCamsSOA?";
    public static String GET_BSE_BANKS = "client/investOnline/getBseBanks?";
    public static String GET_NSE2_BANKS = "client/investOnline/getNseInvestBanks?";
    public static String GET_NSE_BANKS = "client/investOnline/getIINbankDetails?";
    public static String GET_MFU_BANKS = "client/investOnline/getMfuBanks?";
    public static String GET_MANDATE_BANKS = "client/investOnline/getMandates?";
    public static String PLACE_BSE_PAYMENT = "client/investOnline/bsePayment";
    public static String PLACE_NSE_ORDER = "client/investOnline/buyNow";
    public static String PLACE_PURCHAGE_ORDER = "client/investOnline/placePurchaseOrder";
    public static String NSE_INVEST_PLACE_ORDER = "client/investOnline/nseInvestPurchase";
    public static String PLACE_Switch_ORDER = "client/investOnline/placeSwitchOrder";
    public static String PLACE_Redemtion_ORDER = "client/investOnline/placeRedemptionOrder";
    public static String PLACE_SIP_ORDER = "client/investOnline/placeSipOrder";
    public static String NSE_INVEST_PLACE_SIP_ORDER = "client/investOnline/placeNseSipOrder";
    public static String PLACE_SIP_SWP = "client/investOnline/placeSwpOrder";
    public static String PLACE_SIP_SWP_NSE2 = "client/investOnline/placeNseSwpOrder";
    public static String PLACE_STP = "client/investOnline/placeStpOrder";
    public static String NEW_NSE_PLACE_STP = "client/investOnline/placeNseStpOrder";
    public static String PLACE_ORDER_MFU = "client/investOnline/mfuBuyNow";
    public static String OPEN_BSE_CART_URL_CLIENT = "client/investOnline/openBseCartUrl?";
    public static String GET_DIVIDEND_REPORT_CLIENT = "client/reports/getDividendReport?";
    public static String GET_DIVIDEND_REPORT_PDF = "client/reports/getDividendReportPdf?";
    public static String GET_ELSS_REPORT_CLIENT = "client/reports/getElssProcurementData?";
    public static String GET_ELSS_REPORT_CLIENT_PDF ="client/reports/getElssProcurementPdf?";
    public static String GET_CLIENT_INFO_API = "client/getClientInformation";
    public static String GET_CHECK_NSE_FATCA_API = "client/investOnline/checkNseFatca";
    public static String POST_NSE_FATCA_API = "client/investOnline/submitNseFatca";
    public static String POST_CREATE_IIN_API = "client/investOnline/createIIN";
    public static String POST_DO_VIDEO_KYC_API = "client/investOnline/videoKyc";
    public static String GET_IIN_BY_APP_ID_API = "client/investOnline/getIINsByAppid";
    public static String GET_PENDING_ONBOARDING_PROFILES = "client/investOnline/getPendingOnboardingProfiles?";
    public static String GET_ONBOARDING_DETAILS = "client/getOnBoardingDetails";
    public static String GET_BANK_IIN_HOLDERS_API = "client/investOnline/getIINHoldersAndBanks";
    public static String GET_ACCOUNT_TYPE_API = "util/getAccType?";
    public static String POST_SUBMIT_DOCS_API = "client/investOnline/submitNSECreationDocument";
    public static String BSE_COUNTRY_MASTER_API = "client/investOnline/getBseCountryMaster";
    public static String BSE_GET_BANK_LIST_API = "client/investOnline/getBseBanks";
    public static String BSE_CREATE_UCC_API = "client/investOnline/createUCC";
    public static String BSE_STATE_MASTER_API = "client/investOnline/getBseStateMaster";
    public static String MFU_COUNTRY_MASTER_API = "client/investOnline/getMfuCountryMaster";
    public static String MFU_GET_BANK_LIST_API = "client/investOnline/getMfuBankMaster";
    public static String MFU_SUBMIT_DOCUMENT_API = "client/investOnline/completeCAN";
    public static String MFU_GET_CAN_BY_APP_ID_API = "client/investOnline/getSelectedUserCANs";
    public static String MFU_TEMP_DATA = "client/investOnline/getCANData";
    public static String MFU_DOC_LIST_API = "client/investOnline/getCANVerificationDocuments";
    public static String GET_NFO_SCHEME_LIST_API = "client/investOnline/getNFOSchemes";
    public static String GET_FACT_SHEET_DATA = "client/utilities/getFactSheetData";
    public static String GET_FACT_SHEET_GRAPH_DATA = "client/utilities/getNavGraph";
    public static String GET_FACt_SHEET_PDF = "client/utilities/getFactSheetPDF";
    public static String BSE_GET_UCC_BY_APP_ID_API = "client/investOnline/getSelectedUserUCCs";

    public static String GET_CLIENT_IIN_STATUS = "client/investOnline/checkIINStatus";
    public static String CHECK_RISK_PROFILE_CLIENT = "client/riskProfiler/getMyRiskProfile";
    public static String GET_RISK_PROFILE_DATA = "client/riskProfiler/getRiskProfiler";
    public static String SUBMIT_RISK_PROFILE_CLIENT = "client/riskProfiler/submitProfilerForm";
    public static String CREATE_MANDATES_BSE = "client/investOnline/registerBseMandate";
    public static String CREATE_MANDATES_NSE2 = "client/investOnline/registerNseInvestMandate";
    public static String CREATE_MANDATES_MFU = "client/investOnline/registerMfuMandate";
    public static String ACTIVATE_MANDATES_BSE = "client/investOnline/getActivationCode?";
    public static String ACTIVATE_MANDATES_NSE2 = "client/investOnline/getMandateActivationLink?";
    public static String DOWNLOAD_PHYSICAL_MANDATE_BSE = "client/investOnline/downloadPhysicalMandateForm?";
    public static String DOWNLOAD_PHYSICAL_MANDATE_NSE2 = "client/investOnline/downloadNseInvestMandate?";
    public static String MANDATE_UPLOAD_BSE = "client/investOnline/uploadPhysicalMandate?";
    public static String BSE_GET_MANDATE_LIST_API = "client/investOnline/getBseMandates?";
    public static String GOAL_LIST = "client/goal/getAllGoalsDetails?";
    public static String GOAL_MUTUAL_FUNDS_CLIENT = "client/goal/getFoliosForGoal?";
    public static String GOAL_SHARE_AND_BOND_CLIENT = "client/goal/getSBForGoal?";
    public static String GOAL_FD_CLIENT = "client/goal/getFixedAssetForGoal?";
    public static String GOAL_INSURANCE_CLIENT = "client/goal/getInsuranceForGoal?";
    public static String GOAL_OTHER_ASSETS_CLIENT = "client/goal/getOtherAssetsForGoal?";
    public static String GOAL_REPORT_PDF = "client/reports/goalReportPDF?";
    public static String GOAL_CATEGORIES = "client/goal/getCategories?";
    public static String SAVE_GOAL_CLIENT = "client/goal/saveOrUpdateGoal";
    public static String DELETE_GOAL_CLIENT = "client/goal/deleteGoal";
    public static String UPDATE_GOAL_ALLOCATION_CLIENT = "client/goal/updateGoalAllocation";
    public static String UPDATE_BULK_GOAL_ALLOCATION_CLIENT = "client/goal/bulkUpdateGoalAllocation";
    public static String GOAL_ALLOCATION_CLIENT = "client/goal/getAssetGoalAllocation?";
    public static String GET_GOAL_DETAILS_CLIENT = "client/goal/getGoalDetails?";
    public static String DOWNLOAD_PHYSICAL_MANDATE_NSE = "client/investOnline/downloadMandate?";
    public static String MANDATE_UPLOAD_NSE = "client/investOnline/uploadNseMandate";
    public static String CREATE_MANDATES_NSE = "client/investOnline/registerNseMandate";
    public static String GET_WATCH_LIST_API = "client/dashboard/getClientSchemeWatchList";
    public static String CAGR_PORTFOLIO_RETURN_NEW_API = "client/reports/getPortfolioReturnForNativeApps?";
    public static String XIRR_PORTFOLIO_RETURN_NEW_API = "client/dashboard/getCompletePortfolioSummaryForNativeApps?";
    public static String CLIENT_ALLOWED_FEATURES="client/acl/getAllowedFeatureList?selectedUser=";
    public static String DOWNLOAD_TRANSACION_PDF_CLIENT="client/reports/getTxnStatementPDF?";
    public static String UPLOAD_INSURANCE_IMAGE_CLIENT="client/insurance/uploadInsuranceDoc";
    public static String DOCUMENT_LISTING = "client/utilities/getDocumentsListing?";
    public static String DOCUMENT_FOLDERS = "client/utilities/getDirectoryListing?";
    public static String DELETE_DOCUMENT ="client/utilities/deleteDocument";
    public static String CLEINT_DELETE_MY_ACCOUNT="client/accountDelete";
    public static String CLIENT_GRAPH_CHAT_DATA = "client/reports/getAllocationAnalysisV2?";
    public static String GET_CAPITAL_GAIN_DATE = "client/reports/capitalGain/getSellTxnFYDates?";
    public static String BSE_UPLOAD_FATCA_CLIENT = "client/investOnline/uploadBseFatca";
    public static String GET_All_MANDATES_NSE_CLIENT = "client/investOnline/getAllNseMandates?";
    public static String CLINET_UCC_DATA="client/investOnline/getUCCData?";
    public static String CLINET_REFRESH_NSE_UCC_STATUS="client/investOnline/refreshNseUccStatus";
    public static String GET_CLIENT_BSE_ORDER = "client/investOnline/getBseOrder?";
    public static String GET_CLIENT_NSE_ORDER = "client/investOnline/getNseOrder?";

    public static String GET_CLIENT_SYSTEM_ORDER = "client/investOnline/getOrders?";
    public static String BSE_ORDER_AUTHENTICATION = "client/investOnline/bseOrderAuthentication";
    public static String GET_ONBOARDING_DETIALS_CLIENT = "client/investOnline/getIINTempData?";
    public static  String  ADD_ADDITIONAL_BANKS = "client/investOnline/addAdditionalBanks";
    public static String SEND_REPORT_ON_WHATSAPP = "client/reports/sendReportOnWhatsapp?";
    public static String GET_UCC_HOLDER_BSE = "client/investOnline/getUCCHolders?";
    public static String GET_UCC_HOLDER_NSE2 = "client/investOnline/getNseUccHolders?";
    public static String SUBMIT_FATCHA_NSE2 = "client/investOnline/submitNseInvestFatca";
    public static String GET_ESCALATION = "client/getClientsEscalationMatrix?";

    public static String GET_MY_ORDER_BROKER = "broker/investOnline/getOrders?";
    public static String BSE_ORDER_AUTHENTICATION_BROKER = "broker/investOnline/bseOrderAuthentication";
    public static String GET_TARGET_SCHEME_GROUPS = "broker/investOnline/getTargetSchemeGroups?";
    public static String SAVE_GOAL_BROKER = "broker/goal/saveOrUpdateGoal";
    public static String GOAL_CATEGORIES_BROKER = "broker/goal/getCategories?";
    public static String GOAL_MUTUAL_FUNDS_BROKER = "broker/goal/getFoliosForGoal?";
    public static String GOAL_SHARE_AND_BOND_BROKER = "broker/goal/getSBForGoal?";
    public static String GOAL_FD_BROKER = "broker/goal/getFixedAssetForGoal?";
    public static String GOAL_GOAL_LIST_BROKER = "broker/goal/getAllGoalsDetails?";
    public static String GOAL_INSURANCE_BROKER = "broker/goal/getInsuranceForGoal?";
    public static String GOAL_OTHER_ASSETS_BROKER = "broker/goal/getOtherAssetsForGoal?";
    public static String DELETE_GOAL_BROKER = "broker/goal/getFixedAssetForGoal";
    public static String UPDATE_GOAL_ALLOCATION_BROKER = "broker/goal/updateGoalAllocation";
    public static String UPDATE_BULK_GOAL_ALLOCATION_BROKER = "broker/goal/bulkUpdateGoalAllocation";
    public static String GOAL_ALLOCATION_BROKER = "broker/goal/getAssetGoalAllocation?";
    public static String GET_GOAL_DETAILS_BROKER = "broker/goal/getGoalDetails?";
    public static String GET_SEARCH_CLIENT_IMAGE_BROKER="broker/getInvestorImage?";


    public static String SHARE_BOND_TXNS_CLIENT="client/shares/getShareBondTxns?";
    public static String  GET_SCHEMES_CLIENT = "client/elastic/getSchemes?";
    public static String  CREATE_SHARE_BOND_TXN_CLIENT = "client/shares/createShareBondTxn";
    public static String  DELETE_SHARE_BOND_TXN_CLIENT = "client/shares/deleteShareBondTxn";

    public static String  DELETE_FD_TXN_CLIENT = "client/txn/deleteFixedAssetsTxns";
    public static String GET_FIXED_ASSET_TXNS_CLIENT="client/txn/getFixedAssetTxns?";
    public static String GET_FIXED_ASSET_SCHEMES_CLIENT = "client/txn/getFixedAssetSchemes?";
    public static String CREATE_FIXED_SUBASSET_CLIENT = "client/txn/createFixedSubAsset";
    public static String GET_ARNS_CLIENT = "client/txn/getArns?";
    public static String INSERT_FIXED_ASSET_TXN_CLIENT = "client/txn/insertFixedAssetTxn";
    public static String CHEQUE_UPLOAD = "client/investOnline/uploadCheques";
    public static String CHECK_ORDER_STATUS_CLIENT = "client/investOnline/checkOrderStatus";
    public static String MAKE_PAYMENT_V2_CLIENT = "client/investOnline/bsePaymentV2";

    //update nominee
    public static String GET_BSE_NOMINEE_INFO = "client/investOnline/getBseNomineeInfo?";
    public static String AUTH_BSE_NOMINEE = "client/investOnline/authBseNominee";


    //mfu onboarding
    public static String MFU_CREATE_CAN_API_ClIENT = "client/investOnline/createCAN";
    public static String GET_CAN_TEMP_DATA_CLIENT_MFU = "client/investOnline/getCANData?";
    public static String GET_MFU_BANK_MASTER_API_CLIENT = "client/investOnline/getMfuBankMaster?";
    public static String Get_MFU_COUNTRY_MASTER_API_CLIENT = "client/investOnline/getMfuCountryMaster?";
    public static String MFU_UPLOAD_DOC_LIST_API_CLIENT = "client/investOnline/uploadCANVerificationDocument";


    //cart apis for mfu
    public static String REDIRECT_CART_ITEMS_MFU = "client/MFU/cartItems?";
    public static  String INSERT_MFU_CART_ITEM = "client/investOnline/insertMfuCartItem";

    //cart apis for nseInvest
    public static String REDIRECT_CART_ITEMS_NSE_INVEST = "client/nseInvest/cartItems?";
    public static  String INSERT_NSE_BSE_CART_ITEM = "client/investOnline/addToCart";

    //cart apis for bse
    public static String REDIRECT_CART_ITEMS_BSE = "client/BSE/cartItems?";

    //contact us leads api
    public static String GET_INTERESTED_LIST_CLIENT = "client/getBrokerServicesList?";
    public static String CREATE_LEAD_CLIENT ="client/createLead?";



    public static String CHECK_KYC_CLIENT = "client/investOnline/checkKYC";




    /********************************************Broker****************************************/

    public static String BSE_GET_BANK_BROKER_LIST_API = "broker/investOnline/getBseBanks";
    public static String BROKER_TRACK_NSE_INVEST_ORDER = "broker/investOnline/trackNseInvestOrders?";
    public static String BROKER_TRACK_NSE_GET_ACTION_ORDER = "broker/investOnline/getActionForOrders?";
    public static String BROKER_TRACK_NSE_CANCEL_ORDER = "broker/investOnline/cancelNseInvestOrder";
    public static String BROKER_ALLOWED_FEATURES="broker/acl/getAllowedFeatureList?";
    public static String GET_ARN = "broker/AUMReport/getARNs?";
    public static String GET_ELASTIC_SCHEMES = "broker/elastic/getSchemes?";
    public static String GET_PMS_SOA_BROKER ="broker/SOA/getPmsSOAFile?";
    public static String GET_AUM_REPORT = "broker/AUMReport/getAUMReportForMutualFunds?";
    public static String AUM_REPORT_CATEGORY ="broker/utilities/getObjectives?";
    public static String GET_TRANSECTIONS_BROKER = "broker/txn/getTxnStatement?";
    public static String GET_DASHBOARD_SUMMARY = "broker/dashboard/getDashboardSummary?";
    public static String GET_SEARCH_CLIENTS_NEW2 = "broker/mobile/clientFinder?";
    public static String GET_CAS_CLIENT_SEARCH= "broker/elastic/getClientsSearchHistory?";
    public static String TRANSFER_HOLDING_BROKER = "broker/investOnline/transferHoldingUnits";
    public static String GET_PROFILE_LIST = "broker/investOnline/getUCCList?";
    public static String GET_Password_Reset_Data = "broker/mobile/getResetPasswordLink?";
    public static String GET_INVITE_MESSAGE = "broker/mobile/getInviteMessage?";
    public static String DOWNLOAD_FOLIO_SLIP_BROKER ="broker/folio/getTransactionSlip?";
    public static String GET_FOLIO_DETAILS_BROKER ="broker/folio/getFolioDetails?";
    public static String GET_FOLIO_LOOKUP_Broker = "broker/folio/getFolios?";
    public static String GET_LIFE_INSURANCE_BROKER = "broker/insurance/getInsuranceList?";
    public static String GET_SOA_BROKER = "broker/getSOA?";
    public static String GET_FUNDS_BROKER = "broker/investOnline/getFunds?";
    public static String GET_TOP_SCHEME_LIST_NSE_BROKER = "broker/investOnline/getTopSchemes?";
    public static String GET_FUNDSNET_LOGIN_CAPTCHA = "broker/SOA/getFundsNetLoginCaptcha?";
    public static String GET_FUNDSNET_TOKEN_BROKER = "broker/SOA/getFundsNetToken?";
    public static String DOWNLOAD_FUNDSNET_SOA = "broker/SOA/downloadFundsNetSOA?";
    public static String GET_CAMS_CAPTCHA = "broker/SOA/getCamsSecret?";
    public static String GET_CAMS_EDGE360_CAPTCHA = "broker/SOA/getEdge360Captcha?";
    public static String GET_FILE_NAME_VERYFY_CAPTCHA = "broker/SOA/getEdge360SOA?";
    public static String GET_FILE_NAME_VERIFY_CAPTCHA = "broker/SOA/downloadCamsSOA?";
    public static String GET_FILE_NAME = "broker/SOA/downloadSOA?";
    public static String GET_SIP_MINING_SUMMARY = "broker/sipMining/getSIPSummary?";
    public static String OPEN_BSE_CART_URL_BROKER = "broker/investOnline/openBseCartUrl?";
    public static String GET_FACT_SHEET_BROKER_DATA = "broker/utilities/getFactSheetData";
    public static String GET_FACT_SHEET_GRAPH_BROKER_DATA = "broker/utilities/getNavGraph";
    public static String GET_FACt_SHEET_BROKER_PDF = "broker/utilities/getFactSheetPDF";
    public static String BSE_UPLOAD_FATCA_API = "broker/investOnline/uploadBseFatca";
    public static String BSE_SUBMIT_DOCUMENT_API = "broker/investOnline/submitDocument";
    public static String VIDEO_KYC_BROKER = "broker/investOnline/videoKyc";
    public static String GET_TOP_SCHEME_BROKER_DATA = "broker/utilities/getTopSchemes";
    public static String GET_TOP_SCHEME_BROKER_FUND_DATA = "broker/txn/getFunds?";
    public static String GET_TOP_SCHEME_BROKER_OBJ_DATA = "broker/utilities/getObjectives";
    public static String GET_NSE_BROKER_PROFILE_API = "broker/investOnline/getIINListView?";
    public static String GET_BSE_BROKER_PROFILE_API = "broker/investOnline/getUCCList?";
    public static String BROKER_REFRESH_NSE_UCC_STATUS = "broker/investOnline/refreshNseUccStatus";
    public static String GET_MFU_BROKER_PROFILE_API = "broker/investOnline/getCANList?";
    public static String GET_All_MANDATES_NSE = "broker/investOnline/getAllNseMandates?";
    public static String ADD_TO_FAV_FUND="broker/utilities/setRecommendedScheme";
    public static String CLIENT_DASHBOARD_XIRR = "client/dashboard/getInvestmentSummary?";

    public static String DOWNLOAD_TRANSACION_BROKER="broker/txn/downloadTxnStatement?";
    public static String UPLOAD_PROFILE_IMAGE_NAME="broker/investorManagement/updateClientInformation";
    public static String UPLOAD_CLIENT_PROFILE_IMAGE="client/updateClient";
    public static String UPLOAD_INSURANCE_IMAGE_BROKER="broker/insurance/uploadInsuranceDoc";
    public static String BROKER_DELETE_MY_ACCOUNT="broker/accountDelete";
    public static String BROKER_IIN_DATA="broker/investOnline/getIINListView?";
    public static String BROKER_EXCHANGE_REGISTRATION="#/broker/exchangeRegistration/";
    public static String KYC_ONBOARDING_WEB="#/kycOnBoarding/";
    public static String BROKER_EXCHANGE_REGISTRATION_COMPLETION="#/broker/completeExchangeCreation/nseInvest?";
    public static String BROKER_EXCHANGE_REGISTRATION_END="#/broker/exchangeProfileList/nseInvest";
    public static String BROKER_NEW_NSE2_PROFILE="broker/investOnline/getNseInvestProfileData?";
    public static String GET_ARN_LIST_FOR_BROKER_NSE = "broker/txn/getARNs?";
    public static String GET_VALID_INVESTMENT_FOR_BROKER = "broker/investOnline/getValidInvestmentTypes?";
    public static String BROKER_CREATE_IIN = "broker/investOnline/createIIN";
    public static String GET_ONBOARDING_DETIALS = "broker/investOnline/getIINTempData?";
    public static String GET_NSE_IIN_HOLDERS_API = "broker/investOnline/getIINHoldersAndBanks?";
    public static String BROKER_SUBMIT_FACTA = "broker/investOnline/submitNseFatca";
    public static String BROKER_NSE_SUBMIT_DOCUMENT = "broker/investOnline/submitNSECreationDocument";
    public static String GET_BROKER_IIN_STATUS = "broker/investOnline/checkIINStatus";
    public static String BROKER_CREATE_UCC="broker/investOnline/createUCC";
    public static String BROKER_UCC_DATA="broker/investOnline/getUCCData?";
    public static String BSE_STATE_MASTER_BROKER = "broker/investOnline/getBseStateMaster?";
    public static String BSE_COUNTRY_MASTER_BROKER = "broker/investOnline/getBseCountryMaster?";
    public static String GET_UCC_HOLDER_BROKER = "broker/investOnline/getUCCHolders?";

    public static String GET_CHECK_NSE_FATCA_BROKER = "broker/investOnline/checkNseFatca";

    public static String GET_BROKER_BSE_ORDER = "broker/investOnline/getBseOrder?";

    public static String GET_BROKER_NSE_ORDER="broker/investOnline/getNseOrder?";

    public static String GET_BROKER_SYSTEM_ORDER = "broker/investOnline/getOrders?";

    public static String SEARCH_CLIENT_BSE = "broker/investOnline/getClientUsingName?";

    public static String SEARCH_CLIENT_NSE = "broker/investOnline/getNseClientsUsingIinOrName?";
    public static String GET_BROKER_NSE2_PROFILE_LIST = "broker/investOnline/getNseInvestProfileData?";

    //meeting notes
    public static String GET_NOTES = "broker/utilities/getNotes";
    public static String GET_NOTE_DETAILS = "broker/utilities/getNoteDetails";
    public static String CREATE_OR_UPDATE_NOTE = "broker/utilities/createOrUpdateNote";
    public static String DELETE_NOTE = "broker/utilities/deleteNote";
    public static String GET_LABELS = "broker/utilities/getLabels";
    public static String CREATE_LABEL = "broker/utilities/createLabel";
    public static String DELETE_NOTE_ATTACHMENT = "broker/utilities/deleteNoteAttachment";
    public static String DELETE_NOTE_LABEL = "broker/utilities/deleteNoteLabel";

    public static String SEND_NOTIFICATION = "broker/alert/sendfirebaseAlerts";



    public static String FTP_UPLOAD = "auth/file/FTPUpload";
    public static String GET_CLIENTS = "broker/elastic/getClients?";

    public static String GET_NFO_SCHEME_BROKER = "broker/utilities/getNFOSchemes";

    public static String NSE_STATE_LIST_BROKER="broker/investOnline/getNSEStateMaster?";

    //txn share bond endpoint
    public static String SHARE_BOND_TXNS_BROKER="broker/shares/getShareBondTxns?";
    public static String GET_CLIENTS_UNDER_USER = "broker/utilities/getClientsUnderUser?";
    public static String  GET_SCHEMES_BROKER = "broker/elastic/getSchemes?";
    public static String  CREATE_SHARE_BOND_TXN_BROKER = "broker/shares/createShareBondTxn";
    public static String  DELETE_SHARE_BOND_TXN_BROKER = "broker/shares/deleteShareBondTxn";

    //txn fd bond endpoint
    public static String  DELETE_FD_TXN_BROKER = "broker/txn/deleteFixedAssetsTxns";
    public static String GET_FIXED_ASSET_TXNS_BROKER="broker/txn/getFixedAssetTxns?";
    public static String GET_FIXED_ASSET_SCHEMES_BROKER = "broker/txn/getFixedAssetSchemes?";
    public static String CREATE_FIXED_SUBASSET_BROKER = "broker/txn/createFixedSubAsset";
    public static String GET_ARNS_BROKER = "broker/txn/getArns?";
    public static String INSERT_FIXED_ASSET_TXN_BROKER = "broker/txn/insertFixedAssetTxn";
    public static String CHECK_ORDER_STATUS_BROKER = "broker/investOnline/checkOrderStatus";
    public static String MAKE_PAYMENT_BROKER_V2 = "broker/investOnline/bsePaymentV2";


    //mfu onboarding broker
    public static String MFU_CREATE_CAN_API_BROKER = "broker/investOnline/createCAN";
    public static String GET_CAN_TEMP_DATA_BROKER_MFU = "broker/investOnline/getCANData?";
    public static String GET_CAN_LIST_BROKER_MFU = "broker/investOnline/getCANList?";
    public static String GET_MFU_BANK_MASTER_API_BROKER = "broker/investOnline/getMfuBankMaster?";
    public static String Get_MFU_COUNTRY_MASTER_API_BROKER = "broker/investOnline/getMfuCountryMaster?";
    public static String MFU_SUBMIT_DOCUMENT_API_BROKER = "broker/investOnline/completeCAN";
    public static String MFU_DOC_LIST_API_BROKER = "broker/investOnline/getCANVerificationDocuments";
    public static String MFU_UPLOAD_DOC_LIST_API_BROKER = "broker/investOnline/uploadCANVerificationDocument";


    public static String CHECK_KYC_BROKER = "broker/investOnline/checkKYC";




    /********************************************Util api****************************************/
    public static String GET_COUNTRY_MASTER_API = "util/getCountryMaster?";
    public static String GET_PIN_MASTER_API = "util/getCity";
    public static String GET_BANK_MASTER_API = "util/getBanks";
    public static String GET_BANK_DETAIL_API = "util/getBankDetails";
    public static String CLEAN_IMAGE="util/extractSignature";

    public static String GET_FUNDS_WITH_LOGIN="util/getFundsForNavLookup?";
    public static String GET_OBJECTIVE_FUND_WISE_WITH_LOGIN ="util/getObjectiveFundWise?";
    public static String GET_SCHEME_FUND_WISE_WITH_LOGIN ="util/getSchemeFundWise?";

    /********************************************toolkit api****************************************/

    public static String GET_FUNDS_WITHOUT_LOGIN = "toolkit/getFunds?";
    public static String GET_OBJECTIVE_FUND_WISE_WITHOUT_LOGIN ="toolkit/getObjectiveFundWise?";
    public static String GET_SCHEME_FUND_WISE_WITHOUT_LOGIN ="toolkit/getSchemeFundWise?";
    public static String GET_FACT_SHEET_DATA_TOOLKIT = "toolkit/getFactSheetData";
    public static String GET_FACT_SHEET_GRAPH_DATA_TOOLKIT = "toolkit/getNavGraph";
    public static String GET_FACT_SHEET_PDF_DATA_TOOLKIT = "toolkit/getFactSheetPDF";



    /********************************************toolkit api****************************************/

    public static String GET_INTERESTED_LIST_WITHOUT_LOGIN = "toolkit/getBrokerServicesList?";
    public static String CREATE_LEAD_WITHOUT_LOGIN ="toolkit/createLead?";

    /********************************************Other****************************************/
    public static String REDIRECT_URL = "app/#/broker/investOnlineMain/2?";
    public static String REDIRECT_URL_FOR_BROKER_VIDEO_CREATE = "app/#/broker/videoKYCStatus/";
    public static String REDIRECT_URL_MFU_BROKER = "app/#/broker/investOnlineMFU/";
    public static String REDIRECT_URL_MFU_CLIENT = "app/#/client/mfuManageProfiles/";
    public static String DEEP_LINKING = "app/public/signup/1?";
    public static HashMap<String, String> mGraphValue = new HashMap<>();
    public static String GET_FUND_IMAGE_URL = "https://docs.investwellonline.com/cloud_investwell_images/logo/rectlogos/";
    public static String MARKET_UPDATE = "https://nativeapi.my-portfolio.in/Investwell.svc/MarketUpdateV4";
    public static String DEEP_LINKING_SHORT_URL = "https://www.investly.co.in/yourls-api.php?url=";
    public static String IMAGE_PATH_CUSTOM = "https://docs.investwellonline.com/cloud_investwell_images/logo/CustomImages/";


    public static String GET_ASSETS_WISE = "client/dashboard/getAssetWiseCurrentValues?";
    public static String GET_NEW_KYC_ONBOARDING_URL = "kycOnBoarding/";

    public static String GET_INVESTMENT_JOURNEY_SNAPSHOT = "client/reports/getInvestmentJourneySnapshot?";
    public static String GET_INVESTMENT_JOURNEY_GRAPH = "client/reports/getInvestmentJourneyGraph?";


}
