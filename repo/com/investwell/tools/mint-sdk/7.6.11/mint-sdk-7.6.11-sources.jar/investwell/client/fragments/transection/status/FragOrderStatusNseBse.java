package investwell.client.fragments.transection.status;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.broker.activity.BrokerActivity;
import investwell.utils.AppConstants;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.PaymentActivity;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.Utils;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragOrderStatusNseBse extends BaseFragment implements View.OnClickListener {
    private TextView mSchemeName, mConfirmationDate, mOrderNumber,
            mTvSkip, mTvEmailMessage;
    private AppSession mSession;
    private ClientActivity mActivity;
    private RequestQueue requestQueue;
    private String transectionType = "", mBseId = "";
    private JSONObject mResultObject;
    private boolean mHasSuccess = false;
    private RelativeLayout mLlEmailMessage;
    private String payNowOptionType = "";
    private String payOptionType = "";

    @Override
    public void onResume() {
        super.onResume();
     /*   if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_order_status_nse_bse, container, false);
        mSchemeName = view.findViewById(R.id.scheme_name_);
        mConfirmationDate = view.findViewById(R.id.date_textView);
        mTvEmailMessage = view.findViewById(R.id.tvEmailMessage);

        mOrderNumber = view.findViewById(R.id.order_number);
        mLlEmailMessage = view.findViewById(R.id.llEmailMessage);
        TextView tvNseBse = view.findViewById(R.id.tvNseBse);
        TextView tvErrorMessage = view.findViewById(R.id.tvErrorMessage);
        TextView tvfailureReason = view.findViewById(R.id.tvfailureReason);
        ImageView ivStatusIcon = view.findViewById(R.id.ivStatusIcon);

        TextView tvOrderType = view.findViewById(R.id.tvOrderType);
        TextView tvTryAgain = view.findViewById(R.id.tvTryAgain);
        mTvSkip = view.findViewById(R.id.skip_textView);
        tvTryAgain.setOnClickListener(this);
        mTvSkip.setOnClickListener(this);
        view.findViewById(R.id.tvOrerHistory).setOnClickListener(this);

        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("payNowOptionType")) {
            payNowOptionType = bundle.getString("payNowOptionType");
        }

        if (bundle != null && bundle.containsKey("Order_Type")) {
            payOptionType = bundle.getString("Order_Type");
        }

        if (bundle != null && bundle.containsKey("resultObject")) {
            try {
                mResultObject = new JSONObject(bundle.getString("resultObject"));
                transectionType = mResultObject.optString("txnType");

                if (mResultObject.optString("status").equalsIgnoreCase("failed")) {
                    mHasSuccess = false;
                    mLlEmailMessage.setVisibility(View.GONE);
                    ivStatusIcon.setImageResource(R.mipmap.failed);
                    tvTryAgain.setText(getResources().getString(R.string.txt_btn_try_again));
                    tvfailureReason.setVisibility(View.VISIBLE);

                    tvErrorMessage.setVisibility(View.VISIBLE);
                    tvErrorMessage.setText(mResultObject.optString("message"));

                    String exchange = "";
                    if (mSession.getHasMultiExchange()){
                        exchange = AppApplication.sExchangeType;
                        if (exchange == "")
                            exchange = mSession.getExchangeNseBseMfu();
                    }else{
                        if (mSession.getHasNseOpted()){
                            exchange = "1";
                        }else if (mSession.getHasBseOpted()){
                            exchange = "2";
                        }else if (mSession.getHasMfuOpted()){
                            exchange = "3";
                        }else if (mSession.getHasNse2Opted()){
                            exchange = "4";
                        }else{
                            exchange = mSession.getExchangeNseBseMfu();
                        }
                    }

                    if (exchange.equals("1")) {
                        tvNseBse.setText(getResources().getString(R.string.txt_order_failed) + getResources().getString(R.string.txt_at_nse));
                    } else if (exchange.equals("2")) {
                        tvNseBse.setText(getResources().getString(R.string.txt_order_failed) + getResources().getString(R.string.txt_at_bse));
                    } else if (exchange.equals("3")) {
                        tvNseBse.setText(getResources().getString(R.string.txt_order_failed) + getResources().getString(R.string.txt_at_mfu));

                    }

                } else {
                    mHasSuccess = true;
                    mLlEmailMessage.setVisibility(View.VISIBLE);
                    ivStatusIcon.setImageResource(R.mipmap.success);
                    tvfailureReason.setVisibility(View.GONE);
                    String exchange = "";
                    if (mSession.getHasMultiExchange()){
                        exchange = AppApplication.sExchangeType;
                        if (exchange == "")
                            exchange = mSession.getExchangeNseBseMfu();
                    }else{
                        if (mSession.getHasNseOpted()){
                            exchange = "1";
                        }else if (mSession.getHasBseOpted()){
                            exchange = "2";
                        }else if (mSession.getHasMfuOpted()){
                            exchange = "3";
                        }else if (mSession.getHasNse2Opted()){
                            exchange = "4";
                        }else{
                            exchange = mSession.getExchangeNseBseMfu();
                        }
                    }

                    if (exchange.equals("1")) {
                        tvNseBse.setText(getResources().getString(R.string.txt_order_success) + "\n" + getResources().getString(R.string.txt_to_nse));
                        String email = getString(R.string.follow_the_link_sent_by_nse_on_your_registered_email_id) + "<font color=#166DD8>" + mResultObject.optString("email").toLowerCase() + "</font>" + getString(R.string.and_confirm_the_transactions);
                        mTvEmailMessage.setText(Html.fromHtml(email));
                    } else if (exchange.equals("2")) {
                        tvNseBse.setText(getResources().getString(R.string.txt_order_success) + "\n" + getResources().getString(R.string.txt_to_bse));

                        if (bundle.containsKey("paymentMessage")){
                            mTvEmailMessage.setText(bundle.getString("paymentMessage"));
                        }else{
                            String email = "";
                            if (payNowOptionType.toLowerCase().equals("upi")) {
                                email = getString(R.string.complete_payment_using_the_upi_payment_request_sent_on_your_upi_app_or_sms_received);
                            }else{
                                email = getString(R.string.follow_the_link_sent_by_bse_on_your_registered_email_id) + "<font color=#166DD8>" + mResultObject.optString("email").toLowerCase() + "</font>" +  getString(R.string.and_confirm_the_transactions);
                            }
                            mTvEmailMessage.setText(Html.fromHtml(email));
                        }
                    } else if (exchange.equals("3")) {
                        tvNseBse.setText(getResources().getString(R.string.txt_order_success) + "\n" + getResources().getString(R.string.txt_to_mfu));
                        if (bundle.containsKey("paymentMessage")){
                            mTvEmailMessage.setText(bundle.getString("paymentMessage"));
                        }else{
                            String email = getString(R.string.follow_the_link_sent_by_mfu_on_your_registered_email_id) + "<font color=#166DD8>" + mResultObject.optString("email").toLowerCase() + "</font>" + getString(R.string.and_confirm_the_transactions);
                            mTvEmailMessage.setText(Html.fromHtml(email));
                        }
                    }

                    tvErrorMessage.setVisibility(View.GONE);

                    if (exchange.equals("1")) {
                        tvTryAgain.setText(getResources().getString(R.string.txt_transect_more));

                    } else if (exchange.equals("2")&& mHasSuccess) {
                        if (transectionType.equalsIgnoreCase("NRP") || transectionType.equalsIgnoreCase("SIP")) {
                            if (payNowOptionType.toLowerCase().equals("upi") || payNowOptionType.toLowerCase().equals("neft/rtgs")) {
                                tvTryAgain.setVisibility(View.GONE);
                            }else{
                                if (payOptionType.equalsIgnoreCase("email")){
                                    tvTryAgain.setVisibility(View.VISIBLE);
                                    tvTryAgain.setText(getString(R.string.txt_make_payment));
                                }else{
                                    tvTryAgain.setVisibility(View.VISIBLE);
                                    tvTryAgain.setText(getString(R.string.txt_transect_more));
                                }

                            }
                        } else {
                            tvTryAgain.setText(getResources().getString(R.string.txt_transect_more));
                        }

                        if (transectionType.equals("SIP")){
                            tvTryAgain.setText(getResources().getString(R.string.txt_transect_more));
                        }
                    } else if (exchange.equals("3")) {
                        tvTryAgain.setText(getResources().getString(R.string.txt_transect_more));
                    }

                }


                String orderNumber = "";
                if (!mResultObject.isNull("orderNo") && !mResultObject.optString("orderNo").isEmpty()) {
                    orderNumber = mResultObject.optString("orderNo");
                } else if (!mResultObject.isNull("STPRegNo") && !mResultObject.optString("STPRegNo").isEmpty()) {
                    orderNumber = mResultObject.optString("STPRegNo");
                }
                if (!orderNumber.isEmpty() && !orderNumber.equalsIgnoreCase("null")) {
                    mOrderNumber.setText(getString(R.string.txt_order_number_no) + orderNumber);
                    mOrderNumber.setVisibility(View.VISIBLE);
                } else {
                    mOrderNumber.setVisibility(View.GONE);
                }
                mConfirmationDate.setText(Utils.formatedDateFullMonth(mResultObject.optString("date")));
                mSchemeName.setText(mResultObject.getString("schemeName"));
                tvOrderType.setText(Utils.SchemeNameFormat(transectionType));


      /*          if (transectionType.equalsIgnoreCase("NRP")) {
                    tvOrderType.setText(getString(R.string.purchase));
                } else if (transectionType.equalsIgnoreCase("SIP")) {
                    tvOrderType.setText(getString(R.string.SIP));
                } else if (transectionType.equalsIgnoreCase("SWO")) {
                    tvOrderType.setText(getString(R.string.Switch));
                } else if (transectionType.equalsIgnoreCase("NRS")) {
                    tvOrderType.setText(getString(R.string.redeem));
                } else if (transectionType.equalsIgnoreCase("SWP")) {
                    tvOrderType.setText(getString(R.string.SWP));
                } else if (transectionType.equalsIgnoreCase("STP")) {
                    tvOrderType.setText(getString(R.string.txt_STP));

                }*/

                if (bundle.containsKey("bseid")) {
                    mBseId = bundle.getString("bseid");
                }

                mTvSkip.setVisibility(View.VISIBLE);
            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }


        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.tvTryAgain) {
                String exchange = "";
                if (mSession.getHasMultiExchange()){
                    exchange = AppApplication.sExchangeType;
                    if (exchange == "")
                        exchange = mSession.getExchangeNseBseMfu();
                }else{
                    if (mSession.getHasNseOpted()){
                        exchange = "1";
                    }else if (mSession.getHasBseOpted()){
                        exchange = "2";
                    }else if (mSession.getHasMfuOpted()){
                        exchange = "3";
                    }else if (mSession.getHasNse2Opted()){
                        exchange = "4";
                    }else{
                        exchange = mSession.getExchangeNseBseMfu();
                    }
                }

                if (exchange.equals("1")) {
                    getActivity().getSupportFragmentManager().popBackStack();

                } else if (exchange.equals("2")&& mHasSuccess) {
                    if (transectionType.equalsIgnoreCase("NRP") || transectionType.equalsIgnoreCase("SIP")) {
                        getPaymentUrl();
                    } else {
                        getActivity().getSupportFragmentManager().popBackStack();
                    }
                } else if (exchange.equals("3")) {
                    getActivity().getSupportFragmentManager().popBackStack();

                }
}
else if (v.getId() == R.id.skip_textView) {
                AppApplication.sExchangeType = "";
                if (mSession.getLoginType().equals("broker")){
                    mSession.setClientObject("");
                    Intent intent = new Intent(requireActivity(), BrokerActivity.class);
                    AppApplication.COMING_FROM_PATH = AppConstants.BROKER_USER;
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    requireActivity().finish();
                }else{
                    Intent intent = new Intent(requireActivity(), ClientActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    requireActivity().finish();

                }
}
else if (v.getId() == R.id.tvOrerHistory) {
                mActivity.displayViewOther(35, new Bundle());
}
    }

    private void getPaymentUrl() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }

        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        String url = "";
        if (mSession.getLoginType().equals("broker")) {
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.OPEN_BSE_CART_URL_BROKER +
                    "bseid=" + mBseId;
        } else {
            if (Utils.getSelectedLevelNo(mSession).equals("1")){
                mBar.dismiss();
                return;
            }
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.OPEN_BSE_CART_URL_CLIENT +
                    "bseid=" + mBseId + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
        }

        url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                mBar.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                        String url = jsonObject1.optString("cartUrl");
                        Intent intent = new Intent(getActivity(), PaymentActivity.class);
                        intent.putExtra("raw_data", url);
                        intent.putExtra("type", "payNow");
                        startActivityForResult(intent, 500);
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (mBar != null)
                    mBar.dismiss();
                if (!isAdded())
                    return;
               UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

}
