package investwell.client.orderBse;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.iw.mint.sdk.R;

import java.util.ArrayList;
import java.util.List;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragViewPagerAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.client.orderNse.FragOrdersNse;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.CustomViewPager;
import investwell.utils.Utils;

;


public class FragOrderDash extends BaseFragment implements View.OnClickListener, ToolbarFragment.ToolbarCallback {
    public CustomViewPager mViewPager;
    public FragViewPagerAdapter mPagerAdapter;
    public TabLayout mTabLayout;


    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;

    @Override
    public void onResume() {
        super.onResume();
 /*       if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.txt_Myorder),
                    true, false, false, true, false, false, false);

            fragToolBar.setCallback(this);
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_bse_order_home, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }
        setUpToolBar();

        mViewPager = view.findViewById(R.id.pager);
        mTabLayout = view.findViewById(R.id.tabLayout);

        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);

        RadioGroup radioGroup = view.findViewById(R.id.rdGroup);
        radioGroup.check(R.id.rbCurrentMonth);


        updateViewPagerView();
        // getAllMembers();
        return view;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {

        }
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_pdf_download) {
                Fragment fragment = (Fragment) mPagerAdapter.instantiateItem(mViewPager, mViewPager.getCurrentItem());
                if (fragment instanceof FragOrdersBse)
                ((FragOrdersBse) fragment).showFilterMethod();
                else if (fragment instanceof FragOrdersNse)
                    ((FragOrdersNse) fragment).showFilterMethod();
}
    }

    public void updateViewPagerView() {
        List<Fragment> fragList = new ArrayList<>();
        Bundle bundle;

        String exchange = Utils.getSelectedExchange(mSession);
        if (exchange.equals("1")){
            Fragment fragment = new FragOrdersNse();
            bundle = new Bundle();
            bundle.putString("comefrom", "myorder");
            bundle.putString("type", "system_orders");
            fragment.setArguments(bundle);

            Fragment fragment2 = new FragOrdersNse();
            bundle = new Bundle();
            bundle.putString("comefrom", "myorder");
            bundle.putString("type", "all_orders");
            fragment2.setArguments(bundle);

            fragList.add(fragment);
            fragList.add(fragment2);
        }else{
            Fragment fragment = new FragOrdersBse();
            bundle = new Bundle();
            bundle.putString("comefrom", "myorder");
            bundle.putString("type", "system_orders");
            fragment.setArguments(bundle);

            Fragment fragment2 = new FragOrdersBse();
            bundle = new Bundle();
            bundle.putString("comefrom", "myorder");
            bundle.putString("type", "all_orders");
            fragment2.setArguments(bundle);

            fragList.add(fragment);
            fragList.add(fragment2);
        }



        mPagerAdapter = new FragViewPagerAdapter(getChildFragmentManager(), fragList);
        mViewPager.setAdapter(mPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);

        mTabLayout.getTabAt(0).setText(getString(R.string.system_orders));
        mTabLayout.getTabAt(1).setText(getString(R.string.all_orders));

        mViewPager.addOnPageChangeListener(onViewPageChange);

    }


    ViewPager.OnPageChangeListener onViewPageChange = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(final int position) {

            switch (position) {
                case 0:
                    // mTvTitle.setText("Mutual Fund");

                    break;

                case 1:
                    //mTvTitle.setText("Share & Bond");
                    break;

                case 2:
                    //mTvTitle.setText("Fixed Deposit");
                    break;

                case 3:
                    //mTvTitle.setText("Others Asserts");
                    break;


            }
        }


        @Override
        public void onPageScrollStateChanged(int state) {


        }
    };


}
