package investwell.common.piechart.data;

import android.content.Context;
import android.widget.TextView;

import investwell.charts.mikephil.charting.components.MarkerView;
import investwell.charts.mikephil.charting.data.CandleEntry;
import investwell.charts.mikephil.charting.data.Entry;
import investwell.charts.mikephil.charting.highlight.Highlight;
import investwell.charts.mikephil.charting.utils.MPPointF;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import investwell.activity.AppApplication;
import investwell.utils.UtilityKotlin;

public class FactSheetMarkerView extends MarkerView {

    private final TextView tvDate ,tvInvestment;


    public FactSheetMarkerView(Context context, int layoutResource) {
        super(context, layoutResource);
        tvDate = findViewById(R.id.textView29);
        tvInvestment = findViewById(R.id.textView27);

    }

    // runs every time the MarkerView is redrawn, can be used to update the
    // content (user-interface)
    @Override
    public void refreshContent(Entry e, Highlight highlight) {

        try {
            if (e instanceof CandleEntry) {

                CandleEntry ce = (CandleEntry) e;

                //tvContent.setText(Utils.formatNumber(ce.getHigh(), 0, true));
            } else {
                int xValue = (int) (Math.round(e.getX()));
                Entry investment = AppApplication.GNavList.get(xValue);

                JSONObject jsonObject = AppApplication.sheetDataList.get(xValue);

                NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                format.setMinimumFractionDigits(0);
                format.setMaximumFractionDigits(0);
                tvInvestment.setText("NAV"+": " + format.format(investment.getY()));
                String date=jsonObject.optString("navDate");
                tvDate.setText("on "+UtilityKotlin.formatApiGraphMarkerDate(date));

            }


        }catch (Exception ea){
ea.printStackTrace();
        }
        super.refreshContent(e, highlight);
    }

    @Override
    public MPPointF getOffset() {
        return new MPPointF(-(getWidth() / 2), -getHeight());
    }
}
