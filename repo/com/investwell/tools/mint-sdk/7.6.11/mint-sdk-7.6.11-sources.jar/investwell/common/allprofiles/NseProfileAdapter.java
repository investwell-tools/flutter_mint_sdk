package investwell.common.allprofiles;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.Group;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.Utils;

public class NseProfileAdapter extends RecyclerView.Adapter<NseProfileAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private NseProfileAdapter.OnItemClickListener listener;
    private String mLoggedUserType = "";
    private boolean mIsInvestmentProfile = false;

    public NseProfileAdapter(Context context, boolean isInvestmentProfile, ArrayList<JSONObject> list, NseProfileAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
        mIsInvestmentProfile = isInvestmentProfile;
    }

    @NotNull
    @Override
    public NseProfileAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.nse_profile_adapter, viewGroup, false);
        return new NseProfileAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final NseProfileAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position, JSONObject status, String name);

        void onCheckClick(int position, JSONObject status);

        void onProfileItemClick(int position);

        void onMandateItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvManageProfile, tvAddMandate, tvPendingReason, tv_profile_name, tv_holding_status, tvIIn, tvJointHolderName, tvJointHolderName2;
        ImageView mIvActiveStatus, ivForward;
        LinearLayout llActivateIIN, llButtons, llDesableView;
        View mViewLine;
        CardView cvMain;

        public ViewHolder(View view) {
            super(view);
            tv_profile_name = view.findViewById(R.id.tv_profile_name);
            tvIIn = view.findViewById(R.id.tvIIN);
            tvJointHolderName = view.findViewById(R.id.tv_joint_holder_name);
            tvJointHolderName2 = view.findViewById(R.id.tv_joint_holder_name_2);
            tv_holding_status = view.findViewById(R.id.tv_holding_status);
            mIvActiveStatus = view.findViewById(R.id.ivStatus);
            llActivateIIN = view.findViewById(R.id.llActivateIIN);
            tvManageProfile = view.findViewById(R.id.tvManageProfile);
            tvAddMandate = view.findViewById(R.id.tvAddMandate);
            llButtons = view.findViewById(R.id.llButtons);
            mViewLine = view.findViewById(R.id.viewLine);
            cvMain = view.findViewById(R.id.cvMain);
            llDesableView = view.findViewById(R.id.llDesableView);
            ivForward = view.findViewById(R.id.ivForward);
            tvPendingReason = view.findViewById(R.id.tvPendingReason);

        }


        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final NseProfileAdapter.OnItemClickListener listener) {
            try {
                final JSONObject jsonObject = mDataList.get(position);

                tvPendingReason.setVisibility(View.GONE);
                if (jsonObject.optString("activationStatus").equalsIgnoreCase("yes")) {
                    mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_green);
                    llActivateIIN.setVisibility(View.GONE);

                } else {
                    mIvActiveStatus.setBackgroundResource(R.drawable.circle_image_red);
                    llActivateIIN.setVisibility(View.VISIBLE);
                   String value =  jsonObject.optString("iinDeactivationReason");
                    if (!value.equals("null") && !value.equals("")){
                        tvPendingReason.setVisibility(View.VISIBLE);
                        tvPendingReason.setText(jsonObject.optString("iinDeactivationReason"));
                    }
                }

                if (mIsInvestmentProfile) {
                    llButtons.setVisibility(View.GONE);
                    mViewLine.setVisibility(View.GONE);
                    llActivateIIN.setVisibility(View.GONE);
                    ivForward.setVisibility(View.VISIBLE);
                    if (jsonObject.optString("activationStatus").equalsIgnoreCase("yes")) {
                        llDesableView.setVisibility(View.GONE);
                    } else {
                        llDesableView.setVisibility(View.VISIBLE);
                    }

                } else {
                    llButtons.setVisibility(View.VISIBLE);
                    mViewLine.setVisibility(View.VISIBLE);
                    llDesableView.setVisibility(View.GONE);
                    ivForward.setVisibility(View.GONE);
                }


                jsonObject.put("LoginUserType", mLoggedUserType);


                if (!TextUtils.isEmpty(jsonObject.optString("JH1Name")) && !jsonObject.optString("JH1Name").equalsIgnoreCase("null")) {
                    tvJointHolderName.setText(jsonObject.optString("JH1Name"));
                    tvJointHolderName.setVisibility(View.VISIBLE);
                } else {
                    tvJointHolderName.setVisibility(View.GONE);
                }
                if (!TextUtils.isEmpty(jsonObject.optString("JH2Name")) && !jsonObject.optString("JH2Name").equalsIgnoreCase("null")) {
                    tvJointHolderName2.setText(jsonObject.optString("JH2Name"));
                    tvJointHolderName2.setVisibility(View.VISIBLE);
                } else {
                    tvJointHolderName2.setVisibility(View.GONE);
                }

                if ((!TextUtils.isEmpty(jsonObject.optString("holding")) && !jsonObject.optString("holding").equalsIgnoreCase("null")) || (!TextUtils.isEmpty(jsonObject.optString("holdingNatureDescription")) && !jsonObject.optString("holdingNatureDescription").equalsIgnoreCase("null"))) {
                    tv_holding_status.setVisibility(View.VISIBLE);
                } else {
                    tv_holding_status.setVisibility(View.GONE);
                }
                if (mLoggedUserType.equalsIgnoreCase("broker")) {
                    tv_profile_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("name")));
                    tv_holding_status.setText(" | " + Utils.setFirstLetterCapital(jsonObject.optString("holding")));
                    if ((!TextUtils.isEmpty(jsonObject.optString("iinNo")) && !jsonObject.optString("iinNo").equalsIgnoreCase("null"))) {
                        tvIIn.setText(jsonObject.optString("iinNo"));
                        tvIIn.setVisibility(View.VISIBLE);
                    } else {
                        tvIIn.setVisibility(View.GONE);
                    }
                } else {
                    tv_profile_name.setText(Utils.setFirstLetterCapital(jsonObject.optString("investorName")));
                    tv_holding_status.setText(" | " + Utils.setFirstLetterCapital(jsonObject.optString("holdingNatureDescription")));
                    if ((!TextUtils.isEmpty(jsonObject.optString("customerid")) && !jsonObject.optString("customerid").equalsIgnoreCase("null"))) {
                        tvIIn.setText(jsonObject.optString("customerid"));
                        tvIIn.setVisibility(View.VISIBLE);
                    } else {
                        tvIIn.setVisibility(View.INVISIBLE);
                    }
                }



                itemView.setOnClickListener(v -> {
                    if (jsonObject.optString("activationStatus").equalsIgnoreCase("Yes"))
                        listener.onItemClick(position, jsonObject, tv_profile_name.getText().toString());

                });
                llActivateIIN.setOnClickListener(v -> listener.onCheckClick(position, jsonObject));
                tvManageProfile.setOnClickListener(v -> listener.onProfileItemClick(position));
                tvAddMandate.setOnClickListener(v -> listener.onMandateItemClick(position));
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }


        }

    }

    public void updateList(List<JSONObject> list, String mLoginType, Boolean isSearch) {
        if (isSearch) {
            mDataList.clear();
        }
        mLoggedUserType = mLoginType;
        mDataList.addAll(list);


        notifyDataSetChanged();
    }


}

