package investwell.common.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.StateVO;

public class MyAdapter extends ArrayAdapter<StateVO> {
    private Context mContext;
    public ArrayList<StateVO> mDataList;
    private boolean isFromView = false;
    private MyAdapter.OnItemClickListener listener;

    public MyAdapter(Context context , int resource, List<StateVO> objects,  MyAdapter.OnItemClickListener listener) {
        super(context, resource, objects);
        this.mContext = context;
        this.mDataList = (ArrayList<StateVO>) objects;
        this.listener = listener;
    }


    public interface OnItemClickListener {
        void onItemClick(int position);
    }


    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(final int position, View convertView,
                              ViewGroup parent) {

        final ViewHolder holder;
        if (convertView == null) {
            LayoutInflater layoutInflator = LayoutInflater.from(mContext);
            convertView = layoutInflator.inflate(R.layout.spinner_item_checkbox, null);
            holder = new ViewHolder();
            holder.mTextView =  convertView.findViewById(R.id.text);
            holder.mCheckBox = convertView.findViewById(R.id.checkbox);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.mTextView.setText(mDataList.get(position).getTitle());
        holder.mTextView.setOnClickListener(v -> {
            // Toggle the checkbox state
            boolean newState = !holder.mCheckBox.isChecked();
            holder.mCheckBox.setChecked(newState);

            // Update data and trigger listener
            mDataList.get(position).setSelected(newState);
            listener.onItemClick(position);
        });


        // To check weather checked event fire from getview() or user input
        isFromView = true;
        holder.mCheckBox.setChecked(mDataList.get(position).isSelected());
        isFromView = false;

       
        holder.mCheckBox.setTag(position);
        holder.mCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int getPosition = (Integer) buttonView.getTag();

                if (!isFromView) {
                    mDataList.get(position).setSelected(isChecked);
                    listener.onItemClick(position);
                }
            }
        });
        return convertView;
    }

    private class ViewHolder {
        private TextView mTextView;
        private CheckBox mCheckBox;
    }
}