package investwell.common.topscheme.adapter;

import static investwell.utils.UtilityKotlin.getPicassoTransform;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import investwell.utils.AppSession;
import investwell.utils.Config;

public class SearchSchemeAdapter extends RecyclerView.Adapter<SearchSchemeAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private OnTopSchemeClickListener listener;
    private String mSelectedData = "";
    private AppSession mSession ;

    public SearchSchemeAdapter(Context context, ArrayList<JSONObject> list, OnTopSchemeClickListener listener) {
        mContext = context;
        mDataList = list;
        mSession = AppSession.getInstance(mContext);
        this.listener = listener;
    }

    @NotNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_top_scheme_new, viewGroup, false);
        return new SearchSchemeAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SearchSchemeAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnTopSchemeClickListener {
        void onItemClick(int position, JSONObject mJsonData);

        void onTopSchemeNameClick(JSONObject mJObject);

        void onByClick(JSONObject mJObject);

        void onAddFavClick(JSONObject mJObject);
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llTopSchemeCart;
        TextView tvTopSchemeName, tvTopSchemeReturn;
        ImageView topSchemeCartadd, ivTopSchemeImage, ivFundPick;


        public ViewHolder(View view) {
            super(view);
            llTopSchemeCart = view.findViewById(R.id.ll_top_scheme_cart);
            tvTopSchemeName = view.findViewById(R.id.tv_top_scheme_name);
            topSchemeCartadd = view.findViewById(R.id.top_scheme_cartadd);
            ivFundPick = view.findViewById(R.id.ivFundPick);
            ivTopSchemeImage = view.findViewById(R.id.iv_top_scheme_image);
            tvTopSchemeReturn = view.findViewById(R.id.tv_top_scheme_return);
        }

        @SuppressLint("SetTextI18n")
        public void setItem(final int position, final SearchSchemeAdapter.OnTopSchemeClickListener listener) {
            JSONObject topSchemeData = mDataList.get(position);

            try {
                Boolean hasVisibilityFound = false;
                if (mSession.getAllowedFeatures().length() > 0) {
                    JSONObject jsonObject = new JSONObject(mSession.getAllowedFeatures());
                    JSONArray jsonArray = jsonObject.optJSONArray("data");
                    for (int i = 0; i <jsonArray.length() ; i++) {
                        if (jsonArray.optJSONObject(i).has("feature1017") && mSession.getExchangeNseBseMfu().equals("1")){
                            hasVisibilityFound = true;
                        }else if (jsonArray.optJSONObject(i).has("feature1021") && mSession.getExchangeNseBseMfu().equals("2")){
                            hasVisibilityFound = true;
                        }else if (jsonArray.optJSONObject(i).has("feature1024") && mSession.getExchangeNseBseMfu().equals("3")){
                            hasVisibilityFound = true;
                        }else if (jsonArray.optJSONObject(i).has("feature1042") && mSession.getExchangeNseBseMfu().equals("4")){
                            hasVisibilityFound = true;
                        }
                    }
                    if (hasVisibilityFound) {
                        llTopSchemeCart.setVisibility(View.VISIBLE);
                    } else {
                        llTopSchemeCart.setVisibility(View.INVISIBLE);
                    }
                }

                if (!topSchemeData.optString("schemeGroupName").equals("") && !topSchemeData.optString("schemeGroupName").equals("null")) {
                    tvTopSchemeName.setText(topSchemeData.optString("schemeGroupName"));
                }
                if (topSchemeData.optInt("isRecommended") == 1) {
                    ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) topSchemeCartadd.getLayoutParams();
                    params.setMargins(0,-16,0,0);
                    ivFundPick.setVisibility(View.VISIBLE);
                    topSchemeCartadd.setLayoutParams(params);
                } else {
                    ivFundPick.setVisibility(View.GONE);
                }


                if (!TextUtils.isEmpty(topSchemeData.optString("fundName")) && !topSchemeData.optString("fundName").equals("null")) {
                    String mSchemeImageUrl = Config.GET_FUND_IMAGE_URL+topSchemeData.optString("fundName")+".png";
                    if (mSchemeImageUrl.contains("&")) {
                        mSchemeImageUrl = mSchemeImageUrl.replace("&", "");
                    }

                    mSchemeImageUrl = mSchemeImageUrl.replaceAll("\\s+", "");
                    Picasso.get().load(mSchemeImageUrl).error(R.mipmap.tranparent).transform(getPicassoTransform()).into(ivTopSchemeImage);
                }

                if (!TextUtils.isEmpty(mSelectedData)) {
                    if (mSelectedData.equals("1Day")){
                        if (topSchemeData.optString("1Day").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("1Day").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("1Day"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }

                    }else if (mSelectedData.equals("7Day")){
                        if (topSchemeData.optString("7Day").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("7Day").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("7Day"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("15Day")){
                        if (topSchemeData.optString("15Day").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("15Day").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("15Day"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("30Day")){
                        if (topSchemeData.optString("30Day").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("30Day").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("30Day"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("3Month")){
                        if (topSchemeData.optString("3Month").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("3Month").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("3Month"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("6Month")){
                        if (topSchemeData.optString("6Month").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("6Month").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("6Month"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("1Year")){
                        if (topSchemeData.optString("1Year").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("1Year").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("1Year"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("2Year")){
                        if (topSchemeData.optString("2Year").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("2Year").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("2Year"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("3Year")){
                        if (topSchemeData.optString("3Year").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("3Year").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("3Year"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("5Year")){
                        if (topSchemeData.optString("5Year").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("5Year").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("5Year"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }else if (mSelectedData.equals("10Year")){
                        if (topSchemeData.optString("10Year").contains("-")) {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.red_text_color));
                        } else {
                            tvTopSchemeReturn.setTextColor(ContextCompat.getColor(mContext, R.color.green_text_color));
                        }

                        if(!topSchemeData.optString("10Year").equals("null")) {
                            String value = String.format("%.2f", topSchemeData.optDouble("10Year"));
                            tvTopSchemeReturn.setText(value+" %");
                        }else{
                            String value = String.format("%.2f", 0.0);
                            tvTopSchemeReturn.setText(value+" %");
                        }
                    }


                }



            }catch (Exception e){

            }
            itemView.setOnClickListener(v -> {
                listener.onItemClick(position, topSchemeData);
            });
            tvTopSchemeName.setOnClickListener(v -> listener.onTopSchemeNameClick( topSchemeData));
            topSchemeCartadd.setOnClickListener(v -> listener.onByClick(topSchemeData));

        }

    }


    public void updateList(List<JSONObject> list, String mSelectedReturnDate) {
        mDataList.clear();
        mSelectedData = mSelectedReturnDate;
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
