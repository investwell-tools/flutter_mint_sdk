package investwell.client.fragments.transection.additional.purchase;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.CurrencyTextToWord;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.activity.PaymentActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.RecycleBankAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.debugmode.db.ApiDataBase;
import investwell.common.debugmode.db.ApiDataModel;
import investwell.common.debugmode.db.AppExecutors;
import investwell.utils.AppConstants;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.TimeDateUtils;
import investwell.utils.Utils;
import investwell.utils.customView.CustomDialog;
import investwell.utils.edittext.MaskedEditText;


public class  FragAdditionalPurchaseNse extends BaseFragment implements View.OnClickListener {
    private TextView mTvcardview_top_name_color, mTvListLavel, mTvBuy,tvWordAmount;
    private RequestQueue requestQueue;
    private EditText mEtAmount, mEtTransferNo, mEtChequeNumber, etChequeMICRr;
    private MaskedEditText mMaskDate, mMaskDateChequeDate;

    private ClientActivity mActivity;
    private AppSession mSession;
    private JSONObject mOldJsonObject, tranJsonObject, mObjNewScheme;
    private RadioGroup mRadioGroup1;
    private RadioButton mRadioButton1, mRadioButton2;
    private LinearLayout mLinerCheckBox1, mLinerCheckBox2, mLinerCheckBox3, mLinerCheckBox4, mLinerCheckBox5;
    private CheckBox mCheckBox1, mCheckBox2, mCheckBox3, mCheckBox4, mCheckBox5;

    private RelativeLayout mRelFilterMain;
    private LinearLayout mLinerPaymentOption, mLinerBankList, mLinerDate,
            mLinerCheque, mLinerChequeDate;
    private ScrollView mLinFilterPart;
    private Animation slideUpAnimation, slideDownAnimation;
    private RecycleBankAdapter mBankAdapter;
    private AppApplication mAppApplication;
    private ArrayList<JSONObject> mSchemeList, mBankList, mMandateList;
    private String mPaymentMode = "", mSchemeName = "", mSchemeType = "", mTransactionType = "", mPaymentOption = "";
    private boolean mIsRightDateFormateForMask2 = false;
    private boolean mIsBuyButtonEnable = false;
    private RadioGroup mRadioGroupSchemeType;
    private TextView mTvLavelSchemeType;
    private ToolbarFragment mFragToolBar;
    private ApiDataBase db;

    private List<JSONObject> mJsonARNList;
    private Spinner mSpArn;
    private LinearLayout mLlArn;

    private String mChequeMode = "MFSS";
    private Spinner mSpChequeMode;
    private LinearLayout mllChequeMode;
    private String mSelectedAccType="";

    private void insertApiData(String url, String req, String res, String dateTime,String endPoint) {
        final ApiDataModel api = new ApiDataModel(
                url,
                req,
                res,
                AppConstants.ADDITIONAL_PURCHASE,
                dateTime,
                endPoint);

        AppExecutors.getInstance().diskIO().execute(() -> db.apiDao().insertApiData(api));
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppApplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        mRelFilterMain.setVisibility(View.GONE);
    }

    @Override
    public void onStart() {
        super.onStart();
        mMaskDate.setError(null);
        mMaskDateChequeDate.setError(null);
    }

    @Override
    public void onResume() {
        super.onResume();
   /*     if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    private void setUpToolBar() {
        mFragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (mFragToolBar != null) {
            mFragToolBar.setUpToolBar(getResources().getString(R.string.AdditionalPurchase), true, false, false, false, false, false, false);
        }
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_additional_purchage_nse, container, false);
        db = ApiDataBase.getInstance(mActivity.getApplicationContext());
        setUpToolBar();
        mMandateList = new ArrayList<>();

        mSpArn = view.findViewById(R.id.spArn);
        mLlArn = view.findViewById(R.id.llArn);
        mLlArn.setVisibility(View.GONE);
        if (mSession.getLoginType().equals("broker")) {
            getArnList();
        }

        TextView user_name = view.findViewById(R.id.user_name);
        TextView tvINN = view.findViewById(R.id.tvINN);
        TextView tvFolio = view.findViewById(R.id.tvFolio);
        mTvcardview_top_name_color = view.findViewById(R.id.cardview_top_name_color);
        mEtAmount = view.findViewById(R.id.amount);
        tvWordAmount = view.findViewById(R.id.tvWordAmount);

        mMaskDate = view.findViewById(R.id.dateofBirth);
        mMaskDateChequeDate = view.findViewById(R.id.etChequeDate);
        mEtChequeNumber = view.findViewById(R.id.etChequeNumber);

        mSpChequeMode = view.findViewById(R.id.spChequeDepositMode);
        mllChequeMode = view.findViewById(R.id.llChequeDepositMode);
        mllChequeMode.setVisibility(View.GONE);

        mTvBuy = view.findViewById(R.id.tvBuy);
        mEtTransferNo = view.findViewById(R.id.etTransferNo);
        mTvListLavel = view.findViewById(R.id.tvListLavel);
        mRadioGroup1 = view.findViewById(R.id.radioGroup1);
        mRadioButton1 = view.findViewById(R.id.radio1);
        mRadioButton2 = view.findViewById(R.id.radio2);
        mLinerPaymentOption = view.findViewById(R.id.linerPaymentOption);
        mLinerBankList = view.findViewById(R.id.linerBankList);
        mLinerDate = view.findViewById(R.id.linerDate);
        mLinerCheque = view.findViewById(R.id.linerCheque);
        mLinerChequeDate = view.findViewById(R.id.linerChequeDate);
        etChequeMICRr = view.findViewById(R.id.etChequeMICRr);

        mLinerPaymentOption.setVisibility(View.GONE);
        mLinerBankList.setVisibility(View.GONE);
        mLinerDate.setVisibility(View.GONE);
        mLinerCheque.setVisibility(View.GONE);
        mLinerChequeDate.setVisibility(View.GONE);


        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mRelFilterMain.setVisibility(View.GONE);

        slideUpAnimation = AnimationUtils.loadAnimation(mActivity, R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(mActivity, R.anim.slide_down);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        mTvLavelSchemeType = view.findViewById(R.id.tvLavelSchemeType);
        mRadioGroupSchemeType = view.findViewById(R.id.radioGroup2);
        mRadioGroupSchemeType.setVisibility(View.GONE);
        mTvLavelSchemeType.setVisibility(View.GONE);

        mLinerCheckBox1 = view.findViewById(R.id.linerCheck1);
        mLinerCheckBox2 = view.findViewById(R.id.linerCheck2);
        mLinerCheckBox3 = view.findViewById(R.id.linerCheck3);
        mLinerCheckBox4 = view.findViewById(R.id.linerCheck4);
        mLinerCheckBox5 = view.findViewById(R.id.linerCheck5);

        mCheckBox1 = view.findViewById(R.id.checkbox1);
        mCheckBox2 = view.findViewById(R.id.checkbox2);
        mCheckBox3 = view.findViewById(R.id.checkbox3);
        mCheckBox4 = view.findViewById(R.id.checkbox4);
        mCheckBox5 = view.findViewById(R.id.checkbox5);

        mCheckBox1.setOnClickListener(this);
        mCheckBox2.setOnClickListener(this);
        mCheckBox3.setOnClickListener(this);
        mCheckBox4.setOnClickListener(this);
        mCheckBox5.setOnClickListener(this);

        view.findViewById(R.id.ivEdit).setOnClickListener(this);
        view.findViewById(R.id.tvPaymentMode).setOnClickListener(this);
        view.findViewById(R.id.tvBuy).setOnClickListener(this);

        RecyclerView recycleView = view.findViewById(R.id.recycleView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(mActivity);
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recycleView.setLayoutManager(layoutManager);
        recycleView.setHasFixedSize(true);
        WindowManager wm = (WindowManager) mActivity.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        int width = display.getWidth();

        mBankList = new ArrayList<>();
        mBankAdapter = new RecycleBankAdapter(mActivity, new ArrayList<JSONObject>(), width, new RecycleBankAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                try {
                    /*  JSONObject jsonObject = mFolioLookupAdapter.mDataList.get(position);
                     */
                    setButtonEnability();
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        });
        recycleView.setAdapter(mBankAdapter);

        mSchemeList = new ArrayList<>();

        Bundle bundle = getArguments();
        if (bundle != null) {
            try {
                mOldJsonObject = new JSONObject(bundle.getString("oldObject"));
                tranJsonObject = new JSONObject(bundle.getString("tranJsonObject"));
                mTransactionType = bundle.getString("transactionType");

                user_name.setText(mOldJsonObject.optString("applicant_name"));
                mTvcardview_top_name_color.setText(mOldJsonObject.optString("schemeName"));
                tvINN.setText(mOldJsonObject.optString("iinNo"));
                tvFolio.setText(mOldJsonObject.optString("folioNo"));

            } catch (JSONException e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
        }


        mRadioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radio1) {
                        if (mPaymentMode.equalsIgnoreCase("netBanking") || mPaymentMode.equals("upi")) {
                            mPaymentOption = "payNow";
                            mLinerBankList.setVisibility(View.VISIBLE);

                        } else if (mPaymentMode.equalsIgnoreCase("RTGS")) {
                            mPaymentOption = "pay_later";
                            mLinerDate.setVisibility(View.GONE);
                        }
                        setButtonEnability();
}
else if (checkedId == R.id.radio2) {
                        if (mPaymentMode.equalsIgnoreCase("netBanking") || mPaymentMode.equals("upi")) {
                            mPaymentOption = "email";
                            mLinerBankList.setVisibility(View.VISIBLE);
                        } else if (mPaymentMode.equalsIgnoreCase("RTGS")) {
                            mPaymentOption = "already_paid";
                            mLinerDate.setVisibility(View.VISIBLE);
                        }
                        setButtonEnability();
}
            }
        });


        mRadioGroupSchemeType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioSchemeType1) {
                        mSchemeType = "G";
}
else if (checkedId == R.id.radioSchemeType2) {
                        mSchemeType = "DP";
}
else if (checkedId == R.id.radioSchemeType3) {
                        mSchemeType = "DR";
}
            }
        });
        setInvestmentType();

        mMaskDate.addTextChangedListener(new TextWatcher() {
            int beforeTextChangedLength;

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                beforeTextChangedLength = charSequence.length();
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                int length = editable.length();
                // text is being removed
                if (beforeTextChangedLength > length)
                    return;

                String str = editable.toString();

                if (str.length() == 10) {
                    if (validateDateFormat(str)) {
                        setButtonEnability();
                    } else {
                        mMaskDate.setError("");
                        mMaskDate.requestFocus();
                        setButtonEnability();
                    }
                } else {
                    mMaskDate.setError("");
                    mMaskDate.requestFocus();
                    setButtonEnability();
                }
            }
        });

        mMaskDateChequeDate.addTextChangedListener(new TextWatcher() {
            int beforeTextChangedLength;

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                beforeTextChangedLength = charSequence.length();
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                int length = editable.length();
                // text is being removed
                if (beforeTextChangedLength > length)
                    return;

                String str = editable.toString();

                if (str.length() == 10) {
                    if (validateDateFormat(str)) {
                        mIsRightDateFormateForMask2 = true;
                        setButtonEnability();
                    } else {
                        mIsRightDateFormateForMask2 = false;
                        setButtonEnability();
                        mMaskDateChequeDate.setError("");
                        mMaskDateChequeDate.requestFocus();
                    }
                } else {
                    mIsRightDateFormateForMask2 = false;
                    mMaskDateChequeDate.setError("");
                    mMaskDateChequeDate.requestFocus();
                    setButtonEnability();
                }
            }
        });

        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });


        mEtTransferNo.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                setButtonEnability();
            }
        });

        mEtChequeNumber.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                setButtonEnability();
            }
        });

        setButtonEnability();
        getBankList(false);
        getMandateList(false);
        setChecqueMode();

        mEtAmount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String word ="";
                if (!TextUtils.isEmpty(charSequence)){
                    try {
                        if (charSequence.length() !=0){
                            word = CurrencyTextToWord.convertToIndianCurrency(requireContext(),charSequence.toString().trim());
                        }else {
                            word =UtilityKotlin.firstLetterCapitalOfSentence("");
                        }
                    }catch (Exception e){
                        if (BuildConfig.DEBUG)
                        e.printStackTrace();
                    }
                }else {
                    word = UtilityKotlin.firstLetterCapitalOfSentence("");
                }
                tvWordAmount.setText(word);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        return view;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivEdit) {
                if (mSchemeList.size() > 0) {
                    showSchemesDailog();
                } else {
                    getSchemes(mOldJsonObject.optString("fundid"));
                }
}
else if (v.getId() == R.id.tvPaymentMode) {
                checkValidation();
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.tvBuy) {
                if (mIsBuyButtonEnable)
                    placePurchageNSE(false);
}
else if (v.getId() == R.id.checkbox1) {
                if (mCheckBox1.isChecked()) {
                    mLinerCheckBox1.setBackgroundResource(R.drawable.selected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(true);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);
                    mPaymentMode = "netBanking";

                    mTvListLavel.setText(getString(R.string.Choose_Bank));
                    mRadioButton1.setText(getString(R.string.Pay_Now));
                    mRadioButton2.setText(getString(R.string.Send_Payment));
                    mRadioButton1.setChecked(false);
                    mRadioButton2.setChecked(false);

                    if (mBankList.size() > 0) {
                        mBankAdapter.updateList(mBankList, mPaymentMode);
                    } else {
                        getBankList(true);
                    }

                    mLinerPaymentOption.setVisibility(View.VISIBLE);
                    mLinerBankList.setVisibility(View.VISIBLE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);

                } else {
                    mPaymentMode = "";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);
                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerBankList.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);

                }
                setButtonEnability();
}
else if (v.getId() == R.id.checkbox2) {
                if (mCheckBox2.isChecked()) {
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.selected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(true);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);
                    mPaymentMode = "Mandate";

                    mTvListLavel.setText(getString(R.string.Choose_Mandate));
                    if (mMandateList.size() > 0) {
                        mBankAdapter.updateList(mMandateList, mPaymentMode);
                    } else {
                        getMandateList(true);
                    }
                    mLinerBankList.setVisibility(View.VISIBLE);
                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);
                } else {
                    mPaymentMode = "";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);

                    mLinerBankList.setVisibility(View.GONE);
                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);

                }
                setButtonEnability();
}
else if (v.getId() == R.id.checkbox3) {
                if (mCheckBox3.isChecked()) {
                    mPaymentMode = "RTGS";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.selected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(true);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);

                    mTvListLavel.setText(getString(R.string.Choose_Bank));
                    if (mBankList.size() > 0) {
                        mBankAdapter.updateList(mBankList, mPaymentMode);
                    } else {
                        getBankList(true);
                    }

                    mLinerPaymentOption.setVisibility(View.VISIBLE);
                    mRadioButton1.setText(getString(R.string.Pay_Later));
                    mRadioButton2.setText(getString(R.string.Already_Paid));
                    mRadioButton1.setChecked(false);
                    mRadioButton2.setChecked(false);

                    mLinerBankList.setVisibility(View.VISIBLE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);

                } else {
                    mPaymentMode = "";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);

                    mLinerBankList.setVisibility(View.GONE);
                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);
                }
                setButtonEnability();
}
else if (v.getId() == R.id.checkbox4) {
                if (mCheckBox4.isChecked()) {
                    mPaymentMode = "cheque";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.selected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(true);
                    mCheckBox5.setChecked(false);

                    mTvListLavel.setText(getString(R.string.Choose_Bank));
                    if (mBankList.size() > 0) {
                        mBankAdapter.updateList(mBankList, mPaymentMode);
                    } else {
                        getBankList(true);
                    }

                    mLinerBankList.setVisibility(View.VISIBLE);
                    mLinerChequeDate.setVisibility(View.VISIBLE);
                    mLinerCheque.setVisibility(View.VISIBLE);
                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.VISIBLE);
                } else {
                    mPaymentMode = "";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);

                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerBankList.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);
                }
                setButtonEnability();
}
else if (v.getId() == R.id.checkbox5) {
                if (mCheckBox5.isChecked()) {
                    mPaymentMode = "upi";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.selected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(true);

                    mTvListLavel.setText(getString(R.string.Choose_Bank));
                    if (mBankList.size() > 0) {
                        mBankAdapter.updateList(mBankList, mPaymentMode);
                    } else {
                        getBankList(true);
                    }

                    mLinerBankList.setVisibility(View.VISIBLE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerPaymentOption.setVisibility(View.VISIBLE);
                    mLinerDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);
                } else {
                    mPaymentMode = "";
                    mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mLinerCheckBox5.setBackgroundResource(R.drawable.unselected_payment_mode);
                    mCheckBox1.setChecked(false);
                    mCheckBox2.setChecked(false);
                    mCheckBox3.setChecked(false);
                    mCheckBox4.setChecked(false);
                    mCheckBox5.setChecked(false);

                    mLinerPaymentOption.setVisibility(View.GONE);
                    mLinerBankList.setVisibility(View.GONE);
                    mLinerDate.setVisibility(View.GONE);
                    mLinerCheque.setVisibility(View.GONE);
                    mLinerChequeDate.setVisibility(View.GONE);
                    mllChequeMode.setVisibility(View.GONE);
                }
                setButtonEnability();
}
    }

    private void setButtonEnability() {
        boolean isRadio1Checked1 = mRadioButton1.isChecked();
        boolean isRadioChecked2 = mRadioButton2.isChecked();
        if (mPaymentMode.equalsIgnoreCase("netBanking")) {
            if (!mCheckBox1.isChecked()) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (!isRadio1Checked1 && !isRadioChecked2) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (mBankAdapter.mHashSelection.containsValue(true)) {
                mTvBuy.setBackgroundResource(R.drawable.background_blue);
                mIsBuyButtonEnable = true;
            } else {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            }

        }else if (mPaymentMode.equalsIgnoreCase("upi")) {
            if (!mCheckBox5.isChecked()) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            }else if (!isRadio1Checked1 && !isRadioChecked2) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (mBankAdapter.mHashSelection.containsValue(true)) {
                mTvBuy.setBackgroundResource(R.drawable.background_blue);
                mIsBuyButtonEnable = true;
            } else {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            }

        } else if (mPaymentMode.equalsIgnoreCase("Mandate")) {
            if (!mCheckBox2.isChecked()) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (mBankAdapter.mHashSelection.containsValue(true)) {
                mTvBuy.setBackgroundResource(R.drawable.background_blue);
                mIsBuyButtonEnable = true;
            } else {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            }
        } else if (mPaymentMode.equalsIgnoreCase("RTGS")) {
            if (!mCheckBox3.isChecked()) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (!isRadio1Checked1 && !isRadioChecked2) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false; //   mPaymentOption = "already_paid";
            } else if (mPaymentOption.equalsIgnoreCase("already_paid")) {
                if (mEtTransferNo.getText().toString().isEmpty() || mMaskDate.getText().toString().isEmpty()) {
                    mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                    mIsBuyButtonEnable = false;
                } else if (mIsRightDateFormateForMask2) {
                    mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                    mIsBuyButtonEnable = false;
                } else {
                    mTvBuy.setBackgroundResource(R.drawable.background_blue);
                    mIsBuyButtonEnable = true;
                }
            } else if (mBankAdapter.mHashSelection.containsValue(true)) {
                mTvBuy.setBackgroundResource(R.drawable.background_blue);
                mIsBuyButtonEnable = true;
            } else {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            }

        } else if (mPaymentMode.equalsIgnoreCase("cheque")) {
            if (!mCheckBox4.isChecked()) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (mEtChequeNumber.getText().toString().isEmpty() || mMaskDateChequeDate.getText().toString().isEmpty()) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (!mIsRightDateFormateForMask2) {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            } else if (mBankAdapter.mHashSelection.containsValue(true)) {
                mTvBuy.setBackgroundResource(R.drawable.background_blue);
                mIsBuyButtonEnable = true;
            } else {
                mTvBuy.setBackgroundResource(R.drawable.background_light_gray);
                mIsBuyButtonEnable = false;
            }
        }

    }


    private void checkValidation() {
        if (mEtAmount.getText().toString().equals("")) {
            Toast.makeText(mActivity, getString(R.string.error_empty_amount), Toast.LENGTH_SHORT).show();
        } else {
            Utils.hideKeyboard(mActivity);
            mRelFilterMain.setVisibility(View.VISIBLE);
            mLinFilterPart.startAnimation(slideUpAnimation);

        /*    mCheckBox1.setChecked(false);
            mCheckBox2.setChecked(false);
            mCheckBox3.setChecked(false);
            mCheckBox4.setChecked(false);*/

            mPaymentMode = "";
            mSchemeName = "";
          //  mSchemeType = "";
            mTransactionType = "";
            mPaymentOption = "";
            mIsRightDateFormateForMask2 = false;
            mIsBuyButtonEnable = false;
            mRadioGroup1.clearCheck();
            mRadioGroupSchemeType.clearCheck();

            mMaskDate.setError(null);
            mMaskDateChequeDate.setError(null);

            mLinerCheckBox1.setBackgroundResource(R.drawable.unselected_payment_mode);
            mLinerCheckBox2.setBackgroundResource(R.drawable.unselected_payment_mode);
            mLinerCheckBox3.setBackgroundResource(R.drawable.unselected_payment_mode);
            mLinerCheckBox4.setBackgroundResource(R.drawable.unselected_payment_mode);

            /*
        mCheckBox1.setChecked(false);
        mCheckBox2.setChecked(false);
        mCheckBox3.setChecked(false);
        mCheckBox4.setChecked(false);
        mPaymentMode = "";
        mSchemeType = "";
        mRadioGroup1.invalidate();*/
        }

    }

    private void orderExistsDailog() {
        CustomDialog customDialog = new CustomDialog(view -> {
            if (view.getId() == R.id.btDone) {
                    placePurchageNSE(true);
}
else if (view.getId() == R.id.btCalcel) {
}
        });

        customDialog.showDialog(getActivity(), getString(R.string.alert_dialog_order_exist_header_txt),
                getString(R.string.alert_dialog_order_exist_message_txt),
                getString(R.string.alert_dialog__order_exist_button1),
                getString(R.string.alert_dialog__order_exist_button2),
                true, true);
    }

    private void placePurchageNSE(boolean isIgnoreDuplicate) {
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        String url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.PLACE_NSE_ORDER;
        JSONObject objectMain = new JSONObject();

        try {
            JSONObject investorObject = new JSONObject();
            String levelNo = "", uId = "";
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            investorObject.put("uid", uId);
            investorObject.put("levelNo", levelNo);
            objectMain.put("selectedUser", investorObject);
            objectMain.put("investorUid", uId);
            objectMain.put("uid", uId);
            objectMain.put("schemeType", "");
            objectMain.put("iinNo", mOldJsonObject.optString("iinNo"));
            objectMain.put("subType", "NRP");  // static
            objectMain.put("type", "purchase");  // static
            objectMain.put("paymentAdded", "true"); // static
            objectMain.put("amount", mEtAmount.getText().toString());


            if (mPaymentMode.equalsIgnoreCase("netBanking")) {
                objectMain.put("paymentMode", "online");
            } else if (mPaymentMode.equalsIgnoreCase("Mandate")) {
                objectMain.put("paymentMode", "debitMandate");
            } else if (mPaymentMode.equalsIgnoreCase("RTGS")) {
                objectMain.put("paymentMode", "rtgs/neft");
            } else if (mPaymentMode.equalsIgnoreCase("cheque")) {
                objectMain.put("paymentMode", "cheque");
            }


            JSONObject nseObject = new JSONObject();
            if (mObjNewScheme != null) {
                mSchemeName = mObjNewScheme.optString("name");
                nseObject.put("schemeName", mSchemeName);
                String schemeId = Utils.getSchemeIdFromAll(mObjNewScheme);
                nseObject.put("schid", schemeId);
            } else {
                mSchemeName = mOldJsonObject.optString("schemeName");
                nseObject.put("schemeName", mSchemeName);
                String schemeId = Utils.getSchemeIdFromAll(mOldJsonObject);
                nseObject.put("schid", schemeId);
            }

            nseObject.put("folioNo", mOldJsonObject.optString("folioNo"));
            nseObject.put("folioid", mOldJsonObject.optString("folioid"));
            nseObject.put("amount", mEtAmount.getText().toString());
            nseObject.put("IIN", mOldJsonObject.optString("iinNo"));
            nseObject.put("investmentType", mSchemeType);
            if (mSession.getLoginType().equals("broker")) {
                if (mJsonARNList.size() == 1) {
                    JSONObject folioObject = mJsonARNList.get(0);
                    nseObject.put("arnid", folioObject.optString("arnid"));
                } else {
                    int position = mSpArn.getSelectedItemPosition();
                    if (position == 0)
                        nseObject.put("arnid", "");
                    else {
                        JSONObject folioObject = mJsonARNList.get(position - 1);
                        nseObject.put("arnid", folioObject.optString("arnid"));
                    }
                }
            } else {
                // objectMain.put("arnid", "");
            }
            objectMain.put("item", nseObject);

            JSONObject nsePaymentObject = new JSONObject();
            nsePaymentObject.put("amount", mEtAmount.getText().toString());

            for (int i = 0; i < mBankAdapter.mHashSelection.size(); i++) {
                if (mBankAdapter.mHashSelection.get(i)) {
                    JSONObject jsonObject = mBankAdapter.mDataList.get(i);
                    if(!jsonObject.optString("accType").equalsIgnoreCase("null")){
                        mSelectedAccType = jsonObject.optString("accType");
                    }
                    nsePaymentObject.put("accType", mSelectedAccType);

                    if (mPaymentMode.equalsIgnoreCase("netBanking")) {

                        nsePaymentObject.put("paymentMode", "online");
                        nsePaymentObject.put("bankName", jsonObject.optString("bankName"));
                        nsePaymentObject.put("accNo", jsonObject.optString("accNo"));
                        nsePaymentObject.put("ifsc", jsonObject.optString("ifsc"));
                        nsePaymentObject.put("bankBranch", jsonObject.optString("bankBranch"));
                        nsePaymentObject.put("bankCode", jsonObject.optString("bankCode"));
                        nsePaymentObject.put("investorName", mOldJsonObject.optString("applicant_name"));
                        nsePaymentObject.put("immediatePayment", mPaymentOption.equalsIgnoreCase("payNow"));
                    }else if (mPaymentMode.equalsIgnoreCase("upi")) {
                        nsePaymentObject.put("paymentMode", "upi");
                        objectMain.put("paymentMode", "upi");
                        nsePaymentObject.put("bankName", jsonObject.optString("bankName"));
                        nsePaymentObject.put("accNo", jsonObject.optString("accNo"));
                        nsePaymentObject.put("ifsc", jsonObject.optString("ifsc"));
                        nsePaymentObject.put("bankBranch", jsonObject.optString("bankBranch"));
                        nsePaymentObject.put("bankCode", jsonObject.optString("bankCode"));
                        nsePaymentObject.put("investorName", mOldJsonObject.optString("applicant_name"));
                       // nsePaymentObject.put("immediatePayment", true);
                        nsePaymentObject.put("immediatePayment", mPaymentOption.equalsIgnoreCase("payNow"));

                    } else if (mPaymentMode.equalsIgnoreCase("Mandate")) {
                        nsePaymentObject.put("paymentMode", "debitMandate");
                        nsePaymentObject.put("bankName", jsonObject.optString("bankName"));
                        nsePaymentObject.put("accNo", jsonObject.optString("accNo"));
                        nsePaymentObject.put("ifsc", jsonObject.optString("ifsc"));
                        if (jsonObject.has("branchName"))
                            nsePaymentObject.put("bankBranch", jsonObject.optString("branchName"));
                        else
                            nsePaymentObject.put("bankBranch", jsonObject.optString("bankBranch"));
                        nsePaymentObject.put("mandateId", jsonObject.optString("mandateId"));
                        nsePaymentObject.put("mandateCode", jsonObject.optString("mandateCode"));
                        nsePaymentObject.put("mandateAmount", jsonObject.optString("amount"));
                        nsePaymentObject.put("investorName", jsonObject.optString("investorName"));
                        nsePaymentObject.put("iinMandateId", jsonObject.optString("iinMandateId"));
                    } else if (mPaymentMode.equalsIgnoreCase("RTGS")) {
                        nsePaymentObject.put("paymentMode", "rtgs/neft");
                        nsePaymentObject.put("bankName", jsonObject.optString("bankName"));
                        nsePaymentObject.put("accNo", jsonObject.optString("accNo"));
                        nsePaymentObject.put("ifsc", jsonObject.optString("ifsc"));
                        if (jsonObject.has("branchName"))
                            nsePaymentObject.put("bankBranch", jsonObject.optString("branchName"));
                        else
                            nsePaymentObject.put("bankBranch", jsonObject.optString("bankBranch"));
                        nsePaymentObject.put("bankCode", jsonObject.optString("bankCode"));
                        nsePaymentObject.put("investorName", jsonObject.optString("investorName"));
                        if (mPaymentOption.equalsIgnoreCase("pay_later")) {
                            nsePaymentObject.put("isAlreadyPaid", false);
                        } else {
                            nsePaymentObject.put("isAlreadyPaid", true);
                            nsePaymentObject.put("UTR", mEtTransferNo.getText().toString());

                            String toDate = mMaskDate.getText().toString();
                            SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
                            SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
                            Date date = format1.parse(toDate);
                            String formatedDate = format2.format(date);
                            nsePaymentObject.put("transferDate", formatedDate);


                        }

                    } else if (mPaymentMode.equalsIgnoreCase("cheque")) {
                        nsePaymentObject.put("paymentMode", "cheque");
                        nsePaymentObject.put("bankName", jsonObject.optString("bankName"));
                        nsePaymentObject.put("accNo", jsonObject.optString("accNo"));
                        nsePaymentObject.put("ifsc", jsonObject.optString("ifsc"));
                        if (jsonObject.has("branchName"))
                            nsePaymentObject.put("bankBranch", jsonObject.optString("branchName"));
                        else
                            nsePaymentObject.put("bankBranch", jsonObject.optString("bankBranch"));
                        nsePaymentObject.put("bankCode", jsonObject.optString("bankCode"));
                        nsePaymentObject.put("investorName", jsonObject.optString("investorName"));

                        nsePaymentObject.put("chequeNo", mEtChequeNumber.getText().toString());

                        String toDate = mMaskDateChequeDate.getText().toString();
                        SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
                        SimpleDateFormat format2 = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
                        Date date = format1.parse(toDate);
                        String formatedDate = format2.format(date);
                        nsePaymentObject.put("chequeDate", formatedDate);
                        nsePaymentObject.put("chequeDepositMode", mChequeMode);
                        nsePaymentObject.put("micrNo", etChequeMICRr.getText().toString());

                    }
                }
            }
            if (isIgnoreDuplicate)
                objectMain.put("ignoreDuplicate", "N");
            objectMain.put("paymentDetails", nsePaymentObject);
        } catch (Exception e) {

        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, objectMain, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                UtilityKotlin.setRefreshKey(mSession);
                insertApiData(url,objectMain.toString(), jsonObject.toString(),
                        TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.PLACE_NSE_ORDER);

                mLinFilterPart.startAnimation(slideDownAnimation);
                if (mBar != null)
                    mBar.dismiss();
                try {
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject resultObject = jsonObject.optJSONObject("result");
                        if (!resultObject.optString("status").equalsIgnoreCase("failed")) {
                            if (mPaymentMode.equalsIgnoreCase("netBanking") &&
                                    mPaymentOption.equalsIgnoreCase("payNow")) {
                                JSONObject jsonObject2 = resultObject.optJSONObject("data");
                                JSONArray jsonArray = jsonObject2.optJSONArray("redirectionLinks");
                                String paymentUrl = jsonArray.getString(0);
                                paymentUrl = paymentUrl.replace("<a href='", "");
                                paymentUrl = paymentUrl.replace("</a>", "");
                                String[] rawData = paymentUrl.split("'");

                                Intent intent = new Intent(mActivity, PaymentActivity.class);
                                intent.putExtra("raw_data", rawData[0]);
                                intent.putExtra("type", "payNow");
                                startActivityForResult(intent, 500);
                                //mActivity.getSupportFragmentManager().popBackStack();
                            }else if (mPaymentMode.equalsIgnoreCase("upi") &&
                                    mPaymentOption.equalsIgnoreCase("payNow")) {
                                JSONObject jsonObject2 = resultObject.optJSONObject("data");
                                JSONArray jsonArray = jsonObject2.optJSONArray("redirectionLinks");
                                String paymentUrl = jsonArray.getString(0);
                                paymentUrl = paymentUrl.replace("<a href='", "");
                                paymentUrl = paymentUrl.replace("</a>", "");
                                String[] rawData = paymentUrl.split("'");

                                Intent intent = new Intent(mActivity, PaymentActivity.class);
                                intent.putExtra("raw_data", rawData[0]);
                                intent.putExtra("type", "payNow");
                                startActivityForResult(intent, 500);
                                //mActivity.getSupportFragmentManager().popBackStack();
                            } else {
                                Bundle bundle = new Bundle();

                                bundle.putString("payNowOptionType", mPaymentOption);
                                bundle.putString("PaymentType", mPaymentOption);
                                bundle.putString("resultObject", resultObject.toString());
                                mActivity.displayViewOther(38, bundle);
                            }
                        } else {
                            Bundle bundle = new Bundle();
                            bundle.putString("payNowOptionType", mPaymentOption);
                            bundle.putString("PaymentType", mPaymentOption);
                            bundle.putString("resultObject", resultObject.toString());
                            mActivity.displayViewOther(38, bundle);
                        }


                    } else if (jsonObject.optInt("status") == 3) {
                        orderExistsDailog();
                    } else {
                        String message = jsonObject.optString("message");
                        mAppApplication.showCommonDailog(getActivity(), "Failed", message, "message");
                    }

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {


            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        jsonObjectRequest.setShouldCache(false);
        requestQueue.add(jsonObjectRequest);
    }

    private void getArnList() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "investOnline");


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_ARN_LIST_NSE + "exchange=1" +
                    "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

          /*  https://spvithlani.investwell.app/webapi/client/getArns?
            // exchange=2&investorUid=67c025d3f470b86011712f7f974d669d
            // &selectedUser={"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException | JSONException e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
        final ProgressDialog mBar = ProgressDialog.show(getActivity(), null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        mBar.dismiss();

                        mJsonARNList = new ArrayList<>();
                        ArrayList<String> arnList = new ArrayList<>();

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {
                                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObjectMain.optJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                    arnList.add(jsonObject1.optString("arnNo"));
                                    mJsonARNList.add(jsonObject1);
                                }
                            } else if (jsonObject.optInt("status") == -1) {
                                Toast.makeText(getActivity(), jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {

                        } finally {
                            if (mJsonARNList.size() > 1) {
                                mLlArn.setVisibility(View.VISIBLE);
                                setArnList(arnList);
                            }else{
                                mLlArn.setVisibility(View.GONE);
                            }


                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar !=null) mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }




    private void setArnList(List<String> list) {
        try {
            list.add(0, getString(R.string.select_arn_2));
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            mSpArn.setAdapter(dataAdapter);
           

        } catch (Exception e) {

        }
    }




    private void getBankList(final boolean isShowLoader) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";
        try {

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_NSE_BANKS + "iinNo=" +
                    mOldJsonObject.optString("iinNo") + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }
        if (isShowLoader) {
            mAppApplication.showProgressBar(mActivity);
        }
        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl,"GET REQ contains REQ in URL", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_NSE_BANKS);

                        if (isShowLoader)
                            mAppApplication.hideProgressDaolog();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject resultObject = jsonObject.optJSONObject("result");
                            JSONArray jsonArray = resultObject.optJSONArray("data");
                            mBankList = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                mBankList.add(jsonArray.optJSONObject(i));
                            }
                            // mBankAdapter.updateList(mBankList, mPaymentMode);
                            mBankAdapter.updateList(mBankList, "netBanking");
                        } catch (Exception e) {

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (isShowLoader)
                            mAppApplication.hideProgressDaolog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getMandateList(final boolean isShowLoader) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }

        String url = "";
        try {

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String TodayDate = simpleDateFormat.format(new Date());

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_MANDATE_BANKS + "iinNo=" +
                    mOldJsonObject.optString("iinNo") + "&paymentDate=" + TodayDate + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession);
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }
        if (isShowLoader) {
            mAppApplication.showProgressBar(mActivity);
        }
        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl,"GET REQ contains REQ in URL", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_MANDATE_BANKS);

                        if (isShowLoader)
                            mAppApplication.hideProgressDaolog();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONObject resultObject = jsonObject.optJSONObject("result");
                            JSONArray jsonArray = resultObject.optJSONArray("data");
                            mMandateList = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                mMandateList.add(jsonArray.optJSONObject(i));
                            }

                            if (mMandateList.size() == 0) {
                                mMandateList.add(new JSONObject());
                            }
                            //  mBankAdapter.updateList(mMandateList, mPaymentMode);
                        } catch (Exception e) {

                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (isShowLoader)
                            mAppApplication.hideProgressDaolog();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getSchemes(String fundId) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        String url = "";

        try {
            String varableForBSeMfu  = "&hasNseCode=true";
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +
                    Config.GET_FUND_SCHEAMES + "fundid=" + fundId + "&exchange=1" +varableForBSeMfu
                    + "&investorUid=" + Utils.getSelectedUid(mSession) +"&selectedUser="+Utils.getSelectedUserObject(mSession);

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }


        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl,"GET REQ Contains REQ in URL", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_FUND_SCHEAMES);

                        if (mBar != null)
                            mBar.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                JSONObject jsonObject1 = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = jsonObject1.getJSONArray("data");
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    mSchemeList.add(jsonArray.optJSONObject(i));
                                }
                                showSchemesDailog();
                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (mBar != null)
                            mBar.dismiss();
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(mActivity);
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void getAllTransectionTypes() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        try {

            String schemeId = Utils.getSchemeIdFromAll(mObjNewScheme);
            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath()
                    + Config.GET_TRANSECTION_TYPE + "schid=" +schemeId +
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession)+ "&bid=" + mSession.getBid() +
                    "&levelid=" + mSession.getLevelId();
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");


            /*https://spvithlani.investwell.app/webapi/client/investOnline/getSchemeNSEInfo?
            schid=9e539c7cf67bc5232e1e40581ba682ee
            &hasBseCode=true
            &bid=
            a14223ec0adf09805f758441c455d58a
            &levelid=7ecb1293761347d78cf6b8f857435249
            &investorUid=67c025d3f470b86011712f7f974d669d&selectedUser=
            {"uid":"67c025d3f470b86011712f7f974d669d","levelNo":"100"}*/

        } catch (Exception e) {

        }


        String finalUrl = url;
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        insertApiData(finalUrl,"Get Req contains Req in URL", response,
                                TimeDateUtils.INSTANCE.getTimeFromTimeStamp(System.currentTimeMillis()),Config.GET_TRANSECTION_TYPE);

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.optInt("status") == 0) {

                                tranJsonObject = jsonObject.optJSONObject("result");
                                JSONArray jsonArray = tranJsonObject.getJSONArray("allowedInvestmentTypes");
                                if (jsonArray.toString().contains(mTransactionType)) {

                                    mTvcardview_top_name_color.setText(mObjNewScheme.optString("name"));
                                    setInvestmentType();
                                    setButtonEnability();
                                } else {
                                    mObjNewScheme = null;
                                    showErrorDailog();
                                }

                            } else if (jsonObject.optInt("status") == -1) {

                            }

                        } catch (Exception e) {
                            if (BuildConfig.DEBUG)
                        e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                       /* if (mBar != null)
                            mBar.dismiss();*/
                        if (!isAdded())
                            return;
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void showErrorDailog() {
        CustomDialog customDialog = new CustomDialog(new CustomDialog.DialogBtnCallBack() {
            @Override
            public void onDialogBtnClick(View view) {
                if (view.getId() == R.id.btDone) {
                        //  mActivity.getSupportFragmentManager().popBackStack();
}
else if (view.getId() == R.id.btCalcel) {
}
            }
        });

        customDialog.showDialog(mActivity, getString(R.string.alert_dialog_error_txt),
                getString(R.string.alert_dialog_message_purchase_not_allowed),
                getString(R.string.alert_dialog_btn_txt),
                "",
                true, false);
    }


    private void setInvestmentType() {
        RadioButton radioButton = mRadioGroupSchemeType.findViewById(R.id.radioSchemeType1);
        RadioButton radioButton2 = mRadioGroupSchemeType.findViewById(R.id.radioSchemeType2);
        RadioButton radioButton3 = mRadioGroupSchemeType.findViewById(R.id.radioSchemeType3);
        radioButton.setVisibility(View.GONE);
        radioButton2.setVisibility(View.GONE);
        radioButton3.setVisibility(View.GONE);

        String investmentType = tranJsonObject.optString("investmentType");
        if (investmentType.equalsIgnoreCase("G")) {
            mRadioGroupSchemeType.setVisibility(View.GONE);
            mTvLavelSchemeType.setVisibility(View.GONE);
            mSchemeType = "G";
            // radioButton.setVisibility(View.VISIBLE);
        } else {
            mRadioGroupSchemeType.setVisibility(View.VISIBLE);
            mTvLavelSchemeType.setVisibility(View.VISIBLE);
            radioButton2.setVisibility(View.VISIBLE);
            radioButton3.setVisibility(View.VISIBLE);
        }
    }

    private void showSchemesDailog() {
        final Dialog dialog = new Dialog(mActivity);
        dialog.setContentView(R.layout.change_scheme);
        final Spinner mSchemeSpinner = dialog.findViewById(R.id.scheme);
        Button mSubmitBtn = dialog.findViewById(R.id.submit_btn);

        ArrayList<String> list = new ArrayList<>();
        list.add(0, getString(R.string.select_scheme));
        for (int i = 0; i < mSchemeList.size(); i++) {
            JSONObject jsonObject = mSchemeList.get(i);
            String data = jsonObject.optString("name");
            list.add(data);
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_dropdown, list);
        dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown_items);
        mSchemeSpinner.setAdapter(dataAdapter);


        mSchemeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int selectedPostion, long l) {
                if (selectedPostion > 0)
                    mObjNewScheme = mSchemeList.get(selectedPostion - 1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mObjNewScheme != null) {
                    getAllTransectionTypes();
                }

                dialog.dismiss();
            }
        });


        dialog.findViewById(R.id.close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        dialog.setCancelable(false);
        dialog.show();
        Window window = dialog.getWindow();
        window.setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
    }

    public boolean validateDateFormat(String dateToValdate) {

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        formatter.setLenient(false);
        Date parsedDate = null;
        boolean isValid = false;
        try {
            parsedDate = formatter.parse(dateToValdate);
            Date today = new Date();

            isValid = today.getTime() >= parsedDate.getTime();

        } catch (ParseException e) {
            //Handle exception
            isValid = false;
        }
        return isValid;
    }


    private void setChecqueMode(){
        ArrayList<String> list  = new ArrayList<>();
        list.add(getString(R.string.deposit_at_the_service_center));
        list.add(getString(R.string.deposit_at_the_cms_branch));
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mSpChequeMode.setAdapter(dataAdapter);

        mSpChequeMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position==0){
                    mChequeMode = "MFSS";
                }else if (position==1){
                    mChequeMode = "CMS";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }

}






