package investwell.charts.mikephil.charting.interfaces.dataprovider;

import investwell.charts.mikephil.charting.components.YAxis.AxisDependency;
import investwell.charts.mikephil.charting.data.BarLineScatterCandleBubbleData;
import investwell.charts.mikephil.charting.utils.Transformer;

public interface BarLineScatterCandleBubbleDataProvider extends ChartInterface {

    Transformer getTransformer(AxisDependency axis);
    boolean isInverted(AxisDependency axis);
    
    float getLowestVisibleX();
    float getHighestVisibleX();

    BarLineScatterCandleBubbleData getData();
}
