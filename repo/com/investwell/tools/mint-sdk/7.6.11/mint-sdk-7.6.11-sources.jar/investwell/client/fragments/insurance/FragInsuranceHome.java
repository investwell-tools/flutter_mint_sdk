package investwell.client.fragments.insurance;


import static android.os.Build.VERSION.SDK_INT;

import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.ExtensionsKt.showDatePickerDialog;
import static investwell.utils.KtorHelper.requestCallDownload;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.BaseFragment;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.Utils;

import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragViewPagerAdapter;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.CustomViewPager;
import investwell.utils.InputStreamVolleyRequest;
import investwell.utils.UtilityKotlin;


public class FragInsuranceHome extends BaseFragment implements View.OnClickListener {
    public CustomViewPager mViewPager;
    public FragViewPagerAdapter mPagerAdapter;
    public TabLayout mTabLayout;

    //filter items
    private FloatingActionButton mFilterIcon;
    private RelativeLayout mRelFilterMain;
    private LinearLayout mLinFilterPart, mLinerCustomDuration;
    private Animation slideUpAnimation, slideDownAnimation;
    private boolean isClickedApply = false;
    private int mMonthCount = 0;
    public static String mStartingDate = "", mEndDate = "";
    public static int mSelectedPosition = 0;
    public static List<JSONObject> mMemberList;
    public static boolean mIsActiveFolio = false;
    private TextView mTvStartDate, mTvEndDate;
    private boolean mIsFirstTime = true;
    private Spinner mMemberSpinner;
    private RadioGroup mRadioGeoupFilter;
    private RequestQueue requestQueue;

    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ToolbarFragment fragToolBar;

    @Override
    public void onResume() {
        super.onResume();
  /*      if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.insurance_cover),
                    true, false, false, false, false, false, false);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mStartingDate = "";
        mEndDate = "";
        mSelectedPosition = 0;
        mMemberList = null;
        mIsActiveFolio = false;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_insurance_home, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }
        setUpToolBar();

        mViewPager = view.findViewById(R.id.pager);
        mTabLayout = view.findViewById(R.id.tabLayout);

        mFilterIcon = view.findViewById(R.id.filters);
        mRelFilterMain = view.findViewById(R.id.rl_filters);
        mLinFilterPart = view.findViewById(R.id.rl_filter);
        mLinerCustomDuration = view.findViewById(R.id.linerCustomDuration);
        mTvStartDate = view.findViewById(R.id.tvSTart);
        mTvEndDate = view.findViewById(R.id.tvEnd);
        mMemberSpinner = view.findViewById(R.id.member_spinner);
        slideUpAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up);
        slideDownAnimation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_down);


        mRadioGeoupFilter = view.findViewById(R.id.rgFolio);
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);
        mFilterIcon.setOnClickListener(this);
        mTvStartDate.setOnClickListener(this);
        mTvEndDate.setOnClickListener(this);

        RadioGroup radioGroup = view.findViewById(R.id.rdGroup);
        radioGroup.check(R.id.rbCurrentMonth);
        mRadioGeoupFilter.check(R.id.rdFolio1);
        mRadioGeoupFilter.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int position = radioGroup.indexOfChild(view.findViewById(i));
                switch (position) {
                    case 0:
                        mIsActiveFolio = false;
                        break;

                    case 1:
                        mIsActiveFolio = true;
                        break;

                }
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                mLinerCustomDuration.setVisibility(View.GONE);
                int position = radioGroup.indexOfChild(view.findViewById(i));
                switch (position) {
                    case 0:
                        mMonthCount = 0;
                        dateCalculation(true);
                        break;

                    case 1:
                        mMonthCount = 0;
                        dateCalculation(true);

                        mMonthCount = mMonthCount - 1;
                        dateCalculation(true);
                        break;

                    case 2:
                        String year = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
                        mStartingDate = year + "-01-01";
                        mEndDate = year + "-12-31";
                        break;

                    case 3:
                        mLinerCustomDuration.setVisibility(View.VISIBLE);
                        mMonthCount = 0;
                        dateCalculation(true);
                        break;
                }

            }


        });

        slideDownAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @SuppressLint("RestrictedApi")
            @Override
            public void onAnimationEnd(Animation animation) {
                mRelFilterMain.setVisibility(View.GONE);

                mFilterIcon.setVisibility(View.VISIBLE);
                if (isClickedApply) {

                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        updateViewPagerView();
        Bundle bundle = getArguments();
        if (bundle != null && bundle.containsKey("tabName")) {
            String tabName = bundle.getString("tabName");
            if (tabName.equalsIgnoreCase("generalInsurance")) {
                mViewPager.setCurrentItem(1);
            }
        }
        return view;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivRight) {
                downloadFile2();
}
else if (v.getId() == R.id.tvSTart) {
                datePicker(true);
}
else if (v.getId() == R.id.tvEnd) {
                datePicker(false);
}
else if (v.getId() == R.id.filters) {
                mFilterIcon.setVisibility(View.GONE);
                mRelFilterMain.setVisibility(View.VISIBLE);
                mLinFilterPart.startAnimation(slideUpAnimation);
}
else if (v.getId() == R.id.ivClose) {
                mLinFilterPart.startAnimation(slideDownAnimation);
}
else if (v.getId() == R.id.apply_btn) {
                mLinFilterPart.startAnimation(slideDownAnimation);
                isClickedApply = true;

                int pos = mViewPager.getCurrentItem();
                Fragment activeFragment = mPagerAdapter.getItem(pos);
                if (pos == 0) {
                    ((FragLifeInsurance) activeFragment).getInsurance(1);
                }
}
    }

    public void updateViewPagerView() {
        List<Fragment> fragList = new ArrayList<>();
        Bundle bundle;
        Fragment fragment = new FragLifeInsurance();
        bundle = new Bundle();
        bundle.putString("type", "L");
        fragment.setArguments(bundle);
/*
        Fragment fragment2 = new FragLifeInsurance();
        bundle = new Bundle();
        bundle.putString("type", "M");
        fragment2.setArguments(bundle);*/

        Fragment fragment3 = new FragLifeInsurance();
        bundle = new Bundle();
        bundle.putString("type", "G");
        fragment3.setArguments(bundle);

        fragList.add(fragment);
        /*   fragList.add(fragment2);*/
        fragList.add(fragment3);
        mPagerAdapter = new FragViewPagerAdapter(getChildFragmentManager(), fragList);
        mViewPager.setAdapter(mPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);

        mTabLayout.getTabAt(0).setText(R.string.txt_life_insurance);
/*
        mTabLayout.getTabAt(1).setText(R.string.txt_health_insurance);
*/
        mTabLayout.getTabAt(1).setText(R.string.txt_general_nsurance);

        mViewPager.addOnPageChangeListener(onViewPageChange);

    }


    private void datePicker(final boolean isStartDate) {
//        Calendar c = Calendar.getInstance();
//        int mYear = c.get(Calendar.YEAR);
//        int mMonth = c.get(Calendar.MONTH);
//        int mDay = c.get(Calendar.DAY_OF_MONTH);
//        DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
//            @Override
//            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                if (view.isShown()) {
//                    NumberFormat formatter = new DecimalFormat("00");
//                    String day = formatter.format((dayOfMonth));
//                    String month = formatter.format((monthOfYear + 1));
//                    String date_time = year + "-" + month + "-" + day;
//                    String date_for_text = day + "-" + month + "-" + year;
//
//                    if (isStartDate) {
//                        mTvStartDate.setText(date_for_text);
//                        mStartingDate = date_time;
//                    } else {
//                        mTvEndDate.setText(date_for_text);
//                        mEndDate = date_time;
//                    }
//                }
//
//            }
//        }, mYear, mMonth, mDay);
//        datePickerDialog.show();

        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        String defaultDate = "";
        if(isStartDate)
             defaultDate =  mStartingDate;
        else
             defaultDate =  mEndDate;

        showDatePickerDialog(
                requireContext(),
                this,
                null,
                null,
                defaultDate,
                inputFormat,
                outputFormat,
                formattedDate -> {
                    try {
                        Date parsedDate = outputFormat.parse(formattedDate);
                        String apiDate = inputFormat.format(parsedDate != null ? parsedDate : new Date());

                        if (isStartDate) {
                            mTvStartDate.setText(formattedDate);
                            mStartingDate = apiDate;
                        } else {
                            mTvEndDate.setText(formattedDate);
                            mEndDate = apiDate;
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    return null;
                }
        );

    }

    private void dateCalculation(boolean isPreviousMonthClicked) {
        Calendar mCalender = Calendar.getInstance();

        if (mIsFirstTime) {
            mIsFirstTime = false;
            mCalender.add(Calendar.MONTH, 0);
        } else if (mMonthCount == 0) {
            mCalender.add(Calendar.MONTH, 0);
        } else {
            if (isPreviousMonthClicked)
                mCalender.add(Calendar.MONTH, mMonthCount);
            else
                mCalender.add(Calendar.MONTH, mMonthCount);
        }
        mCalender.set(Calendar.DAY_OF_MONTH, 1);
        Date firstDateOfPreviousMonth = mCalender.getTime();
        mCalender.set(Calendar.DATE, mCalender.getActualMaximum(Calendar.DATE)); // changed calendar to mCalender

        Date lastDateOfPreviousMonth = mCalender.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
        SimpleDateFormat formatterForText = new SimpleDateFormat("dd-MM-yyyy");
        mStartingDate = formatter.format(firstDateOfPreviousMonth);
        mEndDate = formatter.format(lastDateOfPreviousMonth);

        String dateForString = formatterForText.format(lastDateOfPreviousMonth);

        mTvStartDate.setText(dateForString);
        mTvEndDate.setText(dateForString);

    }


    private void downloadFile2() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }

        String uId = "";
        String url = "";
        String levelNo = "";

        try {
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd", new Locale("en", "in"));
            String endDate = formatter.format(new Date());


            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);

            JSONObject dateObject2 = new JSONObject();
            dateObject2.put("activeFoliosOnly", "false");
            jsonArray.put(dateObject2);

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_PORTFOLIO_SUMMARY_PDF + "filters=" + jsonArray.toString()
                    + "&selectedUser=" + Utils.getSelectedUserObject(mSession) + "";

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN, "",
                "insurance", new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        if (mBrokerActivity != null)
                            mBrokerActivity.showCommonDownload(getActivity(), getString(R.string.txt_successfully), getString(R.string.txt_insurance_download_successfully), "pdf", mFileSave, uri);
                        else {
                            mMainActivity.showCommonDownload(mMainActivity, getString(R.string.txt_successfully), getString(R.string.txt_insurance_download_successfully), "pdf", mFileSave, uri);
                        }
                    }
                });
    }


    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();
        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }
    }

    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {
            Log.d("DB", "PERMISSION GRANTED");
        } else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2();
        }
    });


    ViewPager.OnPageChangeListener onViewPageChange = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(final int position) {

            switch (position) {
                case 0:
                    // mTvTitle.setText("Mutual Fund");

                    break;

                case 1:
                    //mTvTitle.setText("Share & Bond");
                    break;

                case 2:
                    //mTvTitle.setText("Fixed Deposit");
                    break;

                case 3:
                    //mTvTitle.setText("Others Asserts");
                    break;


            }
        }


        @Override
        public void onPageScrollStateChanged(int state) {


        }
    };

}
