package investwell.common.debugmode.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ApiDao {

    @Query("Select * from apiData order by apiDateTime desc")
    List<ApiDataModel> getApiDate();

    @Insert
    void insertApiData(ApiDataModel apiDataModel);

    @Update
    void updateApiData(ApiDataModel apiDataModel);

    @Delete
    void deleteApiData(ApiDataModel apiDataModel);

    @Query("DELETE FROM apiData")
    void deleteAll();

}
