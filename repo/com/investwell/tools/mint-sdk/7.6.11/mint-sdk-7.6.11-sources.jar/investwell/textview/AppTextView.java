package investwell.textview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import com.iw.mint.sdk.R;

import java.util.concurrent.ConcurrentHashMap;


public class AppTextView extends AppCompatTextView {

    // Lato font-family XMLs resolve via the GMS downloadable Fonts provider, which is a
    // synchronous binder call to another process. Caching the resolved Typeface avoids
    // repeating that blocking call for every AppTextView instance and prevents ANRs on
    // screens that inflate many of them at once.
    private static final ConcurrentHashMap<Integer, Typeface> sFontCache = new ConcurrentHashMap<>();

    private static final int[] PRELOADABLE_FONT_RES_IDS = {
            R.font.lato, R.font.lato_bold, R.font.lato_black, R.font.lato_italic, R.font.lato_thin
    };

    // Call once from Application.onCreate() so the blocking GMS Fonts provider lookup for
    // each font happens off the critical path, before any screen inflates its first
    // AppTextView. Fonts resolved here are cached and reused by loadFont() below.
    public static void preloadFonts(Context context) {
        Handler handler = new Handler(Looper.getMainLooper());
        for (int fontResId : PRELOADABLE_FONT_RES_IDS) {
            ResourcesCompat.getFont(context.getApplicationContext(), fontResId, new ResourcesCompat.FontCallback() {
                @Override
                public void onFontRetrieved(@NonNull Typeface typeface) {
                    sFontCache.put(fontResId, typeface);
                }

                @Override
                public void onFontRetrievalFailed(int reason) {
                    // Ignore; loadFont() falls back to the view's default typeface on first use.
                }
            }, handler);
        }
    }

    public AppTextView(Context context) {
        super(context);
        init(null, context);
    }

    public AppTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(attrs, context);
    }

    public AppTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs, context);
    }

    private void init(@Nullable AttributeSet attrs, Context context) {
        if (attrs == null) return;

        // Load attributes
        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.CustomTextView);

        // font and style
        int fontStyle = typedArray.getInt(R.styleable.CustomTextView_customFontStyle, 0);
        Typeface typeface;
        switch (fontStyle) {
            case 1: //Semi Bold
                // typeface = Typeface.createFromAsset(getContext().getAssets(), "Gilroy-SemiBold.ttf");
                typeface = loadFont(R.font.lato_bold);
                if (typeface != null) setTypeface(typeface);
                break;
            case 2: // Bold
               // typeface = Typeface.createFromAsset(getContext().getAssets(), "Gilroy-Bold.ttf");
                typeface = loadFont(R.font.lato_black);
                if (typeface != null) setTypeface(typeface);
                break;
            case 3: // Italic
                typeface = loadFont(R.font.lato_italic);
                if (typeface != null) setTypeface(typeface, Typeface.ITALIC);
                break;
            case 4: // Bold Italic
                typeface = loadFont(R.font.lato_italic);
                if (typeface != null) setTypeface(typeface, Typeface.BOLD_ITALIC);
                break;
            case 5: // Light (If you have a specific light font)
               // typeface = Typeface.createFromAsset(getContext().getAssets(), "Gilroy-Medium.ttf");
                typeface = loadFont(R.font.lato);
                if (typeface != null) setTypeface(typeface);
                break;
            case 6: // Thin (If you have a specific thin font)
                //typeface = Typeface.createFromAsset(getContext().getAssets(), "Gilroy-Thin.ttf");
                typeface = loadFont(R.font.lato_thin);
                if (typeface != null) setTypeface(typeface);
                break;
            default: // Normal
                typeface = loadFont(R.font.lato);
                if (typeface != null) setTypeface(typeface);
                break;
        }


        // Set font color
        int textColor = typedArray.getColor(R.styleable.CustomTextView_customFontColorType, getCurrentTextColor());
        if (textColor == 0) {
            setTextColor(ContextCompat.getColor(context, R.color.white_black));
        } else if (textColor == 1) {
            setTextColor(ContextCompat.getColor(context, R.color.black_white));
        } else if (textColor == 2) {
            setTextColor(ContextCompat.getColor(context, R.color.primaryToGreenPrimary));
        } else if (textColor == 3) {
            setTextColor(ContextCompat.getColor(context, R.color.key_text_color));
        } else if (textColor == 4) {
            setTextColor(ContextCompat.getColor(context, R.color.value_text_color));
        } else if (textColor == 5) {
            setTextColor(ContextCompat.getColor(context, R.color.red_text_color));
        } else if (textColor == 6) {
            setTextColor(ContextCompat.getColor(context, R.color.default_text_color));
        } else if (textColor == 7) {
            setTextColor(ContextCompat.getColor(context, R.color.both_white));
        } else if (textColor == 8) {
            setTextColor(ContextCompat.getColor(context, R.color.both_black));
        } else if (textColor == 9) {
            setTextColor(ContextCompat.getColor(context, R.color.green_text_color));
        }
        else if(textColor == 10){
            setTextColor(ContextCompat.getColor(context, R.color.textView_button_color));
        }
        else if(textColor == 11){
            setTextColor(ContextCompat.getColor(context, R.color.lightBlack_lightGrey));
        }
        else if(textColor == 12){
            setTextColor(ContextCompat.getColor(context, R.color.purple_text_color));
        }
        else if(textColor == 13){
            setTextColor(ContextCompat.getColor(context, R.color.blue_text_color));
        }
        else if(textColor == 14){
            setTextColor(ContextCompat.getColor(context, R.color.orange_text_color));
        }
        else if(textColor == 15){
            setTextColor(ContextCompat.getColor(context, R.color.colorToolbarText));
        }
        else if(textColor == 16){
            setTextColor(ContextCompat.getColor(context, R.color.key_text_color_diamond_card));
        }
        else if(textColor == 17){
            setTextColor(ContextCompat.getColor(context, R.color.primaryToPurplePrimary));
        }
        else if(textColor == 18){
            setTextColor(ContextCompat.getColor(context, R.color.primaryToBluePrimary));
        }
        else if(textColor == 19){
            setTextColor(ContextCompat.getColor(context, R.color.crm_in_pending));
        }
        else if(textColor == 20){
            setTextColor(ContextCompat.getColor(context, R.color.crm_in_progress));
        }
        else if(textColor == 21) {
            setTextColor(ContextCompat.getColor(context, R.color.crm_on_hold));
        }
        else{
            if (typedArray.hasValue(R.styleable.CustomTextView_customFontColor)) {
                int color = typedArray.getColor(R.styleable.CustomTextView_customFontColor, getCurrentTextColor());
                setTextColor(color);
            }
        }

        int textSize = typedArray.getInt(R.styleable.CustomTextView_customTextSizeType, (int) getTextSize());
        if (textSize == 0) {
            setTextSize(11);
        } else if (textSize == 1) {
            setTextSize(12);
        } else if (textSize == 2) {
            setTextSize(13);
        } else if (textSize == 3) {
            setTextSize(14);
        } else if (textSize == 4) {
            setTextSize(15);
        } else if (textSize == 5) {
            setTextSize(17);
        } else if (textSize == 6) {
            setTextSize(20);
        } else if (textSize == 7) {
            setTextSize(25);
        }else if (textSize == 8) {
            setTextSize(30);
        }else if (textSize == 9) {
            setTextSize(35);
        }else if (textSize == 10) {
            setTextSize(40);
        }else if (textSize == 11) {
            setTextSize(45);
        }else if (textSize == 12) {
            setTextSize(50);
        }else if (textSize == 13) {
            setTextSize(8);
        }else{
            setTextSize(14);
        }

        typedArray.recycle();
    }

    @Nullable
    private Typeface loadFont(int fontResId) {
        return getCachedFont(getContext(), fontResId);
    }

    // Shared by the other custom AppTextView* variants so they all benefit from the same
    // cache (and the preloadFonts() warm-up above) instead of each hitting the GMS Fonts
    // provider independently.
    @Nullable
    public static Typeface getCachedFont(Context context, int fontResId) {
        Typeface cached = sFontCache.get(fontResId);
        if (cached != null) return cached;

        try {
            Typeface typeface = ResourcesCompat.getFont(context, fontResId);
            if (typeface != null) sFontCache.put(fontResId, typeface);
            return typeface;
        } catch (RuntimeException e) {
            // Some OEMs fail to resolve bundled font resources at inflate time;
            // fall back to the view's default typeface instead of crashing.
            return null;
        }
    }
}

