package investwell.client.fragments.portfolio;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragPortfolioFdADapter;
import investwell.utils.AppSession;
import investwell.utils.Config;


public class FragPortfolioFD extends BaseFragment implements View.OnClickListener {
    RequestQueue requestQueue;
    RecyclerView sub_client;
    TextView mTvName, mTvInvest,mTvCurrent, mTvInterest, mTvGain, mTvREturn, mTvCgar;

    FragPortfolioFdADapter portfolio_client_adapter;

    private ClientActivity mActivity;
    private AppSession mSession;
    private ShimmerFrameLayout mShimmerViewContainer;
    private CardView mCardView;
    private TextView mTvNothing;
    private AppApplication mAppplication;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.stopShimmer();
     /*   Activity activity = getActivity();
        if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmer();
        super.onPause();
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_portfolio_fd, container, false);

        mShimmerViewContainer = view.findViewById(R.id.shimmer_view_container);
        mCardView = view.findViewById(R.id.top_layout);
        mTvNothing = view.findViewById(R.id.tvNothing);


        mTvName = view.findViewById(R.id.tvName);
        mTvInvest = view.findViewById(R.id.tvInvestment);
        mTvCurrent = view.findViewById(R.id.tvCurrent);
        mTvREturn = view.findViewById(R.id.tvReturn);
        mTvInterest = view.findViewById(R.id.tvInterest);
        mTvGain = view.findViewById(R.id.tvGain);
        mTvCgar = view.findViewById(R.id.tvCagr);

        sub_client = view.findViewById(R.id.sub_client);

        sub_client.setHasFixedSize(true);
        sub_client.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        portfolio_client_adapter = new FragPortfolioFdADapter(getActivity(), new ArrayList<JSONObject>());
        sub_client.setAdapter(portfolio_client_adapter);
        if (AppApplication.DASHBOARD_PORTFOLIO_FD.isEmpty()) {
            getPortfolioFD();
        } else {
            SetData();
        }
        return view;
    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.ivLeft) {
                /*Uri uriUrl = Uri.parse("https://api.whatsapp.com/send?phone=" + "+91 9016185832" + "&text=");
                Intent intent = new Intent(Intent.ACTION_VIEW, uriUrl);
                startActivity(intent);*/
}
else if (v.getId() == R.id.ivRight) {
                mActivity.displayViewOther(62, null);
}

    }

    private void SetData() {
        mShimmerViewContainer.stopShimmer();
        mShimmerViewContainer.setVisibility(View.GONE);
        try {
            ArrayList<JSONObject> list = new ArrayList<>();
            JSONObject jsonObject = new JSONObject(AppApplication.DASHBOARD_PORTFOLIO_FD);
            if (jsonObject.optInt("status") == 0) {
                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                if (jsonArray.length()>0){
                    JSONObject jsonObjectSummary = jsonObjectMain.optJSONObject("summary");
                    mCardView.setVisibility(View.VISIBLE);
                    mTvNothing.setVisibility(View.GONE);

                    /*"summary":{
"purchaseValue":75000,
"currentValue":89044.81,
"dividend":10567.12,
"avgHoldingDays":1968.3333333333333,
"gain":24611.929999999993,
"absoluteReturn":32.815906666666656,
"CAGR":5.4034952724026475
}*/
                    String userName = "";
                    if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                        String levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                        if (levelNo.equals("98")){
                            mTvName.setText(getString(R.string.family_head));
                        }else{
                            mTvName.setText(UtilityKotlin.getClientHopObject(mSession).optString("name"));
                        }
                    } else {
                    String levelNo = mSession.getLevelNo();
                    if (levelNo.equals("98")) {
                        mTvName.setText(getString(R.string.family_head));
                    } else {
                        mTvName.setText(mSession.getPersonName());
                    }
                }
                    NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
                    format.setMinimumFractionDigits(0);
                    format.setMaximumFractionDigits(0);

                    double currentValue = jsonObjectSummary.optDouble("purchaseValue");
                    String strCurrentAmount = format.format(currentValue);
                    mTvInvest.setText(strCurrentAmount);

                    double purchaseValue = jsonObjectSummary.optDouble("currentValue");
                    String strPurchaseValue = format.format(purchaseValue);
                    mTvCurrent.setText(strPurchaseValue);

                    double devidenValue = jsonObjectSummary.optDouble("dividend");
                    String strDEdidentValue = format.format(devidenValue);
                    mTvInterest.setText(strDEdidentValue);

                    double gaine = jsonObjectSummary.optDouble("gain");
                    String strGain = format.format(gaine);
                    mTvGain.setText(strGain);

                    double cgrValue = jsonObjectSummary.optDouble("CAGR");
                    String data2 = String.format("%.2f", cgrValue) + "%";
                    mTvCgar.setText(data2);

                    double returnValue = jsonObjectSummary.optDouble("absoluteReturn");
                    String stReturnValue = String.format("%.2f", returnValue) + "%";
                    mTvREturn.setText(stReturnValue);


                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                        list.add(jsonObject1);
                    }
                    portfolio_client_adapter.updateList(list);
                }else{
                    mTvNothing.setVisibility(View.VISIBLE);
                }


            }
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getPortfolioFD() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }

        String url = "";
        try {
            JSONObject jsonObject1 = new JSONObject();
            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd",new Locale("en","in"));
            String endDate = formatter.format(new Date());

            JSONArray jsonArray = new JSONArray();
            JSONObject dateObject = new JSONObject();
            dateObject.put("endDate", endDate);
            jsonArray.put(dateObject);

            JSONObject componentObject = new JSONObject();
            componentObject.put("componentName", "folioFixedDepositTable");


            // https://demo.investwell.app/webapi/client/reports/getPortfolioReturnsForFixedAssets?filters=
            // [{"endDate":"2019-08-26"}]&groupBy=fixedSubAssetid&componentForLoader=
            // {"componentName":"folioFixedDepositTable"}&pageSize=20¤tPage=1&investorUid
            // =5553ce3575b8e1a64181794eb86c5b27&selectedUser={"uid":"5553ce3575b8e1a64181794eb86c5b27",
            // "levelNo":"98"}

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() +Config.GET_PORTFOLIO_FD + "filters="+jsonArray.toString()+"&groupBy=fixedSubAssetid"
                    +"&pageSize=100&currentPage=1"+
                    "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser="+Utils.getSelectedUserObject(mSession)+ "";
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);

        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        
                        AppApplication.DASHBOARD_PORTFOLIO_FD = response;
                        SetData();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (!isAdded())
                            return;
                        mShimmerViewContainer.stopShimmer();
                        mShimmerViewContainer.setVisibility(View.GONE);
                     
                        UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

                    }
                }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }
            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


}
