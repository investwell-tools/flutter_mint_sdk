package investwell.client.adapter;

import android.content.Context;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.iw.mint.sdk.R;
import investwell.client.activity.ClientActivity;
import investwell.utils.AppSession;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Portfolio_Share_Adapter extends RecyclerView.Adapter<Portfolio_Share_Adapter.MyViewHolder> {


    private ArrayList<JSONObject> jsonObjects;
    Context context;
    private AppSession mSession;
    private ClientActivity mActivity;


    public Portfolio_Share_Adapter(Context context, ArrayList<JSONObject> jsonObjects) {

        this.context = context;
        this.jsonObjects = jsonObjects;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {


        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_design, parent, false);
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        mActivity = (ClientActivity) context;

        NumberFormat format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));
        format.setMinimumFractionDigits(0);
        format.setMaximumFractionDigits(0);


        final JSONObject jsonObject = jsonObjects.get(position);
        mSession = AppSession.getInstance(context);


        if (jsonObject.optString("gain").contains("-")) {
            holder.gain_arrow.setBackgroundResource(R.drawable.menu_down);
        } else {
            holder.gain_arrow.setBackgroundResource(R.drawable.menu_up);

        }
        if (jsonObject.optString("CAGR").contains("-")) {
            holder.cagr_arrow.setBackgroundResource(R.drawable.menu_down);
        } else {
            holder.cagr_arrow.setBackgroundResource(R.drawable.menu_up);
        }

        holder.applicant_name.setText(jsonObject.optString("applicantName"));

        double purchaseValue = jsonObject.optDouble("purchaseValue");
        String strPurchaseValue = format.format(purchaseValue);
        holder.purchase_cost.setText(strPurchaseValue);

        double currentValue = jsonObject.optDouble("currentValue");
        String strCurrentValue = format.format(currentValue);
        holder.market_value.setText(strCurrentValue);

        double Gain = jsonObject.optDouble("gain");
        String strCurrentAmount = format.format(Gain);
        holder.gain.setText(strCurrentAmount);

        double cgrValue = jsonObject.optDouble("CAGR");
        String data2 = String.format("%.2f", cgrValue) + "%";
        holder.cagr.setText(data2);

        holder.top_linear_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("applicant_name", jsonObject.optString("applicantName"));
                bundle.putString("appid", jsonObject.optString("appid"));
                mActivity.displayViewOther(18, bundle);



            }
        });


    }

    @Override
    public int getItemCount() {

        return jsonObjects.size();
    }

    public void updateList(List<JSONObject> list) {

        jsonObjects.clear();
        jsonObjects.addAll(list);
        notifyDataSetChanged();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView applicant_name, purchase_cost, market_value, gain, cagr, folio;
        ImageView next_arrow;
        ImageView gain_arrow, cagr_arrow;
        LinearLayout top_linear_layout;


        public MyViewHolder(View view) {
            super(view);

            applicant_name = view.findViewById(R.id.applicant_name);
            purchase_cost = view.findViewById(R.id.purchase_cost);
            market_value = view.findViewById(R.id.market_value);
            gain = view.findViewById(R.id.gain);
            cagr = view.findViewById(R.id.cagr);
            folio = view.findViewById(R.id.folio);
            next_arrow = view.findViewById(R.id.next_arrow);
            gain_arrow = view.findViewById(R.id.gain_arrow);
            cagr_arrow = view.findViewById(R.id.cagr_arrow);
            top_linear_layout = view.findViewById(R.id.top_linear_layout);

        }
    }
}
