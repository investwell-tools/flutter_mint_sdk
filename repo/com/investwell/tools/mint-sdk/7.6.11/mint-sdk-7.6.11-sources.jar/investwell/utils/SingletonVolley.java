package investwell.utils;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by hack on 27/10/17.
 */

public class SingletonVolley {

    private static SingletonVolley mInstance;
    private static Context ctx;
    RequestQueue requestQueue;

    SingletonVolley(Context mctx) {
        ctx=mctx;
        requestQueue=getRequestQueue();
    }

    private RequestQueue getRequestQueue(){
        if(requestQueue==null)
            requestQueue= Volley.newRequestQueue(ctx);
        return requestQueue;
    }

    public static synchronized SingletonVolley getmInstance(Context context)
    {
        if(mInstance==null)
            mInstance=new SingletonVolley(context);
        return mInstance;
    }

    public<T> void addToRequestQue(Request<T> request)
    {
        getRequestQueue().add(request);
    }
}