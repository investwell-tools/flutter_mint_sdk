package investwell.client.fragments.others;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import investwell.utils.BaseFragment;
import investwell.utils.SearchAnimationToolbar;
import investwell.utils.Utils;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.adapter.FragViewPagerAdapter;
import investwell.client.fragments.insurance.FragLifeInsurance;
import investwell.utils.AppSession;
import investwell.utils.Config;
import investwell.utils.CustomViewPager;
import investwell.utils.InputStreamVolleyRequest;


public class FragBrokerOrderHome extends BaseFragment implements View.OnClickListener {
    public CustomViewPager mViewPager;
    public FragViewPagerAdapter mPagerAdapter;
    public TabLayout mTabLayout;


    private AppSession mSession;
    private BrokerActivity mBrokerActivity;
    private ClientActivity mMainActivity;
    private AppApplication mApplication;
    private ImageView ivBack;
    private SearchAnimationToolbar mTvTitle;

    @Override
    public void onResume() {
        super.onResume();
 /*       if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mMainActivity).setCurrentScreen(mMainActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mSession = AppSession.getInstance(mBrokerActivity);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mMainActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mMainActivity);
            mApplication = (AppApplication) mMainActivity.getApplication();
            mSession = AppSession.getInstance(mMainActivity);
        }
    }

    private void setUpToolBar() {
        mTvTitle.setTitle(getResources().getString(R.string.txt_Myorder));
        ivBack.setOnClickListener(view -> {
            if (mBrokerActivity!=null){
                mBrokerActivity.onBackPressed();
            }else {
                mMainActivity.onBackPressed();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.frag_broker_order_home, container, false);
        if (mBrokerActivity != null) {
            mBrokerActivity.setMainVisibility(this, null);
        } else {
            mMainActivity.setMainVisibility(this, null);
        }

        mViewPager = view.findViewById(R.id.pager);
        mTabLayout = view.findViewById(R.id.tabLayout);
        mTvTitle = view.findViewById(R.id.toolbar);
        ivBack = view.findViewById(R.id.ivBack);

        setUpToolBar();
        view.findViewById(R.id.ivClose).setOnClickListener(this);
        view.findViewById(R.id.apply_btn).setOnClickListener(this);

        RadioGroup radioGroup = view.findViewById(R.id.rdGroup);
        radioGroup.check(R.id.rbCurrentMonth);


        updateViewPagerView();
        // getAllMembers();
        return view;
    }


    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {




        }
    }

    public void updateViewPagerView() {
        List<Fragment> fragList = new ArrayList<>();
        Bundle bundle;
        Fragment fragment = new FragMyOrders();
        bundle = new Bundle();
        bundle.putString("comefrom","myorder");
        bundle.putString("type", "system_orders");
        fragment.setArguments(bundle);


        Fragment fragment3 = new FragMyOrders();
        bundle = new Bundle();
        bundle.putString("comefrom","myorder");
        bundle.putString("type", "all_orders");
        fragment3.setArguments(bundle);

        fragList.add(fragment);
     /*   fragList.add(fragment2);*/
        fragList.add(fragment3);
        mPagerAdapter = new FragViewPagerAdapter(getChildFragmentManager(), fragList);
        mViewPager.setAdapter(mPagerAdapter);
        mTabLayout.setupWithViewPager(mViewPager);

        mTabLayout.getTabAt(0).setText(R.string.system_orders);
/*
        mTabLayout.getTabAt(1).setText(R.string.txt_health_insurance);
*/
        mTabLayout.getTabAt(1).setText(R.string.all_orders);

        mViewPager.addOnPageChangeListener(onViewPageChange);

    }


    ViewPager.OnPageChangeListener onViewPageChange = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(final int position) {

            switch (position) {
                case 0:
                    // mTvTitle.setText("Mutual Fund");

                    break;

                case 1:
                    //mTvTitle.setText("Share & Bond");
                    break;

                case 2:
                    //mTvTitle.setText("Fixed Deposit");
                    break;

                case 3:
                    //mTvTitle.setText("Others Asserts");
                    break;


            }
        }


        @Override
        public void onPageScrollStateChanged(int state) {


        }
    };

}
