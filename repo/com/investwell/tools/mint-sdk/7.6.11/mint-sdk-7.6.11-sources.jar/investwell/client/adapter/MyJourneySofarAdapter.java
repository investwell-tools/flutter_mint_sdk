package investwell.client.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import investwell.utils.Utils;

/**
 * Created by binesh on 8/5/18.
 */

public class MyJourneySofarAdapter extends RecyclerView.Adapter<MyJourneySofarAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
    private Context mContext;
    private MyJourneySofarAdapter.OnItemClickListener listener;

    public MyJourneySofarAdapter(Context context, ArrayList<JSONObject> list, MyJourneySofarAdapter.OnItemClickListener listener) {
        mContext = context;
        mDataList = list;
        this.listener = listener;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rv_myjourney_sofar_adapter, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position, listener);


    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvValue, tvAlphabetSymbol;

        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvName);
            tvValue = view.findViewById(R.id.tvValue);
            tvAlphabetSymbol = view.findViewById(R.id.tvAlphabetSymbol);
        }

        public void setItem(final int position, final OnItemClickListener listener) {
            try {
                final JSONObject jsonObject = mDataList.get(position);
                tvAlphabetSymbol.setText(jsonObject.optString("symbol"));
                tvName.setText(jsonObject.optString("levelName"));

                String levelName = jsonObject.optString("levelName");
                tvName.setText(levelName);
                tvName.setText(levelName+jsonObject.optString("formula"));
                tvValue.setText(jsonObject.optString("value"));
            } catch (Exception e) {
                if (BuildConfig.DEBUG)
                        e.printStackTrace();
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // listener.onItemClick(position);
                }
            });
        }

    }



    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

}
