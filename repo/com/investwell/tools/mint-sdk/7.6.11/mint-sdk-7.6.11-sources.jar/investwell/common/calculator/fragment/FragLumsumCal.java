package investwell.common.calculator.fragment;

import static investwell.utils.UtilityKotlin.setTintColorIfDark;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import investwell.activity.AppApplication;
import investwell.broker.activity.BrokerActivity;
import investwell.client.activity.ClientActivity;
import investwell.client.fragments.others.ToolbarFragment;
import investwell.common.calculator.utils.AudioPlayer;
import investwell.common.calculator.utils.RoundKnobButton;
import investwell.common.calculator.utils.Singleton;
import investwell.common.calculator.utils.Utils;
import investwell.textview.AppTextViewTitle;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.UtilityKotlin;


public class FragLumsumCal extends BaseFragment implements View.OnClickListener, View.OnTouchListener,
        RoundKnobButton.RoundKnobButtonListener, ToolbarFragment.ToolbarCallback {

    private final long DELAY = 1000; // milliseconds
    double w_delay = 0;
    double w_tot = 0;
    double amt_inv = 0;
    double nYears = 0, amtD = 0, rorD = 0, inflate = 0;
    Singleton m_Inst = Singleton.getInstance();
    private EditText mEtYear, mEtAmount, mEtRate, mEtExpectedInflation;
    private TextView mTvSipTitle, mTvImageTitle, mTvMainAmount, mTvResultAmount, invest_btn;
    /*   private LinearLayout mLinerResult;*/
    private ImageView mIvImageRight, mIvRefresh, mIvBack;
    private int mAmountCount = 0, mAnnualAmountCount = 0, mYearCount = 0, mReturn = 0, mCount6 = 0;
    private ProgressBar mProgressBar;
    private AudioPlayer audioPlayer;
    private ScrollView mScrollView;
    private RoundKnobButton mDailerInvest1, mDailerInvest2, mDailerInvest3, mDailerInvest4;
    private CheckBox mInflationbox;
    private Timer timer = new Timer();
    private ClientActivity mActivity;
    private AppApplication mApplication;
    private RelativeLayout mRelToolbar;
    private Bundle bundle;
    private ConstraintLayout mClCalcFooter;
    private ToolbarFragment fragToolBar;
    private AppTextViewTitle tvHeaderTitle;
    private LinearLayout ll_calculator_header;
    private BrokerActivity mBrokerActivity;
    private AppSession mSession;
    private TextView mTvAppName, mTvWebsite, mTvEmail, mTvAddress, mTvPhone, mTvSlogan;
    private ImageView mIvAppLogo;
    private TextView mTvAmountError, mTvInvestmentPeriodError, mTvAnnualReturnError, mTvInflationError;
    @Override
    public void onResume() {
        super.onResume();
      /*  if (mBrokerActivity != null)
            FirebaseAnalytics.getInstance(mBrokerActivity).setCurrentScreen(mBrokerActivity, this.getClass().getSimpleName(), null);
        else
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);
*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BrokerActivity) {
            this.mBrokerActivity = (BrokerActivity) context;
            mBrokerActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mBrokerActivity.getApplication();
            mSession = AppSession.getInstance(mBrokerActivity);

        } else if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mActivity.setMainVisibility(this, null);
            mApplication = (AppApplication) mActivity.getApplication();
            mSession = AppSession.getInstance(mActivity);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_cal_sparemoney, container, false);
        if (mBrokerActivity != null) {
            m_Inst.InitGUIFrame(mBrokerActivity);

        } else {
            m_Inst.InitGUIFrame(mActivity);

        }


        audioPlayer = new AudioPlayer();


        bundle = getArguments();
        tvHeaderTitle = view.findViewById(R.id.tv_header_title);
        ll_calculator_header = view.findViewById(R.id.ll_calculator_header);
        mTvSlogan = view.findViewById(R.id.tvSlogan);
        setUpToolBar();
        mRelToolbar = view.findViewById(R.id.relToolBar);
        mTvMainAmount = view.findViewById(R.id.result1);
        mTvResultAmount = view.findViewById(R.id.result2);
        mEtAmount = view.findViewById(R.id.edit1);
        mEtYear = view.findViewById(R.id.edit2);
        mEtRate = view.findViewById(R.id.edit3);
        mEtExpectedInflation = view.findViewById(R.id.edit4);
        mIvAppLogo=view.findViewById(R.id.iv_app_logo);
        mScrollView = view.findViewById(R.id.scrollView);
        mInflationbox = view.findViewById(R.id.ch_inflation);
        mClCalcFooter = view.findViewById(R.id.cl_calc_footer);

        mTvAmountError = view.findViewById(R.id.tvAmountError);
        mTvInvestmentPeriodError = view.findViewById(R.id.tvInvestmentPeriodError);
        mTvAnnualReturnError = view.findViewById(R.id.tvAnnualReturnError);
        mTvInflationError = view.findViewById(R.id.tvInflationError);


        mTvSipTitle = view.findViewById(R.id.result_text);
        /* mLinerResult = view.findViewById(R.id.linerResult);*/

        mIvBack = view.findViewById(R.id.ivLeft);
        mProgressBar = view.findViewById(R.id.progress_bar);
        mTvImageTitle = view.findViewById(R.id.tvImageTitle);
        invest_btn = view.findViewById(R.id.invest_btn);
        mClCalcFooter.setVisibility(View.GONE);

        mDailerInvest1 = view.findViewById(R.id.dialer1);
        mDailerInvest2 = view.findViewById(R.id.dialer2);
        mDailerInvest3 = view.findViewById(R.id.dialer3);
        mDailerInvest4 = view.findViewById(R.id.dialer4);

        mTvAddress = view.findViewById(R.id.tvAddress);
        mTvAppName = view.findViewById(R.id.tvApp_name);
        mTvPhone = view.findViewById(R.id.call);
        mTvWebsite = view.findViewById(R.id.web);
        mTvEmail = view.findViewById(R.id.email);
        setupFooter();

        mDailerInvest1.setOnTouchListener(this);
        mDailerInvest2.setOnTouchListener(this);
        mDailerInvest3.setOnTouchListener(this);
        mDailerInvest4.setOnTouchListener(this);
        if (mBrokerActivity != null) {
            mDailerInvest1.RoundKnobButton3(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton3(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton3(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton3(mBrokerActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        } else {
            mDailerInvest1.RoundKnobButton3(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest2.RoundKnobButton3(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest3.RoundKnobButton3(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
            mDailerInvest4.RoundKnobButton3(mActivity, 0, m_Inst.Scale(110), m_Inst.Scale(110));
        }
        /*if (bundle != null && bundle.containsKey(AppConstants.COME_FROM)) {
            invest_btn.setVisibility(View.VISIBLE);
            toolbar_title_left.setText("Spare Money Calculator");

        } else {
            invest_btn.setVisibility(View.GONE);
            toolbar_title_left.setText("Lumpsum Calculator");
        }*/


        mDailerInvest1.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
            }

            public void onRotate(final int percentage) {
                System.out.println("" + percentage);
                mEtAmount.post(new Runnable() {
                    public void run() {
                        long currentValue = Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""));
                        long updateValue = 0;
                        if (mAmountCount != percentage) {
                            if (percentage > mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue + 500);
                                } else {
                                    updateValue = (currentValue + 1000);
                                }
                            } else if (percentage < mAmountCount) {
                                if (currentValue < 10000) {
                                    updateValue = (currentValue - 500);
                                } else {
                                    updateValue = (currentValue - 1000);
                                }
                            }

                            mAmountCount = percentage;
                            if (updateValue < 500) {
                                mEtAmount.setText("" + 500);
                            } else {
                                mEtAmount.setText("" + updateValue);
                            }
                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mActivity);
                            calculateAmount();
                        }


                    }
                });
            }
        });

        mDailerInvest2.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtYear.post(new Runnable() {
                    public void run() {
                        int currentValue = Integer.parseInt(mEtYear.getText().toString());
                        int updateValue = 0;
                        if (mYearCount != percentage) {
                            if (percentage > mYearCount) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mYearCount) {
                                updateValue = (currentValue - 1);
                            }

                            mYearCount = percentage;
                            if (updateValue < 1)
                                mEtYear.setText("" + 1);
                            else if (updateValue > 99)
                                mEtYear.setText("" + 99);
                            else
                                mEtYear.setText("" + updateValue);
                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mActivity);
                            calculateAmount();
                        }

                    }
                });
            }
        });


        mDailerInvest3.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtRate.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtRate.getText().toString());
                        double updateValue = 0;
                        if (mReturn != percentage) {
                            if (percentage > mReturn) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mReturn) {
                                updateValue = (currentValue - 1);
                            }

                            mReturn = percentage;
                            if (updateValue < 1)
                                mEtRate.setText("" + 1.00);
                            else if (updateValue > 100.00)
                                mEtRate.setText("" + 100.00);
                            else
                                mEtRate.setText("" + updateValue);

                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mActivity);
                            calculateAmount();
                        }
                    }
                });
            }
        });

        mDailerInvest4.SetListener(new RoundKnobButton.RoundKnobButtonListener() {
            public void onStateChange(boolean newstate) {
                //Toast.makeText(SipActivity.this, "New state:" + newstate, Toast.LENGTH_SHORT).show();
            }

            public void onRotate(final int percentage) {
                mEtExpectedInflation.post(new Runnable() {
                    public void run() {
                        double currentValue = Double.parseDouble(mEtExpectedInflation.getText().toString());
                        double updateValue = 0;
                        if (mCount6 != percentage) {
                            if (percentage > mCount6) {
                                updateValue = (currentValue + 1);
                            } else if (percentage < mCount6) {
                                updateValue = (currentValue - 1);
                            }

                            mCount6 = percentage;
                            if (updateValue < 1) {
                                mEtExpectedInflation.setText("" + 1.00);
                            } else if (updateValue > 100) {
                                mEtExpectedInflation.setText("" + 100.00);
                            } else {
                                mEtExpectedInflation.setText("" + updateValue);
                            }
                            if (mBrokerActivity != null)
                                audioPlayer.play(mBrokerActivity);
                            else
                                audioPlayer.play(mActivity);
                            calculateAmount();
                        }


                    }
                });

            }
        });


        view.findViewById(R.id.invest_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int duration = Integer.parseInt(mEtYear.getText().toString());

                Bundle bundle = new Bundle();
                bundle.putString("type", "coming_from_goal");
                bundle.putString("investment_type", "Lumpsum");
                bundle.putString("ic_invest_route_goal", "Spare Money");
                bundle.putString("Amount", mTvMainAmount.getText().toString());
                bundle.putInt("duration", duration);
                if (mBrokerActivity != null)
                    mBrokerActivity.displayViewOther(64, bundle);
                else
                    mActivity.displayViewOther(64, bundle);

            }
        });
        mInflationbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                calculateAmount();
            }
        });
        //refreshView();
        mEtAmount.addTextChangedListener(new GenericTextWatcher(mEtAmount));
        mEtRate.addTextChangedListener(new GenericTextWatcher(mEtRate));
        mEtYear.addTextChangedListener(new GenericTextWatcher(mEtYear));
        mEtExpectedInflation.addTextChangedListener(new GenericTextWatcher(mEtExpectedInflation));
        mEtAmount.setText("10000");
        mEtYear.setText("10");
        mEtRate.setText("10.00");
        mEtExpectedInflation.setText("6.00");
        calculateAmount();
        return view;
    }

    private void setupFooter() {
        setTintColorIfDark(requireActivity(), mIvAppLogo);
        mIvAppLogo.setContentDescription(mSession.getCompanyName() + ". logo");
        if (getResources().getString(R.string.subdomain).equals("mint")) {
            if (mSession.getHasLoging()) {
                if(!TextUtils.isEmpty(  mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")){
                    Picasso.get().load( mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                    mIvAppLogo.setVisibility(View.VISIBLE);
                }else{
                    mIvAppLogo.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")){
                    mTvAddress.setText(mSession.getAddress());
                    mTvAddress.setVisibility(View.VISIBLE);
                }else{
                    mTvAddress.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")){
                    mTvWebsite.setText(mSession.getWebsite());
                    mTvWebsite.setVisibility(View.VISIBLE);
                }else{
                    mTvWebsite.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")){
                    mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                    mTvPhone.setVisibility(View.VISIBLE);
                }else{
                    mTvPhone.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")){
                    mTvEmail.setText(mSession.getUserEmail());
                    mTvEmail.setVisibility(View.VISIBLE);
                }else{
                    mTvEmail.setVisibility(View.GONE);
                } if(!TextUtils.isEmpty(  mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")){
                    mTvAppName.setText(mSession.getCompanyName());
                    mTvAppName.setVisibility(View.VISIBLE);
                }else{
                    mTvAppName.setVisibility(View.GONE);
                }
                if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                    mTvSlogan.setText(mSession.getSloganOnLogo());
                    mTvSlogan.setVisibility(View.VISIBLE);
                }else{
                    mTvSlogan.setVisibility(View.GONE);
                }
            } else {
                if(!TextUtils.isEmpty(  mSession.getAppLogo()) && !mSession.getAppLogo().equalsIgnoreCase("null")){
                    Picasso.get().load( mSession.getAppLogo())
                            .error(R.drawable.app_logo_secondry_mint).into(mIvAppLogo);
                }
                mTvAddress.setText(getResources().getString(R.string.locatetext));
                mTvWebsite.setText(getResources().getString(R.string.website));
                mTvPhone.setText(getResources().getString(R.string.image_phone));
                mTvEmail.setText(getResources().getString(R.string.support_email_address));
                mTvAppName.setText(getString(R.string.app_name));
                mTvSlogan.setText(mSession.getSloganOnLogo());
            }
        } else {

            mIvAppLogo.setVisibility(View.VISIBLE);
            int squareLogo =   UtilityKotlin.checkExistResources("app_logo_square","mipmap",requireContext());
            int circleLogo =   UtilityKotlin.checkExistResources("app_logo_round","mipmap",requireContext());
            if (squareLogo !=0) {
                mIvAppLogo.setImageResource(squareLogo);
            }else if (circleLogo !=0) {
                mIvAppLogo.setImageResource(circleLogo);
            }else{
                mIvAppLogo.setImageResource(R.mipmap.app_logo);
            }
            if(!TextUtils.isEmpty(  mSession.getAddress()) && !mSession.getAddress().equalsIgnoreCase("null")){
                mTvAddress.setText(mSession.getAddress());
                mTvAddress.setVisibility(View.VISIBLE);
            }else{
                mTvAddress.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getWebsite()) && !mSession.getWebsite().equalsIgnoreCase("null")){
                mTvWebsite.setText(mSession.getWebsite());
                mTvWebsite.setVisibility(View.VISIBLE);
            }else{
                mTvWebsite.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getMobileNumber()) && !mSession.getMobileNumber().equalsIgnoreCase("null")){
                mTvPhone.setText(getString(R.string.txt_ph).concat(mSession.getMobileNumber()));
                mTvPhone.setVisibility(View.VISIBLE);
            }else{
                mTvPhone.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getUserEmail()) && !mSession.getUserEmail().equalsIgnoreCase("null")){
                mTvEmail.setText(mSession.getUserEmail());
                mTvEmail.setVisibility(View.VISIBLE);
            }else{
                mTvEmail.setVisibility(View.GONE);
            } if(!TextUtils.isEmpty(  mSession.getCompanyName()) && !mSession.getCompanyName().equalsIgnoreCase("null")){
                mTvAppName.setText(mSession.getCompanyName());
                mTvAppName.setVisibility(View.VISIBLE);
            }else{
                mTvAppName.setVisibility(View.GONE);
            }
            if(!TextUtils.isEmpty(  mSession.getSloganOnLogo()) && !mSession.getSloganOnLogo().equalsIgnoreCase("null")){
                mTvSlogan.setText(mSession.getSloganOnLogo());
                mTvSlogan.setVisibility(View.VISIBLE);
            }else{
                mTvSlogan.setVisibility(View.GONE);
            }

        }
    }
private void clearErrorMessage() {
        mEtAmount.setError(null);
        mEtExpectedInflation.setError(null);
        mEtRate.setError(null);
        mEtYear.setError(null);
    }

    private void setUpToolBar() {
        fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.toolBar_title_lumpsum_cal), true, true, false, false, true, false, false);
            fragToolBar.setCallback(this);
        }
        tvHeaderTitle.setText(getResources().getString(R.string.toolBar_title_lumpsum_cal));
    }

    @Override
    public void onStateChange(boolean newstate) {

    }

    @Override
    public void onRotate(int percentage) {

    }

    @Override
    public void onClick(View view) {
        /*if (view.getId() == R.id.ivRight) {
            saveFrameLayout();
        } *//*else if (view.getId() == R.id.ivRight2) {
            refreshView();
        }*//* else if (view.getId() == R.id.ivLeft) {
            mActivity.getSupportFragmentManager().popBackStack();
        }*/

    }

    private void refreshView() {
        mDailerInvest1.setRotorPercentage(50);
        mDailerInvest2.setRotorPercentage(50);
        mDailerInvest3.setRotorPercentage(50);
        mDailerInvest4.setRotorPercentage(50);
        mEtAmount.setText("10000");
        mEtYear.setText("10");
        mEtRate.setText("10.00");
        mEtExpectedInflation.setText("6.00");
        calculateAmount();
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        hideKeyPad();
        String currentValue = "";
        int i = view.getId();
        if (i == R.id.dialer1) {
            currentValue = mEtAmount.getText().toString().replaceAll(",", "");
            if (currentValue.length() > 0) {
                long value = Long.parseLong(currentValue);
                if (value < 500)
                    mEtAmount.setText("" + 500);
            } else {
                mEtAmount.setText("" + 500);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer2) {
            currentValue = mEtYear.getText().toString();
            if (currentValue.length() > 0) {
                int value = Integer.parseInt(currentValue);
                if (value < 1)
                    mEtYear.setText("" + 1);
                else if (value > 99)
                    mEtYear.setText("" + 99);

            } else {
                mEtYear.setText("" + 1);
            }

            desableScrollView(motionEvent);

        } else if (i == R.id.dialer3) {
            currentValue = mEtRate.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 2)
                    mEtRate.setText("" + 1.00);
                else if (value > 100)
                    mEtRate.setText("" + 100.00);
            } else {
                mEtRate.setText("" + 1.00);
            }
            desableScrollView(motionEvent);

        } else if (i == R.id.dialer4) {
            currentValue = mEtExpectedInflation.getText().toString();
            if (currentValue.length() > 0) {
                double value = Double.parseDouble(currentValue);
                if (value < 1)
                    mEtExpectedInflation.setText("" + 0.00);
                else if (value > 100)
                    mEtExpectedInflation.setText("" + 100.00);

            } else {
                mEtExpectedInflation.setText("" + 6.00);
            }
            desableScrollView(motionEvent);
        }
        return false;
    }

    private void desableScrollView(MotionEvent motionEvent) {
        if (motionEvent.getAction() == MotionEvent.ACTION_DOWN)
            mScrollView.requestDisallowInterceptTouchEvent(true);

        else if (motionEvent.getAction() == MotionEvent.ACTION_UP)
            mScrollView.requestDisallowInterceptTouchEvent(false);

    }

    public void hideKeyPad() {
        if (mBrokerActivity != null) {
            InputMethodManager inputManager = (InputMethodManager) mBrokerActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mBrokerActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        } else {
            InputMethodManager inputManager = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
            View focusedView = mActivity.getCurrentFocus();

            if (focusedView != null) {
                inputManager.hideSoftInputFromWindow(focusedView.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
            }
        }
    }

    private void delayCall() {
        timer.cancel();
        timer = new Timer();
        timer.schedule(
                new TimerTask() {
                    @Override
                    public void run() {
                        if (mBrokerActivity != null)
                            mBrokerActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });

                        else
                            mActivity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    calculateAmount();
                                }
                            });
                    }
                },
                DELAY
        );
    }


    private void calculateAmount() {
            if (!isAdded())
                return;
        mTvAmountError.setVisibility(View.GONE);
        mTvInvestmentPeriodError.setVisibility(View.GONE);
        mTvAnnualReturnError.setVisibility(View.GONE);
        mTvInflationError.setVisibility(View.GONE);

        if (mBrokerActivity != null) {
            if (mEtAmount.getText().toString().replaceAll(",", "").replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
//                mBrokerActivity.showCommonDialog(mBrokerActivity, "Not Valid", getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.announceForAccessibility(getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
                mTvAmountError.setText(getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
            } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 500) {
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.announceForAccessibility(getResources().getString(R.string.lumpsum_cal_error_less_amnt));
                mTvAmountError.setText(getResources().getString(R.string.lumpsum_cal_error_less_amnt));
            } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.lumpsum_cal_error_more_amnt));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.lumpsum_cal_error_more_amnt));
            } else if (Integer.parseInt(mEtYear.getText().toString()) > 99) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.announceForAccessibility(getResources().getString(R.string.lumspum_cal_error_duration));
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.lumspum_cal_error_duration));
            } else if (mEtRate.getText().toString().equals("") ||mEtRate.getText().toString().equals(".") || mEtRate.getText().toString().equals("0")) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.lumpsum_cal_error_ror));
                mTvAnnualReturnError.setText(getResources().getString(R.string.lumpsum_cal_error_ror));
            } else if (Double.parseDouble(mEtRate.getText().toString()) > 100.00) {
                mEtRate.setText("100.00");
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.announceForAccessibility(getResources().getString(R.string.lumpsum_cal_error_max_amnt));
                mTvAnnualReturnError.setText(getResources().getString(R.string.lumpsum_cal_error_max_amnt));
            } else if (mEtExpectedInflation.getText().toString().equals("") ||mEtExpectedInflation.getText().toString().equals(".") || mEtExpectedInflation.getText().toString().equals("0")) {
                mTvInflationError.setVisibility(View.VISIBLE);
                mTvInflationError.announceForAccessibility(getResources().getString(R.string.lumpsum_cal_error_roi));
                mTvInflationError.setText(getResources().getString(R.string.lumpsum_cal_error_roi));
            } else if (Double.parseDouble(mEtExpectedInflation.getText().toString()) > 100) {
                mEtExpectedInflation.setText("100.00");
                mTvInflationError.setVisibility(View.VISIBLE);
                mTvInflationError.announceForAccessibility(getResources().getString(R.string.lumpsum_cal_error_max_roi));
                mTvInflationError.setText(getResources().getString(R.string.lumpsum_cal_error_max_roi));

            } else {

                String rawValue = mEtAmount.getText().toString().replaceAll(",", "");
                mBrokerActivity.convertIntoCurrencyFormat(rawValue, mEtAmount);

                try {
                    w_delay = 0;
                    w_tot = 0;
                    amt_inv = 0;
                    amtD = Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", ""));  // spi calculator
                    nYears = Integer.parseInt(mEtYear.getText().toString());
                    rorD = Double.parseDouble(mEtRate.getText().toString());
                    inflate = Double.parseDouble(mEtExpectedInflation.getText().toString());
                    double inrateD = Double.parseDouble("0");


                    double r = rorD / 100;
                    double nMonths = (nYears * 12);
                    double v = 0;

                    if (mInflationbox.isChecked()) {

                        double ror = rorD - inflate;
//
                        w_tot = amtD * (Math.pow((1 + ror / 100), nYears));
                    } else {
                        w_tot = amtD * (Math.pow((1 + r), nYears));
                    }

/*                for (int i = 0; i < nMonths; i++) {
                    amt_inv = amt_inv + amtD;
                    v = v + Math.pow((1 + r), (nMonths - i) / 12);
                }*/

//                w_tot = amtD * v;

                    /*  mLinerResult.setVisibility(View.VISIBLE);*/
                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));


                    String strAmount = format.format(amtD);
                    String[] resultAmount = strAmount.split("\\.", 0);
                    String strAmount1 = format.format(w_tot);
                    String[] resultAmount1 = strAmount1.split("\\.", 0);

                    mTvResultAmount.setText(resultAmount1[0]);
                    mTvSipTitle.setText(getString(R.string.txt_for) + ((int) nYears) + getString(R.string.years_at) + (rorD) + getString(R.string.annual_return_will_grow)+"\n"+getString(R.string.your_money_to));
                    mTvMainAmount.setText(resultAmount[0]);


                    Double onlyProfit = (w_tot - amt_inv);
                    long value3 = Math.round(onlyProfit);
                    String strProfit = format.format(value3);
                    String[] arrayProfit = strProfit.split("\\.", 0);



                    String announcement =
                            getString(R.string.lumpsum_cal_one_time_investment_txt) +". " + mTvMainAmount.getText().toString() + ". "
                             + mTvSipTitle.getText().toString() + ". "
                            + mTvResultAmount.getText().toString() ;

                    mTvMainAmount.post(() ->
                            mTvMainAmount.announceForAccessibility(announcement)
                    );

                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }


            }
        } else {
            if (mEtAmount.getText().toString().replaceAll(",", "").replaceAll(",", "").equals("") || mEtAmount.getText().toString().replaceAll(",", "").equals("0")) {
//                mEtAmount.setError(getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.setText(getResources().getString(R.string.lumsum_cal_error_empty_sip_amnt));
            } else if ((Long.parseLong(mEtAmount.getText().toString().replaceAll(",", ""))) < 500) {
                //mEtAmount.setError("Minimum amount will be at least 500");
                mTvAmountError.setVisibility(View.VISIBLE);
                mTvAmountError.setText(getResources().getString(R.string.lumpsum_cal_error_less_amnt));
            } else if (mEtYear.getText().toString().equals("") || mEtYear.getText().toString().equals("0")) {
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.lumpsum_cal_error_more_amnt));
            } else if (Integer.parseInt(mEtYear.getText().toString()) > 99) {
                mEtYear.setText("50");
                mTvInvestmentPeriodError.setVisibility(View.VISIBLE);
                mTvInvestmentPeriodError.setText(getResources().getString(R.string.lumspum_cal_error_duration));
            } else if (mEtRate.getText().toString().equals("") ||mEtRate.getText().toString().equals(".") || mEtRate.getText().toString().equals("0")) {
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.setText(getResources().getString(R.string.lumpsum_cal_error_ror));
            } else if (Double.parseDouble(mEtRate.getText().toString()) > 100) {
                mEtRate.setText("100.00");
                mTvAnnualReturnError.setVisibility(View.VISIBLE);
                mTvAnnualReturnError.setText(getResources().getString(R.string.lumpsum_cal_error_max_amnt));
            } else if (mEtExpectedInflation.getText().toString().equals("") ||mEtExpectedInflation.getText().toString().equals(".") || mEtExpectedInflation.getText().toString().equals("0")) {
                mTvInflationError.setVisibility(View.VISIBLE);
                mTvInflationError.setText(getResources().getString(R.string.lumpsum_cal_error_roi));
            } else if (Double.parseDouble(mEtExpectedInflation.getText().toString()) > 100) {
                mEtExpectedInflation.setText("100.00");
                mTvInflationError.setVisibility(View.VISIBLE);
                mTvInflationError.setText(getResources().getString(R.string.lumpsum_cal_error_max_roi));

            } else {

                String rawValue = mEtAmount.getText().toString().replaceAll(",", "");
                mActivity.convertIntoCurrencyFormat(rawValue, mEtAmount);

                try {
                    w_delay = 0;
                    w_tot = 0;
                    amt_inv = 0;
                    amtD = Double.parseDouble(mEtAmount.getText().toString().replaceAll(",", ""));  // spi calculator
                    nYears = Integer.parseInt(mEtYear.getText().toString());
                    rorD = Double.parseDouble(mEtRate.getText().toString());
                    inflate = Double.parseDouble(mEtExpectedInflation.getText().toString());
                    double inrateD = Double.parseDouble("0");


                    double r = rorD / 100;
                    double nMonths = (nYears * 12);
                    double v = 0;

                    if (mInflationbox.isChecked()) {

                        double ror = rorD - inflate;
//
                        w_tot = amtD * (Math.pow((1 + ror / 100), nYears));
                    } else {
                        w_tot = amtD * (Math.pow((1 + r), nYears));
                    }

/*                for (int i = 0; i < nMonths; i++) {
                    amt_inv = amt_inv + amtD;
                    v = v + Math.pow((1 + r), (nMonths - i) / 12);
                }*/

//                w_tot = amtD * v;

                    /*          mLinerResult.setVisibility(View.VISIBLE);*/
                    Format format = NumberFormat.getCurrencyInstance(new Locale("en", "in"));


                    String strAmount = format.format(amtD);
                    String[] resultAmount = strAmount.split("\\.", 0);
                    String strAmount1 = format.format(w_tot);
                    String[] resultAmount1 = strAmount1.split("\\.", 0);

                    mTvResultAmount.setText(resultAmount1[0]);
                    mTvSipTitle.setText(getString(R.string.for_space) + ((int) nYears) + getString(R.string.years_at) + (rorD) + getString(R.string.annual_return_will_grow_your_money_to));
                    mTvMainAmount.setText(resultAmount[0]);


                    String announcement =
                            getString(R.string.lumpsum_cal_one_time_investment_txt) +". " + mTvMainAmount.getText().toString() + ". "
                                    + mTvSipTitle.getText().toString() + ". "
                                    + mTvResultAmount.getText().toString() ;


                    if (isAdded() && mTvMainAmount != null) {
                        mTvMainAmount.post(() -> {
                            if (isAdded() && getView() != null && mTvMainAmount != null) {
                                mTvMainAmount.announceForAccessibility(announcement);
                            }
                        });
                    }
                } catch (Exception e) {
                    if (BuildConfig.DEBUG)
                        e.printStackTrace();
                }

            }
        }
    }

    public void saveFrameLayout() {
        mClCalcFooter.setVisibility(View.VISIBLE);
        ll_calculator_header.setVisibility(View.VISIBLE);
        loadUpdatedView();
    }


    private void loadUpdatedView() {
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          createImage();
                                      }
                                  },

                100);
    }

    private void createImage() {
        if (mBrokerActivity != null) {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mBrokerActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        } else {
            int totalHeight = mScrollView.getChildAt(0).getHeight();
            int totalWidth = mScrollView.getChildAt(0).getWidth();
            Bitmap bitmap = getBitmapFromView(mScrollView, totalHeight, totalWidth);

            try {
                Uri imageUri = Utils.saveImage(bitmap, mActivity);
                Intent waIntent = new Intent(Intent.ACTION_SEND);
                waIntent.setType("image/*");
                waIntent.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(waIntent, "Share with"));
            } catch (Exception e) {
                System.out.println(e.getLocalizedMessage());
            } finally {
                mClCalcFooter.setVisibility(View.GONE);
                ll_calculator_header.setVisibility(View.GONE);
                mScrollView.destroyDrawingCache();
            }
        }
    }

    private Bitmap getBitmapFromView(View view, int height, int width) {
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null)
            bgDrawable.draw(canvas);
        else
            canvas.drawColor(Color.WHITE);
        view.draw(canvas);
        return bitmap;
    }

    @Override
    public void onToolbarItemClick(View view) {
        if (view.getId() == R.id.iv_share) {
                saveFrameLayout();
}
else if (view.getId() == R.id.iv_refresh) {
                refreshView();
}
    }

    private class GenericTextWatcher implements TextWatcher {
        private View view;

        private GenericTextWatcher(View view) {
            this.view = view;
        }

        public void afterTextChanged(Editable editable) {
            if (mBrokerActivity != null) {
                if (mBrokerActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                } else if (mBrokerActivity.getCurrentFocus() == mEtExpectedInflation) {
                    delayCall();
                }

            } else {
                if (mActivity.getCurrentFocus() == mEtAmount) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtYear) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtRate) {
                    delayCall();
                } else if (mActivity.getCurrentFocus() == mEtExpectedInflation) {
                    delayCall();
                }
            }
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            clearErrorMessage();
        }

    }


}
