package investwell.client.adapter;
import android.content.ActivityNotFoundException;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.iw.mint.sdk.R;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import investwell.activity.AppIntoMintWebPortalActivity;
import investwell.utils.CrmBuilder;
import investwell.utils.Extensions;
import investwell.utils.TimeDateUtils;
import investwell.utils.Utils;


public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {
    public ArrayList<JSONObject> mDataList;
//    private Context mContext;
    private OnNotificationClick mListener;
    private String mType = "";
    public static final String URL_REGEX = "^((https?|ftp)://|(www|ftp)\\.)?[a-z0-9-]+(\\.[a-z0-9-]+)+([/?].*)?$";

    public interface OnNotificationClick{
        void OnItem(int position);
        void OnUrlClick(String url);
        void onItemClick(int position, JSONObject jsonObject);
    }



    public NotificationAdapter(OnNotificationClick listener, ArrayList<JSONObject> list) {
//        mContext = context;
        mListener=listener;
        mDataList = list;
    }

    @NonNull
    @Override
    public NotificationAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_notification, viewGroup, false);
        return new NotificationAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final NotificationAdapter.ViewHolder viewHolder, final int position) {
        viewHolder.setItem(position);

    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public void updateList(List<JSONObject> list) {
        mDataList.clear();
        mDataList.addAll(list);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView mTvTitle, mTvMessage, mTime, mTvViewMore;
        ImageView mIvBannerNotification;
        ConstraintLayout clNotification;


        public ViewHolder(View view) {
            super(view);
            mTvViewMore = view.findViewById(R.id.textView30);
            mTvTitle = view.findViewById(R.id.tvTitle);
            mTvMessage = view.findViewById(R.id.tvMessage);
            mTime = view.findViewById(R.id.time);
            mIvBannerNotification = view.findViewById(R.id.iv_notification_banner);
            clNotification = view.findViewById(R.id.clNotification);
        }


        public void setItem(final int position) {
            final JSONObject obj = mDataList.get(position);
            // Title & Message
            mTvTitle.setText(obj.optString("title"));
            String message = obj.has("body") ? obj.optString("body") : obj.optString("text");
            Extensions.clickableTextUrl(mTvMessage,message, url -> {
                mListener.OnUrlClick(url);
            return null;
            });



            // Time
            mTime.setText(TimeDateUtils.formatDateWithTime(obj.optString("createdAt")));

            // Image
            String img = obj.optString("imgpath");
            if (!TextUtils.isEmpty(img) && !"null".equalsIgnoreCase(img)) {
                mIvBannerNotification.setVisibility(View.VISIBLE);
                try {
                    Picasso.get()
                            .load(img)
                            .placeholder(R.mipmap.default_generic_icon)
                            .error(R.mipmap.default_generic_icon)
                            .into(mIvBannerNotification);
                } catch (Exception ignored) {}
            } else {
                mIvBannerNotification.setVisibility(View.GONE);
            }
            // Click handling
            String source = obj.optString("source", "");
            boolean isCrm = isValidString(source) && "crm".equalsIgnoreCase(source);
            boolean hasLink = !TextUtils.isEmpty(obj.optString("link")) &&
                    !"null".equalsIgnoreCase(obj.optString("link"));

            View.OnClickListener clickListener = v -> mListener.onItemClick(position, obj);

            if (isCrm || hasLink) {
                mTvViewMore.setVisibility(View.VISIBLE);

                // single source of truth for click
                itemView.setOnClickListener(clickListener);

            } else {
                mTvViewMore.setVisibility(View.GONE);
                itemView.setOnClickListener(null);
            }
        }
    }

    private boolean isValidString(String value) {
        return !TextUtils.isEmpty(value) && !"null".equalsIgnoreCase(value);
    }
}




