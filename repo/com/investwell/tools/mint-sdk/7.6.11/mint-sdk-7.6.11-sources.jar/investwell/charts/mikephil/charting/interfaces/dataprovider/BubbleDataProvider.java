package investwell.charts.mikephil.charting.interfaces.dataprovider;

import investwell.charts.mikephil.charting.data.BubbleData;

public interface BubbleDataProvider extends BarLineScatterCandleBubbleDataProvider {

    BubbleData getBubbleData();
}
