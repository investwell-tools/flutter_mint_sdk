package investwell.client.fragments.others;

import static android.os.Build.VERSION.SDK_INT;
import static investwell.di.core.LogExtKt.logD;
import static investwell.utils.KtorHelper.requestCallDownload;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.iw.mint.sdk.BuildConfig;
import com.iw.mint.sdk.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import investwell.activity.AppApplication;
import investwell.client.activity.ClientActivity;
import investwell.utils.ApiRequestType;
import investwell.utils.AppHeaderType;
import investwell.utils.AppSession;
import investwell.utils.BaseFragment;
import investwell.utils.Config;
import investwell.utils.KtorCallBackDownload;
import investwell.utils.ProgressBarCommon;
import investwell.utils.UtilityKotlin;
import investwell.utils.Utils;


public class FragCapitalGainUnrealized extends BaseFragment implements View.OnClickListener {
    private RequestQueue requestQueue;
    private AppSession mSession;
    private int mRequestCount;
    private File mFileSave;
    private Button mTvButton;
    private TextView mTvError, tvRmEmailId;
    private ClientActivity mActivity;
    private Spinner mMemberSpinner, mSpUserType, mSpCas, mSpReportType, mSpExportType;
    private LinearLayout mLinerUserType, mLinerUsers;
    private List<JSONObject> mMemberList, mMemberTypesList;
    private int mSelectedPosition = 0, mSelectedUserTypePosition = 0;
    private RelativeLayout rlRmemail;
    private CheckBox cbSendOnEmail, cbCcRm;

    private AppApplication mAppplication;

    @Override
    public void onResume() {
        super.onResume();
     /*   if (mActivity != null)
            FirebaseAnalytics.getInstance(mActivity).setCurrentScreen(mActivity, this.getClass().getSimpleName(), null);*/
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ClientActivity) {
            this.mActivity = (ClientActivity) context;
            mSession = AppSession.getInstance(mActivity);
            mAppplication = (AppApplication) mActivity.getApplication();
        }
    }

    private void setUpToolBar() {
        ToolbarFragment fragToolBar = (ToolbarFragment) getChildFragmentManager().findFragmentById(R.id.frag_toolBar);
        if (fragToolBar != null) {
            fragToolBar.setUpToolBar(getResources().getString(R.string.capital_gain_unrealized), true, false, false, false, false, false, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.frag_capital_gain_realized, container, false);
        setUpToolBar();
        mActivity.setMainVisibility(this, null);
        LinearLayout ll_reportType = view.findViewById(R.id.ll_reportType);
        mMemberSpinner = view.findViewById(R.id.member_spinner);
        mSpUserType = view.findViewById(R.id.spUserType);
        mLinerUserType = view.findViewById(R.id.linerUserType);
        mLinerUsers = view.findViewById(R.id.linerUsers);
        tvRmEmailId = view.findViewById(R.id.tvRmEmailId);
        rlRmemail = view.findViewById(R.id.rlRmemail);
        cbSendOnEmail = view.findViewById(R.id.checkBox);
        cbCcRm = view.findViewById(R.id.cbCcRm);


        mTvError = view.findViewById(R.id.tvError);
        mTvError.setVisibility(View.GONE);

        mSpCas = view.findViewById(R.id.sp_Cas_ReportType);
        mSpReportType = view.findViewById(R.id.mSpReportType);
        mSpExportType = view.findViewById(R.id.exportType);
        rlRmemail.setVisibility(View.GONE);


        mTvButton = view.findViewById(R.id.tvDownload);
        mTvButton.setOnClickListener(this);
        cbSendOnEmail.setOnClickListener(this);
        mMemberList = new ArrayList<>();


        if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
            if (mSession.getClientObject().isEmpty()) {
                mLinerUserType.setVisibility(View.VISIBLE);
                mLinerUsers.setVisibility(View.VISIBLE);
                setSpinnerMemberType();
            } else {
                mLinerUserType.setVisibility(View.GONE);
                mLinerUsers.setVisibility(View.VISIBLE);
                getAllMembers("client");
            }
        } else {
            mLinerUserType.setVisibility(View.GONE);
            mLinerUsers.setVisibility(View.VISIBLE);
            getAllMembers("client");
        }
        getFamilyHeadEmail();
        getExportType();
        mSpExportType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 2) {
                    mTvButton.setText(getString(R.string.send_space));
                    cbSendOnEmail.setVisibility(View.GONE);
                    cbSendOnEmail.setChecked(true);
                    cbSendOnEmail.setEnabled(false);
                    rlRmemail.setVisibility(View.VISIBLE);
                    ll_reportType.setVisibility(View.GONE);

                } else {
                    ll_reportType.setVisibility(View.VISIBLE);
                    cbSendOnEmail.setChecked(false);
                    cbSendOnEmail.setEnabled(true);
                    cbSendOnEmail.setVisibility(View.GONE);
                    rlRmemail.setVisibility(View.GONE);
                    if (cbCcRm.isChecked()) {
                        cbCcRm.setChecked(false);
                    }
                    mTvButton.setText(getString(R.string.download_space));
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                cbSendOnEmail.setVisibility(View.GONE);
            }
        });
        getReportType();
        getCASDate();
//    https://demo.investwell.app/webapi/client/reports/getFamilyHeadEmail?selectedUser={"uid":"6a1ecbcd02d490f7ca6eac7c5c806c7f","levelNo":98}&componentForLoader={"componentName":"SendReportOptions"}&investorUid=6a1ecbcd02d490f7ca6eac7c5c806c7f
        return view;
    }

    private void getExportType() {
        List<String> exportTypeList = new ArrayList<>();
        exportTypeList.add("PDF");
        exportTypeList.add("Excel");
        exportTypeList.add("E-Mail");

        try {
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, exportTypeList);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpExportType.setAdapter(dataAdapter);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getReportType() {
        List<String> reportTypeList = new ArrayList<>();
        reportTypeList.add("Summary");
        reportTypeList.add("Details");

        try {
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, reportTypeList);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpReportType.setAdapter(dataAdapter);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getCASDate() {
        List<String> casList = new ArrayList<>();
        casList.add("All");
        casList.add("Managed Data");
        casList.add("Outside Data");
        try {
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(mActivity, R.layout.spinner_bg, casList);
            dataAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpCas.setAdapter(dataAdapter);
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }
    }


    @Override
    public void onClick(View v) {
        Intent intent;
        if (v.getId() == R.id.tvDownload) {
                if (cbSendOnEmail.isChecked()) {
                    sendEmail();
                } else {
                    if (mMemberList.size() > 0) {
                        downloadFile2();
                    } else {
                        Toast.makeText(getActivity(), getString(R.string.txt_something_wrong_try_again_later), Toast.LENGTH_SHORT).show();
                    }
                }
}
else if (v.getId() == R.id.checkBox) {
                if (cbSendOnEmail.isChecked()) {
                    rlRmemail.setVisibility(View.VISIBLE);
                } else {
                    rlRmemail.setVisibility(View.GONE);
                }
}
    }


    private void setSpinnerMemberType() {
        try {
            mMemberTypesList = new ArrayList<>();
            List<String> listMemType = new ArrayList<>();

            JSONArray jsonArray = new JSONArray(mSession.getLowerReportingLevels());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.optJSONObject(i);
                mMemberTypesList.add(jsonObject);
                listMemType.add(jsonObject.optString("levelName"));
            }


            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMemType);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mSpUserType.setAdapter(adapter);
            mSpUserType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedUserTypePosition = position;
                    getAllMembers("broker");
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }


    private void setSpinnerMembers(String rawData) {
        try {
            mMemberList = new ArrayList<>();
            List<String> listMem = new ArrayList<>();
            listMem.add(getString(R.string.all));
            JSONObject jsonObject = new JSONObject(rawData);

            if (jsonObject.optInt("status") == 0) {

                JSONObject jsonObjectMain = jsonObject.optJSONObject("result");
                JSONArray jsonArray = jsonObjectMain.getJSONArray("data");
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.optJSONObject(i);
                    mMemberList.add(jsonObject1);
                    listMem.add(jsonObject1.optString("name"));
                }
            } else {
                String service_msg = jsonObject.optString("message");
                Toast.makeText(getActivity(), service_msg, Toast.LENGTH_SHORT).show();
            }

            ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.spinner_bg, listMem);
            adapter.setDropDownViewResource(R.layout.spinner_dropdown);
            mMemberSpinner.setAdapter(adapter);
            mMemberSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    mSelectedPosition = position;
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            if (BuildConfig.DEBUG)
                        e.printStackTrace();
        }

    }

    private void getFamilyHeadEmail() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        if (Utils.getSelectedLevelNo(mSession).equals("1")){
            return;
        }
        String url = "";

        try {

            JSONObject jsonObject2 = new JSONObject();
            jsonObject2.put("componentName", "SendReportOptions");

            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_FAMILY_HEAD_EMAIL + "levelNo=" + Utils.getSelectedLevelNo(mSession) + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            //  https://demo.investwell.app/webapi/client/reports/getFamilyHeadEmail?
            // selectedUser={"uid":"6a1ecbcd02d490f7ca6eac7c5c806c7f","levelNo":98}&componentForLoader=
            // {"componentName":"SendReportOptions"}&investorUid=6a1ecbcd02d490f7ca6eac7c5c806c7f
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                mBar.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        JSONObject jsonObject2 = jsonObject.optJSONObject("result");
                        String familyHead = jsonObject2.optString("fhEmail");
                        tvRmEmailId.setText(familyHead);
                    }
                } catch (Exception e) {

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                mBar.dismiss();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void sendEmail() {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String uId = "";
        String url = "";
        String levelNo = "";
        String broukerUid = "";
        try {

            int selectedPosition = mMemberSpinner.getSelectedItemPosition();
            int selectedCasPosition = mSpCas.getSelectedItemPosition();

            JSONObject jsonObject1 = new JSONObject();
            if (mSession.getHasLoging() && mSession.getLoginType().equals("broker")) {
                uId = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
            } else {
                uId = mSession.getUid();
                levelNo = mSession.getLevelNo();
            }
            broukerUid = mSession.getBrokerUID();
            jsonObject1.put("uid", uId);
            jsonObject1.put("levelNo", levelNo);


            JSONArray filterArray = new JSONArray();
            JSONObject casObject = new JSONObject();
            JSONArray preferences = new JSONArray();
            JSONObject pObject = new JSONObject();
            JSONArray jm = new JSONArray();
            JSONObject eq = new JSONObject();
            JSONObject mf = new JSONObject();

            mf.put("name", "MF");
            mf.put("isRequired", true);


            eq.put("name", "EQ");
            eq.put("isRequired", true);


            jm.put(mf);
            jm.put(eq);
            pObject.put("products", jm);
            preferences.put(pObject);

            if (selectedCasPosition == 0) {
                casObject.put("dataSource", String.valueOf(selectedCasPosition));
            } else if (selectedCasPosition == 1) {
                casObject.put("dataSource", String.valueOf(selectedCasPosition));
            } else {
                casObject.put("dataSource", String.valueOf(selectedCasPosition));
            }
       /*     Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE, -1); // Subtract 1 day
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String yesterdayDate = sdf.format(calendar.getTime());
            casObject.put("toDate", yesterdayDate);*/
            filterArray.put(casObject);


            if (selectedPosition > 0) {
                JSONObject jsonObject = mMemberList.get(selectedPosition - 1);
                String selectedUid = jsonObject.optString("uid");
                String selectedLevelNo = jsonObject.optString("levelNo");
                broukerUid = jsonObject.optString("brokerUid");

                JSONObject selectedUserForFilter = new JSONObject();
                selectedUserForFilter.put("uid", selectedUid);
                selectedUserForFilter.put("levelNo", selectedLevelNo);

                JSONObject filterObject = new JSONObject();
                filterObject.put("selectedUser", selectedUserForFilter);
                filterArray.put(filterObject);
            }


            url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.SEND_REPORT_ON_EMAIL + "filters=" + filterArray + "&purpose=Capital+Gain+Unrealized&purposeVal=CGUR&ccWithRm=" + cbCcRm.isChecked() + "&brokerUid=" + broukerUid + "&preferences=" + preferences + "&investorUid=" + uId + "&selectedUser=" + jsonObject1;

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
        } catch (Exception e) {

        }
        final ProgressDialog mBar = ProgressDialog.show(mActivity, null, null, true, false);
        mBar.setContentView(R.layout.progress_layout);
        mBar.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                mBar.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.optInt("status") == 0) {
                        Toast.makeText(mActivity, jsonObject.optString("message"), Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {

                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                mBar.dismiss();
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }


    private void getAllMembers(String type) {
        if (UtilityKotlin.hasReAuthTimeNotValid(mSession, requireActivity())){
            return;
        }
        String url = "";


        try {
            String levelNo = "";


            if (type.equals("broker")) {
                JSONObject jsonObject = mMemberTypesList.get(mSelectedUserTypePosition);
                levelNo = jsonObject.optString("levelNo");

                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MEMBERS + "levelNo=" + levelNo + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.GET_MEMBERS + "levelNo=" + "100" + "&investorUid=" + Utils.getSelectedUid(mSession) + "&selectedUser=" + Utils.getSelectedUserObject(mSession);

            }
            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {

        }

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                setSpinnerMembers(response);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                if (!isAdded())
                    return;
                UtilityKotlin.parseVolleyError(volleyError, mSession, getMCurrentActivity(), "");

            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                return UtilityKotlin.returnHeaderAfterLogin(mSession, getMCurrentActivity());
            }

            @Override
            public Response<String> parseNetworkResponse(NetworkResponse response) {
                UtilityKotlin.getNetworkResponse(mSession, response, getMCurrentActivity());
                return super.parseNetworkResponse(response);
            }

        };
        stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {
                int statusCode = error.networkResponse.statusCode;
                if (statusCode == 401) {
                    AppApplication appApplication = (AppApplication) getActivity().getApplication();
                    appApplication.showCommonDailog(getActivity(), getString(R.string.txt_session_expired), getString(R.string.txt_please_login_again_for_continue), "sessionExpired");
                }
            }
        });
        requestQueue = Volley.newRequestQueue(getActivity());
        stringRequest.setShouldCache(false);
        requestQueue.add(stringRequest);
    }

    private void downloadFile2() {
        if (SDK_INT <= Build.VERSION_CODES.Q) {
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                setPermission();
                return;
            }
        }

        String url = "";
        int selectedExportPosition = mSpExportType.getSelectedItemPosition();
        final String[] type = {""};
        if (selectedExportPosition != 0)
            type[0] = "xls";
        else
            type[0] = "pdf";
        try {
            int selectedPosition = mMemberSpinner.getSelectedItemPosition();
            int selectedReportPosition = mSpReportType.getSelectedItemPosition();
            int selectedCasPosition = mSpCas.getSelectedItemPosition();
            String uid = "",levelNo="";
            if (selectedPosition==0){
                if (mSession.getClientObject().isEmpty()) {
                    uid = mSession.getUid();
                    levelNo = mSession.getLevelNo();
                } else {
                    uid = UtilityKotlin.getClientHopObject(mSession).optString("uid");
                    levelNo = UtilityKotlin.getClientHopObject(mSession).optString("levelNo");
                }

            } else {
                JSONObject jsonObject = mMemberList.get(selectedPosition - 1);
                uid = jsonObject.optString("uid");
                levelNo = jsonObject.optString("levelNo");
            }
            JSONObject mf = new JSONObject();
            JSONObject reportTyObject = new JSONObject();
            JSONObject pObject = new JSONObject();
            JSONArray preferences = new JSONArray();
            JSONArray casOptions = new JSONArray();
            JSONArray jm = new JSONArray();
            JSONObject casObject = new JSONObject();
            JSONObject eq = new JSONObject();

            mf.put("name", "MF");
            mf.put("isRequired", true);


            eq.put("name", "EQ");
            eq.put("isRequired", true);


            jm.put(mf);
            jm.put(eq);
            pObject.put("products", jm);

            if (selectedReportPosition == 0) {
                reportTyObject.put("reportType", "summary");
            } else {
                reportTyObject.put("reportType", "detailed");
            }
            preferences.put(pObject);
            preferences.put(reportTyObject);


            if (selectedCasPosition == 0) {
                casObject.put("dataSource", String.valueOf(selectedCasPosition));
            } else if (selectedCasPosition == 1) {
                casObject.put("dataSource", String.valueOf(selectedCasPosition));
            } else {
                casObject.put("dataSource", String.valueOf(selectedCasPosition));
            }
            casOptions.put(casObject);


            if (selectedExportPosition != 0) {
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_CAPITAL_GAIN_UNREALIZED_XLS + "filters=" + casOptions + "&applicantUid=" + uid + "&levelNo=" + levelNo + "&clubTxns=true" + "&preferences=" + preferences + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            } else {
                if (Utils.getSelectedLevelNo(mSession).equals("1")){
                    return;
                }
                url = "https://" + mSession.getUserBrokerDomain() + mSession.getHostingPath() + Config.DOWNLOAD_CAPITAL_GAIN_UNREALIZED_PDF + "filters=" + casOptions + "&applicantUid=" + uid + "&levelNo=" + levelNo + "&clubTxns=true" + "&preferences=" + preferences + "&selectedUser=" + Utils.getSelectedUserObject(mSession);
            }
            // in case of excel file
            //https://spvithlani.investwell.app/webapi/client/reports/capitalGain/downloadUnrealizedCapitalGainXls?filters=[{"casArnOption":"0"}]&applicantUid=6158fa1dba4bf04015e91d2e2caf5bcc&levelNo=98&preferences=[{"products":[{"name":"MF","isRequired":true},{"name":"EQ","isRequired":true}]},{"reportType":"summary"}]

            url = UtilityKotlin.setRefreshKeyInExistingApi(url, mSession);
            url = URLDecoder.decode(url, "UTF-8");

        } catch (Exception e) {

        }

        requestCallDownload(
                requireActivity(),
                mSession,
                url,
                ApiRequestType.GET,
                new JSONObject(),
                AppHeaderType.AFTER_LOGIN,
                "RCUGain_", "."+ type[0], new KtorCallBackDownload() {
                    @Override
                    public void onLoading(boolean isLoading) {
                        if (isLoading) {
                            ProgressBarCommon.showDialog(requireActivity(), getString(R.string.txt_downloading_file_please_wait));
                        } else {
                            ProgressBarCommon.dismissDialog();
                        }
                    }

                    @Override
                    public void onSuccess(File mFileSave, @Nullable Uri uri, int statusCode) {
                        String type = "";
                        if (selectedExportPosition != 0)
                            type = "xls";
                        else
                            type = "pdf";
                        if (type.equals("xls")) {
                            type = "vnd.ms-excel";
                        }
                        mActivity.showCommonDownload(mActivity, getString(R.string.txt_successfully), getString(R.string.txt_capital_gain_unrealized_report_download_successfully), type, mFileSave, uri);


                    }
                });

    }


    private void setPermission() {
        final String[] permissionList = UtilityKotlin.getFilePermissionsList();

        boolean hasPermissions = true;
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                hasPermissions = false;
                break;
            }
        }
        if (!hasPermissions) {
            requestMultiPermissions(permissionList);
        } else {
            logD("DB", "PERMISSION GRANTED");
        }

    }

    private void requestMultiPermissions(String[] permissionList) {
        List<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissionList) {
            if (ContextCompat.checkSelfPermission(requireActivity(), permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }


        if (!permissionsToRequest.isEmpty()) {
            String[] pendingPermission = permissionsToRequest.toArray(new String[0]);
            rqPermission.launch(pendingPermission);
        }
    }

    private final ActivityResultLauncher<String[]> rqPermission = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), permissions -> {
        boolean isGranted = true;
        if (permissions.containsValue(true)) {
            Log.d("DB", "PERMISSION GRANTED");
        } else {
            isGranted = false;
            Toast.makeText(getActivity(), getString(R.string.txt_storage_permission_required_for_download_pdf_file), Toast.LENGTH_LONG).show();
        }
        if (isGranted) {
            downloadFile2();
        }
    });

}






