/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.iw.mint.sdk;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.iw.mint.sdk";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "prod";
  // Field from product flavor: prod
  public static final String CONSOLE = "ED:DA:F6:1D:D8:7E:B7:AD:00:D6:2C:5F:DD:96:67:94:A8:78:9B:D1:4D:65:36:DC:CA:9A:C3:01:C7:24:7A:57";
  // Field from default config.
  public static final boolean IS_ENV_SDK = true;
  // Field from product flavor: prod
  public static final String L_HOST = "mintes.mintservices.in";
  // Field from product flavor: prod
  public static final String MAIN_HOST = "*.investwell.app";
  // Field from default config.
  public static final int VERSION_CODE = 7611;
  // Field from default config.
  public static final String VERSION_NAME = "7.6.13";
  // Field from product flavor: prod
  public static final boolean isCodeTemporalEnabled = false;
  // Field from product flavor: prod
  public static final boolean isLogoDark = false;
  // Field from product flavor: prod
  public static final boolean isRiskyNetworkEnabled = false;
  // Field from product flavor: prod
  public static final boolean isScreenShotIsNotEnabled = false;
  // Field from product flavor: prod
  public static final boolean isSslEnabled = true;
  // Field from product flavor: prod
  public static final boolean isVPNEnabled = false;
  // Field from product flavor: prod
  public static final boolean isVaptEnabled = false;
}
