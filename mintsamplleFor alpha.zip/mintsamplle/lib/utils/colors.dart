

import 'package:flutter/material.dart';

const Color appBg= Color(0xffffffff);
const Color blue= Color(0xff2042FE);
const Color white= Color(0xffffffff);

