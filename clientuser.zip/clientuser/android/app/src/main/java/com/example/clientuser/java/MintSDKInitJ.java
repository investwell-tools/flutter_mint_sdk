package com.example.clientuser.java;

import android.app.TaskStackBuilder;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import com.example.clientuser.kotlin.MainActivity;
import com.example.clientuser.R;

import investwell.activity.SplashActivity;
import investwell.sdk.MintSDK;
import io.flutter.embedding.android.FlutterActivity;

public class MintSDKInitJ extends FlutterActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mint_sdkinit);

        getBundles();
    }

    private void getBundles() {
        if (getIntent() != null && getIntent().hasExtra("route") && MainActivityJ.sdkInitialized ==true) {
            String domain = getIntent().getStringExtra("domain");
            String fcm = getIntent().getStringExtra("fcm");
            String sso = getIntent().getStringExtra("sso");
            MainActivityJ.sdkInitialized = false;
            invokeSDK(sso, fcm, domain);
        } else {
            // Remove activity
            if (!MainActivityJ.sdkInitialized) {
//                startActivity(new Intent(this, MainActivityJ.class));
//                finish();
                Intent intent = new Intent(this, MainActivityJ.class);
                // Use TaskStackBuilder to maintain the back stack when going back to MainActivityJ
                TaskStackBuilder.create(this)
                        .addNextIntentWithParentStack(intent)
                        .startActivities();
                finish();

            } else {
                finish();
            }
        }
    }

    private void invokeSDK(String sso, String fcmToken, String domain) {
        MintSDK mintSdk = new MintSDK(this);
//        mintSdk.invokeMintSDK(sso, fcmToken, domain,"com.example.clientuser.java.MintSDKInit");
       Intent mIntent = new Intent(MintSDKInitJ.this, SplashActivity.class);
        mIntent.putExtra("token", fcmToken); // required FCM Token
        mIntent.putExtra("ssoToken", sso); // required SSO Token
        mIntent.putExtra("domain", domain);
        startActivity(mIntent);
    }

    @Override
    public void onBackPressed() {
        checkBackStack();
        removeAllKeys();
        finish();
    }

    private void checkBackStack() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // For Android 12 and above, use the regular activity behavior
            super.onBackPressed();
        } else {
            // For below Android 12, handle back stack properly
            TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(this);
            taskStackBuilder.addNextIntentWithParentStack(new Intent(this, MainActivityJ.class));
            taskStackBuilder.startActivities();
        }
    }
//    private void checkBackStack() {
//        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(this);
//        taskStackBuilder.addNextIntentWithParentStack(new Intent(this, MainActivity.class));
//        taskStackBuilder.startActivities();
//    }

    @Override
    protected void onPause() {
        super.onPause();
        removeAllKeys();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        removeAllKeys();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    private void removeAllKeys() {
        if (getIntent().hasExtra("route")) {
            getIntent().removeExtra("route");
            // Uncomment if you want to clear the task flags
            // getIntent().removeFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        }
    }
}
