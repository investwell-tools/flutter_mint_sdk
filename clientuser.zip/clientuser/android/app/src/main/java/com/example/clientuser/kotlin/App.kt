package com.example.clientuser.kotlin

import investwell.activity.AppApplication

class App:AppApplication() {
    override fun onCreate() {
        super.onCreate()
    }
}