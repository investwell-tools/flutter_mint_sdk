package com.example.clientuser.kotlin

import android.content.Intent
import android.os.Bundle
import androidx.core.app.TaskStackBuilder
import com.example.clientuser.R
import com.example.clientuser.java.MainActivityJ
import investwell.sdk.MintSDK
import io.flutter.embedding.android.FlutterActivity

class MintSDKInit : FlutterActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mint_sdkinit)
        getBundles()
    }
    private fun getBundles(){
        if (intent !=null && intent.hasExtra("route") && MainActivity.sdkInitialized == true){
            val domain :String = intent.getStringExtra("domain")!!
            val fcm :String= intent.getStringExtra("fcm")!!
            val sso :String= intent.getStringExtra("sso")!!
            MainActivity.sdkInitialized = false
            invokeSDK(sso = sso, fcmToken = fcm, domain = domain)

        }else{
            // remove activity
            if(MainActivity.sdkInitialized ==false){

//                startActivity(new Intent(this, MainActivityJ.class));
//                finish();
                val intent = Intent(this, MainActivityJ::class.java)

                // Use TaskStackBuilder to maintain the back stack when going back to MainActivityJ
                android.app.TaskStackBuilder.create(this)
                    .addNextIntentWithParentStack(intent)
                    .startActivities()
                finish()
            }else{
                finish()
            }

//           finish()
        }
    }

    private fun invokeSDK(sso: String,fcmToken:String,domain:String,classWithPackage:String= "${this@MintSDKInit.packageName}.MintSDKInit") {
        val mintSdk = MintSDK(this@MintSDKInit)
        mintSdk.invokeMintSDKForFlutter(sso, fcmToken,  domain)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        removeAllKeys()
        finish()
    }


    private fun checkBackStack(){
        val taskStackBuilder = TaskStackBuilder.create(this@MintSDKInit)
        taskStackBuilder.addNextIntentWithParentStack(
            Intent(this@MintSDKInit, MainActivity::class.java)
        )
        taskStackBuilder.startActivities()
    }
    override fun onPause() {
        super.onPause()
        removeAllKeys()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeAllKeys()
    }

    private fun removeAllKeys(){
        if (intent.hasExtra("route")){
            intent.removeExtra("route")
//            intent.removeFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
    }

}